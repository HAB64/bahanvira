import type { Metadata } from "next";
import { Vazirmatn } from "next/font/google";
import Script from "next/script";
import { Analytics } from "@vercel/analytics/react";
import { SpeedInsights } from "@vercel/speed-insights/next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import Header from "@/components/Header";
import { siteConfig } from "@/config/site";
import { AIConsultantWidget } from "@/components/ai/ClientWidgets";

const vazirmatn = Vazirmatn({
  subsets: ["arabic"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: siteConfig.seo.defaultTitle,
    template: siteConfig.seo.titleTemplate,
  },
  description:
    `پلتفرم مهارت‌آموزی ${siteConfig.institute.typeFa} ${siteConfig.name.fa} با ${siteConfig.experience.yearsFa} سال تجربه — آموزش مبتنی بر شایستگی (CBT) در ۳ خوشه و ۸ گروه آموزشی: فن آوری اطلاعات، امور مالی و بازرگانی، خدمات آموزشی، خدمات حقوقی، معماری، ساختمان، صنایع پوشاک، هنرهای تجسمی. ${siteConfig.location.city} ${siteConfig.location.province}`,
  keywords: [
    `آموزشگاه ${siteConfig.name.fa}`,
    "آموزش ICDL محمودآباد",
    "آموزش پایتون محمودآباد",
    "آموزش اسکرچ",
    "آموزش فارکس",
    "مشاوره کسب‌وکار",
    `آموزشگاه ${siteConfig.institute.typeFa} محمودآباد`,
    "آموزش کامپیوتر محمودآباد",
    "ICDL محمودآباد",
    "Python محمودآباد",
    "MQL5",
    "هوش مصنوعی محلی",
    "Ollama",
    "آموزش AutoCAD",
    "طراحی دوخت",
    siteConfig.founder.name,
    "CBT",
    "آموزش مبتنی بر شایستگی",
  ],
  authors: [{ name: `آموزشگاه ${siteConfig.name.fa}` }],
  creator: siteConfig.name.fullName,
  publisher: siteConfig.name.fullName,
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "fa_IR",
    url: siteConfig.url.base,
    siteName: `آموزشگاه ${siteConfig.name.fa}`,
    title: `پلتفرم مهارت‌آموزی ${siteConfig.institute.typeFa} ${siteConfig.name.fa}`,
    description:
      `${siteConfig.experience.yearsFa} سال تجربه — آموزش مبتنی بر شایستگی (CBT) در ۳ خوشه و ۸ گروه آموزشی: فن آوری اطلاعات، امور مالی و بازرگانی، خدمات آموزشی، خدمات حقوقی، معماری، ساختمان، صنایع پوشاک، هنرهای تجسمی`,
    images: [
      {
        url: `${siteConfig.url.base}${siteConfig.assets.ogImage}`,
        width: 1200,
        height: 630,
        alt: `آموزشگاه ${siteConfig.name.fa}`,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: `پلتفرم مهارت‌آموزی ${siteConfig.institute.typeFa} ${siteConfig.name.fa}`,
    description:
      `${siteConfig.experience.yearsFa} سال تجربه — آموزش مبتنی بر شایستگی (CBT) در ۳ خوشه و ۸ گروه آموزشی`,
    images: [`${siteConfig.url.base}${siteConfig.assets.ogImage}`],
  },
  alternates: {
    canonical: siteConfig.url.base,
    languages: { 'fa-IR': siteConfig.url.base },
  },
  other: {
    "google-site-verification": "Ael-05oqjIVxHvfOZ2b5peM9C_UYFj0jyGbF1PHmXMQ",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        <meta name="geo.region" content="IR-12" />
        <meta name="geo.placename" content={siteConfig.location.city} />
        <meta name="geo.position" content={`${siteConfig.location.latitude};${siteConfig.location.longitude}`} />
        <meta name="ICBM" content={`${siteConfig.location.latitude}, ${siteConfig.location.longitude}`} />
        {/* Preload hero background image for LCP optimization */}
        <link
          rel="preload"
          as="image"
          href={siteConfig.assets.heroBg}
          type="image/webp"
          fetchPriority="high"
        />
        {/* Preconnect for external font (Vazirmatn via Google Fonts) */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/* Google Tag Manager — dataLayer init (before GTM loads) */}
        <Script id="gtm-datalayer-init" strategy="beforeInteractive">
          {`window.dataLayer=window.dataLayer||[];`}
        </Script>
        {/* Google Tag Manager container — only if GTM_ID is configured */}
        {process.env.NEXT_PUBLIC_GTM_ID && (
          <Script
            id="gtm-script"
            src={`https://www.googletagmanager.com/gtm.js?id=${process.env.NEXT_PUBLIC_GTM_ID}`}
            strategy="afterInteractive"
          />
        )}
      </head>
      <body
        className={`${vazirmatn.variable} antialiased bg-background text-foreground`}
        style={{ fontFamily: "var(--font-vazirmatn)" }}
      >
        <Header />
        {children}
        <AIConsultantWidget />
        <Toaster />
        <Analytics />
        <SpeedInsights />
      </body>
    </html>
  );
}
