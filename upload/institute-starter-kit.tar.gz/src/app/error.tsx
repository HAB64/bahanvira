'use client';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div style={{
      minHeight: '60vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem',
      direction: 'rtl',
    }}>
      <div style={{
        maxWidth: '500px',
        width: '100%',
        textAlign: 'center',
      }}>
        <div style={{
          width: '56px',
          height: '56px',
          borderRadius: '14px',
          backgroundColor: '#fef2f2',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 20px',
        }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="12" />
            <line x1="12" y1="16" x2="12.01" y2="16" />
          </svg>
        </div>

        <h2 style={{
          fontSize: '1.25rem',
          fontWeight: 700,
          marginBottom: '0.5rem',
          color: '#0f172a',
        }}>
          خطا در بارگذاری صفحه
        </h2>

        <p style={{
          fontSize: '0.875rem',
          color: '#64748b',
          marginBottom: '1.5rem',
          lineHeight: 1.7,
        }}>
          در نمایش این صفحه مشکلی پیش آمده است. لطفاً دوباره تلاش کنید.
        </p>

        <button
          onClick={reset}
          style={{
            backgroundColor: '#0d9488',
            color: 'white',
            border: 'none',
            borderRadius: '10px',
            padding: '0.625rem 1.25rem',
            fontSize: '0.875rem',
            fontWeight: 600,
            cursor: 'pointer',
          }}
        >
          تلاش دوباره
        </button>
      </div>
    </div>
  );
}
