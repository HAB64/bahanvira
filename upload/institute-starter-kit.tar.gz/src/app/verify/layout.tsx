import type { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: 'استعلام مدرک | اعتبارسنجی گواهینامه‌ها',
  description: `استعلام و اعتبارسنجی مدارک فنی و حرفه‌ای و بین‌المللی صادر شده توسط ${siteConfig.name.fullName}. کد ملی یا کد رهگیری مدرک خود را وارد کنید.`,
  keywords: [
    'استعلام مدرک',
    'اعتبارسنجی مدرک',
    'استعلام گواهینامه ICDL',
    'استعلام مدرک فنی و حرفه‌ای',
    siteConfig.name.fa,
  ],
  openGraph: {
    title: 'استعلام مدرک | آموزشگاه بهان رایانه',
    description: `اعتبارسنجی مدارک صادر شده توسط ${siteConfig.name.fullName}`,
    url: `${siteConfig.url?.base || 'https://bahanrayaneh.ir'}/verify`,
  },
  alternates: {
    canonical: `${siteConfig.url?.base || 'https://bahanrayaneh.ir'}/verify`,
  },
};

export default function VerifyLayout({ children }: { children: React.ReactNode }) {
  return children;
}
