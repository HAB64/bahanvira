'use client';

import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Shield,
  Search,
  CheckCircle2,
  XCircle,
  BadgeCheck,
  FileCheck2,
  GraduationCap,
  CalendarDays,
  Hash,
  User,
  BookOpen,
  Building2,
  HelpCircle,
  Phone,
} from 'lucide-react';
import { siteConfig } from '@/config/site';

interface VerifyResult {
  found: boolean;
  data?: {
    studentName: string;
    courseName: string;
    certificateNumber: string;
    issueDate: string;
    status: 'valid' | 'expired';
    issuer: string;
    certType: string;
    trackingCode: string;
  };
  error?: string;
}

export default function VerifyPage() {
  const [nationalId, setNationalId] = useState('');
  const [trackingCode, setTrackingCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VerifyResult | null>(null);

  const handleVerify = async () => {
    if (!nationalId && !trackingCode) return;

    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nationalId: nationalId || undefined,
          trackingCode: trackingCode || undefined,
        }),
      });

      const data = await response.json();
      setResult(data);
    } catch {
      setResult({ found: false, error: 'خطا در اتصال به سرور. لطفاً دوباره تلاش کنید.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* JSON-LD Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            name: 'استعلام مدرک — آموزشگاه بهان رایانه',
            description: 'استعلام و اعتبارسنجی مدارک فنی و حرفه‌ای و بین‌المللی صادر شده توسط آموزشگاه بهان رایانه محمودآباد',
            url: `${siteConfig.url?.base || 'https://bahanrayaneh.ir'}/verify`,
            mainEntity: {
              '@type': 'Organization',
              name: siteConfig.name.fullName,
            },
          }),
        }}
      />

      <div className="min-h-screen bg-gradient-to-b from-[#0f172a] via-[#0f172a] to-[#f0fdfa]">
        {/* Hero Section */}
        <section className="relative pt-16 pb-20 sm:pt-24 sm:pb-28 overflow-hidden">
          {/* Background decorative elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-20 right-10 w-72 h-72 bg-[#0d9488]/10 rounded-full blur-3xl" />
            <div className="absolute bottom-10 left-10 w-96 h-96 bg-[#0d9488]/5 rounded-full blur-3xl" />
          </div>

          <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
            <div className="text-center mb-10">
              {/* Trust badge */}
              <div className="inline-flex items-center gap-2 bg-[#0d9488]/20 border border-[#0d9488]/30 rounded-full px-5 py-2 mb-6">
                <Shield className="w-4 h-4 text-[#5eead4]" />
                <span className="text-sm text-[#5eead4] font-medium">سیستم اعتبارسنجی مدارک</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-4 leading-tight">
                استعلام مدرک
              </h1>
              <p className="text-base sm:text-lg text-gray-300 max-w-2xl mx-auto leading-relaxed">
                {`مدارک صادر شده توسط ${siteConfig.name.fullName} را از اینجا اعتبارسنجی کنید.`}
                <br />
                کافیست کد ملی یا کد رهگیری مدرک خود را وارد کنید.
              </p>
            </div>

            {/* Verification Form Card */}
            <Card className="bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl overflow-hidden">
              <CardContent className="p-6 sm:p-8">
                <div className="space-y-6">
                  {/* National ID Input */}
                  <div>
                    <label className="flex items-center gap-2 text-sm font-medium text-gray-200 mb-2">
                      <User className="w-4 h-4 text-[#5eead4]" />
                      کد ملی
                    </label>
                    <Input
                      type="text"
                      dir="ltr"
                      placeholder="مثال: 0012345678"
                      value={nationalId}
                      onChange={(e) => setNationalId(e.target.value)}
                      className="h-12 bg-white/10 border-white/20 text-white placeholder:text-gray-400 text-base focus-visible:border-[#0d9488] focus-visible:ring-[#0d9488]/30"
                      maxLength={10}
                    />
                  </div>

                  {/* Divider */}
                  <div className="flex items-center gap-4">
                    <div className="flex-1 h-px bg-white/15" />
                    <span className="text-sm text-gray-400 font-medium">یا</span>
                    <div className="flex-1 h-px bg-white/15" />
                  </div>

                  {/* Tracking Code Input */}
                  <div>
                    <label className="flex items-center gap-2 text-sm font-medium text-gray-200 mb-2">
                      <Hash className="w-4 h-4 text-[#5eead4]" />
                      کد رهگیری
                    </label>
                    <Input
                      type="text"
                      dir="ltr"
                      placeholder="مثال: BHR-1403-001"
                      value={trackingCode}
                      onChange={(e) => setTrackingCode(e.target.value)}
                      className="h-12 bg-white/10 border-white/20 text-white placeholder:text-gray-400 text-base focus-visible:border-[#0d9488] focus-visible:ring-[#0d9488]/30"
                    />
                  </div>

                  {/* Submit Button */}
                  <Button
                    onClick={handleVerify}
                    disabled={loading || (!nationalId && !trackingCode)}
                    className="w-full h-12 bg-[#0d9488] hover:bg-[#0f766e] text-white font-bold text-base rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        در حال استعلام...
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Search className="w-4 h-4" />
                        استعلام مدرک
                      </div>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Results Section */}
        {result && (
          <section className="pb-8 -mt-8 relative z-20">
            <div className="max-w-4xl mx-auto px-4 sm:px-6">
              {result.found && result.data ? (
                <Card className="bg-white shadow-2xl rounded-2xl overflow-hidden border-0">
                  {/* Status Header */}
                  <div className={`p-4 sm:p-5 flex items-center gap-3 ${
                    result.data.status === 'valid'
                      ? 'bg-gradient-to-l from-emerald-50 to-[#ccfbf1]'
                      : 'bg-gradient-to-l from-red-50 to-orange-50'
                  }`}>
                    {result.data.status === 'valid' ? (
                      <>
                        <CheckCircle2 className="w-7 h-7 text-emerald-600 flex-shrink-0" />
                        <div>
                          <p className="font-bold text-emerald-800 text-base">مدرک معتبر است</p>
                          <p className="text-sm text-emerald-600">این مدرک توسط مرجع صالح صادر شده و اعتبار آن تأیید می‌شود</p>
                        </div>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-7 h-7 text-red-500 flex-shrink-0" />
                        <div>
                          <p className="font-bold text-red-700 text-base">مدرک منقضی شده</p>
                          <p className="text-sm text-red-500">اعتبار این مدرک به پایان رسیده است</p>
                        </div>
                      </>
                    )}
                  </div>

                  <CardContent className="p-6 sm:p-8">
                    {/* Certificate Details Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-6">
                      <DetailItem
                        icon={User}
                        label="نام کارآموز"
                        value={result.data.studentName}
                      />
                      <DetailItem
                        icon={BookOpen}
                        label="نام دوره"
                        value={result.data.courseName}
                      />
                      <DetailItem
                        icon={Hash}
                        label="شماره مدرک"
                        value={result.data.certificateNumber}
                        dir="ltr"
                      />
                      <DetailItem
                        icon={CalendarDays}
                        label="تاریخ صدور"
                        value={result.data.issueDate}
                      />
                      <DetailItem
                        icon={FileCheck2}
                        label="نوع مدرک"
                        value={result.data.certType}
                      />
                      <DetailItem
                        icon={Building2}
                        label="صادرکننده"
                        value={result.data.issuer}
                      />
                    </div>

                    {/* Trust Badges */}
                    <div className="flex flex-wrap items-center gap-3 pt-5 border-t border-gray-100">
                      <div className="flex items-center gap-2 bg-[#ccfbf1]/60 rounded-lg px-4 py-2.5">
                        <BadgeCheck className="w-5 h-5 text-[#0d9488]" />
                        <span className="text-sm font-medium text-[#0f766e]">فنی و حرفه‌ای</span>
                      </div>
                      {result.data.certType.includes('ICDL') && (
                        <div className="flex items-center gap-2 bg-blue-50 rounded-lg px-4 py-2.5">
                          <GraduationCap className="w-5 h-5 text-blue-600" />
                          <span className="text-sm font-medium text-blue-700">ICDL بین‌المللی</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2 bg-amber-50 rounded-lg px-4 py-2.5">
                        <Shield className="w-5 h-5 text-amber-600" />
                        <span className="text-sm font-medium text-amber-700">قابل استعلام</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="bg-white shadow-2xl rounded-2xl overflow-hidden border-0">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <XCircle className="w-8 h-8 text-red-400" />
                    </div>
                    <h3 className="text-lg font-bold text-[#0f172a] mb-2">مدرکی یافت نشد</h3>
                    <p className="text-[#64748b] max-w-md mx-auto leading-relaxed">
                      {result.error || 'اطلاعات وارد شده با هیچ مدرکی در سیستم مطابقت ندارد. لطفاً اطلاعات را بررسی کرده و دوباره تلاش کنید.'}
                    </p>
                    <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
                      <Button
                        variant="outline"
                        onClick={() => { setResult(null); setNationalId(''); setTrackingCode(''); }}
                        className="border-[#0d9488] text-[#0d9488] hover:bg-[#0d9488] hover:text-white"
                      >
                        تلاش مجدد
                      </Button>
                      <a
                        href={siteConfig.contact.phoneHref}
                        className="inline-flex items-center justify-center gap-2 bg-[#0d9488] hover:bg-[#0f766e] text-white font-medium px-6 py-2.5 rounded-lg transition-colors text-sm"
                      >
                        <Phone className="w-4 h-4" />
                        تماس با آموزشگاه
                      </a>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </section>
        )}

        {/* Help Section */}
        <section className="py-16 sm:py-20 bg-white mt-8">
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-full px-5 py-2 mb-4">
                <HelpCircle className="w-4 h-4 text-amber-600" />
                <span className="text-sm text-amber-700 font-medium">راهنمای استعلام</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-3">
                چه مدارکی قابل استعلام است؟
              </h2>
              <p className="text-[#64748b] max-w-2xl mx-auto">
                تمامی مدارک صادر شده توسط آموزشگاه بهان رایانه دارای کد رهگیری بوده و قابل استعلام هستند
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              <HelpCard
                icon={BadgeCheck}
                title="گواهینامه بین‌المللی ICDL"
                description="مدرک سواد دیجیتال بین‌المللی معتبر در ۱۴۰+ کشور"
                color="#0d9488"
              />
              <HelpCard
                icon={FileCheck2}
                title="گواهی فنی و حرفه‌ای"
                description="مدرک صادر شده توسط سازمان آموزش فنی و حرفه‌ای ایران"
                color="#d97706"
              />
              <HelpCard
                icon={GraduationCap}
                title="گواهی پایان دوره"
                description="گواهی تکمیل دوره‌های تخصصی آموزشگاه بهان رایانه"
                color="#7c3aed"
              />
            </div>

            {/* Additional Info */}
            <div className="mt-10 bg-[#f0fdfa] rounded-2xl p-6 sm:p-8 border border-[#ccfbf1]">
              <h3 className="font-bold text-[#0f172a] mb-4 text-base">سؤالات متداول استعلام مدرک</h3>
              <div className="space-y-4">
                <FaqItem
                  question="کد رهگیری مدرک کجاست؟"
                  answer="کد رهگیری روی مدرک فیزیکی شما درج شده است. این کد با فرمت BHR-XXXX-XXX قابل شناسایی است."
                />
                <FaqItem
                  question="اگر مدرکم یافت نشد چه کنم؟"
                  answer={`لطفاً ابتدا اطلاعات وارد شده را بررسی کنید. اگر مشکل ادامه داشت، با شماره ${siteConfig.contact.phone} تماس بگیرید.`}
                />
                <FaqItem
                  question="آیا مدارک قدیمی هم قابل استعلام است؟"
                  answer="بله، تمامی مدارک صادر شده از سال ۱۳۹۸ به بعد در سیستم ثبت شده و قابل استعلام هستند."
                />
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

function DetailItem({
  icon: Icon,
  label,
  value,
  dir,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  dir?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-9 h-9 rounded-lg bg-[#f0fdfa] flex items-center justify-center flex-shrink-0 mt-0.5">
        <Icon className="w-4 h-4 text-[#0d9488]" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-[#64748b] mb-0.5">{label}</p>
        <p className="text-sm font-medium text-[#0f172a] leading-relaxed" dir={dir}>{value}</p>
      </div>
    </div>
  );
}

function HelpCard({
  icon: Icon,
  title,
  description,
  color,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  color: string;
}) {
  return (
    <div className="bg-gray-50 rounded-xl p-5 border border-gray-100 hover:shadow-md transition-shadow">
      <div
        className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
        style={{ backgroundColor: color + '15' }}
      >
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <h3 className="font-bold text-sm text-[#0f172a] mb-1">{title}</h3>
      <p className="text-xs text-[#64748b] leading-relaxed">{description}</p>
    </div>
  );
}

function FaqItem({ question, answer }: { question: string; answer: string }) {
  return (
    <div className="bg-white rounded-lg p-4 border border-gray-100">
      <p className="font-medium text-sm text-[#0f172a] mb-1">{question}</p>
      <p className="text-xs text-[#64748b] leading-relaxed">{answer}</p>
    </div>
  );
}
