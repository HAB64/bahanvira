import Link from 'next/link';

export default function NotFound() {
  return (
    <div style={{
      minHeight: '70vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem',
      direction: 'rtl',
    }}>
      <div style={{
        maxWidth: '460px',
        width: '100%',
        textAlign: 'center',
      }}>
        <div style={{
          fontSize: '6rem',
          fontWeight: 800,
          color: '#0d9488',
          lineHeight: 1,
          marginBottom: '1rem',
        }}>
          ۴۰۴
        </div>

        <h1 style={{
          fontSize: '1.5rem',
          fontWeight: 700,
          marginBottom: '0.75rem',
          color: '#0f172a',
        }}>
          صفحه مورد نظر یافت نشد
        </h1>

        <p style={{
          fontSize: '0.875rem',
          color: '#64748b',
          marginBottom: '2rem',
          lineHeight: 1.7,
        }}>
          ممکن است این صفحه حذف شده باشد یا آدرس آن تغییر کرده باشد.
          لطفاً از طریق لینک زیر به صفحه اصلی بازگردید.
        </p>

        <Link
          href="/"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            backgroundColor: '#0d9488',
            color: 'white',
            borderRadius: '12px',
            padding: '0.75rem 1.5rem',
            fontSize: '0.875rem',
            fontWeight: 600,
            textDecoration: 'none',
            transition: 'background-color 0.2s',
          }}
        >
          بازگشت به خانه
        </Link>
      </div>
    </div>
  );
}
