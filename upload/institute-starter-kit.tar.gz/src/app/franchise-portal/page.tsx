'use client';

import { useState } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DollarSign,
  Users,
  Percent,
  TrendingUp,
  FileText,
  Phone,
  UserCog,
  BarChart3,
  ArrowUpLeft,
  ArrowDownLeft,
  Wallet,
  CalendarDays,
  CheckCircle2,
  XCircle,
  Clock,
  Receipt,
  Building2,
  ChevronLeft,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface StatCard {
  id: string;
  title: string;
  value: string;
  trend: 'up' | 'down';
  trendValue: string;
  icon: React.ReactNode;
  gradient: string;
  iconBg: string;
}

interface Contract {
  id: string;
  contractNumber: string;
  status: 'فعال' | 'منقضی' | 'در انتظار';
  royaltyPercent: number;
  startDate: string;
  revenue: number;
}

interface Payment {
  id: string;
  date: string;
  amount: number;
  status: 'پرداخت شده' | 'در انتظار' | 'لغو شده';
  description: string;
}

/* ─────────── Mock Data ─────────── */

const mockStats: StatCard[] = [
  {
    id: 'revenue',
    title: 'درآمد ماهانه',
    value: toPersianNumber('245,000,000') + ' تومان',
    trend: 'up',
    trendValue: '۱۲.۵٪',
    icon: <DollarSign className="size-5" />,
    gradient: 'from-emerald-500/10 via-emerald-500/5 to-transparent',
    iconBg: 'bg-emerald-500/15 text-emerald-600',
  },
  {
    id: 'students',
    title: 'تعداد دانشجویان فعال',
    value: toPersianNumber('387'),
    trend: 'up',
    trendValue: '۸.۲٪',
    icon: <Users className="size-5" />,
    gradient: 'from-violet-500/10 via-violet-500/5 to-transparent',
    iconBg: 'bg-violet-500/15 text-violet-600',
  },
  {
    id: 'royalty',
    title: 'رویالتی ماه جاری',
    value: toPersianNumber('36,750,000') + ' تومان',
    trend: 'down',
    trendValue: '۲.۱٪',
    icon: <Percent className="size-5" />,
    gradient: 'from-amber-500/10 via-amber-500/5 to-transparent',
    iconBg: 'bg-amber-500/15 text-amber-600',
  },
  {
    id: 'growth',
    title: 'نرخ رشد',
    value: toPersianNumber('18.7') + '٪',
    trend: 'up',
    trendValue: '۳.۴٪',
    icon: <TrendingUp className="size-5" />,
    gradient: 'from-rose-500/10 via-rose-500/5 to-transparent',
    iconBg: 'bg-rose-500/15 text-rose-600',
  },
];

const mockContracts: Contract[] = [
  {
    id: '1',
    contractNumber: 'FR-۱۴۰۳-۰۰۴۲',
    status: 'فعال',
    royaltyPercent: 15,
    startDate: '۱۴۰۳/۰۱/۱۵',
    revenue: 245000000,
  },
  {
    id: '2',
    contractNumber: 'FR-۱۴۰۲-۰۰۳۸',
    status: 'فعال',
    royaltyPercent: 12,
    startDate: '۱۴۰۲/۰۶/۰۱',
    revenue: 198000000,
  },
  {
    id: '3',
    contractNumber: 'FR-۱۴۰۲-۰۰۳۱',
    status: 'منقضی',
    royaltyPercent: 10,
    startDate: '۱۴۰۲/۰۱/۲۰',
    revenue: 156000000,
  },
  {
    id: '4',
    contractNumber: 'FR-۱۴۰۳-۰۰۴۵',
    status: 'در انتظار',
    royaltyPercent: 18,
    startDate: '۱۴۰۳/۰۴/۰۱',
    revenue: 0,
  },
  {
    id: '5',
    contractNumber: 'FR-۱۴۰۱-۰۰۲۵',
    status: 'منقضی',
    royaltyPercent: 10,
    startDate: '۱۴۰۱/۰۷/۱۰',
    revenue: 134000000,
  },
];

const mockPayments: Payment[] = [
  {
    id: '1',
    date: '۱۴۰۳/۰۳/۱۵',
    amount: 36750000,
    status: 'پرداخت شده',
    description: 'رویالتی فروردین ۱۴۰۳',
  },
  {
    id: '2',
    date: '۱۴۰۳/۰۲/۱۵',
    amount: 34200000,
    status: 'پرداخت شده',
    description: 'رویالتی اسفند ۱۴۰۲',
  },
  {
    id: '3',
    date: '۱۴۰۳/۰۱/۱۵',
    amount: 31500000,
    status: 'پرداخت شده',
    description: 'رویالتی بهمن ۱۴۰۲',
  },
  {
    id: '4',
    date: '۱۴۰۲/۱۲/۱۵',
    amount: 29800000,
    status: 'در انتظار',
    description: 'رویالتی دی ۱۴۰۲',
  },
  {
    id: '5',
    date: '۱۴۰۲/۱۱/۱۵',
    amount: 28100000,
    status: 'لغو شده',
    description: 'رویالتی آذر ۱۴۰۲',
  },
];

/* ─────────── Helper Components ─────────── */

function StatusBadge({ status }: { status: Contract['status'] }) {
  const config: Record<Contract['status'], string> = {
    'فعال': 'bg-emerald-500/15 text-emerald-700 border-emerald-500/25',
    'منقضی': 'bg-red-500/15 text-red-700 border-red-500/25',
    'در انتظار': 'bg-amber-500/15 text-amber-700 border-amber-500/25',
  };
  const icons: Record<Contract['status'], React.ReactNode> = {
    'فعال': <CheckCircle2 className="size-3" />,
    'منقضی': <XCircle className="size-3" />,
    'در انتظار': <Clock className="size-3" />,
  };
  return (
    <Badge variant="outline" className={`gap-1 font-medium ${config[status]}`}>
      {icons[status]}
      {status}
    </Badge>
  );
}

function PaymentStatusBadge({ status }: { status: Payment['status'] }) {
  const config: Record<Payment['status'], string> = {
    'پرداخت شده': 'bg-emerald-500/15 text-emerald-700 border-emerald-500/25',
    'در انتظار': 'bg-amber-500/15 text-amber-700 border-amber-500/25',
    'لغو شده': 'bg-red-500/15 text-red-700 border-red-500/25',
  };
  return (
    <Badge variant="outline" className={`font-medium ${config[status]}`}>
      {status}
    </Badge>
  );
}

function formatCurrency(amount: number): string {
  if (amount === 0) return '—';
  return toPersianNumber(amount.toLocaleString('fa-IR')) + ' تومان';
}

/* ─────────── SVG Revenue Chart ─────────── */

function RevenueChart() {
  const months = ['مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  const values = [160, 185, 172, 210, 225, 245];
  const maxVal = 280;
  const chartW = 700;
  const chartH = 220;
  const padX = 55;
  const padY = 25;
  const plotW = chartW - padX * 2;
  const plotH = chartH - padY * 2;

  const points = values.map((v, i) => ({
    x: padX + (i / (values.length - 1)) * plotW,
    y: padY + plotH - (v / maxVal) * plotH,
  }));

  const areaPath = `M ${points[0].x} ${chartH - 16}
    ${points.map((p) => `L ${p.x} ${p.y}`).join(' ')}
    L ${points[points.length - 1].x} ${chartH - 16} Z`;

  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

  const gridLines = [0, 70, 140, 210, 280];

  return (
    <svg
      viewBox={`0 0 ${chartW} ${chartH}`}
      className="w-full h-auto"
      dir="rtl"
    >
      <defs>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0d9488" stopOpacity="0.28" />
          <stop offset="100%" stopColor="#0d9488" stopOpacity="0.02" />
        </linearGradient>
        <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#14b8a6" />
          <stop offset="100%" stopColor="#0d9488" />
        </linearGradient>
        <filter id="dotShadow" x="-50%" y="-50%" width="200%" height="200%">
          <feDropShadow dx="0" dy="1" stdDeviation="2" floodColor="#0d9488" floodOpacity="0.25" />
        </filter>
      </defs>

      {/* Grid lines */}
      {gridLines.map((v) => {
        const y = padY + plotH - (v / maxVal) * plotH;
        return (
          <g key={v}>
            <line
              x1={padX}
              y1={y}
              x2={chartW - padX}
              y2={y}
              stroke="#e2e8f0"
              strokeWidth="1"
              strokeDasharray="5 4"
            />
            <text
              x={padX - 10}
              y={y + 4}
              textAnchor="end"
              className="fill-slate-400"
              style={{ fontSize: '10px' }}
            >
              {toPersianNumber(v)}
            </text>
          </g>
        );
      })}

      {/* Area fill */}
      <path d={areaPath} fill="url(#areaGrad)" />

      {/* Line */}
      <path
        d={linePath}
        fill="none"
        stroke="url(#lineGrad)"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Data points + labels */}
      {points.map((p, i) => (
        <g key={i}>
          <circle cx={p.x} cy={p.y} r="8" fill="#0d9488" opacity="0.1" />
          <circle cx={p.x} cy={p.y} r="5" fill="white" stroke="#0d9488" strokeWidth="2.5" filter="url(#dotShadow)" />
          <text
            x={p.x}
            y={p.y - 16}
            textAnchor="middle"
            className="fill-slate-700"
            style={{ fontSize: '11px', fontWeight: 600 }}
          >
            {toPersianNumber(values[i])}
          </text>
          <text
            x={p.x}
            y={chartH - 2}
            textAnchor="middle"
            className="fill-slate-400"
            style={{ fontSize: '12px' }}
          >
            {months[i]}
          </text>
        </g>
      ))}
    </svg>
  );
}

/* ─────────── Main Page ─────────── */

export default function FranchisePortalPage() {
  const [stats] = useState<StatCard[]>(mockStats);
  const [contracts] = useState<Contract[]>(mockContracts);
  const [payments] = useState<Payment[]>(mockPayments);

  return (
    <div dir="rtl" className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-white to-teal-50/30">
      {/* ───── Header ───── */}
      <header className="relative overflow-hidden border-b bg-gradient-to-l from-teal-600 via-teal-700 to-emerald-800">
        <div className="absolute top-0 left-0 w-72 h-72 bg-white/5 rounded-full -translate-x-1/3 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/5 rounded-full translate-x-1/3 translate-y-1/2" />
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-white/5 rounded-full" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center size-12 sm:size-14 rounded-2xl bg-white/15 backdrop-blur-sm border border-white/20 shadow-lg">
                <Building2 className="size-6 sm:size-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight">
                  پورتال فرانشیزگیرنده
                </h1>
                <p className="mt-1 text-teal-100/80 text-sm sm:text-base">
                  مدیریت فرانشیز و گزارش‌ها
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-teal-100/70 bg-white/10 backdrop-blur-sm rounded-xl px-4 py-2.5 border border-white/10">
              <CalendarDays className="size-4" />
              <span>خرداد ۱۴۰۳</span>
            </div>
          </div>
        </div>
      </header>

      {/* ───── Main Content ───── */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* Stats Cards */}
        <section aria-label="آمار کلی">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
            {stats.map((stat) => (
              <Card
                key={stat.id}
                className={`relative overflow-hidden border-0 shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5 bg-gradient-to-br ${stat.gradient}`}
              >
                <CardContent className="p-5 sm:p-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-3 min-w-0">
                      <p className="text-sm font-medium text-muted-foreground">
                        {stat.title}
                      </p>
                      <p className="text-xl sm:text-2xl font-bold tracking-tight text-foreground truncate">
                        {stat.value}
                      </p>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {stat.trend === 'up' ? (
                          <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-emerald-600 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                            <ArrowUpLeft className="size-3" />
                            {stat.trendValue}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-red-600 bg-red-500/10 px-2 py-0.5 rounded-full">
                            <ArrowDownLeft className="size-3" />
                            {stat.trendValue}
                          </span>
                        )}
                        <span className="text-xs text-muted-foreground">نسبت به ماه قبل</span>
                      </div>
                    </div>
                    <div className={`flex items-center justify-center size-11 rounded-xl ${stat.iconBg} shrink-0`}>
                      {stat.icon}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Revenue Chart */}
        <section aria-label="نمودار درآمد">
          <Card className="border-0 shadow-md overflow-hidden">
            <CardHeader className="pb-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center size-10 rounded-xl bg-teal-500/15 text-teal-600">
                    <BarChart3 className="size-5" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-bold">
                      نمودار درآمد ۶ ماه اخیر
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      میزان درآمد ماهانه (میلیون تومان)
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <span className="size-2.5 rounded-full bg-teal-500" />
                    درآمد
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="px-4 sm:px-6 pb-6">
              <div className="rounded-xl bg-gradient-to-b from-slate-50/80 to-white p-4 sm:p-6 border border-slate-100">
                <RevenueChart />
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Contracts Table */}
        <section aria-label="قراردادهای اخیر">
          <Card className="border-0 shadow-md overflow-hidden">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center size-10 rounded-xl bg-violet-500/15 text-violet-600">
                  <FileText className="size-5" />
                </div>
                <div>
                  <CardTitle className="text-lg font-bold">
                    قراردادهای اخیر
                  </CardTitle>
                  <CardDescription className="text-xs mt-0.5">
                    لیست قراردادهای فرانشیز
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="px-2 sm:px-6 pb-6">
              <div className="rounded-xl border border-slate-200/80 overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50/80 hover:bg-slate-50/80">
                      <TableHead className="text-right text-xs font-semibold text-muted-foreground py-3 px-4">
                        شماره قرارداد
                      </TableHead>
                      <TableHead className="text-right text-xs font-semibold text-muted-foreground py-3 px-4">
                        وضعیت
                      </TableHead>
                      <TableHead className="text-right text-xs font-semibold text-muted-foreground py-3 px-4">
                        درصد رویالتی
                      </TableHead>
                      <TableHead className="text-right text-xs font-semibold text-muted-foreground py-3 px-4 hidden sm:table-cell">
                        تاریخ شروع
                      </TableHead>
                      <TableHead className="text-right text-xs font-semibold text-muted-foreground py-3 px-4">
                        درآمد
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contracts.map((contract) => (
                      <TableRow key={contract.id} className="group">
                        <TableCell className="py-3.5 px-4">
                          <span className="font-mono text-sm font-medium text-foreground">
                            {contract.contractNumber}
                          </span>
                        </TableCell>
                        <TableCell className="py-3.5 px-4">
                          <StatusBadge status={contract.status} />
                        </TableCell>
                        <TableCell className="py-3.5 px-4">
                          <span className="text-sm font-semibold text-foreground">
                            {toPersianNumber(contract.royaltyPercent)}٪
                          </span>
                        </TableCell>
                        <TableCell className="py-3.5 px-4 hidden sm:table-cell">
                          <span className="text-sm text-muted-foreground">
                            {contract.startDate}
                          </span>
                        </TableCell>
                        <TableCell className="py-3.5 px-4">
                          <span className="text-sm font-medium text-foreground">
                            {formatCurrency(contract.revenue)}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Quick Actions + Payment History */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Quick Actions */}
          <section aria-label="دسترسی سریع" className="lg:col-span-2">
            <Card className="border-0 shadow-md h-full">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center size-10 rounded-xl bg-amber-500/15 text-amber-600">
                    <ChevronLeft className="size-5" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-bold">
                      دسترسی سریع
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      عملیات متداول
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="px-5 sm:px-6 pb-6">
                <div className="grid grid-cols-2 gap-3">
                  <button className="group flex flex-col items-center gap-3 rounded-xl border border-slate-200/80 bg-gradient-to-b from-white to-slate-50/50 p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer">
                    <div className="flex items-center justify-center size-12 rounded-2xl bg-emerald-500/10 text-emerald-600 group-hover:bg-emerald-500 group-hover:text-white transition-colors duration-200">
                      <Wallet className="size-5" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium text-foreground text-center leading-5">
                      ثبت درآمد ماهانه
                    </span>
                  </button>

                  <button className="group flex flex-col items-center gap-3 rounded-xl border border-slate-200/80 bg-gradient-to-b from-white to-slate-50/50 p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer">
                    <div className="flex items-center justify-center size-12 rounded-2xl bg-violet-500/10 text-violet-600 group-hover:bg-violet-500 group-hover:text-white transition-colors duration-200">
                      <BarChart3 className="size-5" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium text-foreground text-center leading-5">
                      مشاهده گزارش‌ها
                    </span>
                  </button>

                  <button className="group flex flex-col items-center gap-3 rounded-xl border border-slate-200/80 bg-gradient-to-b from-white to-slate-50/50 p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer">
                    <div className="flex items-center justify-center size-12 rounded-2xl bg-teal-500/10 text-teal-600 group-hover:bg-teal-500 group-hover:text-white transition-colors duration-200">
                      <Phone className="size-5" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium text-foreground text-center leading-5">
                      تماس با پشتیبانی
                    </span>
                  </button>

                  <button className="group flex flex-col items-center gap-3 rounded-xl border border-slate-200/80 bg-gradient-to-b from-white to-slate-50/50 p-5 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200 cursor-pointer">
                    <div className="flex items-center justify-center size-12 rounded-2xl bg-rose-500/10 text-rose-600 group-hover:bg-rose-500 group-hover:text-white transition-colors duration-200">
                      <UserCog className="size-5" />
                    </div>
                    <span className="text-xs sm:text-sm font-medium text-foreground text-center leading-5">
                      بروزرسانی پروفایل
                    </span>
                  </button>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Payment History */}
          <section aria-label="سوابق پرداخت" className="lg:col-span-3">
            <Card className="border-0 shadow-md h-full">
              <CardHeader className="pb-2">
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center size-10 rounded-xl bg-emerald-500/15 text-emerald-600">
                    <Receipt className="size-5" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-bold">
                      سوابق پرداخت رویالتی
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      آخرین پرداخت‌های انجام شده
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="px-5 sm:px-6 pb-6">
                <div className="space-y-3">
                  {payments.map((payment) => (
                    <div
                      key={payment.id}
                      className="flex items-center justify-between gap-4 rounded-xl border border-slate-200/80 bg-gradient-to-l from-white to-slate-50/50 px-4 py-3.5 hover:shadow-sm transition-shadow"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="flex items-center justify-center size-9 rounded-lg bg-slate-100 text-slate-500 shrink-0">
                          <Wallet className="size-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">
                            {payment.description}
                          </p>
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {payment.date}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-sm font-bold text-foreground hidden sm:block">
                          {formatCurrency(payment.amount)}
                        </span>
                        <PaymentStatusBadge status={payment.status} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t bg-white/60 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Building2 className="size-4 text-teal-600" />
              <span>سیستم مدیریت فرانشیز نامی</span>
            </div>
            <p>تمامی حقوق محفوظ است © {toPersianNumber(new Date().getFullYear().toString())}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}