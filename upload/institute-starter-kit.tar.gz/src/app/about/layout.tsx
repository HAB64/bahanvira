import { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: `درباره آموزشگاه فنی و حرفه‌ای ${siteConfig.name.fa} — ${siteConfig.experience.yearsFa} سال تجربه`,
  description: `${siteConfig.name.fullName} با ${siteConfig.experience.yearsFa} سال تجربه در ${siteConfig.location.city} ${siteConfig.location.province}. مجوز رسمی ${siteConfig.institute.typeFa}، مرکز آزمون ICDL، آموزش مبتنی بر شایستگی CBT.`,
  keywords: [`درباره ${siteConfig.name.fa}`, 'تاریخچه آموزشگاه', siteConfig.founder.name, `${siteConfig.institute.typeFa} ${siteConfig.location.city}`, `آموزشگاه فنی و حرفه‌ای ${siteConfig.location.city}`],
  alternates: {
    canonical: `${siteConfig.url.base}/about`,
  },
  openGraph: {
    title: `درباره آموزشگاه فنی و حرفه‌ای ${siteConfig.name.fa}`,
    description: `${siteConfig.experience.yearsFa} سال تجربه در آموزش مهارت‌های ${siteConfig.institute.typeFa}`,
    locale: 'fa_IR',
    url: `${siteConfig.url.base}/about`,
  },
};

export default function AboutLayout({ children }: { children: React.ReactNode }) {
  return children;
}
