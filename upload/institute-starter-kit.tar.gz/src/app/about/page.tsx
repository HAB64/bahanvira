import Link from 'next/link';
import { Award, Users, BookOpen, Target, Shield, Clock, CheckCircle2, GraduationCap, Star } from 'lucide-react';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { siteConfig } from '@/config/site';

const licenses = [
  `مجوز رسمی سازمان آموزش ${siteConfig.institute.typeFa} ایران`,
];

const timeline = [
  { year: '۱۳۷۸', title: `تأسیس آموزشگاه و اخذ مجوز ${siteConfig.institute.typeFa}`, desc: `${siteConfig.name.fullName} توسط ${siteConfig.founder.name} در ${siteConfig.location.city} تأسیس و مجوز رسمی سازمان آموزش ${siteConfig.institute.typeFa} دریافت شد.` },
  { year: '۱۴۰۰', title: 'توسعه دپارتمان مالی', desc: 'راه‌اندازی دپارتمان بازارهای مالی و دوره‌های فارکس و MQL5.' },
  { year: '۱۴۰۳', title: 'تحول دیجیتال و LXP', desc: 'شروع تحول دیجیتال و طراحی پلتفرم آموزش مبتنی بر شایستگی (CBT).' },
  { year: '۱۴۰۵', title: 'لانچ پلتفرم جدید', desc: 'راه‌اندازی پلتفرم LXP با ۳ خوشه، ۸ گروه آموزشی و ۷۷+ دوره تخصصی.' },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <main className="flex-1">
        {/* Hero */}
        <div className="bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#0f766e] py-12 sm:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">درباره {siteConfig.name.fa}</h1>
            <p className="text-white/80 max-w-2xl mx-auto leading-relaxed">
              {siteConfig.experience.yearsFa} سال تجربه در آموزش مهارت‌های {siteConfig.institute.typeFa}. از یک کلاس کامپیوتر کوچک تا پلتفرم
              مهارت‌آموزی با ۳ خوشه و ۸ گروه آموزشی.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Clock, label: 'سال تجربه', value: `${siteConfig.experience.yearsFa}+` },
              { icon: Users, label: 'فارغ‌التحصیل', value: '۵,۰۰۰+' },
              { icon: BookOpen, label: 'دوره تخصصی', value: '۱۳+' },
              { icon: Award, label: 'مجوز و گواهینامه', value: '۴+' },
            ].map((stat) => (
              <div key={stat.label} className="bg-white rounded-2xl shadow-lg p-5 text-center border border-gray-50">
                <stat.icon className="w-8 h-8 text-[#0d9488] mx-auto mb-2" />
                <div className="text-2xl font-bold text-[#0f172a]">{stat.value}</div>
                <div className="text-xs text-[#64748b]">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Story */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="inline-block text-sm font-medium text-[#0d9488] bg-[#ccfbf1] rounded-full px-4 py-1.5 mb-4">
                داستان ما
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-6">
                از کلاس کامپیوتر تا پلتفرم مهارت‌آموزی
              </h2>
              <p className="text-[#475569] leading-relaxed mb-4">
                {siteConfig.name.fullName} در سال ۱۳۷۸ (۱۹۹۹ میلادی) توسط {siteConfig.founder.name} در شهر {siteConfig.location.city}
                {siteConfig.location.province} تأسیس شد. آنچه در ابتدا تنها یک کلاس کوچک کامپیوتر بود، طی {siteConfig.experience.yearsFa} سال تلاش مستمر به یکی
                از معتبرترین مراکز آموزش {siteConfig.institute.typeFa} استان تبدیل شده است.
              </p>
              <p className="text-[#475569] leading-relaxed mb-4">
                مدیریت آموزشگاه بر عهده {siteConfig.founder.name}، دارای دکتری کارآفرینی و بیش از دو دهه تجربه مدیریتی
                و آموزشی است. رویکرد ایشان همواره بر آموزش پروژه‌محور، کاربردی و مبتنی بر نیاز واقعی
                بازار کار بوده است. فارغ‌التحصیلان {siteConfig.name.fa} امروز در سازمان‌های دولتی، شرکت‌های
                خصوصی و کسب‌وکارهای مستقل مشغول به کار هستند.
              </p>
              <p className="text-[#475569] leading-relaxed">
                در سال ۱۴۰۵، آموزشگاه با تحول دیجیتال خود، از مدل سنتی آموزش به یک پلتفرم تجربه یادگیری
                (LXP) ارتقا یافت. این پلتفرم بر پایه آموزش مبتنی بر شایستگی (CBT) طراحی شده و با ۳ خوشه و ۸ گروه
                آموزشی، مسیر یادگیری شخصی‌سازی‌شده‌ای برای هر کارآموز فراهم می‌کند.
              </p>
            </div>
            <div className="bg-gray-50 rounded-2xl p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl bg-[#0d9488] flex items-center justify-center">
                  <GraduationCap className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-[#0f172a] text-lg">{siteConfig.founder.name}</h3>
                  <p className="text-sm text-[#64748b]">مدیر و بنیان‌گذار آموزشگاه</p>
                </div>
              </div>
              <div className="space-y-3 text-sm text-[#475569]">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0d9488] mt-0.5 flex-shrink-0" />
                  <span>دکتری کارآفرینی</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0d9488] mt-0.5 flex-shrink-0" />
                  <span>{siteConfig.experience.yearsFa}+ سال تجربه آموزشی و مدیریتی</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#0d9488] mt-0.5 flex-shrink-0" />
                  <span>مشاور کسب‌وکار و عارضه‌یابی سازمانی</span>
                </div>

              </div>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <div className="bg-gray-50 py-16 sm:py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">مسیر پیشرفت</h2>
              <p className="text-[#64748b]">از تأسیس تا تحول دیجیتال</p>
            </div>
            <div className="space-y-6">
              {timeline.map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 rounded-full bg-[#0d9488] text-white text-xs font-bold flex items-center justify-center flex-shrink-0">
                      {item.year.slice(-2)}
                    </div>
                    {i < timeline.length - 1 && <div className="w-0.5 h-full bg-[#ccfbf1] mt-2" />}
                  </div>
                  <div className="bg-white rounded-xl p-5 flex-1 border border-gray-100">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-bold text-[#0d9488]">{item.year}</span>
                      <span className="font-bold text-[#0f172a]">{item.title}</span>
                    </div>
                    <p className="text-sm text-[#64748b]">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Licenses */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">مجوزها و گواهینامه‌ها</h2>
            <p className="text-[#64748b]">اعتبار رسمی و بین‌المللی</p>
          </div>
          <div className="grid sm:grid-cols-2 gap-4 max-w-3xl mx-auto">
            {licenses.map((license, i) => (
              <div key={i} className="flex items-start gap-3 bg-gray-50 rounded-xl p-5">
                <Shield className="w-5 h-5 text-[#0d9488] mt-0.5 flex-shrink-0" />
                <span className="text-sm text-[#334155]">{license}</span>
              </div>
            ))}
          </div>
        </div>

        {/* CBT Approach */}
        <div className="bg-[#0f172a] py-16 sm:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <span className="inline-block text-sm font-medium text-[#5eead4] bg-white/10 rounded-full px-4 py-1.5 mb-4">
              رویکرد آموزشی
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-6">
              آموزش مبتنی بر شایستگی (CBT)
            </h2>
            <p className="text-white/70 max-w-3xl mx-auto leading-relaxed mb-10">
              در پلتفرم {siteConfig.name.fa}، ما به جای تماشای غیرفعال ویدیو، بر تأیید شایستگی عملی تأکید داریم.
              هر کارآموز باید خروجی‌های ملموس و عملی هر مرحله را ارائه دهد تا به مرحله بعدی دسترسی پیدا کند.
              این رویکرد تضمین می‌کند که فارغ‌التحصیلان ما واقعاً توانایی انجام کار را داشته باشند.
            </p>
            <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {[
                { icon: Target, title: 'یادگیری فعال', desc: 'پروژه‌محور و تعاملی، نه تماشای منفعلانه' },
                { icon: Shield, title: 'تأیید شایستگی', desc: 'ارزیابی عملی خروجی‌ها قبل از ارتقا به سطح بعدی' },
                { icon: Award, title: 'مدرک معتبر', desc: 'گواهینامه‌های بین‌المللی با قابلیت استعلام دیجیتال' },
              ].map((item) => (
                <div key={item.title} className="bg-white/5 rounded-2xl p-6 border border-white/10">
                  <item.icon className="w-8 h-8 text-[#5eead4] mx-auto mb-4" />
                  <h3 className="font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-sm text-white/60">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
