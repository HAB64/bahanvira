'use client';

import { useState } from 'react';
import { Phone, MapPin, Clock, MessageCircle, Mail, Send, CheckCircle2, Instagram, Smartphone } from 'lucide-react';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { siteConfig } from '@/config/site';

const contactInfo = [
  {
    icon: Phone,
    label: 'تلفن ثابت',
    value: siteConfig.contact.phone,
    href: siteConfig.contact.phoneHref,
  },
  {
    icon: Mail,
    label: 'ایمیل',
    value: siteConfig.contact.email,
    href: `mailto:${siteConfig.contact.email}`,
  },
  {
    icon: Instagram,
    label: 'اینستاگرام',
    value: siteConfig.social.instagramHandle,
    href: siteConfig.social.instagram,
  },
  {
    icon: Clock,
    label: 'ساعات کاری',
    value: siteConfig.workHours,
    href: '',
  },
  {
    icon: MapPin,
    label: 'آدرس',
    value: siteConfig.location.fullAddress,
    href: '',
  },
];

/** SVG icons for Iranian messengers */
function MessengerIcon({ platform }: { platform: string }) {
  switch (platform) {
    case 'whatsapp':
      return (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      );
    case 'telegram':
      return (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
        </svg>
      );
    case 'bale':
      return (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
        </svg>
      );
    case 'eita':
      return (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
        </svg>
      );
    case 'rubika':
      return (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.12.02-1.98 1.26-5.58 3.72-.53.36-1 .53-1.43.52-.47-.01-1.37-.26-2.03-.48-.82-.27-1.47-.41-1.42-.86.03-.24.36-.48.99-.73 3.87-1.69 6.45-2.8 7.74-3.34 3.69-1.54 4.46-1.81 4.96-1.82.11 0 .36.03.52.17.13.12.17.28.18.44-.01.06.01.24 0 .38z"/>
        </svg>
      );
    default:
      return <MessageCircle className="w-4 h-4" />;
  }
}

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', phone: '', email: '', subject: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <main className="flex-1">
        {/* Hero */}
        <div className="bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#0f766e] py-12 sm:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">تماس با ما</h1>
            <p className="text-white/80 max-w-2xl mx-auto leading-relaxed">
              سوالی دارید؟ نیاز به مشاوره دارید؟ کارشناسان {siteConfig.name.fullName} آماده پاسخگویی هستند.
            </p>
          </div>
        </div>

        {/* Mobile Numbers Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
          <div className="bg-white rounded-2xl shadow-xl border border-gray-50 p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-[#0d9488]/10 flex items-center justify-center">
                <Smartphone className="w-5 h-5 text-[#0d9488]" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-[#0f172a]">شماره‌های تماس</h2>
                <p className="text-sm text-[#64748b]">از طریق تماس یا پیام‌رسان‌ها با ما در ارتباط باشید</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {siteConfig.contact.mobiles.map((mobile, idx) => (
                <div
                  key={mobile.dialable}
                  className={`rounded-xl border p-5 transition-all hover:shadow-lg ${
                    idx === 0
                      ? 'border-[#0d9488]/30 bg-gradient-to-br from-[#0d9488]/5 to-[#14b8a6]/5'
                      : 'border-gray-100 bg-gray-50/50'
                  }`}
                >
                  {/* Phone number */}
                  <a
                    href={mobile.href}
                    className="flex items-center gap-3 mb-3 group"
                  >
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                      idx === 0
                        ? 'bg-[#0d9488] text-white'
                        : 'bg-gray-200 text-[#64748b] group-hover:bg-[#0d9488] group-hover:text-white'
                    }`}>
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-base font-bold text-[#0f172a] dir-ltr" dir="ltr">
                        {mobile.display}
                      </p>
                      {idx === 0 && (
                        <p className="text-[10px] text-[#0d9488] font-medium mt-0.5">
                          شماره اصلی — پشتیبانی و ثبت‌نام
                        </p>
                      )}
                    </div>
                  </a>

                  {/* Messenger platforms for the first number */}
                  {mobile.platforms && mobile.platforms.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-gray-100">
                      {mobile.platforms.map((p) => (
                        <a
                          key={p.key}
                          href={p.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium text-white transition-all hover:scale-105 hover:shadow-md"
                          style={{ backgroundColor: p.color }}
                        >
                          <MessengerIcon platform={p.key} />
                          {p.labelFa}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Contact Info Cards */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
            {contactInfo.map((info) => (
              info.href ? (
                <a
                  key={info.label}
                  href={info.href}
                  target={info.href.startsWith('http') ? '_blank' : undefined}
                  rel={info.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className="bg-white rounded-xl p-4 shadow-lg border border-gray-50 hover:shadow-xl transition-all text-center"
                >
                  <info.icon className="w-6 h-6 text-[#0d9488] mx-auto mb-2" />
                  <p className="text-xs text-[#64748b] mb-1">{info.label}</p>
                  <p className="text-sm font-medium text-[#0f172a]" dir={info.label === 'ایمیل' ? 'ltr' : 'rtl'}>
                    {info.value}
                  </p>
                </a>
              ) : (
                <div key={info.label} className="bg-white rounded-xl p-4 shadow-lg border border-gray-50 text-center">
                  <info.icon className="w-6 h-6 text-[#0d9488] mx-auto mb-2" />
                  <p className="text-xs text-[#64748b] mb-1">{info.label}</p>
                  <p className="text-sm font-medium text-[#0f172a]">{info.value}</p>
                </div>
              )
            ))}
          </div>
        </div>

        {/* Form + Map */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="grid lg:grid-cols-2 gap-10">
            {/* Form */}
            <div>
              <h2 className="text-2xl font-bold text-[#0f172a] mb-6">ارسال پیام</h2>
              {submitted ? (
                <div className="bg-gray-50 rounded-2xl p-10 text-center border border-gray-100">
                  <CheckCircle2 className="w-16 h-16 text-[#0d9488] mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-[#0f172a] mb-2">پیام شما ارسال شد</h3>
                  <p className="text-[#64748b]">کارشناسان ما در اسرع وقت با شما تماس خواهند گرفت.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-[#334155] mb-1.5">نام و نام خانوادگی</label>
                      <input
                        type="text"
                        required
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm"
                        placeholder="نام کامل"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-[#334155] mb-1.5">شماره تماس</label>
                      <input
                        type="tel"
                        required
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm"
                        placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                        dir="ltr"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">ایمیل (اختیاری)</label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm"
                      placeholder="email@example.com"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">موضوع</label>
                    <select
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm bg-white"
                    >
                      <option value="">انتخاب کنید...</option>
                      <option value="course">استعلام وضعیت دوره</option>
                      <option value="register">ثبت‌نام</option>
                      <option value="certificate">استعلام مدرک</option>
                      <option value="consulting">مشاوره</option>
                      <option value="complaint">شکایت یا پیشنهاد</option>
                      <option value="other">سایر</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">پیام</label>
                    <textarea
                      rows={5}
                      required
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm resize-none"
                      placeholder="متن پیام خود را بنویسید..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-[#0d9488] text-white font-bold py-3.5 rounded-xl hover:bg-[#0f766e] transition-colors shadow-sm shadow-[#0d9488]/20 flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    ارسال پیام
                  </button>
                </form>
              )}
            </div>

            {/* Map */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-[#0f172a] mb-6">موقعیت مکانی</h2>
              <div className="rounded-2xl overflow-hidden border border-gray-100 h-80">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3245.6!2d52.2674!3d36.6304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzbCsDM3JzQ5LjQiTiA1MsKwMTYnMDIuNiJF!5e0!3m2!1sfa!2sir!4v1"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title={`موقعیت ${siteConfig.name.fullName}`}
                />
              </div>
              <div className="bg-gray-50 rounded-2xl p-6">
                <h3 className="font-bold text-[#0f172a] mb-3">راهنمای دسترسی</h3>
                <p className="text-sm text-[#64748b] leading-relaxed">
                  {siteConfig.name.fa} در شهر {siteConfig.location.city}، خیابان اصلی امام، کوچه آسیاب (نسیم ۴)، انتهای کوچه واقع شده است.
                  فاصله تا مرکز شهر ۵ دقیقه پیاده و فاصله تا اتوبان ۱۰ دقیقه با خودرو است.
                  پارکینگ اختصاصی برای مراجعین در نظر گرفته شده است.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
