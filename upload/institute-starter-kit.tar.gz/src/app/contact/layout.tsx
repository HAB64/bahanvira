import { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: `تماس با آموزشگاه فنی و حرفه‌ای ${siteConfig.name.fa} | ${siteConfig.location.city}`,
  description: `تماس با ${siteConfig.name.fullName} ${siteConfig.location.city}. تلفن: ${siteConfig.contact.phone} | واتساپ: ${siteConfig.contact.whatsappDisplay} | آدرس: ${siteConfig.location.fullAddress}`,
  keywords: [`تماس ${siteConfig.name.fa}`, `آدرس آموزشگاه ${siteConfig.location.city}`, 'ثبت‌نام دوره', `آموزشگاه فنی و حرفه‌ای ${siteConfig.location.city}`],
  alternates: {
    canonical: `${siteConfig.url.base}/contact`,
  },
  openGraph: {
    title: `تماس با آموزشگاه فنی و حرفه‌ای ${siteConfig.name.fa}`,
    description: `تماس و ثبت‌نام دوره‌های ${siteConfig.institute.typeFa}`,
    locale: 'fa_IR',
    url: `${siteConfig.url.base}/contact`,
  },
};

export default function ContactLayout({ children }: { children: React.ReactNode }) {
  return children;
}
