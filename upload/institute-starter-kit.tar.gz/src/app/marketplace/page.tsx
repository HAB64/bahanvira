'use client';

import { useState, useEffect, useMemo } from 'react';

// ─── Types ──────────────────────────────────────────────────────────────────

interface MarketplaceApp {
  id: string;
  name: string;
  slug: string;
  shortDesc: string | null;
  category: string;
  iconUrl: string | null;
  pricingModel: string;
  price: number;
  monthlyPrice: number | null;
  downloads: number;
  rating: number;
  reviewCount: number;
  developerName: string | null;
  version: string;
  createdAt: string;
}

interface CategoryCount {
  category: string;
  _count: number;
}

// ─── Category Labels ────────────────────────────────────────────────────────

const CATEGORY_LABELS: Record<string, string> = {
  PAYMENT: 'پرداخت',
  COMMUNICATION: 'ارتباطات',
  ANALYTICS: 'تحلیل داده',
  INTEGRATION: 'یکپارچه‌سازی',
  PLUGIN: 'افزونه',
};

const PRICING_LABELS: Record<string, string> = {
  FREE: 'رایگان',
  FREEMIUM: 'فریمیوم',
  PAID: 'پولی',
};

// ─── Component ──────────────────────────────────────────────────────────────

export default function MarketplacePage() {
  const [apps, setApps] = useState<MarketplaceApp[]>([]);
  const [categories, setCategories] = useState<CategoryCount[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  useEffect(() => {
    fetchApps();
  }, []);

  async function fetchApps() {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (activeCategory) params.set('category', activeCategory);
      if (search.trim()) params.set('search', search.trim());

      const res = await fetch(`/api/marketplace?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setApps(data.apps ?? []);
        if (!activeCategory) setCategories(data.categories ?? []);
      }
    } catch (err) {
      console.error('Marketplace fetch error:', err);
    } finally {
      setLoading(false);
    }
  }

  // Re-fetch when search or category changes
  useEffect(() => {
    const timer = setTimeout(() => {
      fetchApps();
    }, 300);
    return () => clearTimeout(timer);
  }, [search, activeCategory]);

  const filteredApps = useMemo(() => {
    if (!search.trim()) return apps;
    const q = search.trim().toLowerCase();
    return apps.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        (a.shortDesc ?? '').toLowerCase().includes(q)
    );
  }, [apps, search]);

  function formatNumber(n: number): string {
    return new Intl.NumberFormat('fa-IR').format(n);
  }

  function renderStars(rating: number) {
    const full = Math.floor(rating);
    const half = rating - full >= 0.5 ? 1 : 0;
    const empty = 5 - full - half;
    return (
      <span className="flex items-center gap-0.5" dir="ltr">
        {Array.from({ length: full }).map((_, i) => (
          <span key={`f-${i}`} className="text-amber-400 text-xs">★</span>
        ))}
        {half > 0 && <span className="text-amber-400 text-xs">★</span>}
        {Array.from({ length: empty }).map((_, i) => (
          <span key={`e-${i}`} className="text-gray-300 text-xs">★</span>
        ))}
      </span>
    );
  }

  function renderPricingBadge(model: string, price: number, monthlyPrice: number | null) {
    const label = PRICING_LABELS[model] || model;
    const colorClass =
      model === 'FREE'
        ? 'bg-emerald-100 text-emerald-700'
        : model === 'FREEMIUM'
          ? 'bg-sky-100 text-sky-700'
          : 'bg-orange-100 text-orange-700';

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colorClass}`}>
        {label}
        {model === 'PAID' && monthlyPrice ? (
          <span className="mr-1 text-[10px] opacity-75">
            {formatNumber(monthlyPrice)} تومان/ماه
          </span>
        ) : null}
        {model === 'PAID' && !monthlyPrice && price > 0 ? (
          <span className="mr-1 text-[10px] opacity-75">
            {formatNumber(price)} تومان
          </span>
        ) : null}
      </span>
    );
  }

  // ─── Skeleton Loader ───────────────────────────────────────────────────

  function SkeletonCard() {
    return (
      <div className="bg-white rounded-2xl border border-gray-100 p-5 animate-pulse">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-xl bg-gray-200 shrink-0" />
          <div className="flex-1 space-y-3">
            <div className="h-5 w-3/4 rounded bg-gray-200" />
            <div className="h-4 w-1/2 rounded bg-gray-200" />
            <div className="h-3 w-full rounded bg-gray-100" />
            <div className="h-3 w-5/6 rounded bg-gray-100" />
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <div className="h-6 w-20 rounded-full bg-gray-200" />
          <div className="h-9 w-24 rounded-lg bg-gray-200" />
        </div>
      </div>
    );
  }

  // ─── Render ────────────────────────────────────────────────────────────

  return (
    <div dir="rtl" className="min-h-screen bg-gray-50">
      {/* ── Gradient Header ─────────────────────────────────────────────── */}
      <header className="relative overflow-hidden bg-gradient-to-bl from-teal-600 via-emerald-600 to-cyan-700">
        <div className="absolute inset-0 opacity-10">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage:
                'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)',
              backgroundSize: '60px 60px',
            }}
          />
        </div>
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-12 sm:py-16 text-center">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white mb-3">
            مارکت‌پلیس اپلیکیشن‌ها
          </h1>
          <p className="text-teal-100 text-base sm:text-lg max-w-xl mx-auto leading-relaxed">
            اپلیکیشن‌های مورد نیاز خود را پیدا کنید و با یک کلیک نصب کنید
          </p>

          {/* Search Bar */}
          <div className="mt-8 max-w-lg mx-auto relative">
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </span>
            <input
              type="text"
              placeholder="جستجوی اپلیکیشن..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pr-12 pl-4 py-3 rounded-xl border-0 bg-white/95 backdrop-blur text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-white/50 text-sm sm:text-base shadow-lg"
            />
          </div>
        </div>
      </header>

      {/* ── Category Filters ────────────────────────────────────────────── */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 -mt-6 relative z-10">
        <div className="flex flex-wrap gap-2 justify-center">
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 shadow-sm ${
              activeCategory === null
                ? 'bg-teal-600 text-white shadow-md'
                : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            همه دسته‌ها
          </button>
          {categories.map((cat) => (
            <button
              key={cat.category}
              onClick={() =>
                setActiveCategory(
                  activeCategory === cat.category ? null : cat.category
                )
              }
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 shadow-sm ${
                activeCategory === cat.category
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              {CATEGORY_LABELS[cat.category] || cat.category}
              <span className="mr-1.5 text-xs opacity-60">
                ({formatNumber(cat._count)})
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* ── App Grid ────────────────────────────────────────────────────── */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
        {loading ? (
          /* Skeleton State */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {Array.from({ length: 6 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : filteredApps.length === 0 ? (
          /* Empty State */
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center mb-6">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-12 w-12 text-gray-300"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={1.5}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
                />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">
              هنوز اپلیکیشنی ثبت نشده است
            </h3>
            <p className="text-gray-400 text-sm max-w-sm">
              به‌زودی اپلیکیشن‌های جدیدی در مارکت‌پلیس اضافه خواهند شد
            </p>
          </div>
        ) : (
          /* App Cards */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredApps.map((app) => (
              <article
                key={app.id}
                className="group bg-white rounded-2xl border border-gray-100 p-5 hover:shadow-xl hover:border-teal-200 transition-all duration-300 hover:-translate-y-1 flex flex-col"
              >
                {/* Top Row: Icon + Info */}
                <div className="flex items-start gap-4">
                  {/* App Icon */}
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-teal-50 to-emerald-100 flex items-center justify-center shrink-0 border border-teal-100">
                    {app.iconUrl ? (
                      <img
                        src={app.iconUrl}
                        alt={app.name}
                        className="w-8 h-8 rounded-lg object-cover"
                      />
                    ) : (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-7 w-7 text-teal-600"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={1.5}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
                        />
                      </svg>
                    )}
                  </div>

                  {/* Name, Category, Developer */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-gray-800 text-sm leading-tight truncate">
                      {app.name}
                    </h3>
                    <span className="text-xs text-gray-400 mt-0.5 block">
                      {CATEGORY_LABELS[app.category] || app.category}
                      {app.developerName ? ` · ${app.developerName}` : ''}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <p className="mt-3 text-xs text-gray-500 leading-relaxed line-clamp-2 flex-1">
                  {app.shortDesc || 'بدون توضیحات'}
                </p>

                {/* Rating + Downloads */}
                <div className="mt-4 flex items-center gap-4 text-xs text-gray-400">
                  <span className="flex items-center gap-1">
                    {renderStars(app.rating)}
                    <span className="mr-1 text-gray-500">{app.rating.toFixed(1)}</span>
                    {app.reviewCount > 0 && (
                      <span>({formatNumber(app.reviewCount)})</span>
                    )}
                  </span>
                  {app.downloads > 0 && (
                    <span className="flex items-center gap-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-3.5 w-3.5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={2}
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
                        />
                      </svg>
                      {formatNumber(app.downloads)}
                    </span>
                  )}
                </div>

                {/* Bottom Row: Pricing Badge + Install Button */}
                <div className="mt-4 flex items-center justify-between pt-3 border-t border-gray-50">
                  {renderPricingBadge(app.pricingModel, app.price, app.monthlyPrice)}

                  <button
                    className="px-5 py-2 bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white text-sm font-medium rounded-lg transition-colors duration-150 shadow-sm hover:shadow"
                  >
                    نصب
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}