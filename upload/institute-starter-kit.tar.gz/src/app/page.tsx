import { cookies } from 'next/headers';
import HeroWithFeatures from '@/components/home/HeroWithFeatures';
import FeaturedCourses from '@/components/home/FeaturedCourses';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import SchemaMarkup from '@/components/SchemaMarkup';
import {
  CareerPathQuiz,
  ExitIntentPopup,
  FAQSection,
  SocialProofAndCTA,
  PersonalizedRecommendations,
  GatedContentSection,
  BehaviorTracker,
  WebVitalsReporter,
} from '@/components/home/LazyComponents';
import { getPersonalizationFromCookies } from '@/lib/personalization';
import PersonalizedHeroClient from '@/components/home/PersonalizedHeroClient';

/**
 * ═══════════════════════════════════════════════
 * صفحه اصلی — نسخه ۳ بهینه‌شده (Phase 1: 100%)
 * ═══════════════════════════════════════════════
 *
 * استراتژی: حذف بار اضافی + کاهش TBT/LCP + بار شناختی حداقل
 *
 * ساختار نهایی صفحه اصلی (۷ سکشن — بهینه):
 *   ۱. Hero — پیام واضح + ۲ CTA + فرم مشاوره + ۴ خوشه (Server)
 *   ۲. FeaturedCourses — ۴ دوره برتر (Server)
 *   ۳. CareerPathQuiz — کوییز مسیردهی (Lazy)
 *   ۴. PersonalizedRecommendations — پیشنهاد تعاملی هوشمند (Lazy)
 *   ۵. SocialProofAndCTA — اعتبار + دعوت به اقدام ادغام‌شده (Lazy)
 *   ۶. GatedContentSection — محتوای رایگان پشت در (Lazy)
 *   ۷. FAQSection — سوالات متداول (Lazy)
 *
 * حذف شد از صفحه اصلی (انتقال به صفحات اختصاصی خوشه):
 *   ❌ AISection — 870+ خط، 30+ تصویر → /courses?cluster=tech-ai
 *   ❌ CapitalMarketSection — 769+ خط، 30+ تصویر → /courses?cluster=financial
 *   ❌ CTASection — ادغام در SocialProofAndCTA
 *
 * Phase 2 — سیستم هدایت تعاملی:
 *   ✅ CareerPathQuiz — کوییز مسیردهی (lazy)
 *   ✅ PersonalizedRecommendations — پیشنهاد تعاملی (lazy)
 *   ✅ GatedContentSection — محتوای پشت درِ لید (lazy)
 *
 * Phase 4 — سیستم سایبرنتیک آموزشی:
 *   ✅ BehaviorTracker — ردیابی رفتار کاربران (lazy)
 *   ✅ WebVitalsReporter — جمع‌آوری Core Web Vitals (lazy)
 *   ✅ UTMPersonalizer — ادغام در PersonalizedHeroClient
 */
export default async function Home() {
  // Server-side personalization: read br_campaign cookie
  const cookieStore = await cookies();
  const cookieHeader = cookieStore.get('br_campaign')?.value ?? null;
  const fullCookieHeader = cookieHeader !== null
    ? `br_campaign=${cookieHeader}`
    : null;
  const personalization = getPersonalizationFromCookies(fullCookieHeader);

  return (
    <div className="min-h-screen flex flex-col">
      <SchemaMarkup />
      {/* Server-side personalization banner — فقط اگر شخصی‌سازی فعال باشد */}
      <PersonalizedHeroClient personalization={personalization} />

      <main className="flex-1">
        {/* ── ۱. Hero: پیام واضح + ۲ CTA + فرم مشاوره + ۴ خوشه ── */}
        <HeroWithFeatures />

        {/* ── ۲. دوره‌های برتر — Server-rendered, above fold ── */}
        <FeaturedCourses />

        {/* ── ۳. کوییز مسیردهی هوشمند — Lazy ── */}
        <CareerPathQuiz />

        {/* ── ۴. پیشنهاد تعاملی هوشمند — Lazy ── */}
        <PersonalizedRecommendations />

        {/* ── ۵. اعتبار و دعوت به اقدام — ادغام‌شده (Lazy) ── */}
        <SocialProofAndCTA />

        {/* ── ۶. محتوای رایگان پشت در — Lazy ── */}
        <GatedContentSection />

        {/* ── ۷. سوالات متداول — Lazy ── */}
        <FAQSection />
      </main>

      <Footer />
      <WhatsAppButton />
      <ExitIntentPopup />

      {/* ── Phase 4: سایبرنتیک — ردیابی رفتار و عملکرد ── */}
      <BehaviorTracker />
      <WebVitalsReporter />
    </div>
  );
}
