'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  BookOpen,
  Users,
  ClipboardCheck,
  Award,
  LogOut,
  LayoutDashboard,
  Calendar,
  Clock,
  TrendingUp,
  UserCheck,
  GraduationCap,
  ArrowRight,
  Plus,
  Save,
  CheckCircle,
  XCircle,
  AlertCircle,
  FileText,
  Edit,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface ProgramInfo {
  id: string;
  code: string | null;
  name: string;
  description: string | null;
  totalHours: number;
  theoryHours: number;
  practicalHours: number;
  minAttendancePct: number;
  price: number | null;
  capacity: number | null;
  isActive: boolean;
  cluster: string | null;
  instructorName: string | null;
  level: string | null;
}

interface StudentInfo {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  nationalId: string;
  studentCode: string | null;
  photo: string | null;
  status: string;
}

interface StudentData {
  enrollmentId: string;
  enrollmentStatus: string;
  enrollmentDate: string;
  finalGrade: number | null;
  isPassed: boolean | null;
  karAmuz: StudentInfo;
  attendanceStats: {
    present: number;
    late: number;
    absent: number;
    excused: number;
    total: number;
  };
  attendanceRate: number;
  evaluations: Array<{
    type: string;
    score: number | null;
    maxScore: number;
    title: string;
  }>;
  avgScore: number | null;
}

interface SessionInfo {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  title: string | null;
  type: string;
  instructorName: string | null;
  attendanceCount: number;
}

interface EvaluationInfo {
  id: string;
  karAmuzId: string;
  skillProgramId: string;
  type: string;
  title: string;
  score: number | null;
  maxScore: number;
  date: string;
  notes: string | null;
  karAmuz: {
    id: string;
    firstName: string;
    lastName: string;
    studentCode: string | null;
  };
}

interface ProgramData {
  program: ProgramInfo;
  students: StudentData[];
  sessions: SessionInfo[];
  evaluations: EvaluationInfo[];
  evaluationTypeSummary: Record<string, { count: number; avgScore: number }>;
  overallAttendance: {
    total: number;
    present: number;
    late: number;
    absent: number;
    excused: number;
  };
  totalEnrollments: number;
  activeEnrollments: number;
}

/* ─────────── Helper functions ─────────── */

function getStatusLabel(status: string): string {
  const map: Record<string, string> = {
    PRESENT: 'حاضر',
    ABSENT: 'غایب',
    LATE: 'تأخیر',
    EXCUSED: 'مرخصی',
  };
  return map[status] || status;
}

function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    PRESENT: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    ABSENT: 'bg-red-100 text-red-700 border-red-200',
    LATE: 'bg-amber-100 text-amber-700 border-amber-200',
    EXCUSED: 'bg-blue-100 text-blue-700 border-blue-200',
  };
  return map[status] || 'bg-gray-100 text-gray-700 border-gray-200';
}

function getTypeLabel(type: string): string {
  const map: Record<string, string> = {
    MIDTERM: 'میان‌ترم',
    FINAL: 'پایان‌ترم',
    PROJECT: 'پروژه',
    PRACTICAL: 'عملی',
    THEORY: 'تئوری',
    SKILL_CHECK: 'مهارت‌سنجی',
  };
  return map[type] || type;
}

function getLevelLabel(level: string | null): string {
  const map: Record<string, string> = {
    BEGINNER: 'مبتدی',
    INTERMEDIATE: 'متوسط',
    ADVANCED: 'پیشرفته',
  };
  if (!level) return '';
  return map[level] || level;
}

function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr);
    return date.toLocaleDateString('fa-IR');
  } catch {
    return dateStr;
  }
}

function getEnrollmentStatusLabel(status: string): string {
  const map: Record<string, string> = {
    ENROLLED: 'فعال',
    COMPLETED: 'تکمیل‌شده',
    DROPPED: 'ترک‌شده',
    FAILED: 'مردود',
  };
  return map[status] || status;
}

function getEnrollmentStatusColor(status: string): string {
  const map: Record<string, string> = {
    ENROLLED: 'bg-emerald-100 text-emerald-700',
    COMPLETED: 'bg-blue-100 text-blue-700',
    DROPPED: 'bg-red-100 text-red-700',
    FAILED: 'bg-amber-100 text-amber-700',
  };
  return map[status] || 'bg-gray-100 text-gray-700';
}

/* ─────────── Component ─────────── */

export default function InstructorProgramPage() {
  const router = useRouter();
  const params = useParams();
  const skillProgramId = params.skillProgramId as string;

  const [data, setData] = useState<ProgramData | null>(null);
  const [loading, setLoading] = useState(true);
  const [authChecked, setAuthChecked] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  // Attendance state
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [attendanceRecords, setAttendanceRecords] = useState<Record<string, string>>({});
  const [savingAttendance, setSavingAttendance] = useState(false);

  // Evaluation state
  const [evalDialogOpen, setEvalDialogOpen] = useState(false);
  const [evalKarAmuzId, setEvalKarAmuzId] = useState('');
  const [evalKarAmuzName, setEvalKarAmuzName] = useState('');
  const [evalType, setEvalType] = useState('');
  const [evalScore, setEvalScore] = useState('');
  const [evalMaxScore, setEvalMaxScore] = useState('20');
  const [evalNote, setEvalNote] = useState('');
  const [savingEval, setSavingEval] = useState(false);

  const checkAuth = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/auth/check');
      if (!res.ok) {
        router.push('/admin/login');
        return;
      }
      setAuthChecked(true);
    } catch {
      router.push('/admin/login');
    }
  }, [router]);

  const fetchProgram = useCallback(async () => {
    try {
      const res = await fetch(`/api/instructor/program/${skillProgramId}`);
      if (res.status === 401) {
        router.push('/admin/login');
        return;
      }
      if (res.status === 403) {
        toast.error('شما مجوز دسترسی به این برنامه را ندارید');
        router.push('/instructor');
        return;
      }
      if (!res.ok) {
        toast.error('خطا در دریافت اطلاعات برنامه');
        router.push('/instructor');
        return;
      }
      const json = await res.json();
      setData(json);
    } catch {
      toast.error('خطا در اتصال به سرور');
    } finally {
      setLoading(false);
    }
  }, [skillProgramId, router]);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  useEffect(() => {
    if (authChecked) {
      fetchProgram();
    }
  }, [authChecked, fetchProgram]);

  // Initialize attendance records when session is selected
  useEffect(() => {
    if (selectedSessionId && data) {
      const initial: Record<string, string> = {};
      data.students.forEach((s) => {
        initial[s.karAmuz.id] = 'PRESENT';
      });
      setAttendanceRecords(initial);
    }
  }, [selectedSessionId, data]);

  const handleLogout = async () => {
    try {
      await fetch('/api/admin/auth/logout', { method: 'POST' });
      router.push('/admin/login');
    } catch {
      toast.error('خطا در خروج');
    }
  };

  const handleSaveAttendance = async () => {
    if (!selectedSessionId) {
      toast.error('لطفاً ابتدا یک جلسه انتخاب کنید');
      return;
    }

    setSavingAttendance(true);
    try {
      const records = Object.entries(attendanceRecords).map(([karAmuzId, status]) => ({
        karAmuzId,
        status,
      }));

      const res = await fetch('/api/instructor/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: selectedSessionId, records }),
      });

      const result = await res.json();

      if (res.ok) {
        toast.success(`حضور و غیاب ${toPersianNumber(records.length)} کارآموز ثبت شد`);
        fetchProgram();
      } else {
        toast.error(result.error || 'خطا در ثبت حضور و غیاب');
      }
    } catch {
      toast.error('خطا در اتصال به سرور');
    } finally {
      setSavingAttendance(false);
    }
  };

  const openEvalDialog = (karAmuzId: string, name: string, existingType?: string, existingScore?: number | null, existingMaxScore?: number, existingNote?: string | null) => {
    setEvalKarAmuzId(karAmuzId);
    setEvalKarAmuzName(name);
    setEvalType(existingType || '');
    setEvalScore(existingScore !== null && existingScore !== undefined ? String(existingScore) : '');
    setEvalMaxScore(existingMaxScore ? String(existingMaxScore) : '20');
    setEvalNote(existingNote || '');
    setEvalDialogOpen(true);
  };

  const handleSaveEvaluation = async () => {
    if (!evalType) {
      toast.error('لطفاً نوع ارزیابی را انتخاب کنید');
      return;
    }

    setSavingEval(true);
    try {
      const res = await fetch('/api/instructor/evaluation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          karAmuzId: evalKarAmuzId,
          skillProgramId,
          type: evalType,
          score: evalScore !== '' ? Number(evalScore) : undefined,
          maxScore: Number(evalMaxScore) || 20,
          note: evalNote || undefined,
        }),
      });

      const result = await res.json();

      if (res.ok) {
        toast.success('ارزیابی با موفقیت ثبت شد');
        setEvalDialogOpen(false);
        fetchProgram();
      } else {
        toast.error(result.error || 'خطا در ثبت ارزیابی');
      }
    } catch {
      toast.error('خطا در اتصال به سرور');
    } finally {
      setSavingEval(false);
    }
  };

  if (!authChecked || loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-50 via-indigo-50 to-purple-50" dir="rtl">
        <div className="bg-white/80 backdrop-blur-md border-b border-indigo-100 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
            <Skeleton className="h-8 w-40" />
            <Skeleton className="h-8 w-24" />
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <Skeleton className="h-8 w-64 mb-6" />
          <Skeleton className="h-10 w-full mb-6" />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-28 rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-50 via-indigo-50 to-purple-50 flex items-center justify-center" dir="rtl">
        <Card className="w-full max-w-md shadow-xl border-0">
          <CardContent className="p-6 text-center">
            <AlertCircle className="h-12 w-12 text-red-400 mx-auto mb-3" />
            <p className="text-gray-600 mb-4">خطا در بارگذاری اطلاعات برنامه</p>
            <Button onClick={fetchProgram} className="bg-indigo-600 hover:bg-indigo-700">
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { program, students, sessions, evaluations } = data;

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-indigo-50 to-purple-50" dir="rtl">
      {/* ─── Top Navigation ─── */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-indigo-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/instructor" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-200">
                <span className="text-white font-bold text-lg">ب</span>
              </div>
              <div>
                <h1 className="font-bold text-gray-900 text-sm sm:text-base">پنل استاد</h1>
                <p className="text-xs text-gray-500 hidden sm:block">بهان رایانه</p>
              </div>
            </Link>
            <div className="hidden sm:flex items-center gap-1 text-gray-400 mx-2">
              <ArrowRight className="h-4 w-4" />
            </div>
            <div className="hidden sm:block">
              <p className="text-sm font-medium text-gray-700 truncate max-w-48">{program.name}</p>
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-2">
            <Link href="/instructor">
              <Button variant="ghost" size="sm" className="text-indigo-700 hover:bg-indigo-50 gap-1">
                <LayoutDashboard className="h-4 w-4" />
                <span className="hidden sm:inline">داشبورد</span>
              </Button>
            </Link>
            <Link href="/instructor">
              <Button variant="ghost" size="sm" className="text-indigo-700 hover:bg-indigo-50 gap-1">
                <BookOpen className="h-4 w-4" />
                <span className="hidden sm:inline">برنامه‌های من</span>
              </Button>
            </Link>
            <div className="w-px h-6 bg-indigo-100 mx-1 hidden sm:block" />
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-red-600 hover:bg-red-50 gap-1"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">خروج</span>
            </Button>
          </div>
        </div>
      </nav>

      {/* ─── Main Content ─── */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Program Header */}
        <div className="mb-6">
          <Link href="/instructor" className="inline-flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 mb-2">
            <ArrowRight className="h-4 w-4" />
            بازگشت به داشبورد
          </Link>
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900">{program.name}</h2>
          <div className="flex gap-2 mt-2 flex-wrap">
            {program.code && (
              <Badge variant="outline" className="text-xs">کد: {program.code}</Badge>
            )}
            {program.level && (
              <Badge className="text-xs bg-indigo-100 text-indigo-700">{getLevelLabel(program.level)}</Badge>
            )}
            <Badge className="text-xs bg-violet-100 text-violet-700">{toPersianNumber(program.totalHours)} ساعت</Badge>
            <Badge className={program.isActive ? 'text-xs bg-emerald-100 text-emerald-700' : 'text-xs bg-gray-100 text-gray-700'}>
              {program.isActive ? 'فعال' : 'غیرفعال'}
            </Badge>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full flex bg-white shadow-sm rounded-xl p-1 mb-6 h-auto flex-wrap">
            <TabsTrigger value="overview" className="flex-1 min-w-0 data-[state=active]:bg-indigo-600 data-[state=active]:text-white rounded-lg text-xs sm:text-sm py-2.5">
              <LayoutDashboard className="h-4 w-4 ml-1 hidden sm:inline" />
              نمای کلی
            </TabsTrigger>
            <TabsTrigger value="students" className="flex-1 min-w-0 data-[state=active]:bg-indigo-600 data-[state=active]:text-white rounded-lg text-xs sm:text-sm py-2.5">
              <Users className="h-4 w-4 ml-1 hidden sm:inline" />
              کارآموزان
            </TabsTrigger>
            <TabsTrigger value="attendance" className="flex-1 min-w-0 data-[state=active]:bg-indigo-600 data-[state=active]:text-white rounded-lg text-xs sm:text-sm py-2.5">
              <ClipboardCheck className="h-4 w-4 ml-1 hidden sm:inline" />
              حضور و غیاب
            </TabsTrigger>
            <TabsTrigger value="evaluations" className="flex-1 min-w-0 data-[state=active]:bg-indigo-600 data-[state=active]:text-white rounded-lg text-xs sm:text-sm py-2.5">
              <Award className="h-4 w-4 ml-1 hidden sm:inline" />
              ارزیابی‌ها
            </TabsTrigger>
            <TabsTrigger value="content" className="flex-1 min-w-0 data-[state=active]:bg-indigo-600 data-[state=active]:text-white rounded-lg text-xs sm:text-sm py-2.5">
              <FileText className="h-4 w-4 ml-1 hidden sm:inline" />
              محتوا
            </TabsTrigger>
          </TabsList>

          {/* ─── Overview Tab ─── */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card className="border-0 shadow-md bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-1">
                    <Users className="h-5 w-5 opacity-80" />
                    <span className="text-2xl font-bold">{toPersianNumber(data.activeEnrollments)}</span>
                  </div>
                  <p className="text-indigo-100 text-xs">کارآموز فعال</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md bg-gradient-to-br from-violet-500 to-violet-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-1">
                    <Calendar className="h-5 w-5 opacity-80" />
                    <span className="text-2xl font-bold">{toPersianNumber(sessions.length)}</span>
                  </div>
                  <p className="text-violet-100 text-xs">جلسه برگزارشده</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-1">
                    <UserCheck className="h-5 w-5 opacity-80" />
                    <span className="text-2xl font-bold">
                      {data.overallAttendance.total > 0
                        ? `${toPersianNumber(Math.round((data.overallAttendance.present + data.overallAttendance.late) / data.overallAttendance.total * 100))}٪`
                        : '—'}
                    </span>
                  </div>
                  <p className="text-emerald-100 text-xs">نرخ حضور</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-md bg-gradient-to-br from-amber-500 to-amber-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-1">
                    <Award className="h-5 w-5 opacity-80" />
                    <span className="text-2xl font-bold">{toPersianNumber(evaluations.length)}</span>
                  </div>
                  <p className="text-amber-100 text-xs">ارزیابی ثبت‌شده</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Program Info */}
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-bold flex items-center gap-2">
                    <BookOpen className="h-5 w-5 text-indigo-600" />
                    اطلاعات برنامه
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {program.description && (
                      <div>
                        <p className="text-xs text-gray-400 mb-1">توضیحات</p>
                        <p className="text-sm text-gray-700">{program.description}</p>
                      </div>
                    )}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg bg-indigo-50">
                        <p className="text-xs text-indigo-400">ساعت تئوری</p>
                        <p className="text-lg font-bold text-indigo-700">{toPersianNumber(program.theoryHours)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-violet-50">
                        <p className="text-xs text-violet-400">ساعت عملی</p>
                        <p className="text-lg font-bold text-violet-700">{toPersianNumber(program.practicalHours)}</p>
                      </div>
                      <div className="p-3 rounded-lg bg-emerald-50">
                        <p className="text-xs text-emerald-400">حداقل حضور</p>
                        <p className="text-lg font-bold text-emerald-700">{toPersianNumber(Math.round(program.minAttendancePct * 100))}٪</p>
                      </div>
                      <div className="p-3 rounded-lg bg-amber-50">
                        <p className="text-xs text-amber-400">ظرفیت</p>
                        <p className="text-lg font-bold text-amber-700">{program.capacity ? toPersianNumber(program.capacity) : 'نامحدود'}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Attendance Summary */}
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-bold flex items-center gap-2">
                    <ClipboardCheck className="h-5 w-5 text-emerald-600" />
                    خلاصه حضور و غیاب
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {data.overallAttendance.total === 0 ? (
                    <p className="text-gray-400 text-sm text-center py-8">هنوز رکوردی ثبت نشده است</p>
                  ) : (
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-emerald-600 font-medium">حاضر</span>
                          <span className="text-gray-700">{toPersianNumber(data.overallAttendance.present)} از {toPersianNumber(data.overallAttendance.total)}</span>
                        </div>
                        <Progress value={(data.overallAttendance.present / data.overallAttendance.total) * 100} className="h-2 bg-gray-100" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-amber-600 font-medium">تأخیر</span>
                          <span className="text-gray-700">{toPersianNumber(data.overallAttendance.late)} از {toPersianNumber(data.overallAttendance.total)}</span>
                        </div>
                        <Progress value={(data.overallAttendance.late / data.overallAttendance.total) * 100} className="h-2 bg-gray-100" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-red-600 font-medium">غایب</span>
                          <span className="text-gray-700">{toPersianNumber(data.overallAttendance.absent)} از {toPersianNumber(data.overallAttendance.total)}</span>
                        </div>
                        <Progress value={(data.overallAttendance.absent / data.overallAttendance.total) * 100} className="h-2 bg-gray-100" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-blue-600 font-medium">مرخصی</span>
                          <span className="text-gray-700">{toPersianNumber(data.overallAttendance.excused)} از {toPersianNumber(data.overallAttendance.total)}</span>
                        </div>
                        <Progress value={(data.overallAttendance.excused / data.overallAttendance.total) * 100} className="h-2 bg-gray-100" />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Recent Sessions */}
            <Card className="border-0 shadow-md mt-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-violet-600" />
                  جلسات اخیر
                </CardTitle>
              </CardHeader>
              <CardContent>
                {sessions.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-8">هنوز جلسه‌ای ثبت نشده است</p>
                ) : (
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {sessions.slice(0, 5).map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center">
                            <Clock className="h-5 w-5 text-indigo-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              {session.title || `جلسه ${formatDate(session.date)}`}
                            </p>
                            <p className="text-xs text-gray-400">
                              {formatDate(session.date)} • {session.startTime} - {session.endTime}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs">
                            {getTypeLabel(session.type)}
                          </Badge>
                          <Badge className="text-xs bg-indigo-50 text-indigo-600">
                            {toPersianNumber(session.attendanceCount)} حضور
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ─── Students Tab ─── */}
          <TabsContent value="students">
            <Card className="border-0 shadow-md">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-bold flex items-center gap-2">
                    <Users className="h-5 w-5 text-indigo-600" />
                    لیست کارآموزان
                  </CardTitle>
                  <Badge variant="secondary" className="bg-indigo-100 text-indigo-700">
                    {toPersianNumber(students.length)} نفر
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {students.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-8">هنوز کارآموزی ثبت‌نام نکرده است</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-100">
                          <th className="text-right py-3 px-2 font-medium text-gray-500">نام</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500 hidden sm:table-cell">کد ملی</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500">وضعیت</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500">نرخ حضور</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500 hidden md:table-cell">میانگین نمره</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500">عملیات</th>
                        </tr>
                      </thead>
                      <tbody>
                        {students.map((student) => (
                          <tr key={student.karAmuz.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                            <td className="py-3 px-2">
                              <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center shrink-0">
                                  <span className="text-xs font-bold text-indigo-600">
                                    {student.karAmuz.firstName.charAt(0)}
                                  </span>
                                </div>
                                <div>
                                  <p className="font-medium text-gray-900 text-sm">{student.karAmuz.firstName} {student.karAmuz.lastName}</p>
                                  {student.karAmuz.studentCode && (
                                    <p className="text-xs text-gray-400">{student.karAmuz.studentCode}</p>
                                  )}
                                </div>
                              </div>
                            </td>
                            <td className="py-3 px-2 text-gray-600 hidden sm:table-cell">{student.karAmuz.nationalId}</td>
                            <td className="py-3 px-2">
                              <Badge className={`text-xs ${getEnrollmentStatusColor(student.enrollmentStatus)}`}>
                                {getEnrollmentStatusLabel(student.enrollmentStatus)}
                              </Badge>
                            </td>
                            <td className="py-3 px-2">
                              <div className="flex items-center gap-2">
                                <Progress value={student.attendanceRate} className="h-1.5 w-16 bg-gray-100" />
                                <span className="text-xs text-gray-600">{toPersianNumber(student.attendanceRate)}٪</span>
                              </div>
                            </td>
                            <td className="py-3 px-2 hidden md:table-cell">
                              {student.avgScore !== null ? (
                                <span className="font-medium text-gray-900">{toPersianNumber(student.avgScore)}</span>
                              ) : (
                                <span className="text-gray-400 text-xs">—</span>
                              )}
                            </td>
                            <td className="py-3 px-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-indigo-600 hover:bg-indigo-50 h-8 px-2"
                                onClick={() => openEvalDialog(
                                  student.karAmuz.id,
                                  `${student.karAmuz.firstName} ${student.karAmuz.lastName}`
                                )}
                              >
                                <Edit className="h-3.5 w-3.5 ml-1" />
                                ارزیابی
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ─── Attendance Tab ─── */}
          <TabsContent value="attendance">
            <Card className="border-0 shadow-md mb-6">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold flex items-center gap-2">
                  <ClipboardCheck className="h-5 w-5 text-emerald-600" />
                  ثبت حضور و غیاب
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <Label className="text-sm font-medium mb-2 block">انتخاب جلسه</Label>
                  <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="یک جلسه انتخاب کنید..." />
                    </SelectTrigger>
                    <SelectContent>
                      {sessions.map((session) => (
                        <SelectItem key={session.id} value={session.id}>
                          {session.title || `جلسه ${formatDate(session.date)}`} — {formatDate(session.date)} ({session.startTime} - {session.endTime})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedSessionId && (
                  <>
                    <div className="border border-gray-100 rounded-xl overflow-hidden">
                      <div className="bg-gray-50 px-4 py-3 flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">لیست کارآموزان</span>
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs h-7"
                            onClick={() => {
                              const allPresent: Record<string, string> = {};
                              students.forEach((s) => { allPresent[s.karAmuz.id] = 'PRESENT'; });
                              setAttendanceRecords(allPresent);
                            }}
                          >
                            همه حاضر
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs h-7"
                            onClick={() => {
                              const allAbsent: Record<string, string> = {};
                              students.forEach((s) => { allAbsent[s.karAmuz.id] = 'ABSENT'; });
                              setAttendanceRecords(allAbsent);
                            }}
                          >
                            همه غایب
                          </Button>
                        </div>
                      </div>
                      <div className="divide-y divide-gray-50 max-h-96 overflow-y-auto">
                        {students.map((student) => (
                          <div key={student.karAmuz.id} className="flex items-center justify-between px-4 py-3 hover:bg-gray-50 transition-colors">
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center shrink-0">
                                <span className="text-xs font-bold text-indigo-600">
                                  {student.karAmuz.firstName.charAt(0)}
                                </span>
                              </div>
                              <span className="text-sm font-medium text-gray-900 truncate">
                                {student.karAmuz.firstName} {student.karAmuz.lastName}
                              </span>
                            </div>
                            <div className="flex gap-1 shrink-0">
                              {(['PRESENT', 'LATE', 'ABSENT', 'EXCUSED'] as const).map((status) => (
                                <Button
                                  key={status}
                                  variant="outline"
                                  size="sm"
                                  className={`text-xs h-8 px-2.5 ${
                                    attendanceRecords[student.karAmuz.id] === status
                                      ? getStatusColor(status)
                                      : 'text-gray-400 border-gray-200'
                                  }`}
                                  onClick={() => setAttendanceRecords((prev) => ({ ...prev, [student.karAmuz.id]: status }))}
                                >
                                  {getStatusLabel(status)}
                                </Button>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="mt-4 flex justify-end">
                      <Button
                        onClick={handleSaveAttendance}
                        disabled={savingAttendance}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2"
                      >
                        {savingAttendance ? (
                          <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        ) : (
                          <Save className="h-4 w-4" />
                        )}
                        ثبت حضور و غیاب
                      </Button>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Attendance History */}
            <Card className="border-0 shadow-md">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-violet-600" />
                  تاریخچه جلسات
                </CardTitle>
              </CardHeader>
              <CardContent>
                {sessions.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-8">هنوز جلسه‌ای ثبت نشده است</p>
                ) : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {sessions.map((session) => (
                      <div key={session.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center">
                            <Calendar className="h-5 w-5 text-indigo-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-900">
                              {session.title || `جلسه ${formatDate(session.date)}`}
                            </p>
                            <p className="text-xs text-gray-400">
                              {formatDate(session.date)} • {session.startTime} - {session.endTime}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className="text-xs bg-indigo-50 text-indigo-600">
                            {toPersianNumber(session.attendanceCount)} رکورد
                          </Badge>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs h-7"
                            onClick={() => setSelectedSessionId(session.id)}
                          >
                            مشاهده
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ─── Evaluations Tab ─── */}
          <TabsContent value="evaluations">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
              {/* Evaluation Summary */}
              <Card className="border-0 shadow-md">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-bold flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-amber-600" />
                    خلاصه ارزیابی‌ها
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {Object.keys(data.evaluationTypeSummary).length === 0 ? (
                    <p className="text-gray-400 text-sm text-center py-4">هنوز ارزیابی‌ای ثبت نشده</p>
                  ) : (
                    <div className="space-y-3">
                      {Object.entries(data.evaluationTypeSummary).map(([type, summary]) => (
                        <div key={type} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                          <div>
                            <p className="text-sm font-medium text-gray-900">{getTypeLabel(type)}</p>
                            <p className="text-xs text-gray-400">{toPersianNumber(summary.count)} ارزیابی</p>
                          </div>
                          <div className="text-left">
                            <p className="text-lg font-bold text-indigo-700">{toPersianNumber(summary.avgScore)}</p>
                            <p className="text-xs text-gray-400">از ۲۰</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Quick Grade Entry */}
              <Card className="border-0 shadow-md lg:col-span-2">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-bold flex items-center gap-2">
                    <GraduationCap className="h-5 w-5 text-indigo-600" />
                    ثبت سریع ارزیابی
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500 mb-4">برای ثبت ارزیابی، روی دکمه «ارزیابی» در مقابل هر کارآموز کلیک کنید</p>
                  <div className="space-y-2 max-h-72 overflow-y-auto">
                    {students.map((student) => (
                      <div key={student.karAmuz.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center shrink-0">
                            <span className="text-xs font-bold text-indigo-600">
                              {student.karAmuz.firstName.charAt(0)}
                            </span>
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{student.karAmuz.firstName} {student.karAmuz.lastName}</p>
                            <div className="flex gap-1 mt-0.5">
                              {student.evaluations.map((ev, idx) => (
                                <Badge key={idx} variant="secondary" className="text-xs">
                                  {getTypeLabel(ev.type)}: {ev.score !== null ? toPersianNumber(ev.score) : '—'}
                                </Badge>
                              ))}
                              {student.evaluations.length === 0 && (
                                <span className="text-xs text-gray-400">بدون ارزیابی</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-indigo-600 border-indigo-200 hover:bg-indigo-50 h-8 px-3 gap-1"
                          onClick={() => openEvalDialog(
                            student.karAmuz.id,
                            `${student.karAmuz.firstName} ${student.karAmuz.lastName}`
                          )}
                        >
                          <Plus className="h-3.5 w-3.5" />
                          ارزیابی
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Evaluation History */}
            <Card className="border-0 shadow-md">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold flex items-center gap-2">
                  <Award className="h-5 w-5 text-amber-600" />
                  تاریخچه ارزیابی‌ها
                </CardTitle>
              </CardHeader>
              <CardContent>
                {evaluations.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-8">هنوز ارزیابی‌ای ثبت نشده است</p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-100">
                          <th className="text-right py-3 px-2 font-medium text-gray-500">کارآموز</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500">نوع</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500">عنوان</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500">نمره</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500 hidden sm:table-cell">تاریخ</th>
                          <th className="text-right py-3 px-2 font-medium text-gray-500">عملیات</th>
                        </tr>
                      </thead>
                      <tbody>
                        {evaluations.map((ev) => (
                          <tr key={ev.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                            <td className="py-3 px-2">
                              <p className="font-medium text-gray-900">{ev.karAmuz.firstName} {ev.karAmuz.lastName}</p>
                            </td>
                            <td className="py-3 px-2">
                              <Badge variant="secondary" className="text-xs bg-indigo-50 text-indigo-600">
                                {getTypeLabel(ev.type)}
                              </Badge>
                            </td>
                            <td className="py-3 px-2 text-gray-600">{ev.title}</td>
                            <td className="py-3 px-2">
                              {ev.score !== null ? (
                                <span className="font-medium text-gray-900">{toPersianNumber(ev.score)} / {toPersianNumber(ev.maxScore)}</span>
                              ) : (
                                <span className="text-gray-400">—</span>
                              )}
                            </td>
                            <td className="py-3 px-2 text-gray-500 hidden sm:table-cell">{formatDate(ev.date)}</td>
                            <td className="py-3 px-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-indigo-600 hover:bg-indigo-50 h-8 px-2"
                                onClick={() => openEvalDialog(
                                  ev.karAmuzId,
                                  `${ev.karAmuz.firstName} ${ev.karAmuz.lastName}`,
                                  ev.type,
                                  ev.score,
                                  ev.maxScore,
                                  ev.notes
                                )}
                              >
                                <Edit className="h-3.5 w-3.5" />
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* ─── Content Tab ─── */}
          <TabsContent value="content">
            <Card className="border-0 shadow-md">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold flex items-center gap-2">
                  <FileText className="h-5 w-5 text-indigo-600" />
                  مدیریت محتوای آموزشی
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-2xl bg-indigo-100 flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="h-8 w-8 text-indigo-600" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">مدیریت محتوا</h3>
                  <p className="text-gray-500 text-sm mb-6 max-w-md mx-auto">
                    برای مدیریت محتوای آموزشی این برنامه (درس‌ها، ویدیوها، مستندات) از پنل مدیریت LMS استفاده کنید
                  </p>
                  <Link href={`/admin/lms?program=${skillProgramId}`}>
                    <Button className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2">
                      <BookOpen className="h-4 w-4" />
                      رفتن به مدیریت محتوا
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* ─── Evaluation Dialog ─── */}
      <Dialog open={evalDialogOpen} onOpenChange={setEvalDialogOpen}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>ثبت ارزیابی</DialogTitle>
            <DialogDescription>
              ارزیابی برای {evalKarAmuzName}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-sm font-medium mb-1.5 block">نوع ارزیابی</Label>
              <Select value={evalType} onValueChange={setEvalType}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب کنید..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MIDTERM">میان‌ترم</SelectItem>
                  <SelectItem value="FINAL">پایان‌ترم</SelectItem>
                  <SelectItem value="PROJECT">پروژه</SelectItem>
                  <SelectItem value="PRACTICAL">عملی</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm font-medium mb-1.5 block">نمره</Label>
                <Input
                  type="number"
                  min="0"
                  max={evalMaxScore}
                  step="0.5"
                  value={evalScore}
                  onChange={(e) => setEvalScore(e.target.value)}
                  placeholder="نمره"
                />
              </div>
              <div>
                <Label className="text-sm font-medium mb-1.5 block">نمره کل</Label>
                <Input
                  type="number"
                  min="1"
                  value={evalMaxScore}
                  onChange={(e) => setEvalMaxScore(e.target.value)}
                  placeholder="20"
                />
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium mb-1.5 block">یادداشت (اختیاری)</Label>
              <Textarea
                value={evalNote}
                onChange={(e) => setEvalNote(e.target.value)}
                placeholder="توضیحات تکمیلی..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setEvalDialogOpen(false)}
            >
              انصراف
            </Button>
            <Button
              onClick={handleSaveEvaluation}
              disabled={savingEval || !evalType}
              className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2"
            >
              {savingEval ? (
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              ثبت ارزیابی
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="mt-auto py-6 text-center text-xs text-gray-400 border-t border-indigo-100 bg-white/50">
        <p>آموزشگاه فنی و حرفه‌ای بهان رایانه — پنل استاد</p>
      </footer>
    </div>
  );
}
