'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  BookOpen,
  Users,
  ClipboardCheck,
  Award,
  Clock,
  TrendingUp,
  UserCheck,
  GraduationCap,
  ArrowLeft,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface InstructorInfo {
  id: string;
  username: string;
  displayName: string;
}

interface ProgramStats {
  id: string;
  name: string;
  code: string | null;
  description: string | null;
  totalHours: number;
  theoryHours: number;
  practicalHours: number;
  level: string | null;
  cluster: string | null;
  capacity: number | null;
  enrollmentCount: number;
  sessionCount: number;
  attendanceStats: {
    total: number;
    present: number;
    late: number;
    absent: number;
    excused: number;
  };
  avgAttendance: number;
  avgGrade: number;
  evaluationCount: number;
}

interface RecentAttendance {
  id: string;
  status: string;
  hours: number;
  createdAt: string;
  karAmuz: {
    id: string;
    firstName: string;
    lastName: string;
    studentCode: string | null;
  };
  session: {
    id: string;
    date: string;
    title: string | null;
    startTime: string;
    endTime: string;
    skillProgram: {
      id: string;
      name: string;
    };
  };
}

interface RecentEvaluation {
  id: string;
  type: string;
  title: string;
  score: number | null;
  maxScore: number;
  date: string;
  karAmuz: {
    id: string;
    firstName: string;
    lastName: string;
    studentCode: string | null;
  };
}

interface DashboardData {
  instructor: InstructorInfo;
  stats: {
    totalPrograms: number;
    totalStudents: number;
    avgAttendance: number;
    avgGrade: number;
  };
  programs: ProgramStats[];
  recentAttendances: RecentAttendance[];
  recentEvaluations: RecentEvaluation[];
}

/* ─────────── Helper functions ─────────── */

function getStatusLabel(status: string): string {
  const map: Record<string, string> = {
    PRESENT: 'حاضر',
    ABSENT: 'غایب',
    LATE: 'تأخیر',
    EXCUSED: 'مرخصی',
  };
  return map[status] || status;
}

function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    PRESENT: 'bg-emerald-100 text-emerald-700',
    ABSENT: 'bg-red-100 text-red-700',
    LATE: 'bg-amber-100 text-amber-700',
    EXCUSED: 'bg-blue-100 text-blue-700',
  };
  return map[status] || 'bg-gray-100 text-gray-700';
}

function getTypeLabel(type: string): string {
  const map: Record<string, string> = {
    MIDTERM: 'میان‌ترم',
    FINAL: 'پایان‌ترم',
    PROJECT: 'پروژه',
    PRACTICAL: 'عملی',
  };
  return map[type] || type;
}

function getLevelLabel(level: string | null): string {
  const map: Record<string, string> = {
    BEGINNER: 'مبتدی',
    INTERMEDIATE: 'متوسط',
    ADVANCED: 'پیشرفته',
  };
  if (!level) return '';
  return map[level] || level;
}

function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr);
    return date.toLocaleDateString('fa-IR');
  } catch {
    return dateStr;
  }
}

/* ─────────── Component ─────────── */

export default function InstructorDashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchDashboard = useCallback(async () => {
    try {
      const res = await fetch('/api/instructor/dashboard');
      if (!res.ok) {
        toast.error('خطا در دریافت اطلاعات داشبورد');
        return;
      }
      const json = await res.json();
      setData(json);
    } catch {
      toast.error('خطا در اتصال به سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  /* ─────────── Loading State ─────────── */
  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <Card className="border-0 shadow-xl w-full max-w-md mx-auto">
        <CardContent className="p-6 text-center">
          <p className="text-gray-600">خطا در بارگذاری اطلاعات</p>
          <Button onClick={fetchDashboard} className="mt-4 bg-teal-600 hover:bg-teal-700">
            تلاش مجدد
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
          سلام، {data.instructor.displayName} 👋
        </h2>
        <p className="text-gray-500 mt-1 text-sm sm:text-base">به پنل مدیریت استاد خوش آمدید</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <Card className="border-0 shadow-md bg-gradient-to-br from-teal-500 to-teal-600 text-white">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between mb-2">
              <BookOpen className="h-5 w-5 sm:h-6 sm:w-6 opacity-80" />
              <span className="text-2xl sm:text-3xl font-bold">{toPersianNumber(data.stats.totalPrograms)}</span>
            </div>
            <p className="text-teal-100 text-xs sm:text-sm">برنامه مهارتی</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md bg-gradient-to-br from-violet-500 to-violet-600 text-white">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between mb-2">
              <Users className="h-5 w-5 sm:h-6 sm:w-6 opacity-80" />
              <span className="text-2xl sm:text-3xl font-bold">{toPersianNumber(data.stats.totalStudents)}</span>
            </div>
            <p className="text-violet-100 text-xs sm:text-sm">کارآموز فعال</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between mb-2">
              <ClipboardCheck className="h-5 w-5 sm:h-6 sm:w-6 opacity-80" />
              <span className="text-2xl sm:text-3xl font-bold">{toPersianNumber(data.stats.avgAttendance)}٪</span>
            </div>
            <p className="text-emerald-100 text-xs sm:text-sm">میانگین حضور</p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md bg-gradient-to-br from-amber-500 to-amber-600 text-white">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="h-5 w-5 sm:h-6 sm:w-6 opacity-80" />
              <span className="text-2xl sm:text-3xl font-bold">{toPersianNumber(data.stats.avgGrade)}</span>
            </div>
            <p className="text-amber-100 text-xs sm:text-sm">میانگین نمره از ۲۰</p>
          </CardContent>
        </Card>
      </div>

      {/* Programs Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg sm:text-xl font-bold text-gray-900 flex items-center gap-2">
            <GraduationCap className="h-5 w-5 text-teal-600" />
            برنامه‌های آموزشی من
          </h3>
          <Badge variant="secondary" className="bg-teal-100 text-teal-700">
            {toPersianNumber(data.programs.length)} برنامه
          </Badge>
        </div>

        {data.programs.length === 0 ? (
          <Card className="border-0 shadow-md">
            <CardContent className="p-8 text-center">
              <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">هنوز برنامه آموزشی به شما اختصاص داده نشده است</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {data.programs.map((program) => (
              <Link key={program.id} href={`/instructor/program/${program.id}`}>
                <Card className="border-0 shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer group hover:-translate-y-1">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-base font-bold text-gray-900 group-hover:text-teal-700 transition-colors truncate">
                          {program.name}
                        </CardTitle>
                        {program.code && (
                          <p className="text-xs text-gray-400 mt-0.5">کد: {program.code}</p>
                        )}
                      </div>
                      <ArrowLeft className="h-4 w-4 text-gray-300 group-hover:text-teal-500 transition-colors shrink-0 mr-2" />
                    </div>
                    <div className="flex gap-1.5 mt-2 flex-wrap">
                      {program.level && (
                        <Badge variant="secondary" className="text-xs bg-teal-50 text-teal-600">
                          {getLevelLabel(program.level)}
                        </Badge>
                      )}
                      <Badge variant="secondary" className="text-xs bg-violet-50 text-violet-600">
                        {toPersianNumber(program.totalHours)} ساعت
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="text-center p-2 rounded-lg bg-teal-50">
                        <p className="text-lg font-bold text-teal-700">{toPersianNumber(program.enrollmentCount)}</p>
                        <p className="text-xs text-teal-500">کارآموز</p>
                      </div>
                      <div className="text-center p-2 rounded-lg bg-emerald-50">
                        <p className="text-lg font-bold text-emerald-700">{toPersianNumber(program.avgAttendance)}٪</p>
                        <p className="text-xs text-emerald-500">حضور</p>
                      </div>
                    </div>
                    <div className="mt-3">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-500">نرخ حضور</span>
                        <span className="font-medium text-gray-700">{toPersianNumber(program.avgAttendance)}٪</span>
                      </div>
                      <Progress
                        value={program.avgAttendance}
                        className="h-1.5 bg-gray-100"
                      />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Attendances */}
        <Card className="border-0 shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-bold flex items-center gap-2">
              <UserCheck className="h-5 w-5 text-emerald-600" />
              آخرین حضور و غیاب
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.recentAttendances.length === 0 ? (
              <p className="text-gray-400 text-sm text-center py-4">رکوردی یافت نشد</p>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {data.recentAttendances.map((att) => (
                  <div key={att.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-teal-600">
                          {att.karAmuz.firstName.charAt(0)}
                        </span>
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {att.karAmuz.firstName} {att.karAmuz.lastName}
                        </p>
                        <p className="text-xs text-gray-400 truncate">
                          {att.session.skillProgram.name} • {formatDate(att.session.date)}
                        </p>
                      </div>
                    </div>
                    <Badge className={`text-xs shrink-0 ${getStatusColor(att.status)}`}>
                      {getStatusLabel(att.status)}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Evaluations */}
        <Card className="border-0 shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-bold flex items-center gap-2">
              <Award className="h-5 w-5 text-amber-600" />
              آخرین ارزیابی‌ها
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.recentEvaluations.length === 0 ? (
              <p className="text-gray-400 text-sm text-center py-4">رکوردی یافت نشد</p>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {data.recentEvaluations.map((ev) => (
                  <div key={ev.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-amber-600">
                          {ev.karAmuz.firstName.charAt(0)}
                        </span>
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">
                          {ev.karAmuz.firstName} {ev.karAmuz.lastName}
                        </p>
                        <p className="text-xs text-gray-400 truncate">
                          {getTypeLabel(ev.type)} • {formatDate(ev.date)}
                        </p>
                      </div>
                    </div>
                    <div className="text-left shrink-0">
                      {ev.score !== null ? (
                        <span className="text-sm font-bold text-gray-900">
                          {toPersianNumber(ev.score)} / {toPersianNumber(ev.maxScore)}
                        </span>
                      ) : (
                        <Badge variant="secondary" className="text-xs">بدون نمره</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}