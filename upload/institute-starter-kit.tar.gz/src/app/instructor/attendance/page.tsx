'use client';

import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ClipboardCheck,
  Calendar,
  Users,
  Save,
  CheckCircle,
  AlertCircle,
  BookOpen,
  UserCheck,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Student {
  id: string;
  firstName: string;
  lastName: string;
  studentCode: string | null;
  phone: string | null;
  enrollmentId: string;
}

interface SessionInfo {
  id: string;
  date: string;
  title: string | null;
  startTime: string;
  endTime: string;
}

interface ProgramData {
  id: string;
  name: string;
  code: string | null;
  description: string | null;
  totalHours: number;
  theoryHours: number;
  practicalHours: number;
  level: string | null;
  cluster: string | null;
  capacity: number | null;
  students: Student[];
  sessions: SessionInfo[];
}

interface AttendanceRecord {
  id: string;
  karAmuzId: string;
  status: string;
  hours: number;
  notes: string | null;
}

/* ─────────── Helpers ─────────── */

function getStatusLabel(status: string): string {
  const map: Record<string, string> = {
    NONE: 'ثبت نشده',
    PRESENT: 'حاضر',
    ABSENT: 'غایب',
    LATE: 'تأخیر',
    EXCUSED: 'مرخصی',
  };
  return map[status] || status;
}

function getStatusBadgeClass(status: string): string {
  const map: Record<string, string> = {
    NONE: 'bg-gray-100 text-gray-600',
    PRESENT: 'bg-emerald-100 text-emerald-700',
    ABSENT: 'bg-red-100 text-red-700',
    LATE: 'bg-amber-100 text-amber-700',
    EXCUSED: 'bg-blue-100 text-blue-700',
  };
  return map[status] || 'bg-gray-100 text-gray-600';
}

function formatDate(dateStr: string): string {
  try {
    const date = new Date(dateStr);
    return date.toLocaleDateString('fa-IR');
  } catch {
    return dateStr;
  }
}

function todayISO(): string {
  return new Date().toISOString().split('T')[0];
}

/* ─────────── Component ─────────── */

export default function AttendancePage() {
  const [programs, setPrograms] = useState<ProgramData[]>([]);
  const [selectedProgramId, setSelectedProgramId] = useState<string>('');
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>(todayISO());
  const [attendanceMap, setAttendanceMap] = useState<Record<string, string>>({});
  const [existingAttendance, setExistingAttendance] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const selectedProgram = programs.find((p) => p.id === selectedProgramId);

  // Fetch programs
  const fetchPrograms = useCallback(async () => {
    try {
      const res = await fetch('/api/instructor/programs');
      if (!res.ok) {
        toast.error('خطا در دریافت لیست برنامه‌ها');
        return;
      }
      const json = await res.json();
      setPrograms(json.programs || []);
    } catch {
      toast.error('خطا در اتصال به سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPrograms();
  }, [fetchPrograms]);

  // Filter sessions by selected date for the selected program
  const filteredSessions = selectedProgram?.sessions.filter(
    (s) => s.date === selectedDate
  ) || [];

  // When session changes, fetch existing attendance
  useEffect(() => {
    if (!selectedSessionId) {
      setExistingAttendance([]);
      setAttendanceMap({});
      return;
    }

    const fetchAttendance = async () => {
      try {
        const res = await fetch(`/api/instructor/attendance?sessionId=${selectedSessionId}`);
        if (res.ok) {
          const json = await res.json();
          const records: AttendanceRecord[] = json.attendances || [];
          setExistingAttendance(records);

          // Pre-fill attendance map
          const map: Record<string, string> = {};
          records.forEach((r) => {
            map[r.karAmuzId] = r.status;
          });
          setAttendanceMap(map);
        }
      } catch {
        // Ignore
      }
    };

    fetchAttendance();
  }, [selectedSessionId]);

  // Reset session when program or date changes
  useEffect(() => {
    setSelectedSessionId('');
    setAttendanceMap({});
    setExistingAttendance([]);
  }, [selectedProgramId, selectedDate]);

  const handleStatusChange = (studentId: string, status: string) => {
    setAttendanceMap((prev) => ({ ...prev, [studentId]: status }));
  };

  const handleMarkAllPresent = () => {
    if (!selectedProgram) return;
    const map: Record<string, string> = {};
    selectedProgram.students.forEach((s) => {
      map[s.id] = 'PRESENT';
    });
    setAttendanceMap(map);
    toast.success('همه کارآموزان به عنوان «حاضر» علامت‌گذاری شدند');
  };

  const handleSubmit = async () => {
    if (!selectedSessionId) {
      toast.error('لطفاً ابتدا یک جلسه را انتخاب کنید');
      return;
    }

    if (selectedProgram && Object.keys(attendanceMap).length === 0) {
      toast.error('لطفاً وضعیت حداقل یک کارآموز را مشخص کنید');
      return;
    }

    setSaving(true);
    try {
      const records = Object.entries(attendanceMap).map(([karAmuzId, status]) => ({
        karAmuzId,
        status,
      }));

      const res = await fetch('/api/instructor/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: selectedSessionId, records }),
      });

      if (!res.ok) {
        const err = await res.json();
        toast.error(err.error || 'خطا در ثبت حضور و غیاب');
        return;
      }

      toast.success('حضور و غیاب با موفقیت ثبت شد');
    } catch {
      toast.error('خطا در اتصال به سرور');
    } finally {
      setSaving(false);
    }
  };

  /* ─────────── Loading State ─────────── */
  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="h-10 w-full max-w-md" />
        <Skeleton className="h-10 w-full max-w-md" />
        <Skeleton className="h-10 w-full max-w-md" />
        <div className="rounded-xl border p-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-12 w-full mb-2" />
          ))}
        </div>
      </div>
    );
  }

  /* ─────────── Render ─────────── */
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center">
            <ClipboardCheck className="h-5 w-5 text-teal-700" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">حضور و غیاب</h1>
            <p className="text-sm text-gray-500">ثبت و مدیریت حضور و غیاب کارآموزان</p>
          </div>
        </div>
      </div>

      {/* Filters Card */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-bold flex items-center gap-2">
            <Calendar className="h-4 w-4 text-teal-600" />
            انتخاب برنامه و جلسه
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Program Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">برنامه مهارتی</label>
              <Select value={selectedProgramId} onValueChange={setSelectedProgramId}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="انتخاب برنامه..." />
                </SelectTrigger>
                <SelectContent>
                  {programs.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} {p.code ? `(${p.code})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date Picker */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">تاریخ کلاس</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-white file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
            </div>

            {/* Session Selector */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">جلسه</label>
              <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
                <SelectTrigger className="w-full" disabled={!selectedProgramId}>
                  <SelectValue placeholder={
                    selectedProgramId
                      ? (filteredSessions.length > 0 ? 'انتخاب جلسه...' : 'جلسه‌ای برای این تاریخ یافت نشد')
                      : 'ابتدا برنامه را انتخاب کنید'
                  } />
                </SelectTrigger>
                <SelectContent>
                  {filteredSessions.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.title || `جلسه ${formatDate(s.date)}`}
                      {' '}({s.startTime} - {s.endTime})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Attendance Table */}
      {selectedProgram && selectedProgram.students.length > 0 && (
        <Card className="border-0 shadow-md">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <CardTitle className="text-base font-bold flex items-center gap-2">
                <Users className="h-4 w-4 text-teal-600" />
                {selectedProgram.name}
                <Badge variant="secondary" className="bg-teal-50 text-teal-700 mr-2">
                  {toPersianNumber(selectedProgram.students.length)} کارآموز
                </Badge>
              </CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={handleMarkAllPresent}
                className="border-teal-200 text-teal-700 hover:bg-teal-50 gap-1.5"
              >
                <UserCheck className="h-4 w-4" />
                علامت‌گذاری همه حاضر
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="text-right font-bold text-gray-700 w-12">ردیف</TableHead>
                    <TableHead className="text-right font-bold text-gray-700">نام و نام خانوادگی</TableHead>
                    <TableHead className="text-right font-bold text-gray-700 hidden sm:table-cell">کد دانشجویی</TableHead>
                    <TableHead className="text-right font-bold text-gray-700 w-44">وضعیت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedProgram.students.map((student, index) => {
                    const currentStatus = attendanceMap[student.id] || 'NONE';
                    return (
                      <TableRow key={student.id} className="hover:bg-gray-50 transition-colors">
                        <TableCell className="font-medium text-gray-500">
                          {toPersianNumber(index + 1)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center shrink-0">
                              <span className="text-xs font-bold text-teal-700">
                                {student.firstName.charAt(0)}
                              </span>
                            </div>
                            <span className="font-medium text-gray-900">
                              {student.firstName} {student.lastName}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden sm:table-cell text-gray-500 text-sm">
                          {student.studentCode ? toPersianNumber(student.studentCode) : '—'}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Select
                              value={currentStatus}
                              onValueChange={(val) => handleStatusChange(student.id, val)}
                            >
                              <SelectTrigger className="w-36">
                                <SelectValue>
                                  <Badge className={`${getStatusBadgeClass(currentStatus)} border-0 text-xs`}>
                                    {getStatusLabel(currentStatus)}
                                  </Badge>
                                </SelectValue>
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="PRESENT">
                                  <div className="flex items-center gap-2">
                                    <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
                                    حاضر
                                  </div>
                                </SelectItem>
                                <SelectItem value="LATE">
                                  <div className="flex items-center gap-2">
                                    <AlertCircle className="h-3.5 w-3.5 text-amber-600" />
                                    تأخیر
                                  </div>
                                </SelectItem>
                                <SelectItem value="ABSENT">
                                  <div className="flex items-center gap-2">
                                    <AlertCircle className="h-3.5 w-3.5 text-red-600" />
                                    غایب
                                  </div>
                                </SelectItem>
                                <SelectItem value="EXCUSED">
                                  <div className="flex items-center gap-2">
                                    <AlertCircle className="h-3.5 w-3.5 text-blue-600" />
                                    مرخصی
                                  </div>
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* Submit Button */}
            {selectedSessionId && (
              <div className="mt-4 flex justify-end">
                <Button
                  onClick={handleSubmit}
                  disabled={saving || Object.keys(attendanceMap).length === 0}
                  className="bg-teal-600 hover:bg-teal-700 text-white gap-2 min-w-40"
                >
                  {saving ? (
                    <>
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      در حال ثبت...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4" />
                      ثبت حضور و غیاب
                    </>
                  )}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Empty States */}
      {!loading && programs.length === 0 && (
        <Card className="border-0 shadow-md">
          <CardContent className="p-8 text-center">
            <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">هنوز برنامه آموزشی به شما اختصاص داده نشده است</p>
          </CardContent>
        </Card>
      )}

      {selectedProgram && selectedProgram.students.length === 0 && (
        <Card className="border-0 shadow-md">
          <CardContent className="p-8 text-center">
            <Users className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">هنوز کارآموزی در این برنامه ثبت‌نام نکرده است</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}