'use client';

import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Award,
  Users,
  Save,
  BookOpen,
  TrendingUp,
  CheckCircle,
  XCircle,
  Clock,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Student {
  id: string;
  firstName: string;
  lastName: string;
  studentCode: string | null;
  phone: string | null;
  enrollmentId: string;
}

interface ProgramData {
  id: string;
  name: string;
  code: string | null;
  description: string | null;
  totalHours: number;
  theoryHours: number;
  practicalHours: number;
  level: string | null;
  cluster: string | null;
  capacity: number | null;
  students: Student[];
  sessions: { id: string; date: string; title: string | null; startTime: string; endTime: string }[];
}

interface GradeRow {
  karAmuzId: string;
  score: string;
  status: string;
}

/* ─────────── Helpers ─────────── */

function getStatusLabel(status: string): string {
  const map: Record<string, string> = {
    PENDING: 'در انتظار',
    PASS: 'قبول',
    FAIL: 'مردود',
  };
  return map[status] || status;
}

function getStatusBadgeClass(status: string): string {
  const map: Record<string, string> = {
    PENDING: 'bg-gray-100 text-gray-600',
    PASS: 'bg-emerald-100 text-emerald-700',
    FAIL: 'bg-red-100 text-red-700',
  };
  return map[status] || 'bg-gray-100 text-gray-600';
}

/* ─────────── Component ─────────── */

export default function GradesPage() {
  const [programs, setPrograms] = useState<ProgramData[]>([]);
  const [selectedProgramId, setSelectedProgramId] = useState<string>('');
  const [evaluationType, setEvaluationType] = useState<string>('FINAL');
  const [grades, setGrades] = useState<Record<string, GradeRow>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const selectedProgram = programs.find((p) => p.id === selectedProgramId);

  // Fetch programs
  const fetchPrograms = useCallback(async () => {
    try {
      const res = await fetch('/api/instructor/programs');
      if (!res.ok) {
        toast.error('خطا در دریافت لیست برنامه‌ها');
        return;
      }
      const json = await res.json();
      setPrograms(json.programs || []);
    } catch {
      toast.error('خطا در اتصال به سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPrograms();
  }, [fetchPrograms]);

  // Initialize grades when program changes
  useEffect(() => {
    if (selectedProgram) {
      const initial: Record<string, GradeRow> = {};
      selectedProgram.students.forEach((s) => {
        initial[s.id] = { karAmuzId: s.id, score: '', status: 'PENDING' };
      });
      setGrades(initial);
    } else {
      setGrades({});
    }
  }, [selectedProgramId]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleScoreChange = (studentId: string, value: string) => {
    // Only allow numbers and empty string
    const cleaned = value.replace(/[^0-9.]/g, '');
    setGrades((prev) => ({
      ...prev,
      [studentId]: { ...prev[studentId], score: cleaned },
    }));

    // Auto-determine status based on score
    if (cleaned !== '') {
      const numScore = parseFloat(cleaned);
      if (!isNaN(numScore)) {
        const status = numScore >= 10 ? 'PASS' : 'FAIL';
        setGrades((prev) => ({
          ...prev,
          [studentId]: { ...prev[studentId], status },
        }));
      }
    }
  };

  const handleStatusChange = (studentId: string, status: string) => {
    setGrades((prev) => ({
      ...prev,
      [studentId]: { ...prev[studentId], status },
    }));
  };

  const handleSubmit = async () => {
    if (!selectedProgramId) {
      toast.error('لطفاً ابتدا یک برنامه مهارتی را انتخاب کنید');
      return;
    }

    // Validate all scores
    const evaluations = Object.values(grades).map((g) => ({
      karAmuzId: g.karAmuzId,
      score: g.score !== '' ? parseFloat(g.score) : null,
      status: g.status,
    }));

    // Validate score range
    for (const ev of evaluations) {
      if (ev.score !== null && (ev.score < 0 || ev.score > 20)) {
        toast.error('نمره باید بین ۰ تا ۲۰ باشد');
        return;
      }
    }

    setSaving(true);
    try {
      const res = await fetch('/api/instructor/evaluations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          skillProgramId: selectedProgramId,
          type: evaluationType,
          evaluations,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        toast.error(err.error || 'خطا در ثبت نمرات');
        return;
      }

      toast.success('نمرات با موفقیت ثبت شدند');
    } catch {
      toast.error('خطا در اتصال به سرور');
    } finally {
      setSaving(false);
    }
  };

  // Stats
  const totalStudents = selectedProgram?.students.length || 0;
  const filledCount = Object.values(grades).filter((g) => g.score !== '').length;
  const passCount = Object.values(grades).filter((g) => g.status === 'PASS').length;
  const failCount = Object.values(grades).filter((g) => g.status === 'FAIL').length;

  /* ─────────── Loading State ─────────── */
  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="h-10 w-full max-w-md" />
        <Skeleton className="h-10 w-full max-w-md" />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
        </div>
        <div className="rounded-xl border p-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-12 w-full mb-2" />
          ))}
        </div>
      </div>
    );
  }

  /* ─────────── Render ─────────── */
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center">
            <Award className="h-5 w-5 text-amber-700" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">نمرات و ارزیابی</h1>
            <p className="text-sm text-gray-500">ثبت و مدیریت نمرات کارآموزان</p>
          </div>
        </div>
      </div>

      {/* Filters Card */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="text-base font-bold flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-teal-600" />
            انتخاب برنامه و نوع ارزیابی
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">برنامه مهارتی</label>
              <Select value={selectedProgramId} onValueChange={setSelectedProgramId}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="انتخاب برنامه..." />
                </SelectTrigger>
                <SelectContent>
                  {programs.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} {p.code ? `(${p.code})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">نوع ارزیابی</label>
              <Select value={evaluationType} onValueChange={setEvaluationType}>
                <SelectTrigger className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="FINAL">پایان‌ترم</SelectItem>
                  <SelectItem value="MIDTERM">میان‌ترم</SelectItem>
                  <SelectItem value="PROJECT">پروژه</SelectItem>
                  <SelectItem value="PRACTICAL">عملی</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      {selectedProgram && totalStudents > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="border-0 shadow-md bg-gradient-to-br from-teal-500 to-teal-600 text-white">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-teal-100 text-xs">نمره‌دهی شده</p>
                <p className="text-2xl font-bold">{toPersianNumber(filledCount)} / {toPersianNumber(totalStudents)}</p>
              </div>
              <CheckCircle className="h-8 w-8 opacity-60" />
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md bg-gradient-to-br from-emerald-500 to-emerald-600 text-white">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-emerald-100 text-xs">قبول</p>
                <p className="text-2xl font-bold">{toPersianNumber(passCount)}</p>
              </div>
              <CheckCircle className="h-8 w-8 opacity-60" />
            </CardContent>
          </Card>

          <Card className="border-0 shadow-md bg-gradient-to-br from-red-500 to-red-600 text-white">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-red-100 text-xs">مردود</p>
                <p className="text-2xl font-bold">{toPersianNumber(failCount)}</p>
              </div>
              <XCircle className="h-8 w-8 opacity-60" />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Grades Table */}
      {selectedProgram && totalStudents > 0 && (
        <Card className="border-0 shadow-md">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <CardTitle className="text-base font-bold flex items-center gap-2">
                <Users className="h-4 w-4 text-teal-600" />
                {selectedProgram.name}
                <Badge variant="secondary" className="bg-teal-50 text-teal-700 mr-2">
                  {toPersianNumber(totalStudents)} کارآموز
                </Badge>
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50">
                    <TableHead className="text-right font-bold text-gray-700 w-12">ردیف</TableHead>
                    <TableHead className="text-right font-bold text-gray-700">نام و نام خانوادگی</TableHead>
                    <TableHead className="text-right font-bold text-gray-700 hidden sm:table-cell">کد دانشجویی</TableHead>
                    <TableHead className="text-right font-bold text-gray-700 w-36">نمره (از ۲۰)</TableHead>
                    <TableHead className="text-right font-bold text-gray-700 w-40">وضعیت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedProgram.students.map((student, index) => {
                    const grade = grades[student.id];
                    if (!grade) return null;
                    return (
                      <TableRow key={student.id} className="hover:bg-gray-50 transition-colors">
                        <TableCell className="font-medium text-gray-500">
                          {toPersianNumber(index + 1)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
                              <span className="text-xs font-bold text-amber-700">
                                {student.firstName.charAt(0)}
                              </span>
                            </div>
                            <span className="font-medium text-gray-900">
                              {student.firstName} {student.lastName}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden sm:table-cell text-gray-500 text-sm">
                          {student.studentCode ? toPersianNumber(student.studentCode) : '—'}
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min="0"
                            max="20"
                            step="0.5"
                            placeholder="—"
                            value={grade.score}
                            onChange={(e) => handleScoreChange(student.id, e.target.value)}
                            className="w-28 text-center"
                            dir="ltr"
                          />
                        </TableCell>
                        <TableCell>
                          <Select
                            value={grade.status}
                            onValueChange={(val) => handleStatusChange(student.id, val)}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue>
                                <Badge className={`${getStatusBadgeClass(grade.status)} border-0 text-xs gap-1`}>
                                  {grade.status === 'PASS' && <CheckCircle className="h-3 w-3" />}
                                  {grade.status === 'FAIL' && <XCircle className="h-3 w-3" />}
                                  {grade.status === 'PENDING' && <Clock className="h-3 w-3" />}
                                  {getStatusLabel(grade.status)}
                                </Badge>
                              </SelectValue>
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="PENDING">در انتظار</SelectItem>
                              <SelectItem value="PASS">قبول</SelectItem>
                              <SelectItem value="FAIL">مردود</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* Submit Button */}
            <div className="mt-4 flex justify-end">
              <Button
                onClick={handleSubmit}
                disabled={saving || Object.keys(grades).length === 0}
                className="bg-teal-600 hover:bg-teal-700 text-white gap-2 min-w-40"
              >
                {saving ? (
                  <>
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    در حال ثبت...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    ثبت همه نمرات
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty States */}
      {!loading && programs.length === 0 && (
        <Card className="border-0 shadow-md">
          <CardContent className="p-8 text-center">
            <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">هنوز برنامه آموزشی به شما اختصاص داده نشده است</p>
          </CardContent>
        </Card>
      )}

      {selectedProgram && totalStudents === 0 && (
        <Card className="border-0 shadow-md">
          <CardContent className="p-8 text-center">
            <Users className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">هنوز کارآموزی در این برنامه ثبت‌نام نکرده است</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}