import { Suspense } from 'react';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import CoursesClient from './CoursesClient';
import { siteConfig } from '@/config/site';

export default function CoursesPage() {
  // BreadcrumbList schema for /courses page
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'خانه',
        item: siteConfig.url.base,
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'دوره‌های آموزشی',
        item: `${siteConfig.url.base}/courses`,
      },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <div className="min-h-screen flex flex-col bg-gray-50">
      <main className="flex-1">
        {/* Hero */}
        <div className="bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#0f766e] py-12 sm:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              دایرکتوری دوره‌های آموزشی
            </h1>
            <p className="text-white/80 max-w-2xl mx-auto leading-relaxed">
              از سواد دیجیتال پایه تا اتوماسیون هوشمند. مسیر شغلی خود را در ۳ خوشه و ۸ گروه آموزشی پیدا کنید.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
          {/* Client-side interactive component with filtering */}
          <Suspense fallback={
            <div className="text-center py-16">
              <div className="w-12 h-12 border-4 border-[#0d9488] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-[#64748b]">در حال بارگذاری دوره‌ها...</p>
            </div>
          }>
            <CoursesClient />
          </Suspense>
        </div>
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
    </>
  );
}