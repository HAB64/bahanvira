import { Metadata } from 'next'
import { GROUPS, OCCUPATIONS } from '@/lib/skill-graph'
import { getCoursesByCluster } from '@/data/courses'
import { siteConfig } from '@/config/site'
import ClusterPageClient from './ClusterPageClient'

interface Props {
  params: Promise<{ clusterId: string }>
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { clusterId } = await params
  const group = GROUPS[clusterId as keyof typeof GROUPS]
  if (!group) return { title: 'خوشه یافت نشد' }

  return {
    title: `${group.label} — ${siteConfig.name.fullName}`,
    description: group.description,
  }
}

export function generateStaticParams() {
  return Object.keys(GROUPS).map(clusterId => ({ clusterId }))
}

export default async function ClusterPage({ params }: Props) {
  const { clusterId } = await params
  const group = GROUPS[clusterId as keyof typeof GROUPS]

  if (!group) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">خوشه آموزشی یافت نشد</h1>
          <a href="/courses" className="text-teal-600 hover:underline">بازگشت به دوره‌ها</a>
        </div>
      </div>
    )
  }

  const clusterCourses = getCoursesByCluster(clusterId as any)
  const occupations = OCCUPATIONS.filter(o => o.groupKey === clusterId)

  return <ClusterPageClient group={group} courses={clusterCourses} occupations={occupations} clusterId={clusterId} />
}
