'use client'

import { useState, useEffect, type FormEvent } from 'react'
import Link from 'next/link'
import {
  ArrowLeft, CheckCircle2, Clock, Award, Users,
  Phone, Send, Loader2, AlertCircle, Briefcase, GraduationCap,
  Sparkles, Zap, BookOpen, Star, ArrowRight,
} from 'lucide-react'
import { siteConfig } from '@/config/site'
import { useUTM } from '@/hooks/use-utm'

interface Course {
  slug: string; title: string; subtitle: string; level: string;
  duration: string; sessions: number; price?: string; priceNote?: string;
  certificate: string; prerequisites: string[]; learningOutcomes: string[];
  highlights: string[]; targetAudience: string;
}

interface Occupation {
  title: string; description: string; salary?: string; demand?: string;
}

interface Group {
  key: string; label: string; description: string; color: string; icon: string;
}

interface Props {
  group: Group
  courses: Course[]
  occupations: Occupation[]
  clusterId: string
}

export default function ClusterPageClient({ group, courses, occupations, clusterId }: Props) {
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const utm = useUTM()

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !/^09[0-9]{9}$/.test(phone)) {
      setError('نام و شماره معتبر الزامی است')
      return
    }
    setLoading(true)
    try {
      const res = await fetch('/api/crm/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(), phone, cluster: clusterId,
          source: `cluster-page-${clusterId}`,
          utmSource: utm.utmSource, utmMedium: utm.utmMedium, utmCampaign: utm.utmCampaign,
        }),
      })
      if (res.ok) {
        setSuccess(true)
        fetch('/api/events', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'CLUSTER_LEAD',
            category: 'conversion',
            label: clusterId,
            metadata: { source: 'cluster-page' },
          }),
        }).catch(() => {})
      }
      else setError('خطا در ثبت درخواست')
    } catch { setError('خطا در ارتباط') }
    finally { setLoading(false) }
  }

  // Sort courses by level
  const levelOrder: Record<string, number> = { 'FOUNDATION': 0, 'BEGINNER': 0, 'SPECIALIZED': 1, 'INTERMEDIATE': 1, 'STRATEGIC': 2, 'ADVANCED': 2, 'EXPERT': 3 }
  const sortedCourses = [...courses].sort((a, b) => (levelOrder[a.level] ?? 1) - (levelOrder[b.level] ?? 1))

  // Group courses by level
  const coursesByLevel = sortedCourses.reduce<Record<string, Course[]>>((acc, course) => {
    const level = course.level || 'OTHER'
    if (!acc[level]) acc[level] = []
    acc[level].push(course)
    return acc
  }, {})

  const levelConfig: Record<string, { label: string; description: string; icon: React.ElementType }> = {
    'BEGINNER': { label: 'مبانی', description: 'نقطه شروع — بدون پیش‌نیاز', icon: BookOpen },
    'FOUNDATION': { label: 'مبانی', description: 'نقطه شروع — بدون پیش‌نیاز', icon: BookOpen },
    'INTERMEDIATE': { label: 'تخصصی', description: 'مهارت‌های کلیدی حرفه‌ای', icon: Zap },
    'SPECIALIZED': { label: 'تخصصی', description: 'مهارت‌های کلیدی حرفه‌ای', icon: Zap },
    'ADVANCED': { label: 'پیشرفته', description: 'مهارت‌های سطح بالا', icon: Sparkles },
    'STRATEGIC': { label: 'پیشرفته', description: 'مهارت‌های سطح بالا', icon: Sparkles },
    'EXPERT': { label: 'حرفه‌ای', description: 'تخصص کامل', icon: Award },
  }

  const color = group.color

  return (
    <div className="min-h-screen" style={{ background: '#0a1628' }} dir="rtl">
      {/* ===== Hero ===== */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0d1f3c] to-[#0a1628]" />
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: `linear-gradient(${color}40 1px, transparent 1px), linear-gradient(90deg, ${color}40 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
          }}
        />
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full blur-[120px]" style={{ backgroundColor: color + '10' }} />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <Link href="/courses" className="inline-flex items-center gap-1 text-sm text-gray-400 hover:text-gray-200 mb-4 transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" /> تمام دوره‌ها
          </Link>
          <h1 className="text-3xl sm:text-4xl font-black text-white mb-3">{group.label}</h1>
          <p className="text-lg text-gray-300 max-w-2xl mb-6">{group.description}</p>
          <div className="flex flex-wrap gap-4 text-sm text-gray-400">
            <span className="flex items-center gap-1.5"><GraduationCap className="w-4 h-4" style={{ color }} />{courses.length} دوره</span>
            <span className="flex items-center gap-1.5"><Briefcase className="w-4 h-4" style={{ color }} />{occupations.length} مسیر شغلی</span>
            <span className="flex items-center gap-1.5"><Award className="w-4 h-4" style={{ color }} />مدرک فنی و حرفه‌ای</span>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* ===== Learning Path ===== */}
          <div className="flex-1">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Sparkles className="w-5 h-5" style={{ color }} />
              مسیر یادگیری {group.label}
            </h2>
            <div className="space-y-8">
              {Object.entries(coursesByLevel).map(([level, levelCourses]) => {
                const info = levelConfig[level] || { label: level, description: '', icon: BookOpen }
                const Icon = info.icon
                return (
                  <div key={level}>
                    {/* Level header */}
                    <div className="flex items-center gap-2 mb-4 pb-2 border-b border-white/10">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: color + '15' }}>
                        <Icon className="w-4 h-4" style={{ color }} />
                      </div>
                      <div>
                        <h3 className="font-bold text-white text-sm">{info.label}</h3>
                        <p className="text-xs text-gray-500">{info.description}</p>
                      </div>
                      <span className="text-xs text-gray-500 mr-auto">{levelCourses.length} دوره</span>
                    </div>

                    {/* Course cards */}
                    <div className="space-y-3">
                      {levelCourses.map((course) => (
                        <Link
                          key={course.slug}
                          href={`/courses/${course.slug}`}
                          className="block glass-card-lite rounded-xl p-5 hover:border-white/25 transition-colors group"
                        >
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <h3 className="font-bold text-white group-hover:text-teal-300 transition-colors mb-1">{course.title}</h3>
                              <p className="text-sm text-gray-400 mb-3">{course.subtitle}</p>
                              <div className="flex flex-wrap gap-3 text-xs text-gray-500">
                                <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{course.duration}</span>
                                <span className="flex items-center gap-1"><Award className="w-3 h-3" />{course.certificate}</span>
                                {course.sessions > 0 && (
                                  <span className="flex items-center gap-1"><Users className="w-3 h-3" />{course.sessions} جلسه</span>
                                )}
                              </div>
                              {course.learningOutcomes.length > 0 && (
                                <div className="mt-3 flex flex-wrap gap-1.5">
                                  {course.learningOutcomes.slice(0, 4).map((outcome, i) => (
                                    <span key={i} className="inline-flex items-center gap-0.5 text-[11px] bg-white/5 text-gray-400 rounded-full px-2 py-0.5 border border-white/10">
                                      <CheckCircle2 className="w-2.5 h-2.5" style={{ color }} />
                                      {outcome}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </div>
                            <div className="text-left shrink-0">
                              {course.price && (
                                <span className="text-sm font-bold" style={{ color }}>{course.price}</span>
                              )}
                              <div className="text-xs text-gray-500 mt-1">{course.priceNote}</div>
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* ===== Sidebar ===== */}
          <div className="w-full lg:w-[360px] shrink-0 space-y-6">
            {/* Lead Form */}
            <div className="glass-card rounded-2xl p-6 sticky top-24">
              <h3 className="font-bold text-white mb-1">مشاوره رایگان {group.label}</h3>
              <p className="text-xs text-gray-400 mb-4">نام و شماره بگذارید، تماس می‌گیریم</p>
              {success ? (
                <div className="text-center py-4">
                  <CheckCircle2 className="w-10 h-10 text-teal-400 mx-auto mb-2" />
                  <p className="font-bold text-white">ثبت شد!</p>
                  <p className="text-sm text-gray-400">مشاوران ما تماس خواهند گرفت</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-3">
                  <input type="text" value={name} onChange={e => setName(e.target.value)}
                    placeholder="نام و نام خانوادگی" disabled={loading}
                    className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500/50" />
                  <input type="tel" value={phone} onChange={e => { const v = e.target.value.replace(/[^0-9]/g, ''); if (v.length <= 11) setPhone(v); }}
                    placeholder="09123456789" dir="ltr" disabled={loading}
                    className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-4 py-3 text-sm text-white text-left placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500/50" />
                  {error && <p className="text-red-400 text-xs flex items-center gap-1"><AlertCircle className="w-3 h-3" />{error}</p>}
                  <button type="submit" disabled={loading}
                    className="w-full text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 text-sm transition-all"
                    style={{ backgroundColor: color }}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Send className="w-4 h-4" /> دریافت مشاوره رایگان</>}
                  </button>
                </form>
              )}
            </div>

            {/* Career paths */}
            {occupations.length > 0 && (
              <div className="glass-card rounded-2xl p-6">
                <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                  <Briefcase className="w-4 h-4" style={{ color }} />
                  مسیرهای شغلی
                </h3>
                <div className="space-y-3">
                  {occupations.slice(0, 5).map((occ, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-white text-xs font-bold" style={{ backgroundColor: color }}>
                        {i + 1}
                      </div>
                      <div>
                        <p className="font-medium text-white text-sm">{occ.title}</p>
                        <p className="text-xs text-gray-400 mt-0.5">{occ.description}</p>
                        {occ.salary && <p className="text-xs mt-0.5" style={{ color }}>{occ.salary}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Trust */}
            <div className="glass-card-lite rounded-xl p-4 flex items-center gap-2 text-xs text-gray-400">
              <CheckCircle2 className="w-4 h-4 text-teal-500 shrink-0" />
              <span>مجوز رسمی فنی و حرفه‌ای + مدرک بین‌المللی ICDL</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
