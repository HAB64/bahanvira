import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { courses, getCourseBySlug, competencyClusters } from '@/data/courses';
import CourseDetailClient from './CourseDetailClient';
import { siteConfig } from '@/config/site';

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const course = getCourseBySlug(slug);

  if (!course) {
    return {
      title: 'دوره یافت نشد',
    };
  }

  return {
    title: `${course.title} | ${siteConfig.name.fullName}`,
    description: course.subtitle,
    keywords: [
      course.title,
      `آموزش ${course.clusterLabel}`,
      siteConfig.name.fa,
      siteConfig.institute.typeFa,
      siteConfig.location.city,
      siteConfig.location.province,
      'CBT',
      course.level,
    ],
    openGraph: {
      title: course.title,
      description: course.subtitle,
      url: `${siteConfig.url.base}/courses/${course.slug}`,
      siteName: siteConfig.name.fullName,
      type: 'website',
      locale: 'fa_IR',
      images: [
        {
          url: `${siteConfig.url.base}${siteConfig.assets.ogImage}`,
          width: 1200,
          height: 630,
          alt: course.title,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title: course.title,
      description: course.subtitle,
    },
    alternates: {
      canonical: `${siteConfig.url.base}/courses/${course.slug}`,
    },
  };
}

export async function generateStaticParams() {
  return courses.map((course) => ({
    slug: course.slug,
  }));
}

export default async function CoursePage({ params }: Props) {
  const { slug } = await params;
  const course = getCourseBySlug(slug);

  if (!course) {
    notFound();
  }

  const cluster = competencyClusters.find((c) => c.id === course.cluster);

  // JSON-LD schema for this specific course
  const courseSchema = {
    '@context': 'https://schema.org',
    '@type': 'Course',
    name: course.title,
    description: course.description,
    url: `${siteConfig.url.base}/courses/${course.slug}`,
    provider: {
      '@type': 'Organization',
      name: siteConfig.name.fullName,
      url: siteConfig.url.base,
    },
    coursePrerequisites: course.prerequisites?.join(', ') || 'بدون پیش‌نیاز',
    educationalLevel: course.level === 'پایه' ? 'Beginner' : course.level === 'متوسط' ? 'Intermediate' : 'Advanced',
    inLanguage: 'fa-IR',
    ...(course.price && {
      offers: {
        '@type': 'Offer',
        price: course.price.replace(/[^0-9]/g, ''),
        priceCurrency: 'IRR',
        availability: 'https://schema.org/InStock',
        category: course.clusterLabel,
      },
    }),
    hasCourseInstance: {
      '@type': 'CourseInstance',
      courseMode: 'onsite',
      location: {
        '@type': 'Place',
        name: siteConfig.name.fa,
        address: {
          '@type': 'PostalAddress',
          addressLocality: siteConfig.location.city,
          addressRegion: siteConfig.location.province,
          addressCountry: 'IR',
        },
      },
    },
  };

  const breadcrumbPageSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'خانه',
        item: siteConfig.url.base,
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'دوره‌ها',
        item: `${siteConfig.url.base}/courses`,
      },
      {
        '@type': 'ListItem',
        position: 3,
        name: course.clusterLabel,
        item: `${siteConfig.url.base}/courses?cluster=${course.cluster}`,
      },
      {
        '@type': 'ListItem',
        position: 4,
        name: course.title,
        item: `${siteConfig.url.base}/courses/${course.slug}`,
      },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(courseSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbPageSchema) }}
      />
      <CourseDetailClient course={course} cluster={cluster} />
    </>
  );
}
