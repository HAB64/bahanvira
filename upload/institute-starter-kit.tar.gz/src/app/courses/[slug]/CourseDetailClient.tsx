'use client';

import Link from 'next/link';
import {
  ArrowLeft, Clock, BookOpen, Users, Star, CheckCircle2,
  Play, Award, ChevronDown, ChevronUp, Phone, MessageCircle,
  Shield, FileText, Target, Cpu, TrendingUp, Briefcase, Palette,
  CreditCard, BadgeCheck, Headphones, CalendarDays, PhoneCall
} from 'lucide-react';
import { useState } from 'react';
import { Course, competencyClusters } from '@/data/courses';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { siteConfig } from '@/config/site';

function ModuleAccordion({ module, index, courseColor }: { module: any; index: number; courseColor: string }) {
  const [open, setOpen] = useState(index === 0);
  const typeLabel: Record<string, string> = { theory: 'تئوری', practical: 'عملی', project: 'پروژه' };
  const typeColor: Record<string, string> = { theory: 'bg-blue-100 text-blue-700', practical: 'bg-green-100 text-green-700', project: 'bg-amber-100 text-amber-700' };

  return (
    <div className="border border-gray-100 rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold flex-shrink-0"
            style={{ backgroundColor: courseColor }}
          >
            {index + 1}
          </div>
          <div className="text-right">
            <span className="font-medium text-[#0f172a] text-sm">{module.title}</span>
            <div className="flex items-center gap-2 mt-0.5">
              <span className={`text-[10px] px-2 py-0.5 rounded-full ${typeColor[module.type]}`}>
                {typeLabel[module.type]}
              </span>
              <span className="text-[10px] text-[#64748b]">{module.duration}</span>
            </div>
          </div>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-[#64748b]" /> : <ChevronDown className="w-4 h-4 text-[#64748b]" />}
      </button>
      {open && (
        <div className="px-4 pb-4 pr-15">
          <ul className="space-y-2">
            {module.lessons.map((lesson: string, i: number) => (
              <li key={i} className="flex items-center gap-2 text-sm text-[#475569]">
                <Play className="w-3 h-3 flex-shrink-0" style={{ color: courseColor }} />
                {lesson}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

interface CourseDetailClientProps {
  course: Course;
  cluster: typeof competencyClusters[number] | undefined;
}

export default function CourseDetailClient({ course, cluster }: CourseDetailClientProps) {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <main className="flex-1">
        {/* Hero */}
        <div className="relative" style={{ backgroundColor: course.color }}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-sm text-white/70 mb-6">
              <Link href="/" className="hover:text-white transition-colors">خانه</Link>
              <span>/</span>
              <Link href="/courses" className="hover:text-white transition-colors">دوره‌ها</Link>
              <span>/</span>
              <Link href={`/courses?cluster=${course.cluster}`} className="hover:text-white transition-colors">{course.clusterLabel}</Link>
              <span>/</span>
              <span className="text-white">{course.title}</span>
            </div>

            <div className="grid lg:grid-cols-3 gap-8 items-start">
              {/* Title Area */}
              <div className="lg:col-span-2">
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-xs font-medium px-3 py-1 rounded-full bg-white/20 text-white">
                    {course.clusterLabel}
                  </span>
                  <span className="text-xs font-medium px-3 py-1 rounded-full bg-white/20 text-white">
                    سطح {course.level}
                  </span>
                </div>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-3">
                  {course.title}
                </h1>
                <p className="text-white/80 leading-relaxed max-w-2xl">
                  {course.subtitle}
                </p>
              </div>

              {/* Quick Info Card */}
              <div className="bg-white rounded-2xl p-6 shadow-xl">
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3 text-sm">
                    <Clock className="w-4 h-4 text-[#64748b]" />
                    <span className="text-[#334155]">مدت دوره: {course.duration}</span>
                  </div>
                  {course.sessions > 0 && (
                    <div className="flex items-center gap-3 text-sm">
                      <BookOpen className="w-4 h-4 text-[#64748b]" />
                      <span className="text-[#334155]">تعداد جلسات: {course.sessions}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-3 text-sm">
                    <Award className="w-4 h-4 text-[#64748b]" />
                    <span className="text-[#334155]">مدرک: {course.certificate}</span>
                  </div>
                </div>
                <Link
                  href="/consulting"
                  className="block w-full text-center bg-[#0d9488] text-white font-bold py-3 rounded-xl hover:bg-[#0f766e] transition-colors mb-3"
                >
                  ثبت‌نام و رزرو صندلی
                </Link>
                <a
                  href={siteConfig.contact.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full text-center bg-[#25D366] text-white font-bold py-3 rounded-xl hover:bg-[#20ba5c] transition-colors flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  مشاوره در واتساپ
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <div className="grid lg:grid-cols-3 gap-10">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-10">
              {/* Video Placeholder */}
              <div
                className="rounded-2xl overflow-hidden aspect-video flex items-center justify-center"
                style={{ backgroundColor: course.colorLight }}
              >
                <div className="text-center">
                  <div
                    className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
                    style={{ backgroundColor: course.color + '20' }}
                  >
                    <Play className="w-10 h-10" style={{ color: course.color }} />
                  </div>
                  <p className="text-sm font-medium" style={{ color: course.colorDark }}>
                    ویدیوی معرفی دوره
                  </p>
                  <p className="text-xs mt-1" style={{ color: course.colorDark + '80' }}>
                    برای مشاهده ویدیو ثبت‌نام کنید
                  </p>
                </div>
              </div>

              {/* Description */}
              <div>
                <h2 className="text-xl font-bold text-[#0f172a] mb-4">درباره دوره</h2>
                <p className="text-[#475569] leading-relaxed">{course.description}</p>
              </div>

              {/* Highlights */}
              <div>
                <h2 className="text-xl font-bold text-[#0f172a] mb-4">ویژگی‌های دوره</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  {course.highlights.map((h, i) => (
                    <div key={i} className="flex items-start gap-3 bg-gray-50 rounded-xl p-4">
                      <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: course.color }} />
                      <span className="text-sm text-[#334155]">{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Syllabus */}
              <div>
                <h2 className="text-xl font-bold text-[#0f172a] mb-4">سرفصل‌های دوره</h2>
                <div className="space-y-3">
                  {course.modules.map((mod, i) => (
                    <ModuleAccordion key={i} module={mod} index={i} courseColor={course.color} />
                  ))}
                </div>
              </div>

              {/* Learning Outcomes */}
              <div>
                <h2 className="text-xl font-bold text-[#0f172a] mb-4">خروجی‌های یادگیری</h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  {course.learningOutcomes.map((outcome, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <Target className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: course.color }} />
                      <span className="text-sm text-[#334155]">{outcome}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Target Audience */}
              <div>
                <h2 className="text-xl font-bold text-[#0f172a] mb-4">مخاطبان دوره</h2>
                <p className="text-[#475569] leading-relaxed">{course.targetAudience}</p>
              </div>

              {/* Prerequisites */}
              {course.prerequisites && course.prerequisites.length > 0 && (
                <div>
                  <h2 className="text-xl font-bold text-[#0f172a] mb-4">پیش‌نیازها</h2>
                  <div className="space-y-2">
                    {course.prerequisites.map((pr, i) => (
                      <div key={i} className="flex items-center gap-3 text-sm text-[#475569]">
                        <Shield className="w-4 h-4 text-[#0d9488]" />
                        {pr}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Learning Path / Next Step */}
              <div>
                <h2 className="text-xl font-bold text-[#0f172a] mb-4">مسیر پیشرفت</h2>
                <div className="bg-gray-50 rounded-2xl p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium px-3 py-1 rounded-full" style={{ backgroundColor: course.colorLight, color: course.colorDark }}>
                        سطح {course.level}
                      </span>
                      <span className="text-[#64748b] text-sm">جایی که هستید</span>
                    </div>
                    <div className="flex-1 h-0.5 bg-gray-200" />
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium px-3 py-1 rounded-full bg-[#0d9488]/10 text-[#0d9488]">
                        سطح بعدی
                      </span>
                      <span className="text-[#64748b] text-sm">
                        {course.level === 'پایه' ? 'متوسط' : course.level === 'متوسط' ? 'پیشرفته' : 'متخصص / مشاوره'}
                      </span>
                    </div>
                  </div>
                  <p className="text-sm text-[#475569] leading-relaxed">
                    {course.level === 'پایه' 
                      ? 'پس از گذراندن این دوره پایه، شما آماده ورود به دوره‌های سطح متوسط خواهید بود. مسیر پیشرفت شما از اینجا شروع می‌شود.'
                      : course.level === 'متوسط'
                      ? 'با تسلط بر مهارت‌های این دوره، می‌توانید به دوره‌های سطح پیشرفته بروید و تخصص خود را عمیق‌تر کنید.'
                      : 'شما در بالاترین سطح آموزشی هستید. اکنون می‌توانید به عنوان مشاور یا متخصص فعالیت کنید.'
                    }
                  </p>
                  <Link
                    href="/consulting"
                    className="inline-flex items-center gap-2 mt-4 text-sm font-medium text-[#0d9488] hover:text-[#0f766e] transition-colors"
                  >
                    مشاوره رایگان مسیر شغلی
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>

              {/* Reviews */}
              {course.reviews.length > 0 && (
                <div>
                  <h2 className="text-xl font-bold text-[#0f172a] mb-4">نظرات کارآموزان</h2>
                  <div className="space-y-4">
                    {course.reviews.map((review, i) => (
                      <div key={i} className="bg-gray-50 rounded-2xl p-5">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div
                              className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                              style={{ backgroundColor: course.color }}
                            >
                              {review.name.charAt(0)}
                            </div>
                            <div>
                              <p className="font-medium text-sm text-[#0f172a]">{review.name}</p>
                              <p className="text-xs text-[#64748b]">{review.role}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            {[...Array(5)].map((_, j) => (
                              <Star
                                key={j}
                                className={`w-3.5 h-3.5 ${
                                  j < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-sm text-[#475569] leading-relaxed">{review.text}</p>
                        <p className="text-xs text-[#94a3b8] mt-2">{review.date}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Sticky Card */}
              <div className="sticky top-24 space-y-6">
                {/* Pricing Card */}
                <div className="bg-white rounded-2xl border-2 border-[#0d9488]/20 p-6 shadow-sm">
                  <div className="flex items-center gap-3 mb-4">
                    <CreditCard className="w-6 h-6 text-[#0d9488]" />
                    <h3 className="font-bold text-[#0f172a]">شهریه دوره</h3>
                  </div>

                  {course.price ? (
                    <>
                      <div className="bg-gradient-to-l from-[#0d9488]/10 to-[#0d9488]/5 rounded-xl p-4 mb-4">
                        <div className="text-2xl font-bold text-[#0d9488]">{course.price}</div>
                        {course.priceNote && (
                          <p className="text-xs text-[#64748b] mt-1">{course.priceNote}</p>
                        )}
                      </div>
                      <div className="bg-amber-50 rounded-xl p-3 mb-4 flex items-center gap-2">
                        <CalendarDays className="w-4 h-4 text-amber-600 flex-shrink-0" />
                        <span className="text-xs text-amber-700">قسط‌بندی ۲ تا ۳ ماهه بدون چک و بدون بهره</span>
                      </div>
                    </>
                  ) : (
                    <div className="bg-gray-50 rounded-xl p-4 mb-4 text-center">
                      <p className="text-sm text-[#475569] mb-2">برای اطلاع از شهریه تماس بگیرید</p>
                      <a
                        href={siteConfig.contact.phoneHref}
                        className="inline-flex items-center gap-2 text-sm font-bold text-[#0d9488]"
                      >
                        <PhoneCall className="w-4 h-4" />
                        <span dir="ltr">{siteConfig.contact.phone}</span>
                      </a>
                    </div>
                  )}

                  {/* What's Included */}
                  <div className="space-y-2.5 mb-5">
                    <div className="flex items-center gap-2.5 text-sm">
                      <BadgeCheck className="w-4 h-4 text-[#0d9488] flex-shrink-0" />
                      <span className="text-[#334155]">مدرک معتبر فنی و حرفه‌ای</span>
                    </div>
                    <div className="flex items-center gap-2.5 text-sm">
                      <BookOpen className="w-4 h-4 text-[#0d9488] flex-shrink-0" />
                      <span className="text-[#334155]">جزوه و مواد آموزشی</span>
                    </div>
                    <div className="flex items-center gap-2.5 text-sm">
                      <Headphones className="w-4 h-4 text-[#0d9488] flex-shrink-0" />
                      <span className="text-[#334155]">پشتیبانی تا زمان اخذ مدرک</span>
                    </div>
                    <div className="flex items-center gap-2.5 text-sm">
                      <CalendarDays className="w-4 h-4 text-[#0d9488] flex-shrink-0" />
                      <span className="text-[#334155]">قسط‌بندی بدون چک و بدون بهره</span>
                    </div>
                  </div>

                  <Link
                    href="/consulting"
                    className="block w-full text-center bg-[#0d9488] text-white font-bold py-3.5 rounded-xl hover:bg-[#0f766e] transition-colors text-sm"
                  >
                    ثبت‌نام و رزرو صندلی
                  </Link>
                  <a
                    href={siteConfig.contact.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full text-center mt-2 border border-[#25D366] text-[#25D366] font-bold py-3 rounded-xl hover:bg-[#25D366]/5 transition-colors text-sm flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    مشاوره رایگان قبل از ثبت‌نام
                  </a>
                </div>

                {/* Certificate */}
                <div className="bg-white rounded-2xl border border-gray-100 p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <Award className="w-6 h-6" style={{ color: course.color }} />
                    <h3 className="font-bold text-[#0f172a]">گواهینامه</h3>
                  </div>
                  <p className="text-sm text-[#475569] leading-relaxed">{course.certificate}</p>
                </div>

                {/* Cluster Info */}
                {cluster && (
                  <div className="rounded-2xl border border-gray-100 p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: cluster.colorLight }}>
                        {(() => { const Icon = { Cpu, TrendingUp, Briefcase, Palette }[cluster.icon] || Cpu; return <Icon className="w-4 h-4" style={{ color: cluster.color }} />; })()}
                      </div>
                      <h3 className="font-bold text-[#0f172a]">{cluster.title}</h3>
                    </div>
                    <p className="text-sm text-[#475569] leading-relaxed mb-3">{cluster.description}</p>
                    <Link
                      href={`/courses?cluster=${cluster.id}`}
                      className="text-sm font-medium flex items-center gap-1"
                      style={{ color: course.color }}
                    >
                      سایر دوره‌های این خوشه
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                )}

                {/* Contact */}
                <div className="bg-gray-50 rounded-2xl p-6">
                  <h3 className="font-bold text-[#0f172a] mb-4">سوالی دارید؟</h3>
                  <div className="space-y-3">
                    <a
                      href={siteConfig.contact.phoneHref}
                      className="flex items-center gap-3 text-sm text-[#475569] hover:text-[#0d9488] transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      <span dir="ltr">{siteConfig.contact.phone}</span>
                    </a>
                    <a
                      href={siteConfig.contact.whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 text-sm text-[#475569] hover:text-[#25D366] transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      پیام در واتساپ
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
