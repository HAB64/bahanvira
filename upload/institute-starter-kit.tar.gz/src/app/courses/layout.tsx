import { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: `دوره‌های آموزشی فنی و حرفه‌ای در ${siteConfig.location.city} | ثبت‌نام`,
  description: `ثبت‌نام دوره‌های فنی و حرفه‌ای در ${siteConfig.name.fullName} ${siteConfig.location.city}. ICDL، برنامه‌نویسی پایتون، فارکس، حسابداری، طراحی دوخت و هوش مصنوعی. مدرک معتبر.`,
  keywords: [
    'دوره فنی و حرفه‌ای',
    `ثبت‌نام دوره ${siteConfig.location.city}`,
    `آموزشگاه ${siteConfig.institute.typeFa} ${siteConfig.location.city}`,
    'ICDL',
    'پایتون',
    'فارکس',
    siteConfig.name.fa,
  ],
  alternates: {
    canonical: `${siteConfig.url.base}/courses`,
  },
  openGraph: {
    title: `دوره‌های فنی و حرفه‌ای | ${siteConfig.name.fa}`,
    description: `ثبت‌نام دوره‌های مهارتی با مدرک معتبر`,
    locale: 'fa_IR',
    url: `${siteConfig.url.base}/courses`,
  },
};

export default function CoursesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
