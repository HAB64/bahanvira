'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Cpu, TrendingUp, Briefcase, Palette, ArrowLeft, Clock, Filter, Star, BookOpen, Monitor, Gamepad2, Code2, Brain, BarChart3, Zap, Calculator, Lightbulb, Rocket, Ruler, Box, Scissors, Wrench, GraduationCap, PenTool, CandlestickChart, Scale } from 'lucide-react';
import { courses, competencyClusters, Course } from '@/data/courses';

const iconMap: Record<string, React.ElementType> = {
  Cpu,
  TrendingUp,
  Briefcase,
  Palette,
  Brain,
  Calculator,
  Rocket,
  PenTool,
  CandlestickChart,
  GraduationCap,
  Scale,
};

const courseIconMap: Record<string, React.ElementType> = {
  Monitor, Gamepad2, Code2, Brain, BarChart3, Zap, Calculator, Lightbulb, Rocket, Ruler, Box, Scissors,
};

const levelColors: Record<string, string> = {
  'پایه': 'bg-green-100 text-green-700',
  'متوسط': 'bg-blue-100 text-blue-700',
  'پیشرفته': 'bg-purple-100 text-purple-700',
};

type BloomLevel = Course['bloomLevel'] | 'ALL';

const bloomConfig: Record<BloomLevel, { label: string; description: string; icon: React.ElementType; color: string; colorLight: string; colorDark: string }> = {
  ALL: {
    label: 'همه دوره‌ها',
    description: '',
    icon: Filter,
    color: '#0d9488',
    colorLight: '#ccfbf1',
    colorDark: '#0f766e',
  },
  FOUNDATION: {
    label: 'پایه و مهارتی',
    description: 'مهارت‌های پایه ورود به بازار کار',
    icon: BookOpen,
    color: '#0d9488',
    colorLight: '#ccfbf1',
    colorDark: '#0f766e',
  },
  SPECIALIZED: {
    label: 'تخصصی',
    description: 'تخصص عمیق و حرفه‌ای',
    icon: Wrench,
    color: '#d97706',
    colorLight: '#fef3c7',
    colorDark: '#92400e',
  },
  STRATEGIC: {
    label: 'استراتژیک و کارآفرینی',
    description: 'کارآفرینی و رهبری کسب‌وکار',
    icon: GraduationCap,
    color: '#7c3aed',
    colorLight: '#ede9fe',
    colorDark: '#5b21b6',
  },
};

const bloomBadgeColors: Record<string, string> = {
  FOUNDATION: 'bg-teal-100 text-teal-700',
  SPECIALIZED: 'bg-amber-100 text-amber-700',
  STRATEGIC: 'bg-purple-100 text-purple-700',
};

export default function CoursesClient() {
  const searchParams = useSearchParams();
  const clusterParam = searchParams.get('cluster');
  const [manualCluster, setManualCluster] = useState<string>('all');
  const [bloomFilter, setBloomFilter] = useState<BloomLevel>('ALL');

  // SSR grid is hidden via CSS in page.tsx — no JS needed here

  const activeCluster = clusterParam || manualCluster;
  const setActiveCluster = setManualCluster;

  // Filter by cluster first, then by bloom level
  const clusterFiltered = activeCluster === 'all'
    ? courses
    : courses.filter((c) => c.cluster === activeCluster);

  const filteredCourses = bloomFilter === 'ALL'
    ? clusterFiltered
    : clusterFiltered.filter((c) => c.bloomLevel === bloomFilter);

  const sortedCourses = [...filteredCourses].sort((a, b) => a.levelOrder - b.levelOrder);

  return (
    <>
      {/* Bloom's Taxonomy Filter */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3">
          <GraduationCap className="w-5 h-5 text-[#0d9488]" />
          <h2 className="font-bold text-[#0f172a]">سطح آموزشی (فرم مالیخان)</h2>
        </div>
        <div className="flex flex-wrap gap-3">
          {(Object.keys(bloomConfig) as BloomLevel[]).map((level) => {
            const config = bloomConfig[level];
            const Icon = config.icon;
            const count = level === 'ALL'
              ? clusterFiltered.length
              : clusterFiltered.filter((c) => c.bloomLevel === level).length;
            const isActive = bloomFilter === level;

            return (
              <button
                key={level}
                onClick={() => setBloomFilter(level)}
                className={`px-5 py-3 rounded-xl text-sm font-medium transition-all flex items-center gap-2 ${
                  isActive
                    ? 'text-white shadow-lg scale-[1.02]'
                    : 'bg-white text-[#334155] hover:bg-gray-50 border border-gray-200'
                }`}
                style={isActive ? { backgroundColor: config.color } : {}}
              >
                <Icon className="w-4 h-4" />
                <div className="text-right">
                  <div>{config.label} ({count})</div>
                  {config.description && !isActive && (
                    <div className="text-[10px] text-[#94a3b8] mt-0.5">{config.description}</div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
        {bloomFilter !== 'ALL' && (
          <div
            className="mt-3 rounded-xl p-4 border"
            style={{
              backgroundColor: bloomConfig[bloomFilter].colorLight,
              borderColor: bloomConfig[bloomFilter].color + '30',
            }}
          >
            <div className="flex items-center gap-2">
              {(() => { const BIcon = bloomConfig[bloomFilter].icon; return <BIcon className="w-4 h-4" style={{ color: bloomConfig[bloomFilter].colorDark }} />; })()}
              <span className="text-sm font-medium" style={{ color: bloomConfig[bloomFilter].colorDark }}>
                {bloomConfig[bloomFilter].label}: {bloomConfig[bloomFilter].description}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Cluster Filter */}
      <div className="flex flex-wrap gap-3 mb-8">
        <button
          onClick={() => setActiveCluster('all')}
          className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
            activeCluster === 'all'
              ? 'bg-[#0d9488] text-white shadow-md'
              : 'bg-white text-[#334155] hover:bg-gray-50 border border-gray-200'
          }`}
        >
          <Filter className="w-4 h-4 inline ml-1" />
          همه خوشه‌ها ({bloomFilter === 'ALL' ? courses.length : courses.filter((c) => c.bloomLevel === bloomFilter).length})
        </button>
        {competencyClusters.map((cluster) => {
          const Icon = iconMap[cluster.icon] || Cpu;
          const count = bloomFilter === 'ALL'
            ? courses.filter((c) => c.cluster === cluster.id).length
            : courses.filter((c) => c.cluster === cluster.id && c.bloomLevel === bloomFilter).length;
          return (
            <button
              key={cluster.id}
              onClick={() => setActiveCluster(cluster.id)}
              className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all flex items-center gap-2 ${
                activeCluster === cluster.id
                  ? 'text-white shadow-md'
                  : 'bg-white text-[#334155] hover:bg-gray-50 border border-gray-200'
              }`}
              style={activeCluster === cluster.id ? { backgroundColor: cluster.color } : {}}
            >
              <Icon className="w-4 h-4" />
              {cluster.shortTitle} ({count})
            </button>
          );
        })}
      </div>

      {/* Active Cluster Description */}
      {activeCluster !== 'all' && (
        <div
          className="rounded-2xl p-6 mb-8 border"
          style={{
            backgroundColor: competencyClusters.find((c) => c.id === activeCluster)?.colorLight,
            borderColor: competencyClusters.find((c) => c.id === activeCluster)?.color + '30',
          }}
        >
          <p className="text-sm leading-relaxed" style={{ color: competencyClusters.find((c) => c.id === activeCluster)?.colorDark }}>
            {competencyClusters.find((c) => c.id === activeCluster)?.description}
          </p>
        </div>
      )}

      {/* Course Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedCourses.map((course) => (
          <Link
            key={course.slug}
            href={`/courses/${course.slug}`}
            className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
          >
            {/* Top Color Bar */}
            <div className="h-2" style={{ backgroundColor: course.color }} />

            <div className="p-5">
              {/* Course Icon */}
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ backgroundColor: course.colorLight }}>
                {(() => { const Icon = courseIconMap[course.icon] || Monitor; return <Icon className="w-5 h-5" style={{ color: course.color }} />; })()}
              </div>

              {/* Badges */}
              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <span
                  className="text-xs font-medium px-2.5 py-1 rounded-full"
                  style={{ backgroundColor: course.colorLight, color: course.colorDark }}
                >
                  {course.clusterLabel}
                </span>
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${levelColors[course.level]}`}>
                  {course.level}
                </span>
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${bloomBadgeColors[course.bloomLevel]}`}>
                  {bloomConfig[course.bloomLevel].label}
                </span>
              </div>

              {/* Title */}
              <h3 className="font-bold text-[#0f172a] mb-2 line-clamp-2 min-h-[2.5rem]">
                {course.title}
              </h3>

              {/* Subtitle */}
              <p className="text-xs text-[#64748b] leading-relaxed mb-4 line-clamp-2">
                {course.subtitle}
              </p>

              {/* Meta */}
              <div className="flex items-center gap-3 text-xs text-[#64748b] mb-3">
                <div className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{course.duration}</span>
                </div>
                {course.sessions > 0 && (
                  <div className="flex items-center gap-1">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>{course.sessions} جلسه</span>
                  </div>
                )}
              </div>

              {/* Learning Outcomes Preview */}
              <div className="space-y-1.5 mb-4">
                {course.learningOutcomes.slice(0, 2).map((outcome, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-[#64748b]">
                    <span className="mt-0.5 w-1 h-1 rounded-full flex-shrink-0" style={{ backgroundColor: course.color }} />
                    <span>{outcome}</span>
                  </div>
                ))}
              </div>

              {/* Rating */}
              {course.reviews.length > 0 && (
                <div className="flex items-center gap-1 mb-4">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < Math.round(course.reviews.reduce((a, r) => a + r.rating, 0) / course.reviews.length)
                            ? 'text-yellow-400 fill-yellow-400'
                            : 'text-gray-200'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-[#64748b]">
                    ({course.reviews.length} نظر)
                  </span>
                </div>
              )}

              {/* Price + CTA */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div>
                  {course.price && (
                    <div className="text-sm font-bold text-[#0d9488]">{course.price}</div>
                  )}
                </div>
                <div
                  className="flex items-center gap-1 text-sm font-medium group-hover:gap-2 transition-all"
                  style={{ color: course.color }}
                >
                  جزئیات
                  <ArrowLeft className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Empty State */}
      {sortedCourses.length === 0 && (
        <div className="text-center py-16">
          <p className="text-[#64748b]">دوره‌ای با این ترکیب فیلتر یافت نشد.</p>
          <button
            onClick={() => { setBloomFilter('ALL'); setManualCluster('all'); }}
            className="mt-4 text-sm font-medium text-[#0d9488] hover:text-[#0f766e] transition-colors"
          >
            پاک کردن فیلترها
          </button>
        </div>
      )}
    </>
  );
}
