import { Metadata } from 'next';
import RegisterPageClient from './RegisterPageClient';
import Footer from '@/components/Footer';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: `ثبت‌نام آنلاین | ${siteConfig.name.fa}`,
  description: `ثبت‌نام آنلاین در دوره‌های آموزشی ${siteConfig.name.fa} — ICDL، Python، Scratch و مشاوره کسب‌وکار`,
};

export default function RegisterPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-1">
        <RegisterPageClient />
      </main>
      <Footer />
    </div>
  );
}
