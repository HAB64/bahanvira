'use client';

import { useState, useCallback } from 'react';
import { CreditCard, CheckCircle, Shield, ArrowLeft, UserPlus, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Link from 'next/link';
import { useGTM } from '@/hooks/useGTM';
import { submitLead } from '@/app/actions/leadActions';
import type { InterestedCategory } from '@/types/lead';

const courses = [
  { id: 'icdl', name: 'ICDL', description: 'مهارت‌های کاربردی کامپیوتر' },
  { id: 'scratch', name: 'Scratch', description: 'برنامه‌نویسی بصری برای کودکان' },
  { id: 'python', name: 'Python', description: 'برنامه‌نویسی پایتون' },
  { id: 'consulting', name: 'مشاوره کسب‌وکار', description: 'مشاوره تخصصی رایگان' },
  { id: 'forex', name: 'بازار سرمایه', description: 'فارکس و بازارهای مالی' },
  { id: 'graphic', name: 'گرافیک و طراحی', description: 'فتوشاپ، ایلاستریتور' },
  { id: 'autocad', name: 'AutoCAD', description: 'نقشه‌کشی معماری' },
  { id: 'tailoring', name: 'طراحی دوخت', description: 'الگو و خیاطی' },
  { id: 'accounting', name: 'حسابداری', description: 'امور مالی و حسابداری' },
  { id: 'ai', name: 'هوش مصنوعی', description: 'AI و علوم داده' },
];

const benefits = [
  { text: 'پرداخت امن با درگاه بانکی', icon: Shield },
  { text: 'امکان پرداخت قسطی', icon: CheckCircle },
  { text: 'صدور فاکتور رسمی', icon: CheckCircle },
  { text: 'گواهینامه معتبر پس از اتمام دوره', icon: CheckCircle },
  { text: 'پشتیبانی آنلاین', icon: CheckCircle },
  { text: 'دسترسی به محتوای دوره', icon: CheckCircle },
];

export default function RegisterPageClient() {
  const [selectedCourse, setSelectedCourse] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    mobile: '',
  });
  const [loading, setLoading] = useState(false);
  const [serverError, setServerError] = useState('');
  const { trackFormSubmission } = useGTM();

  const courseToCategory: Record<string, InterestedCategory> = {
    icdl: 'IT',
    scratch: 'IT',
    python: 'AI',
    consulting: 'IT',
    forex: 'Finance',
    graphic: 'GraphicDesign',
    autocad: 'Architecture',
    tailoring: 'IT',
    accounting: 'Finance',
    ai: 'AI',
  };

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setServerError('');
    setLoading(true);

    // ── Server Action: score + webhook ──────────────────────
    const result = await submitLead({
      name: formData.fullName,
      mobile: formData.mobile,
      source: 'website_form',
      interestedCategory: courseToCategory[selectedCourse] || 'IT',
      courseSlug: selectedCourse || undefined,
      pageUrl: typeof window !== 'undefined' ? window.location.href : undefined,
    });

    // ── GTM: track form submission ──────────────────────────
    trackFormSubmission({
      formType: 'registration',
      formLocation: '/register',
      interestedCategory: courseToCategory[selectedCourse] || 'IT',
      source: 'website_form',
    });

    if (result.success) {
      setSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setServerError(result.message);
    }
    setLoading(false);
  }, [formData, selectedCourse, trackFormSubmission]);

  if (submitted) {
    return (
      <section className="py-16 sm:py-24 bg-gradient-to-br from-[#0d9488] via-[#0f766e] to-[#115e59] min-h-screen">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="bg-white rounded-3xl p-10 sm:p-14 shadow-2xl">
            <div className="w-20 h-20 rounded-full bg-[#ccfbf1] flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-[#0d9488]" />
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-[#0f172a] mb-4">
              درخواست ثبت‌نام شما دریافت شد!
            </h2>
            <p className="text-[#64748b] text-base mb-3 leading-relaxed">
              به زودی تیم پشتیبانی با شماره <span dir="ltr" className="font-bold text-[#0d9488]">{formData.mobile}</span> تماس خواهیم گرفت تا مراحل ثبت‌نام و پرداخت را تکمیل کنید.
            </p>
            <p className="text-[#94a3b8] text-sm mb-8">
              دوره انتخاب‌شده: <span className="font-bold text-[#0f172a]">{courses.find(c => c.id === selectedCourse)?.name || '—'}</span>
            </p>
            {serverError && (
              <p className="text-red-500 text-sm mb-4">{serverError}</p>
            )}
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                onClick={() => {
                  setSubmitted(false);
                  setFormData({ fullName: '', mobile: '' });
                  setSelectedCourse('');
                }}
                className="bg-[#0d9488] hover:bg-[#0f766e] text-white px-8"
              >
                <UserPlus className="w-4 h-4 ml-2" />
                ثبت‌نام دوره دیگر
              </Button>
              <Link href="/">
                <Button variant="outline" className="border-gray-200 px-8">
                  <ArrowLeft className="w-4 h-4 ml-2" />
                  بازگشت به صفحه اصلی
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 sm:py-20 bg-gradient-to-br from-[#0d9488] via-[#0f766e] to-[#115e59] relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="regGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#regGrid)" />
        </svg>
      </div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Title */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-full px-5 py-2 mb-5 border border-white/20">
            <CreditCard className="w-5 h-5 text-white/90" />
            <span className="text-base text-white/90 font-bold">ثبت‌نام و پرداخت</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white mb-4">ثبت‌نام آنلاین</h1>
          <p className="text-white/80 text-lg max-w-2xl mx-auto leading-relaxed">
            همین الان ثبت‌نام کنید و مسیر یادگیری خود را آغاز کنید
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Benefits Sidebar */}
          <div className="lg:col-span-2 space-y-3">
            <h3 className="text-white font-bold text-lg mb-4">مزایای ثبت‌نام آنلاین</h3>
            {benefits.map((benefit) => (
              <div key={benefit.text} className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                <benefit.icon className="w-5 h-5 text-[#5eead4] flex-shrink-0" />
                <span className="text-sm text-white font-medium">{benefit.text}</span>
              </div>
            ))}

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-5 border border-white/20 mt-6">
              <div className="flex items-center gap-2 mb-3">
                <Shield className="w-5 h-5 text-[#5eead4]" />
                <span className="text-sm font-bold text-white">پرداخت امن</span>
              </div>
              <p className="text-xs text-white/70 leading-relaxed">
                پرداخت از طریق درگاه بانکی زرین‌پال با رمزنگاری SSL انجام می‌شود. اطلاعات مالی شما کاملاً محرمانه خواهد بود.
              </p>
            </div>
          </div>

          {/* Registration Form */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-2xl">
              <form onSubmit={handleSubmit} className="space-y-5">
                <h3 className="text-xl font-black text-[#0f172a] mb-1">فرم ثبت‌نام</h3>
                <p className="text-sm text-[#94a3b8] -mt-2 mb-2">اطلاعات خود را وارد کنید</p>

                <div>
                  <label className="block text-sm font-bold text-[#334155] mb-1.5">نام و نام خانوادگی</label>
                  <Input
                    required
                    placeholder="نام خود را وارد کنید"
                    className="h-12 bg-gray-50 border-gray-200 focus:border-[#0d9488] focus:ring-[#0d9488]/20 text-base"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-[#334155] mb-1.5">شماره موبایل</label>
                  <Input
                    required
                    placeholder="۰۹۱۲XXXXXXX"
                    dir="ltr"
                    className="h-12 bg-gray-50 border-gray-200 focus:border-[#0d9488] focus:ring-[#0d9488]/20 text-right text-base"
                    value={formData.mobile}
                    onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold text-[#334155] mb-2">دوره مورد نظر</label>
                  <div className="grid grid-cols-2 gap-2">
                    {courses.map((course) => (
                      <button
                        key={course.id}
                        type="button"
                        onClick={() => setSelectedCourse(course.id)}
                        className={`p-3 rounded-xl text-right transition-all duration-200 border ${
                          selectedCourse === course.id
                            ? 'bg-[#ccfbf1] border-[#0d9488] shadow-md shadow-[#0d9488]/10'
                            : 'bg-gray-50 border-gray-200 hover:border-[#0d9488]/50'
                        }`}
                      >
                        <p className={`text-sm font-bold ${selectedCourse === course.id ? 'text-[#0d9488]' : 'text-[#0f172a]'}`}>
                          {course.name}
                        </p>
                        <p className="text-[11px] text-[#94a3b8] mt-0.5">{course.description}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  disabled={loading}
                  className="w-full bg-[#0d9488] hover:bg-[#0f766e] text-white shadow-lg shadow-[#0d9488]/20 h-13 text-base font-bold mt-4"
                >
                  {loading ? (
                    <><Loader2 className="w-5 h-5 ml-2 animate-spin" /> در حال ثبت...</>
                  ) : (
                    <><CreditCard className="w-5 h-5 ml-2" />ثبت‌نام و پرداخت</>
                  )}
                </Button>

                <p className="text-xs text-[#94a3b8] text-center">
                  با کلیک روی دکمه بالا، به درگاه پرداخت امن هدایت می‌شوید
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
