/**
 * Server Action: Submit Lead
 * =============================
 * Validates form data (Zod), scores the lead, and fires a webhook
 * to the CRM. Token is NEVER exposed to the client.
 *
 * File: src/app/actions/leadActions.ts
 */

'use server';

import { leadFormSchema, isValidIranianMobile } from '@/lib/lead-scoring/schemas';
import { calculateLeadScore } from '@/lib/lead-scoring/engine';
import type {
  LeadFormData,
  LeadSubmissionResult,
  ScoringEvent,
  CRMWebhookPayload,
  LeadStatus,
} from '@/types/lead';

// ─── Environment Variables (server-only) ──────────────────────────────────────

const CRM_WEBHOOK_URL = process.env.CRM_WEBHOOK_URL;
const INSTITUTE_NAME = 'بهان رایانه';

// ─── Helper: Generate unique event ID ─────────────────────────────────────────

function generateEventId(): string {
  return `lead_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

// ─── Main Server Action ──────────────────────────────────────────────────────

/**
 * Submit a lead form.
 *   1. Validate with Zod (Iranian mobile regex)
 *   2. Score the lead on the server
 *   3. Send webhook to CRM
 *
 * @returns LeadSubmissionResult — never throws; errors are in .errors array
 */
export async function submitLead(
  rawFormData: LeadFormData,
): Promise<LeadSubmissionResult> {
  // ── Step 1: Validate ──────────────────────────────────────────────────

  const parsed = leadFormSchema.safeParse(rawFormData);

  if (!parsed.success) {
    return {
      success: false,
      score: 0,
      temperature: 'cold',
      status: 'new',
      message: 'اطلاعات وارد شده معتبر نیست. لطفاً فرم را بررسی کنید.',
      errors: parsed.error.issues.map((issue) => ({
        field: issue.path.join('.'),
        message: issue.message,
      })),
    };
  }

  const validData = parsed.data;

  // ── Step 2: Score the Lead ────────────────────────────────────────────

  const scoringEvents: ScoringEvent[] = ['form_submission'];

  // Bonus for high-value category
  if (validData.interestedCategory === 'AI') {
    scoringEvents.push('interested_category_ai');
  }

  // Penalty for invalid phone (shouldn't happen after Zod, but defensive)
  if (!isValidIranianMobile(validData.mobile)) {
    scoringEvents.push('invalid_phone_pattern');
  }

  const scoringResult = calculateLeadScore(scoringEvents);

  // ── Step 3: Build CRM Webhook Payload ──────────────────────────────────

  const payload: CRMWebhookPayload = {
    name: validData.name,
    mobile: validData.mobile,
    email: validData.email || undefined,
    lead_score: scoringResult.score,
    lead_temperature: scoringResult.temperature,
    lead_status: scoringResult.status,
    interested_category: validData.interestedCategory,
    course_slug: validData.courseSlug,
    source: validData.source,
    utm_source: validData.utm?.source,
    utm_medium: validData.utm?.medium,
    utm_campaign: validData.utm?.campaign,
    utm_term: validData.utm?.term,
    utm_content: validData.utm?.content,
    page_url: validData.pageUrl,
    scored_at: new Date().toISOString(),
    institute: INSTITUTE_NAME,
    event_id: generateEventId(),
    scoring_events: scoringResult.appliedRules,
  };

  // ── Step 4: Fire Webhook (non-blocking — don't block the user) ────────

  if (CRM_WEBHOOK_URL) {
    // Wrap in { event, data } format expected by /api/crm/webhook
    const webhookBody = {
      event: 'lead.scored',
      data: payload,
    };

    // Fire-and-forget — we don't await so the user gets a fast response
    fetch(CRM_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(webhookBody),
    }).catch((err) => {
      // Log but don't fail the user-facing response
      console.error('[Lead Webhook] Failed to send to CRM:', err);
    });
  }

  // ── Step 5: Return Success ────────────────────────────────────────────

  const statusMessages: Record<LeadStatus, string> = {
    new: 'درخواست شما ثبت شد. به زودی با شما تماس می‌گیریم.',
    contacted: 'درخواست شما ثبت شد. به زودی با شما تماس می‌گیریم.',
    qualified: 'درخواست شما ثبت شد. مشاوران ما در اسرع وقت پاسخگو هستند.',
    hot: 'درخواست فوری شما ثبت شد! مدیر آموزشگاه شخصاً پیگیری می‌کند.',
    cold: 'درخواست شما ثبت شد. در اولین فرصت با شما تماس خواهیم گرفت.',
    spam: '',
    converted: 'ثبت‌نام شما تأیید شد.',
    lost: '',
  };

  return {
    success: true,
    score: scoringResult.score,
    temperature: scoringResult.temperature,
    status: scoringResult.status,
    message: statusMessages[scoringResult.status] || 'درخواست شما با موفقیت ثبت شد.',
  };
}

// ─── Secondary: Update Score for Existing Lead ───────────────────────────────

/**
 * Called when a lead performs an additional action (e.g. clicks WhatsApp).
 * Takes the current score and adds the new event's points.
 */
export async function updateLeadScore(
  mobile: string,
  newEvent: ScoringEvent,
  currentScore: number,
  currentStatus: LeadStatus,
): Promise<LeadSubmissionResult> {
  // Re-validate mobile
  if (!isValidIranianMobile(mobile)) {
    return {
      success: false,
      score: 0,
      temperature: 'cold',
      status: 'spam',
      message: 'شماره موبایل نامعتبر است.',
      errors: [{ field: 'mobile', message: 'شماره موبایل نامعتبر است.' }],
    };
  }

  const scoringResult = calculateLeadScore([newEvent], currentScore, currentStatus);

  const payload: CRMWebhookPayload = {
    name: '',
    mobile,
    lead_score: scoringResult.score,
    lead_temperature: scoringResult.temperature,
    lead_status: scoringResult.status,
    interested_category: 'IT',
    source: 'website_form',
    scored_at: new Date().toISOString(),
    institute: INSTITUTE_NAME,
    event_id: generateEventId(),
    scoring_events: scoringResult.appliedRules,
  };

  if (CRM_WEBHOOK_URL) {
    const webhookBody = {
      event: 'lead.scored',
      data: payload,
    };
    fetch(CRM_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(webhookBody),
    }).catch((err) => {
      console.error('[Lead Webhook] Score update failed:', err);
    });
  }

  return {
    success: true,
    score: scoringResult.score,
    temperature: scoringResult.temperature,
    status: scoringResult.status,
    message: `امتیاز لید به‌روزرسانی شد: ${scoringResult.score}`,
  };
}