'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Users, TrendingUp, Award, Wallet, Gift, Share2,
  MessageCircle, LogOut, BarChart3, ChevronUp, Eye
} from 'lucide-react';

interface ReferrerData {
  id: string;
  code: string;
  firstName: string;
  lastName: string;
  tier: string;
  phone: string;
  totalReferrals: number;
  totalEnrollments: number;
  totalCommission: number;
  totalPaid: number;
  instagram?: string;
  telegram?: string;
}

interface Stats {
  thisMonthLeads: number;
  thisMonthEnrollments: number;
  lastMonthLeads: number;
  thisMonthCommission: number;
  pendingCommission: number;
  conversionRate: number;
  currentRate: number;
  nextTier: string | null;
  nextTierProgress: { current: number; target: number; percentage: number };
}

export default function ReferrerDashboard() {
  const router = useRouter();
  const [referrer, setReferrer] = useState<ReferrerData | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [loginForm, setLoginForm] = useState({ code: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [commissions, setCommissions] = useState<Array<{ id: string; amount: number; rate: number; baseAmount: number; type: string; status: string; description: string; createdAt: string }>>([]);
  const [leaderboard, setLeaderboard] = useState<Array<{ rank: number; firstName: string; lastName: string; totalEnrollments: number; totalCommission: number; tierLabel: string }>>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'commissions' | 'leaderboard' | 'share'>('overview');

  useEffect(() => {
    checkAuth();
  }, []);

  async function checkAuth() {
    try {
      const res = await fetch('/api/referrer-auth/check');
      const data = await res.json();
      if (data.authenticated && data.referrer) {
        setReferrer(data.referrer);
        await fetchDashboardData(data.referrer.id);
      }
    } catch {
      // Not authenticated
    } finally {
      setLoading(false);
    }
  }

  async function fetchDashboardData(referrerId: string) {
    try {
      // Fetch stats from dedicated referrer stats API
      const statsRes = await fetch(`/api/referrer/stats?referrerId=${referrerId}`);
      const statsData = await statsRes.json();
      if (statsData.stats) setStats(statsData.stats);
      if (statsData.referrer) setReferrer(prev => prev ? { ...prev, ...statsData.referrer } : prev);
      if (statsData.commissions) setCommissions(statsData.commissions);
    } catch {
      // Silently fail
    }

    // Fetch leaderboard
    try {
      const lbRes = await fetch('/api/crm/referrers/leaderboard');
      const lbData = await lbRes.json();
      if (lbData.leaderboard) setLeaderboard(lbData.leaderboard);
    } catch {
      // Silently fail
    }
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoginError('');
    try {
      const res = await fetch('/api/referrer-auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginForm),
      });
      const data = await res.json();
      if (data.success && data.referrer) {
        setReferrer(data.referrer);
        await fetchDashboardData(data.referrer.id);
      } else {
        setLoginError(data.error || 'خطا در ورود');
      }
    } catch {
      setLoginError('خطا در ارتباط با سرور');
    }
  }

  async function handleLogout() {
    document.cookie = 'referrer_session=; path=/; max-age=0';
    setReferrer(null);
    setStats(null);
  }

  const handleShare = (platform: string) => {
    if (!referrer) return;
    const url = `${window.location.origin}/ref?code=${referrer.code}`;
    const text = `با کد معرف من (${referrer.code}) در آموزشگاه بهان رایانه ثبت‌نام کنید و از تخفیف ویژه بهره‌مند شوید!`;
    if (platform === 'telegram') {
      window.open(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`);
    } else if (platform === 'whatsapp') {
      window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`);
    } else if (platform === 'copy') {
      navigator.clipboard.writeText(url);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50" dir="rtl">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-teal-600 border-t-transparent" />
      </div>
    );
  }

  // Login screen
  if (!referrer) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-50 to-cyan-50 p-4" dir="rtl">
        <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Award className="h-8 w-8 text-teal-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">داشبورد معرفین</h1>
            <p className="text-gray-500 mt-2 text-sm">آموزشگاه فنی و حرفه‌ای بهان رایانه</p>
          </div>

          {loginError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 text-sm text-red-600">{loginError}</div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">کد معرف</label>
              <input
                type="text"
                required
                value={loginForm.code}
                onChange={e => setLoginForm(prev => ({ ...prev, code: e.target.value.toUpperCase() }))}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none text-sm text-center tracking-widest font-mono"
                placeholder="BR-1001"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">رمز عبور</label>
              <input
                type="password"
                required
                value={loginForm.password}
                onChange={e => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none text-sm"
                placeholder="رمز عبور"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-l from-teal-600 to-teal-700 text-white font-bold rounded-xl hover:from-teal-700 hover:to-teal-800 transition-all text-sm"
            >
              ورود به داشبورد
            </button>
          </form>
        </div>
      </div>
    );
  }

  const TIER_LABELS: Record<string, string> = { BRONZE: 'برنزی', SILVER: 'نقره‌ای', GOLD: 'طلایی', PLATINUM: 'پلاتین' };
  const TIER_COLORS: Record<string, string> = { BRONZE: 'bg-amber-100 text-amber-700', SILVER: 'bg-gray-200 text-gray-700', GOLD: 'bg-yellow-100 text-yellow-700', PLATINUM: 'bg-purple-100 text-purple-700' };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <header className="bg-gradient-to-l from-teal-600 to-teal-700 text-white">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur">
              <Award className="h-5 w-5" />
            </div>
            <div>
              <h1 className="font-bold text-sm">داشبورد معرفین</h1>
              <p className="text-xs text-teal-200">{referrer.firstName} {referrer.lastName}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className={`px-3 py-1 rounded-full text-xs font-bold ${TIER_COLORS[referrer.tier] || 'bg-gray-100 text-gray-600'}`}>
              {TIER_LABELS[referrer.tier] || referrer.tier}
            </span>
            <button onClick={handleLogout} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex gap-1 py-3 overflow-x-auto">
          {[
            { key: 'overview' as const, label: 'خلاصه', icon: BarChart3 },
            { key: 'commissions' as const, label: 'کمیسیون‌ها', icon: Wallet },
            { key: 'leaderboard' as const, label: 'رتبه‌بندی', icon: TrendingUp },
            { key: 'share' as const, label: 'اشتراک‌گذاری', icon: Share2 },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.key ? 'bg-teal-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pb-8">
        {/* Overview Tab */}
        {activeTab === 'overview' && stats && (
          <div className="space-y-4">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="h-4 w-4 text-teal-600" />
                  <span className="text-xs text-gray-500">معرفی‌های این ماه</span>
                </div>
                <p className="text-2xl font-bold text-gray-900">{stats.thisMonthLeads}</p>
              </div>
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="text-xs text-gray-500">ثبت‌نام‌های موفق</span>
                </div>
                <p className="text-2xl font-bold text-gray-900">{stats.thisMonthEnrollments}</p>
              </div>
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <Wallet className="h-4 w-4 text-blue-600" />
                  <span className="text-xs text-gray-500">کمیسیون این ماه</span>
                </div>
                <p className="text-2xl font-bold text-gray-900">{stats.thisMonthCommission.toLocaleString('fa-IR')}</p>
                <p className="text-xs text-gray-400">ریال</p>
              </div>
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <Gift className="h-4 w-4 text-purple-600" />
                  <span className="text-xs text-gray-500">کمیسیون در انتظار</span>
                </div>
                <p className="text-2xl font-bold text-gray-900">{stats.pendingCommission.toLocaleString('fa-IR')}</p>
                <p className="text-xs text-gray-400">ریال</p>
              </div>
            </div>

            {/* Conversion Rate */}
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-700">نرخ تبدیل</span>
                <span className="text-lg font-bold text-teal-600">{stats.conversionRate}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-teal-600 rounded-full h-2 transition-all" style={{ width: `${Math.min(stats.conversionRate, 100)}%` }} />
              </div>
            </div>

            {/* Tier Progress */}
            {stats.nextTier && (
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">پیشرفت تا سطح {TIER_LABELS[stats.nextTier]}</span>
                  <span className="text-sm font-bold text-teal-600">{stats.nextTierProgress.percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2">
                  <div className="bg-gradient-to-l from-teal-500 to-teal-600 rounded-full h-2.5 transition-all" style={{ width: `${stats.nextTierProgress.percentage}%` }} />
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>{stats.nextTierProgress.current} ثبت‌نام</span>
                  <span>هدف: {stats.nextTierProgress.target} ثبت‌نام</span>
                </div>
              </div>
            )}

            {/* Commission Rate */}
            <div className="bg-gradient-to-l from-teal-600 to-teal-700 rounded-2xl p-5 text-white shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-teal-200 text-sm">نرخ کمیسیون فعلی شما</p>
                  <p className="text-3xl font-bold mt-1">{Math.round(stats.currentRate * 100)}%</p>
                </div>
                <ChevronUp className="h-10 w-10 text-teal-300" />
              </div>
              <p className="text-teal-200 text-xs mt-3">
                با افزایش تعداد ثبت‌نام‌ها، نرخ کمیسیون شما به‌صورت خودکار افزایش می‌یابد!
              </p>
            </div>

            {/* Quick Link */}
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <p className="text-sm font-medium text-gray-700 mb-2">لینک معرفی شما:</p>
              <div className="flex items-center gap-2">
                <code className="flex-1 bg-gray-100 px-3 py-2 rounded-lg text-xs text-gray-700 overflow-hidden" dir="ltr">
                  {typeof window !== 'undefined' ? `${window.location.origin}/ref?code=${referrer.code}` : `/ref?code=${referrer.code}`}
                </code>
                <button
                  onClick={() => handleShare('copy')}
                  className="px-3 py-2 bg-teal-600 text-white rounded-lg text-xs hover:bg-teal-700 transition-colors"
                >
                  کپی
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Commissions Tab */}
        {activeTab === 'commissions' && (
          <div className="space-y-3">
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <h3 className="font-bold text-gray-900 mb-3">سوابق کمیسیون</h3>
              {commissions.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-8">هنوز کمیسیونی ثبت نشده است</p>
              ) : (
                <div className="space-y-2">
                  {commissions.map(c => (
                    <div key={c.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                      <div>
                        <p className="text-sm font-medium text-gray-900">{c.description || c.type}</p>
                        <p className="text-xs text-gray-500">{new Date(c.createdAt).toLocaleDateString('fa-IR')}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-sm font-bold text-gray-900">{c.amount.toLocaleString('fa-IR')} <span className="text-xs text-gray-400">ریال</span></p>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          c.status === 'PENDING' ? 'bg-yellow-100 text-yellow-700' :
                          c.status === 'APPROVED' ? 'bg-blue-100 text-blue-700' :
                          c.status === 'PAID' ? 'bg-green-100 text-green-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {c.status === 'PENDING' ? 'در انتظار' : c.status === 'APPROVED' ? 'تأیید شده' : c.status === 'PAID' ? 'پرداخت شده' : 'لغو شده'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Leaderboard Tab */}
        {activeTab === 'leaderboard' && (
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="font-bold text-gray-900 mb-4">جدول رتبه‌بندی معرفین</h3>
            {leaderboard.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-8">هنوز رتبه‌بندی موجود نیست</p>
            ) : (
              <div className="space-y-2">
                {leaderboard.map(entry => (
                  <div key={entry.rank} className={`flex items-center justify-between p-3 rounded-xl ${
                    referrer && `${entry.firstName} ${entry.lastName}` === `${referrer.firstName} ${referrer.lastName}` ? 'bg-teal-50 border border-teal-200' : 'bg-gray-50'
                  }`}>
                    <div className="flex items-center gap-3">
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        entry.rank === 1 ? 'bg-yellow-400 text-yellow-900' :
                        entry.rank === 2 ? 'bg-gray-300 text-gray-700' :
                        entry.rank === 3 ? 'bg-amber-600 text-white' :
                        'bg-gray-100 text-gray-600'
                      }`}>
                        {entry.rank}
                      </span>
                      <div>
                        <p className="text-sm font-medium text-gray-900">{entry.firstName} {entry.lastName}</p>
                        <span className="text-xs text-gray-500">{entry.tierLabel}</span>
                      </div>
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-bold text-gray-900">{entry.totalEnrollments} ثبت‌نام</p>
                      <p className="text-xs text-gray-500">{entry.totalCommission.toLocaleString('fa-IR')} ریال</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Share Tab */}
        {activeTab === 'share' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-5 shadow-sm text-center">
              <div className="w-24 h-24 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Eye className="h-12 w-12 text-teal-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">لینک معرفی خود را به اشتراک بگذارید!</h3>
              <p className="text-sm text-gray-600 mb-4">
                هرکس از طریق لینک شما ثبت‌نام کند، شما کمیسیون دریافت می‌کنید
              </p>
              <div className="bg-gray-100 rounded-xl p-3 mb-4">
                <code className="text-sm text-teal-700 break-all" dir="ltr">
                  {typeof window !== 'undefined' ? `${window.location.origin}/ref?code=${referrer.code}` : `/ref?code=${referrer.code}`}
                </code>
              </div>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => handleShare('telegram')}
                  className="flex items-center gap-2 px-6 py-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors font-medium text-sm"
                >
                  <MessageCircle className="h-5 w-5" />
                  اشتراک در تلگرام
                </button>
                <button
                  onClick={() => handleShare('whatsapp')}
                  className="flex items-center gap-2 px-6 py-3 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors font-medium text-sm"
                >
                  <Share2 className="h-5 w-5" />
                  اشتراک در واتساپ
                </button>
              </div>
            </div>

            {/* Share Tips */}
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <h4 className="font-bold text-gray-900 mb-3">نکات برای موفقیت بیشتر:</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="text-teal-500 mt-0.5">•</span>
                  لینک خود را در گروه‌ها و کانال‌های مرتبط به اشتراک بگذارید
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-500 mt-0.5">•</span>
                  از دوستان و آشنایانی که به دوره‌های آموزشی علاقه دارند بخواهید از لینک شما ثبت‌نام کنند
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-500 mt-0.5">•</span>
                  هرچه تعداد ثبت‌نام‌های موفق بیشتر باشد، نرخ کمیسیون شما بالاتر می‌رود!
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-teal-500 mt-0.5">•</span>
                  QR کد خود را چاپ کرده و در اماکن عمومی نمایش دهید
                </li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
