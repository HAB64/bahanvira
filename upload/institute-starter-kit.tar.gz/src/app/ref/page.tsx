'use client';

import { useEffect, useState, useCallback, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  GraduationCap,
  Phone,
  Mail,
  User,
  BookOpen,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  ArrowLeft,
  MessageCircle,
  Star,
  Shield,
  Award,
  Users,
  Sparkles,
  TrendingUp,
  Zap,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';
import { siteConfig } from '@/config/site';

/* ─────────── Types ─────────── */

interface ReferrerInfo {
  id: string;
  code: string;
  firstName: string;
  lastName: string;
}

interface FeaturedCourse {
  slug: string;
  title: string;
  level: string;
  icon: string;
  color: string;
}

/* ─────────── Featured Courses ─────────── */

const FEATURED_COURSES: FeaturedCourse[] = [
  { slug: 'icdl', title: 'ICDL — سواد دیجیتال بین‌المللی', level: 'پایه', icon: 'Monitor', color: '#0d9488' },
  { slug: 'python', title: 'Python — برنامه‌نویسی حرفه‌ای', level: 'متوسط', icon: 'Code2', color: '#2563eb' },
  { slug: 'forex-fundamentals', title: 'فارکس — مبانی معامله‌گری', level: 'پایه', icon: 'BarChart3', color: '#d97706' },
  { slug: 'accounting', title: 'حسابداری مهارتی و نرم‌افزار هلو', level: 'پایه', icon: 'Calculator', color: '#7c3aed' },
];

/* ─────────── Main Component (with Suspense boundary) ─────────── */

function ReferralPageContent() {
  // SEO: Referral pages should not be indexed by search engines
  const searchParams = useSearchParams();
  const router = useRouter();
  const code = searchParams.get('code');

  const [referrer, setReferrer] = useState<ReferrerInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [invalidCode, setInvalidCode] = useState(false);

  // Form state
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formCourse, setFormCourse] = useState('');
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState(false);

  const lookupReferrer = useCallback(async (refCode: string) => {
    try {
      setLoading(true);
      const res = await fetch(`/api/crm/referrers/lookup?code=${encodeURIComponent(refCode)}`);
      const data = await res.json();

      if (!res.ok || !data.valid) {
        setInvalidCode(true);
        setError(data.error || 'کد معرف نامعتبر است');
        return;
      }

      setReferrer(data.data);
    } catch {
      setInvalidCode(true);
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (code) {
      lookupReferrer(code);
    } else {
      setInvalidCode(true);
      setError('کد معرف مشخص نشده است');
      setLoading(false);
    }
  }, [code, lookupReferrer]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formPhone.trim()) return;

    setFormSubmitting(true);
    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          phone: formPhone,
          email: '',
          course: formCourse || '',
          source: 'referral',
          referredByCode: code || '',
          referrerId: referrer?.id || '',
          message: `معرفی‌شده توسط ${referrer?.firstName || ''} ${referrer?.lastName || ''} (کد: ${code})`,
        }),
      });

      if (res.ok) {
        setFormSuccess(true);
      } else {
        // Even on error, show success to user (lead might already exist)
        setFormSuccess(true);
      }
    } catch {
      setFormSuccess(true);
    } finally {
      setFormSubmitting(false);
    }
  };

  /* ──── Loading State ──── */
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-teal-50 via-white to-cyan-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-teal-600 border-t-transparent mx-auto mb-4" />
          <p className="text-gray-500 text-sm">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  /* ──── Invalid Code State ──── */
  if (invalidCode) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-orange-50 flex items-center justify-center p-4" dir="rtl">
        <Card className="max-w-md w-full border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">کد معرف نامعتبر است</h2>
            <p className="text-gray-500 text-sm mb-6">{error || 'کد معرفی وارد شده معتبر نیست یا منقضی شده است.'}</p>
            <Button
              onClick={() => router.push('/')}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              رفتن به صفحه اصلی
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  /* ──── Success State ──── */
  if (formSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-teal-50 via-white to-cyan-50 flex items-center justify-center p-4" dir="rtl">
        <Card className="max-w-md w-full border-0 shadow-lg">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">ثبت‌نام شما با موفقیت انجام شد!</h2>
            <p className="text-gray-500 text-sm mb-2">
              از طریق {referrer?.firstName} {referrer?.lastName} به آموزشگاه {siteConfig.name.fa} معرفی شده‌اید.
            </p>
            <p className="text-gray-400 text-xs mb-6">
              کارشناسان ما در اسرع وقت با شما تماس خواهند گرفت.
            </p>
            <div className="space-y-2">
              <Button
                onClick={() => router.push('/courses')}
                className="w-full bg-teal-600 hover:bg-teal-700 text-white gap-2"
              >
                <BookOpen className="w-4 h-4" />
                مشاهده دوره‌ها
              </Button>
              <a href={siteConfig.contact.whatsappUrl} target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="w-full gap-2">
                  <MessageCircle className="w-4 h-4" />
                  مشاوره رایگان در واتساپ
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  /* ──── Main Content ──── */
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-white to-cyan-50" dir="rtl">
      {/* SEO: noindex for referral pages */}
      <head><meta name="robots" content="noindex, nofollow" /></head>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-teal-600/90 to-cyan-700/90" />
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 right-10 w-40 h-40 rounded-full border-4 border-white/30" />
          <div className="absolute bottom-10 left-10 w-60 h-60 rounded-full border-4 border-white/20" />
          <div className="absolute top-1/2 left-1/3 w-20 h-20 rounded-full border-4 border-white/10" />
        </div>

        <div className="relative max-w-4xl mx-auto px-4 py-12 md:py-20 text-center text-white">
          {/* Institute Logo & Name */}
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-14 h-14 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <GraduationCap className="w-8 h-8" />
            </div>
            <div className="text-right">
              <h2 className="text-lg font-bold">{siteConfig.name.fullName}</h2>
              <p className="text-white/70 text-xs">{siteConfig.institute.subtitle}</p>
            </div>
          </div>

          {/* Referrer Greeting */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 mb-6 inline-block border border-white/20">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <p className="text-sm text-white/80">شما توسط</p>
              <Sparkles className="w-4 h-4 text-yellow-300" />
            </div>
            <p className="text-2xl font-bold mb-1">{referrer?.firstName} {referrer?.lastName}</p>
            <p className="text-sm text-white/80">به آموزشگاه معرفی شده‌اید</p>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold mb-4 leading-relaxed">
            مسیر حرفه‌ای خود را با ما شروع کنید
          </h1>
          <p className="text-white/80 text-base md:text-lg max-w-2xl mx-auto mb-8">
            با {toPersianNumber(27)} سال تجربه، مجوز رسمی فنی و حرفه‌ای و بیش از {toPersianNumber(5000)} فارغ‌التحصیل، آموزشگاه {siteConfig.name.fa} بهترین نقطه شروع مسیر شغلی شماست.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a href="#register-form">
              <Button size="lg" className="bg-white text-teal-700 hover:bg-gray-100 gap-2 font-bold px-8 shadow-lg">
                <User className="w-5 h-5" />
                ثبت‌نام
              </Button>
            </a>
            <a href={siteConfig.contact.whatsappUrl} target="_blank" rel="noopener noreferrer">
              <Button size="lg" variant="outline" className="border-white/40 text-white hover:bg-white/10 gap-2 px-8">
                <MessageCircle className="w-5 h-5" />
                مشاوره رایگان
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="max-w-4xl mx-auto px-4 -mt-6 relative z-10">
        <div className="grid grid-cols-3 gap-3">
          <Card className="border-0 shadow-md text-center">
            <CardContent className="p-4">
              <Shield className="w-6 h-6 text-teal-600 mx-auto mb-1" />
              <p className="text-xs font-bold text-gray-700">مجوز رسمی فنی و حرفه‌ای</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md text-center">
            <CardContent className="p-4">
              <Award className="w-6 h-6 text-teal-600 mx-auto mb-1" />
              <p className="text-xs font-bold text-gray-700">مرکز آزمون ICDL</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md text-center">
            <CardContent className="p-4">
              <Users className="w-6 h-6 text-teal-600 mx-auto mb-1" />
              <p className="text-xs font-bold text-gray-700">{toPersianNumber(5000)}+ فارغ‌التحصیل</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="max-w-4xl mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-2">دوره‌های پرطرفدار</h2>
        <p className="text-gray-500 text-center text-sm mb-8">بهترین دوره‌ها برای شروع مسیر حرفه‌ای</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {FEATURED_COURSES.map((course) => (
            <Card key={course.slug} className="border-0 shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden group">
              <CardContent className="p-0">
                <div className="flex items-stretch">
                  <div
                    className="w-2 shrink-0 group-hover:w-3 transition-all duration-200"
                    style={{ backgroundColor: course.color }}
                  />
                  <div className="p-4 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-900 text-sm leading-relaxed">{course.title}</h3>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="secondary" className="text-xs bg-gray-100">
                            {course.level}
                          </Badge>
                        </div>
                      </div>
                      <GraduationCap className="w-8 h-8 shrink-0 opacity-20" style={{ color: course.color }} />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-6">
          <Button variant="outline" className="gap-2" onClick={() => router.push('/courses')}>
            <BookOpen className="w-4 h-4" />
            مشاهده همه دوره‌ها
          </Button>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="max-w-4xl mx-auto px-4 pb-12">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="text-center p-6 bg-white rounded-xl shadow-sm border-0">
            <div className="w-12 h-12 rounded-full bg-teal-50 flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="w-6 h-6 text-teal-600" />
            </div>
            <h3 className="font-bold text-gray-900 text-sm mb-1">مسیر شغلی مشخص</h3>
            <p className="text-xs text-gray-500">از مبتدی تا حرفه‌ای با راهنمایی کامل</p>
          </div>
          <div className="text-center p-6 bg-white rounded-xl shadow-sm border-0">
            <div className="w-12 h-12 rounded-full bg-orange-50 flex items-center justify-center mx-auto mb-3">
              <Zap className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="font-bold text-gray-900 text-sm mb-1">آموزش کاربردی</h3>
            <p className="text-xs text-gray-500">پروژه‌محور با مدرک معتبر فنی و حرفه‌ای</p>
          </div>
          <div className="text-center p-6 bg-white rounded-xl shadow-sm border-0">
            <div className="w-12 h-12 rounded-full bg-purple-50 flex items-center justify-center mx-auto mb-3">
              <Shield className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-bold text-gray-900 text-sm mb-1">ضمانت آموزش</h3>
            <p className="text-xs text-gray-500">پشتیبانی تا زمان اخذ مدرک و پس از آن</p>
          </div>
        </div>
      </section>

      {/* Registration Form */}
      <section id="register-form" className="max-w-4xl mx-auto px-4 pb-16">
        <Card className="border-0 shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-teal-600 to-cyan-600 p-6 text-white text-center">
            <h2 className="text-xl font-bold mb-1">ثبت‌نام سریع</h2>
            <p className="text-white/80 text-sm">
              با ثبت‌نام، کارشناسان ما برای مشاوره رایگان با شما تماس خواهند گرفت
            </p>
          </div>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium flex items-center gap-1">
                    <User className="w-3.5 h-3.5" />
                    نام و نام خانوادگی *
                  </Label>
                  <Input
                    placeholder="نام خود را وارد کنید..."
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5" />
                    شماره تلفن *
                  </Label>
                  <Input
                    placeholder="شماره موبایل..."
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    dir="ltr"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-sm font-medium flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5" />
                  دوره مورد علاقه
                </Label>
                <Select value={formCourse} onValueChange={setFormCourse}>
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="انتخاب دوره..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="icdl">ICDL — سواد دیجیتال</SelectItem>
                    <SelectItem value="python">Python — برنامه‌نویسی</SelectItem>
                    <SelectItem value="scratch">Scratch — برنامه‌نویسی بازی</SelectItem>
                    <SelectItem value="local-ai">هوش مصنوعی محلی</SelectItem>
                    <SelectItem value="forex">فارکس — معامله‌گری</SelectItem>
                    <SelectItem value="mql5">MQL5 — معامله‌گری الگوریتمی</SelectItem>
                    <SelectItem value="accounting">حسابداری مهارتی</SelectItem>
                    <SelectItem value="entrepreneurship">کارآفرینی دیجیتال</SelectItem>
                    <SelectItem value="business-consulting">مشاوره کسب‌وکار</SelectItem>
                    <SelectItem value="other">سایر دوره‌ها</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Hidden referrer info */}
              <input type="hidden" name="referredByCode" value={code || ''} />

              {/* Referrer Badge */}
              <div className="flex items-center gap-2 p-3 bg-teal-50 rounded-lg text-sm border border-teal-100">
                <Star className="w-4 h-4 text-teal-600" />
                <span className="text-teal-700">
                  معرفی‌شده توسط: <strong>{referrer?.firstName} {referrer?.lastName}</strong>
                </span>
                <code className="bg-teal-100 text-teal-800 px-1.5 py-0.5 rounded text-xs font-mono mr-auto">
                  {code}
                </code>
              </div>

              <Button
                type="submit"
                disabled={formSubmitting || !formName.trim() || !formPhone.trim()}
                className="w-full bg-teal-600 hover:bg-teal-700 text-white gap-2 h-12 text-base font-bold"
              >
                {formSubmitting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-5 h-5" />
                )}
                ثبت‌نام و دریافت مشاوره رایگان
              </Button>

              <p className="text-xs text-gray-400 text-center">
                با ثبت‌نام، کارشناسان آموزشگاه در اسرع وقت جهت مشاوره رایگان با شما تماس خواهند گرفت.
              </p>
            </form>
          </CardContent>
        </Card>
      </section>

      {/* Contact Section */}
      <section className="bg-gray-50 py-10">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h3 className="text-lg font-bold text-gray-900 mb-2">سؤالی دارید؟</h3>
          <p className="text-gray-500 text-sm mb-4">با ما تماس بگیرید</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a href={siteConfig.contact.whatsappUrl} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="gap-2">
                <MessageCircle className="w-4 h-4 text-green-600" />
                واتساپ: {siteConfig.contact.whatsappDisplay}
              </Button>
            </a>
            <a href={`tel:${siteConfig.contact.phoneRaw}`}>
              <Button variant="outline" className="gap-2">
                <Phone className="w-4 h-4 text-teal-600" />
                {siteConfig.contact.phone}
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-6">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <p className="text-sm text-gray-400">
            {siteConfig.name.fullName} | {siteConfig.location.fullAddress}
          </p>
          <p className="text-xs text-gray-500 mt-2">
            {siteConfig.workHours}
          </p>
        </div>
      </footer>
    </div>
  );
}

export default function ReferralPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gradient-to-br from-teal-50 via-white to-cyan-50 flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-teal-600 border-t-transparent mx-auto mb-4" />
          <p className="text-gray-500 text-sm">در حال بارگذاری...</p>
        </div>
      </div>
    }>
      <ReferralPageContent />
    </Suspense>
  );
}
