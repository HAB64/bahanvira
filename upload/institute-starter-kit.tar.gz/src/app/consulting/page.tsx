'use client';

import { useState } from 'react';
import { Briefcase, Phone, MessageCircle, CheckCircle2, Building2, Lightbulb, TrendingUp, GraduationCap, UserPlus, MessageSquare } from 'lucide-react';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { useUTM } from '@/hooks/use-utm';
import { siteConfig } from '@/config/site';

const services = [
  {
    icon: Building2,
    title: 'عارضه‌یابی سازمانی',
    desc: 'تحلیل ساختاری سازمان، شناسایی نقاط ضعف و فرصت‌های بهبود با ابزارهای تشخیصی ساختاریافته. خروجی این خدمت، گزارش تحلیلی کامل با اولویت‌بندی اقدامات و بازگشت سرمایه پیش‌بینی‌شده است.',
  },
  {
    icon: Lightbulb,
    title: 'سیستم‌سازی فرآیندها',
    desc: 'طراحی و پیاده‌سازی سیستم‌های عملیاتی استاندارد (SOP) برای حذف وابستگی به افراد و ایجاد رویه‌های تکرارپذیر. این خدمت شامل مستندسازی فرآیندها، تعیین شاخص‌های عملکرد و آموزش تیم اجرایی است.',
  },
  {
    icon: TrendingUp,
    title: 'استراتژی رشد و توسعه',
    desc: 'طراحی نقشه راه رشد کسب‌وکار بر اساس تحلیل بازار، مدل‌های درآمدی نوین و فرصت‌های دیجیتالی. این خدمت برای کسب‌وکارهایی طراحی شده که به دنبال مقیاس‌پذیری و ورود به بازارهای جدید هستند.',
  },
  {
    icon: Briefcase,
    title: 'انکوباسیون استارتاپ',
    desc: `از ایده تا محصول: اعتبارسنجی ایده، ساخت MVP، تست بازار و جذب اولین مشتریان. این خدمت مستقیماً توسط ${siteConfig.founder.name}، دارای دکتری کارآفرینی، ارائه می‌شود و شامل منتورینگ هفتگی است.`,
  },
];

// دوره‌های آموزشی برای فرم ثبت‌نام — هماهنگ با ۳ خوشه و ۸ گروه آموزشی
const COURSES = [
  { value: 'it', label: 'فن آوری اطلاعات', cluster: 'خدمات' },
  { value: 'finance', label: 'امور مالی و بازرگانی', cluster: 'خدمات' },
  { value: 'educational-services', label: 'خدمات آموزشی', cluster: 'خدمات' },
  { value: 'legal-services', label: 'خدمات حقوقی', cluster: 'خدمات' },
  { value: 'architecture', label: 'معماری', cluster: 'صنعت' },
  { value: 'building', label: 'ساختمان', cluster: 'صنعت' },
  { value: 'clothing', label: 'صنایع پوشاک', cluster: 'فرهنگ و هنر' },
  { value: 'visual-arts', label: 'هنرهای تجسمی', cluster: 'فرهنگ و هنر' },
] as const;

// زیردوره‌ها بر اساس گروه
const SUB_COURSES: Record<string, { value: string; label: string }[]> = {
  'it': [
    { value: 'icdl', label: 'ICDL' },
    { value: 'e-citizen', label: 'E-Citizen' },
    { value: 'computer-user-2', label: 'رایانه‌کار ۲' },
    { value: 'excel', label: 'اکسل' },
    { value: 'access', label: 'اکسس' },
    { value: 'word', label: 'وورد' },
    { value: 'powerpoint', label: 'پاورپوینت' },
    { value: 'html', label: 'HTML' },
    { value: 'javascript', label: 'JavaScript' },
    { value: 'cpp', label: 'C++' },
    { value: 'java-core', label: 'جاوا' },
    { value: 'csharp-windows', label: 'سی‌شارپ' },
    { value: 'matlab', label: 'متلب' },
    { value: 'web-design', label: 'طراحی وب' },
    { value: 'dreamweaver', label: 'دریم‌ویور' },
    { value: 'cs-fundamentals', label: 'مفاهیم پایه علوم کامپیوتر' },
    { value: 'python', label: 'پایتون' },
    { value: 'python-advanced', label: 'پایتون پیشرفته' },
    { value: 'ai-python', label: 'هوش مصنوعی با پایتون' },
    { value: 'machine-learning', label: 'یادگیری ماشین' },
    { value: 'deep-learning', label: 'یادگیری عمیق' },
    { value: 'data-science', label: 'علوم داده' },
    { value: 'numpy-pandas', label: 'NumPy و Pandas' },
    { value: 'algorithms', label: 'طراحی الگوریتم' },
    { value: 'local-ai-ollama', label: 'هوش مصنوعی محلی (Ollama)' },
    { value: 'ai-agents-n8n', label: 'عامل‌های هوشمند (n8n)' },
    { value: 'claude-code-dev', label: 'توسعه با Claude Code' },
    { value: 'scratch', label: 'اسکرچ' },
    { value: 'scratch-advanced', label: 'اسکرچ پیشرفته' },
    { value: 'ai-teens', label: 'هوش مصنوعی نوجوانان' },
  ],
  'finance': [
    { value: 'accounting', label: 'حسابداری مالی' },
    { value: 'accounting-practice', label: 'کار عملی حسابداری' },
    { value: 'costs-various', label: 'هزینه‌یابی صنعتی' },
    { value: 'costs-past', label: 'هزینه‌یابی گذشته‌نظر' },
    { value: 'finance-commerce', label: 'اصول مالی و بازرگانی' },
    { value: 'finance-commerce-2', label: 'حسابداری بازرگانی ۲' },
    { value: 'finance-commerce-degree2', label: 'دارایی ۲ (درجه ۲)' },
    { value: 'forex-fundamentals', label: 'فارکس (مبانی)' },
    { value: 'mql5-algorithmic', label: 'MQL5 الگوریتمی' },
    { value: 'gold-trading-phase-shift', label: 'معامله‌گری طلا' },
    { value: 'risk-capital-management', label: 'مدیریت ریسک و سرمایه' },
    { value: 'capital-market-intro', label: 'آشنایی با بازار سرمایه' },
    { value: 'capital-market-principles', label: 'اصول بازار سرمایه' },
    { value: 'technical-analysis', label: 'تحلیل تکنیکال' },
    { value: 'fundamental-analysis', label: 'تحلیل بنیادی' },
    { value: 'board-reading', label: 'تابلوخوانی و روانشناسی' },
    { value: 'portfolio-management', label: 'مدیریت پرتفوی' },
    { value: 'time-management', label: 'مدیریت زمان' },
    { value: 'financial-management', label: 'مدیریت مالی' },
    { value: 'stress-management', label: 'مدیریت استرس' },
    { value: 'body-language', label: 'زبان بدن' },
    { value: 'communication-skills', label: 'مهارت‌های ارتباطی' },
    { value: 'entrepreneurship', label: 'کارآفرینی' },
    { value: 'business-consulting', label: 'مشاوره کسب‌وکار' },
  ],
  'educational-services': [
    { value: 'pedagogy', label: 'پداگوژی و روش تدریس' },
    { value: 'presentation-skills', label: 'فن بیان و مهارت ارائه' },
    { value: 'course-design-lms', label: 'طراحی دوره و LMS' },
  ],
  'legal-services': [
    { value: 'contract-writing', label: 'قراردادنویسی' },
    { value: 'legal-consulting', label: 'مشاور حقوقی' },
    { value: 'judicial-writing', label: 'نگارش قضایی' },
    { value: 'judicial-e-services', label: 'خدمات الکترونیک قضایی' },
  ],
  'architecture': [
    { value: 'autocad-3d', label: 'اتوکد سه‌بعدی' },
    { value: 'interior-design', label: 'طراحی داخلی' },
  ],
  'building': [
    { value: 'building-drafting', label: 'نقشه‌کشی ساختمان' },
    { value: 'building-drafting-2', label: 'نقشه‌کشی ساختمان ۲' },
    { value: 'autocad', label: 'اتوکد' },
    { value: '3dmax', label: 'سه‌بعدی (3D Max)' },
    { value: '3dmax-building', label: 'سه‌بعدی ساختمان' },
  ],
  'clothing': [
    { value: 'sewing-basics', label: 'خیاطی پایه' },
    { value: 'pattern-making', label: 'الگوکشی' },
    { value: 'fashion-design', label: 'طراحی لباس' },
  ],
  'visual-arts': [
    { value: 'computer-graphics', label: 'گرافیک کامپیوتری' },
    { value: 'photoshop', label: 'فتوشاپ' },
    { value: 'corel-draw', label: 'کورل‌دراو' },
    { value: 'freehand', label: 'فری‌هند' },
    { value: 'indesign', label: 'ایندیزاین' },
  ],
};

type FormMode = 'consultation' | 'registration';

export default function ConsultingPage() {
  const [formMode, setFormMode] = useState<FormMode>('consultation');

  // مشاوره
  const [consultForm, setConsultForm] = useState({ name: '', phone: '', company: '', service: '', message: '' });
  // ثبت‌نام
  const [regForm, setRegForm] = useState({ name: '', phone: '', email: '', cluster: '', course: '', education: '', message: '' });

  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const utm = useUTM();

  const handleConsultSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: consultForm.name,
          phone: consultForm.phone,
          company: consultForm.company,
          serviceType: consultForm.service,
          message: consultForm.message,
          source: 'consulting-form',
          utmSource: utm.utmSource,
          utmMedium: utm.utmMedium,
          utmCampaign: utm.utmCampaign,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'خطا در ثبت اطلاعات');
        return;
      }
      setSubmitted(true);
    } catch {
      setError('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRegSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    // Validate phone
    const phoneRegex = /^09[0-9]{9}$/;
    if (!phoneRegex.test(regForm.phone)) {
      setError('شماره موبایل نامعتبر است (فرمت: 09123456789)');
      setSubmitting(false);
      return;
    }

    try {
      const selectedCourse = regForm.course
        ? SUB_COURSES[regForm.cluster]?.find(c => c.value === regForm.course)?.label || regForm.course
        : '';
      const selectedCluster = COURSES.find(c => c.value === regForm.cluster)?.label || regForm.cluster;

      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regForm.name,
          phone: regForm.phone,
          email: regForm.email,
          course: selectedCourse || selectedCluster,
          cluster: regForm.cluster,
          goal: regForm.education ? `تحصیلات: ${regForm.education}` : '',
          message: regForm.message,
          source: 'registration-form',
          utmSource: utm.utmSource,
          utmMedium: utm.utmMedium,
          utmCampaign: utm.utmCampaign,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'خطا در ثبت اطلاعات');
        return;
      }
      setSubmitted(true);
    } catch {
      setError('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setSubmitted(false);
    setError('');
    setConsultForm({ name: '', phone: '', company: '', service: '', message: '' });
    setRegForm({ name: '', phone: '', email: '', cluster: '', course: '', education: '', message: '' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <main className="flex-1">
        {/* Hero */}
        <div className="bg-gradient-to-bl from-[#0f172a] via-[#7c3aed] to-[#5b21b6] py-12 sm:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div className="text-center lg:text-right">
                <span className="inline-block text-sm font-medium text-[#c4b5fd] bg-white/10 rounded-full px-4 py-1.5 mb-4">
                  پورتال سازمانی B2B
                </span>
                <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                  مشاوره کسب‌وکار و ثبت‌نام دوره‌ها
                </h1>
                <p className="text-white/80 leading-relaxed max-w-lg mx-auto lg:mx-0">
                  خدمات مشاوره تخصصی زیر نظر {siteConfig.founder.name}، دارای دکتری کارآفرینی و {siteConfig.experience.yearsFa} سال تجربه مدیریتی.
                  از عارضه‌یابی سازمانی تا سیستم‌سازی و استراتژی رشد.
                </p>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-xl">
                <h2 className="font-bold text-[#0f172a] text-lg mb-1">{siteConfig.founder.name}</h2>
                <p className="text-sm text-[#64748b] mb-4">مشاور ارشد کسب‌وکار و کارآفرینی</p>
                <div className="space-y-2 mb-4">
                  {[
                    'دکتری کارآفرینی',
                    `${siteConfig.experience.yearsFa}+ سال تجربه مدیریتی و آموزشی`,
                    'مشاور ده‌ها کسب‌وکار در استان مازندران',
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-[#475569]">
                      <CheckCircle2 className="w-4 h-4 text-[#7c3aed]" />
                      {item}
                    </div>
                  ))}
                </div>
                <div className="flex gap-3">
                  <a
                    href={siteConfig.contact.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 bg-[#25D366] text-white font-bold py-2.5 rounded-xl text-sm hover:bg-[#20ba5c] transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    واتساپ
                  </a>
                  <a
                    href={siteConfig.contact.phoneHref}
                    className="flex-1 flex items-center justify-center gap-2 bg-[#7c3aed] text-white font-bold py-2.5 rounded-xl text-sm hover:bg-[#6d28d9] transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    تماس
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Services */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">خدمات مشاوره‌ای</h2>
            <p className="text-[#64748b] max-w-2xl mx-auto">هر خدمت بر اساس نیاز خاص کسب‌وکار شما شخصی‌سازی می‌شود</p>
          </div>
          <div className="grid sm:grid-cols-2 gap-6">
            {services.map((service) => (
              <div key={service.title} className="bg-white rounded-2xl border border-gray-100 p-6 hover:shadow-lg transition-all">
                <div className="w-12 h-12 rounded-xl bg-[#ede9fe] flex items-center justify-center mb-4">
                  <service.icon className="w-6 h-6 text-[#7c3aed]" />
                </div>
                <h3 className="font-bold text-[#0f172a] text-lg mb-2">{service.title}</h3>
                <p className="text-sm text-[#64748b] leading-relaxed">{service.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Registration & Consultation Form */}
        <div className="bg-gray-50 py-16 sm:py-20">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-10">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
                ثبت‌نام و درخواست مشاوره
              </h2>
              <p className="text-[#64748b]">
                نوع درخواست خود را انتخاب کنید و فرم مربوطه را تکمیل نمایید.
              </p>
            </div>

            {submitted ? (
              <div className="bg-white rounded-2xl p-10 text-center border border-gray-100">
                <CheckCircle2 className="w-16 h-16 text-[#0d9488] mx-auto mb-4" />
                <h3 className="text-xl font-bold text-[#0f172a] mb-2">
                  {formMode === 'consultation'
                    ? 'درخواست مشاوره شما ثبت شد'
                    : 'درخواست ثبت‌نام شما ثبت شد'}
                </h3>
                <p className="text-[#64748b] mb-1">
                  {formMode === 'consultation'
                    ? 'کارشناسان ما ظرف ۲۴ ساعت کاری با شما تماس خواهند گرفت.'
                    : 'کارشناسان ما ظرف ۲۴ ساعت کاری جهت تکمیل فرآیند ثبت‌نام با شما تماس خواهند گرفت.'}
                </p>
                <button
                  onClick={resetForm}
                  className="mt-4 text-sm text-teal-600 hover:text-teal-700 font-medium transition-colors"
                >
                  ثبت درخواست دیگر
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                {/* Tab Selector */}
                <div className="flex border-b border-gray-100">
                  <button
                    type="button"
                    onClick={() => { setFormMode('consultation'); setError(''); }}
                    className={`flex-1 flex items-center justify-center gap-2 py-4 px-4 text-sm font-bold transition-all relative ${
                      formMode === 'consultation'
                        ? 'text-[#0d9488] bg-teal-50/50'
                        : 'text-[#64748b] hover:text-[#334155] hover:bg-gray-50'
                    }`}
                  >
                    <MessageSquare className="w-5 h-5" />
                    درخواست مشاوره
                    {formMode === 'consultation' && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0d9488]" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setFormMode('registration'); setError(''); }}
                    className={`flex-1 flex items-center justify-center gap-2 py-4 px-4 text-sm font-bold transition-all relative ${
                      formMode === 'registration'
                        ? 'text-[#7c3aed] bg-purple-50/50'
                        : 'text-[#64748b] hover:text-[#334155] hover:bg-gray-50'
                    }`}
                  >
                    <GraduationCap className="w-5 h-5" />
                    ثبت‌نام دوره
                    {formMode === 'registration' && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#7c3aed]" />
                    )}
                  </button>
                </div>

                <div className="p-8">
                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg p-3 mb-5">
                      {error}
                    </div>
                  )}

                  {/* ── فرم مشاوره ────────────────────────────── */}
                  {formMode === 'consultation' && (
                    <form onSubmit={handleConsultSubmit} className="space-y-5">
                      <div className="grid sm:grid-cols-2 gap-5">
                        <div>
                          <label className="block text-sm font-medium text-[#334155] mb-1.5">نام و نام خانوادگی</label>
                          <input
                            type="text"
                            required
                            value={consultForm.name}
                            onChange={(e) => setConsultForm({ ...consultForm, name: e.target.value })}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm"
                            placeholder="نام کامل"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-[#334155] mb-1.5">شماره تماس</label>
                          <input
                            type="tel"
                            required
                            value={consultForm.phone}
                            onChange={(e) => setConsultForm({ ...consultForm, phone: e.target.value })}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm"
                            placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                            dir="ltr"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#334155] mb-1.5">نام شرکت / کسب‌وکار (اختیاری)</label>
                        <input
                          type="text"
                          value={consultForm.company}
                          onChange={(e) => setConsultForm({ ...consultForm, company: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm"
                          placeholder="نام سازمان یا شرکت"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#334155] mb-1.5">خدمت مورد نظر</label>
                        <select
                          value={consultForm.service}
                          onChange={(e) => setConsultForm({ ...consultForm, service: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm bg-white"
                        >
                          <option value="">انتخاب کنید...</option>
                          <option value="diagnostics">عارضه‌یابی سازمانی</option>
                          <option value="systemization">سیستم‌سازی فرآیندها</option>
                          <option value="growth">استراتژی رشد و توسعه</option>
                          <option value="startup">انکوباسیون استارتاپ</option>
                          <option value="course">ثبت‌نام در دوره آموزشی</option>
                          <option value="other">سایر</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-[#334155] mb-1.5">توضیحات</label>
                        <textarea
                          rows={4}
                          value={consultForm.message}
                          onChange={(e) => setConsultForm({ ...consultForm, message: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/20 outline-none transition-all text-sm resize-none"
                          placeholder="توضیحات تکمیلی..."
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={submitting}
                        className="w-full bg-[#0d9488] text-white font-bold py-3.5 rounded-xl hover:bg-[#0f766e] transition-colors shadow-sm shadow-[#0d9488]/20 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {submitting ? (
                          <span className="flex items-center justify-center gap-2">
                            <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            در حال ارسال...
                          </span>
                        ) : (
                          <span className="flex items-center justify-center gap-2">
                            <MessageSquare className="w-4 h-4" />
                            ارسال درخواست مشاوره
                          </span>
                        )}
                      </button>
                    </form>
                  )}

                  {/* ── فرم ثبت‌نام ────────────────────────────── */}
                  {formMode === 'registration' && (
                    <form onSubmit={handleRegSubmit} className="space-y-5">
                      <div className="grid sm:grid-cols-2 gap-5">
                        <div>
                          <label className="block text-sm font-medium text-[#334155] mb-1.5">نام و نام خانوادگی <span className="text-red-500">*</span></label>
                          <input
                            type="text"
                            required
                            value={regForm.name}
                            onChange={(e) => setRegForm({ ...regForm, name: e.target.value })}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#7c3aed] focus:ring-2 focus:ring-[#7c3aed]/20 outline-none transition-all text-sm"
                            placeholder="نام کامل"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-[#334155] mb-1.5">شماره موبایل <span className="text-red-500">*</span></label>
                          <input
                            type="tel"
                            required
                            value={regForm.phone}
                            onChange={(e) => {
                              const val = e.target.value.replace(/[^0-9]/g, '');
                              if (val.length <= 11) setRegForm({ ...regForm, phone: val });
                            }}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#7c3aed] focus:ring-2 focus:ring-[#7c3aed]/20 outline-none transition-all text-sm text-left"
                            placeholder="09123456789"
                            dir="ltr"
                          />
                        </div>
                      </div>

                      <div className="grid sm:grid-cols-2 gap-5">
                        <div>
                          <label className="block text-sm font-medium text-[#334155] mb-1.5">ایمیل (اختیاری)</label>
                          <input
                            type="email"
                            value={regForm.email}
                            onChange={(e) => setRegForm({ ...regForm, email: e.target.value })}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#7c3aed] focus:ring-2 focus:ring-[#7c3aed]/20 outline-none transition-all text-sm text-left"
                            placeholder="email@example.com"
                            dir="ltr"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-[#334155] mb-1.5">مدرک تحصیلی</label>
                          <select
                            value={regForm.education}
                            onChange={(e) => setRegForm({ ...regForm, education: e.target.value })}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#7c3aed] focus:ring-2 focus:ring-[#7c3aed]/20 outline-none transition-all text-sm bg-white"
                          >
                            <option value="">انتخاب کنید...</option>
                            <option value="دیپلم">دیپلم</option>
                            <option value="کاردانی">کاردانی</option>
                            <option value="کارشناسی">کارشناسی</option>
                            <option value="کارشناسی ارشد">کارشناسی ارشد</option>
                            <option value="دکتری">دکتری</option>
                            <option value="دانش‌آموز">دانش‌آموز</option>
                          </select>
                        </div>
                      </div>

                      {/* خوشه شایستگی */}
                      <div>
                        <label className="block text-sm font-medium text-[#334155] mb-1.5">خوشه شایستگی <span className="text-red-500">*</span></label>
                        <select
                          required
                          value={regForm.cluster}
                          onChange={(e) => setRegForm({ ...regForm, cluster: e.target.value, course: '' })}
                          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#7c3aed] focus:ring-2 focus:ring-[#7c3aed]/20 outline-none transition-all text-sm bg-white"
                        >
                          <option value="">انتخاب خوشه شایستگی...</option>
                          {COURSES.map((c) => (
                            <option key={c.value} value={c.value}>{c.label}</option>
                          ))}
                        </select>
                      </div>

                      {/* دوره مورد علاقه - داینامیک بر اساس خوشه */}
                      {regForm.cluster && SUB_COURSES[regForm.cluster] && (
                        <div>
                          <label className="block text-sm font-medium text-[#334155] mb-1.5">دوره مورد علاقه</label>
                          <select
                            value={regForm.course}
                            onChange={(e) => setRegForm({ ...regForm, course: e.target.value })}
                            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#7c3aed] focus:ring-2 focus:ring-[#7c3aed]/20 outline-none transition-all text-sm bg-white"
                          >
                            <option value="">انتخاب دوره...</option>
                            {SUB_COURSES[regForm.cluster].map((c) => (
                              <option key={c.value} value={c.value}>{c.label}</option>
                            ))}
                          </select>
                        </div>
                      )}

                      <div>
                        <label className="block text-sm font-medium text-[#334155] mb-1.5">توضیحات (اختیاری)</label>
                        <textarea
                          rows={3}
                          value={regForm.message}
                          onChange={(e) => setRegForm({ ...regForm, message: e.target.value })}
                          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-[#7c3aed] focus:ring-2 focus:ring-[#7c3aed]/20 outline-none transition-all text-sm resize-none"
                          placeholder="سؤال یا توضیح تکمیلی..."
                        />
                      </div>

                      <div className="bg-purple-50 rounded-xl p-3 text-sm text-purple-700">
                        <p>پس از ثبت‌نام، کارشناسان ما جهت تکمیل فرآیند ثبت‌نام و انتخاب زمان کلاس با شما تماس خواهند گرفت. امکان قسط‌بندی شهریه بدون چک و بدون بهره وجود دارد.</p>
                      </div>

                      <button
                        type="submit"
                        disabled={submitting}
                        className="w-full bg-[#7c3aed] text-white font-bold py-3.5 rounded-xl hover:bg-[#6d28d9] transition-colors shadow-sm shadow-[#7c3aed]/20 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {submitting ? (
                          <span className="flex items-center justify-center gap-2">
                            <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            در حال ارسال...
                          </span>
                        ) : (
                          <span className="flex items-center justify-center gap-2">
                            <UserPlus className="w-4 h-4" />
                            ثبت‌نام در دوره
                          </span>
                        )}
                      </button>
                    </form>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
// deploy trigger 1780827538
