import { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: `مشاوره کسب‌وکار و ثبت‌نام | ${siteConfig.name.fullName}`,
  description: `خدمات مشاوره کسب‌وکار زیر نظر ${siteConfig.founder.name} — عارضه‌یابی سازمانی، سیستم‌سازی، استراتژی رشد و انکوباسیون استارتاپ. ثبت‌نام دوره‌های ${siteConfig.institute.typeFa}.`,
  keywords: ['مشاوره کسب‌وکار', 'سیستم‌سازی', 'عارضه‌یابی سازمانی', `ثبت‌نام دوره ${siteConfig.location.city}`],
  alternates: {
    canonical: `${siteConfig.url.base}/consulting`,
  },
  openGraph: {
    title: 'مشاوره کسب‌وکار و ثبت‌نام',
    description: `مشاوره تخصصی و ثبت‌نام دوره‌های ${siteConfig.institute.typeFa} ${siteConfig.name.fa}`,
    locale: 'fa_IR',
    url: `${siteConfig.url.base}/consulting`,
  },
};

export default function ConsultingLayout({ children }: { children: React.ReactNode }) {
  return children;
}
