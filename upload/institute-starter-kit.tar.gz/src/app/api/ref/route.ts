import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { siteConfig } from '@/config/site';

/**
 * GET /api/ref?code=XXXX
 * نقطه پایانی عمومی — هندل لینک‌های معرف و اسکن QR
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');

    if (!code) {
      return NextResponse.redirect(new URL('/', siteConfig.url.base));
    }

    const referrer = await db.referrer.findUnique({
      where: { code },
      select: {
        id: true,
        code: true,
        isActive: true,
        status: true,
        firstName: true,
        lastName: true,
      },
    });

    if (!referrer || !referrer.isActive || referrer.status !== 'ACTIVE') {
      return NextResponse.redirect(new URL('/', siteConfig.url.base));
    }

    // تشخیص منبع: پارامتر source اولویت دارد، سپس referer header
    const sourceParam = searchParams.get('source');
    let referrerSource: string;
    if (sourceParam === 'qr') {
      referrerSource = 'QR_SCAN';
    } else if (sourceParam === 'link') {
      referrerSource = 'REFERRAL_LINK';
    } else {
      const refererHeader = request.headers.get('referer');
      referrerSource = refererHeader ? 'REFERRAL_LINK' : 'QR_SCAN';
    }

    // ثبت خودکار یک معرف جدید

    try {
      await db.referral.create({
        data: {
          referrerId: referrer.id,
          refName: 'بازدیدکننده وبسایت',
          refPhone: '00000000000',
          source: referrerSource,
          referrerCode: referrer.code,
          status: 'PENDING',
        },
      });

      await db.referrer.update({
        where: { id: referrer.id },
        data: {
          totalReferrals: { increment: 1 },
        },
      });
    } catch {
      // خطا در ثبت نادیده گرفته می‌شود
    }

    const redirectUrl = new URL('/', siteConfig.url.base);
    redirectUrl.searchParams.set('ref', code);

    return NextResponse.redirect(redirectUrl);
  } catch (error) {
    console.error('Ref link handler error:', error);
    return NextResponse.redirect(new URL('/', siteConfig.url.base));
  }
}
