import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/ref/info?code=BR-1001
 * Public endpoint to get referrer basic info (for QR landing page)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');

    if (!code) {
      return NextResponse.json({ error: 'کد معرف وارد نشده' }, { status: 400 });
    }

    const referrer = await db.referrer.findUnique({
      where: { code: code.toUpperCase() },
      select: {
        id: true,
        code: true,
        firstName: true,
        lastName: true,
        tier: true,
        instagram: true,
        telegram: true,
      },
    });

    if (!referrer) {
      return NextResponse.json({ error: 'معرف یافت نشد' }, { status: 404 });
    }

    // Get any active discount code for this referrer
    const discountCode = await db.discountCode.findFirst({
      where: {
        referrerId: referrer.id,
        isActive: true,
        OR: [
          { endDate: null },
          { endDate: { gte: new Date() } },
        ],
      },
      select: { code: true, type: true, value: true },
    });

    return NextResponse.json({
      referrer,
      discountCode: discountCode || null,
    });
  } catch (error) {
    console.error('Error fetching referrer info:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات' }, { status: 500 });
  }
}
