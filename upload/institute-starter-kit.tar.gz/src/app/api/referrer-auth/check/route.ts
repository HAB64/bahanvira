import { NextResponse } from 'next/server';
import { createHash } from 'crypto';
import { db } from '@/lib/db';

const REFERRER_SESSION_SECRET = 'bahan-referrer-session-2024';

function verifyReferrerSessionToken(token: string): { code: string; exp: number } | null {
  try {
    const [tokenPart, signature] = token.split('.');
    const expectedSignature = createHash('sha256').update(tokenPart + REFERRER_SESSION_SECRET).digest('hex');
    if (signature !== expectedSignature) return null;
    const payload = JSON.parse(Buffer.from(tokenPart, 'base64').toString());
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

/**
 * GET /api/referrer-auth/check
 * Check referrer session validity
 */
export async function GET(request: Request) {
  try {
    const cookieHeader = request.headers.get('cookie') || '';
    const match = cookieHeader.match(/referrer_session=([^;]+)/);
    const token = match?.[1];

    if (!token) {
      return NextResponse.json({ authenticated: false });
    }

    const session = verifyReferrerSessionToken(decodeURIComponent(token));
    if (!session) {
      return NextResponse.json({ authenticated: false });
    }

    const referrer = await db.referrer.findUnique({
      where: { code: session.code },
      select: {
        id: true, code: true, firstName: true, lastName: true,
        tier: true, status: true, phone: true,
      },
    });

    if (!referrer || referrer.status !== 'ACTIVE') {
      return NextResponse.json({ authenticated: false });
    }

    return NextResponse.json({ authenticated: true, referrer });
  } catch {
    return NextResponse.json({ authenticated: false });
  }
}
