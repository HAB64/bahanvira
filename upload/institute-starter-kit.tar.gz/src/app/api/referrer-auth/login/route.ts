import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { createHash } from 'crypto';

const REFERRER_SESSION_SECRET = 'bahan-referrer-session-2024';

function createReferrerSessionToken(code: string): string {
  const payload = JSON.stringify({ code, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 }); // 7 days
  const token = Buffer.from(payload).toString('base64');
  const signature = createHash('sha256').update(token + REFERRER_SESSION_SECRET).digest('hex');
  return `${token}.${signature}`;
}

/**
 * POST /api/referrer-auth/login
 * Login for referrers (using code + phone/password)
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { code, password } = body;

    if (!code || !password) {
      return NextResponse.json({ error: 'کد معرف و رمز عبور الزامی است' }, { status: 400 });
    }

    const referrer = await db.referrer.findUnique({
      where: { code: code.toUpperCase() },
    });

    if (!referrer) {
      return NextResponse.json({ error: 'کد معرف یافت نشد' }, { status: 404 });
    }

    if (referrer.status !== 'ACTIVE') {
      return NextResponse.json({ error: 'حساب شما غیرفعال شده است' }, { status: 403 });
    }

    // Check password
    const passwordHash = createHash('sha256').update(password).digest('hex');
    if (referrer.passwordHash !== passwordHash) {
      return NextResponse.json({ error: 'رمز عبور اشتباه است' }, { status: 401 });
    }

    const token = createReferrerSessionToken(referrer.code);

    const response = NextResponse.json({
      success: true,
      referrer: {
        id: referrer.id,
        code: referrer.code,
        firstName: referrer.firstName,
        lastName: referrer.lastName,
        tier: referrer.tier,
      },
    });

    response.cookies.set('referrer_session', token, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60,
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Referrer login error:', error);
    return NextResponse.json({ error: 'خطا در ورود' }, { status: 500 });
  }
}
