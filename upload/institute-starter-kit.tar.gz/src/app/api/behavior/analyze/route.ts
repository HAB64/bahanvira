import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { GROUPS, OCCUPATIONS } from '@/lib/skill-graph'


export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const sessionId = searchParams.get('sessionId')
    const userId = searchParams.get('userId')

    if (!sessionId && !userId) {
      return NextResponse.json({ error: 'sessionId یا userId الزامی است' }, { status: 400 })
    }

    // Get or create profile
    let profile = null
    if (sessionId) {
      profile = await db.personalizationProfile.findUnique({
        where: { sessionId },
      })
    } else if (userId) {
      profile = await db.personalizationProfile.findFirst({
        where: { userId: userId! },
      })
    }

    // Get recent behavior
    const whereClause: { sessionId?: string; userId?: string } = {}
    if (sessionId) whereClause.sessionId = sessionId
    if (userId) whereClause.userId = userId!

    const recentBehaviors = await db.userBehavior.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    // Compute cluster preferences
    const clusterCounts: Record<string, number> = {}
    for (const behavior of recentBehaviors) {
      if (behavior.cluster) {
        clusterCounts[behavior.cluster] = (clusterCounts[behavior.cluster] || 0) + 1
      }
    }

    // Sort clusters by engagement
    const sortedClusters = Object.entries(clusterCounts)
      .sort(([, a], [, b]) => b - a)
      .map(([cluster, count]) => ({
        cluster,
        label: GROUPS[cluster as keyof typeof GROUPS]?.label || cluster,
        count,
        percentage: recentBehaviors.length > 0 ? Math.round((count / recentBehaviors.length) * 100) : 0,
      }))

    // Compute engagement level
    const eventCounts: Record<string, number> = {}
    for (const behavior of recentBehaviors) {
      eventCounts[behavior.eventType] = (eventCounts[behavior.eventType] || 0) + 1
    }

    const totalEvents = recentBehaviors.length
    const highEngagementEvents = (eventCounts['CTA_CLICK'] || 0) + (eventCounts['QUIZ_COMPLETE'] || 0) + (eventCounts['CONSULTATION_START'] || 0)
    const engagementLevel = totalEvents > 0 ? Math.min(1, (totalEvents * 0.02 + highEngagementEvents * 0.15)) : 0

    // Determine engagement category
    let engagementCategory = 'LOW'
    if (engagementLevel >= 0.6) engagementCategory = 'HIGH'
    else if (engagementLevel >= 0.3) engagementCategory = 'MEDIUM'

    // Infer goal from profile or behavior
    let inferredGoal = profile?.inferredGoal || null
    if (!inferredGoal) {
      if (eventCounts['CTA_CLICK'] && eventCounts['CTA_CLICK'] > 2) inferredGoal = 'EMPLOYMENT'
      else if (sortedClusters.length > 0 && sortedClusters[0].cluster === 'entrepreneurship-and-business') inferredGoal = 'ENTREPRENEURSHIP'
      else if (sortedClusters.length > 0 && (sortedClusters[0].cluster === 'finance' || sortedClusters[0].cluster === 'capital-market')) inferredGoal = 'INCOME'
      else inferredGoal = 'SKILL_UP'
    }

    // Generate recommendations based on top clusters
    const recommendations = []
    const topClusters = sortedClusters.slice(0, 3)

    for (const clusterInfo of topClusters) {
      const clusterOccupations = OCCUPATIONS.filter(o => o.groupKey === clusterInfo.cluster)
      const topOccupations = clusterOccupations.slice(0, 3)

      for (const occ of topOccupations) {
        recommendations.push({
          slug: occ.slug,
          title: occ.title,
          cluster: occ.groupKey,
          level: occ.level,
          matchScore: Math.min(100, 50 + clusterInfo.percentage),
          reason: `بر اساس علاقه شما به ${clusterInfo.label}`,
        })
      }
    }

    // Detect patterns
    const patterns = []

    // Peak activity hours
    const hourCounts: Record<number, number> = {}
    for (const behavior of recentBehaviors) {
      const hour = new Date(behavior.createdAt).getHours()
      hourCounts[hour] = (hourCounts[hour] || 0) + 1
    }
    const peakHour = Object.entries(hourCounts).sort(([, a], [, b]) => b - a)[0]
    if (peakHour) {
      patterns.push({
        type: 'PEAK_ACTIVITY',
        description: `بیشترین فعالیت شما ساعت ${peakHour[0]} است`,
      })
    }

    // Bounce risk detection
    const lastBehavior = recentBehaviors[0]
    if (lastBehavior) {
      const hoursSinceLastActivity = (Date.now() - new Date(lastBehavior.createdAt).getTime()) / (1000 * 60 * 60)
      if (hoursSinceLastActivity > 48 && totalEvents < 5) {
        patterns.push({
          type: 'BOUNCE_RISK',
          description: 'احتمال ترک سایت بالاست - نیاز به تشویق',
        })
      }
    }

    // Conversion signal
    if (eventCounts['CTA_CLICK'] && eventCounts['CTA_CLICK'] >= 2 && eventCounts['CONSULTATION_START']) {
      patterns.push({
        type: 'CONVERSION_SIGNAL',
        description: 'نشانگان تبدیل قوی - کاربر آماده ثبت‌نام',
      })
    }

    return NextResponse.json({
      profile: profile ? {
        sessionId: profile.sessionId,
        clusterScores: (profile.clusterScores as Record<string, number>) || {},
        visitCount: profile.visitCount,
        inferredGoal: profile.inferredGoal || inferredGoal,
        inferredLevel: profile.inferredLevel,
        engagementScore: profile.engagementScore,
        conversionProb: profile.conversionProb,
      } : {
        inferredGoal,
        engagementScore: engagementLevel,
      },
      recommendations: recommendations.slice(0, 6),
      patterns,
      analysis: {
        totalEvents,
        eventCounts,
        sortedClusters,
        engagementLevel,
        engagementCategory,
      },
    })
  } catch (error) {
    console.error('Behavior analyze error:', error)
    return NextResponse.json({ error: 'خطا در تحلیل رفتار' }, { status: 500 })
  }
}
