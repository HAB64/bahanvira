import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { sessionId, batch } = body as {
      sessionId: string
      batch?: Array<{
        eventType: string
        page: string
        element?: string
        metadata?: Record<string, unknown>
        duration?: number
        cluster?: string
        courseSlug?: string
        referrer?: string
      }>
    }

    // Support both batch and single-event modes for backward compatibility
    const events = batch || [body]

    if (!sessionId || !events.length) {
      return NextResponse.json({ error: 'sessionId و events الزامی هستند' }, { status: 400 })
    }

    // Get request metadata
    const userAgent = request.headers.get('user-agent') || undefined
    const forwarded = request.headers.get('x-forwarded-for')
    const ipAddress = forwarded ? forwarded.split(',')[0]?.trim() : undefined

    // Process all events
    for (const event of events) {
      const { eventType, page, element, metadata, duration, cluster, courseSlug, referrer } = event

      if (!eventType || !page) continue

      // Create behavior record
      try {
        await db.userBehavior.create({
          data: {
            sessionId,
            eventType,
            page,
            element: element || null,
            metadata: metadata || undefined,
            duration: duration || 0,
            cluster: cluster || null,
            courseSlug: courseSlug || null,
            referrer: referrer || null,
            userAgent,
            ipAddress: ipAddress || null,
          },
        })
      } catch (dbError) {
        console.error('Behavior track DB error:', dbError)
      }

      // Update personalization profile for the last event only
      // (batch events are usually related — last one is most representative)
    }

    // Update personalization profile once per batch (not per event)
    try {
      const lastEvent = events[events.length - 1]
      const { eventType, page, element, metadata, duration, cluster, courseSlug, referrer } = lastEvent

      const existingProfile = await db.personalizationProfile.findUnique({
        where: { sessionId },
      })

      if (existingProfile) {
        const updateData: Record<string, unknown> = {}

        // Count PAGE_VIEW events in batch
        const pageViewsInBatch = events.filter(e => e.eventType === 'PAGE_VIEW').length
        if (pageViewsInBatch > 0) {
          updateData.visitCount = existingProfile.visitCount + pageViewsInBatch
        }

        // Update courseViews for COURSE_VIEW
        if (eventType === 'COURSE_VIEW' && courseSlug) {
          const courseViews = (existingProfile.courseViews as Array<{ slug: string; count: number; lastViewed: string }>) || []
          const existing = courseViews.find(cv => cv.slug === courseSlug)
          if (existing) {
            existing.count += 1
            existing.lastViewed = new Date().toISOString()
          } else {
            courseViews.push({ slug: courseSlug, count: 1, lastViewed: new Date().toISOString() })
          }
          updateData.courseViews = courseViews
        }

        // Update searchQueries for SEARCH
        if (eventType === 'SEARCH' && metadata && typeof metadata === 'object' && 'query' in metadata) {
          const searchQueries = (existingProfile.searchQueries as Array<{ query: string; timestamp: string }>) || []
          searchQueries.push({ query: String(metadata.query), timestamp: new Date().toISOString() })
          // Keep last 20 searches
          updateData.searchQueries = searchQueries.slice(-20)
        }

        // Update clusterScores based on behavior
        if ((eventType === 'COURSE_VIEW' || eventType === 'QUIZ_COMPLETE' || eventType === 'CTA_CLICK') && cluster) {
          const clusterScores = (existingProfile.clusterScores as Record<string, number>) || {}
          const increment = eventType === 'QUIZ_COMPLETE' ? 15 : eventType === 'CTA_CLICK' ? 10 : 5
          clusterScores[cluster] = Math.min(100, (clusterScores[cluster] || 0) + increment)
          updateData.clusterScores = clusterScores
        }

        // Update engagement score
        const courseViewsArr = (existingProfile.courseViews as Array<unknown>) || []
        const searchQueriesArr = (existingProfile.searchQueries as Array<unknown>) || []
        const totalInteractions = existingProfile.visitCount + courseViewsArr.length + searchQueriesArr.length
        const ctaClicks = await countCTAClicks(sessionId)
        const quizCompletions = await countQuizCompletions(sessionId)
        const engagementScore = Math.min(1, (totalInteractions * 0.02 + ctaClicks * 0.15 + quizCompletions * 0.2))
        updateData.engagementScore = engagementScore

        // Infer goal from behavior
        if (!existingProfile.inferredGoal) {
          const clusterScores = (updateData.clusterScores || existingProfile.clusterScores) as Record<string, number>
          const searchQueries = (updateData.searchQueries || existingProfile.searchQueries) as Array<{ query: string; timestamp: string }>
          updateData.inferredGoal = inferGoal(clusterScores || {}, searchQueries || [])
        }

        // Infer level from behavior
        if (!existingProfile.inferredLevel) {
          updateData.inferredLevel = inferLevel({
            visitCount: existingProfile.visitCount,
            quizResults: existingProfile.quizResults,
            courseViews: existingProfile.courseViews,
          })
        }

        if (Object.keys(updateData).length > 0) {
          await db.personalizationProfile.update({
            where: { sessionId },
            data: updateData,
          })
        }
      } else {
        // Create new profile — PostgreSQL Json fields accept objects directly
        const clusterScores: Record<string, number> = {}
        if (cluster && (eventType === 'COURSE_VIEW' || eventType === 'QUIZ_COMPLETE' || eventType === 'CTA_CLICK')) {
          clusterScores[cluster] = eventType === 'QUIZ_COMPLETE' ? 15 : eventType === 'CTA_CLICK' ? 10 : 5
        }

        const courseViews: Array<{ slug: string; count: number; lastViewed: string }> = []
        if (eventType === 'COURSE_VIEW' && courseSlug) {
          courseViews.push({ slug: courseSlug, count: 1, lastViewed: new Date().toISOString() })
        }

        const searchQueries: Array<{ query: string; timestamp: string }> = []
        if (eventType === 'SEARCH' && metadata && typeof metadata === 'object' && 'query' in metadata) {
          searchQueries.push({ query: String(metadata.query), timestamp: new Date().toISOString() })
        }

        await db.personalizationProfile.create({
          data: {
            sessionId,
            clusterScores,
            visitCount: eventType === 'PAGE_VIEW' ? 1 : 0,
            courseViews,
            searchQueries,
            engagementScore: 0.05,
          },
        })
      }
    } catch (profileError) {
      console.error('Profile update error:', profileError)
      // Don't fail the request
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Behavior track error:', error)
    return NextResponse.json({ error: 'خطا در ثبت رفتار' }, { status: 500 })
  }
}

async function countCTAClicks(sessionId: string): Promise<number> {
  try {
    const clicks = await db.userBehavior.count({
      where: { sessionId, eventType: 'CTA_CLICK' },
    })
    return clicks
  } catch {
    return 0
  }
}

async function countQuizCompletions(sessionId: string): Promise<number> {
  try {
    const completions = await db.userBehavior.count({
      where: { sessionId, eventType: 'QUIZ_COMPLETE' },
    })
    return completions
  } catch {
    return 0
  }
}

function inferGoal(clusterScores: Record<string, number>, searchQueries: Array<{ query: string; timestamp: string }>): string {
  const queries = searchQueries.map(sq => sq.query.toLowerCase()).join(' ')

  if (queries.includes('استخدام') || queries.includes('کار') || queries.includes('درآمد')) {
    return 'EMPLOYMENT'
  }
  if (queries.includes('تغییر') || queries.includes('مسیر') || queries.includes('شغل جدید')) {
    return 'CAREER_CHANGE'
  }
  if (queries.includes('ارتقا') || queries.includes('پیشرفت') || queries.includes('تخصص')) {
    return 'SKILL_UP'
  }
  if (queries.includes('کسب‌وکار') || queries.includes('استارتاپ') || queries.includes('کارآفرینی')) {
    return 'ENTREPRENEURSHIP'
  }
  if (queries.includes('سرمایه') || queries.includes('بورس') || queries.includes('فارکس')) {
    return 'INCOME'
  }

  // Infer from cluster scores
  const topCluster = Object.entries(clusterScores).sort(([, a], [, b]) => b - a)[0]
  if (topCluster) {
    if (topCluster[0] === 'entrepreneurship-and-business') return 'ENTREPRENEURSHIP'
    if (topCluster[0] === 'finance' || topCluster[0] === 'capital-market') return 'INCOME'
    if (topCluster[0] === 'it' || topCluster[0] === 'ai') return 'EMPLOYMENT'
  }

  return 'SKILL_UP'
}

function inferLevel(profile: { visitCount: number; quizResults: unknown; courseViews: unknown }): string {
  // PostgreSQL returns Json fields as parsed objects
  const courseViewsArr = Array.isArray(profile.courseViews) ? profile.courseViews : []
  const quizResultsArr = Array.isArray(profile.quizResults) ? profile.quizResults : []
  const courseViewsCount = courseViewsArr.length
  const quizResultsCount = quizResultsArr.length

  if (profile.visitCount > 15 || courseViewsCount > 5 || quizResultsCount > 1) {
    return 'INTERMEDIATE'
  }
  if (profile.visitCount > 5 || courseViewsCount > 2) {
    return 'BEGINNER_PLUS'
  }
  return 'BEGINNER'
}
