import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * POST /api/track
 * Receives client-side tracking events (replacement/supplement for GTM).
 * Stores events in EventLog table for analytics.
 *
 * Body: { event, event_id, event_timestamp, event_params?, page_url?, ... }
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      event,
      event_id,
      event_timestamp,
      event_params,
      page_url,
      page_title,
      referrer,
      utm_source,
      utm_medium,
      utm_campaign,
    } = body;

    if (!event) {
      return NextResponse.json({ error: 'رویداد الزامی است' }, { status: 400 });
    }

    // Map event names to EventLog categories
    const categoryMap: Record<string, string> = {
      form_submission: 'conversion',
      whatsapp_click: 'conversion',
      career_test_completed: 'engagement',
      page_view_pricing: 'engagement',
      page_view: 'navigation',
      cta_click: 'conversion',
    };

    const labelMap: Record<string, string> = {
      form_submission: event_params?.form_type || 'فرم',
      whatsapp_click: 'کلیک واتساپ',
      career_test_completed: `تست شغلی — نتیجه: ${event_params?.result_category || ''}`,
      page_view_pricing: 'مشاهده صفحه قیمت',
    };

    const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || '';
    const ua = request.headers.get('user-agent') || '';
    const sessionId = event_id?.split('_')[0] || '';

    await db.eventLog.create({
      data: {
        event: event,
        category: categoryMap[event] || 'engagement',
        label: labelMap[event] || event,
        page: page_url || '',
        referrer: referrer || '',
        sessionId,
        utmSource: utm_source || '',
        utmMedium: utm_medium || '',
        utmCampaign: utm_campaign || '',
        metadata: {
          event_id,
          event_timestamp,
          event_params: event_params || {},
          page_title: page_title || '',
        },
        ipAddress: ip,
        userAgent: ua,
      },
    });

    return NextResponse.json({ ok: true, event });
  } catch (error) {
    console.error('[Track API] Error:', error);
    return NextResponse.json({ ok: true });
  }
}