import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/marketplace — Public marketplace listing (approved apps only)
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const category = url.searchParams.get('category');
    const search = url.searchParams.get('search');
    const sort = url.searchParams.get('sort') || 'newest';

    const where: Record<string, unknown> = { status: 'APPROVED' };
    if (category) where.category = category;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
        { shortDesc: { contains: search } },
      ];
    }

    const orderBy: Record<string, string> =
      sort === 'popular' ? { downloads: 'desc' } :
      sort === 'rating' ? { rating: 'desc' } :
      sort === 'newest' ? { createdAt: 'desc' } :
      { createdAt: 'desc' };

    const apps = await db.marketplaceApp.findMany({
      where,
      select: {
        id: true,
        name: true,
        slug: true,
        shortDesc: true,
        category: true,
        iconUrl: true,
        pricingModel: true,
        price: true,
        monthlyPrice: true,
        downloads: true,
        rating: true,
        reviewCount: true,
        developerName: true,
        version: true,
        createdAt: true,
      },
      orderBy,
    });

    // Categories with counts
    const categories = await db.marketplaceApp.groupBy({
      by: ['category'],
      where: { status: 'APPROVED' },
      _count: true,
    });

    return NextResponse.json({ apps, categories });
  } catch (error: unknown) {
    console.error('Public marketplace error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اپلیکیشن‌ها' }, { status: 500 });
  }
}
