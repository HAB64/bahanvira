import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/marketplace/[slug] — Public app detail
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const app = await db.marketplaceApp.findUnique({
      where: { slug, status: 'APPROVED' },
      include: {
        reviews: {
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
        subscriptions: {
          where: { status: 'ACTIVE' },
          select: { id: true, plan: true },
        },
      },
    });

    if (!app) {
      return NextResponse.json({ error: 'اپلیکیشن یافت نشد' }, { status: 404 });
    }

    // Increment downloads counter
    await db.marketplaceApp.update({
      where: { id: app.id },
      data: { downloads: { increment: 1 } },
    });

    return NextResponse.json({ app });
  } catch (error: unknown) {
    console.error('Public marketplace app detail error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اپلیکیشن' }, { status: 500 });
  }
}
