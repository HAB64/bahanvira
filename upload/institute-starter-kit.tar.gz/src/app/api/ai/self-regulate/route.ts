import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { cycleType = 'DAILY' } = body as { cycleType?: string }

    const validCycleTypes = ['DAILY', 'WEEKLY', 'MONTHLY']
    if (!validCycleTypes.includes(cycleType)) {
      return NextResponse.json({ error: `cycleType باید یکی از ${validCycleTypes.join(', ')} باشد` }, { status: 400 })
    }

    // Compute current metrics
    const now = new Date()
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000)
    const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)

    // Total leads
    const totalLeads = await db.lead.count()

    // New leads in period
    const periodStart = cycleType === 'DAILY' ? oneDayAgo : oneWeekAgo
    const newLeads = await db.lead.count({
      where: { createdAt: { gte: periodStart } },
    })

    // Leads by stage
    const leadsByStage = await db.lead.groupBy({
      by: ['stage'],
      _count: { id: true },
    })

    // Conversion rate (ENROLLED / total)
    const enrolledCount = leadsByStage.find(s => s.stage === 'ENROLLED')?._count.id || 0
    const conversionRate = totalLeads > 0 ? (enrolledCount / totalLeads) * 100 : 0

    // Active sessions
    const activeSessions = await db.aIConsultationSession.count({
      where: { status: 'ACTIVE' },
    })

    // Completed consultations
    const completedConsultations = await db.aIConsultationSession.count({
      where: {
        status: 'COMPLETED',
        endedAt: { gte: periodStart },
      },
    })

    // Lead captures from consultation
    const leadCaptures = await db.aIConsultationSession.count({
      where: {
        leadCaptured: true,
        endedAt: { gte: periodStart },
      },
    })

    // User behavior stats
    const totalBehaviors = await db.userBehavior.count({
      where: { createdAt: { gte: periodStart } },
    })

    const uniqueVisitors = await db.userBehavior.findMany({
      where: { createdAt: { gte: periodStart } },
      select: { sessionId: true },
      distinct: ['sessionId'],
    })

    // Average engagement score
    const engagementScores = await db.personalizationProfile.findMany({
      select: { engagementScore: true },
    })
    const avgEngagement = engagementScores.length > 0
      ? engagementScores.reduce((sum, p) => sum + p.engagementScore, 0) / engagementScores.length
      : 0

    // Build metrics object
    const metrics = {
      totalLeads,
      newLeads,
      enrolledCount,
      conversionRate: Math.round(conversionRate * 100) / 100,
      activeSessions,
      completedConsultations,
      leadCaptures,
      totalBehaviors,
      uniqueVisitors: uniqueVisitors.length,
      avgEngagement: Math.round(avgEngagement * 1000) / 1000,
      leadsByStage: leadsByStage.map(s => ({ stage: s.stage, count: s._count.id })),
    }

    // Detect anomalies
    const anomalies: Array<{ type: string; description: string; severity: string }> = []

    // Check conversion rate drop
    if (conversionRate < 5 && totalLeads > 10) {
      anomalies.push({
        type: 'LOW_CONVERSION',
        description: `نرخ تبدیل پایین: ${conversionRate.toFixed(1)}% - نیاز به بررسی فرآیند فروش`,
        severity: 'HIGH',
      })
    }

    // Check engagement drop
    if (avgEngagement < 0.1 && engagementScores.length > 5) {
      anomalies.push({
        type: 'LOW_ENGAGEMENT',
        description: `میانگین تعامل پایین: ${avgEngagement.toFixed(2)} - نیاز به بهبود تجربه کاربری`,
        severity: 'MEDIUM',
      })
    }

    // Check if consultations not converting to leads
    if (completedConsultations > 5 && leadCaptures === 0) {
      anomalies.push({
        type: 'NO_LEAD_CAPTURE',
        description: 'مشاوره‌ها به لید تبدیل نمی‌شوند - نیاز به بهبود فرآیند ثبت‌نام',
        severity: 'HIGH',
      })
    }

    // Check high bounce rate
    const bounceRiskCount = await db.personalizationProfile.count({
      where: { engagementScore: { lt: 0.1 }, visitCount: { lt: 2 } },
    })
    if (bounceRiskCount > 3) {
      anomalies.push({
        type: 'HIGH_BOUNCE_RISK',
        description: `${bounceRiskCount} کاربر در معرض ترک سایت هستند`,
        severity: 'MEDIUM',
      })
    }

    // Take corrective actions
    const actions: Array<{ type: string; description: string; params: Record<string, unknown> }> = []

    for (const anomaly of anomalies) {
      switch (anomaly.type) {
        case 'LOW_CONVERSION':
          actions.push({
            type: 'TRIGGER_FOLLOW_UP',
            description: 'ارسال پیام پیگیری به لیدهای جدید',
            params: { targetStage: 'NEW', channel: 'SMS' },
          })
          break

        case 'LOW_ENGAGEMENT':
          actions.push({
            type: 'SHOW_RECOMMENDATIONS',
            description: 'نمایش پیشنهادات شخصی‌سازی‌شده به کاربران',
            params: { showPopup: true, showRecommendations: true },
          })
          break

        case 'NO_LEAD_CAPTURE':
          actions.push({
            type: 'IMPROVE_CTA',
            description: 'بهبود فراخوان عمل در مشاوره‌ها',
            params: { showLeadForm: true, offerFreeConsultation: true },
          })
          break

        case 'HIGH_BOUNCE_RISK':
          actions.push({
            type: 'TRIGGER_ENGAGEMENT',
            description: 'تحریک تعامل با پیشنهاد ویژه',
            params: { showExitIntent: true, offerDiscount: true },
          })
          break
      }
    }

    // ─── اجرای واقعی اقدامات اصلاحی (Effector) ───
    const executedActions: Array<{ type: string; result: string; success: boolean }> = []

    for (const action of actions) {
      try {
        switch (action.type) {
          case 'TRIGGER_FOLLOW_UP': {
            // پیدا کردن لیدهای جدید بدون پیگیری و ایجاد تسک پیگیری
            const newLeads = await db.lead.findMany({
              where: { stage: 'NEW', lastContactedAt: null },
              take: 20,
              select: { id: true, name: true, phone: true },
            })
            let followUpsCreated = 0
            for (const lead of newLeads) {
              // بررسی آیا تسک پیگیری قبلاً وجود دارد
              const existingTask = await db.crmTask.findFirst({
                where: { leadId: lead.id, title: { contains: 'پیگیری خودکار' } },
              })
              if (!existingTask) {
                await db.crmTask.create({
                  data: {
                    title: `پیگیری خودکار — ${lead.name}`,
                    description: `سیستم خودتنظیم: نرخ تبدیل پایین — لید ${lead.name} (${lead.phone}) پیگیری نشده است`,
                    status: 'PENDING',
                    priority: 'HIGH',
                    leadId: lead.id,
                    dueDate: new Date(now.getTime() + 24 * 60 * 60 * 1000), // فردا
                  },
                })
                followUpsCreated++
              }
            }
            executedActions.push({ type: action.type, result: `${followUpsCreated} تسک پیگیری ایجاد شد`, success: true })
            break
          }

          case 'SHOW_RECOMMENDATIONS': {
            // به‌روزرسانی پرچم‌های رفتاری برای نمایش پیشنهادات فعال
            const lowEngProfiles = await db.personalizationProfile.findMany({
              where: { engagementScore: { lt: 0.2 }, visitCount: { gte: 2 } },
              take: 50,
              select: { id: true },
            })
            let updatedCount = 0
            for (const profile of lowEngProfiles) {
              try {
                await db.personalizationProfile.update({
                  where: { id: profile.id },
                  data: {
                    // تنظیم پرچم نمایش پیشنهادات فعال
                    inferredGoal: 'ENGAGEMENT_BOOST',
                  },
                })
                updatedCount++
              } catch { /* skip */ }
            }
            executedActions.push({ type: action.type, result: `${updatedCount} پروفایل برای نمایش پیشنهادات فعال شد`, success: true })
            break
          }

          case 'IMPROVE_CTA': {
            // فعال‌سازی Exit Intent Popup با فرم لید برای نشست‌های مشاوره بدون لید
            const sessionsWithoutLead = await db.aIConsultationSession.findMany({
              where: { leadCaptured: false, status: 'ACTIVE' },
              take: 30,
              select: { id: true, sessionId: true },
            })
            // ثبت رویداد برای فرانت‌اند — نشست‌هایی که نیاز به CTA بهتر دارند
            let ctasTriggered = 0
            for (const session of sessionsWithoutLead) {
              try {
                await db.userBehavior.create({
                  data: {
                    sessionId: session.sessionId,
                    eventType: 'SYSTEM_ACTION',
                    page: '/chatbot',
                    metadata: { action: 'SHOW_LEAD_CTA', reason: 'no_lead_captured' },
                  },
                })
                ctasTriggered++
              } catch { /* skip */ }
            }
            executedActions.push({ type: action.type, result: `${ctasTriggered} نشست مشاوره CTA لید دریافت کردند`, success: true })
            break
          }

          case 'TRIGGER_ENGAGEMENT': {
            // ایجاد پیشنهاد ویژه برای کاربران در معرض ترک
            const atRiskProfiles = await db.personalizationProfile.findMany({
              where: { engagementScore: { lt: 0.1 }, visitCount: { lt: 2 } },
              take: 30,
              select: { id: true, sessionId: true },
            })
            let engagementTriggered = 0
            for (const profile of atRiskProfiles) {
              try {
                await db.userBehavior.create({
                  data: {
                    sessionId: profile.sessionId,
                    eventType: 'SYSTEM_ACTION',
                    page: '/',
                    metadata: { action: 'SHOW_EXIT_INTENT', reason: 'high_bounce_risk', offerDiscount: true },
                  },
                })
                engagementTriggered++
              } catch { /* skip */ }
            }
            executedActions.push({ type: action.type, result: `${engagementTriggered} کاربر در معرض ترک، Exit Intent فعال شد`, success: true })
            break
          }

          default:
            executedActions.push({ type: action.type, result: 'نوع اقدام ناشناخته', success: false })
        }
      } catch (actionError) {
        console.error(`Action ${action.type} failed:`, actionError)
        executedActions.push({ type: action.type, result: 'خطا در اجرای اقدام', success: false })
      }
    }

    // Log the self-regulation cycle
    try {
      await db.selfRegulationLog.create({
        data: {
          cycleType,
          metrics,
          anomalies: anomalies,
          actions: actions,
          startedAt: now,
          completedAt: new Date(),
        },
      })
    } catch (logError) {
      console.error('Self-regulation log error:', logError)
    }

    return NextResponse.json({
      success: true,
      cycleType,
      metrics,
      anomalies,
      actions,
      executedActions,
      timestamp: now.toISOString(),
    })
  } catch (error) {
    console.error('Self-regulation error:', error)
    return NextResponse.json({ error: 'خطا در چرخه خودتنظیمی' }, { status: 500 })
  }
}
