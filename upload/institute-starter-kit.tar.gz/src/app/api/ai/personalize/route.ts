import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { GROUPS, OCCUPATIONS } from '@/lib/skill-graph'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json({ error: 'sessionId الزامی است' }, { status: 400 })
    }

    // Load personalization profile
    const profile = await db.personalizationProfile.findUnique({
      where: { sessionId },
    })

    // Load recent behavior
    const recentBehaviors = await db.userBehavior.findMany({
      where: { sessionId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    // Build context for personalization — PostgreSQL returns Json fields as parsed objects
    const clusterScores = (profile?.clusterScores as Record<string, number>) || {}
    const courseViews = (profile?.courseViews as Array<{ slug: string; count: number; lastViewed: string }>) || []
    const searchQueries = (profile?.searchQueries as Array<{ query: string; timestamp: string }>) || []
    const quizResults = (profile?.quizResults as Array<{ quizId: string; answers: unknown; recommendedCluster: string; score: number }>) || []

    // Find top clusters
    const sortedClusters = Object.entries(clusterScores)
      .sort(([, a], [, b]) => b - a)

    // Generate recommendations
    let recommendations: Array<{
      step: number
      courseSlug: string
      courseTitle: string
      cluster: string
      clusterLabel: string
      reason: string
      confidence: number
    }> = []

    let path: Array<{
      step: number
      title: string
      description: string
      courses: string[]
    }> = []

    if (sortedClusters.length > 0) {
      try {
        const topCluster = sortedClusters[0][0]
        const clusterOccupations = OCCUPATIONS.filter(o => o.groupKey === topCluster)
        const foundationCourses = clusterOccupations.filter(o => o.level === 'FOUNDATION')
        const specializedCourses = clusterOccupations.filter(o => o.level === 'SPECIALIZED')
        const strategicCourses = clusterOccupations.filter(o => o.level === 'STRATEGIC')

        const viewedSlugs = courseViews.map(cv => cv.slug)
        const hasViewedFoundation = foundationCourses.some(fc => viewedSlugs.includes(fc.slug))
        const hasQuizResults = quizResults.length > 0

        let startLevel = 'FOUNDATION'
        if (hasQuizResults || hasViewedFoundation) startLevel = 'SPECIALIZED'
        if (courseViews.length > 5) startLevel = 'STRATEGIC'

        const steps = []

        if (startLevel === 'FOUNDATION' && foundationCourses.length > 0) {
          const course = foundationCourses[0]
          recommendations.push({
            step: 1,
            courseSlug: course.slug,
            courseTitle: course.title,
            cluster: topCluster,
            clusterLabel: GROUPS[topCluster as keyof typeof GROUPS]?.label || topCluster,
            reason: 'شروع مسیر یادگیری از پایه',
            confidence: 0.9,
          })
          steps.push({
            step: 1,
            title: 'پایه',
            description: 'یادگیری مفاهیم پایه',
            courses: foundationCourses.slice(0, 2).map(c => c.title),
          })
        }

        if ((startLevel === 'FOUNDATION' || startLevel === 'SPECIALIZED') && specializedCourses.length > 0) {
          const nextStep = recommendations.length + 1
          const unviewedSpecialized = specializedCourses.filter(sc => !viewedSlugs.includes(sc.slug))
          const course = unviewedSpecialized[0] || specializedCourses[0]
          recommendations.push({
            step: nextStep,
            courseSlug: course.slug,
            courseTitle: course.title,
            cluster: topCluster,
            clusterLabel: GROUPS[topCluster as keyof typeof GROUPS]?.label || topCluster,
            reason: 'توسعه مهارت‌های تخصصی',
            confidence: 0.8,
          })
          steps.push({
            step: nextStep,
            title: 'تخصصی',
            description: 'یادگیری مهارت‌های تخصصی',
            courses: specializedCourses.slice(0, 3).map(c => c.title),
          })
        }

        if (strategicCourses.length > 0) {
          const nextStep = recommendations.length + 1
          const course = strategicCourses[0]
          recommendations.push({
            step: nextStep,
            courseSlug: course.slug,
            courseTitle: course.title,
            cluster: topCluster,
            clusterLabel: GROUPS[topCluster as keyof typeof GROUPS]?.label || topCluster,
            reason: 'رسیدن به سطح استراتژیک و حرفه‌ای',
            confidence: 0.7,
          })
          steps.push({
            step: nextStep,
            title: 'استراتژیک',
            description: 'تسلط حرفه‌ای و سطح پیشرفته',
            courses: strategicCourses.slice(0, 2).map(c => c.title),
          })
        }

        path = steps

        // Add second cluster recommendations if available
        if (sortedClusters.length > 1) {
          const secondCluster = sortedClusters[1][0]
          const secondClusterCourses = OCCUPATIONS.filter(o => o.groupKey === secondCluster)
          const topCourse = secondClusterCourses[0]
          if (topCourse) {
            recommendations.push({
              step: recommendations.length + 1,
              courseSlug: topCourse.slug,
              courseTitle: topCourse.title,
              cluster: secondCluster,
              clusterLabel: GROUPS[secondCluster as keyof typeof GROUPS]?.label || secondCluster,
              reason: `علاقه دوم شما: ${GROUPS[secondCluster as keyof typeof GROUPS]?.label || secondCluster}`,
              confidence: 0.6,
            })
          }
        }
      } catch (err) {
        console.error('Personalization error:', err)
      }
    }

    // If no cluster data yet, provide general recommendations
    if (recommendations.length === 0) {
      const popularCourses = ['icdl', 'python', 'forex-fundamentals', 'scratch', 'photoshop', 'entrepreneurship']
      for (let i = 0; i < Math.min(3, popularCourses.length); i++) {
        const occ = OCCUPATIONS.find(o => o.slug === popularCourses[i])
        if (occ) {
          recommendations.push({
            step: i + 1,
            courseSlug: occ.slug,
            courseTitle: occ.title,
            cluster: occ.groupKey,
            clusterLabel: GROUPS[occ.groupKey as keyof typeof GROUPS]?.label || occ.groupKey,
            reason: 'دوره محبوب و پرتقاضا',
            confidence: 0.5,
          })
        }
      }

      path = [{
        step: 1,
        title: 'شروع',
        description: 'با آزمون مسیر شغلی، بهترین مسیر را پیدا کنید',
        courses: recommendations.map(r => r.courseTitle),
      }]
    }

    // Try AI-powered personalization
    try {
      if (recentBehaviors.length > 3 || searchQueries.length > 0) {
        const ZAI = (await import('z-ai-web-dev-sdk')).default
        const zai = await ZAI.create()

        const behaviorSummary = `بازدیدها: ${profile?.visitCount || 0}, دوره‌های مشاهده: ${courseViews.length}, جستجوها: ${searchQueries.map(sq => sq.query).join(', ')}, خوشه‌های علاقه: ${sortedClusters.map(([k, v]) => `${GROUPS[k as keyof typeof GROUPS]?.label || k}(${v})`).join(', ')}`

        const aiCompletion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: 'تو یک سیستم شخصی‌سازی مسیر شغلی هستی. بر اساس رفتار کاربر، بهترین مسیر یادگیری را پیشنهاد بده. فقط نام دوره‌ها را با کاما جدا کن. حداکثر ۵ دوره.',
            },
            {
              role: 'user',
              content: `رفتار کاربر: ${behaviorSummary}. سه دوره برتر پیشنهاد بده.`,
            },
          ],
        })

        const aiSuggestion = aiCompletion.choices?.[0]?.message?.content || ''
        if (aiSuggestion) {
          for (const rec of recommendations.slice(0, 2)) {
            rec.reason = `بر اساس تحلیل رفتار شما: ${aiSuggestion.substring(0, 100)}`
          }
        }
      }
    } catch (aiError) {
      console.error('AI personalization fallback:', aiError)
    }

    // Update profile with recommendations
    try {
      if (profile) {
        await db.personalizationProfile.update({
          where: { sessionId },
          data: {
            recommendedPath: recommendations.map(r => ({
              step: r.step,
              courseSlug: r.courseSlug,
              reason: r.reason,
              confidence: r.confidence,
            })),
            lastPersonalizedAt: new Date(),
            inferredGoal: profile.inferredGoal || (sortedClusters.length > 0 ? 'SKILL_UP' : null),
          },
        })
      }
    } catch (updateError) {
      console.error('Profile update error:', updateError)
    }

    return NextResponse.json({
      recommendations,
      path,
      profile: profile ? {
        sessionId: profile.sessionId,
        clusterScores,
        visitCount: profile.visitCount,
        inferredGoal: profile.inferredGoal,
        inferredLevel: profile.inferredLevel,
        engagementScore: profile.engagementScore,
      } : null,
    })
  } catch (error) {
    console.error('AI personalize error:', error)
    return NextResponse.json({ error: 'خطا در شخصی‌سازی' }, { status: 500 })
  }
}
