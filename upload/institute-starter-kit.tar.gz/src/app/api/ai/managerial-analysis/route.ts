/**
 * Managerial Analysis API — تحلیل مدیریتی واقعی بر اساس داده دیتابیس
 * فاز ۴: سیستم سایبرنتیک آموزشی
 *
 * تحلیل جامع شامل:
 * - سلامت قیف فروش (Pipeline Health)
 * - بازگشت سرمایه (ROI Estimation)
 * - شناسایی گلوگاه‌ها
 * - پیشنهادات اجرایی برای مدیر
 * - تحلیل خوشه‌ها و منابع جذب
 */
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// ─── Types ──────────────────────────────────────────────────

interface PipelineStage {
  stage: string
  stageLabel: string
  count: number
  percentage: number
  avgDaysInStage: number
  conversionToNext: number
}

interface UTMAnalysis {
  source: string
  leads: number
  conversions: number
  conversionRate: number
  avgScore: number
  topCluster: string
}

interface ClusterAnalysis {
  cluster: string
  label: string
  leads: number
  enrolled: number
  conversionRate: number
  avgScore: number
  revenue: number
}

interface ManagerialReport {
  // Pipeline
  pipelineStages: PipelineStage[]
  pipelineHealth: 'healthy' | 'warning' | 'critical'
  pipelineScore: number

  // ROI
  totalLeads: number
  totalEnrolled: number
  overallConversionRate: number
  estimatedRevenue: number
  costPerLead: number
  costPerAcquisition: number
  roiScore: number

  // UTM & Marketing
  utmAnalysis: UTMAnalysis[]
  topUTMSource: string

  // Cluster Performance
  clusterAnalysis: ClusterAnalysis[]
  bestPerformingCluster: string

  // Bottlenecks
  bottlenecks: string[]
  bottleneckCount: number

  // Actionable Recommendations
  recommendations: string[]
  priority: string

  // Timing
  avgTimeToConvert: number
  bestConversionDay: string
  peakHours: number[]

  // Self-Regulation Status
  lastSelfRegulation: string | null
  selfRegulationCycles: number
  actionsExecuted: number

  // Generated At
  generatedAt: string
  isRealData: boolean
}

const STAGE_LABELS: Record<string, string> = {
  NEW: 'جدید',
  CONTACTED: 'تماس گرفته شده',
  INTERESTED: 'علاقه‌مند',
  ENROLLED: 'ثبت‌نام شده',
  REJECTED: 'رد شده',
  ARCHIVED: 'بایگانی',
}

const CLUSTER_LABELS: Record<string, string> = {
  'tech-ai': 'فناوری و هوش مصنوعی',
  'financial': 'بازار سرمایه و مالی',
  'management': 'مدیریت و کسب‌وکار',
  'entrepreneurship': 'کارآفرینی',
  '': 'بدون خوشه',
}

// ─── Pipeline Analysis ──────────────────────────────────────

async function analyzePipeline(): Promise<{
  stages: PipelineStage[]
  health: 'healthy' | 'warning' | 'critical'
  score: number
}> {
  const allLeads = await db.lead.findMany({
    select: {
      stage: true,
      createdAt: true,
      lastContactedAt: true,
      score: true,
    },
    orderBy: { createdAt: 'asc' },
  })

  const total = allLeads.length
  if (total === 0) {
    return {
      stages: [],
      health: 'warning',
      score: 50,
    }
  }

  // Group by stage
  const stageMap = new Map<string, { count: number; totalDays: number; dates: Date[] }>()
  const stageOrder = ['NEW', 'CONTACTED', 'INTERESTED', 'ENROLLED']

  for (const lead of allLeads) {
    const data = stageMap.get(lead.stage) || { count: 0, totalDays: 0, dates: [] }
    data.count++

    // Calculate days in current stage
    const ref = lead.lastContactedAt || lead.createdAt
    const days = Math.max(1, Math.round((Date.now() - ref.getTime()) / (1000 * 60 * 60 * 24)))
    data.totalDays += days
    data.dates.push(lead.createdAt)

    stageMap.set(lead.stage, data)
  }

  const stages: PipelineStage[] = []
  for (let i = 0; i < stageOrder.length; i++) {
    const stage = stageOrder[i]
    const data = stageMap.get(stage) || { count: 0, totalDays: 0, dates: [] }
    const nextStage = stageOrder[i + 1]
    const nextData = nextStage ? (stageMap.get(nextStage) || { count: 0 }) : { count: 0 }

    stages.push({
      stage,
      stageLabel: STAGE_LABELS[stage] || stage,
      count: data.count,
      percentage: Math.round((data.count / total) * 1000) / 10,
      avgDaysInStage: data.count > 0 ? Math.round(data.totalDays / data.count) : 0,
      conversionToNext: data.count > 0
        ? Math.round((nextData.count / data.count) * 1000) / 10
        : 0,
    })
  }

  // Add REJECTED and ARCHIVED
  for (const stage of ['REJECTED', 'ARCHIVED']) {
    const data = stageMap.get(stage) || { count: 0, totalDays: 0, dates: [] }
    stages.push({
      stage,
      stageLabel: STAGE_LABELS[stage] || stage,
      count: data.count,
      percentage: Math.round((data.count / total) * 1000) / 10,
      avgDaysInStage: data.count > 0 ? Math.round(data.totalDays / data.count) : 0,
      conversionToNext: 0,
    })
  }

  // Health assessment
  const newLeads = stageMap.get('NEW')?.count || 0
  const enrolled = stageMap.get('ENROLLED')?.count || 0
  const interested = stageMap.get('INTERESTED')?.count || 0
  const contacted = stageMap.get('CONTACTED')?.count || 0

  let score = 50

  // Conversion from NEW to CONTACTED
  if (newLeads > 0) {
    const newToContacted = contacted / newLeads
    if (newToContacted > 0.5) score += 15
    else if (newToContacted > 0.3) score += 8
    else score -= 10
  }

  // Conversion from CONTACTED to INTERESTED
  if (contacted > 0) {
    const contactedToInterested = interested / contacted
    if (contactedToInterested > 0.4) score += 15
    else if (contactedToInterested > 0.2) score += 8
    else score -= 10
  }

  // Conversion from INTERESTED to ENROLLED
  if (interested > 0) {
    const interestedToEnrolled = enrolled / interested
    if (interestedToEnrolled > 0.3) score += 15
    else if (interestedToEnrolled > 0.15) score += 8
    else score -= 10
  }

  // Overall conversion rate
  const overallRate = total > 0 ? enrolled / total : 0
  if (overallRate > 0.2) score += 10
  else if (overallRate > 0.1) score += 5

  score = Math.max(0, Math.min(100, score))

  const health: 'healthy' | 'warning' | 'critical' =
    score >= 65 ? 'healthy' : score >= 40 ? 'warning' : 'critical'

  return { stages, health, score }
}

// ─── ROI Analysis ───────────────────────────────────────────

async function analyzeROI(): Promise<{
  totalLeads: number
  totalEnrolled: number
  overallConversionRate: number
  estimatedRevenue: number
  costPerLead: number
  costPerAcquisition: number
  roiScore: number
}> {
  const totalLeads = await db.lead.count()
  const totalEnrolled = await db.lead.count({ where: { stage: 'ENROLLED' } })
  const overallConversionRate = totalLeads > 0
    ? Math.round((totalEnrolled / totalLeads) * 1000) / 10
    : 0

  // Estimate average course price (in toman) — based on Iranian market
  const avgCoursePrice = 5_000_000 // 5M toman average
  const estimatedRevenue = totalEnrolled * avgCoursePrice

  // Assume basic marketing cost (website hosting + basic ads)
  const estimatedMarketingCost = 2_000_000 // 2M toman monthly estimate
  const costPerLead = totalLeads > 0 ? Math.round(estimatedMarketingCost / totalLeads) : 0
  const costPerAcquisition = totalEnrolled > 0 ? Math.round(estimatedMarketingCost / totalEnrolled) : 0

  // ROI Score (0-100)
  let roiScore = 50
  if (overallConversionRate > 15) roiScore += 20
  else if (overallConversionRate > 8) roiScore += 10
  else roiScore -= 10

  if (costPerAcquisition > 0 && costPerAcquisition < avgCoursePrice * 0.3) roiScore += 15
  else if (costPerAcquisition > 0 && costPerAcquisition < avgCoursePrice * 0.5) roiScore += 8

  if (totalEnrolled > 5) roiScore += 10
  else if (totalEnrolled > 0) roiScore += 5

  roiScore = Math.max(0, Math.min(100, roiScore))

  return {
    totalLeads,
    totalEnrolled,
    overallConversionRate,
    estimatedRevenue,
    costPerLead,
    costPerAcquisition,
    roiScore,
  }
}

// ─── UTM Analysis ───────────────────────────────────────────

async function analyzeUTM(): Promise<{
  analysis: UTMAnalysis[]
  topSource: string
}> {
  const leads = await db.lead.findMany({
    where: { utmSource: { not: '' } },
    select: {
      utmSource: true,
      stage: true,
      score: true,
      cluster: true,
    },
  })

  const sourceMap = new Map<string, { leads: number; conversions: number; totalScore: number; clusters: Map<string, number> }>()

  for (const lead of leads) {
    const data = sourceMap.get(lead.utmSource) || {
      leads: 0, conversions: 0, totalScore: 0, clusters: new Map<string, number>(),
    }
    data.leads++
    if (lead.stage === 'ENROLLED') data.conversions++
    data.totalScore += lead.score
    if (lead.cluster) {
      data.clusters.set(lead.cluster, (data.clusters.get(lead.cluster) || 0) + 1)
    }
    sourceMap.set(lead.utmSource, data)
  }

  const analysis: UTMAnalysis[] = []
  for (const [source, data] of sourceMap) {
    // Find top cluster
    let topCluster = ''
    let topCount = 0
    for (const [cluster, count] of data.clusters) {
      if (count > topCount) {
        topCount = count
        topCluster = cluster
      }
    }

    analysis.push({
      source,
      leads: data.leads,
      conversions: data.conversions,
      conversionRate: Math.round((data.conversions / data.leads) * 1000) / 10,
      avgScore: Math.round(data.totalScore / data.leads),
      topCluster,
    })
  }

  analysis.sort((a, b) => b.leads - a.leads)

  return {
    analysis,
    topSource: analysis.length > 0 ? analysis[0].source : 'نامشخص',
  }
}

// ─── Cluster Analysis ───────────────────────────────────────

async function analyzeClusters(): Promise<{
  analysis: ClusterAnalysis[]
  bestCluster: string
}> {
  const leads = await db.lead.findMany({
    select: {
      cluster: true,
      stage: true,
      score: true,
      lifetimeValue: true,
    },
  })

  const clusterMap = new Map<string, { leads: number; enrolled: number; totalScore: number; revenue: number }>()

  for (const lead of leads) {
    const cluster = lead.cluster || ''
    const data = clusterMap.get(cluster) || { leads: 0, enrolled: 0, totalScore: 0, revenue: 0 }
    data.leads++
    if (lead.stage === 'ENROLLED') data.enrolled++
    data.totalScore += lead.score
    data.revenue += lead.lifetimeValue
    clusterMap.set(cluster, data)
  }

  const analysis: ClusterAnalysis[] = []
  for (const [cluster, data] of clusterMap) {
    analysis.push({
      cluster,
      label: CLUSTER_LABELS[cluster] || cluster,
      leads: data.leads,
      enrolled: data.enrolled,
      conversionRate: Math.round((data.enrolled / data.leads) * 1000) / 10,
      avgScore: Math.round(data.totalScore / data.leads),
      revenue: data.revenue,
    })
  }

  analysis.sort((a, b) => b.conversionRate - a.conversionRate)

  return {
    analysis,
    bestCluster: analysis.length > 0 ? analysis[0].cluster : 'نامشخص',
  }
}

// ─── Bottleneck Detection ───────────────────────────────────

async function detectBottlenecks(pipelineStages: PipelineStage[]): Promise<string[]> {
  const bottlenecks: string[] = []

  for (let i = 0; i < pipelineStages.length; i++) {
    const stage = pipelineStages[i]
    if (stage.stage === 'REJECTED' || stage.stage === 'ARCHIVED') continue

    if (stage.count > 5 && stage.conversionToNext < 10) {
      bottlenecks.push(
        `گلوگاه در مرحله "${stage.stageLabel}": ${stage.count} لید با نرخ انتقال ${stage.conversionToNext}% — نیاز به بررسی فرآیند پیگیری`
      )
    }

    if (stage.avgDaysInStage > 14 && stage.stage !== 'NEW') {
      bottlenecks.push(
        `تأخیر در مرحله "${stage.stageLabel}": میانگین ${stage.avgDaysInStage} روز — لیدها بیش از حد در این مرحله مانده‌اند`
      )
    }
  }

  return bottlenecks
}

// ─── Timing Analysis ────────────────────────────────────────

async function analyzeTiming(): Promise<{
  avgTimeToConvert: number
  bestDay: string
  peakHours: number[]
}> {
  const enrolledLeads = await db.lead.findMany({
    where: { stage: 'ENROLLED' },
    select: { createdAt: true, lastContactedAt: true },
  })

  // Average time to convert
  let avgTimeToConvert = 0
  if (enrolledLeads.length > 0) {
    const totalDays = enrolledLeads.reduce((sum, lead) => {
      const ref = lead.lastContactedAt || lead.createdAt
      return sum + Math.max(1, Math.round((Date.now() - ref.getTime()) / (1000 * 60 * 60 * 24)))
    }, 0)
    avgTimeToConvert = Math.round(totalDays / enrolledLeads.length)
  }

  // Best conversion day
  const dayCounts = new Map<string, number>()
  const dayNames = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه']
  for (const lead of enrolledLeads) {
    const dayIndex = lead.createdAt.getDay()
    const dayName = dayNames[dayIndex]
    dayCounts.set(dayName, (dayCounts.get(dayName) || 0) + 1)
  }

  let bestDay = 'نامشخص'
  let maxCount = 0
  for (const [day, count] of dayCounts) {
    if (count > maxCount) {
      maxCount = count
      bestDay = day
    }
  }

  // Peak hours (based on all leads creation time)
  const allLeads = await db.lead.findMany({
    select: { createdAt: true },
    take: 500,
  })

  const hourCounts = new Array(24).fill(0)
  for (const lead of allLeads) {
    hourCounts[lead.createdAt.getHours()]++
  }

  const peakHours: number[] = []
  const maxHour = Math.max(...hourCounts)
  if (maxHour > 0) {
    for (let h = 0; h < 24; h++) {
      if (hourCounts[h] >= maxHour * 0.7) {
        peakHours.push(h)
      }
    }
  }

  return { avgTimeToConvert, bestDay, peakHours }
}

// ─── Recommendations Engine ─────────────────────────────────

function generateRecommendations(
  pipeline: Awaited<ReturnType<typeof analyzePipeline>>,
  roi: Awaited<ReturnType<typeof analyzeROI>>,
  utm: Awaited<ReturnType<typeof analyzeUTM>>,
  clusters: Awaited<ReturnType<typeof analyzeClusters>>,
  bottlenecks: string[],
): { recommendations: string[]; priority: string } {
  const recommendations: string[] = []

  // Pipeline recommendations
  if (pipeline.health === 'critical') {
    recommendations.push('🔴 فوری: قیف فروش در وضعیت بحرانی است. تعداد لیدهای جدید افزایش یابد و فرآیند پیگیری تسریع شود.')
  }

  const newStage = pipeline.stages.find(s => s.stage === 'NEW')
  if (newStage && newStage.count > 10 && newStage.conversionToNext < 30) {
    recommendations.push(
      `⚠️ ${newStage.count} لید جدید بدون تماس هستند. پیگیری در کمتر از ۲۴ ساعت اولویت دارد.`
    )
  }

  // ROI recommendations
  if (roi.overallConversionRate < 10) {
    recommendations.push(
      '📉 نرخ تبدیل کلی زیر ۱۰% است. بررسی کیفیت لیدها و بهبود فرآیند مشاوره پیشنهاد می‌شود.'
    )
  }

  if (utm.topSource && utm.analysis.length > 0) {
    const top = utm.analysis[0]
    if (top.conversionRate > 15) {
      recommendations.push(
        `✅ منبع ${top.source} بالاترین نرخ تبدیل (${top.conversionRate}%) را دارد. سرمایه‌گذاری روی این کانال افزایش یابد.`
      )
    }
  }

  // Cluster recommendations
  if (clusters.analysis.length >= 2) {
    const worst = clusters.analysis[clusters.analysis.length - 1]
    if (worst.leads > 3 && worst.conversionRate < 5) {
      recommendations.push(
        `📊 خوشه "${worst.label}" نرخ تبدیل بسیار پایین دارد (${worst.conversionRate}%). بررسی محتوا و پیشنهادات این خوشه ضروری است.`
      )
    }
  }

  // Bottleneck recommendations (already in Persian)
  recommendations.push(...bottlenecks.slice(0, 2))

  // Priority
  const priority = bottlenecks.length > 2
    ? 'بالا — گلوگاه‌های متعدد شناسایی شده'
    : pipeline.health === 'critical'
      ? 'بالا — قیف فروش بحرانی'
      : roi.overallConversionRate < 10
        ? 'متوسط — نرخ تبدیل پایین'
        : 'پایین — سیستم در وضعیت پایدار'

  return { recommendations: recommendations.slice(0, 8), priority }
}

// ─── Main Handler ───────────────────────────────────────────

export async function GET() {
  try {
    // Run all analyses in parallel
    const [pipeline, roi, utm, clusters, timing, selfRegLogs] = await Promise.all([
      analyzePipeline(),
      analyzeROI(),
      analyzeUTM(),
      analyzeClusters(),
      analyzeTiming(),
      db.selfRegulationLog.count(),
    ])

    // Detect bottlenecks
    const bottlenecks = await detectBottlenecks(pipeline.stages)

    // Generate recommendations
    const { recommendations, priority } = generateRecommendations(pipeline, roi, utm, clusters, bottlenecks)

    // Count executed actions from self-regulation
    let actionsExecuted = 0
    try {
      const recentLogs = await db.selfRegulationLog.findMany({
        orderBy: { startedAt: 'desc' },
        take: 5,
        select: { actions: true },
      })
      for (const log of recentLogs) {
        const actions = (log.actions as Array<{ type: string }>) || []
        actionsExecuted += actions.length
      }
    } catch { /* ignore */ }

    // Last self-regulation time
    let lastSelfRegulation: string | null = null
    try {
      const lastLog = await db.selfRegulationLog.findFirst({
        orderBy: { startedAt: 'desc' },
        select: { startedAt: true },
      })
      lastSelfRegulation = lastLog?.startedAt?.toISOString() || null
    } catch { /* ignore */ }

    const report: ManagerialReport = {
      pipelineStages: pipeline.stages,
      pipelineHealth: pipeline.health,
      pipelineScore: pipeline.score,
      totalLeads: roi.totalLeads,
      totalEnrolled: roi.totalEnrolled,
      overallConversionRate: roi.overallConversionRate,
      estimatedRevenue: roi.estimatedRevenue,
      costPerLead: roi.costPerLead,
      costPerAcquisition: roi.costPerAcquisition,
      roiScore: roi.roiScore,
      utmAnalysis: utm.analysis,
      topUTMSource: utm.topSource,
      clusterAnalysis: clusters.analysis,
      bestPerformingCluster: clusters.bestCluster,
      bottlenecks,
      bottleneckCount: bottlenecks.length,
      recommendations,
      priority,
      avgTimeToConvert: timing.avgTimeToConvert,
      bestConversionDay: timing.bestDay,
      peakHours: timing.peakHours,
      lastSelfRegulation,
      selfRegulationCycles: selfRegLogs,
      actionsExecuted,
      generatedAt: new Date().toISOString(),
      isRealData: true,
    }

    return NextResponse.json(report)
  } catch (error) {
    console.error('[ManagerialAnalysis Error]', error)
    return NextResponse.json(
      { error: 'خطا در تحلیل مدیریتی', details: String(error) },
      { status: 500 }
    )
  }
}