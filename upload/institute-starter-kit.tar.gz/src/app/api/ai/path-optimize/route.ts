/**
 * Path Optimization API — بهینه‌سازی مسیر کاربران بر اساس داده واقعی
 * فاز ۴: سیستم سایبرنتیک آموزشی
 *
 * POST /api/ai/path-optimize
 * GET /api/ai/path-optimize (cached result)
 */
import { NextRequest, NextResponse } from 'next/server'
import { runPathOptimization, analyzeConversionPaths } from '@/lib/path-optimizer'
import { db } from '@/lib/db'

// Cache for periodic analysis (avoid DB heavy queries on every request)
let cachedResult: string | null = null
let cacheTimestamp = 0
const CACHE_TTL = 10 * 60 * 1000 // 10 minutes

export async function GET() {
  try {
    // Return cached result if fresh
    if (cachedResult && Date.now() - cacheTimestamp < CACHE_TTL) {
      return NextResponse.json({
        ...JSON.parse(cachedResult),
        fromCache: true,
      })
    }

    const result = await runPathOptimization(30)
    cachedResult = JSON.stringify(result)
    cacheTimestamp = Date.now()

    return NextResponse.json({ ...result, fromCache: false })
  } catch (error) {
    console.error('[PathOptimize Error]', error)
    return NextResponse.json(
      { error: 'خطا در تحلیل مسیرها', details: String(error) },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { days = 30, forceRefresh = false } = body as { days?: number; forceRefresh?: boolean }

    // Force refresh if requested
    if (forceRefresh) {
      cachedResult = null
    }

    const result = await runPathOptimization(days)

    // Store the analysis result in BehaviorPattern table for persistence
    try {
      await db.behaviorPattern.upsert({
        where: {
          id: 'path-optimization-latest',
        },
        create: {
          id: 'path-optimization-latest',
          patternType: 'PATH_OPTIMIZATION',
          patternData: JSON.parse(JSON.stringify(result)) as any,
          confidence: result.pathEfficiencyScore / 100,
          sampleSize: result.totalSessions,
          optimizedAction: result.recommendations[0] || null,
          actionParams: { bottlenecks: result.bottlenecks.length, recommendations: result.recommendations.length },
          lastObservedAt: new Date(),
        },
        update: {
          patternData: JSON.parse(JSON.stringify(result)) as any,
          confidence: result.pathEfficiencyScore / 100,
          sampleSize: result.totalSessions,
          optimizedAction: result.recommendations[0] || null,
          actionParams: { bottlenecks: result.bottlenecks.length, recommendations: result.recommendations.length },
          lastObservedAt: new Date(),
        },
      })
    } catch (dbError) {
      console.warn('[PathOptimize] Could not persist result:', dbError)
    }

    // Invalidate cache
    cachedResult = JSON.stringify(result)
    cacheTimestamp = Date.now()

    return NextResponse.json(result)
  } catch (error) {
    console.error('[PathOptimize Error]', error)
    return NextResponse.json(
      { error: 'خطا در بهینه‌سازی مسیرها', details: String(error) },
      { status: 500 }
    )
  }
}