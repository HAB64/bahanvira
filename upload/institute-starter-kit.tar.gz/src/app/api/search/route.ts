/**
 * Unified Search API — جستجوی یکپارچه
 * جستجو در دوره‌ها، خوشه‌ها، مسیرهای شغلی، و بلاگ
 */
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { SKILL_GRAPH, CLUSTERS, type ClusterKey } from '@/lib/skill-graph';

const CAREER_PATHS = [
  { label: 'کارجو و ورود به بازار کار', href: '/courses?goal=employment', keywords: ['استخدام', 'کار', 'کارجو', 'ورود بازار'] },
  { label: 'ارتقای مهارت شغلی', href: '/courses?goal=skill-up', keywords: ['ارتقا', 'تخصص', 'پیشرفت', 'مهارت'] },
  { label: 'درآمد دلاری و بین‌المللی', href: '/courses?cluster=financial', keywords: ['دلار', 'درآمد', 'فارکس', 'ترید', 'بین‌المللی'] },
  { label: 'کارآفرینی و راه‌اندازی کسب‌وکار', href: '/courses?goal=entrepreneurship', keywords: ['کارآفرینی', 'استارتاپ', 'کسب‌وکار', 'خوداشتغالی'] },
];

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get('q')?.trim();
  if (!q || q.length < 1) {
    return NextResponse.json({ results: [], query: '' });
  }

  const query = q.toLowerCase();
  const results: Array<{
    type: 'course' | 'cluster' | 'career' | 'blog';
    title: string;
    description: string;
    href: string;
    icon: string;
    color?: string;
  }> = [];

  // 1. Search Skill Graph (courses)
  for (const program of SKILL_GRAPH) {
    const tagMatch = program.tags.some(tag =>
      tag.toLowerCase().includes(query) || query.includes(tag.toLowerCase())
    );
    const titleMatch = program.title.toLowerCase().includes(query);
    const descMatch = program.description.toLowerCase().includes(query);

    if (tagMatch || titleMatch || descMatch) {
      results.push({
        type: 'course',
        title: program.title,
        description: program.description,
        href: `/courses/${program.slug}`,
        icon: 'BookOpen',
        color: CLUSTERS[program.cluster].color,
      });
    }
  }

  // 2. Search Clusters
  for (const [key, cluster] of Object.entries(CLUSTERS) as [ClusterKey, typeof CLUSTERS[ClusterKey]][]) {
    if (cluster.label.toLowerCase().includes(query) || cluster.description.toLowerCase().includes(query)) {
      results.push({
        type: 'cluster',
        title: cluster.label,
        description: cluster.description,
        href: `/courses?cluster=${key}`,
        icon: 'Layers',
        color: cluster.color,
      });
    }
  }

  // 3. Search Career Paths
  for (const path of CAREER_PATHS) {
    const kwMatch = path.keywords.some(kw => kw.includes(query) || query.includes(kw));
    const labelMatch = path.label.toLowerCase().includes(query);
    if (kwMatch || labelMatch) {
      results.push({
        type: 'career',
        title: path.label,
        description: `مسیر شغلی — ${path.keywords.slice(0, 3).join('، ')}`,
        href: path.href,
        icon: 'Compass',
      });
    }
  }

  // 4. Search Blog Posts
  try {
    const blogs = await db.blogPost.findMany({
      where: {
        published: true,
        OR: [
          { title: { contains: q, mode: 'insensitive' } },
          { excerpt: { contains: q, mode: 'insensitive' } },
        ],
      },
      take: 5,
      select: { title: true, slug: true, excerpt: true },
    });
    for (const blog of blogs) {
      results.push({
        type: 'blog',
        title: blog.title,
        description: blog.excerpt || '',
        href: `/blog/${blog.slug}`,
        icon: 'FileText',
      });
    }
  } catch {
    // Blog table may not exist
  }

  // Sort: career first, then cluster, then course, then blog
  const typeOrder = { career: 0, cluster: 1, course: 2, blog: 3 };
  results.sort((a, b) => typeOrder[a.type] - typeOrder[b.type]);

  return NextResponse.json({
    results: results.slice(0, 12),
    query: q,
    total: results.length,
  });
}
