import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json({ error: 'شناسه نشست الزامی است' }, { status: 400 })
    }

    const session = await db.aIConsultationSession.findFirst({
      where: { sessionId, status: 'ACTIVE' },
      include: {
        messages: { orderBy: { createdAt: 'asc' } },
      },
    })

    if (!session) {
      return NextResponse.json({ session: null, messages: [] })
    }

    return NextResponse.json({
      session: {
        id: session.id,
        status: session.status,
        subject: session.subject,
        cluster: session.cluster,
        suggestedCourses: session.suggestedCourses,
        startedAt: session.startedAt,
      },
      messages: session.messages.map(m => ({
        id: m.id,
        role: m.role,
        content: m.content,
        suggestedCourses: m.suggestedCourses,
        createdAt: m.createdAt,
      })),
    })
  } catch (error) {
    console.error('Get session error:', error)
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات نشست' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const sessionId = searchParams.get('sessionId')

    if (!sessionId) {
      return NextResponse.json({ error: 'شناسه نشست الزامی است' }, { status: 400 })
    }

    const session = await db.aIConsultationSession.findFirst({
      where: { sessionId, status: 'ACTIVE' },
    })

    if (!session) {
      return NextResponse.json({ error: 'نشست فعال یافت نشد' }, { status: 404 })
    }

    await db.aIConsultationSession.update({
      where: { id: session.id },
      data: {
        status: 'COMPLETED',
        endedAt: new Date(),
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('End session error:', error)
    return NextResponse.json({ error: 'خطا در پایان نشست' }, { status: 500 })
  }
}
