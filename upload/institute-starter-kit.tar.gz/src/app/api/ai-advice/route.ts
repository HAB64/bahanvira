import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { question, context } = body as {
      question: string
      context?: { age?: number; currentSkill?: string; goal?: string }
    }

    if (!question || typeof question !== 'string') {
      return NextResponse.json(
        { خطا: 'سوال الزامی است' },
        { status: 400 }
      )
    }

    // Build context-aware system prompt
    let systemPrompt = `تو یک مشاور آموزشی حرفه‌ای در موسسه بهان رایانه با ۲۷ سال سابقه هستی. به سوالات درباره مسیرهای یادگیری، انتخاب دوره، و توسعه مهارت پاسخ بده. پاسخ‌ها باید مختصر، کاربردی و مسیرمحور باشند.

موسسه بهان رایانه در ۳ خوشه و ۸ گروه آموزشی دوره ارائه می‌دهد:
خوشه خدمات:
۱. فن آوری اطلاعات: ICDL، Scratch، پایتون، جاوا، سی‌شارپ، متلب، هوش مصنوعی، یادگیری ماشین، علم داده
۲. امور مالی و بازرگانی: حسابداری، فارکس، MQL5، بازار سرمایه، تحلیل تکنیکال و بنیادی، کارآفرینی، مشاوره کسب‌وکار
۳. خدمات آموزشی: پداگوژی، فن بیان، طراحی دوره آموزشی
۴. خدمات حقوقی: قراردادنویسی، مشاور حقوقی، نگارش قضایی
خوشه صنعت:
۵. معماری: اتوکد سه‌بعدی، طراحی داخلی
۶. ساختمان: نقشه‌کشی، AutoCAD، 3D Max
خوشه فرهنگ و هنر:
۷. صنایع پوشاک: خیاطی، الگوکشی، طراحی لباس
۸. هنرهای تجسمی: فتوشاپ، کورل‌دراو، ایندیزاین، طراحی گرافیک

همه دوره‌ها مدرک معتبر فنی و حرفه‌ای دارند. شهریه دوره‌ها قسط‌بندی ۲ تا ۳ ماهه بدون چک و بدون بهره است.`

    if (context) {
      const contextParts: string[] = []
      if (context.age) contextParts.push(`سن کاربر: ${context.age}`)
      if (context.currentSkill) contextParts.push(`مهارت فعلی: ${context.currentSkill}`)
      if (context.goal) contextParts.push(`هدف کاربر: ${context.goal}`)
      if (contextParts.length > 0) {
        systemPrompt += `\n\nاطلاعات کاربر:\n${contextParts.join('\n')}`
      }
    }

    let advice = ''
    let recommendedCourses: string[] = []
    let followUpQuestions: string[] = []

    try {
      // Dynamic import to ensure server-side only
      const ZAI = (await import('z-ai-web-dev-sdk')).default
      const zai = await ZAI.create()
      
      const completion = await zai.chat.completions.create({
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: question },
        ],
      })

      const content = completion.choices?.[0]?.message?.content || ''
      advice = content

      // Try to extract course recommendations from the response
      const courseKeywords = ['ICDL', 'پایتون', 'Python', 'فارکس', 'Forex', 'Scratch', 'AutoCAD', 'Photoshop', 'MQL5', 'خیاطی', 'حسابداری', 'کارآفرینی', 'هوش مصنوعی', 'سه‌بعدی', '3D Max', 'هنر', 'پیش‌دبستانی', 'مشاوره']
      for (const keyword of courseKeywords) {
        if (advice.includes(keyword)) {
          recommendedCourses.push(keyword)
        }
      }

      // Generate follow-up questions
      followUpQuestions = [
        'آیا ترجیح می‌دهید دوره‌ها آنلاین یا حضوری باشد؟',
        'چه سطحی از تجربه در این حوزه دارید؟',
        'آیا هدف شما از یادگیری، استخدام است یا توسعه شخصی؟',
      ]
    } catch (aiError) {
      console.error('AI advice fallback:', aiError)
      
      // Rule-based fallback
      advice = generateFallbackAdvice(question, context)
      recommendedCourses = extractCoursesFromQuestion(question)
      followUpQuestions = [
        'برای مشاوره رایگان با کارشناسان ما تماس بگیرید',
        'آیا می‌خواهید مسیر یادگیری شخصی‌سازی شده دریافت کنید؟',
      ]
    }

    return NextResponse.json({
      advice,
      recommendedCourses,
      followUpQuestions,
    })
  } catch (error) {
    console.error('AI advice error:', error)
    return NextResponse.json(
      { خطا: 'خطا در تولید مشاوره' },
      { status: 500 }
    )
  }
}

// ─── Rule-based fallback ─────────────────────────────────────

function generateFallbackAdvice(
  question: string,
  context?: { age?: number; currentSkill?: string; goal?: string }
): string {
  const q = question.toLowerCase()
  
  if (q.includes('icdl') || q.includes('آی‌سی‌دی‌ال') || q.includes('کامپیوتر') || q.includes('استخدام دولتی')) {
    return 'دوره ICDL بهترین نقطه شروع برای ورود به دنیای فناوری است. این گواهینامه بین‌المللی برای استخدام‌های دولتی و غیردولتی یک مزیت رقابتی محسوب می‌شود. پس از اتمام ICDL می‌توانید به سمت برنامه‌نویسی پایتون یا هوش مصنوعی محلی پیش بروید.'
  }
  
  if (q.includes('فارکس') || q.includes('forex') || q.includes('ترید') || q.includes('سرمایه‌گذاری')) {
    return 'دوره فارکس (مبانی) شما را با تحلیل تکنیکال و فاندامنتال بازار آشنا می‌کند. پس از تسلط بر مبانی، دوره MQL5 الگوریتمی به شما یاد می‌دهد ربات‌های معامله‌گر خودکار بسازید. توجه: معاملات بازار مالی همیشه با ریسک همراه است.'
  }
  
  if (q.includes('پایتون') || q.includes('python') || q.includes('برنامه‌نویسی')) {
    return 'پایتون یکی از پرتقاضاترین زبان‌های برنامه‌نویسی در ایران و جهان است. مسیر پیشنهادی: ابتدا ICDL (اگر مبانی ندارید) → پایتون → هوش مصنوعی محلی. این مسیر شما را از مبتدی تا سطح حرفه‌ای پیش می‌برد.'
  }
  
  if (q.includes('کودک') || q.includes('نوجوان') || q.includes('scratch') || q.includes('اسکرچ')) {
    return 'برای کودکان و نوجوانان دوره Scratch بهترین شروع است. این دوره منطق برنامه‌نویسی را از طریق بازی‌سازی آموزش می‌دهد. پس از آن، مسیر پایتون برای نوجوانان بالای ۱۵ سال مناسب است.'
  }
  
  if (q.includes('کارآفرینی') || q.includes('کسب‌وکار') || q.includes('استارتاپ')) {
    return 'دوره کارآفرینی شما را از ایده‌پردازی تا اجرا همراهی می‌کند. مسیر پیشنهادی: حسابداری (برای مدیریت مالی) → مشاوره کسب‌وکار → کارآفرینی. همه دوره‌ها مدرک فنی و حرفه‌ای دارند.'
  }
  
  if (q.includes('طراحی') || q.includes('گرافیک') || q.includes('photoshop') || q.includes('فتوشاپ')) {
    return 'دوره Photoshop نقطه شروع عالی برای ورود به دنیای طراحی گرافیک است. سپس می‌توانید AutoCAD (برای طراحی فنی) یا 3D Max (برای مدلسازی سه‌بعدی) را انتخاب کنید.'
  }

  // Generic advice
  const ageNote = context?.age && context.age < 18
    ? 'با توجه به سن شما، دوره‌های پایه (FOUNDATION) مناسب‌تر هستند.'
    : context?.age && context.age >= 30
    ? 'با توجه به تجربه شما، دوره‌های استراتژیک و کارآفرینی توصیه می‌شود.'
    : ''
  
  return `بهان رایانه با ۲۷ سال سابقه، دوره‌های تخصصی در ۳ خوشه و ۸ گروه آموزشی ارائه می‌دهد. برای انتخاب بهترین مسیر، مشاوره رایگان با کارشناسان ما پیشنهاد می‌شود. ${ageNote} همه دوره‌ها دارای مدرک معتبر فنی و حرفه‌ای و امکان قسط‌بندی بدون چک هستند.`
}

function extractCoursesFromQuestion(question: string): string[] {
  const q = question.toLowerCase()
  const courses: string[] = []
  
  if (q.includes('icdl') || q.includes('کامپیوتر')) courses.push('ICDL')
  if (q.includes('پایتون') || q.includes('python')) courses.push('برنامه‌نویسی پایتون')
  if (q.includes('فارکس') || q.includes('forex')) courses.push('فارکس')
  if (q.includes('scratch') || q.includes('اسکرچ')) courses.push('Scratch')
  if (q.includes('کارآفرینی')) courses.push('کارآفرینی')
  if (q.includes('photoshop') || q.includes('فتوشاپ')) courses.push('Photoshop')
  if (q.includes('autocad') || q.includes('اتوکد')) courses.push('AutoCAD')
  if (q.includes('هوش مصنوعی') || q.includes('ai')) courses.push('هوش مصنوعی محلی')
  
  return courses
}
