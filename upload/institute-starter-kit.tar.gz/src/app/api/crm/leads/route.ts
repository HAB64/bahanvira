import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { executeAutomationRules, seedDefaultAutomationRules } from '@/lib/crm/automation-engine';
import { calculateLeadScore, classifyTemperature } from '@/lib/lead-scoring';
import type { ScoringEvent, InterestedCategory, LeadTemperature } from '@/types/lead';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/leads
 * List leads with filtering, sorting, and pagination.
 * Query params: stage, cluster, search, source, assignedTo, segment,
 *               dateFrom, dateTo, sort, order, page, limit
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    // Filters
    const stage = searchParams.get('stage');
    const cluster = searchParams.get('cluster');
    const search = searchParams.get('search');
    const source = searchParams.get('source');
    const assignedTo = searchParams.get('assignedTo');
    const segment = searchParams.get('segment');
    const dateFrom = searchParams.get('dateFrom');
    const dateTo = searchParams.get('dateTo');

    // Sorting
    const sort = searchParams.get('sort') || 'createdAt';
    const order = searchParams.get('order') || 'desc';

    // Pagination
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {};

    if (stage) {
      where.stage = stage;
    }

    if (cluster) {
      where.cluster = cluster;
    }

    if (source) {
      where.source = source;
    }

    if (assignedTo) {
      where.assignedTo = assignedTo;
    }

    if (segment) {
      where.segment = segment;
    }

    if (dateFrom || dateTo) {
      where.createdAt = {
        ...(dateFrom && { gte: new Date(dateFrom) }),
        ...(dateTo && { lte: new Date(dateTo) }),
      };
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { email: { contains: search, mode: 'insensitive' } },
        { course: { contains: search, mode: 'insensitive' } },
        { company: { contains: search, mode: 'insensitive' } },
      ];
    }

    // Validate sort field
    const allowedSortFields = [
      'createdAt', 'name', 'phone', 'stage', 'score',
      'cluster', 'lastContactedAt', 'source', 'lifetimeValue', 'segment',
    ];
    const sortField = allowedSortFields.includes(sort) ? sort : 'createdAt';
    const sortOrder = order === 'asc' ? 'asc' : 'desc';

    const [leads, total] = await Promise.all([
      db.lead.findMany({
        where,
        orderBy: { [sortField]: sortOrder },
        skip,
        take: limit,
        include: {
          tags: { include: { tag: true } },
          _count: { select: { activityLogs: true, payments: true, tasks: true } },
        },
      }),
      db.lead.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست لیدها با موفقیت دریافت شد',
      داده‌ها: leads,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('CRM leads list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست لیدها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/leads
 * Create a new lead with auto lead-scoring logic.
 * Triggers LEAD_CREATED automation rules.
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      name,
      phone,
      email,
      goal,
      level,
      interest,
      course,
      company,
      serviceType,
      message,
      result,
      source,
      cluster,
      assignedTo,
      utmSource,
      utmMedium,
      utmCampaign,
    } = body;

    // Validate required fields
    if (!name || !phone) {
      return NextResponse.json(
        { خطا: 'نام و شماره تماس الزامی است' },
        { status: 400 }
      );
    }

    // Validate phone format (Iranian mobile)
    const phoneRegex = /^09[0-9]{9}$/;
    if (!phoneRegex.test(phone)) {
      return NextResponse.json(
        { خطا: 'شماره موبایل نامعتبر است (فرمت: 09123456789)' },
        { status: 400 }
      );
    }

    // ── Lead Scoring Engine (Phase 4 — event-based) ──────────────────
    const scoringEvents: ScoringEvent[] = ['form_submission'];

    // +10 if interested in AI
    const clusterToCategory: Record<string, InterestedCategory> = {
      'tech-ai': 'AI',
      'ai': 'AI',
      'finance': 'Finance',
      'financial': 'Finance',
      'it': 'IT',
      'graphic-design': 'GraphicDesign',
      'architecture': 'Architecture',
      'management': 'IT',
      'creative': 'GraphicDesign',
    };
    const interestedCategory = clusterToCategory[cluster || ''] || 'IT';
    if (interestedCategory === 'AI') {
      scoringEvents.push('interested_category_ai');
    }

    const scoringResult = calculateLeadScore(scoringEvents);
    let score = scoringResult.score;
    const temperature: LeadTemperature = scoringResult.temperature;

    // Auto-segment based on temperature
    let segment = 'COLD';
    if (temperature === 'hot') segment = 'VIP';
    else if (temperature === 'warm') segment = 'REGULAR';

    const lead = await db.lead.create({
      data: {
        name,
        phone,
        email: email || '',
        goal: goal || '',
        level: level || '',
        interest: interest || '',
        course: course || '',
        company: company || '',
        serviceType: serviceType || '',
        message: message || '',
        result: result || null,
        source: source || 'career-quiz',
        stage: 'NEW',
        score,
        segment,
        cluster: cluster || '',
        assignedTo: assignedTo || '',
        utmSource: utmSource || '',
        utmMedium: utmMedium || '',
        utmCampaign: utmCampaign || '',
      },
      include: {
        tags: { include: { tag: true } },
      },
    });

    // Ensure default automation rules exist (seed if first time)
    await seedDefaultAutomationRules();

    // Execute automation rules: LEAD_CREATED
    // Run asynchronously — don't block the response
    executeAutomationRules('LEAD_CREATED', {
      leadId: lead.id,
      stage: 'NEW',
      cluster: lead.cluster,
      assignedTo: lead.assignedTo,
      leadName: lead.name,
      leadPhone: lead.phone,
      courseTitle: course || '',
    }).catch((err) => {
      console.error('Automation execution error (LEAD_CREATED):', err);
    });

    return NextResponse.json(
      {
        پیام: 'لید با موفقیت ایجاد شد',
        داده: lead,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('CRM lead creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت لید جدید' },
      { status: 500 }
    );
  }
}
