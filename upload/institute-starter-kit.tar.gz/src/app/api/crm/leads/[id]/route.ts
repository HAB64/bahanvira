import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { executeAutomationRules } from '@/lib/crm/automation-engine';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/leads/[id]
 * Get a single lead with activityLogs, tags, payments, and karAmuz.
 */
export async function GET(
  _request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const lead = await db.lead.findUnique({
      where: { id },
      include: {
        activityLogs: {
          orderBy: { createdAt: 'desc' },
        },
        tags: {
          include: { tag: true },
        },
        payments: {
          orderBy: { createdAt: 'desc' },
        },
        karAmuz: true,
      },
    });

    if (!lead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      پیام: 'اطلاعات لید با موفقیت دریافت شد',
      داده: lead,
    });
  } catch (error) {
    console.error('CRM lead get error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت اطلاعات لید' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/crm/leads/[id]
 * Update a lead (stage, score, assignedTo, etc.)
 * When stage changes to "ENROLLED":
 *   - Automatically set score to 100
 *   - Auto-create KarAmuz record if one doesn't exist
 */
export async function PATCH(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // Check if lead exists (include karAmuz to check for existing link)
    const existingLead = await db.lead.findUnique({
      where: { id },
      include: { karAmuz: true },
    });
    if (!existingLead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate stage if provided
    const validStages = ['NEW', 'CONTACTED', 'INTERESTED', 'QUALIFIED', 'PROPOSAL', 'NEGOTIATION', 'ENROLLED', 'REJECTED', 'ARCHIVED', 'LOST'];
    if (body.stage && !validStages.includes(body.stage)) {
      return NextResponse.json(
        { خطا: 'مرحله نامعتبر است. مقادیر مجاز: NEW, CONTACTED, INTERESTED, QUALIFIED, PROPOSAL, NEGOTIATION, ENROLLED, REJECTED, ARCHIVED, LOST' },
        { status: 400 }
      );
    }

    // Build update data
    const updateData: Record<string, unknown> = {};

    const allowedFields = [
      'name', 'phone', 'email', 'goal', 'level', 'interest',
      'course', 'company', 'serviceType', 'message', 'result',
      'source', 'stage', 'score', 'cluster', 'assignedTo',
      'lastContactedAt', 'utmSource', 'utmMedium', 'utmCampaign',
      'enrollmentProb', 'aiMetadata', 'segment', 'lifetimeValue',
      'satisfactionScore',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field];
      }
    }

    // When stage changes to "ENROLLED", automatically set score to 100
    // and create a KarAmuz record if one doesn't exist
    if (body.stage === 'ENROLLED') {
      updateData.score = 100;

      // Auto-create KarAmuz if not already linked
      if (!existingLead.karAmuz) {
        try {
          // Generate student code: BR-YYYY-XXXX
          const currentYear = new Date().getFullYear();
          const lastKarAmuz = await db.karAmuz.findFirst({
            where: { studentCode: { startsWith: `BR-${currentYear}-` } },
            orderBy: { studentCode: 'desc' },
          });
          let seq = 1;
          if (lastKarAmuz?.studentCode) {
            const parts = lastKarAmuz.studentCode.split('-');
            seq = (parseInt(parts[2] || '0', 10) || 0) + 1;
          }
          const studentCode = `BR-${currentYear}-${seq.toString().padStart(4, '0')}`;

          // Split name into first/last
          const nameParts = existingLead.name.trim().split(/\s+/);
          const firstName = nameParts[0] || existingLead.name;
          const lastName = nameParts.slice(1).join(' ') || '-';

          await db.karAmuz.create({
            data: {
              nationalId: `TEMP-${existingLead.phone}`, // Temporary; admin will update with real nationalId
              studentCode,
              firstName,
              lastName,
              phone: existingLead.phone,
              email: existingLead.email || undefined,
              leadId: id,
              status: 'ACTIVE',
            },
          });
        } catch (karAmuzError) {
          console.error('Auto-create KarAmuz error:', karAmuzError);
          // Don't fail the lead update if KarAmuz creation fails
          // Admin can manually create KarAmuz later
        }
      }
    }

    // Also update segment when stage changes
    if (body.stage === 'ENROLLED') {
      updateData.segment = 'LOYAL';
    } else if (body.stage === 'REJECTED' || body.stage === 'LOST') {
      updateData.segment = existingLead.segment === 'VIP' ? 'AT_RISK' : 'CHURNED';
    }

    // Update lifetimeValue (CLV) — recalculate from paid payments
    if (body.stage === 'ENROLLED' || body.lifetimeValue !== undefined) {
      const paidTotal = await db.payment.aggregate({
        where: { leadId: id, status: 'PAID' },
        _sum: { amount: true },
      });
      updateData.lifetimeValue = paidTotal._sum.amount || 0;
    }

    // If stage is changing, create an activity log
    if (body.stage && body.stage !== existingLead.stage) {
      await db.activityLog.create({
        data: {
          leadId: id,
          type: 'STAGE_CHANGE',
          content: `تغییر مرحله از ${existingLead.stage} به ${body.stage}`,
        },
      });
    }

    const updatedLead = await db.lead.update({
      where: { id },
      data: updateData,
      include: {
        tags: { include: { tag: true } },
        activityLogs: {
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
        karAmuz: true,
      },
    });

    // Execute automation rules: STAGE_CHANGED
    if (body.stage && body.stage !== existingLead.stage) {
      executeAutomationRules('STAGE_CHANGED', {
        leadId: id,
        stage: body.stage,
        previousStage: existingLead.stage,
        cluster: updatedLead.cluster,
        assignedTo: updatedLead.assignedTo,
        leadName: updatedLead.name,
        leadPhone: updatedLead.phone,
        courseTitle: updatedLead.course || '',
      }).catch((err) => {
        console.error('Automation execution error (STAGE_CHANGED):', err);
      });
    }

    return NextResponse.json({
      پیام: 'اطلاعات لید با موفقیت به‌روزرسانی شد',
      داده: updatedLead,
    });
  } catch (error) {
    console.error('CRM lead update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی اطلاعات لید' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/crm/leads/[id]
 * Delete a lead (cascade deletes activities, tags, payments).
 */
export async function DELETE(
  _request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    // Check if lead exists
    const existingLead = await db.lead.findUnique({ where: { id } });
    if (!existingLead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    await db.lead.delete({ where: { id } });

    return NextResponse.json({
      پیام: 'لید با موفقیت حذف شد',
    });
  } catch (error) {
    console.error('CRM lead delete error:', error);
    return NextResponse.json(
      { خطا: 'خطا در حذف لید' },
      { status: 500 }
    );
  }
}
