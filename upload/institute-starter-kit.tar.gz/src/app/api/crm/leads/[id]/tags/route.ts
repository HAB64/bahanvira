import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

import { getAdminSession } from '@/lib/admin-auth';
const prisma = new PrismaClient();

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/leads/[id]/tags
 * List tags for a lead.
 */
export async function GET(
  _request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    // Check if lead exists
    const lead = await prisma.lead.findUnique({ where: { id } });
    if (!lead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const tagRelations = await prisma.tagOnLead.findMany({
      where: { leadId: id },
      include: { tag: true },
    });

    const tags = tagRelations.map((rel) => rel.tag);

    return NextResponse.json({
      پیام: 'لیست برچسب‌ها با موفقیت دریافت شد',
      داده‌ها: tags,
    });
  } catch (error) {
    console.error('CRM lead tags list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست برچسب‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/leads/[id]/tags
 * Add a tag to a lead (create tag if not exists).
 * Body: { name, color? }
 */
export async function POST(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, color } = body;

    // Check if lead exists
    const lead = await prisma.lead.findUnique({ where: { id } });
    if (!lead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate required fields
    if (!name || !name.trim()) {
      return NextResponse.json(
        { خطا: 'نام برچسب الزامی است' },
        { status: 400 }
      );
    }

    const tagName = name.trim();

    // Find or create the tag
    let tag = await prisma.tag.findUnique({
      where: { name: tagName },
    });

    if (!tag) {
      tag = await prisma.tag.create({
        data: {
          name: tagName,
          color: color || '#0d9488',
        },
      });
    }

    // Check if tag is already assigned to this lead
    const existingRelation = await prisma.tagOnLead.findUnique({
      where: {
        leadId_tagId: {
          leadId: id,
          tagId: tag.id,
        },
      },
    });

    if (existingRelation) {
      return NextResponse.json(
        { خطا: 'این برچسب قبلاً به این لید اختصاص داده شده است' },
        { status: 409 }
      );
    }

    // Add tag to lead
    await prisma.tagOnLead.create({
      data: {
        leadId: id,
        tagId: tag.id,
      },
    });

    return NextResponse.json(
      {
        پیام: 'برچسب با موفقیت به لید اضافه شد',
        داده: tag,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('CRM lead tag add error:', error);
    return NextResponse.json(
      { خطا: 'خطا در افزودن برچسب' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/crm/leads/[id]/tags
 * Remove a tag from a lead.
 * Body: { tagId } or query param: ?tagId=xxx
 */
export async function DELETE(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    // Get tagId from body or query params
    let tagId: string | null = null;

    const contentType = request.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      try {
        const body = await request.json();
        tagId = body.tagId;
      } catch {
        // Empty body, try query params
      }
    }

    if (!tagId) {
      const { searchParams } = new URL(request.url);
      tagId = searchParams.get('tagId');
    }

    if (!tagId) {
      return NextResponse.json(
        { خطا: 'شناسه برچسب الزامی است' },
        { status: 400 }
      );
    }

    // Check if the relation exists
    const existingRelation = await prisma.tagOnLead.findUnique({
      where: {
        leadId_tagId: {
          leadId: id,
          tagId,
        },
      },
    });

    if (!existingRelation) {
      return NextResponse.json(
        { خطا: 'این برچسب به این لید اختصاص داده نشده است' },
        { status: 404 }
      );
    }

    await prisma.tagOnLead.delete({
      where: {
        leadId_tagId: {
          leadId: id,
          tagId,
        },
      },
    });

    return NextResponse.json({
      پیام: 'برچسب با موفقیت از لید حذف شد',
    });
  } catch (error) {
    console.error('CRM lead tag remove error:', error);
    return NextResponse.json(
      { خطا: 'خطا در حذف برچسب' },
      { status: 500 }
    );
  }
}
