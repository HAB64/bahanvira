import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

import { getAdminSession } from '@/lib/admin-auth';
const prisma = new PrismaClient();

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/leads/[id]/activities
 * List activities for a lead.
 * Query params: type, page, limit
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);

    // Check if lead exists
    const lead = await prisma.lead.findUnique({ where: { id } });
    if (!lead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const type = searchParams.get('type');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = { leadId: id };
    if (type) {
      where.type = type;
    }

    const [activities, total] = await Promise.all([
      prisma.activityLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.activityLog.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست فعالیت‌ها با موفقیت دریافت شد',
      داده‌ها: activities,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('CRM activities list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست فعالیت‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/leads/[id]/activities
 * Add an activity log for a lead.
 * Body: { type, content, followUpAt? }
 */
export async function POST(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { type, content, followUpAt } = body;

    // Check if lead exists
    const lead = await prisma.lead.findUnique({ where: { id } });
    if (!lead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate required fields
    if (!type || !content) {
      return NextResponse.json(
        { خطا: 'نوع و محتوای فعالیت الزامی است' },
        { status: 400 }
      );
    }

    // Validate activity type
    const validTypes = ['CALL', 'WHATSAPP', 'SMS', 'NOTE', 'STAGE_CHANGE', 'REMINDER'];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { خطا: `نوع فعالیت نامعتبر است. مقادیر مجاز: ${validTypes.join(', ')}` },
        { status: 400 }
      );
    }

    const activity = await prisma.activityLog.create({
      data: {
        leadId: id,
        type,
        content,
        followUpAt: followUpAt ? new Date(followUpAt) : null,
      },
    });

    // Update lastContactedAt for CALL, WHATSAPP, SMS types
    if (['CALL', 'WHATSAPP', 'SMS'].includes(type)) {
      await prisma.lead.update({
        where: { id },
        data: { lastContactedAt: new Date() },
      });
    }

    return NextResponse.json(
      {
        پیام: 'فعالیت با موفقیت ثبت شد',
        داده: activity,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('CRM activity creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت فعالیت' },
      { status: 500 }
    );
  }
}
