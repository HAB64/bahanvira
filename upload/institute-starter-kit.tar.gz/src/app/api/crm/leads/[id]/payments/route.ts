import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

import { getAdminSession } from '@/lib/admin-auth';
const prisma = new PrismaClient();

interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/leads/[id]/payments
 * List payments for a lead.
 * Query params: status, type, page, limit
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);

    // Check if lead exists
    const lead = await prisma.lead.findUnique({ where: { id } });
    if (!lead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = { leadId: id };
    if (status) {
      where.status = status;
    }
    if (type) {
      where.type = type;
    }

    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.payment.count({ where }),
    ]);

    // Calculate total amounts
    const totalAmount = payments.reduce((sum, p) => sum + p.amount, 0);
    const paidAmount = payments
      .filter((p) => p.status === 'PAID')
      .reduce((sum, p) => sum + p.amount, 0);
    const pendingAmount = payments
      .filter((p) => p.status === 'PENDING')
      .reduce((sum, p) => sum + p.amount, 0);

    return NextResponse.json({
      پیام: 'لیست پرداخت‌ها با موفقیت دریافت شد',
      داده‌ها: payments,
      خلاصه: {
        مبلغ_کل: totalAmount,
        مبلغ_پرداخت_شده: paidAmount,
        مبلغ_در_انتظار: pendingAmount,
      },
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('CRM payments list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست پرداخت‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/leads/[id]/payments
 * Add a payment record for a lead.
 * Body: { amount, type, status?, dueDate?, paidAt?, note? }
 */
export async function POST(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { amount, type, status, dueDate, paidAt, note } = body;

    // Check if lead exists
    const lead = await prisma.lead.findUnique({ where: { id } });
    if (!lead) {
      return NextResponse.json(
        { خطا: 'لید مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate required fields
    if (!amount || !type) {
      return NextResponse.json(
        { خطا: 'مبلغ و نوع پرداخت الزامی است' },
        { status: 400 }
      );
    }

    // Validate amount
    if (typeof amount !== 'number' || amount <= 0) {
      return NextResponse.json(
        { خطا: 'مبلغ پرداخت باید یک عدد مثبت باشد' },
        { status: 400 }
      );
    }

    // Validate payment type
    const validTypes = ['CASH', 'CHECK', 'INSTALLMENT'];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { خطا: `نوع پرداخت نامعتبر است. مقادیر مجاز: ${validTypes.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate payment status
    const validStatuses = ['PENDING', 'PAID', 'OVERDUE', 'CANCELLED'];
    const paymentStatus = status || 'PENDING';
    if (!validStatuses.includes(paymentStatus)) {
      return NextResponse.json(
        { خطا: `وضعیت پرداخت نامعتبر است. مقادیر مجاز: ${validStatuses.join(', ')}` },
        { status: 400 }
      );
    }

    const payment = await prisma.payment.create({
      data: {
        leadId: id,
        amount,
        type,
        status: paymentStatus,
        dueDate: dueDate ? new Date(dueDate) : null,
        paidAt: paidAt ? new Date(paidAt) : null,
        note: note || '',
      },
    });

    return NextResponse.json(
      {
        پیام: 'پرداخت با موفقیت ثبت شد',
        داده: payment,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('CRM payment creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت پرداخت' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/crm/leads/[id]/payments
 * Update a payment status (mark as paid, overdue, cancel).
 * Body: { paymentId, status, note? }
 */
export async function PATCH(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { paymentId, status, note } = body;

    if (!paymentId) {
      return NextResponse.json(
        { خطا: 'شناسه پرداخت الزامی است' },
        { status: 400 }
      );
    }

    if (!status) {
      return NextResponse.json(
        { خطا: 'وضعیت جدید الزامی است' },
        { status: 400 }
      );
    }

    const validStatuses = ['PENDING', 'PAID', 'OVERDUE', 'CANCELLED'];
    if (!validStatuses.includes(status)) {
      return NextResponse.json(
        { خطا: `وضعیت نامعتبر است. مقادیر مجاز: ${validStatuses.join(', ')}` },
        { status: 400 }
      );
    }

    // Check if payment exists and belongs to this lead
    const existingPayment = await prisma.payment.findFirst({
      where: { id: paymentId, leadId: id },
    });

    if (!existingPayment) {
      return NextResponse.json(
        { خطا: 'پرداخت مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const updateData: Record<string, unknown> = { status };

    // If marking as paid, set paidAt to now
    if (status === 'PAID') {
      updateData.paidAt = new Date();
    }

    // If moving away from PAID, clear paidAt
    if (existingPayment.status === 'PAID' && status !== 'PAID') {
      updateData.paidAt = null;
    }

    if (note !== undefined) {
      updateData.note = note;
    }

    const updatedPayment = await prisma.payment.update({
      where: { id: paymentId },
      data: updateData,
    });

    return NextResponse.json({
      پیام: 'وضعیت پرداخت با موفقیت به‌روزرسانی شد',
      داده: updatedPayment,
    });
  } catch (error) {
    console.error('CRM payment update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی پرداخت' },
      { status: 500 }
    );
  }
}
