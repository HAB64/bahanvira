import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * POST /api/crm/leads/bulk
 * Perform bulk operations on multiple leads.
 * Body: { action: 'changeStage' | 'addTag' | 'delete' | 'assign' | 'exportCsv', leadIds: string[], data?: any }
 */
export async function POST(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const body = await request.json();
    const { action, leadIds, data } = body;

    if (!action || !leadIds || !Array.isArray(leadIds) || leadIds.length === 0) {
      return NextResponse.json(
        { خطا: 'نوع عملیات و لیست شناسه لیدها الزامی است' },
        { status: 400 }
      );
    }

    // Limit bulk operations to 200 leads at a time
    if (leadIds.length > 200) {
      return NextResponse.json(
        { خطا: 'حداکثر ۲۰۰ لید در هر عملیات دسته‌ای مجاز است' },
        { status: 400 }
      );
    }

    switch (action) {
      case 'changeStage': {
        if (!data?.stage) {
          return NextResponse.json(
            { خطا: 'مرحله جدید الزامی است' },
            { status: 400 }
          );
        }

        const validStages = ['NEW', 'CONTACTED', 'INTERESTED', 'ENROLLED', 'REJECTED', 'ARCHIVED'];
        if (!validStages.includes(data.stage)) {
          return NextResponse.json(
            { خطا: 'مرحله نامعتبر است' },
            { status: 400 }
          );
        }

        const result = await db.lead.updateMany({
          where: { id: { in: leadIds } },
          data: { stage: data.stage },
        });

        // Create activity logs for each lead
        await Promise.all(
          leadIds.map((leadId: string) =>
            db.activityLog.create({
              data: {
                leadId,
                type: 'STAGE_CHANGE',
                content: `تغییر مرحله دسته‌ای به: ${data.stage}`,
              },
            })
          )
        );

        return NextResponse.json({
          پیام: `مرحله ${result.count} لید با موفقیت تغییر کرد`,
          موفق: true,
          تعداد_تأثیر: result.count,
        });
      }

      case 'addTag': {
        if (!data?.tagName) {
          return NextResponse.json(
            { خطا: 'نام برچسب الزامی است' },
            { status: 400 }
          );
        }

        // Find or create the tag
        let tag = await db.tag.findUnique({
          where: { name: data.tagName },
        });

        if (!tag) {
          tag = await db.tag.create({
            data: {
              name: data.tagName,
              color: data.tagColor || '#0d9488',
            },
          });
        }

        // Get existing tag associations to avoid duplicates
        const existingAssociations = await db.tagOnLead.findMany({
          where: {
            tagId: tag.id,
            leadId: { in: leadIds },
          },
          select: { leadId: true },
        });

        const existingLeadIds = new Set(existingAssociations.map((a) => a.leadId));
        const newLeadIds = leadIds.filter((id: string) => !existingLeadIds.has(id));

        if (newLeadIds.length > 0) {
          await db.tagOnLead.createMany({
            data: newLeadIds.map((leadId: string) => ({
              leadId,
              tagId: tag.id,
            })),
          });
        }

        return NextResponse.json({
          پیام: `برچسب "${data.tagName}" به ${newLeadIds.length} لید اضافه شد`,
          موفق: true,
          تعداد_تأثیر: newLeadIds.length,
        });
      }

      case 'delete': {
        // Delete leads and their related records (cascading)
        const result = await db.lead.deleteMany({
          where: { id: { in: leadIds } },
        });

        return NextResponse.json({
          پیام: `${result.count} لید با موفقیت حذف شد`,
          موفق: true,
          تعداد_تأثیر: result.count,
        });
      }

      case 'assign': {
        if (!data?.assignedTo && data?.assignedTo !== '') {
          return NextResponse.json(
            { خطا: 'نام مشاور الزامی است' },
            { status: 400 }
          );
        }

        const result = await db.lead.updateMany({
          where: { id: { in: leadIds } },
          data: { assignedTo: data.assignedTo },
        });

        return NextResponse.json({
          پیام: `${result.count} لید با موفقیت تخصیص یافت`,
          موفق: true,
          تعداد_تأثیر: result.count,
        });
      }

      case 'exportCsv': {
        // Fetch the selected leads with their tags
        const leads = await db.lead.findMany({
          where: { id: { in: leadIds } },
          include: {
            tags: { include: { tag: true } },
          },
          orderBy: { createdAt: 'desc' },
        });

        // Generate CSV
        const headers = [
          'نام',
          'شماره تماس',
          'ایمیل',
          'مرحله',
          'امتیاز',
          'خوشه',
          'دوره',
          'مشاور',
          'منبع',
          'برچسب‌ها',
          'تاریخ ایجاد',
        ];

        const stageLabels: Record<string, string> = {
          NEW: 'جدید',
          CONTACTED: 'تماس‌شده',
          INTERESTED: 'علاقه‌مند',
          ENROLLED: 'ثبت‌نام‌شده',
          REJECTED: 'ردشده',
          ARCHIVED: 'بایگانی',
        };

        const clusterLabels: Record<string, string> = {
          'tech-ai': 'کامپیوتر و هوش مصنوعی',
          financial: 'بازار سرمایه',
          management: 'توسعه کسب‌وکار',
          entrepreneurship: 'کارآفرینی',
        };

        const rows = leads.map((lead) => [
          lead.name,
          lead.phone,
          lead.email || '',
          stageLabels[lead.stage] || lead.stage,
          lead.score.toString(),
          clusterLabels[lead.cluster] || lead.cluster,
          lead.course || '',
          lead.assignedTo || '',
          lead.source || '',
          lead.tags?.map((t) => t.tag.name).join(' | ') || '',
          new Intl.DateTimeFormat('fa-IR').format(lead.createdAt),
        ]);

        // Use BOM for proper UTF-8 display in Excel
        const bom = '\uFEFF';
        const csvContent = bom + [
          headers.join(','),
          ...rows.map((row) =>
            row.map((cell) => `"${cell.replace(/"/g, '""')}"`).join(',')
          ),
        ].join('\n');

        return new NextResponse(csvContent, {
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="leads-export-${new Date().toISOString().split('T')[0]}.csv"`,
          },
        });
      }

      default:
        return NextResponse.json(
          { خطا: 'نوع عملیات نامعتبر است' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Bulk leads operation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در انجام عملیات دسته‌ای' },
      { status: 500 }
    );
  }
}
