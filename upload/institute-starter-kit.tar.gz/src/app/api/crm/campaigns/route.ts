import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/campaigns — List campaigns with filters
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const channel = searchParams.get('channel');
    const type = searchParams.get('type');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (channel) where.channel = channel;
    if (type) where.type = type;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { utmCampaign: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [campaigns, total] = await Promise.all([
      db.campaign.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { recipients: true } },
        },
      }),
      db.campaign.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست کمپین‌ها با موفقیت دریافت شد',
      داده‌ها: campaigns,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Campaigns list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت کمپین‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/campaigns — Create campaign with auto UTM tracking
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      name, description, type, channel, startDate, endDate,
      budget, targetSegment, targetCluster, stages, assignedTo,
      adPlatform, adCostPerClick, adImpressions, adClicks,
    } = body;

    if (!name) {
      return NextResponse.json({ خطا: 'نام کمپین الزامی است' }, { status: 400 });
    }

    // Auto-generate UTM campaign name from campaign name
    const utmCampaign = name
      .replace(/\s+/g, '-')
      .replace(/[^\w\u0600-\u06FF-]/g, '')
      .toLowerCase()
      .slice(0, 50);

    const campaign = await db.campaign.create({
      data: {
        name,
        description: description || null,
        type: type || 'MULTI_STAGE',
        channel: channel || 'SMS',
        status: 'DRAFT',
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        budget: budget || 0,
        targetSegment: targetSegment || '',
        targetCluster: targetCluster || '',
        utmCampaign,
        stages: stages || null,
        assignedTo: assignedTo || '',
        adPlatform: adPlatform || null,
        adCostPerClick: adCostPerClick ?? null,
        adImpressions: adImpressions ?? null,
        adClicks: adClicks ?? null,
      },
    });

    return NextResponse.json({ پیام: 'کمپین با موفقیت ایجاد شد', داده: campaign }, { status: 201 });
  } catch (error) {
    console.error('Campaign creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت کمپین' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/campaigns — Update campaign status
 * When status changes to RUNNING, auto-create CampaignRecipient records
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { campaignId, status, ...otherFields } = body;

    if (!campaignId) {
      return NextResponse.json({ خطا: 'شناسه کمپین الزامی است' }, { status: 400 });
    }

    const existing = await db.campaign.findUnique({
      where: { id: campaignId },
      include: { _count: { select: { recipients: true } } },
    });
    if (!existing) {
      return NextResponse.json({ خطا: 'کمپین یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};

    // Handle status transitions
    if (status) {
      const validTransitions: Record<string, string[]> = {
        DRAFT: ['SCHEDULED', 'CANCELLED'],
        SCHEDULED: ['RUNNING', 'CANCELLED', 'DRAFT'],
        RUNNING: ['PAUSED', 'COMPLETED', 'CANCELLED'],
        PAUSED: ['RUNNING', 'CANCELLED', 'COMPLETED'],
        COMPLETED: [],
        CANCELLED: [],
      };

      const allowed = validTransitions[existing.status] || [];
      if (!allowed.includes(status) && status !== existing.status) {
        return NextResponse.json({
          خطا: `تغییر وضعیت از ${existing.status} به ${status} مجاز نیست. وضعیت‌های مجاز: ${allowed.join(', ')}`,
        }, { status: 400 });
      }
      updateData.status = status;
    }

    // Update other allowed fields
    const allowedFields = [
      'name', 'description', 'type', 'channel', 'startDate', 'endDate',
      'budget', 'spentAmount', 'targetSegment', 'targetCluster', 'stages',
      'assignedTo', 'sentCount', 'deliveredCount', 'openCount', 'clickCount',
      'conversionCount', 'bounceCount', 'adPlatform', 'adCostPerClick', 'adImpressions', 'adClicks',
    ];

    for (const field of allowedFields) {
      if (otherFields[field] !== undefined) {
        if (field === 'startDate' || field === 'endDate') {
          updateData[field] = otherFields[field] ? new Date(otherFields[field]) : null;
        } else {
          updateData[field] = otherFields[field];
        }
      }
    }

    const updated = await db.campaign.update({
      where: { id: campaignId },
      data: updateData,
      include: {
        _count: { select: { recipients: true } },
      },
    });

    // When status changes to RUNNING, auto-create CampaignRecipient records
    if (status === 'RUNNING' && existing.status !== 'RUNNING') {
      const targetSegment = existing.targetSegment;
      const targetCluster = existing.targetCluster;

      const leadWhere: Record<string, unknown> = {};
      if (targetSegment && targetSegment !== 'ALL') {
        leadWhere.segment = targetSegment;
      }
      if (targetCluster && targetCluster !== 'all') {
        leadWhere.cluster = targetCluster;
      }

      const leads = await db.lead.findMany({
        where: leadWhere,
        select: { id: true },
      });

      const karAmuzWhere: Record<string, unknown> = {};
      // For karAmuz targeting, use the cluster from lead relation
      if (targetCluster && targetCluster !== 'all') {
        karAmuzWhere.lead = { cluster: targetCluster };
      }
      if (targetSegment && targetSegment !== 'ALL') {
        karAmuzWhere.lead = { segment: targetSegment };
      }

      const karAmuzList = await db.karAmuz.findMany({
        where: karAmuzWhere,
        select: { id: true },
      });

      // Create recipients (avoid duplicates)
      const recipientData: { campaignId: string; leadId: string | null; karAmuzId: string | null; status: string; currentStage: number }[] = [];

      for (const lead of leads) {
        recipientData.push({
          campaignId,
          leadId: lead.id,
          karAmuzId: null,
          status: 'PENDING',
          currentStage: 0,
        });
      }

      for (const ka of karAmuzList) {
        // Skip if this karAmuz's lead is already added
        const kaWithLead = await db.karAmuz.findUnique({
          where: { id: ka.id },
          select: { leadId: true },
        });
        const alreadyAdded = kaWithLead?.leadId && leads.some(l => l.id === kaWithLead.leadId);
        if (!alreadyAdded) {
          recipientData.push({
            campaignId,
            leadId: null,
            karAmuzId: ka.id,
            status: 'PENDING',
            currentStage: 0,
          });
        }
      }

      if (recipientData.length > 0) {
        await db.campaignRecipient.createMany({ data: recipientData, skipDuplicates: true });
      }

      const finalCampaign = await db.campaign.findUnique({
        where: { id: campaignId },
        include: {
          _count: { select: { recipients: true } },
        },
      });

      return NextResponse.json({
        پیام: `کمپین فعال شد و ${recipientData.length} گیرنده اضافه شد`,
        داده: finalCampaign,
        تعداد_گیرندگان: recipientData.length,
      });
    }

    return NextResponse.json({ پیام: 'کمپین با موفقیت به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Campaign update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی کمپین' }, { status: 500 });
  }
}
