import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/campaigns/[id] — Get single campaign with recipients
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const recipientStatus = searchParams.get('recipientStatus');

    const campaign = await db.campaign.findUnique({
      where: { id },
      include: {
        recipients: {
          where: recipientStatus ? { status: recipientStatus } : undefined,
          include: {
            lead: { select: { id: true, name: true, phone: true } },
            karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!campaign) {
      return NextResponse.json({ خطا: 'کمپین یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ پیام: 'کمپین با موفقیت دریافت شد', داده: campaign });
  } catch (error) {
    console.error('Campaign get error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت کمپین' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/campaigns/[id] — Update campaign
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const existing = await db.campaign.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ خطا: 'کمپین یافت نشد' }, { status: 404 });
    }

    const allowedFields = [
      'name', 'description', 'type', 'channel', 'status', 'startDate', 'endDate',
      'budget', 'spentAmount', 'targetSegment', 'targetCluster', 'utmCampaign', 'stages',
      'assignedTo', 'sentCount', 'deliveredCount', 'openCount', 'clickCount',
      'conversionCount', 'bounceCount', 'adPlatform', 'adCostPerClick', 'adImpressions', 'adClicks',
    ];

    const updateData: Record<string, unknown> = {};
    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        if (field === 'startDate' || field === 'endDate') {
          updateData[field] = body[field] ? new Date(body[field]) : null;
        } else {
          updateData[field] = body[field];
        }
      }
    }

    const updated = await db.campaign.update({
      where: { id },
      data: updateData,
      include: {
        _count: { select: { recipients: true } },
      },
    });

    return NextResponse.json({ پیام: 'کمپین با موفقیت به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Campaign update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی کمپین' }, { status: 500 });
  }
}

/**
 * DELETE /api/crm/campaigns/[id] — Delete campaign
 */
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const existing = await db.campaign.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ خطا: 'کمپین یافت نشد' }, { status: 404 });
    }

    await db.campaign.delete({ where: { id } });

    return NextResponse.json({ پیام: 'کمپین با موفقیت حذف شد' });
  } catch (error) {
    console.error('Campaign delete error:', error);
    return NextResponse.json({ خطا: 'خطا در حذف کمپین' }, { status: 500 });
  }
}
