import { NextRequest, NextResponse } from 'next/server';
import { processCampaignStages } from '@/lib/crm/campaign-engine';

/**
 * POST /api/crm/campaigns/process
 * Cron endpoint: Process overdue campaign stages automatically.
 *
 * Call from Vercel Cron or external scheduler (e.g. every hour).
 * Secured with CRON_SECRET header to prevent unauthorized calls.
 *
 * Flow:
 * 1. Find all RUNNING campaigns
 * 2. For each, find recipients whose nextStageAt has passed
 * 3. Execute the next stage (SMS/Email/WhatsApp)
 * 4. Auto-complete campaigns when all recipients have finished
 * 5. Return summary
 */
export async function POST(request: NextRequest) {
  try {
    // Validate cron secret
    const cronSecret = request.headers.get('x-cron-secret') || request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (expectedSecret && cronSecret !== `Bearer ${expectedSecret}` && cronSecret !== expectedSecret) {
      return NextResponse.json(
        { خطا: 'دسترسی غیرمجاز' },
        { status: 401 }
      );
    }

    const result = await processCampaignStages();

    return NextResponse.json({
      پیام: 'پردازش مراحل کمپین انجام شد',
      کمپین‌های_پردازش_شده: result.campaignsProcessed,
      مراحل_اجرا_شده: result.stagesExecuted,
      تعداد_ارسال_شده: result.totalSent,
      تعداد_ناموفق: result.totalFailed,
      خطاها: result.errors.length > 0 ? result.errors : undefined,
    });
  } catch (error) {
    console.error('Campaign process cron error:', error);
    return NextResponse.json(
      { خطا: 'خطا در پردازش مراحل کمپین' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/crm/campaigns/process
 * Preview: Show how many campaigns and recipients are due for processing.
 */
export async function GET(request: NextRequest) {
  try {
    const cronSecret = request.headers.get('x-cron-secret') || request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (expectedSecret && cronSecret !== `Bearer ${expectedSecret}` && cronSecret !== expectedSecret) {
      return NextResponse.json(
        { خطا: 'دسترسی غیرمجاز' },
        { status: 401 }
      );
    }

    const { db } = await import('@/lib/db');

    // Count running campaigns
    const runningCampaigns = await db.campaign.count({
      where: { status: 'RUNNING' },
    });

    // Count due recipients
    const dueRecipients = await db.campaignRecipient.count({
      where: {
        nextStageAt: { lte: new Date() },
        status: { in: ['PENDING', 'SENT', 'DELIVERED'] },
      },
    });

    return NextResponse.json({
      پیام: 'پیش‌نمایش مراحل کمپین',
      کمپین‌های_فعال: runningCampaigns,
      گیرنده‌های_سررسیدشده: dueRecipients,
    });
  } catch (error) {
    console.error('Campaign process preview error:', error);
    return NextResponse.json(
      { خطا: 'خطا در پیش‌نمایش' },
      { status: 500 }
    );
  }
}
