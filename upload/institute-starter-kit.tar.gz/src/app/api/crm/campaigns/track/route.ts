import { NextRequest, NextResponse } from 'next/server';
import { trackCampaignEvent, CampaignEventType } from '@/lib/crm/campaign-engine';

/**
 * POST /api/crm/campaigns/track
 * Track campaign events (OPENED, CLICKED, CONVERTED, BOUNCED).
 *
 * Called from:
 * - Email tracking pixels (1x1 image in emails)
 * - Click tracking redirects
 * - Webhook callbacks from SMS/WhatsApp providers
 * - Manual conversion tracking
 *
 * Body: { campaignId, recipientId, event }
 * Optional header: X-Track-Secret for webhook validation
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { campaignId, recipientId, event } = body;

    if (!campaignId || !recipientId || !event) {
      return NextResponse.json(
        { خطا: 'شناسه کمپین، شناسه گیرنده و نوع رویداد الزامی است' },
        { status: 400 }
      );
    }

    const validEvents: CampaignEventType[] = ['OPENED', 'CLICKED', 'CONVERTED', 'BOUNCED'];
    if (!validEvents.includes(event as CampaignEventType)) {
      return NextResponse.json(
        { خطا: `نوع رویداد نامعتبر. انواع مجاز: ${validEvents.join(', ')}` },
        { status: 400 }
      );
    }

    const result = await trackCampaignEvent(
      campaignId,
      recipientId,
      event as CampaignEventType
    );

    if (!result.success) {
      return NextResponse.json(
        { خطا: result.error },
        { status: 400 }
      );
    }

    return NextResponse.json({
      پیام: `رویداد ${event} با موفقیت ثبت شد`,
    });
  } catch (error) {
    console.error('Campaign track error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت رویداد کمپین' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/crm/campaigns/track
 * Email open tracking pixel (1x1 transparent GIF).
 * Query params: c=campaignId, r=recipientId
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const campaignId = searchParams.get('c');
    const recipientId = searchParams.get('r');

    if (campaignId && recipientId) {
      // Fire and forget - don't block the pixel response
      trackCampaignEvent(campaignId, recipientId, 'OPENED').catch(() => {});
    }

    // Return 1x1 transparent GIF
    const gif = Buffer.from(
      'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
      'base64'
    );

    return new Response(gif, {
      headers: {
        'Content-Type': 'image/gif',
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      },
    });
  } catch {
    // Still return the pixel even if tracking fails
    const gif = Buffer.from(
      'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
      'base64'
    );
    return new Response(gif, {
      headers: { 'Content-Type': 'image/gif' },
    });
  }
}
