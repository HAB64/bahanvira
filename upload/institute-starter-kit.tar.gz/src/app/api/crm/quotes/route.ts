import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/quotes — List quotes with filters
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const leadId = searchParams.get('leadId');
    const karAmuzId = searchParams.get('karAmuzId');
    const assignedTo = searchParams.get('assignedTo');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (leadId) where.leadId = leadId;
    if (karAmuzId) where.karAmuzId = karAmuzId;
    if (assignedTo) where.assignedTo = assignedTo;
    if (search) {
      where.OR = [
        { quoteNumber: { contains: search, mode: 'insensitive' } },
        { notes: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [quotes, total] = await Promise.all([
      db.quote.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          lead: { select: { id: true, name: true, phone: true } },
          karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
        },
      }),
      db.quote.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست پیشنهادها با موفقیت دریافت شد',
      داده‌ها: quotes,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Quotes list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت پیشنهادها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/quotes — Create a new quote
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { items, discountPct, notes, internalNotes, leadId, karAmuzId, assignedTo, validUntil } = body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ خطا: 'حداقل یک آیتم الزامی است' }, { status: 400 });
    }

    // Generate quote number: QT-YYYY-XXXX
    const currentYear = new Date().getFullYear();
    const lastQuote = await db.quote.findFirst({
      where: { quoteNumber: { startsWith: `QT-${currentYear}-` } },
      orderBy: { quoteNumber: 'desc' },
    });
    let seq = 1;
    if (lastQuote?.quoteNumber) {
      const parts = lastQuote.quoteNumber.split('-');
      seq = (parseInt(parts[2] || '0', 10) || 0) + 1;
    }
    const quoteNumber = `QT-${currentYear}-${seq.toString().padStart(4, '0')}`;

    // Calculate totals
    const subtotal = items.reduce((sum: number, item: { total?: number; unitPrice?: number; quantity?: number }) =>
      sum + (item.total || (item.unitPrice || 0) * (item.quantity || 1)), 0);
    const discPct = discountPct || 0;
    const discountAmount = Math.round(subtotal * discPct / 100);
    const afterDiscount = subtotal - discountAmount;
    const taxAmount = Math.round(afterDiscount * 0.09); // 9% VAT
    const totalAmount = afterDiscount + taxAmount;

    const quote = await db.quote.create({
      data: {
        quoteNumber,
        leadId: leadId || null,
        karAmuzId: karAmuzId || null,
        assignedTo: assignedTo || '',
        items,
        subtotal,
        discountPct: discPct,
        discountAmount,
        taxAmount,
        totalAmount,
        status: 'DRAFT',
        validUntil: validUntil ? new Date(validUntil) : null,
        notes: notes || null,
        internalNotes: internalNotes || null,
      },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    return NextResponse.json({ پیام: 'پیشنهاد با موفقیت ایجاد شد', داده: quote }, { status: 201 });
  } catch (error) {
    console.error('Quote creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت پیشنهاد' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/quotes — Update quote status
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { quoteId, status, items, discountPct, notes, internalNotes, assignedTo, validUntil } = body;

    if (!quoteId) return NextResponse.json({ خطا: 'شناسه پیشنهاد الزامی است' }, { status: 400 });

    const existing = await db.quote.findUnique({ where: { id: quoteId } });
    if (!existing) return NextResponse.json({ خطا: 'پیشنهاد یافت نشد' }, { status: 404 });

    const updateData: Record<string, unknown> = {};

    if (status) {
      const validStatuses = ['DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'EXPIRED', 'CONVERTED'];
      if (!validStatuses.includes(status)) return NextResponse.json({ خطا: 'وضعیت نامعتبر' }, { status: 400 });
      updateData.status = status;
      if (status === 'SENT') updateData.sentAt = new Date();
      if (status === 'ACCEPTED') updateData.acceptedAt = new Date();
      if (status === 'REJECTED') updateData.rejectedAt = new Date();
    }

    if (items && Array.isArray(items)) {
      updateData.items = items;
      const subtotal = items.reduce((sum: number, item: { total?: number; unitPrice?: number; quantity?: number }) =>
        sum + (item.total || (item.unitPrice || 0) * (item.quantity || 1)), 0);
      const discPct = discountPct !== undefined ? discountPct : existing.discountPct;
      const discountAmount = Math.round(subtotal * Number(discPct) / 100);
      const afterDiscount = subtotal - discountAmount;
      const taxAmount = Math.round(afterDiscount * 0.09);
      const totalAmount = afterDiscount + taxAmount;
      updateData.subtotal = subtotal;
      updateData.discountPct = discPct;
      updateData.discountAmount = discountAmount;
      updateData.taxAmount = taxAmount;
      updateData.totalAmount = totalAmount;
    }

    if (discountPct !== undefined && !items) updateData.discountPct = discountPct;
    if (notes !== undefined) updateData.notes = notes;
    if (internalNotes !== undefined) updateData.internalNotes = internalNotes;
    if (assignedTo !== undefined) updateData.assignedTo = assignedTo;
    if (validUntil !== undefined) updateData.validUntil = validUntil ? new Date(validUntil) : null;

    const updated = await db.quote.update({ where: { id: quoteId }, data: updateData,
      include: { lead: { select: { id: true, name: true } }, karAmuz: { select: { id: true, firstName: true, lastName: true } } },
    });

    return NextResponse.json({ پیام: 'پیشنهاد به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Quote update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی' }, { status: 500 });
  }
}
