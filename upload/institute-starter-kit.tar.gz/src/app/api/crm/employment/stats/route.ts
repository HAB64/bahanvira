import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/employment/stats
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const [
      totalSeekers,
      availableSeekers,
      employedSeekers,
      totalJobs,
      activeJobs,
      totalEmployers,
      verifiedEmployers,
      totalApplications,
      pendingApplications,
      acceptedApplications,
      rejectedApplications,
      interviewApplications,
    ] = await Promise.all([
      db.jobSeeker.count(),
      db.jobSeeker.count({ where: { isAvailable: true, status: 'ACTIVE' } }),
      db.jobSeeker.count({ where: { status: 'EMPLOYED' } }),
      db.jobListing.count(),
      db.jobListing.count({ where: { status: 'ACTIVE' } }),
      db.employer.count(),
      db.employer.count({ where: { isVerified: true } }),
      db.jobApplication.count(),
      db.jobApplication.count({ where: { status: 'PENDING' } }),
      db.jobApplication.count({ where: { status: 'ACCEPTED' } }),
      db.jobApplication.count({ where: { status: 'REJECTED' } }),
      db.jobApplication.count({ where: { status: 'INTERVIEW_SCHEDULED' } }),
    ]);

    // Applications by status
    const applicationsByStatus = await db.jobApplication.groupBy({
      by: ['status'],
      _count: { id: true },
    });

    // Jobs by category
    const jobsByCategory = await db.jobListing.groupBy({
      by: ['category'],
      _count: { id: true },
    });

    // Jobs by type
    const jobsByType = await db.jobListing.groupBy({
      by: ['jobType'],
      _count: { id: true },
    });

    // Match rate
    const matchRate = totalApplications > 0
      ? Math.round((acceptedApplications / totalApplications) * 100)
      : 0;

    // Recent activity (latest 10 applications)
    const recentApplications = await db.jobApplication.findMany({
      take: 10,
      orderBy: { createdAt: 'desc' },
      include: {
        jobListing: { select: { title: true, employer: { select: { companyName: true } } } },
        jobSeeker: { select: { firstName: true, lastName: true } },
      },
    });

    // KarAmuz graduates not yet job seekers
    const graduatedNotSeekers = await db.karAmuz.count({
      where: {
        status: 'GRADUATED',
        jobSeeker: { is: null },
      },
    });

    return NextResponse.json({
      پیام: 'آمار اشتغال با موفقیت دریافت شد',
      داده: {
        کارجویان: { کل: totalSeekers, فعال: availableSeekers, شاغل: employedSeekers },
        فرصت_شغلی: { کل: totalJobs, فعال: activeJobs },
        کارفرمایان: { کل: totalEmployers, تأیید_شده: verifiedEmployers },
        درخواست‌ها: {
          کل: totalApplications,
          در_انتظار: pendingApplications,
          پذیرفته_شده: acceptedApplications,
          رد_شده: rejectedApplications,
          مصاحبه: interviewApplications,
        },
        نرخ_تطبیق: matchRate,
        فارغ‌التحصیلان_بدون_کارجو: graduatedNotSeekers,
        درخواست‌ها_بر_وضعیت: applicationsByStatus,
        مشاغل_بر_دسته: jobsByCategory,
        مشاغل_بر_نوع: jobsByType,
        فعالیت_اخیر: recentApplications,
      },
    });
  } catch (error) {
    console.error('Employment stats error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت آمار اشتغال' }, { status: 500 });
  }
}
