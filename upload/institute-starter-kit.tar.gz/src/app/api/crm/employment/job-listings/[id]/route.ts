import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const job = await db.jobListing.findUnique({
      where: { id },
      include: {
        employer: true,
        applications: {
          include: {
            jobSeeker: { select: { id: true, firstName: true, lastName: true, phone: true, skills: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
        _count: { select: { applications: true } },
      },
    });
    if (!job) return NextResponse.json({ خطا: 'فرصت شغلی یافت نشد' }, { status: 404 });

    // Increment view count
    await db.jobListing.update({ where: { id }, data: { viewCount: { increment: 1 } } });

    return NextResponse.json({ پیام: 'فرصت شغلی دریافت شد', داده: job });
  } catch (error) {
    console.error('Job listing get error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت فرصت شغلی' }, { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const existing = await db.jobListing.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ خطا: 'فرصت شغلی یافت نشد' }, { status: 404 });

    const updateData: Record<string, unknown> = {};
    const fields = [
      'title', 'description', 'category', 'jobType', 'experienceLevel',
      'salaryMin', 'salaryMax', 'requiredSkills', 'requiredEducation',
      'requiredCertifications', 'benefits', 'city', 'address', 'isRemote',
      'status', 'urgency', 'deadline',
    ];
    for (const f of fields) {
      if (body[f] !== undefined) {
        updateData[f] = f === 'deadline' && body[f] ? new Date(body[f]) : body[f];
      }
    }

    const job = await db.jobListing.update({ where: { id }, data: updateData, include: { employer: { select: { id: true, companyName: true } } } });
    return NextResponse.json({ پیام: 'فرصت شغلی بروزرسانی شد', داده: job });
  } catch (error) {
    console.error('Job listing update error:', error);
    return NextResponse.json({ خطا: 'خطا در بروزرسانی فرصت شغلی' }, { status: 500 });
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.jobListing.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ خطا: 'فرصت شغلی یافت نشد' }, { status: 404 });

    const job = await db.jobListing.update({ where: { id }, data: { status: 'CLOSED' } });
    return NextResponse.json({ پیام: 'فرصت شغلی بسته شد', داده: job });
  } catch (error) {
    console.error('Job listing delete error:', error);
    return NextResponse.json({ خطا: 'خطا در حذف فرصت شغلی' }, { status: 500 });
  }
}
