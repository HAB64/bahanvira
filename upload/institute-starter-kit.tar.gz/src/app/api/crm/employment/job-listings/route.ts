import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/employment/job-listings
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const category = searchParams.get('category');
    const jobType = searchParams.get('jobType');
    const city = searchParams.get('city');
    const employerId = searchParams.get('employerId');
    const search = searchParams.get('search');
    const isRemote = searchParams.get('isRemote');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, any> = {};
    if (status) where.status = status;
    if (category) where.category = category;
    if (jobType) where.jobType = jobType;
    if (city) where.city = city;
    if (employerId) where.employerId = employerId;
    if (isRemote === 'true') where.isRemote = true;
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { requiredSkills: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [jobs, total] = await Promise.all([
      db.jobListing.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          employer: { select: { id: true, companyName: true, city: true, isVerified: true } },
          _count: { select: { applications: true } },
        },
      }),
      db.jobListing.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست فرصت‌های شغلی با موفقیت دریافت شد',
      داده‌ها: jobs,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Job listings error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت لیست فرصت‌های شغلی' }, { status: 500 });
  }
}

/**
 * POST /api/crm/employment/job-listings
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      employerId, title, description, category, jobType,
      experienceLevel, salaryMin, salaryMax, requiredSkills,
      requiredEducation, requiredCertifications, benefits,
      city, address, isRemote, urgency, deadline,
    } = body;

    if (!employerId || !title || !description) {
      return NextResponse.json(
        { خطا: 'کارفرما، عنوان و توضیحات شغل الزامی است' },
        { status: 400 }
      );
    }

    const employerExists = await db.employer.findUnique({ where: { id: employerId } });
    if (!employerExists) {
      return NextResponse.json({ خطا: 'کارفرما یافت نشد' }, { status: 400 });
    }

    const job = await db.jobListing.create({
      data: {
        employerId,
        title,
        description,
        category: category || '',
        jobType: jobType || 'FULL_TIME',
        experienceLevel: experienceLevel || 'JUNIOR',
        salaryMin: salaryMin || null,
        salaryMax: salaryMax || null,
        requiredSkills: requiredSkills || '',
        requiredEducation: requiredEducation || '',
        requiredCertifications: requiredCertifications || '',
        benefits: benefits || '',
        city: city || 'Mahmoudabad',
        address: address || null,
        isRemote: isRemote || false,
        urgency: urgency || 'NORMAL',
        deadline: deadline ? new Date(deadline) : null,
      },
      include: {
        employer: { select: { id: true, companyName: true, city: true } },
      },
    });

    // Update employer stats
    await db.employer.update({
      where: { id: employerId },
      data: { totalJobsPosted: { increment: 1 } },
    });

    return NextResponse.json(
      { پیام: 'فرصت شغلی با موفقیت ثبت شد', داده: job },
      { status: 201 }
    );
  } catch (error) {
    console.error('Job listing creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت فرصت شغلی' }, { status: 500 });
  }
}
