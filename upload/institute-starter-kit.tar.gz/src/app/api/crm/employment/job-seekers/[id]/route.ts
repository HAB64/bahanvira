import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const seeker = await db.jobSeeker.findUnique({
      where: { id },
      include: {
        karAmuz: { select: { id: true, firstName: true, lastName: true, studentCode: true, status: true, enrollments: { include: { skillProgram: { select: { name: true } } } } } },
        applications: {
          include: {
            jobListing: { include: { employer: { select: { companyName: true } } } },
          },
          orderBy: { createdAt: 'desc' },
        },
        _count: { select: { applications: true } },
      },
    });
    if (!seeker) return NextResponse.json({ خطا: 'کارجو یافت نشد' }, { status: 404 });

    await db.jobSeeker.update({ where: { id }, data: { profileViews: { increment: 1 } } });
    return NextResponse.json({ پیام: 'کارجو دریافت شد', داده: seeker });
  } catch (error) {
    console.error('Job seeker get error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت اطلاعات کارجو' }, { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const existing = await db.jobSeeker.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ خطا: 'کارجو یافت نشد' }, { status: 404 });

    const updateData: Record<string, unknown> = {};
    const fields = [
      'firstName', 'lastName', 'phone', 'email', 'gender', 'city', 'address',
      'education', 'fieldOfStudy', 'skills', 'certifications', 'experienceYears',
      'currentJob', 'desiredJob', 'desiredSalary', 'desiredJobType', 'status',
      'isAvailable', 'resumeUrl', 'linkedIn', 'portfolioUrl',
    ];
    for (const f of fields) {
      if (body[f] !== undefined) updateData[f] = body[f];
    }
    if (body.dateOfBirth !== undefined) updateData.dateOfBirth = body.dateOfBirth ? new Date(body.dateOfBirth) : null;
    if (body.availableFrom !== undefined) updateData.availableFrom = body.availableFrom ? new Date(body.availableFrom) : null;

    const seeker = await db.jobSeeker.update({ where: { id }, data: updateData });
    return NextResponse.json({ پیام: 'کارجو بروزرسانی شد', داده: seeker });
  } catch (error) {
    console.error('Job seeker update error:', error);
    return NextResponse.json({ خطا: 'خطا در بروزرسانی کارجو' }, { status: 500 });
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.jobSeeker.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ خطا: 'کارجو یافت نشد' }, { status: 404 });

    const seeker = await db.jobSeeker.update({ where: { id }, data: { status: 'BLOCKED' } });
    return NextResponse.json({ پیام: 'کارجو حذف شد', داده: seeker });
  } catch (error) {
    console.error('Job seeker delete error:', error);
    return NextResponse.json({ خطا: 'خطا در حذف کارجو' }, { status: 500 });
  }
}
