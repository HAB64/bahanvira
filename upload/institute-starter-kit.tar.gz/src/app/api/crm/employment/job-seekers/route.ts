import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/employment/job-seekers
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const isAvailable = searchParams.get('isAvailable');
    const city = searchParams.get('city');
    const source = searchParams.get('source');
    const search = searchParams.get('search');
    const karAmuzId = searchParams.get('karAmuzId');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, any> = {};
    if (status) where.status = status;
    if (isAvailable === 'true') where.isAvailable = true;
    if (isAvailable === 'false') where.isAvailable = false;
    if (city) where.city = city;
    if (source) where.source = source;
    if (karAmuzId) where.karAmuzId = karAmuzId;

    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { skills: { contains: search, mode: 'insensitive' } },
        { desiredJob: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [seekers, total] = await Promise.all([
      db.jobSeeker.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          karAmuz: { select: { id: true, firstName: true, lastName: true, studentCode: true, status: true } },
          _count: { select: { applications: true } },
        },
      }),
      db.jobSeeker.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست کارجویان با موفقیت دریافت شد',
      داده‌ها: seekers,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Job seekers error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت لیست کارجویان' }, { status: 500 });
  }
}

/**
 * POST /api/crm/employment/job-seekers
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      karAmuzId, firstName, lastName, phone, email, dateOfBirth,
      gender, city, address, education, fieldOfStudy, skills,
      certifications, experienceYears, currentJob, desiredJob,
      desiredSalary, desiredJobType, availableFrom, resumeUrl,
      linkedIn, portfolioUrl, source,
    } = body;

    if (!firstName || !lastName || !phone) {
      return NextResponse.json(
        { خطا: 'نام، نام خانوادگی و شماره تماس الزامی است' },
        { status: 400 }
      );
    }

    // If karAmuzId provided, check it exists and is GRADUATED
    if (karAmuzId) {
      const karamuz = await db.karAmuz.findUnique({ where: { id: karAmuzId } });
      if (!karamuz) {
        return NextResponse.json({ خطا: 'کارآموز یافت نشد' }, { status: 400 });
      }
      if (karamuz.status !== 'GRADUATED') {
        return NextResponse.json({ خطا: 'فقط کارآموزان فارغ‌التحصیل می‌توانند به عنوان کارجو ثبت شوند' }, { status: 400 });
      }
      // Check not already a job seeker
      const existingSeeker = await db.jobSeeker.findUnique({ where: { karAmuzId } });
      if (existingSeeker) {
        return NextResponse.json({ خطا: 'این کارآموز قبلاً به عنوان کارجو ثبت شده است' }, { status: 409 });
      }
    }

    const seeker = await db.jobSeeker.create({
      data: {
        karAmuzId: karAmuzId || null,
        firstName,
        lastName,
        phone,
        email: email || '',
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
        gender: gender || '',
        city: city || 'Mahmoudabad',
        address: address || null,
        education: education || '',
        fieldOfStudy: fieldOfStudy || '',
        skills: skills || '',
        certifications: certifications || '',
        experienceYears: experienceYears || 0,
        currentJob: currentJob || '',
        desiredJob: desiredJob || '',
        desiredSalary: desiredSalary || null,
        desiredJobType: desiredJobType || 'FULL_TIME',
        availableFrom: availableFrom ? new Date(availableFrom) : null,
        resumeUrl: resumeUrl || null,
        linkedIn: linkedIn || null,
        portfolioUrl: portfolioUrl || null,
        source: source || (karAmuzId ? 'KARAMUZ_GRADUATE' : 'WEB_FORM'),
      },
      include: {
        karAmuz: { select: { id: true, firstName: true, lastName: true, studentCode: true } },
      },
    });

    return NextResponse.json(
      { پیام: 'کارجو با موفقیت ثبت شد', داده: seeker },
      { status: 201 }
    );
  } catch (error) {
    console.error('Job seeker creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت کارجو' }, { status: 500 });
  }
}
