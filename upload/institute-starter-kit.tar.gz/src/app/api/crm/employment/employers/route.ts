import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/employment/employers
 * List employers with search/filter/pagination
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const search = searchParams.get('search');
    const city = searchParams.get('city');
    const industry = searchParams.get('industry');
    const isVerified = searchParams.get('isVerified');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, any> = {};
    if (status) where.status = status;
    if (city) where.city = city;
    if (industry) where.industry = industry;
    if (isVerified === 'true') where.isVerified = true;
    if (isVerified === 'false') where.isVerified = false;

    if (search) {
      where.OR = [
        { companyName: { contains: search, mode: 'insensitive' } },
        { contactPerson: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [employers, total] = await Promise.all([
      db.employer.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          _count: { select: { jobListings: true } },
        },
      }),
      db.employer.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست کارفرمایان با موفقیت دریافت شد',
      داده‌ها: employers,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Employers list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت لیست کارفرمایان' }, { status: 500 });
  }
}

/**
 * POST /api/crm/employment/employers
 * Create a new employer
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      companyName, contactPerson, phone, email, address, city,
      industry, website, description, source, leadId,
    } = body;

    if (!companyName || !contactPerson || !phone) {
      return NextResponse.json(
        { خطا: 'نام شرکت، شخص مسئول و شماره تماس الزامی است' },
        { status: 400 }
      );
    }

    const employer = await db.employer.create({
      data: {
        companyName,
        contactPerson,
        phone,
        email: email || '',
        address: address || null,
        city: city || 'Mahmoudabad',
        industry: industry || '',
        website: website || null,
        description: description || null,
        source: source || 'WEB_FORM',
        leadId: leadId || null,
      },
      include: {
        _count: { select: { jobListings: true } },
      },
    });

    return NextResponse.json(
      { پیام: 'کارفرما با موفقیت ثبت شد', داده: employer },
      { status: 201 }
    );
  } catch (error) {
    console.error('Employer creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت کارفرما' }, { status: 500 });
  }
}
