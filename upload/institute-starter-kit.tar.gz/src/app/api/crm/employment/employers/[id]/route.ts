import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/employment/employers/[id]
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const employer = await db.employer.findUnique({
      where: { id },
      include: {
        jobListings: {
          orderBy: { createdAt: 'desc' },
          include: { _count: { select: { applications: true } } },
        },
        _count: { select: { jobListings: true } },
      },
    });

    if (!employer) {
      return NextResponse.json({ خطا: 'کارفرما یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ پیام: 'کارفرما با موفقیت دریافت شد', داده: employer });
  } catch (error) {
    console.error('Employer get error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت اطلاعات کارفرما' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/employment/employers/[id]
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const existing = await db.employer.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ خطا: 'کارفرما یافت نشد' }, { status: 404 });
    }

    const employer = await db.employer.update({
      where: { id },
      data: {
        ...(body.companyName !== undefined && { companyName: body.companyName }),
        ...(body.contactPerson !== undefined && { contactPerson: body.contactPerson }),
        ...(body.phone !== undefined && { phone: body.phone }),
        ...(body.email !== undefined && { email: body.email }),
        ...(body.address !== undefined && { address: body.address }),
        ...(body.city !== undefined && { city: body.city }),
        ...(body.industry !== undefined && { industry: body.industry }),
        ...(body.website !== undefined && { website: body.website }),
        ...(body.description !== undefined && { description: body.description }),
        ...(body.status !== undefined && { status: body.status }),
        ...(body.isVerified !== undefined && { isVerified: body.isVerified }),
        ...(body.leadId !== undefined && { leadId: body.leadId }),
      },
      include: {
        _count: { select: { jobListings: true } },
      },
    });

    return NextResponse.json({ پیام: 'کارفرما با موفقیت بروزرسانی شد', داده: employer });
  } catch (error) {
    console.error('Employer update error:', error);
    return NextResponse.json({ خطا: 'خطا در بروزرسانی کارفرما' }, { status: 500 });
  }
}

/**
 * DELETE /api/crm/employment/employers/[id] — soft delete
 */
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const existing = await db.employer.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ خطا: 'کارفرما یافت نشد' }, { status: 404 });
    }

    const employer = await db.employer.update({
      where: { id },
      data: { status: 'BLOCKED' },
    });

    return NextResponse.json({ پیام: 'کارفرما با موفقیت حذف شد', داده: employer });
  } catch (error) {
    console.error('Employer delete error:', error);
    return NextResponse.json({ خطا: 'خطا در حذف کارفرما' }, { status: 500 });
  }
}
