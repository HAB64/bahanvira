import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const application = await db.jobApplication.findUnique({
      where: { id },
      include: {
        jobListing: { include: { employer: true } },
        jobSeeker: { include: { karAmuz: { select: { id: true, studentCode: true, enrollments: { include: { skillProgram: { select: { name: true } } } } } } } },
      },
    });
    if (!application) return NextResponse.json({ خطا: 'درخواست یافت نشد' }, { status: 404 });
    return NextResponse.json({ پیام: 'درخواست دریافت شد', داده: application });
  } catch (error) {
    console.error('Application get error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت درخواست' }, { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const existing = await db.jobApplication.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ خطا: 'درخواست یافت نشد' }, { status: 404 });

    const updateData: Record<string, unknown> = {};
    if (body.status !== undefined) {
      updateData.status = body.status;
      // Set timestamps based on status
      const now = new Date();
      if (body.status === 'REVIEWED') updateData.reviewedAt = now;
      if (body.status === 'SHORTLISTED') updateData.shortlistedAt = now;
      if (body.status === 'INTERVIEW_SCHEDULED') updateData.interviewAt = now;
      if (body.status === 'ACCEPTED') {
        updateData.hiredAt = now;
        // Update job seeker status to EMPLOYED
        await db.jobSeeker.update({ where: { id: existing.jobSeekerId }, data: { status: 'EMPLOYED', isAvailable: false } });
        // Update employer totalHired
        const jobListing = await db.jobListing.findUnique({ where: { id: existing.jobListingId } });
        if (jobListing) {
          await db.employer.update({ where: { id: jobListing.employerId }, data: { totalHired: { increment: 1 } } });
        }
      }
      if (body.status === 'REJECTED') updateData.rejectedAt = now;
    }
    if (body.adminNotes !== undefined) updateData.adminNotes = body.adminNotes;
    if (body.employerNotes !== undefined) updateData.employerNotes = body.employerNotes;
    if (body.employerRating !== undefined) updateData.employerRating = body.employerRating;
    if (body.interviewAt !== undefined) updateData.interviewAt = body.interviewAt ? new Date(body.interviewAt) : null;

    const application = await db.jobApplication.update({ where: { id }, data: updateData });
    return NextResponse.json({ پیام: 'وضعیت درخواست بروزرسانی شد', داده: application });
  } catch (error) {
    console.error('Application update error:', error);
    return NextResponse.json({ خطا: 'خطا در بروزرسانی درخواست' }, { status: 500 });
  }
}
