import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/employment/applications
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const jobListingId = searchParams.get('jobListingId');
    const jobSeekerId = searchParams.get('jobSeekerId');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, any> = {};
    if (status) where.status = status;
    if (jobListingId) where.jobListingId = jobListingId;
    if (jobSeekerId) where.jobSeekerId = jobSeekerId;

    const [applications, total] = await Promise.all([
      db.jobApplication.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          jobListing: {
            select: { id: true, title: true, jobType: true, city: true, employer: { select: { id: true, companyName: true } } },
          },
          jobSeeker: {
            select: { id: true, firstName: true, lastName: true, phone: true, skills: true, education: true },
          },
        },
      }),
      db.jobApplication.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست درخواست‌ها با موفقیت دریافت شد',
      داده‌ها: applications,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Applications list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت لیست درخواست‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/employment/applications
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { jobListingId, jobSeekerId, coverLetter, proposedSalary, availableFrom } = body;

    if (!jobListingId || !jobSeekerId) {
      return NextResponse.json(
        { خطا: 'فرصت شغلی و کارجو الزامی است' },
        { status: 400 }
      );
    }

    // Check job listing exists and is active
    const job = await db.jobListing.findUnique({ where: { id: jobListingId } });
    if (!job) return NextResponse.json({ خطا: 'فرصت شغلی یافت نشد' }, { status: 400 });
    if (job.status !== 'ACTIVE') return NextResponse.json({ خطا: 'این فرصت شغلی فعال نیست' }, { status: 400 });

    // Check job seeker exists
    const seeker = await db.jobSeeker.findUnique({ where: { id: jobSeekerId } });
    if (!seeker) return NextResponse.json({ خطا: 'کارجو یافت نشد' }, { status: 400 });

    // Check not already applied
    const existingApp = await db.jobApplication.findUnique({
      where: { jobListingId_jobSeekerId: { jobListingId, jobSeekerId } },
    });
    if (existingApp) {
      return NextResponse.json({ خطا: 'شما قبلاً برای این شغل درخواست داده‌اید' }, { status: 409 });
    }

    const application = await db.jobApplication.create({
      data: {
        jobListingId,
        jobSeekerId,
        coverLetter: coverLetter || null,
        proposedSalary: proposedSalary || null,
        availableFrom: availableFrom ? new Date(availableFrom) : null,
      },
      include: {
        jobListing: { select: { id: true, title: true, employer: { select: { companyName: true } } } },
        jobSeeker: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    // Update stats
    await Promise.all([
      db.jobListing.update({ where: { id: jobListingId }, data: { applicationCount: { increment: 1 } } }),
      db.jobSeeker.update({ where: { id: jobSeekerId }, data: { applicationCount: { increment: 1 } } }),
    ]);

    return NextResponse.json(
      { پیام: 'درخواست شما با موفقیت ثبت شد', داده: application },
      { status: 201 }
    );
  } catch (error) {
    console.error('Application creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت درخواست' }, { status: 500 });
  }
}
