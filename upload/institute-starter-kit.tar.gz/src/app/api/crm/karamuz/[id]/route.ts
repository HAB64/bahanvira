import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/karamuz/[id]
 * Get a single KarAmuz with full details including all relations.
 */
export async function GET(
  _request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const karAmuz = await db.karAmuz.findUnique({
      where: { id },
      include: {
        enrollments: {
          include: {
            skillProgram: {
              select: {
                id: true,
                name: true,
                code: true,
                totalHours: true,
                theoryHours: true,
                practicalHours: true,
                minAttendancePct: true,
                instructorName: true,
              },
            },
          },
          orderBy: { enrollmentDate: 'desc' },
        },
        attendances: {
          include: {
            session: {
              select: {
                id: true,
                date: true,
                title: true,
                type: true,
                startTime: true,
                endTime: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        evaluations: {
          orderBy: { date: 'desc' },
        },
        certificates: {
          include: {
            skillProgram: {
              select: {
                id: true,
                name: true,
                code: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        payments: {
          orderBy: { createdAt: 'desc' },
        },
        lead: true,
      },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      پیام: 'اطلاعات کارآموز با موفقیت دریافت شد',
      داده: karAmuz,
    });
  } catch (error) {
    console.error('KarAmuz get error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت اطلاعات کارآموز' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/crm/karamuz/[id]
 * Update a KarAmuz.
 * - nationalId is immutable after creation
 * - If status changes to GRADUATED → set actualEndDate to now
 * - If status changes to DROPPED → set actualEndDate to now
 */
export async function PATCH(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // Check if KarAmuz exists
    const existing = await db.karAmuz.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { خطا: 'کارآموز مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // nationalId is immutable
    if (body.nationalId && body.nationalId !== existing.nationalId) {
      return NextResponse.json(
        { خطا: 'کد ملی قابل تغییر نیست' },
        { status: 400 }
      );
    }

    // Validate status if provided
    const validStatuses = ['ACTIVE', 'GRADUATED', 'DROPPED', 'SUSPENDED'];
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { خطا: 'وضعیت نامعتبر است. مقادیر مجاز: ACTIVE, GRADUATED, DROPPED, SUSPENDED' },
        { status: 400 }
      );
    }

    // Validate phone if provided
    if (body.phone) {
      const phoneRegex = /^09[0-9]{9}$/;
      if (!phoneRegex.test(body.phone)) {
        return NextResponse.json(
          { خطا: 'شماره موبایل نامعتبر است (فرمت: 09123456789)' },
          { status: 400 }
        );
      }
    }

    // Validate studentCode uniqueness if being changed
    if (body.studentCode && body.studentCode !== existing.studentCode) {
      const codeExists = await db.karAmuz.findUnique({
        where: { studentCode: body.studentCode },
      });
      if (codeExists) {
        return NextResponse.json(
          { خطا: 'کد کارآموزی وارد شده قبلاً استفاده شده است' },
          { status: 409 }
        );
      }
    }

    // Validate leadId if provided
    if (body.leadId && body.leadId !== existing.leadId) {
      const leadExists = await db.lead.findUnique({ where: { id: body.leadId } });
      if (!leadExists) {
        return NextResponse.json(
          { خطا: 'لید مورد نظر یافت نشد' },
          { status: 400 }
        );
      }
    }

    // Build update data from allowed fields
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const updateData: Record<string, any> = {};

    const allowedFields = [
      'studentCode', 'firstName', 'lastName', 'phone',
      'email', 'photo', 'education', 'fatherName',
      'address', 'city', 'leadId', 'status',
      'startDate', 'expectedEndDate', 'actualEndDate', 'notes',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field];
      }
    }

    // Handle dateOfBirth separately (needs Date conversion)
    if (body.dateOfBirth !== undefined) {
      updateData.dateOfBirth = body.dateOfBirth ? new Date(body.dateOfBirth) : null;
    }

    // Convert date strings to Date objects
    if (updateData.startDate) {
      updateData.startDate = new Date(updateData.startDate);
    }
    if (updateData.expectedEndDate) {
      updateData.expectedEndDate = new Date(updateData.expectedEndDate);
    }
    if (updateData.actualEndDate) {
      updateData.actualEndDate = new Date(updateData.actualEndDate);
    }

    // Handle status transitions
    if (body.status && body.status !== existing.status) {
      if (body.status === 'GRADUATED' || body.status === 'DROPPED') {
        updateData.actualEndDate = new Date();
      }

      // If reactivating from GRADUATED/DROPPED back to ACTIVE, clear actualEndDate
      if (body.status === 'ACTIVE' && (existing.status === 'GRADUATED' || existing.status === 'DROPPED')) {
        updateData.actualEndDate = null;
      }
    }

    const updatedKarAmuz = await db.karAmuz.update({
      where: { id },
      data: updateData,
      include: {
        enrollments: {
          include: {
            skillProgram: {
              select: {
                id: true,
                name: true,
                code: true,
                totalHours: true,
              },
            },
          },
        },
        _count: {
          select: {
            attendances: true,
            evaluations: true,
            certificates: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'اطلاعات کارآموز با موفقیت به‌روزرسانی شد',
      داده: updatedKarAmuz,
    });
  } catch (error) {
    console.error('KarAmuz update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی اطلاعات کارآموز' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/crm/karamuz/[id]
 * Soft delete: set status to DROPPED and actualEndDate to now.
 * Does not actually delete the record.
 */
export async function DELETE(
  _request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    // Check if KarAmuz exists
    const existing = await db.karAmuz.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { خطا: 'کارآموز مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Already dropped
    if (existing.status === 'DROPPED') {
      return NextResponse.json(
        { خطا: 'این کارآموز قبلاً انصراف داده شده است' },
        { status: 400 }
      );
    }

    // Soft delete: set status to DROPPED and actualEndDate to now
    const updatedKarAmuz = await db.karAmuz.update({
      where: { id },
      data: {
        status: 'DROPPED',
        actualEndDate: new Date(),
      },
    });

    return NextResponse.json({
      پیام: 'کارآموز با موفقیت انصراف داده شد (حذف نرم)',
      داده: updatedKarAmuz,
    });
  } catch (error) {
    console.error('KarAmuz soft delete error:', error);
    return NextResponse.json(
      { خطا: 'خطا در انصراف کارآموز' },
      { status: 500 }
    );
  }
}
