import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/karamuz
 * List KarAmuz with filtering, sorting, and pagination.
 * Query params: status, search, skillProgramId, page, limit, sort, order
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    // Filters
    const status = searchParams.get('status');
    const search = searchParams.get('search');
    const skillProgramId = searchParams.get('skillProgramId');

    // Sorting
    const sort = searchParams.get('sort') || 'createdAt';
    const order = searchParams.get('order') || 'desc';

    // Pagination
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    // Build where clause
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const where: Record<string, any> = {};

    if (status) {
      where.status = status;
    }

    if (skillProgramId) {
      where.enrollments = {
        some: { skillProgramId },
      };
    }

    if (search) {
      where.OR = [
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { nationalId: { contains: search } },
        { phone: { contains: search } },
        { studentCode: { contains: search, mode: 'insensitive' } },
      ];
    }

    // Validate sort field
    const allowedSortFields = [
      'createdAt', 'firstName', 'lastName', 'nationalId',
      'phone', 'status', 'startDate', 'studentCode', 'city',
    ];
    const sortField = allowedSortFields.includes(sort) ? sort : 'createdAt';
    const sortOrder = order === 'asc' ? 'asc' : 'desc';

    const [karamuzHa, total] = await Promise.all([
      db.karAmuz.findMany({
        where,
        orderBy: { [sortField]: sortOrder },
        skip,
        take: limit,
        include: {
          enrollments: {
            include: {
              skillProgram: {
                select: {
                  id: true,
                  name: true,
                  code: true,
                  totalHours: true,
                },
              },
            },
          },
          _count: {
            select: {
              attendances: true,
              evaluations: true,
              certificates: true,
            },
          },
        },
      }),
      db.karAmuz.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست کارآموزان با موفقیت دریافت شد',
      داده‌ها: karamuzHa,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('KarAmuz list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست کارآموزان' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/karamuz
 * Create a new KarAmuz (trainee).
 * Required: nationalId, firstName, lastName, phone
 * Auto-generates studentCode if not provided (format: BR-YYYY-XXXX)
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      nationalId,
      firstName,
      lastName,
      phone,
      studentCode,
      email,
      photo,
      dateOfBirth,
      education,
      fatherName,
      address,
      city,
      leadId,
      startDate,
      expectedEndDate,
      notes,
      status,
    } = body;

    // --- Validate required fields ---
    if (!nationalId || !firstName || !lastName || !phone) {
      return NextResponse.json(
        { خطا: 'کد ملی، نام، نام خانوادگی و شماره تماس الزامی است' },
        { status: 400 }
      );
    }

    // --- Validate nationalId (10-digit Iranian national ID) ---
    if (!/^\d{10}$/.test(nationalId)) {
      return NextResponse.json(
        { خطا: 'کد ملی نامعتبر است (باید ۱۰ رقم باشد)' },
        { status: 400 }
      );
    }

    // Check nationalId checksum (standard Iranian validation)
    const digits = nationalId.split('').map(Number);
    const checkDigit = digits[9];
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      sum += digits[i] * (10 - i);
    }
    const remainder = sum % 11;
    const isValid =
      (remainder < 2 && checkDigit === remainder) ||
      (remainder >= 2 && checkDigit === 11 - remainder);

    if (!isValid) {
      return NextResponse.json(
        { خطا: 'کد ملی نامعتبر است (رقم کنترل اشتباه است)' },
        { status: 400 }
      );
    }

    // --- Validate phone (09XXXXXXXXX format) ---
    const phoneRegex = /^09[0-9]{9}$/;
    if (!phoneRegex.test(phone)) {
      return NextResponse.json(
        { خطا: 'شماره موبایل نامعتبر است (فرمت: 09123456789)' },
        { status: 400 }
      );
    }

    // --- Check for duplicate nationalId ---
    const existing = await db.karAmuz.findUnique({
      where: { nationalId },
    });
    if (existing) {
      return NextResponse.json(
        { خطا: 'کارآموزی با این کد ملی قبلاً ثبت شده است' },
        { status: 409 }
      );
    }

    // --- Auto-generate studentCode if not provided ---
    let finalStudentCode = studentCode;
    if (!finalStudentCode) {
      const currentYear = new Date().getFullYear();
      const prefix = `BR-${currentYear}-`;

      // Find the last studentCode with this prefix to determine next sequential number
      const lastKarAmuz = await db.karAmuz.findFirst({
        where: {
          studentCode: { startsWith: prefix },
        },
        orderBy: { studentCode: 'desc' },
        select: { studentCode: true },
      });

      let nextNumber = 1;
      if (lastKarAmuz?.studentCode) {
        const lastNumberStr = lastKarAmuz.studentCode.replace(prefix, '');
        const lastNumber = parseInt(lastNumberStr, 10);
        if (!isNaN(lastNumber)) {
          nextNumber = lastNumber + 1;
        }
      }

      finalStudentCode = `${prefix}${String(nextNumber).padStart(4, '0')}`;
    } else {
      // If studentCode is manually provided, check for uniqueness
      const existingCode = await db.karAmuz.findUnique({
        where: { studentCode: finalStudentCode },
      });
      if (existingCode) {
        return NextResponse.json(
          { خطا: 'کد کارآموزی وارد شده قبلاً استفاده شده است' },
          { status: 409 }
        );
      }
    }

    // --- Validate leadId if provided ---
    if (leadId) {
      const leadExists = await db.lead.findUnique({ where: { id: leadId } });
      if (!leadExists) {
        return NextResponse.json(
          { خطا: 'لید مورد نظر یافت نشد' },
          { status: 400 }
        );
      }
    }

    // --- Validate status if provided ---
    const validStatuses = ['ACTIVE', 'GRADUATED', 'DROPPED', 'SUSPENDED'];
    const finalStatus = status || 'ACTIVE';
    if (!validStatuses.includes(finalStatus)) {
      return NextResponse.json(
        { خطا: 'وضعیت نامعتبر است. مقادیر مجاز: ACTIVE, GRADUATED, DROPPED, SUSPENDED' },
        { status: 400 }
      );
    }

    // --- Create the KarAmuz ---
    const karAmuz = await db.karAmuz.create({
      data: {
        nationalId,
        studentCode: finalStudentCode,
        firstName,
        lastName,
        phone,
        email: email || null,
        photo: photo || null,
        dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
        education: education || null,
        fatherName: fatherName || null,
        address: address || null,
        city: city || 'Mahmoudabad',
        leadId: leadId || null,
        status: finalStatus,
        startDate: startDate ? new Date(startDate) : new Date(),
        expectedEndDate: expectedEndDate ? new Date(expectedEndDate) : null,
        notes: notes || null,
      },
      include: {
        enrollments: {
          include: {
            skillProgram: {
              select: {
                id: true,
                name: true,
                code: true,
                totalHours: true,
              },
            },
          },
        },
        _count: {
          select: {
            attendances: true,
            evaluations: true,
            certificates: true,
          },
        },
      },
    });

    return NextResponse.json(
      {
        پیام: 'کارآموز با موفقیت ثبت شد',
        داده: karAmuz,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('KarAmuz creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت کارآموز جدید' },
      { status: 500 }
    );
  }
}
