import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

const VALID_TYPES = ['FOLLOW_UP', 'CALL', 'MEETING', 'DOCUMENT', 'PAYMENT_REMINDER', 'OTHER'] as const;
const VALID_PRIORITIES = ['LOW', 'MEDIUM', 'HIGH', 'URGENT'] as const;
const VALID_STATUSES = ['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'] as const;

/**
 * GET /api/crm/tasks/[id]
 * Get a single task with lead and karAmuz relations.
 */
export async function GET(
  _request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const task = await db.task.findUnique({
      where: { id },
      include: {
        lead: {
          select: { id: true, name: true, phone: true, stage: true },
        },
        karAmuz: {
          select: { id: true, firstName: true, lastName: true, status: true },
        },
      },
    });

    if (!task) {
      return NextResponse.json(
        { خطا: 'وظیفه مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      پیام: 'اطلاعات وظیفه با موفقیت دریافت شد',
      داده: task,
    });
  } catch (error) {
    console.error('Task get error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت اطلاعات وظیفه' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/crm/tasks/[id]
 * Update a task.
 * - If status changes to COMPLETED, auto-set completedAt = now
 * - If status changes from COMPLETED to something else, clear completedAt
 */
export async function PATCH(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // Check if task exists
    const existingTask = await db.task.findUnique({ where: { id } });
    if (!existingTask) {
      return NextResponse.json(
        { خطا: 'وظیفه مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate type if provided
    if (body.type && !VALID_TYPES.includes(body.type)) {
      return NextResponse.json(
        { خطا: `نوع وظیفه نامعتبر است. مقادیر مجاز: ${VALID_TYPES.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate priority if provided
    if (body.priority && !VALID_PRIORITIES.includes(body.priority)) {
      return NextResponse.json(
        { خطا: `اولویت نامعتبر است. مقادیر مجاز: ${VALID_PRIORITIES.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate status if provided
    if (body.status && !VALID_STATUSES.includes(body.status)) {
      return NextResponse.json(
        { خطا: `وضعیت نامعتبر است. مقادیر مجاز: ${VALID_STATUSES.join(', ')}` },
        { status: 400 }
      );
    }

    // Build update data
    const updateData: Record<string, unknown> = {};

    const allowedFields = [
      'title', 'description', 'type', 'priority', 'status',
      'dueDate', 'assignedTo', 'leadId', 'karAmuzId',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field];
      }
    }

    // Handle dueDate conversion
    if (body.dueDate !== undefined) {
      updateData.dueDate = body.dueDate ? new Date(body.dueDate) : null;
    }

    // Handle completedAt based on status change
    const newStatus = body.status;
    const oldStatus = existingTask.status;

    if (newStatus === 'COMPLETED' && oldStatus !== 'COMPLETED') {
      // Status changing TO completed — auto-set completedAt
      updateData.completedAt = new Date();
    } else if (newStatus && newStatus !== 'COMPLETED' && oldStatus === 'COMPLETED') {
      // Status changing FROM completed to something else — clear completedAt
      updateData.completedAt = null;
    }

    const updatedTask = await db.task.update({
      where: { id },
      data: updateData,
      include: {
        lead: {
          select: { id: true, name: true, phone: true },
        },
        karAmuz: {
          select: { id: true, firstName: true, lastName: true },
        },
      },
    });

    return NextResponse.json({
      پیام: 'وظیفه با موفقیت به‌روزرسانی شد',
      داده: updatedTask,
    });
  } catch (error) {
    console.error('Task update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی وظیفه' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/crm/tasks/[id]
 * Delete a task.
 */
export async function DELETE(
  _request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    // Check if task exists
    const existingTask = await db.task.findUnique({ where: { id } });
    if (!existingTask) {
      return NextResponse.json(
        { خطا: 'وظیفه مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    await db.task.delete({ where: { id } });

    return NextResponse.json({
      پیام: 'وظیفه با موفقیت حذف شد',
    });
  } catch (error) {
    console.error('Task delete error:', error);
    return NextResponse.json(
      { خطا: 'خطا در حذف وظیفه' },
      { status: 500 }
    );
  }
}
