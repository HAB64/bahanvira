import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
const VALID_TYPES = ['FOLLOW_UP', 'CALL', 'MEETING', 'DOCUMENT', 'PAYMENT_REMINDER', 'OTHER'] as const;
const VALID_PRIORITIES = ['LOW', 'MEDIUM', 'HIGH', 'URGENT'] as const;
const VALID_STATUSES = ['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'] as const;

// Priority sort order: URGENT=0, HIGH=1, MEDIUM=2, LOW=3
const PRIORITY_ORDER: Record<string, number> = {
  URGENT: 0,
  HIGH: 1,
  MEDIUM: 2,
  LOW: 3,
};

/**
 * GET /api/crm/tasks
 * List tasks with filtering, sorting, and pagination.
 * Query params: status, priority, type, assignedTo, leadId, karAmuzId, overdue, search
 * Sort: priority (URGENT first), then dueDate asc
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    // Filters
    const status = searchParams.get('status');
    const priority = searchParams.get('priority');
    const type = searchParams.get('type');
    const assignedTo = searchParams.get('assignedTo');
    const leadId = searchParams.get('leadId');
    const karAmuzId = searchParams.get('karAmuzId');
    const overdue = searchParams.get('overdue');
    const search = searchParams.get('search');

    // Pagination
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '50', 10)));
    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {};

    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (type) where.type = type;
    if (assignedTo) where.assignedTo = assignedTo;
    if (leadId) where.leadId = leadId;
    if (karAmuzId) where.karAmuzId = karAmuzId;

    if (overdue === 'true') {
      where.status = { not: 'COMPLETED' };
      where.dueDate = { lt: new Date() };
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [tasks, total] = await Promise.all([
      db.task.findMany({
        where,
        include: {
          lead: {
            select: { name: true, phone: true },
          },
          karAmuz: {
            select: { firstName: true, lastName: true },
          },
        },
        orderBy: [
          { priority: 'desc' }, // We'll sort programmatically below for URGENT-first
          { dueDate: 'asc' },
        ],
        skip,
        take: limit,
      }),
      db.task.count({ where }),
    ]);

    // Re-sort by custom priority order (URGENT first), then dueDate asc
    tasks.sort((a, b) => {
      const pA = PRIORITY_ORDER[a.priority] ?? 99;
      const pB = PRIORITY_ORDER[b.priority] ?? 99;
      if (pA !== pB) return pA - pB;
      // Secondary sort: dueDate asc (nulls last)
      if (!a.dueDate && !b.dueDate) return 0;
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    });

    return NextResponse.json({
      پیام: 'لیست وظایف با موفقیت دریافت شد',
      داده‌ها: tasks,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Tasks list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست وظایف' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/tasks
 * Create a new task.
 * Required: title
 * Optional: description, type (default FOLLOW_UP), priority (default MEDIUM),
 *           status (default PENDING), dueDate, assignedTo, leadId, karAmuzId
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      title,
      description,
      type,
      priority,
      status,
      dueDate,
      assignedTo,
      leadId,
      karAmuzId,
    } = body;

    // Validate required fields
    if (!title || typeof title !== 'string' || title.trim() === '') {
      return NextResponse.json(
        { خطا: 'عنوان وظیفه الزامی است' },
        { status: 400 }
      );
    }

    // Validate type
    const taskType = type || 'FOLLOW_UP';
    if (!VALID_TYPES.includes(taskType)) {
      return NextResponse.json(
        { خطا: `نوع وظیفه نامعتبر است. مقادیر مجاز: ${VALID_TYPES.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate priority
    const taskPriority = priority || 'MEDIUM';
    if (!VALID_PRIORITIES.includes(taskPriority)) {
      return NextResponse.json(
        { خطا: `اولویت نامعتبر است. مقادیر مجاز: ${VALID_PRIORITIES.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate status
    const taskStatus = status || 'PENDING';
    if (!VALID_STATUSES.includes(taskStatus)) {
      return NextResponse.json(
        { خطا: `وضعیت نامعتبر است. مقادیر مجاز: ${VALID_STATUSES.join(', ')}` },
        { status: 400 }
      );
    }

    // If status is COMPLETED, set completedAt
    const completedAt = taskStatus === 'COMPLETED' ? new Date() : null;

    const task = await db.task.create({
      data: {
        title: title.trim(),
        description: description || null,
        type: taskType,
        priority: taskPriority,
        status: taskStatus,
        dueDate: dueDate ? new Date(dueDate) : null,
        completedAt,
        assignedTo: assignedTo || '',
        leadId: leadId || null,
        karAmuzId: karAmuzId || null,
      },
      include: {
        lead: {
          select: { name: true, phone: true },
        },
        karAmuz: {
          select: { firstName: true, lastName: true },
        },
      },
    });

    return NextResponse.json(
      {
        پیام: 'وظیفه با موفقیت ایجاد شد',
        داده: task,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Task creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت وظیفه جدید' },
      { status: 500 }
    );
  }
}
