import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/email-logs — List email logs with filters
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const leadId = searchParams.get('leadId');
    const karAmuzId = searchParams.get('karAmuzId');
    const status = searchParams.get('status');
    const campaignId = searchParams.get('campaignId');
    const templateId = searchParams.get('templateId');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (leadId) where.leadId = leadId;
    if (karAmuzId) where.karAmuzId = karAmuzId;
    if (status) where.status = status;
    if (campaignId) where.campaignId = campaignId;
    if (templateId) where.templateId = templateId;
    if (search) {
      where.OR = [
        { to: { contains: search, mode: 'insensitive' } },
        { subject: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [logs, total] = await Promise.all([
      db.emailLog.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          lead: { select: { id: true, name: true, phone: true } },
          karAmuz: { select: { id: true, firstName: true, lastName: true } },
        },
      }),
      db.emailLog.count({ where }),
    ]);

    // Summary stats by status
    const stats = await db.emailLog.groupBy({
      by: ['status'],
      _count: { id: true },
      where,
    });

    return NextResponse.json({
      پیام: 'لیست لاگ ایمیل با موفقیت دریافت شد',
      داده‌ها: logs,
      آمار: stats.reduce((acc, s) => ({ ...acc, [s.status]: s._count.id }), {} as Record<string, number>),
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Email logs list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت لاگ ایمیل' }, { status: 500 });
  }
}
