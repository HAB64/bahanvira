import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/churn-predictions — List predictions with risk level filter
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const riskLevel = searchParams.get('riskLevel');
    const leadId = searchParams.get('leadId');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (riskLevel) where.riskLevel = riskLevel;
    if (leadId) where.leadId = leadId;

    const [predictions, total] = await Promise.all([
      db.churnPrediction.findMany({
        where, skip, take: limit,
        orderBy: { riskScore: 'desc' },
        include: {
          lead: { select: { id: true, name: true, phone: true, segment: true, cluster: true, stage: true } },
        },
      }),
      db.churnPrediction.count({ where }),
    ]);

    // Stats
    const stats = await db.churnPrediction.groupBy({
      by: ['riskLevel'],
      _count: { riskLevel: true },
    });

    return NextResponse.json({
      پیام: 'لیست پیش‌بینی ریزش با موفقیت دریافت شد',
      داده‌ها: predictions,
      آمار: Object.fromEntries(stats.map(s => [s.riskLevel, s._count.riskLevel])),
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Churn predictions list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت پیش‌بینی‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/churn-predictions — Generate prediction for a specific lead
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { leadId } = body;

    if (!leadId) {
      return NextResponse.json({ خطا: 'شناسه لید الزامی است' }, { status: 400 });
    }

    const lead = await db.lead.findUnique({
      where: { id: leadId },
      include: {
        payments: true,
        activityLogs: { orderBy: { createdAt: 'desc' }, take: 5 },
        karAmuz: { include: { enrollments: true, attendances: true } },
      },
    });

    if (!lead) {
      return NextResponse.json({ خطا: 'لید یافت نشد' }, { status: 404 });
    }

    // Rule-based churn prediction (fallback)
    let riskScore = 0;
    const factors: Record<string, string> = {};
    const recommendedActions: string[] = [];

    // Factor: No recent contact
    const daysSinceContact = lead.lastContactedAt
      ? Math.floor((Date.now() - new Date(lead.lastContactedAt).getTime()) / (1000 * 60 * 60 * 24))
      : 999;
    if (daysSinceContact > 30) {
      riskScore += 0.3;
      factors['بدون تماس اخیر'] = `${daysSinceContact} روز بدون تماس`;
      recommendedActions.push('تماس تلفنی فوری');
    }

    // Factor: AT_RISK or CHURNED segment
    if (lead.segment === 'AT_RISK' || lead.segment === 'CHURNED') {
      riskScore += 0.25;
      factors['بخش‌بندی'] = `بخش ${lead.segment}`;
      recommendedActions.push('ارائه تخفیف ویژه');
    }

    // Factor: Low satisfaction
    if (lead.satisfactionScore && lead.satisfactionScore <= 2) {
      riskScore += 0.2;
      factors['رضایت پایین'] = `امتیاز ${lead.satisfactionScore} از ۵`;
      recommendedActions.push('بررسی مشکلات و تماس مدیر');
    }

    // Factor: OVERDUE payments
    const overduePayments = lead.payments.filter(p => p.status === 'OVERDUE');
    if (overduePayments.length > 0) {
      riskScore += 0.15;
      factors['پرداخت معوق'] = `${overduePayments.length} فاکتور معوق`;
      recommendedActions.push('پیگیری پرداخت');
    }

    // Factor: Stage stuck in CONTACTED/INTERESTED for too long
    if ((lead.stage === 'CONTACTED' || lead.stage === 'INTERESTED') && daysSinceContact > 14) {
      riskScore += 0.1;
      factors['مرحله متوقف'] = `لید در مرحله ${lead.stage}`;
      recommendedActions.push('مشاوره رایگان پیشنهاد شود');
    }

    // Cap risk score
    riskScore = Math.min(1.0, riskScore);

    // Determine risk level
    let riskLevel = 'LOW';
    if (riskScore >= 0.8) riskLevel = 'CRITICAL';
    else if (riskScore >= 0.5) riskLevel = 'HIGH';
    else if (riskScore >= 0.3) riskLevel = 'MEDIUM';

    const reasoning = `بر اساس تحلیل ${Object.keys(factors).length} عامل، سطح ریسک ${riskLevel} ارزیابی شد. ${Object.entries(factors).map(([k, v]) => `${k}: ${v}`).join('؛ ')}`;

    // Upsert prediction
    const prediction = await db.churnPrediction.upsert({
      where: { leadId },
      update: {
        riskLevel,
        riskScore,
        factors,
        reasoning,
        recommendedActions: JSON.stringify(recommendedActions),
        predictedAt: new Date(),
      },
      create: {
        leadId,
        riskLevel,
        riskScore,
        factors,
        reasoning,
        recommendedActions: JSON.stringify(recommendedActions),
      },
      include: {
        lead: { select: { id: true, name: true, phone: true, segment: true, cluster: true, stage: true } },
      },
    });

    return NextResponse.json({ پیام: 'پیش‌بینی با موفقیت انجام شد', داده: prediction }, { status: 201 });
  } catch (error) {
    console.error('Churn prediction error:', error);
    return NextResponse.json({ خطا: 'خطا در پیش‌بینی ریزش' }, { status: 500 });
  }
}
