import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * POST /api/crm/churn-predictions/batch — Run batch prediction for ALL leads
 */
export async function POST() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    // Get all leads that are candidates for churn prediction
    const leads = await db.lead.findMany({
      where: {
        stage: { notIn: ['REJECTED', 'ARCHIVED'] },
      },
      include: {
        payments: true,
      },
    });

    let processed = 0;
    const results: { leadId: string; riskLevel: string; riskScore: number }[] = [];

    for (const lead of leads) {
      let riskScore = 0;
      const factors: Record<string, string> = {};
      const recommendedActions: string[] = [];

      // Factor: No recent contact
      const daysSinceContact = lead.lastContactedAt
        ? Math.floor((Date.now() - new Date(lead.lastContactedAt).getTime()) / (1000 * 60 * 60 * 24))
        : 999;
      if (daysSinceContact > 30) {
        riskScore += 0.3;
        factors['بدون تماس اخیر'] = `${daysSinceContact} روز بدون تماس`;
        recommendedActions.push('تماس تلفنی فوری');
      }

      // Factor: AT_RISK or CHURNED segment
      if (lead.segment === 'AT_RISK' || lead.segment === 'CHURNED') {
        riskScore += 0.25;
        factors['بخش‌بندی'] = `بخش ${lead.segment}`;
        recommendedActions.push('ارائه تخفیف ویژه');
      }

      // Factor: Low satisfaction
      if (lead.satisfactionScore && lead.satisfactionScore <= 2) {
        riskScore += 0.2;
        factors['رضایت پایین'] = `امتیاز ${lead.satisfactionScore} از ۵`;
        recommendedActions.push('بررسی مشکلات و تماس مدیر');
      }

      // Factor: OVERDUE payments
      const overduePayments = lead.payments.filter(p => p.status === 'OVERDUE');
      if (overduePayments.length > 0) {
        riskScore += 0.15;
        factors['پرداخت معوق'] = `${overduePayments.length} فاکتور معوق`;
        recommendedActions.push('پیگیری پرداخت');
      }

      // Factor: Stage stuck
      if ((lead.stage === 'CONTACTED' || lead.stage === 'INTERESTED') && daysSinceContact > 14) {
        riskScore += 0.1;
        factors['مرحله متوقف'] = `لید در مرحله ${lead.stage}`;
        recommendedActions.push('مشاوره رایگان پیشنهاد شود');
      }

      riskScore = Math.min(1.0, riskScore);

      let riskLevel = 'LOW';
      if (riskScore >= 0.8) riskLevel = 'CRITICAL';
      else if (riskScore >= 0.5) riskLevel = 'HIGH';
      else if (riskScore >= 0.3) riskLevel = 'MEDIUM';

      const reasoning = `بر اساس تحلیل ${Object.keys(factors).length} عامل، سطح ریسک ${riskLevel} ارزیابی شد. ${Object.entries(factors).map(([k, v]) => `${k}: ${v}`).join('؛ ')}`;

      await db.churnPrediction.upsert({
        where: { leadId: lead.id },
        update: {
          riskLevel,
          riskScore,
          factors,
          reasoning,
          recommendedActions: JSON.stringify(recommendedActions),
          predictedAt: new Date(),
        },
        create: {
          leadId: lead.id,
          riskLevel,
          riskScore,
          factors,
          reasoning,
          recommendedActions: JSON.stringify(recommendedActions),
        },
      });

      results.push({ leadId: lead.id, riskLevel, riskScore });
      processed++;
    }

    return NextResponse.json({
      پیام: `پیش‌بینی ریزش برای ${processed} لید انجام شد`,
      تعداد: processed,
      نتایج: results,
    });
  } catch (error) {
    console.error('Batch churn prediction error:', error);
    return NextResponse.json({ خطا: 'خطا در پیش‌بینی دسته‌ای' }, { status: 500 });
  }
}
