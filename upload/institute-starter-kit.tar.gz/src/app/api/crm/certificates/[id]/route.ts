import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * PATCH /api/crm/certificates/[id]
 * Update a certificate's status and other fields.
 * Body: { status?, issueDate?, certificateNo?, qrCode?, pdfUrl? }
 */
export async function PATCH(
  request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const body = await request.json();
    const { status, issueDate, certificateNo, qrCode, pdfUrl } = body;

    // Check if certificate exists
    const existing = await db.certificate.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { خطا: 'گواهینامه مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate status if provided
    const validStatuses = ['PENDING', 'EXAM_REGISTERED', 'EXAM_PASSED', 'EXAM_FAILED', 'ISSUED'];
    if (status && !validStatuses.includes(status)) {
      return NextResponse.json(
        { خطا: `وضعیت نامعتبر است. مقادیر مجاز: ${validStatuses.join(', ')}` },
        { status: 400 }
      );
    }

    // Build update data
    const updateData: Record<string, unknown> = {};

    if (status !== undefined) updateData.status = status;
    if (issueDate !== undefined) updateData.issueDate = issueDate ? new Date(issueDate) : null;
    if (certificateNo !== undefined) updateData.certificateNo = certificateNo;
    if (qrCode !== undefined) updateData.qrCode = qrCode;
    if (pdfUrl !== undefined) updateData.pdfUrl = pdfUrl;

    // If status is ISSUED, set issueDate to now if not provided
    if (status === 'ISSUED' && !issueDate) {
      updateData.issueDate = new Date();
    }

    const updatedCertificate = await db.certificate.update({
      where: { id },
      data: updateData,
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
          },
        },
        skillProgram: {
          select: {
            id: true,
            name: true,
            code: true,
            totalHours: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'گواهینامه با موفقیت به‌روزرسانی شد',
      داده: updatedCertificate,
    });
  } catch (error) {
    console.error('Certificate update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی گواهینامه' },
      { status: 500 }
    );
  }
}
