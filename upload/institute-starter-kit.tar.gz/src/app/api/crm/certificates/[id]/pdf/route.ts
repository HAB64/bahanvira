import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { siteConfig } from '@/config/site';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/certificates/[id]/pdf
 * Generates a printable HTML certificate that can be saved as PDF via browser print.
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const certificate = await db.certificate.findUnique({
      where: { id },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            email: true,
            nationalId: true,
            studentCode: true,
            fatherName: true,
          },
        },
        skillProgram: {
          select: {
            id: true,
            name: true,
            code: true,
            totalHours: true,
            theoryHours: true,
            practicalHours: true,
            instructorName: true,
          },
        },
      },
    });

    if (!certificate) {
      return NextResponse.json({ خطا: 'گواهینامه یافت نشد' }, { status: 404 });
    }

    if (certificate.status !== 'ISSUED' && certificate.status !== 'EXAM_PASSED') {
      return NextResponse.json({ خطا: 'گواهینامه هنوز صادر نشده است' }, { status: 400 });
    }

    const formatDate = (d: string | Date | null) => {
      if (!d) return '—';
      return new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(d));
    };

    const traineeName = `${certificate.karAmuz.firstName} ${certificate.karAmuz.lastName}`;
    const programName = certificate.skillProgram.name;
    const programCode = certificate.skillProgram.code || '—';
    const totalHours = certificate.skillProgram.totalHours;
    const instructorName = certificate.skillProgram.instructorName || '—';
    const issueDate = formatDate(certificate.issueDate || certificate.createdAt);
    const certificateNo = certificate.certificateNo || '—';
    const serialNo = certificate.id.substring(0, 8).toUpperCase();

    // Get the latest evaluation score for this karAmuz and skillProgram
    const evaluation = await db.evaluation.findFirst({
      where: {
        karAmuzId: certificate.karAmuzId,
        skillProgramId: certificate.skillProgramId,
        type: 'FINAL',
        score: { not: null },
      },
      orderBy: { date: 'desc' },
    });

    const grade = evaluation?.score ? `${evaluation.score.toLocaleString('fa-IR')} از ${evaluation.maxScore.toLocaleString('fa-IR')}` : '—';

    const html = `<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
  <meta charset="UTF-8">
  <title>گواهینامه - ${traineeName}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap');

    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: 'Vazirmatn', 'Tahoma', sans-serif;
      direction: rtl;
      background: #f0f0f0;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    @media print {
      body { background: #fff; margin: 0; }
      .no-print { display: none !important; }
      .certificate-container {
        box-shadow: none !important;
        margin: 0 !important;
        page-break-after: avoid;
      }
    }

    .certificate-container {
      width: 800px;
      min-height: 560px;
      background: #fff;
      position: relative;
      padding: 50px 60px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
    }

    /* Decorative Border */
    .border-outer {
      position: absolute;
      top: 12px; left: 12px; right: 12px; bottom: 12px;
      border: 3px solid #0d9488;
      border-radius: 4px;
      pointer-events: none;
    }

    .border-inner {
      position: absolute;
      top: 18px; left: 18px; right: 18px; bottom: 18px;
      border: 1px solid #99f6e4;
      border-radius: 2px;
      pointer-events: none;
    }

    /* Corner Decorations */
    .corner {
      position: absolute;
      width: 40px;
      height: 40px;
      pointer-events: none;
    }
    .corner::before, .corner::after {
      content: '';
      position: absolute;
      background: #0d9488;
    }
    .corner-tl { top: 8px; right: 8px; }
    .corner-tl::before { top: 0; right: 0; width: 3px; height: 30px; }
    .corner-tl::after { top: 0; right: 0; width: 30px; height: 3px; }
    .corner-tr { top: 8px; left: 8px; }
    .corner-tr::before { top: 0; left: 0; width: 3px; height: 30px; }
    .corner-tr::after { top: 0; left: 0; width: 30px; height: 3px; }
    .corner-bl { bottom: 8px; right: 8px; }
    .corner-bl::before { bottom: 0; right: 0; width: 3px; height: 30px; }
    .corner-bl::after { bottom: 0; right: 0; width: 30px; height: 3px; }
    .corner-br { bottom: 8px; left: 8px; }
    .corner-br::before { bottom: 0; left: 0; width: 3px; height: 30px; }
    .corner-br::after { bottom: 0; left: 0; width: 30px; height: 3px; }

    /* Watermark */
    .watermark {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      font-size: 120px;
      font-weight: 900;
      color: rgba(13, 148, 136, 0.04);
      pointer-events: none;
      white-space: nowrap;
    }

    /* Header */
    .cert-header {
      text-align: center;
      margin-bottom: 20px;
      position: relative;
    }

    .institution-name {
      font-size: 18px;
      font-weight: 700;
      color: #0d9488;
      margin-bottom: 6px;
    }

    .institution-subtitle {
      font-size: 10px;
      color: #9ca3af;
    }

    .cert-title {
      font-size: 32px;
      font-weight: 900;
      color: #1f2937;
      margin: 16px 0 4px;
      letter-spacing: 2px;
    }

    .cert-subtitle {
      font-size: 11px;
      color: #9ca3af;
      font-weight: 400;
    }

    .divider {
      width: 80px;
      height: 2px;
      background: linear-gradient(to left, transparent, #0d9488, transparent);
      margin: 16px auto;
    }

    /* Main Content */
    .cert-body {
      text-align: center;
      position: relative;
    }

    .cert-intro {
      font-size: 13px;
      color: #6b7280;
      margin-bottom: 16px;
    }

    .trainee-name {
      font-size: 26px;
      font-weight: 800;
      color: #0d9488;
      margin-bottom: 16px;
      padding: 8px 24px;
      border-bottom: 2px solid #ccfbf1;
      display: inline-block;
    }

    .cert-description {
      font-size: 13px;
      color: #4b5563;
      line-height: 2;
      max-width: 580px;
      margin: 0 auto 20px;
    }

    .cert-description strong {
      color: #1f2937;
      font-weight: 700;
    }

    /* Info Grid */
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px 32px;
      max-width: 520px;
      margin: 20px auto;
      text-align: right;
    }

    .info-item {
      display: flex;
      justify-content: space-between;
      padding: 6px 12px;
      background: #f9fafb;
      border-radius: 6px;
      border: 1px solid #f3f4f6;
    }

    .info-label {
      font-size: 10px;
      color: #9ca3af;
      font-weight: 500;
    }

    .info-value {
      font-size: 11px;
      font-weight: 700;
      color: #374151;
    }

    /* Signatures */
    .signatures {
      display: flex;
      justify-content: space-between;
      margin-top: 32px;
      padding-top: 16px;
    }

    .signature-box {
      text-align: center;
      min-width: 160px;
    }

    .signature-line {
      width: 120px;
      border-top: 1px solid #d1d5db;
      margin: 40px auto 8px;
    }

    .signature-label {
      font-size: 10px;
      color: #6b7280;
      font-weight: 600;
    }

    .signature-name {
      font-size: 11px;
      color: #374151;
      font-weight: 700;
    }

    /* Serial & QR area */
    .cert-footer {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      margin-top: 24px;
    }

    .serial-info {
      text-align: right;
    }

    .serial-number {
      font-size: 10px;
      color: #9ca3af;
      font-family: monospace;
      direction: ltr;
      text-align: left;
    }

    .qr-placeholder {
      width: 64px;
      height: 64px;
      border: 1px dashed #d1d5db;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 8px;
      color: #d1d5db;
      text-align: center;
    }

    /* Print Button */
    .print-btn {
      position: fixed;
      bottom: 20px;
      left: 20px;
      padding: 12px 24px;
      background: #0d9488;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-family: 'Vazirmatn', sans-serif;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(13,148,136,0.3);
      z-index: 100;
    }

    .print-btn:hover {
      background: #0f766e;
    }
  </style>
</head>
<body>
  <button class="print-btn no-print" onclick="window.print()">📥 دانلود / چاپ PDF</button>

  <div class="certificate-container">
    <!-- Decorative borders -->
    <div class="border-outer"></div>
    <div class="border-inner"></div>
    <div class="corner corner-tl"></div>
    <div class="corner corner-tr"></div>
    <div class="corner corner-bl"></div>
    <div class="corner corner-br"></div>

    <!-- Watermark -->
    <div class="watermark">گواهینامه</div>

    <!-- Header -->
    <div class="cert-header">
      <div class="institution-name">${siteConfig.name.fullFa}</div>
      <div class="institution-subtitle">${siteConfig.name.fullEn}</div>
      <div class="divider"></div>
      <div class="cert-title">گواهینامه</div>
      <div class="cert-subtitle">CERTIFICATE OF COMPLETION</div>
    </div>

    <!-- Body -->
    <div class="cert-body">
      <div class="cert-intro">بدینوسیله گواهی می‌شود که</div>
      <div class="trainee-name">${traineeName}</div>
      <div class="cert-description">
        با موفقیت دوره <strong>${programName}</strong> 
        به مدت <strong>${totalHours.toLocaleString('fa-IR')}</strong> ساعت آموزشی 
        (شامل <strong>${certificate.skillProgram.theoryHours.toLocaleString('fa-IR')}</strong> ساعت تئوری و 
        <strong>${certificate.skillProgram.practicalHours.toLocaleString('fa-IR')}</strong> ساعت عملی) 
        را در مؤسسه آموزشی <strong>${siteConfig.name.fa}</strong> گذرانده 
        و در ارزیابی نهایی موفق به کسب نمره 
        <strong>${grade}</strong> 
        گردیده است.
      </div>

      <!-- Info Grid -->
      <div class="info-grid">
        <div class="info-item">
          <span class="info-label">شماره گواهینامه:</span>
          <span class="info-value">${certificateNo}</span>
        </div>
        <div class="info-item">
          <span class="info-label">تاریخ صدور:</span>
          <span class="info-value">${issueDate}</span>
        </div>
        <div class="info-item">
          <span class="info-label">کد دوره:</span>
          <span class="info-value">${programCode}</span>
        </div>
        <div class="info-item">
          <span class="info-label">مدرس:</span>
          <span class="info-value">${instructorName}</span>
        </div>
      </div>
    </div>

    <!-- Signatures -->
    <div class="signatures">
      <div class="signature-box">
        <div class="signature-line"></div>
        <div class="signature-label">مدیر آموزش</div>
        <div class="signature-name">مؤسسه ${siteConfig.name.fa}</div>
      </div>
      <div class="signature-box">
        <div class="signature-line"></div>
        <div class="signature-label">مدرس مسئول</div>
        <div class="signature-name">${instructorName !== '—' ? instructorName : ''}</div>
      </div>
    </div>

    <!-- Footer -->
    <div class="cert-footer">
      <div class="serial-info">
        <div class="serial-number">SN: ${serialNo}</div>
      </div>
      <div class="qr-placeholder">
        QR Code<br>Placeholder
      </div>
    </div>
  </div>

  <script>
    document.addEventListener('keydown', function(e) {
      if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        window.print();
      }
    });
  </script>
</body>
</html>`;

    return new NextResponse(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
    });
  } catch (error) {
    console.error('Certificate PDF error:', error);
    return NextResponse.json(
      { خطا: 'خطا در تولید گواهینامه PDF' },
      { status: 500 }
    );
  }
}
