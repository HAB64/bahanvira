import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * Auto-generate certificateNo in format: BR-CERT-YYYY-XXXX
 * where YYYY is current year and XXXX is a sequential number.
 */
async function generateCertificateNo(): Promise<string> {
  const year = new Date().getFullYear();

  // Find the highest sequential number for this year
  const lastCert = await db.certificate.findFirst({
    where: {
      certificateNo: {
        startsWith: `BR-CERT-${year}-`,
      },
    },
    orderBy: { createdAt: 'desc' },
    select: { certificateNo: true },
  });

  let nextSeq = 1;
  if (lastCert?.certificateNo) {
    const parts = lastCert.certificateNo.split('-');
    const lastSeq = parseInt(parts[parts.length - 1], 10);
    if (!isNaN(lastSeq)) {
      nextSeq = lastSeq + 1;
    }
  }

  const seq = String(nextSeq).padStart(4, '0');
  return `BR-CERT-${year}-${seq}`;
}

/**
 * GET /api/crm/certificates
 * List certificates with optional filters.
 * Query params: karAmuzId, skillProgramId, status
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const karAmuzId = searchParams.get('karAmuzId');
    const skillProgramId = searchParams.get('skillProgramId');
    const status = searchParams.get('status');

    const where: Record<string, unknown> = {};

    if (karAmuzId) {
      where.karAmuzId = karAmuzId;
    }

    if (skillProgramId) {
      where.skillProgramId = skillProgramId;
    }

    if (status) {
      where.status = status;
    }

    const certificates = await db.certificate.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
          },
        },
        skillProgram: {
          select: {
            id: true,
            name: true,
            code: true,
            totalHours: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'لیست گواهینامه‌ها با موفقیت دریافت شد',
      داده‌ها: certificates,
    });
  } catch (error) {
    console.error('Certificates list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست گواهینامه‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/certificates
 * Create certificate record.
 * Required: karAmuzId, skillProgramId
 * Default status: PENDING
 * Auto-generate certificateNo if not provided (format: BR-CERT-YYYY-XXXX)
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { karAmuzId, skillProgramId, certificateNo, status, issueDate, qrCode, pdfUrl } = body;

    // Validate required fields
    if (!karAmuzId || !skillProgramId) {
      return NextResponse.json(
        { خطا: 'شناسه کارآموز و شناسه برنامه مهارتی الزامی است' },
        { status: 400 }
      );
    }

    // Validate that karAmuzId exists
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز یافت نشد' },
        { status: 404 }
      );
    }

    // Validate that skillProgramId exists
    const skillProgram = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
    });

    if (!skillProgram) {
      return NextResponse.json(
        { خطا: 'برنامه مهارتی یافت نشد' },
        { status: 404 }
      );
    }

    // Check if certificateNo is manually provided and if it's already taken
    if (certificateNo) {
      const existingCert = await db.certificate.findUnique({
        where: { certificateNo },
      });

      if (existingCert) {
        return NextResponse.json(
          { خطا: 'شماره گواهینامه تکراری است' },
          { status: 409 }
        );
      }
    }

    // Auto-generate certificateNo if not provided
    const generatedCertNo = certificateNo || await generateCertificateNo();

    // Create certificate
    const certificate = await db.certificate.create({
      data: {
        karAmuzId,
        skillProgramId,
        certificateNo: generatedCertNo,
        status: status || 'PENDING',
        issueDate: issueDate ? new Date(issueDate) : null,
        qrCode: qrCode || null,
        pdfUrl: pdfUrl || null,
      },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
          },
        },
        skillProgram: {
          select: {
            id: true,
            name: true,
            code: true,
            totalHours: true,
          },
        },
      },
    });

    return NextResponse.json(
      {
        پیام: 'گواهینامه با موفقیت ایجاد شد',
        داده: certificate,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Certificate creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ایجاد گواهینامه' },
      { status: 500 }
    );
  }
}
