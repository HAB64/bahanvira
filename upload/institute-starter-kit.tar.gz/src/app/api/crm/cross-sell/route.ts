import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { courses } from '@/data/courses';

// Bloom level ordering for progression recommendations
const BLOOM_ORDER: Record<string, number> = {
  FOUNDATION: 1,
  SPECIALIZED: 2,
  STRATEGIC: 3,
};

// GET /api/crm/cross-sell?karAmuzId=xxx
// Returns recommended next courses based on:
// 1. Current enrollments (what courses they've taken)
// 2. Cluster affinity (if in tech-ai, suggest advanced tech-ai courses)
// 3. Bloom's taxonomy progression (FOUNDATION → SPECIALIZED → STRATEGIC)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const karAmuzId = searchParams.get('karAmuzId');

    if (!karAmuzId) {
      return NextResponse.json(
        { خطا: 'شناسه کارآموز الزامی است' },
        { status: 400 }
      );
    }

    // Get the student with their enrollments
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
      include: {
        enrollments: {
          where: { status: { in: ['ENROLLED', 'COMPLETED'] } },
          include: {
            skillProgram: {
              select: {
                id: true,
                name: true,
                cluster: true,
                level: true,
              },
            },
          },
        },
        lead: {
          select: {
            cluster: true,
            name: true,
          },
        },
      },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز یافت نشد' },
        { status: 404 }
      );
    }

    // Get enrolled skill program IDs and names
    const enrolledProgramIds = new Set(
      karAmuz.enrollments.map((e) => e.skillProgramId)
    );
    const enrolledProgramNames = karAmuz.enrollments.map(
      (e) => e.skillProgram.name
    );

    // Determine the student's primary cluster from enrollments
    const clusterCounts: Record<string, number> = {};
    for (const enrollment of karAmuz.enrollments) {
      const cluster = enrollment.skillProgram.cluster || 'unknown';
      clusterCounts[cluster] = (clusterCounts[cluster] || 0) + 1;
    }
    // Also factor in the lead's cluster
    const leadCluster = karAmuz.lead?.cluster;
    if (leadCluster) {
      clusterCounts[leadCluster] = (clusterCounts[leadCluster] || 0) + 0.5;
    }

    // Determine highest bloom level reached
    let maxBloomLevel = 0;
    const enrolledBloomLevels: string[] = [];

    for (const enrollment of karAmuz.enrollments) {
      const programName = enrollment.skillProgram.name;
      // Try to find matching course in courses data for bloom level
      const matchingCourse = courses.find(
        (c) =>
          c.title.includes(programName) ||
          programName.includes(c.title.split('—')[0].trim()) ||
          programName.includes(c.title.split('—')[0].trim().substring(0, 10))
      );
      if (matchingCourse) {
        const bloomNum = BLOOM_ORDER[matchingCourse.bloomLevel] || 1;
        enrolledBloomLevels.push(matchingCourse.bloomLevel);
        if (bloomNum > maxBloomLevel) {
          maxBloomLevel = bloomNum;
        }
      }
    }

    // Determine next bloom level to suggest
    const nextBloomLevel =
      maxBloomLevel < 2 ? 'SPECIALIZED' : maxBloomLevel < 3 ? 'STRATEGIC' : 'STRATEGIC';

    // Get all available skill programs
    const allPrograms = await db.skillProgram.findMany({
      where: { isActive: true },
      select: {
        id: true,
        name: true,
        cluster: true,
        level: true,
        price: true,
      },
    });

    // Build recommendations
    interface Recommendation {
      programId: string;
      programName: string;
      cluster: string | null;
      bloomLevel: string;
      reason: string;
      priority: number;
    }

    const recommendations: Recommendation[] = [];

    for (const program of allPrograms) {
      // Skip already enrolled programs
      if (enrolledProgramIds.has(program.id)) continue;

      // Find matching course for bloom level
      const matchingCourse = courses.find(
        (c) =>
          c.title.includes(program.name) ||
          program.name.includes(c.title.split('—')[0].trim()) ||
          program.name.includes(c.title.split('—')[0].trim().substring(0, 10))
      );

      const bloomLevel = matchingCourse?.bloomLevel || 'FOUNDATION';
      const bloomNum = BLOOM_ORDER[bloomLevel] || 1;
      const programCluster = program.cluster || matchingCourse?.cluster || '';

      let priority = 0;
      let reason = '';

      // Priority 1: Same cluster, next bloom level up
      if (programCluster && clusterCounts[programCluster] && bloomNum === maxBloomLevel + 1) {
        priority = 100 + (clusterCounts[programCluster] || 0) * 10;
        const bloomLabel =
          bloomLevel === 'SPECIALIZED'
            ? 'تخصصی'
            : bloomLevel === 'STRATEGIC'
              ? 'استراتژیک'
              : 'پایه';
        reason = `ارتقای سطح ${bloomLabel} در خوشه ${matchingCourse?.clusterLabel || programCluster}`;
      }
      // Priority 2: Same cluster, any level
      else if (programCluster && clusterCounts[programCluster]) {
        priority = 50 + (clusterCounts[programCluster] || 0) * 5;
        if (bloomNum > maxBloomLevel) {
          priority += 20;
        }
        reason = `تکمیل مسیر شغلی در خوشه ${matchingCourse?.clusterLabel || programCluster}`;
      }
      // Priority 3: Different cluster, bloom level progression
      else if (bloomNum <= maxBloomLevel + 1 && bloomNum >= maxBloomLevel) {
        priority = 30;
        reason = 'تنوع مهارتی و توسعه cross-functional';
      }
      // Skip very different/low-priority recommendations
      else {
        continue;
      }

      recommendations.push({
        programId: program.id,
        programName: program.name,
        cluster: programCluster,
        bloomLevel,
        reason,
        priority,
      });
    }

    // Sort by priority and take top 3
    recommendations.sort((a, b) => b.priority - a.priority);
    const topRecommendations = recommendations.slice(0, 3);

    return NextResponse.json({
      karAmuzId,
      studentName: `${karAmuz.firstName} ${karAmuz.lastName}`,
      currentEnrollments: enrolledProgramNames,
      primaryCluster: Object.entries(clusterCounts).sort(
        ([, a], [, b]) => b - a
      )[0]?.[0] || null,
      currentBloomLevel:
        maxBloomLevel === 3
          ? 'STRATEGIC'
          : maxBloomLevel === 2
            ? 'SPECIALIZED'
            : 'FOUNDATION',
      recommendations: topRecommendations.map((r) => ({
        courseId: r.programId,
        courseName: r.programName,
        cluster: r.cluster,
        bloomLevel: r.bloomLevel,
        reason: r.reason,
      })),
    });
  } catch (error) {
    console.error('Cross-sell API error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت پیشنهادات' },
      { status: 500 }
    );
  }
}
