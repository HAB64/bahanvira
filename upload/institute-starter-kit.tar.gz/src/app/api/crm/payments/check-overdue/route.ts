import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { executeAutomationRules } from '@/lib/crm/automation-engine';

/**
 * POST /api/crm/payments/check-overdue
 * Cron endpoint: Auto-mark overdue payments and trigger SMS/WhatsApp notifications.
 *
 * Call from Vercel Cron or external scheduler (e.g. every day at 8:00 AM).
 * Secured with CRON_SECRET header to prevent unauthorized calls.
 *
 * Flow:
 * 1. Find PENDING payments where dueDate < today
 * 2. Update their status to OVERDUE
 * 3. For each, trigger PAYMENT_OVERDUE automation (SMS + WhatsApp)
 * 4. Return summary
 */
export async function POST(request: NextRequest) {
  try {
    // Validate cron secret
    const cronSecret = request.headers.get('x-cron-secret') || request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (expectedSecret && cronSecret !== `Bearer ${expectedSecret}` && cronSecret !== expectedSecret) {
      return NextResponse.json(
        { خطا: 'دسترسی غیرمجاز' },
        { status: 401 }
      );
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Find all PENDING payments past their due date
    const overduePayments = await db.payment.findMany({
      where: {
        status: 'PENDING',
        dueDate: {
          lt: today,
        },
      },
      include: {
        lead: {
          select: {
            id: true,
            name: true,
            phone: true,
            course: true,
            assignedTo: true,
            cluster: true,
          },
        },
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
      },
    });

    if (overduePayments.length === 0) {
      return NextResponse.json({
        پیام: 'هیچ پرداخت سررسیدشده‌ای یافت نشد',
        تعداد: 0,
      });
    }

    let markedCount = 0;
    let notificationCount = 0;
    const errors: string[] = [];

    for (const payment of overduePayments) {
      try {
        // Update status to OVERDUE
        await db.payment.update({
          where: { id: payment.id },
          data: { status: 'OVERDUE' },
        });
        markedCount++;

        // Prepare context for automation
        const leadName = payment.lead?.name ||
          (payment.karAmuz ? `${payment.karAmuz.firstName} ${payment.karAmuz.lastName}`.trim() : '');
        const leadPhone = payment.lead?.phone || payment.karAmuz?.phone || '';
        const courseTitle = payment.lead?.course || '';

        if (leadPhone) {
          // Trigger automation (SMS + WhatsApp) — async
          executeAutomationRules('PAYMENT_OVERDUE', {
            leadId: payment.leadId || undefined,
            karAmuzId: payment.karAmuzId || undefined,
            paymentId: payment.id,
            paymentStatus: 'OVERDUE',
            leadName,
            leadPhone,
            courseTitle,
            amount: payment.amount,
            dueDate: payment.dueDate?.toISOString() || '',
            assignedTo: payment.lead?.assignedTo || '',
          }).catch((err) => {
            console.error(`Automation error for payment ${payment.id}:`, err);
          });
          notificationCount++;
        }
      } catch (paymentError) {
        const msg = `Payment ${payment.id}: ${paymentError instanceof Error ? paymentError.message : String(paymentError)}`;
        errors.push(msg);
      }
    }

    return NextResponse.json({
      پیام: 'بررسی پرداخت‌های سررسیدشده انجام شد',
      تعداد_سررسیدشده: overduePayments.length,
      تعداد_علامتگذاری_شده: markedCount,
      تعداد_اعلان_ارسال_شده: notificationCount,
      خطاها: errors.length > 0 ? errors : undefined,
    });
  } catch (error) {
    console.error('Check-overdue cron error:', error);
    return NextResponse.json(
      { خطا: 'خطا در بررسی پرداخت‌های سررسیدشده' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/crm/payments/check-overdue
 * Preview: Show how many payments would be marked overdue (dry-run).
 */
export async function GET(request: NextRequest) {
  try {
    const cronSecret = request.headers.get('x-cron-secret') || request.headers.get('authorization');
    const expectedSecret = process.env.CRON_SECRET;

    if (expectedSecret && cronSecret !== `Bearer ${expectedSecret}` && cronSecret !== expectedSecret) {
      return NextResponse.json(
        { خطا: 'دسترسی غیرمجاز' },
        { status: 401 }
      );
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const count = await db.payment.count({
      where: {
        status: 'PENDING',
        dueDate: {
          lt: today,
        },
      },
    });

    return NextResponse.json({
      پیام: 'پیش‌نمایش پرداخت‌های سررسیدشده',
      تعداد: count,
    });
  } catch (error) {
    console.error('Check-overdue preview error:', error);
    return NextResponse.json(
      { خطا: 'خطا در پیش‌نمایش' },
      { status: 500 }
    );
  }
}
