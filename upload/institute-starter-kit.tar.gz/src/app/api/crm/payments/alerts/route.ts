import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/payments/alerts
 * Return overdue and near-due payments with lead info.
 * - Overdue: dueDate < today, status PENDING
 * - Near-due: dueDate <= today + 3 days, status PENDING
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const threeDaysLater = new Date(today);
    threeDaysLater.setDate(threeDaysLater.getDate() + 3);
    threeDaysLater.setHours(23, 59, 59, 999);

    // Overdue payments (dueDate < today, status PENDING)
    const overduePayments = await db.payment.findMany({
      where: {
        status: 'PENDING',
        dueDate: {
          lt: today,
        },
      },
      include: {
        lead: {
          select: {
            id: true,
            name: true,
            phone: true,
          },
        },
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
      },
      orderBy: { dueDate: 'asc' },
    });

    // Near-due payments (dueDate <= today + 3 days, dueDate >= today, status PENDING)
    const nearDuePayments = await db.payment.findMany({
      where: {
        status: 'PENDING',
        dueDate: {
          gte: today,
          lte: threeDaysLater,
        },
      },
      include: {
        lead: {
          select: {
            id: true,
            name: true,
            phone: true,
          },
        },
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
      },
      orderBy: { dueDate: 'asc' },
    });

    return NextResponse.json({
      پیام: 'هشدارهای پرداخت با موفقیت دریافت شد',
      داده: {
        سررسید_شده: overduePayments.map((p) => ({
          id: p.id,
          amount: p.amount,
          type: p.type,
          status: p.status,
          dueDate: p.dueDate,
          note: p.note,
          leadId: p.leadId,
          leadName: p.lead?.name || p.karAmuz ? `${p.karAmuz?.firstName || ''} ${p.karAmuz?.lastName || ''}`.trim() : '-',
          leadPhone: p.lead?.phone || p.karAmuz?.phone || '-',
        })),
        نزدیک_سررسید: nearDuePayments.map((p) => ({
          id: p.id,
          amount: p.amount,
          type: p.type,
          status: p.status,
          dueDate: p.dueDate,
          note: p.note,
          leadId: p.leadId,
          leadName: p.lead?.name || p.karAmuz ? `${p.karAmuz?.firstName || ''} ${p.karAmuz?.lastName || ''}`.trim() : '-',
          leadPhone: p.lead?.phone || p.karAmuz?.phone || '-',
        })),
      },
    });
  } catch (error) {
    console.error('CRM payment alerts error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت هشدارهای پرداخت' },
      { status: 500 }
    );
  }
}
