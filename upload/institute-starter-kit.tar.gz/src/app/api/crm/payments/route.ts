import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { executeAutomationRules } from '@/lib/crm/automation-engine';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/payments
 * List payments with optional filters.
 * Query params: karAmuzId, leadId, status, type
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const karAmuzId = searchParams.get('karAmuzId');
    const leadId = searchParams.get('leadId');
    const status = searchParams.get('status');
    const type = searchParams.get('type');

    const where: Record<string, unknown> = {};

    if (karAmuzId) {
      where.karAmuzId = karAmuzId;
    }

    if (leadId) {
      where.leadId = leadId;
    }

    if (status) {
      where.status = status;
    }

    if (type) {
      where.type = type;
    }

    const payments = await db.payment.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      پیام: 'لیست پرداخت‌ها با موفقیت دریافت شد',
      داده‌ها: payments,
    });
  } catch (error) {
    console.error('Payments list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست پرداخت‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/payments
 * Create a payment record linked to either a leadId or karAmuzId.
 * Required: amount, type
 * At least one of: leadId, karAmuzId
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { amount, type, status, dueDate, note, leadId, karAmuzId, paidAt } = body;

    // Validate required fields
    if (!amount || !type) {
      return NextResponse.json(
        { خطا: 'مبلغ و نوع پرداخت الزامی است' },
        { status: 400 }
      );
    }

    // At least one of leadId or karAmuzId must be provided
    if (!leadId && !karAmuzId) {
      return NextResponse.json(
        { خطا: 'حداقل یکی از شناسه لید یا شناسه کارآموز الزامی است' },
        { status: 400 }
      );
    }

    // Validate amount
    if (typeof amount !== 'number' || amount <= 0) {
      return NextResponse.json(
        { خطا: 'مبلغ پرداخت باید یک عدد مثبت باشد' },
        { status: 400 }
      );
    }

    // Validate payment type
    const validTypes = ['CASH', 'CHECK', 'INSTALLMENT'];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { خطا: `نوع پرداخت نامعتبر است. مقادیر مجاز: ${validTypes.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate payment status
    const validStatuses = ['PENDING', 'PAID', 'OVERDUE', 'CANCELLED'];
    const paymentStatus = status || 'PENDING';
    if (!validStatuses.includes(paymentStatus)) {
      return NextResponse.json(
        { خطا: `وضعیت پرداخت نامعتبر است. مقادیر مجاز: ${validStatuses.join(', ')}` },
        { status: 400 }
      );
    }

    const payment = await db.payment.create({
      data: {
        leadId: leadId || null,
        karAmuzId: karAmuzId || null,
        amount,
        type,
        status: paymentStatus,
        dueDate: dueDate ? new Date(dueDate) : null,
        paidAt: paidAt ? new Date(paidAt) : null,
        note: note || '',
      },
    });

    return NextResponse.json(
      {
        پیام: 'پرداخت با موفقیت ثبت شد',
        داده: payment,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Payment creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت پرداخت' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/crm/payments
 * Update a payment status.
 * Body: { paymentId, status, note? }
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { paymentId, status, note } = body;

    if (!paymentId) {
      return NextResponse.json(
        { خطا: 'شناسه پرداخت الزامی است' },
        { status: 400 }
      );
    }

    if (!status) {
      return NextResponse.json(
        { خطا: 'وضعیت جدید الزامی است' },
        { status: 400 }
      );
    }

    const validStatuses = ['PENDING', 'PAID', 'OVERDUE', 'CANCELLED'];
    if (!validStatuses.includes(status)) {
      return NextResponse.json(
        { خطا: `وضعیت نامعتبر است. مقادیر مجاز: ${validStatuses.join(', ')}` },
        { status: 400 }
      );
    }

    const existingPayment = await db.payment.findUnique({
      where: { id: paymentId },
    });

    if (!existingPayment) {
      return NextResponse.json(
        { خطا: 'پرداخت مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const updateData: Record<string, unknown> = { status };

    if (status === 'PAID') {
      updateData.paidAt = new Date();
    }

    if (existingPayment.status === 'PAID' && status !== 'PAID') {
      updateData.paidAt = null;
    }

    if (note !== undefined) {
      updateData.note = note;
    }

    const updatedPayment = await db.payment.update({
      where: { id: paymentId },
      data: updateData,
      include: {
        lead: { select: { id: true, name: true, phone: true, course: true, assignedTo: true, cluster: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    // ── Automation: Trigger PAYMENT_OVERDUE when status changes to OVERDUE ──
    if (status === 'OVERDUE' && existingPayment.status !== 'OVERDUE') {
      const leadName = updatedPayment.lead?.name ||
        (updatedPayment.karAmuz ? `${updatedPayment.karAmuz.firstName} ${updatedPayment.karAmuz.lastName}`.trim() : '');
      const leadPhone = updatedPayment.lead?.phone || updatedPayment.karAmuz?.phone || '';
      const courseTitle = updatedPayment.lead?.course || '';

      executeAutomationRules('PAYMENT_OVERDUE', {
        leadId: updatedPayment.leadId || undefined,
        karAmuzId: updatedPayment.karAmuzId || undefined,
        paymentId: updatedPayment.id,
        paymentStatus: 'OVERDUE',
        leadName,
        leadPhone,
        courseTitle,
        amount: updatedPayment.amount,
        dueDate: updatedPayment.dueDate?.toISOString() || '',
        assignedTo: updatedPayment.lead?.assignedTo || '',
      }).catch((err) => {
        console.error('Automation execution error (PAYMENT_OVERDUE):', err);
      });
    }

    // ── Automation: Trigger PAYMENT_RECEIVED when status changes to PAID ──
    if (status === 'PAID' && existingPayment.status !== 'PAID') {
      const leadName = updatedPayment.lead?.name ||
        (updatedPayment.karAmuz ? `${updatedPayment.karAmuz.firstName} ${updatedPayment.karAmuz.lastName}`.trim() : '');
      const leadPhone = updatedPayment.lead?.phone || updatedPayment.karAmuz?.phone || '';
      const courseTitle = updatedPayment.lead?.course || '';

      executeAutomationRules('PAYMENT_RECEIVED', {
        leadId: updatedPayment.leadId || undefined,
        karAmuzId: updatedPayment.karAmuzId || undefined,
        paymentId: updatedPayment.id,
        paymentStatus: 'PAID',
        leadName,
        leadPhone,
        courseTitle,
        amount: updatedPayment.amount,
        assignedTo: updatedPayment.lead?.assignedTo || '',
      }).catch((err) => {
        console.error('Automation execution error (PAYMENT_RECEIVED):', err);
      });

      // ── Recalculate CLV for lead after payment ──
      if (updatedPayment.leadId) {
        const paidTotal = await db.payment.aggregate({
          where: { leadId: updatedPayment.leadId, status: 'PAID' },
          _sum: { amount: true },
        });
        await db.lead.update({
          where: { id: updatedPayment.leadId },
          data: { lifetimeValue: paidTotal._sum.amount || 0 },
        });
      }
    }

    return NextResponse.json({
      پیام: 'وضعیت پرداخت با موفقیت به‌روزرسانی شد',
      داده: updatedPayment,
    });
  } catch (error) {
    console.error('Payment update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی پرداخت' },
      { status: 500 }
    );
  }
}
