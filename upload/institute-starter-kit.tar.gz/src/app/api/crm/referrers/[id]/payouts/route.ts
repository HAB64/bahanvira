import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/referrers/[id]/payouts
 * لیست پرداخت‌های یک معرف
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);

    const referrer = await db.referrer.findUnique({ where: { id } });
    if (!referrer) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const status = searchParams.get('status');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = { referrerId: id };
    if (status) {
      where.status = status;
    }

    const [payouts, total] = await Promise.all([
      db.referrerPayout.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          commissions: {
            select: {
              id: true,
              commissionAmount: true,
              tierName: true,
              status: true,
              referral: {
                select: { refName: true, enrolledCourse: true },
              },
            },
          },
        },
      }),
      db.referrerPayout.count({ where }),
    ]);

    const totalPaid = await db.referrerPayout.aggregate({
      where: { referrerId: id, status: 'COMPLETED' },
      _sum: { amount: true },
    });

    return NextResponse.json({
      پیام: 'لیست پرداخت‌ها با موفقیت دریافت شد',
      داده‌ها: payouts,
      خلاصه: {
        کل_پرداخت_شده: totalPaid._sum.amount || 0,
      },
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Payouts list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست پرداخت‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/referrers/[id]/payouts
 * ایجاد پرداخت جدید برای یک بازه زمانی
 * تمام پورسانت‌های PENDING در بازه به PAID تغییر وضعیت می‌دهند
 */
export async function POST(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const {
      periodStart,
      periodEnd,
      method,
      bankName,
      bankAccountNo,
      bankShaba,
      trackingNo,
      receiptUrl,
      notes,
    } = body;

    const referrer = await db.referrer.findUnique({ where: { id } });
    if (!referrer) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    if (!periodStart || !periodEnd) {
      return NextResponse.json(
        { خطا: 'تاریخ شروع و پایان دوره الزامی است' },
        { status: 400 }
      );
    }

    const startDate = new Date(periodStart);
    const endDate = new Date(periodEnd);

    if (startDate >= endDate) {
      return NextResponse.json(
        { خطا: 'تاریخ شروع باید قبل از تاریخ پایان باشد' },
        { status: 400 }
      );
    }

    // یافتن پورسانت‌های PENDING در بازه زمانی
    const pendingCommissions = await db.referrerCommission.findMany({
      where: {
        referrerId: id,
        status: 'PENDING',
        createdAt: {
          gte: startDate,
          lte: endDate,
        },
      },
    });

    if (pendingCommissions.length === 0) {
      return NextResponse.json(
        { خطا: 'پورسانت در انتظار پرداختی در این بازه زمانی یافت نشد' },
        { status: 400 }
      );
    }

    const totalAmount = pendingCommissions.reduce((sum, c) => sum + c.commissionAmount, 0);

    const validMethods = ['BANK_TRANSFER', 'CASH', 'CHECK'];
    const payoutMethod = method || 'BANK_TRANSFER';
    if (!validMethods.includes(payoutMethod)) {
      return NextResponse.json(
        { خطا: 'روش پرداخت نامعتبر است. مقادیر مجاز: BANK_TRANSFER, CASH, CHECK' },
        { status: 400 }
      );
    }

    // استفاده از اطلاعات بانکی معرف اگر ارائه نشده
    const payoutBankName = bankName || referrer.bankName;
    const payoutBankAccountNo = bankAccountNo || referrer.bankAccountNo;
    const payoutBankShaba = bankShaba || referrer.bankShaba;

    // ایجاد رکورد پرداخت
    const payout = await db.referrerPayout.create({
      data: {
        referrerId: id,
        amount: totalAmount,
        method: payoutMethod,
        bankName: payoutBankName,
        bankAccountNo: payoutBankAccountNo,
        bankShaba: payoutBankShaba,
        trackingNo: trackingNo || null,
        receiptUrl: receiptUrl || null,
        periodStart: startDate,
        periodEnd: endDate,
        status: 'PENDING',
        notes: notes || null,
      },
    });

    // به‌روزرسانی پورسانت‌ها — اتصال به پرداخت و تغییر وضعیت به PAID
    await db.referrerCommission.updateMany({
      where: {
        id: { in: pendingCommissions.map(c => c.id) },
      },
      data: {
        status: 'PAID',
        paidAt: new Date(),
        payoutId: payout.id,
      },
    });

    // به‌روزرسانی آمار معرف
    await db.referrer.update({
      where: { id },
      data: {
        totalPaidCommission: { increment: totalAmount },
      },
    });

    // بازگرداندن نتیجه با جزئیات
    const result = await db.referrerPayout.findUnique({
      where: { id: payout.id },
      include: {
        commissions: {
          select: {
            id: true,
            commissionAmount: true,
            tierName: true,
            referral: {
              select: { refName: true, enrolledCourse: true },
            },
          },
        },
      },
    });

    return NextResponse.json(
      {
        پیام: 'پرداخت با موفقیت ایجاد شد',
        داده: result,
        جزئیات: {
          تعداد_پورسانت: pendingCommissions.length,
          مبلغ_کل: totalAmount,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Payout creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت پرداخت' },
      { status: 500 }
    );
  }
}
