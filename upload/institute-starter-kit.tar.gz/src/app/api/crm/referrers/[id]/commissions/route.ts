import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

const DEFAULT_COMMISSION_TIERS = [
  { minEnrollments: 1, maxEnrollments: 5, pct: 10, name: 'پایه', level: 1 },
  { minEnrollments: 6, maxEnrollments: 15, pct: 12, name: 'برنزی', level: 2 },
  { minEnrollments: 16, maxEnrollments: 30, pct: 15, name: 'نقره‌ای', level: 3 },
  { minEnrollments: 31, maxEnrollments: Infinity, pct: 20, name: 'طلایی', level: 4 },
];

function getCurrentTier(totalEnrollments: number, customTiers?: unknown) {
  const tiers = (customTiers && Array.isArray(customTiers) && customTiers.length > 0)
    ? customTiers as Array<{ minEnrollments: number; maxEnrollments: number; pct: number; name: string; level: number }>
    : DEFAULT_COMMISSION_TIERS;

  for (const tier of tiers) {
    if (totalEnrollments >= tier.minEnrollments && totalEnrollments <= tier.maxEnrollments) {
      return tier;
    }
  }

  return tiers[tiers.length - 1];
}

/**
 * GET /api/crm/referrers/[id]/commissions
 * لیست پورسانت‌های یک معرف
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);

    const referrer = await db.referrer.findUnique({ where: { id } });
    if (!referrer) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const status = searchParams.get('status');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = { referrerId: id };
    if (status) {
      where.status = status;
    }

    const [commissions, total] = await Promise.all([
      db.referrerCommission.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          referral: {
            select: { refName: true, refPhone: true, enrolledCourse: true },
          },
        },
      }),
      db.referrerCommission.count({ where }),
    ]);

    const sumResult = await db.referrerCommission.aggregate({
      where: { referrerId: id },
      _sum: { commissionAmount: true },
    });

    const pendingSum = await db.referrerCommission.aggregate({
      where: { referrerId: id, status: 'PENDING' },
      _sum: { commissionAmount: true },
    });

    return NextResponse.json({
      پیام: 'لیست پورسانت‌ها با موفقیت دریافت شد',
      داده‌ها: commissions,
      خلاصه: {
        کل_پورسانت: sumResult._sum.commissionAmount || 0,
        پورسانت_در_انتظار: pendingSum._sum.commissionAmount || 0,
      },
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Commissions list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست پورسانت‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/referrers/[id]/commissions
 * ایجاد پورسانت جدید (وقتی ثبت‌نام رخ می‌دهد)
 * محاسبه خودکار مبلغ پورسانت بر اساس سطح فعلی
 */
export async function POST(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const {
      referralId,
      paymentId,
      amount,
      description,
    } = body;

    const referrer = await db.referrer.findUnique({ where: { id } });
    if (!referrer) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    if (!amount || amount <= 0) {
      return NextResponse.json(
        { خطا: 'مبلغ پایه (شهریه) باید بزرگتر از صفر باشد' },
        { status: 400 }
      );
    }

    // تعیین سطح پورسانت فعلی
    const currentTier = getCurrentTier(referrer.totalEnrollments, referrer.commissionTiers);
    const commissionPct = currentTier.pct;
    const commissionAmount = (amount * commissionPct) / 100;

    const commission = await db.referrerCommission.create({
      data: {
        referrerId: id,
        referralId: referralId || null,
        paymentId: paymentId || null,
        amount: parseFloat(String(amount)),
        commissionPct,
        commissionAmount,
        tierLevel: currentTier.level,
        tierName: currentTier.name,
        status: 'PENDING',
        description: description || `پورسانت ${currentTier.name} (${commissionPct}%) از مبلغ ${amount} ریال`,
      },
      include: {
        referral: {
          select: { refName: true, refPhone: true, enrolledCourse: true },
        },
      },
    });

    // به‌روزرسانی آمار معرف
    await db.referrer.update({
      where: { id },
      data: {
        totalCommission: { increment: commissionAmount },
      },
    });

    return NextResponse.json(
      {
        پیام: 'پورسانت با موفقیت ایجاد شد',
        داده: commission,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Commission creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت پورسانت' },
      { status: 500 }
    );
  }
}
