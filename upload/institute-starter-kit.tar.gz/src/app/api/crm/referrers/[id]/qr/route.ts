import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import QRCode from 'qrcode';
import { siteConfig } from '@/config/site';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/referrers/[id]/qr
 * تولید تصویر QR Code برای معرف
 */
export async function GET(
  _request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const referrer = await db.referrer.findUnique({
      where: { id },
      select: { id: true, code: true, firstName: true, lastName: true },
    });

    if (!referrer) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const refUrl = `${siteConfig.url.base}/ref?code=${encodeURIComponent(referrer.code)}&source=qr`;

    const qrBuffer = await QRCode.toBuffer(refUrl, {
      type: 'png',
      width: 400,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
      errorCorrectionLevel: 'M',
    });

    const fullName = `${referrer.firstName} ${referrer.lastName}`;

    // Sanitize filename: only keep ASCII-safe characters for HTTP headers
    const safeCode = referrer.code.replace(/[^a-zA-Z0-9_-]/g, '') || 'referrer';
    const safeName = encodeURIComponent(fullName);

    return new Response(qrBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'image/png',
        'Cache-Control': 'public, max-age=3600, s-maxage=3600',
        'X-Referrer-Name': safeName,
        'X-Referrer-Code': safeCode,
        'X-Referrer-URL': encodeURIComponent(refUrl),
        'Content-Disposition': `inline; filename="qr-${safeCode}.png"`,
      },
    });
  } catch (error) {
    console.error('QR code generation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در تولید QR Code' },
      { status: 500 }
    );
  }
}
