import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

const DEFAULT_COMMISSION_TIERS = [
  { minEnrollments: 1, maxEnrollments: 5, pct: 10, name: 'پایه', level: 1 },
  { minEnrollments: 6, maxEnrollments: 15, pct: 12, name: 'برنزی', level: 2 },
  { minEnrollments: 16, maxEnrollments: 30, pct: 15, name: 'نقره‌ای', level: 3 },
  { minEnrollments: 31, maxEnrollments: Infinity, pct: 20, name: 'طلایی', level: 4 },
];

function getCurrentTier(totalEnrollments: number, customTiers?: unknown) {
  const tiers = (customTiers && Array.isArray(customTiers) && customTiers.length > 0)
    ? customTiers as Array<{ minEnrollments: number; maxEnrollments: number; pct: number; name: string; level: number }>
    : DEFAULT_COMMISSION_TIERS;

  for (const tier of tiers) {
    if (totalEnrollments >= tier.minEnrollments && totalEnrollments <= tier.maxEnrollments) {
      return tier;
    }
  }

  return tiers[tiers.length - 1];
}

/**
 * GET /api/crm/referrers/[id]/stats
 * آمار تفصیلی یک معرف
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const referrer = await db.referrer.findUnique({
      where: { id },
      include: {
        referrals: {
          orderBy: { createdAt: 'desc' },
        },
        commissions: {
          orderBy: { createdAt: 'desc' },
        },
        payouts: {
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!referrer) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // سطح فعلی پورسانت
    const currentTier = getCurrentTier(referrer.totalEnrollments, referrer.commissionTiers);

    // تفکیک ماهانه
    const monthlyBreakdown: Record<string, { referrals: number; enrollments: number; revenue: number; commission: number }> = {};

    for (const ref of referrer.referrals) {
      const month = ref.createdAt.toISOString().slice(0, 7);
      if (!monthlyBreakdown[month]) {
        monthlyBreakdown[month] = { referrals: 0, enrollments: 0, revenue: 0, commission: 0 };
      }
      monthlyBreakdown[month].referrals++;
      if (ref.status === 'ENROLLED') {
        monthlyBreakdown[month].enrollments++;
        if (ref.commissionAmount) {
          monthlyBreakdown[month].commission += ref.commissionAmount;
        }
      }
    }

    const sortedMonthly = Object.entries(monthlyBreakdown)
      .sort(([a], [b]) => b.localeCompare(a))
      .map(([month, data]) => ({ month, ...data }));

    // دوره‌های برتر
    const courseMap: Record<string, { course: string; count: number }> = {};
    for (const ref of referrer.referrals) {
      if (ref.enrolledCourse) {
        if (!courseMap[ref.enrolledCourse]) {
          courseMap[ref.enrolledCourse] = { course: ref.enrolledCourse, count: 0 };
        }
        courseMap[ref.enrolledCourse].count++;
      }
    }
    const topCourses = Object.values(courseMap)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // منبع ورود
    const sourceMap: Record<string, number> = {};
    for (const ref of referrer.referrals) {
      sourceMap[ref.source] = (sourceMap[ref.source] || 0) + 1;
    }

    // نرخ تبدیل
    const totalReferrals = referrer.referrals.length;
    const enrolledCount = referrer.referrals.filter(r => r.status === 'ENROLLED').length;
    const contactedCount = referrer.referrals.filter(r => r.status === 'CONTACTED').length;
    const cancelledCount = referrer.referrals.filter(r => r.status === 'CANCELLED').length;
    const conversionRate = totalReferrals > 0 ? (enrolledCount / totalReferrals) * 100 : 0;

    // پورسانت‌ها
    const pendingCommissions = referrer.commissions.filter(c => c.status === 'PENDING');
    const approvedCommissions = referrer.commissions.filter(c => c.status === 'APPROVED');
    const paidCommissions = referrer.commissions.filter(c => c.status === 'PAID');

    const pendingAmount = pendingCommissions.reduce((sum, c) => sum + c.commissionAmount, 0);
    const approvedAmount = approvedCommissions.reduce((sum, c) => sum + c.commissionAmount, 0);

    // فاصله تا سطح بعدی
    let nextTierInfo = null;
    const allTiers = (referrer.commissionTiers && Array.isArray(referrer.commissionTiers) && referrer.commissionTiers.length > 0)
      ? referrer.commissionTiers as Array<{ minEnrollments: number; maxEnrollments: number; pct: number; name: string; level: number }>
      : DEFAULT_COMMISSION_TIERS;

    const currentTierIndex = allTiers.findIndex(t =>
      referrer.totalEnrollments >= t.minEnrollments && referrer.totalEnrollments <= t.maxEnrollments
    );

    if (currentTierIndex < allTiers.length - 1) {
      const next = allTiers[currentTierIndex + 1];
      nextTierInfo = {
        name: next.name,
        pct: next.pct,
        enrollmentsNeeded: next.minEnrollments - referrer.totalEnrollments,
      };
    }

    return NextResponse.json({
      پیام: 'آمار معرف با موفقیت دریافت شد',
      داده: {
        referrer: {
          id: referrer.id,
          code: referrer.code,
          firstName: referrer.firstName,
          lastName: referrer.lastName,
          status: referrer.status,
          totalReferrals: referrer.totalReferrals,
          totalEnrollments: referrer.totalEnrollments,
          totalRevenue: referrer.totalRevenue,
          totalCommission: referrer.totalCommission,
          totalPaidCommission: referrer.totalPaidCommission,
        },
        currentTier,
        nextTierInfo,
        conversionRate: Math.round(conversionRate * 100) / 100,
        referralsByStatus: {
          PENDING: totalReferrals - enrolledCount - contactedCount - cancelledCount,
          CONTACTED: contactedCount,
          ENROLLED: enrolledCount,
          CANCELLED: cancelledCount,
        },
        monthlyBreakdown: sortedMonthly,
        topCourses,
        referralsBySource: sourceMap,
        commissions: {
          pending: { count: pendingCommissions.length, amount: pendingAmount },
          approved: { count: approvedCommissions.length, amount: approvedAmount },
          paid: { count: paidCommissions.length },
        },
        recentPayouts: referrer.payouts.slice(0, 5),
      },
    });
  } catch (error) {
    console.error('Referrer stats error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت آمار معرف' },
      { status: 500 }
    );
  }
}
