import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/referrers/[id]
 * دریافت اطلاعات کامل یک معرف
 */
export async function GET(
  _request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const referrer = await db.referrer.findUnique({
      where: { id },
      include: {
        referrals: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
        commissions: {
          orderBy: { createdAt: 'desc' },
          take: 10,
          include: {
            referral: {
              select: { refName: true, refPhone: true, enrolledCourse: true },
            },
          },
        },
        payouts: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
      },
    });

    if (!referrer) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const pendingCommissions = await db.referrerCommission.aggregate({
      where: { referrerId: id, status: 'PENDING' },
      _sum: { commissionAmount: true },
    });

    const unpaidTotal = pendingCommissions._sum.commissionAmount || 0;

    return NextResponse.json({
      پیام: 'اطلاعات معرف با موفقیت دریافت شد',
      داده: {
        ...referrer,
        _stats: {
          pendingCommissionAmount: unpaidTotal,
        },
      },
    });
  } catch (error) {
    console.error('Referrer get error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت اطلاعات معرف' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/crm/referrers/[id]
 * به‌روزرسانی اطلاعات معرف
 */
export async function PATCH(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const existing = await db.referrer.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const validStatuses = ['ACTIVE', 'SUSPENDED', 'INACTIVE'];
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json(
        { خطا: 'وضعیت نامعتبر است. مقادیر مجاز: ACTIVE, SUSPENDED, INACTIVE' },
        { status: 400 }
      );
    }

    const updateData: Record<string, unknown> = {};

    const allowedFields = [
      'firstName', 'lastName', 'phone', 'email', 'avatarUrl',
      'isActive', 'status', 'baseCommissionPct', 'commissionTiers',
      'bankName', 'bankAccountNo', 'bankCardNo', 'bankShaba', 'notes',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field];
      }
    }

    if (body.status === 'INACTIVE') {
      updateData.isActive = false;
    } else if (body.status === 'ACTIVE') {
      updateData.isActive = true;
    }

    const updated = await db.referrer.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({
      پیام: 'اطلاعات معرف با موفقیت به‌روزرسانی شد',
      داده: updated,
    });
  } catch (error) {
    console.error('Referrer update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی اطلاعات معرف' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/crm/referrers/[id]
 * حذف نرم (تغییر وضعیت به INACTIVE)
 */
export async function DELETE(
  _request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    const existing = await db.referrer.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const updated = await db.referrer.update({
      where: { id },
      data: {
        status: 'INACTIVE',
        isActive: false,
      },
    });

    return NextResponse.json({
      پیام: 'معرف با موفقیت غیرفعال شد',
      داده: updated,
    });
  } catch (error) {
    console.error('Referrer delete error:', error);
    return NextResponse.json(
      { خطا: 'خطا در غیرفعال‌سازی معرف' },
      { status: 500 }
    );
  }
}
