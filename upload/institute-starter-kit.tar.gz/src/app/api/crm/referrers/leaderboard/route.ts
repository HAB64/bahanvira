import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';
import { TIER_LABELS, TIER_RATES } from '@/lib/referrer';

/**
 * GET /api/crm/referrers/leaderboard
 * Referrer leaderboard ranked by enrollments and commission
 */
export async function GET() {
  try {
    // Public endpoint — no auth required for leaderboard
    const referrers = await db.referrer.findMany({
      where: { status: 'ACTIVE' },
      select: {
        id: true,
        code: true,
        firstName: true,
        lastName: true,
        tier: true,
        totalReferrals: true,
        totalEnrollments: true,
        totalCommission: true,
        instagram: true,
      },
      orderBy: [
        { totalEnrollments: 'desc' },
        { totalCommission: 'desc' },
      ],
      take: 20,
    });

    const leaderboard = referrers.map((r, idx) => ({
      rank: idx + 1,
      ...r,
      tierLabel: TIER_LABELS[r.tier] || 'برنزی',
      tierRate: TIER_RATES[r.tier] || 0.10,
    }));

    return NextResponse.json({ leaderboard });
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات' }, { status: 500 });
  }
}
