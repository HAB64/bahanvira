import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/referrers/commissions — List all commissions
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const referrerId = searchParams.get('referrerId');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '50', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (status && status !== 'all') where.status = status;
    if (referrerId) where.referrerId = referrerId;

    const [commissions, total] = await Promise.all([
      db.referrerCommission.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          referrer: { select: { id: true, firstName: true, lastName: true, code: true } },
          referral: { select: { id: true, refName: true, refPhone: true } },
        },
      }),
      db.referrerCommission.count({ where }),
    ]);

    return NextResponse.json({
      data: commissions,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Commissions list error:', error);
    return NextResponse.json({ error: 'خطا در دریافت پورسانت‌ها' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/referrers/commissions — Update commission status
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { commissionId, status } = body;

    if (!commissionId || !status) {
      return NextResponse.json({ error: 'شناسه پورسانت و وضعیت الزامی است' }, { status: 400 });
    }

    const existing = await db.referrerCommission.findUnique({
      where: { id: commissionId },
    });

    if (!existing) {
      return NextResponse.json({ error: 'پورسانت یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = { status };
    if (status === 'APPROVED') updateData.approvedAt = new Date();
    if (status === 'PAID') {
      updateData.paidAt = new Date();
      if (!existing.approvedAt) updateData.approvedAt = new Date();
    }

    const updated = await db.referrerCommission.update({
      where: { id: commissionId },
      data: updateData,
    });

    // Update referrer totalPaidCommission if commission is paid
    if (status === 'PAID') {
      await db.referrer.update({
        where: { id: existing.referrerId },
        data: {
          totalPaidCommission: { increment: existing.commissionAmount },
        },
      });
    }

    return NextResponse.json({ message: 'وضعیت پورسانت با موفقیت به‌روزرسانی شد', data: updated });
  } catch (error) {
    console.error('Commission update error:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی پورسانت' }, { status: 500 });
  }
}
