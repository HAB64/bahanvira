import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * GET /api/crm/referrers/payments
 * List all referral payments
 */
export async function GET(request: NextRequest) {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const referrerId = searchParams.get('referrerId') || '';

    const where: Record<string, unknown> = {};
    if (referrerId) where.referrerId = referrerId;

    const payments = await db.referralPayment.findMany({
      where,
      include: {
        referrer: { select: { id: true, firstName: true, lastName: true, code: true } },
        commissions: true,
      },
      orderBy: { paidAt: 'desc' },
      take: 100,
    });

    return NextResponse.json({ payments });
  } catch (error) {
    console.error('Error fetching payments:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات' }, { status: 500 });
  }
}

/**
 * POST /api/crm/referrers/payments
 * Create a new payment (settle commissions)
 */
export async function POST(request: NextRequest) {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await request.json();
    const { referrerId, amount, method, reference, note, periodFrom, periodTo, commissionIds } = body;

    if (!referrerId || !amount) {
      return NextResponse.json({ error: 'معرف و مبلغ الزامی است' }, { status: 400 });
    }

    // Create payment
    const payment = await db.referralPayment.create({
      data: {
        referrerId,
        amount,
        method: method || 'BANK_TRANSFER',
        reference: reference || null,
        note: note || null,
        paidAt: new Date(),
        periodFrom: periodFrom ? new Date(periodFrom) : null,
        periodTo: periodTo ? new Date(periodTo) : null,
      },
    });

    // Mark commissions as paid
    if (commissionIds && Array.isArray(commissionIds)) {
      await db.referralCommission.updateMany({
        where: { id: { in: commissionIds } },
        data: { status: 'PAID', paidAt: new Date(), paymentId: payment.id },
      });
    } else {
      // Auto-approve and pay all pending commissions
      await db.referralCommission.updateMany({
        where: { referrerId, status: 'PENDING' },
        data: { status: 'PAID', paidAt: new Date(), paymentId: payment.id },
      });
    }

    // Update referrer total paid
    await db.referrer.update({
      where: { id: referrerId },
      data: { totalPaid: { increment: amount } },
    });

    return NextResponse.json({ success: true, payment }, { status: 201 });
  } catch (error) {
    console.error('Error creating payment:', error);
    return NextResponse.json({ error: 'خطا در ثبت پرداخت' }, { status: 500 });
  }
}
