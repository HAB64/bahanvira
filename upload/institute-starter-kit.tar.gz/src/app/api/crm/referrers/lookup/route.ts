import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/referrers/lookup?code=XXX — Look up a referrer by code (public)
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');

    if (!code) {
      return NextResponse.json({ error: 'کد معرف الزامی است' }, { status: 400 });
    }

    const referrer = await db.referrer.findUnique({
      where: { code },
      select: {
        id: true,
        code: true,
        firstName: true,
        lastName: true,
        isActive: true,
        status: true,
      },
    });

    if (!referrer) {
      return NextResponse.json({ error: 'کد معرف نامعتبر است', valid: false }, { status: 404 });
    }

    if (!referrer.isActive || referrer.status !== 'ACTIVE') {
      return NextResponse.json({ error: 'این کد معرف غیرفعال است', valid: false }, { status: 400 });
    }

    return NextResponse.json({
      valid: true,
      data: {
        id: referrer.id,
        code: referrer.code,
        firstName: referrer.firstName,
        lastName: referrer.lastName,
      },
    });
  } catch (error) {
    console.error('Referrer lookup error:', error);
    return NextResponse.json({ error: 'خطا در بررسی کد معرف' }, { status: 500 });
  }
}
