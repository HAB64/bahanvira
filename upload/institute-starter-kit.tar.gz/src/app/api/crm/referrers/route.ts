import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * سطوح پورسانت پیش‌فرض
 */
const DEFAULT_COMMISSION_TIERS = [
  { minEnrollments: 1, maxEnrollments: 5, pct: 10, name: 'پایه', level: 1 },
  { minEnrollments: 6, maxEnrollments: 15, pct: 12, name: 'برنزی', level: 2 },
  { minEnrollments: 16, maxEnrollments: 30, pct: 15, name: 'نقره‌ای', level: 3 },
  { minEnrollments: 31, maxEnrollments: Infinity, pct: 20, name: 'طلایی', level: 4 },
];

/**
 * نقشه‌برداری حروف فارسی به معادل لاتین برای تولید کد ASCII
 * Persian to Latin transliteration map for ASCII-safe referrer codes
 */
const PERSIAN_TO_LATIN: Record<string, string> = {
  'ا':'A','آ':'A','ب':'B','پ':'P','ت':'T','ث':'S','ج':'J','چ':'CH',
  'ح':'H','خ':'KH','د':'D','ذ':'Z','ر':'R','ز':'Z','ژ':'ZH',
  'س':'S','ش':'SH','ص':'S','ض':'Z','ط':'T','ظ':'Z','ع':'A','غ':'GH',
  'ف':'F','ق':'G','ک':'K','گ':'G','ل':'L','م':'M','ن':'N','و':'V',
  'ه':'H','ی':'Y',
};

/**
 * تبدیل نام فارسی به معادل لاتین
 * Transliterate Persian name to Latin characters (ASCII-safe)
 */
function transliteratePersian(name: string): string {
  return name
    .split('')
    .map(ch => PERSIAN_TO_LATIN[ch] || ch)
    .join('');
}

/**
 * تولید کد یکتای معرف از نام (فقط حروف ASCII)
 * Example: "علی محمدی" → "ALI1404" (transliterated + Persian year)
 */
async function generateUniqueCode(firstName: string, lastName: string): Promise<string> {
  // First try transliterating Persian to Latin, then keep only ASCII letters
  const transliterated = transliteratePersian(firstName);
  const cleanName = transliterated
    .replace(/[^a-zA-Z]/g, '')
    .toUpperCase()
    .slice(0, 4);

  const now = new Date();
  const persianYear = now.getFullYear() - 621;

  let baseCode = cleanName.length > 0 ? `${cleanName}${persianYear}` : `REF${persianYear}`;

  if (baseCode.length < 4) {
    baseCode = baseCode.padEnd(4, '0');
  }

  let code = baseCode;
  let suffix = 1;

  while (true) {
    const existing = await db.referrer.findUnique({ where: { code } });
    if (!existing) break;
    code = `${baseCode}${suffix}`;
    suffix++;
  }

  return code;
}

/**
 * GET /api/crm/referrers
 * لیست معرف‌ها با آمار. پشتیبانی جستجو و فیلتر بر اساس وضعیت
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const status = searchParams.get('status');
    const search = searchParams.get('search');

    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (status) {
      where.status = status;
    }

    if (search) {
      where.OR = [
        { code: { contains: search, mode: 'insensitive' } },
        { firstName: { contains: search, mode: 'insensitive' } },
        { lastName: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [referrers, total] = await Promise.all([
      db.referrer.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          _count: {
            select: {
              referrals: true,
              commissions: true,
              payouts: true,
            },
          },
        },
      }),
      db.referrer.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست معرف‌ها با موفقیت دریافت شد',
      داده‌ها: referrers,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Referrers list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست معرف‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/referrers
 * ایجاد معرف جدید. تولید خودکار کد یکتا
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      firstName,
      lastName,
      phone,
      email,
      avatarUrl,
      baseCommissionPct,
      commissionTiers,
      bankName,
      bankAccountNo,
      bankCardNo,
      bankShaba,
      notes,
    } = body;

    if (!firstName || !lastName || !phone) {
      return NextResponse.json(
        { خطا: 'نام، نام خانوادگی و شماره تلفن الزامی است' },
        { status: 400 }
      );
    }

    const existingPhone = await db.referrer.findFirst({ where: { phone } });
    if (existingPhone) {
      return NextResponse.json(
        { خطا: 'این شماره تلفن قبلاً به عنوان معرف ثبت شده است' },
        { status: 409 }
      );
    }

    const code = await generateUniqueCode(firstName, lastName);
    const tiers = commissionTiers || DEFAULT_COMMISSION_TIERS;

    const referrer = await db.referrer.create({
      data: {
        code,
        firstName,
        lastName,
        phone,
        email: email || null,
        avatarUrl: avatarUrl || null,
        isActive: true,
        status: 'ACTIVE',
        baseCommissionPct: baseCommissionPct || 10.0,
        commissionTiers: tiers,
        bankName: bankName || null,
        bankAccountNo: bankAccountNo || null,
        bankCardNo: bankCardNo || null,
        bankShaba: bankShaba || null,
        notes: notes || null,
      },
    });

    return NextResponse.json(
      {
        پیام: 'معرف با موفقیت ایجاد شد',
        داده: referrer,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Referrer creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت معرف جدید' },
      { status: 500 }
    );
  }
}
