import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/referrers/payouts — List all payouts
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const referrerId = searchParams.get('referrerId');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '50', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (referrerId) where.referrerId = referrerId;

    const [payouts, total] = await Promise.all([
      db.referrerPayout.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          referrer: { select: { id: true, firstName: true, lastName: true, code: true, bankName: true, bankAccountNo: true, bankShaba: true } },
        },
      }),
      db.referrerPayout.count({ where }),
    ]);

    return NextResponse.json({
      data: payouts,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Payouts list error:', error);
    return NextResponse.json({ error: 'خطا در دریافت پرداخت‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/referrers/payouts — Create a new payout
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { referrerId, method, periodStart, periodEnd, notes } = body;

    if (!referrerId || !periodStart || !periodEnd) {
      return NextResponse.json({ error: 'شناسه معرف و بازه زمانی الزامی است' }, { status: 400 });
    }

    const referrer = await db.referrer.findUnique({
      where: { id: referrerId },
    });

    if (!referrer) {
      return NextResponse.json({ error: 'معرف یافت نشد' }, { status: 404 });
    }

    // Calculate pending commissions in the period
    const pendingCommissions = await db.referrerCommission.findMany({
      where: {
        referrerId,
        status: 'APPROVED',
        createdAt: {
          gte: new Date(periodStart),
          lte: new Date(periodEnd),
        },
      },
    });

    const totalAmount = pendingCommissions.reduce((sum, c) => sum + c.commissionAmount, 0);

    if (totalAmount === 0) {
      return NextResponse.json({ error: 'پورسانت تأییدشده‌ای در این بازه زمانی وجود ندارد' }, { status: 400 });
    }

    const payout = await db.referrerPayout.create({
      data: {
        referrerId,
        amount: totalAmount,
        method: method || 'BANK_TRANSFER',
        bankName: referrer.bankName,
        bankAccountNo: referrer.bankAccountNo,
        bankShaba: referrer.bankShaba,
        periodStart: new Date(periodStart),
        periodEnd: new Date(periodEnd),
        status: 'PENDING',
        notes: notes || null,
      },
    });

    // Mark commissions as paid
    await db.referrerCommission.updateMany({
      where: {
        id: { in: pendingCommissions.map(c => c.id) },
      },
      data: {
        status: 'PAID',
        paidAt: new Date(),
      },
    });

    // Update referrer paid total
    await db.referrer.update({
      where: { id: referrerId },
      data: {
        totalPaidCommission: { increment: totalAmount },
      },
    });

    return NextResponse.json({ message: 'پرداخت با موفقیت ثبت شد', data: payout }, { status: 201 });
  } catch (error) {
    console.error('Payout creation error:', error);
    return NextResponse.json({ error: 'خطا در ثبت پرداخت' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/referrers/payouts — Update payout status
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { payoutId, status, trackingNo, notes } = body;

    if (!payoutId) {
      return NextResponse.json({ error: 'شناسه پرداخت الزامی است' }, { status: 400 });
    }

    const existing = await db.referrerPayout.findUnique({ where: { id: payoutId } });
    if (!existing) {
      return NextResponse.json({ error: 'پرداخت یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};
    if (status) {
      updateData.status = status;
      if (status === 'COMPLETED') updateData.completedAt = new Date();
    }
    if (trackingNo) updateData.trackingNo = trackingNo;
    if (notes !== undefined) updateData.notes = notes;

    const updated = await db.referrerPayout.update({
      where: { id: payoutId },
      data: updateData,
    });

    return NextResponse.json({ message: 'پرداخت با موفقیت به‌روزرسانی شد', data: updated });
  } catch (error) {
    console.error('Payout update error:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی پرداخت' }, { status: 500 });
  }
}
