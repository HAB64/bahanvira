import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/service-contracts — List service contracts with filters
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const leadId = searchParams.get('leadId');
    const karAmuzId = searchParams.get('karAmuzId');
    const type = searchParams.get('type');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (leadId) where.leadId = leadId;
    if (karAmuzId) where.karAmuzId = karAmuzId;
    if (type) where.type = type;
    if (search) {
      where.OR = [
        { contractNumber: { contains: search, mode: 'insensitive' } },
        { title: { contains: search, mode: 'insensitive' } },
        { notes: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [contracts, total] = await Promise.all([
      db.serviceContract.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          lead: { select: { id: true, name: true, phone: true } },
          karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
          _count: { select: { serviceActivities: true, warranties: true } },
        },
      }),
      db.serviceContract.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست قراردادهای خدمات با موفقیت دریافت شد',
      داده‌ها: contracts,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Service contracts list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت قراردادهای خدمات' }, { status: 500 });
  }
}

/**
 * POST /api/crm/service-contracts — Create a new service contract
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      leadId, karAmuzId, title, description, type,
      responseTimeHrs, resolutionTimeHrs, uptimeGuarantee,
      startDate, endDate, contractValue, notes,
    } = body;

    if (!title) {
      return NextResponse.json({ خطا: 'عنوان قرارداد الزامی است' }, { status: 400 });
    }
    if (!startDate) {
      return NextResponse.json({ خطا: 'تاریخ شروع قرارداد الزامی است' }, { status: 400 });
    }

    // Generate contract number: SC-YYYY-XXXX
    const currentYear = new Date().getFullYear();
    const lastContract = await db.serviceContract.findFirst({
      where: { contractNumber: { startsWith: `SC-${currentYear}-` } },
      orderBy: { contractNumber: 'desc' },
    });
    let seq = 1;
    if (lastContract?.contractNumber) {
      const parts = lastContract.contractNumber.split('-');
      seq = (parseInt(parts[2] || '0', 10) || 0) + 1;
    }
    const contractNumber = `SC-${currentYear}-${seq.toString().padStart(4, '0')}`;

    const contract = await db.serviceContract.create({
      data: {
        contractNumber,
        leadId: leadId || null,
        karAmuzId: karAmuzId || null,
        title,
        description: description || null,
        type: type || 'SLA',
        responseTimeHrs: responseTimeHrs ?? 24,
        resolutionTimeHrs: resolutionTimeHrs ?? 72,
        uptimeGuarantee: uptimeGuarantee ?? null,
        startDate: new Date(startDate),
        endDate: endDate ? new Date(endDate) : null,
        contractValue: contractValue || 0,
        notes: notes || null,
        status: 'DRAFT',
      },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    return NextResponse.json({ پیام: 'قرارداد خدمات با موفقیت ایجاد شد', داده: contract }, { status: 201 });
  } catch (error) {
    console.error('Service contract creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت قرارداد خدمات' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/service-contracts — Update contract status/notes
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { contractId, status, notes } = body;

    if (!contractId) {
      return NextResponse.json({ خطا: 'شناسه قرارداد الزامی است' }, { status: 400 });
    }

    const existing = await db.serviceContract.findUnique({ where: { id: contractId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'قرارداد یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};
    if (status) {
      const validStatuses = ['DRAFT', 'ACTIVE', 'EXPIRED', 'TERMINATED'];
      if (!validStatuses.includes(status)) {
        return NextResponse.json({ خطا: `وضعیت نامعتبر. مقادیر مجاز: ${validStatuses.join(', ')}` }, { status: 400 });
      }
      updateData.status = status;
    }
    if (notes !== undefined) updateData.notes = notes;

    const updated = await db.serviceContract.update({
      where: { id: contractId },
      data: updateData,
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    return NextResponse.json({ پیام: 'قرارداد خدمات به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Service contract update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی قرارداد' }, { status: 500 });
  }
}
