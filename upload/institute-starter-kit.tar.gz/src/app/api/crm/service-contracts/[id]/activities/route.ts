import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/service-contracts/[id]/activities — List activities for a contract
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const priority = searchParams.get('priority');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const contract = await db.serviceContract.findUnique({ where: { id } });
    if (!contract) {
      return NextResponse.json({ خطا: 'قرارداد یافت نشد' }, { status: 404 });
    }

    const where: Record<string, unknown> = { contractId: id };
    if (status) where.status = status;
    if (priority) where.priority = priority;

    const [activities, total] = await Promise.all([
      db.serviceActivity.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      db.serviceActivity.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست فعالیت‌ها با موفقیت دریافت شد',
      داده‌ها: activities,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Service activities list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت فعالیت‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/service-contracts/[id]/activities — Create activity with auto SLA deadline
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { title, description, type, priority, scheduledAt, assignedTo, notes } = body;

    if (!title) {
      return NextResponse.json({ خطا: 'عنوان فعالیت الزامی است' }, { status: 400 });
    }

    const contract = await db.serviceContract.findUnique({ where: { id } });
    if (!contract) {
      return NextResponse.json({ خطا: 'قرارداد یافت نشد' }, { status: 404 });
    }

    // Auto-calculate SLA deadline: createdAt + resolutionTimeHrs from contract
    const now = new Date();
    const slaDeadline = new Date(now.getTime() + (contract.resolutionTimeHrs || 72) * 60 * 60 * 1000);

    const activity = await db.serviceActivity.create({
      data: {
        contractId: id,
        title,
        description: description || null,
        type: type || 'SUPPORT',
        priority: priority || 'MEDIUM',
        status: 'PENDING',
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
        slaDeadline,
        assignedTo: assignedTo || '',
        notes: notes || null,
      },
    });

    return NextResponse.json({ پیام: 'فعالیت با موفقیت ایجاد شد', داده: activity }, { status: 201 });
  } catch (error) {
    console.error('Service activity creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت فعالیت' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/service-contracts/[id]/activities — Update activity status, check SLA breach
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { activityId, status, priority, assignedTo, hoursSpent, notes } = body;

    if (!activityId) {
      return NextResponse.json({ خطا: 'شناسه فعالیت الزامی است' }, { status: 400 });
    }

    const existing = await db.serviceActivity.findFirst({
      where: { id: activityId, contractId: id },
    });
    if (!existing) {
      return NextResponse.json({ خطا: 'فعالیت یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};

    if (status) {
      const validStatuses = ['PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'];
      if (!validStatuses.includes(status)) {
        return NextResponse.json({ خطا: `وضعیت نامعتبر. مقادیر مجاز: ${validStatuses.join(', ')}` }, { status: 400 });
      }
      updateData.status = status;

      // Check SLA breach on completion
      if (status === 'COMPLETED') {
        updateData.completedAt = new Date();
        if (existing.slaDeadline && new Date() > existing.slaDeadline) {
          updateData.slaBreached = true;
        }
      }
      if (status === 'IN_PROGRESS' && !existing.slaDeadline) {
        // Set SLA deadline if not already set
        const contract = await db.serviceContract.findUnique({ where: { id } });
        if (contract) {
          updateData.slaDeadline = new Date(Date.now() + (contract.resolutionTimeHrs || 72) * 60 * 60 * 1000);
        }
      }
    }

    if (priority) updateData.priority = priority;
    if (assignedTo !== undefined) updateData.assignedTo = assignedTo;
    if (hoursSpent !== undefined) updateData.hoursSpent = hoursSpent;
    if (notes !== undefined) updateData.notes = notes;

    const updated = await db.serviceActivity.update({
      where: { id: activityId },
      data: updateData,
    });

    return NextResponse.json({
      پیام: updateData.slaBreached ? 'فعالیت به‌روزرسانی شد — هشدار: SLA نقض شده است!' : 'فعالیت با موفقیت به‌روزرسانی شد',
      داده: updated,
      هشدار_SLA: updateData.slaBreached || false,
    });
  } catch (error) {
    console.error('Service activity update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی فعالیت' }, { status: 500 });
  }
}
