import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/service-contracts/[id] — Get single contract with relations
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const contract = await db.serviceContract.findUnique({
      where: { id },
      include: {
        lead: { select: { id: true, name: true, phone: true, email: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true, email: true } },
        serviceActivities: { orderBy: { createdAt: 'desc' } },
        warranties: { orderBy: { createdAt: 'desc' } },
      },
    });

    if (!contract) {
      return NextResponse.json({ خطا: 'قرارداد یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ پیام: 'قرارداد با موفقیت دریافت شد', داده: contract });
  } catch (error) {
    console.error('Service contract get error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت قرارداد' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/service-contracts/[id] — Update any contract field
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const existing = await db.serviceContract.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ خطا: 'قرارداد یافت نشد' }, { status: 404 });
    }

    const allowedFields = [
      'title', 'description', 'type', 'responseTimeHrs', 'resolutionTimeHrs',
      'uptimeGuarantee', 'startDate', 'endDate', 'status', 'contractValue', 'notes',
      'leadId', 'karAmuzId',
    ];
    const updateData: Record<string, unknown> = {};

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        if (field === 'startDate' || field === 'endDate') {
          updateData[field] = body[field] ? new Date(body[field]) : null;
        } else if (field === 'status') {
          const validStatuses = ['DRAFT', 'ACTIVE', 'EXPIRED', 'TERMINATED'];
          if (!validStatuses.includes(body[field])) {
            return NextResponse.json({ خطا: `وضعیت نامعتبر. مقادیر مجاز: ${validStatuses.join(', ')}` }, { status: 400 });
          }
          updateData[field] = body[field];
        } else {
          updateData[field] = body[field];
        }
      }
    }

    const updated = await db.serviceContract.update({
      where: { id },
      data: updateData,
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
        serviceActivities: { orderBy: { createdAt: 'desc' } },
        warranties: { orderBy: { createdAt: 'desc' } },
      },
    });

    return NextResponse.json({ پیام: 'قرارداد با موفقیت به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Service contract update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی قرارداد' }, { status: 500 });
  }
}

/**
 * DELETE /api/crm/service-contracts/[id] — Delete a service contract
 */
export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const existing = await db.serviceContract.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ خطا: 'قرارداد یافت نشد' }, { status: 404 });
    }

    await db.serviceContract.delete({ where: { id } });

    return NextResponse.json({ پیام: 'قرارداد با موفقیت حذف شد' });
  } catch (error) {
    console.error('Service contract delete error:', error);
    return NextResponse.json({ خطا: 'خطا در حذف قرارداد' }, { status: 500 });
  }
}
