import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/service-contracts/[id]/warranties — List warranties for a contract
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const contract = await db.serviceContract.findUnique({ where: { id } });
    if (!contract) {
      return NextResponse.json({ خطا: 'قرارداد یافت نشد' }, { status: 404 });
    }

    const where: Record<string, unknown> = { contractId: id };
    if (status) where.status = status;

    const [warranties, total] = await Promise.all([
      db.warranty.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      db.warranty.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست گارانتی‌ها با موفقیت دریافت شد',
      داده‌ها: warranties,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Warranties list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت گارانتی‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/service-contracts/[id]/warranties — Create warranty with auto-calculated endDate
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { title, description, durationMonths, startDate, coverageDetails, maxClaims } = body;

    if (!title) {
      return NextResponse.json({ خطا: 'عنوان گارانتی الزامی است' }, { status: 400 });
    }
    if (!durationMonths || durationMonths <= 0) {
      return NextResponse.json({ خطا: 'مدت گارانتی (ماه) باید بزرگتر از صفر باشد' }, { status: 400 });
    }
    if (!startDate) {
      return NextResponse.json({ خطا: 'تاریخ شروع گارانتی الزامی است' }, { status: 400 });
    }

    const contract = await db.serviceContract.findUnique({ where: { id } });
    if (!contract) {
      return NextResponse.json({ خطا: 'قرارداد یافت نشد' }, { status: 404 });
    }

    // Auto-calculate endDate: startDate + durationMonths
    const start = new Date(startDate);
    const end = new Date(start);
    end.setMonth(end.getMonth() + durationMonths);

    const warranty = await db.warranty.create({
      data: {
        contractId: id,
        title,
        description: description || null,
        durationMonths,
        startDate: start,
        endDate: end,
        coverageDetails: coverageDetails || '{}',
        maxClaims: maxClaims || 0,
        claimsUsed: 0,
        status: 'ACTIVE',
      },
    });

    return NextResponse.json({ پیام: 'گارانتی با موفقیت ایجاد شد', داده: warranty }, { status: 201 });
  } catch (error) {
    console.error('Warranty creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت گارانتی' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/service-contracts/[id]/warranties — Update warranty status, increment claimsUsed
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { warrantyId, status, incrementClaim, title, description, coverageDetails, notes } = body;

    if (!warrantyId) {
      return NextResponse.json({ خطا: 'شناسه گارانتی الزامی است' }, { status: 400 });
    }

    const existing = await db.warranty.findFirst({
      where: { id: warrantyId, contractId: id },
    });
    if (!existing) {
      return NextResponse.json({ خطا: 'گارانتی یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};

    if (status) {
      const validStatuses = ['ACTIVE', 'EXPIRED', 'VOIDED', 'CLAIMED'];
      if (!validStatuses.includes(status)) {
        return NextResponse.json({ خطا: `وضعیت نامعتبر. مقادیر مجاز: ${validStatuses.join(', ')}` }, { status: 400 });
      }
      updateData.status = status;
    }

    // Increment claimsUsed
    if (incrementClaim) {
      const newClaimsUsed = (existing.claimsUsed || 0) + 1;
      updateData.claimsUsed = newClaimsUsed;

      // Check if maxClaims reached
      if (existing.maxClaims > 0 && newClaimsUsed >= existing.maxClaims) {
        updateData.status = 'CLAIMED';
      }
    }

    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (coverageDetails !== undefined) updateData.coverageDetails = coverageDetails;

    const updated = await db.warranty.update({
      where: { id: warrantyId },
      data: updateData,
    });

    const maxReached = existing.maxClaims > 0 && (updateData.claimsUsed as number) >= existing.maxClaims;

    return NextResponse.json({
      پیام: maxReached ? 'گارانتی به‌روزرسانی شد — حداکثر تعداد ادعا رسیده است' : 'گارانتی با موفقیت به‌روزرسانی شد',
      داده: updated,
      حداکثر_ادعا_رسیده: maxReached || false,
    });
  } catch (error) {
    console.error('Warranty update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی گارانتی' }, { status: 500 });
  }
}
