import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/business-processes — List business processes
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const isActive = searchParams.get('isActive');
    const triggerType = searchParams.get('triggerType');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (isActive !== null && isActive !== undefined) {
      where.isActive = isActive === 'true';
    }
    if (triggerType) where.triggerType = triggerType;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [processes, total] = await Promise.all([
      db.businessProcess.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { executions: true } },
        },
      }),
      db.businessProcess.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست فرآیندها با موفقیت دریافت شد',
      داده‌ها: processes,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Business processes list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت فرآیندها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/business-processes — Create business process
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, steps, triggerType, triggerConditions, isActive, version } = body;

    if (!name) {
      return NextResponse.json({ خطا: 'نام فرآیند الزامی است' }, { status: 400 });
    }
    if (!steps) {
      return NextResponse.json({ خطا: 'مراحل فرآیند الزامی است' }, { status: 400 });
    }
    if (!triggerType) {
      return NextResponse.json({ خطا: 'نوع راه‌انداز فرآیند الزامی است' }, { status: 400 });
    }

    const validTriggers = ['MANUAL', 'LEAD_CREATED', 'STAGE_CHANGED', 'PAYMENT_RECEIVED', 'TICKET_CREATED'];
    if (!validTriggers.includes(triggerType)) {
      return NextResponse.json({ خطا: `نوع راه‌انداز نامعتبر. مقادیر مجاز: ${validTriggers.join(', ')}` }, { status: 400 });
    }

    const process = await db.businessProcess.create({
      data: {
        name,
        description: description || null,
        steps,
        triggerType,
        triggerConditions: triggerConditions || null,
        isActive: isActive !== undefined ? isActive : true,
        version: version || 1,
      },
    });

    return NextResponse.json({ پیام: 'فرآیند با موفقیت ایجاد شد', داده: process }, { status: 201 });
  } catch (error) {
    console.error('Business process creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت فرآیند' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/business-processes — Update business process
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { processId, ...otherFields } = body;

    if (!processId) {
      return NextResponse.json({ خطا: 'شناسه فرآیند الزامی است' }, { status: 400 });
    }

    const existing = await db.businessProcess.findUnique({ where: { id: processId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'فرآیند یافت نشد' }, { status: 404 });
    }

    const allowedFields = ['name', 'description', 'steps', 'triggerType', 'triggerConditions', 'isActive', 'version'];
    const updateData: Record<string, unknown> = {};
    for (const field of allowedFields) {
      if (otherFields[field] !== undefined) {
        updateData[field] = otherFields[field];
      }
    }

    // Auto-increment version if steps changed
    if (otherFields.steps) {
      updateData.version = (existing.version || 1) + 1;
    }

    const updated = await db.businessProcess.update({
      where: { id: processId },
      data: updateData,
      include: {
        _count: { select: { executions: true } },
      },
    });

    return NextResponse.json({ پیام: 'فرآیند با موفقیت به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Business process update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی فرآیند' }, { status: 500 });
  }
}
