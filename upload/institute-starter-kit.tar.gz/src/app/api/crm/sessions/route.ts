import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/sessions
 * List sessions with optional filters.
 * Query params: skillProgramId, dateFrom, dateTo
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const skillProgramId = searchParams.get('skillProgramId');
    const dateFrom = searchParams.get('dateFrom');
    const dateTo = searchParams.get('dateTo');

    const where: Record<string, unknown> = {};

    if (skillProgramId) {
      where.skillProgramId = skillProgramId;
    }

    if (dateFrom || dateTo) {
      where.date = {
        ...(dateFrom && { gte: new Date(dateFrom) }),
        ...(dateTo && { lte: new Date(dateTo) }),
      };
    }

    const sessions = await db.session.findMany({
      where,
      orderBy: { date: 'desc' },
      include: {
        skillProgram: {
          select: {
            id: true,
            name: true,
            code: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'لیست جلسات با موفقیت دریافت شد',
      داده‌ها: sessions,
    });
  } catch (error) {
    console.error('Sessions list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست جلسات' },
      { status: 500 }
    );
  }
}
