import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

import { getAdminSession } from '@/lib/admin-auth';
const prisma = new PrismaClient();

/**
 * GET /api/crm/stats
 * Return pipeline stats: count by stage, count by cluster,
 * recent leads count, follow-ups due today, monthly trends.
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    // Count by stage
    const leadsByStage = await prisma.lead.groupBy({
      by: ['stage'],
      _count: { id: true },
    });

    const stageCounts: Record<string, number> = {
      NEW: 0,
      CONTACTED: 0,
      INTERESTED: 0,
      ENROLLED: 0,
    };

    for (const item of leadsByStage) {
      stageCounts[item.stage] = item._count.id;
    }

    // Count by cluster
    const leadsByCluster = await prisma.lead.groupBy({
      by: ['cluster'],
      _count: { id: true },
    });

    const clusterCounts: Record<string, number> = {};
    for (const item of leadsByCluster) {
      if (item.cluster) {
        clusterCounts[item.cluster] = item._count.id;
      }
    }

    // Recent leads (last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const recentLeadsCount = await prisma.lead.count({
      where: {
        createdAt: { gte: sevenDaysAgo },
      },
    });

    // Follow-ups due today
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const followUpsDueToday = await prisma.activityLog.count({
      where: {
        followUpAt: {
          gte: todayStart,
          lte: todayEnd,
        },
        type: 'REMINDER',
      },
    });

    // Total leads
    const totalLeads = await prisma.lead.count();

    // Average score
    const scoreResult = await prisma.lead.aggregate({
      _avg: { score: true },
    });

    // Total revenue (sum of paid payments)
    const paidPayments = await prisma.payment.findMany({
      where: { status: 'PAID' },
      select: { amount: true },
    });
    const totalRevenue = paidPayments.reduce((sum, p) => sum + p.amount, 0);

    // Pending payments total
    const pendingPayments = await prisma.payment.findMany({
      where: { status: 'PENDING' },
      select: { amount: true },
    });
    const pendingRevenue = pendingPayments.reduce((sum, p) => sum + p.amount, 0);

    // ── Monthly Trends (last 6 months) ──
    const monthlyLeads: { month: string; count: number }[] = [];
    const monthlyRevenue: { month: string; revenue: number }[] = [];
    const monthlyConversion: { month: string; rate: number }[] = [];

    for (let i = 5; i >= 0; i--) {
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setMonth(monthStart.getMonth() - i);
      monthStart.setHours(0, 0, 0, 0);

      const monthEnd = new Date(monthStart);
      monthEnd.setMonth(monthEnd.getMonth() + 1);
      monthEnd.setDate(0); // last day of month
      monthEnd.setHours(23, 59, 59, 999);

      const monthLabel = new Intl.DateTimeFormat('fa-IR', {
        month: 'short',
        year: '2-digit',
      }).format(monthStart);

      // Leads count for this month
      const leadsCount = await prisma.lead.count({
        where: {
          createdAt: {
            gte: monthStart,
            lte: monthEnd,
          },
        },
      });

      // Enrolled count for this month
      const enrolledCount = await prisma.lead.count({
        where: {
          createdAt: {
            gte: monthStart,
            lte: monthEnd,
          },
          stage: 'ENROLLED',
        },
      });

      // Revenue for this month (PAID payments)
      const monthPayments = await prisma.payment.findMany({
        where: {
          status: 'PAID',
          paidAt: {
            gte: monthStart,
            lte: monthEnd,
          },
        },
        select: { amount: true },
      });
      const monthRevenue = monthPayments.reduce((sum, p) => sum + p.amount, 0);

      const conversionRate = leadsCount > 0 ? Math.round((enrolledCount / leadsCount) * 100) : 0;

      monthlyLeads.push({ month: monthLabel, count: leadsCount });
      monthlyRevenue.push({ month: monthLabel, revenue: monthRevenue });
      monthlyConversion.push({ month: monthLabel, rate: conversionRate });
    }

    return NextResponse.json({
      پیام: 'آمار داشبورد با موفقیت دریافت شد',
      داده: {
        لیدها_بر_مرحله: stageCounts,
        لیدها_بر_خوشه: clusterCounts,
        لیدهای_اخیر: recentLeadsCount,
        پیگیری_امروز: followUpsDueToday,
        کل_لیدها: totalLeads,
        میانگین_امتیاز: Math.round(scoreResult._avg.score || 0),
        درآمد_کل: totalRevenue,
        درآمد_در_انتظار: pendingRevenue,
        لیدهای_ماهانه: monthlyLeads,
        درآمد_ماهانه: monthlyRevenue,
        نرخ_تبدیل_ماهانه: monthlyConversion,
      },
    });
  } catch (error) {
    console.error('CRM stats error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت آمار داشبورد' },
      { status: 500 }
    );
  }
}
