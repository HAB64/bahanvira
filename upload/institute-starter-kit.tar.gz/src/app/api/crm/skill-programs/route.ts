import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/skill-programs
 * List SkillPrograms with filtering, sorting, and pagination.
 * Query params: isActive, cluster, search, page, limit, sort, order
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    // Filters
    const isActiveParam = searchParams.get('isActive');
    const cluster = searchParams.get('cluster');
    const search = searchParams.get('search');

    // Sorting
    const sort = searchParams.get('sort') || 'createdAt';
    const order = searchParams.get('order') || 'desc';

    // Pagination
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    // Build where clause
    const where: Record<string, unknown> = {};

    if (isActiveParam !== null) {
      where.isActive = isActiveParam === 'true';
    }

    if (cluster) {
      where.cluster = cluster;
    }

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { code: { contains: search, mode: 'insensitive' } },
        { instructorName: { contains: search, mode: 'insensitive' } },
      ];
    }

    // Validate sort field
    const allowedSortFields = [
      'createdAt', 'name', 'code', 'totalHours', 'price',
      'capacity', 'isActive', 'cluster', 'level',
    ];
    const sortField = allowedSortFields.includes(sort) ? sort : 'createdAt';
    const sortOrder = order === 'asc' ? 'asc' : 'desc';

    const [programs, total] = await Promise.all([
      db.skillProgram.findMany({
        where,
        orderBy: { [sortField]: sortOrder },
        skip,
        take: limit,
        include: {
          _count: {
            select: {
              enrollments: true,
              sessions: true,
            },
          },
        },
      }),
      db.skillProgram.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست دوره‌های مهارتی با موفقیت دریافت شد',
      داده‌ها: programs,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('CRM skill-programs list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست دوره‌های مهارتی' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/skill-programs
 * Create a new SkillProgram.
 * Required fields: name, totalHours
 * Validates: totalHours >= theoryHours + practicalHours
 * Validates: code uniqueness if provided
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      name,
      code,
      description,
      totalHours,
      theoryHours,
      practicalHours,
      minAttendancePct,
      price,
      capacity,
      isActive,
      cluster,
      instructorName,
      level,
    } = body;

    // Validate required fields
    if (!name || typeof name !== 'string' || name.trim() === '') {
      return NextResponse.json(
        { خطا: 'نام دوره مهارتی الزامی است' },
        { status: 400 }
      );
    }

    if (totalHours === undefined || totalHours === null || typeof totalHours !== 'number' || totalHours < 0) {
      return NextResponse.json(
        { خطا: 'مجموع ساعات باید یک عدد غیرمنفی باشد' },
        { status: 400 }
      );
    }

    // Validate totalHours >= theoryHours + practicalHours
    const theory = typeof theoryHours === 'number' ? theoryHours : 0;
    const practical = typeof practicalHours === 'number' ? practicalHours : 0;

    if (totalHours < theory + practical) {
      return NextResponse.json(
        { خطا: `مجموع ساعات (${totalHours}) نمی‌تواند کمتر از مجموع ساعات تئوری (${theory}) و عملی (${practical}) باشد` },
        { status: 400 }
      );
    }

    // Check code uniqueness if provided
    if (code && typeof code === 'string' && code.trim() !== '') {
      const existing = await db.skillProgram.findUnique({
        where: { code: code.trim() },
      });
      if (existing) {
        return NextResponse.json(
          { خطا: 'کد دوره مهارتی تکراری است' },
          { status: 409 }
        );
      }
    }

    const program = await db.skillProgram.create({
      data: {
        name: name.trim(),
        code: code?.trim() || null,
        description: description || null,
        totalHours,
        theoryHours: theory,
        practicalHours: practical,
        minAttendancePct: typeof minAttendancePct === 'number' ? minAttendancePct : 0.8,
        price: typeof price === 'number' ? price : null,
        capacity: typeof capacity === 'number' ? capacity : null,
        isActive: typeof isActive === 'boolean' ? isActive : true,
        cluster: cluster || null,
        instructorName: instructorName || null,
        level: level || null,
      },
      include: {
        _count: {
          select: {
            enrollments: true,
            sessions: true,
          },
        },
      },
    });

    return NextResponse.json(
      {
        پیام: 'دوره مهارتی با موفقیت ایجاد شد',
        داده: program,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('CRM skill-program creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت دوره مهارتی جدید' },
      { status: 500 }
    );
  }
}
