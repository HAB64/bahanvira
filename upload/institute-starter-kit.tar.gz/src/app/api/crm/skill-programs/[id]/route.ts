import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/skill-programs/[id]
 * Get a single SkillProgram with enrollments (including karAmuz),
 * sessions (ordered by date), and _count of certificates.
 */
export async function GET(
  _request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const program = await db.skillProgram.findUnique({
      where: { id },
      include: {
        enrollments: {
          include: {
            karAmuz: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                nationalId: true,
                studentCode: true,
                phone: true,
                status: true,
              },
            },
          },
          orderBy: { enrollmentDate: 'desc' },
        },
        sessions: {
          orderBy: { date: 'asc' },
        },
        _count: {
          select: {
            certificates: true,
          },
        },
      },
    });

    if (!program) {
      return NextResponse.json(
        { خطا: 'دوره مهارتی مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      پیام: 'اطلاعات دوره مهارتی با موفقیت دریافت شد',
      داده: program,
    });
  } catch (error) {
    console.error('CRM skill-program get error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت اطلاعات دوره مهارتی' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/crm/skill-programs/[id]
 * Update a SkillProgram.
 * Validates: totalHours >= theoryHours + practicalHours if both provided.
 */
export async function PATCH(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // Check if program exists
    const existingProgram = await db.skillProgram.findUnique({ where: { id } });
    if (!existingProgram) {
      return NextResponse.json(
        { خطا: 'دوره مهارتی مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate totalHours >= theoryHours + practicalHours
    const totalHours = body.totalHours !== undefined ? body.totalHours : existingProgram.totalHours;
    const theoryHours = body.theoryHours !== undefined ? body.theoryHours : existingProgram.theoryHours;
    const practicalHours = body.practicalHours !== undefined ? body.practicalHours : existingProgram.practicalHours;

    if (
      typeof totalHours === 'number' &&
      typeof theoryHours === 'number' &&
      typeof practicalHours === 'number'
    ) {
      if (totalHours < theoryHours + practicalHours) {
        return NextResponse.json(
          { خطا: `مجموع ساعات (${totalHours}) نمی‌تواند کمتر از مجموع ساعات تئوری (${theoryHours}) و عملی (${practicalHours}) باشد` },
          { status: 400 }
        );
      }
    }

    // Check code uniqueness if code is being changed
    if (body.code && body.code.trim() !== '' && body.code.trim() !== existingProgram.code) {
      const duplicate = await db.skillProgram.findUnique({
        where: { code: body.code.trim() },
      });
      if (duplicate) {
        return NextResponse.json(
          { خطا: 'کد دوره مهارتی تکراری است' },
          { status: 409 }
        );
      }
    }

    // Build update data
    const updateData: Record<string, unknown> = {};

    const allowedFields = [
      'name', 'code', 'description', 'totalHours', 'theoryHours',
      'practicalHours', 'minAttendancePct', 'price', 'capacity',
      'isActive', 'cluster', 'instructorName', 'level',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field];
      }
    }

    // Trim string fields
    if (updateData.name && typeof updateData.name === 'string') {
      updateData.name = (updateData.name as string).trim();
    }
    if (updateData.code !== undefined) {
      updateData.code = (updateData.code as string)?.trim() || null;
    }

    const updatedProgram = await db.skillProgram.update({
      where: { id },
      data: updateData,
      include: {
        _count: {
          select: {
            enrollments: true,
            sessions: true,
            certificates: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'اطلاعات دوره مهارتی با موفقیت به‌روزرسانی شد',
      داده: updatedProgram,
    });
  } catch (error) {
    console.error('CRM skill-program update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی اطلاعات دوره مهارتی' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/crm/skill-programs/[id]
 * Soft delete a SkillProgram (set isActive to false).
 */
export async function DELETE(
  _request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    // Check if program exists
    const existingProgram = await db.skillProgram.findUnique({ where: { id } });
    if (!existingProgram) {
      return NextResponse.json(
        { خطا: 'دوره مهارتی مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Soft delete: set isActive to false
    await db.skillProgram.update({
      where: { id },
      data: { isActive: false },
    });

    return NextResponse.json({
      پیام: 'دوره مهارتی با موفقیت غیرفعال شد',
    });
  } catch (error) {
    console.error('CRM skill-program delete error:', error);
    return NextResponse.json(
      { خطا: 'خطا در غیرفعال‌سازی دوره مهارتی' },
      { status: 500 }
    );
  }
}
