import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/sales-targets — List sales targets with progress
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const statusFilter = searchParams.get('status');

    const where: Record<string, unknown> = {};
    if (statusFilter) {
      where.status = statusFilter;
    } else {
      // By default return all (ACTIVE + COMPLETED + CANCELLED)
    }

    const targets = await db.salesTarget.findMany({
      where,
      orderBy: { endDate: 'asc' },
    });

    // Auto-calculate actuals for each target
    const results = await Promise.all(targets.map(async (target) => {
      const [revenue, enrollments, leads] = await Promise.all([
        db.payment.aggregate({
          where: { status: 'PAID', paidAt: { gte: target.startDate, lte: target.endDate } },
          _sum: { amount: true },
        }),
        db.lead.count({
          where: { stage: 'ENROLLED', createdAt: { gte: target.startDate, lte: target.endDate } },
        }),
        db.lead.count({
          where: { createdAt: { gte: target.startDate, lte: target.endDate } },
        }),
      ]);

      const actualRevenue = revenue._sum.amount || 0;

      // Update actuals if changed
      if (actualRevenue !== target.actualRevenue || enrollments !== target.actualEnrollments || leads !== target.actualLeads) {
        await db.salesTarget.update({
          where: { id: target.id },
          data: { actualRevenue, actualEnrollments: enrollments, actualLeads: leads },
        });
      }

      return {
        ...target,
        actualRevenue,
        actualEnrollments: enrollments,
        actualLeads: leads,
        revenueProgress: target.targetRevenue > 0 ? Math.round((actualRevenue / target.targetRevenue) * 100) : 0,
        enrollmentProgress: target.targetEnrollments > 0 ? Math.round((enrollments / target.targetEnrollments) * 100) : 0,
        leadsProgress: target.targetLeads > 0 ? Math.round((leads / target.targetLeads) * 100) : 0,
      };
    }));

    return NextResponse.json({ پیام: 'اهداف فروش دریافت شد', داده‌ها: results });
  } catch (error) {
    console.error('Sales targets error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت اهداف' }, { status: 500 });
  }
}

/**
 * POST /api/crm/sales-targets — Create sales target
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, period, startDate, endDate, assignedTo, targetRevenue, targetEnrollments, targetLeads } = body;

    if (!title || !period || !startDate || !endDate) {
      return NextResponse.json({ خطا: 'عنوان، دوره، تاریخ شروع و پایان الزامی است' }, { status: 400 });
    }

    const target = await db.salesTarget.create({
      data: {
        title,
        period,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        assignedTo: assignedTo || '',
        targetRevenue: targetRevenue || 0,
        targetEnrollments: targetEnrollments || 0,
        targetLeads: targetLeads || 0,
      },
    });

    return NextResponse.json({ پیام: 'هدف فروش ایجاد شد', داده: target }, { status: 201 });
  } catch (error) {
    console.error('Sales target creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت هدف' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/sales-targets — Update target
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { targetId, status, targetRevenue, targetEnrollments, targetLeads } = body;

    if (!targetId) return NextResponse.json({ خطا: 'شناسه هدف الزامی است' }, { status: 400 });

    const updateData: Record<string, unknown> = {};
    if (status) updateData.status = status;
    if (targetRevenue !== undefined) updateData.targetRevenue = targetRevenue;
    if (targetEnrollments !== undefined) updateData.targetEnrollments = targetEnrollments;
    if (targetLeads !== undefined) updateData.targetLeads = targetLeads;

    const updated = await db.salesTarget.update({ where: { id: targetId }, data: updateData });
    return NextResponse.json({ پیام: 'هدف به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Sales target update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی هدف' }, { status: 500 });
  }
}
