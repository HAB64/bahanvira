import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/conversations — List conversations with filters
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const channel = searchParams.get('channel');
    const status = searchParams.get('status');
    const leadId = searchParams.get('leadId');
    const karAmuzId = searchParams.get('karAmuzId');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (channel) where.channel = channel;
    if (status) where.status = status;
    if (leadId) where.leadId = leadId;
    if (karAmuzId) where.karAmuzId = karAmuzId;
    if (search) {
      where.OR = [
        { subject: { contains: search, mode: 'insensitive' } },
        { summary: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [conversations, total] = await Promise.all([
      db.conversation.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          lead: { select: { id: true, name: true, phone: true } },
          karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
          _count: { select: { messages: true } },
        },
      }),
      db.conversation.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست مکالمات با موفقیت دریافت شد',
      داده‌ها: conversations,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Conversations list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت مکالمات' }, { status: 500 });
  }
}

/**
 * POST /api/crm/conversations — Create conversation
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      leadId, karAmuzId, channel, subject, summary, sentiment,
      keyTopics, actionItems, durationSec, startedAt, endedAt, status,
    } = body;

    const conversation = await db.conversation.create({
      data: {
        leadId: leadId || null,
        karAmuzId: karAmuzId || null,
        channel: channel || 'PHONE',
        subject: subject || null,
        summary: summary || null,
        sentiment: sentiment || null,
        keyTopics: keyTopics || null,
        actionItems: actionItems || null,
        durationSec: durationSec ?? null,
        startedAt: startedAt ? new Date(startedAt) : new Date(),
        endedAt: endedAt ? new Date(endedAt) : null,
        status: status || 'ACTIVE',
      },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    return NextResponse.json({ پیام: 'مکالمه با موفقیت ایجاد شد', داده: conversation }, { status: 201 });
  } catch (error) {
    console.error('Conversation creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت مکالمه' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/conversations — Update conversation status, add AI summary
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { conversationId, status, summary, sentiment, keyTopics, actionItems, endedAt } = body;

    if (!conversationId) {
      return NextResponse.json({ خطا: 'شناسه مکالمه الزامی است' }, { status: 400 });
    }

    const existing = await db.conversation.findUnique({ where: { id: conversationId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'مکالمه یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};

    if (status) {
      const validStatuses = ['ACTIVE', 'COMPLETED', 'ARCHIVED'];
      if (!validStatuses.includes(status)) {
        return NextResponse.json({ خطا: `وضعیت نامعتبر. مقادیر مجاز: ${validStatuses.join(', ')}` }, { status: 400 });
      }
      updateData.status = status;
      if (status === 'COMPLETED' && !existing.endedAt) {
        updateData.endedAt = new Date();
      }
    }
    if (summary !== undefined) updateData.summary = summary;
    if (sentiment !== undefined) updateData.sentiment = sentiment;
    if (keyTopics !== undefined) updateData.keyTopics = keyTopics;
    if (actionItems !== undefined) updateData.actionItems = actionItems;
    if (endedAt !== undefined) updateData.endedAt = endedAt ? new Date(endedAt) : null;

    const updated = await db.conversation.update({
      where: { id: conversationId },
      data: updateData,
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
        _count: { select: { messages: true } },
      },
    });

    return NextResponse.json({ پیام: 'مکالمه با موفقیت به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Conversation update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی مکالمه' }, { status: 500 });
  }
}
