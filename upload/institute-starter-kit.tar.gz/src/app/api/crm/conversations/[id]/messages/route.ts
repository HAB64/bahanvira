import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/conversations/[id]/messages — List messages for conversation
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const speaker = searchParams.get('speaker');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '50', 10)));
    const skip = (page - 1) * limit;

    const conversation = await db.conversation.findUnique({ where: { id } });
    if (!conversation) {
      return NextResponse.json({ خطا: 'مکالمه یافت نشد' }, { status: 404 });
    }

    const where: Record<string, unknown> = { conversationId: id };
    if (speaker) where.speaker = speaker;

    const [messages, total] = await Promise.all([
      db.conversationMessage.findMany({
        where, skip, take: limit,
        orderBy: { timestamp: 'asc' },
      }),
      db.conversationMessage.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست پیام‌ها با موفقیت دریافت شد',
      داده‌ها: messages,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Conversation messages list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت پیام‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/conversations/[id]/messages — Add message to conversation
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { content, speaker, speakerName, aiSuggestion, aiConfidence, metadata } = body;

    if (!content) {
      return NextResponse.json({ خطا: 'محتوای پیام الزامی است' }, { status: 400 });
    }

    const conversation = await db.conversation.findUnique({ where: { id } });
    if (!conversation) {
      return NextResponse.json({ خطا: 'مکالمه یافت نشد' }, { status: 404 });
    }

    const message = await db.conversationMessage.create({
      data: {
        conversationId: id,
        content,
        speaker: speaker || 'CUSTOMER',
        speakerName: speakerName || null,
        aiSuggestion: aiSuggestion || null,
        aiConfidence: aiConfidence ?? null,
        timestamp: new Date(),
        metadata: metadata || null,
      },
    });

    return NextResponse.json({ پیام: 'پیام با موفقیت اضافه شد', داده: message }, { status: 201 });
  } catch (error) {
    console.error('Conversation message creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت پیام' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/conversations/[id]/messages — Update message (for AI suggestions)
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { messageId, content, aiSuggestion, aiConfidence, metadata } = body;

    if (!messageId) {
      return NextResponse.json({ خطا: 'شناسه پیام الزامی است' }, { status: 400 });
    }

    const existing = await db.conversationMessage.findFirst({
      where: { id: messageId, conversationId: id },
    });
    if (!existing) {
      return NextResponse.json({ خطا: 'پیام یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};
    if (content !== undefined) updateData.content = content;
    if (aiSuggestion !== undefined) updateData.aiSuggestion = aiSuggestion;
    if (aiConfidence !== undefined) updateData.aiConfidence = aiConfidence;
    if (metadata !== undefined) updateData.metadata = metadata;

    const updated = await db.conversationMessage.update({
      where: { id: messageId },
      data: updateData,
    });

    return NextResponse.json({ پیام: 'پیام با موفقیت به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Conversation message update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی پیام' }, { status: 500 });
  }
}
