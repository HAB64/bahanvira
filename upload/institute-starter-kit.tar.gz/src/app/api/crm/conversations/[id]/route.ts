import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/conversations/[id] — Get single conversation with messages
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const messageLimit = Math.min(100, Math.max(1, parseInt(searchParams.get('messageLimit') || '50', 10)));

    const conversation = await db.conversation.findUnique({
      where: { id },
      include: {
        lead: { select: { id: true, name: true, phone: true, email: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true, email: true } },
        messages: {
          orderBy: { timestamp: 'asc' },
          take: messageLimit,
        },
      },
    });

    if (!conversation) {
      return NextResponse.json({ خطا: 'مکالمه یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ پیام: 'مکالمه با موفقیت دریافت شد', داده: conversation });
  } catch (error) {
    console.error('Conversation get error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت مکالمه' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/conversations/[id] — Update conversation
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const existing = await db.conversation.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ خطا: 'مکالمه یافت نشد' }, { status: 404 });
    }

    const allowedFields = [
      'channel', 'subject', 'summary', 'sentiment', 'keyTopics', 'actionItems',
      'durationSec', 'startedAt', 'endedAt', 'status', 'leadId', 'karAmuzId',
    ];

    const updateData: Record<string, unknown> = {};
    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        if (field === 'startedAt' || field === 'endedAt') {
          updateData[field] = body[field] ? new Date(body[field]) : null;
        } else if (field === 'status') {
          const validStatuses = ['ACTIVE', 'COMPLETED', 'ARCHIVED'];
          if (!validStatuses.includes(body[field])) {
            return NextResponse.json({ خطا: `وضعیت نامعتبر. مقادیر مجاز: ${validStatuses.join(', ')}` }, { status: 400 });
          }
          updateData.status = body[field];
          if (body[field] === 'COMPLETED' && !existing.endedAt) {
            updateData.endedAt = new Date();
          }
        } else {
          updateData[field] = body[field];
        }
      }
    }

    const updated = await db.conversation.update({
      where: { id },
      data: updateData,
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
        _count: { select: { messages: true } },
      },
    });

    return NextResponse.json({ پیام: 'مکالمه با موفقیت به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Conversation update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی مکالمه' }, { status: 500 });
  }
}
