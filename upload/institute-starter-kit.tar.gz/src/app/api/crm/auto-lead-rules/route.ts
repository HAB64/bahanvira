import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/auto-lead-rules — List auto lead rules
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const source = searchParams.get('source');
    const isActive = searchParams.get('isActive');

    const where: Record<string, unknown> = {};
    if (source) where.source = source;
    if (isActive !== null && isActive !== undefined) where.isActive = isActive === 'true';

    const rules = await db.autoLeadRule.findMany({
      where,
      orderBy: [{ priority: 'desc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json({
      پیام: 'لیست قوانین تشخیص خودکار با موفقیت دریافت شد',
      داده‌ها: rules,
    });
  } catch (error) {
    console.error('Auto lead rules list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت قوانین' }, { status: 500 });
  }
}

/**
 * POST /api/crm/auto-lead-rules — Create a new auto lead rule
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, source, conditions, actions, isActive, priority } = body;

    if (!name || !conditions || !actions) {
      return NextResponse.json({ خطا: 'نام، شروط و اقدامات الزامی است' }, { status: 400 });
    }

    const rule = await db.autoLeadRule.create({
      data: {
        name,
        description: description || null,
        source: source || 'WEB_FORM',
        conditions,
        actions,
        isActive: isActive !== undefined ? isActive : true,
        priority: priority || 0,
      },
    });

    return NextResponse.json({ پیام: 'قانون با موفقیت ایجاد شد', داده: rule }, { status: 201 });
  } catch (error) {
    console.error('Auto lead rule create error:', error);
    return NextResponse.json({ خطا: 'خطا در ایجاد قانون' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/auto-lead-rules — Update an auto lead rule
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { ruleId, name, description, source, conditions, actions, isActive, priority } = body;

    if (!ruleId) {
      return NextResponse.json({ خطا: 'شناسه قانون الزامی است' }, { status: 400 });
    }

    const existing = await db.autoLeadRule.findUnique({ where: { id: ruleId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'قانون یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};
    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (source !== undefined) updateData.source = source;
    if (conditions !== undefined) updateData.conditions = conditions;
    if (actions !== undefined) updateData.actions = actions;
    if (isActive !== undefined) updateData.isActive = isActive;
    if (priority !== undefined) updateData.priority = priority;

    const updated = await db.autoLeadRule.update({
      where: { id: ruleId },
      data: updateData,
    });

    return NextResponse.json({ پیام: 'قانون به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Auto lead rule update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی قانون' }, { status: 500 });
  }
}

/**
 * DELETE /api/crm/auto-lead-rules — Delete an auto lead rule
 * Body: { ruleId: string }
 */
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json();
    const { ruleId } = body;

    if (!ruleId) {
      return NextResponse.json({ خطا: 'شناسه قانون الزامی است' }, { status: 400 });
    }

    const existing = await db.autoLeadRule.findUnique({ where: { id: ruleId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'قانون یافت نشد' }, { status: 404 });
    }

    await db.autoLeadRule.delete({ where: { id: ruleId } });

    return NextResponse.json({ پیام: 'قانون با موفقیت حذف شد' });
  } catch (error) {
    console.error('Auto lead rule delete error:', error);
    return NextResponse.json({ خطا: 'خطا در حذف قانون' }, { status: 500 });
  }
}
