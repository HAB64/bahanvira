import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

import { getAdminSession } from '@/lib/admin-auth';
const prisma = new PrismaClient();

/**
 * GET /api/crm/performance
 * Consultant performance metrics: conversion rates, activity counts, response times.
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    // Get all leads grouped by assignedTo
    const leads = await prisma.lead.findMany({
      select: {
        id: true,
        assignedTo: true,
        stage: true,
        score: true,
        createdAt: true,
        lastContactedAt: true,
        activityLogs: {
          select: {
            type: true,
            createdAt: true,
          },
          orderBy: { createdAt: 'asc' },
        },
      },
    });

    // Group by consultant
    const consultantMap: Record<
      string,
      {
        consultantId: string;
        totalLeads: number;
        newLeads: number;
        contacted: number;
        interested: number;
        enrolled: number;
        rejected: number;
        archived: number;
        conversionRate: number;
        avgScore: number;
        totalActivities: number;
        callCount: number;
        whatsappCount: number;
        smsCount: number;
        avgResponseHours: number;
      }
    > = {};

    for (const lead of leads) {
      const key = lead.assignedTo || 'unassigned';

      if (!consultantMap[key]) {
        consultantMap[key] = {
          consultantId: key,
          totalLeads: 0,
          newLeads: 0,
          contacted: 0,
          interested: 0,
          enrolled: 0,
          rejected: 0,
          archived: 0,
          conversionRate: 0,
          avgScore: 0,
          totalActivities: 0,
          callCount: 0,
          whatsappCount: 0,
          smsCount: 0,
          avgResponseHours: 0,
        };
      }

      const c = consultantMap[key];
      c.totalLeads++;

      // Stage counts
      if (lead.stage === 'NEW') c.newLeads++;
      else if (lead.stage === 'CONTACTED') c.contacted++;
      else if (lead.stage === 'INTERESTED') c.interested++;
      else if (lead.stage === 'ENROLLED') c.enrolled++;
      else if (lead.stage === 'REJECTED') c.rejected++;
      else if (lead.stage === 'ARCHIVED') c.archived++;

      // Score sum
      c.avgScore += lead.score;

      // Activity counts
      c.totalActivities += lead.activityLogs.length;
      for (const log of lead.activityLogs) {
        if (log.type === 'CALL') c.callCount++;
        else if (log.type === 'WHATSAPP') c.whatsappCount++;
        else if (log.type === 'SMS') c.smsCount++;
      }
    }

    // Calculate averages and conversion rates
    for (const key of Object.keys(consultantMap)) {
      const c = consultantMap[key];
      c.conversionRate = c.totalLeads > 0 ? Math.round((c.enrolled / c.totalLeads) * 100) : 0;
      c.avgScore = c.totalLeads > 0 ? Math.round(c.avgScore / c.totalLeads) : 0;
    }

    // Overall funnel stats
    const totalLeads = leads.length;
    const funnelStats = {
      total: totalLeads,
      new: leads.filter((l) => l.stage === 'NEW').length,
      contacted: leads.filter((l) => l.stage === 'CONTACTED').length,
      interested: leads.filter((l) => l.stage === 'INTERESTED').length,
      enrolled: leads.filter((l) => l.stage === 'ENROLLED').length,
      rejected: leads.filter((l) => l.stage === 'REJECTED').length,
      archived: leads.filter((l) => l.stage === 'ARCHIVED').length,
      overallConversionRate: totalLeads > 0 ? Math.round((leads.filter((l) => l.stage === 'ENROLLED').length / totalLeads) * 100) : 0,
    };

    // Source breakdown
    const sourceBreakdown: Record<string, number> = {};
    for (const lead of leads) {
      const src = (lead as { assignedTo?: string } & { _source?: string }).assignedTo || 'unknown';
      // We need source field - let's re-query
    }

    // Actually let's get source stats properly
    const sourceStats = await prisma.lead.groupBy({
      by: ['source'],
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
    });

    return NextResponse.json({
      پیام: 'آمار عملکرد با موفقیت دریافت شد',
      داده: {
        مشاوران: Object.values(consultantMap).sort((a, b) => b.conversionRate - a.conversionRate),
        قیف_کلی: funnelStats,
        منابع: sourceStats.map((s) => ({
          منبع: s.source,
          تعداد: s._count.id,
        })),
      },
    });
  } catch (error) {
    console.error('Performance stats error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت آمار عملکرد' },
      { status: 500 }
    );
  }
}
