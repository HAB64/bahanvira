import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/attendances
 * List attendances with optional filters.
 * Query params: karAmuzId, sessionId, skillProgramId (filter by session's skillProgram), status, dateFrom, dateTo
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const karAmuzId = searchParams.get('karAmuzId');
    const sessionId = searchParams.get('sessionId');
    const skillProgramId = searchParams.get('skillProgramId');
    const status = searchParams.get('status');
    const dateFrom = searchParams.get('dateFrom');
    const dateTo = searchParams.get('dateTo');

    const where: Record<string, unknown> = {};

    if (karAmuzId) {
      where.karAmuzId = karAmuzId;
    }

    if (sessionId) {
      where.sessionId = sessionId;
    }

    if (status) {
      where.status = status;
    }

    // Filter by session's skillProgram
    if (skillProgramId) {
      where.session = {
        skillProgramId,
      };
    }

    // Filter by session date range
    if (dateFrom || dateTo) {
      const sessionWhere: Record<string, unknown> = {
        ...(where.session as Record<string, unknown> || {}),
        date: {
          ...(dateFrom && { gte: new Date(dateFrom) }),
          ...(dateTo && { lte: new Date(dateTo) }),
        },
      };
      where.session = sessionWhere;
    }

    const attendances = await db.attendance.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
          },
        },
        session: {
          select: {
            id: true,
            skillProgramId: true,
            date: true,
            startTime: true,
            endTime: true,
            title: true,
            type: true,
            instructorName: true,
            skillProgram: {
              select: {
                id: true,
                name: true,
                code: true,
              },
            },
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'لیست حضور و غیاب با موفقیت دریافت شد',
      داده‌ها: attendances,
    });
  } catch (error) {
    console.error('Attendances list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست حضور و غیاب' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/attendances
 * Record attendance for a KarAmuz in a session.
 * Required: karAmuzId, sessionId, status
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { karAmuzId, sessionId, status, hours, notes } = body;

    // Validate required fields
    if (!karAmuzId || !sessionId || !status) {
      return NextResponse.json(
        { خطا: 'شناسه کارآموز، شناسه جلسه و وضعیت حضور الزامی است' },
        { status: 400 }
      );
    }

    // Validate status value
    const validStatuses = ['PRESENT', 'ABSENT', 'LATE', 'EXCUSED'];
    if (!validStatuses.includes(status)) {
      return NextResponse.json(
        { خطا: `وضعیت حضور نامعتبر است. مقادیر مجاز: ${validStatuses.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate that karAmuzId exists
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز یافت نشد' },
        { status: 404 }
      );
    }

    // Validate that session exists and get its skillProgramId
    const session = await db.session.findUnique({
      where: { id: sessionId },
    });

    if (!session) {
      return NextResponse.json(
        { خطا: 'جلسه یافت نشد' },
        { status: 404 }
      );
    }

    // Validate that the karAmuz is enrolled in the session's skillProgram
    const enrollment = await db.enrollment.findUnique({
      where: {
        karAmuzId_skillProgramId: {
          karAmuzId,
          skillProgramId: session.skillProgramId,
        },
      },
    });

    if (!enrollment) {
      return NextResponse.json(
        { خطا: 'کارآموز در برنامه مهارتی این جلسه ثبت‌نام نکرده است' },
        { status: 400 }
      );
    }

    if (enrollment.status !== 'ENROLLED') {
      return NextResponse.json(
        { خطا: 'وضعیت ثبت‌نام کارآموز فعال نیست' },
        { status: 400 }
      );
    }

    // Check unique constraint (karAmuzId+sessionId)
    const existing = await db.attendance.findUnique({
      where: {
        karAmuzId_sessionId: {
          karAmuzId,
          sessionId,
        },
      },
    });

    if (existing) {
      return NextResponse.json(
        { خطا: 'قبلاً برای این کارآموز در این جلسه حضور و غیاب ثبت شده است' },
        { status: 409 }
      );
    }

    // Create attendance (default hours to 0 if not provided)
    const attendance = await db.attendance.create({
      data: {
        karAmuzId,
        sessionId,
        status,
        hours: hours !== undefined ? Number(hours) : 0,
        notes: notes || null,
      },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
          },
        },
        session: {
          select: {
            id: true,
            skillProgramId: true,
            date: true,
            startTime: true,
            endTime: true,
            title: true,
            type: true,
            instructorName: true,
            skillProgram: {
              select: {
                id: true,
                name: true,
                code: true,
              },
            },
          },
        },
      },
    });

    return NextResponse.json(
      {
        پیام: 'حضور و غیاب با موفقیت ثبت شد',
        داده: attendance,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Attendance creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت حضور و غیاب' },
      { status: 500 }
    );
  }
}
