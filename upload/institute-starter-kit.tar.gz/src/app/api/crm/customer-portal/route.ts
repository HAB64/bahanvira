import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { randomBytes, createHash } from 'crypto';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/customer-portal — List portal users
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const users = await db.customerPortalUser.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    // Stats
    const [activeCount, recentLogin] = await Promise.all([
      db.customerPortalUser.count({ where: { isActive: true } }),
      db.customerPortalUser.findFirst({
        where: { lastLoginAt: { not: null } },
        orderBy: { lastLoginAt: 'desc' },
        select: { lastLoginAt: true },
      }),
    ]);

    // Monthly signups this month
    const thisMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const monthlySignups = await db.customerPortalUser.count({
      where: { createdAt: { gte: thisMonth } },
    });

    return NextResponse.json({
      پیام: 'لیست کاربران پورتال با موفقیت دریافت شد',
      داده‌ها: users,
      آمار: {
        کاربران_فعال: activeCount,
        آخرین_ورود: recentLogin?.lastLoginAt || null,
        ثبت‌نام_ماهانه: monthlySignups,
      },
    });
  } catch (error) {
    console.error('Customer portal list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت کاربران' }, { status: 500 });
  }
}

/**
 * POST /api/crm/customer-portal — Create portal user
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { leadId, karAmuzId, username, password } = body;

    if (!username || !password) {
      return NextResponse.json({ خطا: 'نام کاربری و رمز عبور الزامی است' }, { status: 400 });
    }

    // Check username uniqueness
    const existing = await db.customerPortalUser.findUnique({ where: { username } });
    if (existing) {
      return NextResponse.json({ خطا: 'نام کاربری تکراری است' }, { status: 400 });
    }

    // Hash password
    const passwordHash = createHash('sha256').update(password).digest('hex');

    const user = await db.customerPortalUser.create({
      data: {
        leadId: leadId || null,
        karAmuzId: karAmuzId || null,
        username,
        passwordHash,
        isActive: true,
      },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    // Remove passwordHash from response
    const { passwordHash: _, ...safeUser } = user;

    return NextResponse.json({ پیام: 'کاربر پورتال با موفقیت ایجاد شد', داده: safeUser }, { status: 201 });
  } catch (error) {
    console.error('Customer portal create error:', error);
    return NextResponse.json({ خطا: 'خطا در ایجاد کاربر' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/customer-portal — Toggle active/inactive
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, isActive } = body;

    if (!userId) {
      return NextResponse.json({ خطا: 'شناسه کاربر الزامی است' }, { status: 400 });
    }

    const existing = await db.customerPortalUser.findUnique({ where: { id: userId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'کاربر یافت نشد' }, { status: 404 });
    }

    const updated = await db.customerPortalUser.update({
      where: { id: userId },
      data: { isActive: isActive !== undefined ? isActive : !existing.isActive },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    const { passwordHash: _, ...safeUser } = updated;

    return NextResponse.json({ پیام: 'وضعیت کاربر به‌روزرسانی شد', داده: safeUser });
  } catch (error) {
    console.error('Customer portal update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی' }, { status: 500 });
  }
}
