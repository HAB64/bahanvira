import { NextRequest, NextResponse } from 'next/server';
import { sendUnifiedMessage, sendMultiChannel, getMessageStats, type MessagingChannel } from '@/lib/crm/messaging-unified';

/**
 * POST /api/crm/messaging
 * ارسال پیام از طریق کانال مشخص‌شده
 *
 * Body:
 *   channel: 'SMS' | 'WHATSAPP' | 'EITAA' | 'BALEH' | 'EMAIL' | 'TELEGRAM'
 *   channels?: string[]  (برای ارسال چندکاناله)
 *   recipient: string
 *   content: string
 *   subject?: string
 *   leadId?: string
 *   karAmuzId?: string
 *   campaignId?: string
 *   keyboardButtons?: string[][]
 *   inlineButtons?: Array<{ text: string; callbackData: string }[]>
 *   mediaUrl?: string
 *   recipientName?: string
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // اعتبارسنجی
    if (!body.content) {
      return NextResponse.json(
        { خطا: 'محتوای پیام الزامی است' },
        { status: 400 }
      );
    }

    // ارسال چندکاناله
    if (body.channels && Array.isArray(body.channels)) {
      const results = await sendMultiChannel({
        channels: body.channels as MessagingChannel[],
        recipient: body.recipient || '',
        content: body.content,
        subject: body.subject,
        leadId: body.leadId,
        karAmuzId: body.karAmuzId,
        campaignId: body.campaignId,
        keyboardButtons: body.keyboardButtons,
        inlineButtons: body.inlineButtons,
        mediaUrl: body.mediaUrl,
        recipientName: body.recipientName,
        metadata: body.metadata,
      });

      return NextResponse.json({
        پیام: 'پیام‌ها ارسال شدند',
        نتایج: results,
        تعداد_موفق: results.filter(r => r.success).length,
        تعداد_ناموفق: results.filter(r => !r.success).length,
      });
    }

    // ارسال تک‌کاناله
    if (!body.channel) {
      return NextResponse.json(
        { خطا: 'کانال ارسال الزامی است (SMS, WHATSAPP, EITAA, BALEH, EMAIL, TELEGRAM)' },
        { status: 400 }
      );
    }

    if (!body.recipient) {
      return NextResponse.json(
        { خطا: 'شناسه گیرنده الزامی است' },
        { status: 400 }
      );
    }

    const result = await sendUnifiedMessage({
      channel: body.channel as MessagingChannel,
      recipient: body.recipient,
      content: body.content,
      subject: body.subject,
      leadId: body.leadId,
      karAmuzId: body.karAmuzId,
      campaignId: body.campaignId,
      keyboardButtons: body.keyboardButtons,
      inlineButtons: body.inlineButtons,
      mediaUrl: body.mediaUrl,
      recipientName: body.recipientName,
      metadata: body.metadata,
    });

    return NextResponse.json({
      پیام: result.success ? 'پیام با موفقیت ارسال شد' : 'خطا در ارسال پیام',
      موفق: result.success,
      شناسه_لاگ: result.messageLogId,
      کانال: result.channel,
      شناسه_خارجی: result.externalId,
      خطا: result.error,
    });

  } catch (error) {
    console.error('[Messaging API Error]', error);
    return NextResponse.json(
      { خطا: 'خطا در پردازش درخواست پیام‌رسانی' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/crm/messaging
 * دریافت آمار پیام‌ها
 *
 * Query params:
 *   startDate?: ISO date
 *   endDate?: ISO date
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const startDate = searchParams.get('startDate') ? new Date(searchParams.get('startDate')!) : undefined;
    const endDate = searchParams.get('endDate') ? new Date(searchParams.get('endDate')!) : undefined;

    const stats = await getMessageStats(startDate, endDate);

    return NextResponse.json({
      پیام: 'آمار پیام‌ها',
      داده‌ها: stats,
    });
  } catch (error) {
    console.error('[Messaging Stats API Error]', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت آمار پیام‌ها' },
      { status: 500 }
    );
  }
}
