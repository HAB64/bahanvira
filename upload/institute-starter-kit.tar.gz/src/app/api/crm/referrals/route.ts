import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/referrals
 * لیست معرف‌ها با فیلتر
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const referrerId = searchParams.get('referrerId');
    const status = searchParams.get('status');
    const source = searchParams.get('source');
    const referrerCode = searchParams.get('referrerCode');
    const dateFrom = searchParams.get('dateFrom');
    const dateTo = searchParams.get('dateTo');
    const search = searchParams.get('search');

    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (referrerId) {
      where.referrerId = referrerId;
    }

    if (status) {
      where.status = status;
    }

    if (source) {
      where.source = source;
    }

    if (referrerCode) {
      where.referrerCode = referrerCode;
    }

    if (dateFrom || dateTo) {
      where.createdAt = {
        ...(dateFrom && { gte: new Date(dateFrom) }),
        ...(dateTo && { lte: new Date(dateTo) }),
      };
    }

    if (search) {
      where.OR = [
        { refName: { contains: search, mode: 'insensitive' } },
        { refPhone: { contains: search } },
        { refEmail: { contains: search, mode: 'insensitive' } },
        { enrolledCourse: { contains: search, mode: 'insensitive' } },
        { referrerCode: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [referrals, total] = await Promise.all([
      db.referral.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          referrer: {
            select: {
              id: true,
              code: true,
              firstName: true,
              lastName: true,
              phone: true,
            },
          },
          lead: {
            select: { id: true, name: true, phone: true, stage: true },
          },
          commissions: {
            select: { id: true, commissionAmount: true, status: true },
          },
        },
      }),
      db.referral.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست معرف‌ها با موفقیت دریافت شد',
      داده‌ها: referrals,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Referrals list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست معرف‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/referrals
 * ایجاد معرف جدید (از اسکن QR، لینک معرف یا دستی)
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      referrerId,
      referrerCode,
      refName,
      refPhone,
      refEmail,
      source,
      leadId,
    } = body;

    if (!refName || !refPhone) {
      return NextResponse.json(
        { خطا: 'نام و شماره تلفن شخص معرفی‌شده الزامی است' },
        { status: 400 }
      );
    }

    // یافتن معرف
    let referrer;
    if (referrerId) {
      referrer = await db.referrer.findUnique({ where: { id: referrerId } });
    } else if (referrerCode) {
      referrer = await db.referrer.findUnique({ where: { code: referrerCode } });
    }

    if (!referrer) {
      return NextResponse.json(
        { خطا: 'معرف مورد نظر یافت نشد. شناسه یا کد معرف را بررسی کنید' },
        { status: 404 }
      );
    }

    if (!referrer.isActive || referrer.status !== 'ACTIVE') {
      return NextResponse.json(
        { خطا: 'معرف غیرفعال یا معلق است و امکان معرفی جدید وجود ندارد' },
        { status: 400 }
      );
    }

    const referral = await db.referral.create({
      data: {
        referrerId: referrer.id,
        leadId: leadId || null,
        refName,
        refPhone,
        refEmail: refEmail || null,
        source: source || 'MANUAL',
        referrerCode: referrer.code,
        status: 'PENDING',
      },
    });

    // به‌روزرسانی آمار معرف
    await db.referrer.update({
      where: { id: referrer.id },
      data: {
        totalReferrals: { increment: 1 },
      },
    });

    // به‌روزرسانی لید
    if (leadId) {
      await db.lead.update({
        where: { id: leadId },
        data: {
          referredByCode: referrer.code,
          referrerId: referrer.id,
        },
      }).catch(() => {
        // اگر لید وجود نداشت، نادیده بگیر
      });
    }

    return NextResponse.json(
      {
        پیام: 'معرف با موفقیت ایجاد شد',
        داده: referral,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Referral creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت معرف جدید' },
      { status: 500 }
    );
  }
}
