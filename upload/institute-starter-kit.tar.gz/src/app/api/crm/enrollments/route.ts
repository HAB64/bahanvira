import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/enrollments
 * List enrollments with optional filters.
 * Query params: karAmuzId, skillProgramId, status
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const karAmuzId = searchParams.get('karAmuzId');
    const skillProgramId = searchParams.get('skillProgramId');
    const status = searchParams.get('status');

    const where: Record<string, unknown> = {};

    if (karAmuzId) {
      where.karAmuzId = karAmuzId;
    }

    if (skillProgramId) {
      where.skillProgramId = skillProgramId;
    }

    if (status) {
      where.status = status;
    }

    const enrollments = await db.enrollment.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
            status: true,
          },
        },
        skillProgram: {
          select: {
            id: true,
            name: true,
            code: true,
            totalHours: true,
            capacity: true,
            isActive: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'لیست ثبت‌نام‌ها با موفقیت دریافت شد',
      داده‌ها: enrollments,
    });
  } catch (error) {
    console.error('Enrollments list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست ثبت‌نام‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/enrollments
 * Create enrollment (register a KarAmuz in a SkillProgram).
 * Required: karAmuzId, skillProgramId
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { karAmuzId, skillProgramId, status } = body;

    // Validate required fields
    if (!karAmuzId || !skillProgramId) {
      return NextResponse.json(
        { خطا: 'شناسه کارآموز و برنامه مهارتی الزامی است' },
        { status: 400 }
      );
    }

    // Check that karAmuzId exists and is ACTIVE
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز یافت نشد' },
        { status: 404 }
      );
    }

    if (karAmuz.status !== 'ACTIVE') {
      return NextResponse.json(
        { خطا: 'کارآموز در وضعیت فعال نیست. وضعیت فعلی: ' + karAmuz.status },
        { status: 400 }
      );
    }

    // Check that skillProgramId exists and is active
    const skillProgram = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
    });

    if (!skillProgram) {
      return NextResponse.json(
        { خطا: 'برنامه مهارتی یافت نشد' },
        { status: 404 }
      );
    }

    if (!skillProgram.isActive) {
      return NextResponse.json(
        { خطا: 'برنامه مهارتی فعال نیست' },
        { status: 400 }
      );
    }

    // Check for duplicate enrollment (unique constraint on karAmuzId+skillProgramId)
    const existing = await db.enrollment.findUnique({
      where: {
        karAmuzId_skillProgramId: {
          karAmuzId,
          skillProgramId,
        },
      },
    });

    if (existing) {
      return NextResponse.json(
        { خطا: 'این کارآموز قبلاً در این برنامه مهارتی ثبت‌نام کرده است' },
        { status: 409 }
      );
    }

    // Check capacity: count existing ENROLLED enrollments
    if (skillProgram.capacity) {
      const enrolledCount = await db.enrollment.count({
        where: {
          skillProgramId,
          status: 'ENROLLED',
        },
      });

      if (enrolledCount >= skillProgram.capacity) {
        return NextResponse.json(
          { خطا: `ظرفیت برنامه مهارتی تکمیل شده است (${enrolledCount}/${skillProgram.capacity})` },
          { status: 400 }
        );
      }
    }

    // Create enrollment
    const enrollment = await db.enrollment.create({
      data: {
        karAmuzId,
        skillProgramId,
        status: status || 'ENROLLED',
      },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
            status: true,
          },
        },
        skillProgram: {
          select: {
            id: true,
            name: true,
            code: true,
            totalHours: true,
            capacity: true,
            isActive: true,
          },
        },
      },
    });

    return NextResponse.json(
      {
        پیام: 'ثبت‌نام با موفقیت انجام شد',
        داده: enrollment,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Enrollment creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت‌نام کارآموز' },
      { status: 500 }
    );
  }
}
