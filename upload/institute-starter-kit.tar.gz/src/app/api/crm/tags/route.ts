import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

import { getAdminSession } from '@/lib/admin-auth';
const prisma = new PrismaClient();

/**
 * GET /api/crm/tags
 * List all tags with their lead counts.
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const tags = await prisma.tag.findMany({
      include: {
        _count: {
          select: { leads: true },
        },
      },
      orderBy: { name: 'asc' },
    });

    return NextResponse.json({
      پیام: 'لیست برچسب‌ها با موفقیت دریافت شد',
      داده‌ها: tags,
    });
  } catch (error) {
    console.error('CRM tags list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست برچسب‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/tags
 * Create a new tag.
 * Body: { name, color? }
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, color } = body;

    // Validate required fields
    if (!name || !name.trim()) {
      return NextResponse.json(
        { خطا: 'نام برچسب الزامی است' },
        { status: 400 }
      );
    }

    const tagName = name.trim();

    // Check if tag already exists
    const existingTag = await prisma.tag.findUnique({
      where: { name: tagName },
    });

    if (existingTag) {
      return NextResponse.json(
        { خطا: 'برچسب با این نام قبلاً وجود دارد' },
        { status: 409 }
      );
    }

    const tag = await prisma.tag.create({
      data: {
        name: tagName,
        color: color || '#0d9488',
      },
    });

    return NextResponse.json(
      {
        پیام: 'برچسب با موفقیت ایجاد شد',
        داده: tag,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('CRM tag creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ایجاد برچسب' },
      { status: 500 }
    );
  }
}
