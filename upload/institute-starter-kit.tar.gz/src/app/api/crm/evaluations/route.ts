import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/evaluations
 * List evaluations with optional filters.
 * Query params: karAmuzId, skillProgramId, type
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const karAmuzId = searchParams.get('karAmuzId');
    const skillProgramId = searchParams.get('skillProgramId');
    const type = searchParams.get('type');

    const where: Record<string, unknown> = {};

    if (karAmuzId) {
      where.karAmuzId = karAmuzId;
    }

    if (skillProgramId) {
      where.skillProgramId = skillProgramId;
    }

    if (type) {
      where.type = type;
    }

    const evaluations = await db.evaluation.findMany({
      where,
      orderBy: { date: 'desc' },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'لیست ارزیابی‌ها با موفقیت دریافت شد',
      داده‌ها: evaluations,
    });
  } catch (error) {
    console.error('Evaluations list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست ارزیابی‌ها' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/evaluations
 * Create evaluation for a KarAmuz.
 * Required: karAmuzId, skillProgramId, type, title, date
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { karAmuzId, skillProgramId, type, title, date, score, maxScore, notes } = body;

    // Validate required fields
    if (!karAmuzId || !skillProgramId || !type || !title || !date) {
      return NextResponse.json(
        { خطا: 'شناسه کارآموز، شناسه برنامه مهارتی، نوع ارزیابی، عنوان و تاریخ الزامی است' },
        { status: 400 }
      );
    }

    // Validate type
    const validTypes = ['MIDTERM', 'FINAL', 'PROJECT', 'SKILL_CHECK'];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { خطا: `نوع ارزیابی نامعتبر است. مقادیر مجاز: ${validTypes.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate that karAmuzId exists
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز یافت نشد' },
        { status: 404 }
      );
    }

    // Validate that skillProgramId exists
    const skillProgram = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
    });

    if (!skillProgram) {
      return NextResponse.json(
        { خطا: 'برنامه مهارتی یافت نشد' },
        { status: 404 }
      );
    }

    // Validate score <= maxScore if score provided
    const effectiveMaxScore = maxScore !== undefined ? Number(maxScore) : 20;
    if (score !== undefined && Number(score) > effectiveMaxScore) {
      return NextResponse.json(
        { خطا: `نمره (${score}) نمی‌تواند بیشتر از نمره کل (${effectiveMaxScore}) باشد` },
        { status: 400 }
      );
    }

    // Create evaluation
    const evaluation = await db.evaluation.create({
      data: {
        karAmuzId,
        skillProgramId,
        type,
        title,
        score: score !== undefined ? Number(score) : null,
        maxScore: effectiveMaxScore,
        date: new Date(date),
        notes: notes || null,
      },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
          },
        },
      },
    });

    return NextResponse.json(
      {
        پیام: 'ارزیابی با موفقیت ایجاد شد',
        داده: evaluation,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Evaluation creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ایجاد ارزیابی' },
      { status: 500 }
    );
  }
}
