import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/knowledge-base
 * List knowledge articles with filtering and search.
 * Query params: category, isPublished, isInternal, search, sort, order, page, limit
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const category = searchParams.get('category');
    const isPublished = searchParams.get('isPublished');
    const isInternal = searchParams.get('isInternal');
    const search = searchParams.get('search');

    const sort = searchParams.get('sort') || 'sortOrder';
    const order = searchParams.get('order') || 'asc';

    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (category) where.category = category;
    if (isPublished !== null && isPublished !== undefined) {
      where.isPublished = isPublished === 'true';
    }
    if (isInternal !== null && isInternal !== undefined) {
      where.isInternal = isInternal === 'true';
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { content: { contains: search, mode: 'insensitive' } },
        { tags: { contains: search, mode: 'insensitive' } },
      ];
    }

    const allowedSortFields = ['createdAt', 'title', 'category', 'sortOrder', 'viewCount'];
    const sortField = allowedSortFields.includes(sort) ? sort : 'sortOrder';
    const sortOrder = order === 'desc' ? 'desc' : 'asc';

    const [articles, total] = await Promise.all([
      db.knowledgeArticle.findMany({
        where,
        orderBy: { [sortField]: sortOrder },
        skip,
        take: limit,
        select: {
          id: true,
          title: true,
          slug: true,
          excerpt: true,
          category: true,
          tags: true,
          isPublished: true,
          isInternal: true,
          author: true,
          viewCount: true,
          sortOrder: true,
          createdAt: true,
          updatedAt: true,
        },
      }),
      db.knowledgeArticle.count({ where }),
    ]);

    // Categories with count
    const categories = await db.knowledgeArticle.groupBy({
      by: ['category'],
      _count: { id: true },
      where: { isPublished: true },
    });

    return NextResponse.json({
      پیام: 'لیست مقالات پایگاه دانش با موفقیت دریافت شد',
      داده‌ها: articles,
      دسته‌بندی‌ها: categories.reduce((acc, c) => ({ ...acc, [c.category]: c._count.id }), {} as Record<string, number>),
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Knowledge base list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت مقالات' }, { status: 500 });
  }
}

/**
 * POST /api/crm/knowledge-base
 * Create a new knowledge article.
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, content, excerpt, category, tags, isPublished, isInternal, author, sortOrder } = body;

    if (!title || !content) {
      return NextResponse.json(
        { خطا: 'عنوان و محتوای مقاله الزامی است' },
        { status: 400 }
      );
    }

    // Auto-generate slug from title
    const slug = body.slug || title
      .replace(/[\s]+/g, '-')
      .replace(/[^\u0600-\u06FF\w-]/g, '')
      .toLowerCase()
      .substring(0, 80);

    // Check slug uniqueness
    const existing = await db.knowledgeArticle.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json(
        { خطا: 'این slug قبلاً استفاده شده است' },
        { status: 409 }
      );
    }

    const article = await db.knowledgeArticle.create({
      data: {
        title,
        slug,
        content,
        excerpt: excerpt || '',
        category: category || 'GENERAL',
        tags: tags || '',
        isPublished: isPublished || false,
        isInternal: isInternal !== undefined ? isInternal : true,
        author: author || '',
        sortOrder: sortOrder || 0,
      },
    });

    return NextResponse.json(
      { پیام: 'مقاله با موفقیت ایجاد شد', داده: article },
      { status: 201 }
    );
  } catch (error) {
    console.error('Knowledge article creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت مقاله' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/knowledge-base
 * Update a knowledge article.
 * Body: { articleId, title?, content?, excerpt?, category?, tags?, isPublished?, isInternal?, sortOrder? }
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { articleId, title, content, excerpt, category, tags, isPublished, isInternal, sortOrder } = body;

    if (!articleId) {
      return NextResponse.json({ خطا: 'شناسه مقاله الزامی است' }, { status: 400 });
    }

    const existing = await db.knowledgeArticle.findUnique({ where: { id: articleId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'مقاله مورد نظر یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};
    if (title !== undefined) updateData.title = title;
    if (content !== undefined) updateData.content = content;
    if (excerpt !== undefined) updateData.excerpt = excerpt;
    if (category !== undefined) updateData.category = category;
    if (tags !== undefined) updateData.tags = tags;
    if (isPublished !== undefined) updateData.isPublished = isPublished;
    if (isInternal !== undefined) updateData.isInternal = isInternal;
    if (sortOrder !== undefined) updateData.sortOrder = sortOrder;

    const updated = await db.knowledgeArticle.update({
      where: { id: articleId },
      data: updateData,
    });

    return NextResponse.json({
      پیام: 'مقاله با موفقیت به‌روزرسانی شد',
      داده: updated,
    });
  } catch (error) {
    console.error('Knowledge article update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی مقاله' }, { status: 500 });
  }
}

/**
 * DELETE /api/crm/knowledge-base
 * Delete a knowledge article.
 * Body: { articleId }
 */
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json();
    const { articleId } = body;

    if (!articleId) {
      return NextResponse.json({ خطا: 'شناسه مقاله الزامی است' }, { status: 400 });
    }

    await db.knowledgeArticle.delete({ where: { id: articleId } });

    return NextResponse.json({ پیام: 'مقاله با موفقیت حذف شد' });
  } catch (error) {
    console.error('Knowledge article delete error:', error);
    return NextResponse.json({ خطا: 'خطا در حذف مقاله' }, { status: 500 });
  }
}
