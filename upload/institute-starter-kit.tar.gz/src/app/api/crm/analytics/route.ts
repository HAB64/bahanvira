import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/analytics
 * Advanced CRM analytics with conversion funnel, CLV, retention,
 * response time, satisfaction, segment distribution, and monthly trends.
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    // ── 1. Conversion Funnel ──
    const funnelStages = ['NEW', 'CONTACTED', 'INTERESTED', 'ENROLLED'];

    const leadsByStage = await db.lead.groupBy({
      by: ['stage'],
      _count: { id: true },
      where: {
        stage: { in: funnelStages },
      },
    });

    const stageCounts: Record<string, number> = {
      NEW: 0,
      CONTACTED: 0,
      INTERESTED: 0,
      ENROLLED: 0,
    };
    for (const item of leadsByStage) {
      stageCounts[item.stage] = item._count.id;
    }

    const totalFunnel = Object.values(stageCounts).reduce((a, b) => a + b, 0);

    const conversionFunnel = funnelStages.map((stage) => ({
      مرحله: stage,
      تعداد: stageCounts[stage],
      درصد: totalFunnel > 0 ? Math.round((stageCounts[stage] / totalFunnel) * 100) : 0,
    }));

    const overallConversionRate =
      stageCounts.NEW > 0
        ? Math.round((stageCounts.ENROLLED / stageCounts.NEW) * 100)
        : 0;

    // ── 2. CLV (Customer Lifetime Value) ──
    const enrolledLeads = await db.lead.findMany({
      where: { stage: 'ENROLLED' },
      select: { lifetimeValue: true, segment: true, name: true, phone: true, id: true },
    });

    const totalCLV = enrolledLeads.reduce((sum, l) => sum + l.lifetimeValue, 0);
    const avgCLV = enrolledLeads.length > 0 ? Math.round(totalCLV / enrolledLeads.length) : 0;

    // CLV by segment
    const clvBySegmentMap: Record<string, { total: number; count: number }> = {};
    for (const lead of enrolledLeads) {
      const seg = lead.segment || 'بدون_بخش';
      if (!clvBySegmentMap[seg]) {
        clvBySegmentMap[seg] = { total: 0, count: 0 };
      }
      clvBySegmentMap[seg].total += lead.lifetimeValue;
      clvBySegmentMap[seg].count += 1;
    }

    const clvBySegment = Object.entries(clvBySegmentMap).map(([segment, data]) => ({
      بخش: segment,
      میانگین_CLV: data.count > 0 ? Math.round(data.total / data.count) : 0,
      تعداد: data.count,
    }));

    // Top 10 highest CLV leads
    const topCLVLeads = await db.lead.findMany({
      where: { stage: 'ENROLLED', lifetimeValue: { gt: 0 } },
      select: { id: true, name: true, phone: true, lifetimeValue: true, segment: true },
      orderBy: { lifetimeValue: 'desc' },
      take: 10,
    });

    // ── 3. Retention Metrics ──
    const karAmuzByStatus = await db.karAmuz.groupBy({
      by: ['status'],
      _count: { id: true },
      where: {
        status: { in: ['ACTIVE', 'DROPPED'] },
      },
    });

    const activeCount =
      karAmuzByStatus.find((k) => k.status === 'ACTIVE')?._count.id ?? 0;
    const droppedCount =
      karAmuzByStatus.find((k) => k.status === 'DROPPED')?._count.id ?? 0;
    const retentionRate =
      activeCount + droppedCount > 0
        ? Math.round((activeCount / (activeCount + droppedCount)) * 100)
        : 0;

    // Average time before dropout
    const droppedKarAmuz = await db.karAmuz.findMany({
      where: {
        status: 'DROPPED',
        actualEndDate: { not: null },
      },
      select: { startDate: true, actualEndDate: true },
    });

    let avgDropoutDays = 0;
    if (droppedKarAmuz.length > 0) {
      const totalDays = droppedKarAmuz.reduce((sum, k) => {
        if (k.actualEndDate) {
          const diffMs = new Date(k.actualEndDate).getTime() - new Date(k.startDate).getTime();
          return sum + diffMs / (1000 * 60 * 60 * 24);
        }
        return sum;
      }, 0);
      avgDropoutDays = Math.round(totalDays / droppedKarAmuz.length);
    }

    // ── 4. Response Time Metrics ──
    // Average time from lead creation to first contact (CALL/WHATSAPP/SMS activity after lead creation)
    const firstContacts = await db.activityLog.findMany({
      where: {
        type: { in: ['CALL', 'WHATSAPP', 'SMS'] },
      },
      select: {
        leadId: true,
        createdAt: true,
        lead: {
          select: { createdAt: true, assignedTo: true },
        },
      },
      orderBy: { createdAt: 'asc' },
    });

    // Group by leadId to find first contact per lead
    const firstContactMap = new Map<
      string,
      { leadCreated: Date; firstContact: Date; assignedTo: string }
    >();
    for (const fc of firstContacts) {
      if (!firstContactMap.has(fc.leadId)) {
        firstContactMap.set(fc.leadId, {
          leadCreated: new Date(fc.lead.createdAt),
          firstContact: new Date(fc.createdAt),
          assignedTo: fc.lead.assignedTo || 'بدون_مشاور',
        });
      }
    }

    const responseTimes = Array.from(firstContactMap.values());
    const avgResponseMinutes =
      responseTimes.length > 0
        ? Math.round(
            responseTimes.reduce((sum, r) => {
              const diffMs = r.firstContact.getTime() - r.leadCreated.getTime();
              return sum + diffMs / (1000 * 60);
            }, 0) / responseTimes.length
          )
        : 0;

    // By assignedTo (consultant)
    const responseByConsultantMap: Record<string, { total: number; count: number }> = {};
    for (const r of responseTimes) {
      const consultant = r.assignedTo || 'بدون_مشاور';
      if (!responseByConsultantMap[consultant]) {
        responseByConsultantMap[consultant] = { total: 0, count: 0 };
      }
      const diffMin = (r.firstContact.getTime() - r.leadCreated.getTime()) / (1000 * 60);
      responseByConsultantMap[consultant].total += diffMin;
      responseByConsultantMap[consultant].count += 1;
    }

    const responseByConsultant = Object.entries(responseByConsultantMap).map(
      ([consultant, data]) => ({
        مشاور: consultant,
        میانگین_پاسخ_دقیقه: data.count > 0 ? Math.round(data.total / data.count) : 0,
        تعداد_تماس: data.count,
      })
    );

    // ── 5. Satisfaction Score ──
    const satisfactionAgg = await db.lead.aggregate({
      _avg: { satisfactionScore: true },
      _count: { satisfactionScore: true },
      where: { satisfactionScore: { not: null } },
    });

    const avgSatisfaction = satisfactionAgg._avg.satisfactionScore
      ? Math.round(satisfactionAgg._avg.satisfactionScore * 10) / 10
      : 0;

    // Distribution (1-5)
    const satisfactionDistribution: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    const satisfactionByScore = await db.lead.groupBy({
      by: ['satisfactionScore'],
      _count: { id: true },
      where: { satisfactionScore: { not: null } },
    });
    for (const item of satisfactionByScore) {
      const score = item.satisfactionScore as number;
      if (score >= 1 && score <= 5) {
        satisfactionDistribution[score] = item._count.id;
      }
    }

    // ── 6. Segment Distribution ──
    const allSegments = ['VIP', 'REGULAR', 'AT_RISK', 'CHURNED', 'NEW', 'LOYAL', ''];
    const segmentGrouped = await db.lead.groupBy({
      by: ['segment'],
      _count: { id: true },
    });

    const segmentDistribution = allSegments.map((seg) => {
      const found = segmentGrouped.find((s) => s.segment === seg);
      return {
        بخش: seg || 'بدون_بخش',
        تعداد: found?._count.id ?? 0,
      };
    });

    // ── 7. Monthly Trends (last 6 months) ──
    const monthlyTrends: {
      ماه: string;
      تعداد_لید: number;
      تعداد_ثبت‌نام: number;
      درآمد: number;
      نرخ_تبدیل: number;
    }[] = [];

    for (let i = 5; i >= 0; i--) {
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setMonth(monthStart.getMonth() - i);
      monthStart.setHours(0, 0, 0, 0);

      const monthEnd = new Date(monthStart);
      monthEnd.setMonth(monthEnd.getMonth() + 1);
      monthEnd.setDate(0);
      monthEnd.setHours(23, 59, 59, 999);

      const monthLabel = new Intl.DateTimeFormat('fa-IR', {
        month: 'short',
        year: '2-digit',
      }).format(monthStart);

      // Lead count for this month
      const leadCount = await db.lead.count({
        where: {
          createdAt: { gte: monthStart, lte: monthEnd },
        },
      });

      // Enrolled count for this month (leads with stage ENROLLED created in this month)
      const enrolledCount = await db.lead.count({
        where: {
          createdAt: { gte: monthStart, lte: monthEnd },
          stage: 'ENROLLED',
        },
      });

      // Revenue for this month (PAID payments)
      const revenueResult = await db.payment.aggregate({
        _sum: { amount: true },
        where: {
          status: 'PAID',
          paidAt: { gte: monthStart, lte: monthEnd },
        },
      });

      const revenue = revenueResult._sum.amount ?? 0;
      const convRate = leadCount > 0 ? Math.round((enrolledCount / leadCount) * 100) : 0;

      monthlyTrends.push({
        ماه: monthLabel,
        تعداد_لید: leadCount,
        تعداد_ثبت‌نام: enrolledCount,
        درآمد: revenue,
        نرخ_تبدیل: convRate,
      });
    }

    // ── Assemble Final Response ──
    return NextResponse.json({
      پیام: 'تحلیل‌های پیشرفته CRM با موفقیت دریافت شد',
      داده: {
        قیف_تبدیل: {
          مراحل: conversionFunnel,
          نرخ_تبدیل_کل: overallConversionRate,
        },
        ارزش_مشتری: {
          میانگین_CLV: avgCLV,
          CLV_بر_بخش: clvBySegment,
          برترین_مشتریان: topCLVLeads,
        },
        حفظ_مشتری: {
          فعال: activeCount,
          ترک_کرده: droppedCount,
          نرخ_حفظ: retentionRate,
          میانگین_زمان_ترک_روز: avgDropoutDays,
        },
        زمان_پاسخ: {
          میانگین_پاسخ_دقیقه: avgResponseMinutes,
          بر_مشاور: responseByConsultant,
        },
        رضایت: {
          میانگین_امتیاز: avgSatisfaction,
          تعداد_نظرات: satisfactionAgg._count.satisfactionScore,
          توزیع: satisfactionDistribution,
        },
        توزیع_بخش: segmentDistribution,
        روند_ماهانه: monthlyTrends,
      },
    });
  } catch (error) {
    console.error('CRM analytics error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت تحلیل‌های CRM' },
      { status: 500 }
    );
  }
}
