import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * POST /api/crm/webhook
 * Accept external automation events.
 * Headers: X-Webhook-Secret
 * Body: { event, data }
 *
 * Supported events:
 * - lead.created: { name, phone, email?, course?, cluster?, source? }
 * - payment.reminder: { leadId, message? }
 * - sms.sent: { leadId, message? }
 * - whatsapp.sent: { leadId, message? }
 */
export async function POST(request: NextRequest) {
  try {
    // Validate webhook secret
    const secret = request.headers.get('X-Webhook-Secret');
    const expectedSecret = process.env.WEBHOOK_SECRET;

    if (expectedSecret && secret !== expectedSecret) {
      return NextResponse.json(
        { خطا: 'کلید وب‌هوک نامعتبر است' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { event, data } = body;

    if (!event || !data) {
      return NextResponse.json(
        { خطا: 'نوع رویداد و داده‌ها الزامی است' },
        { status: 400 }
      );
    }

    switch (event) {
      case 'lead.created': {
        const { name, phone, email, course, cluster, source, utmSource, utmMedium, utmCampaign } = data;

        if (!name || !phone) {
          return NextResponse.json(
            { خطا: 'نام و شماره تماس برای ایجاد لید الزامی است' },
            { status: 400 }
          );
        }

        // Create lead
        let score = 30;
        if (course && course.trim() !== '') score += 20;
        if (cluster === 'finance' || cluster === 'tech-ai') score += 15;
        if (source === 'hero-form') score += 10;
        score += 15; // valid phone
        if (email && email.trim() !== '') score += 10;
        score = Math.min(score, 100);

        const lead = await prisma.lead.create({
          data: {
            name,
            phone,
            email: email || '',
            course: course || '',
            cluster: cluster || '',
            source: source || 'webhook',
            stage: 'NEW',
            score,
            utmSource: utmSource || '',
            utmMedium: utmMedium || '',
            utmCampaign: utmCampaign || '',
          },
        });

        // Log activity
        await prisma.activityLog.create({
          data: {
            leadId: lead.id,
            type: 'NOTE',
            content: `لید از طریق وب‌هوک ایجاد شد (منبع: ${source || 'webhook'})`,
          },
        });

        return NextResponse.json({
          پیام: 'لید با موفقیت از وب‌هوک ایجاد شد',
          داده: { leadId: lead.id },
        });
      }

      // ── Lead Scoring System (from leadActions.ts) ──────────────────────
      case 'lead.scored': {
        const {
          name, mobile, email, lead_score, lead_temperature, lead_status,
          interested_category, course_slug, source, event_id,
          scoring_events, utm_source, utm_medium, utm_campaign,
          utm_term, utm_content, page_url, institute,
        } = data;

        if (!name || !mobile) {
          return NextResponse.json(
            { خطا: 'نام و شماره موبایل برای لید امتیازدهی‌شده الزامی است' },
            { status: 400 }
          );
        }

        // Check if lead already exists (by phone)
        const existingLead = await prisma.lead.findFirst({
          where: { phone: mobile },
          orderBy: { createdAt: 'desc' },
        });

        let lead;

        if (existingLead) {
          // Update existing lead with new score if higher
          lead = await prisma.lead.update({
            where: { id: existingLead.id },
            data: {
              score: Math.max(existingLead.score, lead_score || 0),
              stage: lead_status === 'hot' ? 'INTERESTED' : existingLead.stage,
              cluster: interested_category || existingLead.cluster,
              lastContactedAt: new Date(),
            },
          });

          // Log scoring update
          await prisma.activityLog.create({
            data: {
              leadId: lead.id,
              type: 'STAGE_CHANGE',
              content: `امتیاز لید به‌روزرسانی شد: ${lead_score} (دما: ${lead_temperature}) — رویدادها: ${(scoring_events || []).join(', ')}`,
            },
          });
        } else {
          // Create new lead with scoring data
          const segment = lead_score >= 80 ? 'VIP' : lead_score >= 50 ? 'REGULAR' : 'NEW';

          lead = await prisma.lead.create({
            data: {
              name,
              phone: mobile,
              email: email || '',
              course: course_slug || '',
              cluster: interested_category || '',
              source: source || 'lead-scoring-system',
              stage: lead_status === 'hot' ? 'INTERESTED' : 'NEW',
              score: lead_score || 0,
              segment,
              utmSource: utm_source || '',
              utmMedium: utm_medium || '',
              utmCampaign: utm_campaign || '',
            },
          });

          // Log creation
          await prisma.activityLog.create({
            data: {
              leadId: lead.id,
              type: 'NOTE',
              content: `لید از سیستم امتیازدهی ایجاد شد — امتیاز: ${lead_score} | دما: ${lead_temperature} | رویدادها: ${(scoring_events || []).join(', ')} | منبع: ${source}`,
            },
          });
        }

        // Execute automation rules for scored leads
        try {
          const { executeAutomationRules, seedDefaultAutomationRules } = await import('@/lib/crm/automation-engine');
          await seedDefaultAutomationRules();
          executeAutomationRules('LEAD_CREATED', {
            leadId: lead.id,
            stage: lead.stage,
            cluster: lead.cluster,
            assignedTo: lead.assignedTo,
            leadName: lead.name,
            leadPhone: lead.phone,
            courseTitle: course_slug || '',
          }).catch(() => {});
        } catch {}

        return NextResponse.json({
          پیام: existingLead ? 'امتیاز لید به‌روزرسانی شد' : 'لید امتیازدهی‌شده ایجاد شد',
          داده: { leadId: lead.id, score: lead.score, temperature: lead_temperature, event_id },
        });
      }

      case 'payment.reminder': {
        const { leadId, message } = data;

        if (!leadId) {
          return NextResponse.json(
            { خطا: 'شناسه لید الزامی است' },
            { status: 400 }
          );
        }

        const lead = await prisma.lead.findUnique({ where: { id: leadId } });
        if (!lead) {
          return NextResponse.json(
            { خطا: 'لید مورد نظر یافت نشد' },
            { status: 404 }
          );
        }

        await prisma.activityLog.create({
          data: {
            leadId,
            type: 'REMINDER',
            content: message || 'یادآوری پرداخت از طریق وب‌هوک',
          },
        });

        return NextResponse.json({
          پیام: 'یادآوری پرداخت با موفقیت ثبت شد',
        });
      }

      case 'sms.sent': {
        const { leadId, message } = data;

        if (!leadId) {
          return NextResponse.json(
            { خطا: 'شناسه لید الزامی است' },
            { status: 400 }
          );
        }

        const lead = await prisma.lead.findUnique({ where: { id: leadId } });
        if (!lead) {
          return NextResponse.json(
            { خطا: 'لید مورد نظر یافت نشد' },
            { status: 404 }
          );
        }

        await prisma.activityLog.create({
          data: {
            leadId,
            type: 'SMS',
            content: message || 'پیامک از طریق وب‌هوک ارسال شد',
          },
        });

        // Update lastContactedAt
        await prisma.lead.update({
          where: { id: leadId },
          data: { lastContactedAt: new Date() },
        });

        return NextResponse.json({
          پیام: 'فعالیت پیامک با موفقیت ثبت شد',
        });
      }

      case 'whatsapp.sent': {
        const { leadId, message } = data;

        if (!leadId) {
          return NextResponse.json(
            { خطا: 'شناسه لید الزامی است' },
            { status: 400 }
          );
        }

        const lead = await prisma.lead.findUnique({ where: { id: leadId } });
        if (!lead) {
          return NextResponse.json(
            { خطا: 'لید مورد نظر یافت نشد' },
            { status: 404 }
          );
        }

        await prisma.activityLog.create({
          data: {
            leadId,
            type: 'WHATSAPP',
            content: message || 'پیام واتس‌اپ از طریق وب‌هوک ارسال شد',
          },
        });

        // Update lastContactedAt
        await prisma.lead.update({
          where: { id: leadId },
          data: { lastContactedAt: new Date() },
        });

        return NextResponse.json({
          پیام: 'فعالیت واتس‌اپ با موفقیت ثبت شد',
        });
      }

      default:
        return NextResponse.json(
          { خطا: `نوع رویداد پشتیبانی نمی‌شود: ${event}` },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('CRM webhook error:', error);
    return NextResponse.json(
      { خطا: 'خطا در پردازش وب‌هوک' },
      { status: 500 }
    );
  }
}
