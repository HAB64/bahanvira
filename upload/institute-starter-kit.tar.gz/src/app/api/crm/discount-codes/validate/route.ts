import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * POST /api/crm/discount-codes/validate
 * Validate a discount code (public endpoint)
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { code, courseSlug, orderAmount, isNewStudent } = body;

    if (!code) {
      return NextResponse.json({ valid: false, error: 'کد تخفیف وارد نشده' }, { status: 400 });
    }

    const discountCode = await db.discountCode.findUnique({
      where: { code: code.toUpperCase() },
      include: {
        referrer: { select: { firstName: true, lastName: true, code: true } },
      },
    });

    if (!discountCode) {
      return NextResponse.json({ valid: false, error: 'کد تخفیف نامعتبر است' });
    }

    // Check active
    if (!discountCode.isActive) {
      return NextResponse.json({ valid: false, error: 'این کد تخفیف غیرفعال شده است' });
    }

    // Check date validity
    const now = new Date();
    if (discountCode.startDate && now < discountCode.startDate) {
      return NextResponse.json({ valid: false, error: 'این کد تخفیف هنوز فعال نشده است' });
    }
    if (discountCode.endDate && now > discountCode.endDate) {
      return NextResponse.json({ valid: false, error: 'اعتبار این کد تخفیف به پایان رسیده است' });
    }

    // Check usage limit
    if (discountCode.maxUses && discountCode.currentUses >= discountCode.maxUses) {
      return NextResponse.json({ valid: false, error: 'ظرفیت استفاده از این کد تخفیف تکمیل شده است' });
    }

    // Check minimum order amount
    if (discountCode.minOrderAmount && orderAmount && orderAmount < discountCode.minOrderAmount) {
      return NextResponse.json({
        valid: false,
        error: `حداقل مبلغ سفارش برای این کد ${discountCode.minOrderAmount.toLocaleString('fa-IR')} ریال است`,
      });
    }

    // Check applicable courses
    if (discountCode.applicableCourses && courseSlug) {
      const allowedCourses = discountCode.applicableCourses.split(',').map(s => s.trim());
      if (!allowedCourses.includes(courseSlug)) {
        return NextResponse.json({ valid: false, error: 'این کد تخفیف برای این دوره قابل استفاده نیست' });
      }
    }

    // Check new students only
    if (discountCode.forNewStudentsOnly && !isNewStudent) {
      return NextResponse.json({ valid: false, error: 'این کد تخفیف فقط برای دانشجویان جدید است' });
    }

    // Calculate discount amount
    let discountAmount = 0;
    if (discountCode.type === 'PERCENTAGE') {
      discountAmount = orderAmount ? Math.round(orderAmount * (discountCode.value / 100)) : 0;
      if (discountCode.maxDiscount && discountAmount > discountCode.maxDiscount) {
        discountAmount = discountCode.maxDiscount;
      }
    } else {
      discountAmount = Math.round(discountCode.value);
    }

    return NextResponse.json({
      valid: true,
      discount: {
        type: discountCode.type,
        value: discountCode.value,
        amount: discountAmount,
        code: discountCode.code,
        referrerName: discountCode.referrer ? `${discountCode.referrer.firstName} ${discountCode.referrer.lastName}` : null,
      },
    });
  } catch (error) {
    console.error('Error validating discount code:', error);
    return NextResponse.json({ valid: false, error: 'خطا در بررسی کد تخفیف' }, { status: 500 });
  }
}
