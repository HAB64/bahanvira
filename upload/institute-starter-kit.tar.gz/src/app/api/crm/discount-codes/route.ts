import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * GET /api/crm/discount-codes
 * List all discount codes
 */
export async function GET(request: NextRequest) {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const isActive = searchParams.get('isActive');

    const where: Record<string, unknown> = {};
    if (search) {
      where.OR = [
        { code: { contains: search, mode: 'insensitive' } },
      ];
    }
    if (isActive !== null && isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const codes = await db.discountCode.findMany({
      where,
      include: {
        referrer: { select: { id: true, firstName: true, lastName: true, code: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ codes });
  } catch (error) {
    console.error('Error fetching discount codes:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات' }, { status: 500 });
  }
}

/**
 * POST /api/crm/discount-codes
 * Create a new discount code
 */
export async function POST(request: NextRequest) {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await request.json();
    const {
      code, referrerId, type, value, maxUses, maxDiscount,
      startDate, endDate, isActive,
      minOrderAmount, applicableCourses, forNewStudentsOnly,
    } = body;

    if (!code || value === undefined) {
      return NextResponse.json({ error: 'کد تخفیف و مقدار الزامی است' }, { status: 400 });
    }

    const discountCode = await db.discountCode.create({
      data: {
        code: code.toUpperCase(),
        referrerId: referrerId || null,
        type: type || 'PERCENTAGE',
        value: parseFloat(value),
        maxUses: maxUses ? parseInt(maxUses) : null,
        maxDiscount: maxDiscount ? parseInt(maxDiscount) : null,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        isActive: isActive !== false,
        minOrderAmount: minOrderAmount ? parseInt(minOrderAmount) : null,
        applicableCourses: applicableCourses || null,
        forNewStudentsOnly: forNewStudentsOnly || false,
      },
    });

    return NextResponse.json({ success: true, discountCode }, { status: 201 });
  } catch (error) {
    console.error('Error creating discount code:', error);
    if (String(error).includes('Unique constraint')) {
      return NextResponse.json({ error: 'این کد تخفیف قبلاً ثبت شده است' }, { status: 409 });
    }
    return NextResponse.json({ error: 'خطا در ایجاد کد تخفیف' }, { status: 500 });
  }
}
