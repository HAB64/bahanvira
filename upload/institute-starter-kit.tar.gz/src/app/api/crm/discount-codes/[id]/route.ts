import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * PATCH /api/crm/discount-codes/[id]
 * Update a discount code
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { id } = await params;
    const body = await request.json();

    const updateData: Record<string, unknown> = {};
    const allowedFields = [
      'code', 'referrerId', 'type', 'value', 'maxUses', 'maxDiscount',
      'startDate', 'endDate', 'isActive',
      'minOrderAmount', 'applicableCourses', 'forNewStudentsOnly',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        if (field === 'value') updateData[field] = parseFloat(body[field]);
        else if (field === 'maxUses' || field === 'maxDiscount' || field === 'minOrderAmount') {
          updateData[field] = body[field] ? parseInt(body[field]) : null;
        } else if (field === 'startDate' || field === 'endDate') {
          updateData[field] = body[field] ? new Date(body[field]) : null;
        } else {
          updateData[field] = body[field];
        }
      }
    }

    if (updateData.code) updateData.code = String(updateData.code).toUpperCase();

    const discountCode = await db.discountCode.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({ success: true, discountCode });
  } catch (error) {
    console.error('Error updating discount code:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی' }, { status: 500 });
  }
}

/**
 * DELETE /api/crm/discount-codes/[id]
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getAdminSession();
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { id } = await params;
    await db.discountCode.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting discount code:', error);
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
