import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { randomBytes } from 'crypto';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/api-keys — List API keys
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const keys = await db.apiKey.findMany({
      orderBy: { createdAt: 'desc' },
    });

    // Mask keys for security
    const masked = keys.map(k => ({
      ...k,
      key: k.key.slice(0, 8) + '...' + k.key.slice(-4),
    }));

    return NextResponse.json({
      پیام: 'لیست کلیدهای API با موفقیت دریافت شد',
      داده‌ها: masked,
    });
  } catch (error) {
    console.error('API keys list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت کلیدها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/api-keys — Create a new API key
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, permissions, expiresAt } = body;

    if (!name) {
      return NextResponse.json({ خطا: 'نام کلید الزامی است' }, { status: 400 });
    }

    // Generate random API key
    const key = `bhr_${randomBytes(32).toString('hex')}`;

    const apiKey = await db.apiKey.create({
      data: {
        name,
        key,
        permissions: permissions || 'READ',
        expiresAt: expiresAt ? new Date(expiresAt) : null,
      },
    });

    // Return the FULL key only on creation
    return NextResponse.json({
      پیام: 'کلید API با موفقیت ایجاد شد',
      داده: apiKey,
      هشدار: 'این کلید فقط یک بار نمایش داده می‌شود. حتماً آن را ذخیره کنید.',
    }, { status: 201 });
  } catch (error) {
    console.error('API key create error:', error);
    return NextResponse.json({ خطا: 'خطا در ایجاد کلید' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/api-keys — Update an API key
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { keyId, name, permissions, isActive, expiresAt } = body;

    if (!keyId) {
      return NextResponse.json({ خطا: 'شناسه کلید الزامی است' }, { status: 400 });
    }

    const existing = await db.apiKey.findUnique({ where: { id: keyId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'کلید یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};
    if (name !== undefined) updateData.name = name;
    if (permissions !== undefined) updateData.permissions = permissions;
    if (isActive !== undefined) updateData.isActive = isActive;
    if (expiresAt !== undefined) updateData.expiresAt = expiresAt ? new Date(expiresAt) : null;

    const updated = await db.apiKey.update({
      where: { id: keyId },
      data: updateData,
    });

    // Mask key in response
    const masked = {
      ...updated,
      key: updated.key.slice(0, 8) + '...' + updated.key.slice(-4),
    };

    return NextResponse.json({ پیام: 'کلید به‌روزرسانی شد', داده: masked });
  } catch (error) {
    console.error('API key update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی کلید' }, { status: 500 });
  }
}
