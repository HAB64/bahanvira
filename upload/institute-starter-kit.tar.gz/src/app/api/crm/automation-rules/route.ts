import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
const VALID_TRIGGERS = [
  'LEAD_CREATED',
  'STAGE_CHANGED',
  'PAYMENT_RECEIVED',
  'PAYMENT_OVERDUE',
  'FOLLOW_UP_DUE',
  'TICKET_CREATED',
  'TICKET_SLA_BREACH',
  'QUOTE_ACCEPTED',
  'QUOTE_SENT',
  'APPOINTMENT_REMINDER',
  'ENROLLMENT_CREATED',
  'CERTIFICATE_ISSUED',
] as const;

const VALID_ACTION_TYPES = [
  'CREATE_TASK',
  'ADD_TAG',
  'STAGE_CHANGE',
  'ADD_NOTE',
  'SEND_SMS',
  'SEND_WHATSAPP',
  'NOTIFY',
  'CREATE_INVOICE',
  'UPDATE_SEGMENT',
  'ESCALATE_TICKET',
  'SEND_EMAIL',
] as const;

/**
 * GET /api/crm/automation-rules
 * List all automation rules.
 * Query params: isActive (boolean filter)
 * Sort by priority desc
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const isActive = searchParams.get('isActive');
    const trigger = searchParams.get('trigger');

    const where: Record<string, unknown> = {};
    if (isActive !== null && isActive !== undefined) {
      where.isActive = isActive === 'true';
    }
    if (trigger) {
      where.trigger = trigger;
    }

    const rules = await db.automationRule.findMany({
      where,
      orderBy: { priority: 'desc' },
    });

    return NextResponse.json({
      پیام: 'لیست قوانین اتوماسیون با موفقیت دریافت شد',
      داده‌ها: rules,
    });
  } catch (error) {
    console.error('Automation rules list error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست قوانین اتوماسیون' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/crm/automation-rules
 * Create a new automation rule.
 * Required: name, trigger, actions
 * actions: Json array of action objects [{ type, payload }]
 * conditions: optional Json
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, trigger, actions, conditions, isActive, priority } = body;

    // Validate required fields
    if (!name || typeof name !== 'string' || name.trim() === '') {
      return NextResponse.json(
        { خطا: 'نام قانون الزامی است' },
        { status: 400 }
      );
    }

    if (!trigger) {
      return NextResponse.json(
        { خطا: 'رویداد راه‌انداز الزامی است' },
        { status: 400 }
      );
    }

    if (!VALID_TRIGGERS.includes(trigger)) {
      return NextResponse.json(
        { خطا: `رویداد راه‌انداز نامعتبر است. مقادیر مجاز: ${VALID_TRIGGERS.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate actions
    if (!actions || !Array.isArray(actions) || actions.length === 0) {
      return NextResponse.json(
        { خطا: 'حداقل یک عملیات الزامی است' },
        { status: 400 }
      );
    }

    for (const action of actions) {
      if (!action.type || !VALID_ACTION_TYPES.includes(action.type)) {
        return NextResponse.json(
          { خطا: `نوع عملیات نامعتبر است. مقادیر مجاز: ${VALID_ACTION_TYPES.join(', ')}` },
          { status: 400 }
        );
      }
      if (!action.payload || typeof action.payload !== 'object') {
        return NextResponse.json(
          { خطا: 'هر عملیات باید شامل payload باشد' },
          { status: 400 }
        );
      }
    }

    const rule = await db.automationRule.create({
      data: {
        name: name.trim(),
        trigger,
        conditions: conditions || {},
        actions,
        isActive: isActive !== undefined ? Boolean(isActive) : true,
        priority: priority !== undefined ? Number(priority) : 0,
      },
    });

    return NextResponse.json(
      {
        پیام: 'قانون اتوماسیون با موفقیت ایجاد شد',
        داده: rule,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Automation rule creation error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت قانون اتوماسیون جدید' },
      { status: 500 }
    );
  }
}
