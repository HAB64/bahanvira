import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

const VALID_TRIGGERS = [
  'LEAD_CREATED',
  'STAGE_CHANGED',
  'PAYMENT_RECEIVED',
  'PAYMENT_OVERDUE',
  'FOLLOW_UP_DUE',
  'TICKET_CREATED',
  'TICKET_SLA_BREACH',
  'QUOTE_ACCEPTED',
  'QUOTE_SENT',
  'APPOINTMENT_REMINDER',
  'ENROLLMENT_CREATED',
  'CERTIFICATE_ISSUED',
] as const;

const VALID_ACTION_TYPES = [
  'CREATE_TASK',
  'ADD_TAG',
  'STAGE_CHANGE',
  'ADD_NOTE',
  'SEND_SMS',
  'SEND_WHATSAPP',
  'NOTIFY',
  'CREATE_INVOICE',
  'UPDATE_SEGMENT',
  'ESCALATE_TICKET',
  'SEND_EMAIL',
] as const;

/**
 * GET /api/crm/automation-rules/[id]
 * Get a single automation rule.
 */
export async function GET(
  _request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const rule = await db.automationRule.findUnique({ where: { id } });

    if (!rule) {
      return NextResponse.json(
        { خطا: 'قانون اتوماسیون مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      پیام: 'اطلاعات قانون اتوماسیون با موفقیت دریافت شد',
      داده: rule,
    });
  } catch (error) {
    console.error('Automation rule get error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت اطلاعات قانون اتوماسیون' },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/crm/automation-rules/[id]
 * Update an automation rule.
 * Allow updating all fields: name, trigger, conditions, actions, isActive, priority
 */
export async function PATCH(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // Check if rule exists
    const existingRule = await db.automationRule.findUnique({ where: { id } });
    if (!existingRule) {
      return NextResponse.json(
        { خطا: 'قانون اتوماسیون مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate trigger if provided
    if (body.trigger && !VALID_TRIGGERS.includes(body.trigger)) {
      return NextResponse.json(
        { خطا: `رویداد راه‌انداز نامعتبر است. مقادیر مجاز: ${VALID_TRIGGERS.join(', ')}` },
        { status: 400 }
      );
    }

    // Validate actions if provided
    if (body.actions) {
      if (!Array.isArray(body.actions) || body.actions.length === 0) {
        return NextResponse.json(
          { خطا: 'حداقل یک عملیات الزامی است' },
          { status: 400 }
        );
      }

      for (const action of body.actions) {
        if (!action.type || !VALID_ACTION_TYPES.includes(action.type)) {
          return NextResponse.json(
            { خطا: `نوع عملیات نامعتبر است. مقادیر مجاز: ${VALID_ACTION_TYPES.join(', ')}` },
            { status: 400 }
          );
        }
        if (!action.payload || typeof action.payload !== 'object') {
          return NextResponse.json(
            { خطا: 'هر عملیات باید شامل payload باشد' },
            { status: 400 }
          );
        }
      }
    }

    // Build update data
    const updateData: Record<string, unknown> = {};

    if (body.name !== undefined) updateData.name = body.name.trim();
    if (body.trigger !== undefined) updateData.trigger = body.trigger;
    if (body.conditions !== undefined) updateData.conditions = body.conditions;
    if (body.actions !== undefined) updateData.actions = body.actions;
    if (body.isActive !== undefined) updateData.isActive = Boolean(body.isActive);
    if (body.priority !== undefined) updateData.priority = Number(body.priority);

    const updatedRule = await db.automationRule.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({
      پیام: 'قانون اتوماسیون با موفقیت به‌روزرسانی شد',
      داده: updatedRule,
    });
  } catch (error) {
    console.error('Automation rule update error:', error);
    return NextResponse.json(
      { خطا: 'خطا در به‌روزرسانی قانون اتوماسیون' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/crm/automation-rules/[id]
 * Delete an automation rule.
 */
export async function DELETE(
  _request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { id } = await params;

    // Check if rule exists
    const existingRule = await db.automationRule.findUnique({ where: { id } });
    if (!existingRule) {
      return NextResponse.json(
        { خطا: 'قانون اتوماسیون مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    await db.automationRule.delete({ where: { id } });

    return NextResponse.json({
      پیام: 'قانون اتوماسیون با موفقیت حذف شد',
    });
  } catch (error) {
    console.error('Automation rule delete error:', error);
    return NextResponse.json(
      { خطا: 'خطا در حذف قانون اتوماسیون' },
      { status: 500 }
    );
  }
}
