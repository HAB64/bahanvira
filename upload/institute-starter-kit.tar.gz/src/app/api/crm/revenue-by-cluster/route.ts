import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
// Cluster labels mapping for Persian
const CLUSTER_LABELS: Record<string, string> = {
  'tech-ai': 'فناوری و هوش مصنوعی',
  'financial': 'مالی و سرمایه‌گذاری',
  'management': 'مدیریت و کسب‌وکار',
  'entrepreneurship': 'کارآفرینی',
  'capital-market': 'بازار سرمایه',
  'educational-services': 'خدمات آموزشی',
  'legal-services': 'خدمات حقوقی',
};

export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    // Get all paid payments with their related enrollment data
    const payments = await db.payment.findMany({
      where: {
        status: 'PAID',
        paidAt: { not: null },
      },
      include: {
        karAmuz: {
          include: {
            enrollments: {
              where: { status: { in: ['ENROLLED', 'COMPLETED'] } },
              include: {
                skillProgram: {
                  select: {
                    id: true,
                    name: true,
                    cluster: true,
                  },
                },
              },
            },
          },
        },
        lead: {
          select: {
            id: true,
            cluster: true,
          },
        },
      },
    });

    // Aggregate revenue by cluster
    const clusterData: Record<
      string,
      {
        cluster: string;
        clusterLabel: string;
        revenue: number;
        enrollments: number;
        paymentCount: number;
      }
    > = {};

    for (const payment of payments) {
      let cluster = '';

      // Try to get cluster from enrollment's skillProgram
      if (payment.karAmuzId && payment.karAmuz) {
        const enrollment = payment.karAmuz.enrollments[0];
        if (enrollment?.skillProgram?.cluster) {
          cluster = enrollment.skillProgram.cluster;
        }
      }

      // Fallback: get cluster from lead
      if (!cluster && payment.leadId && payment.lead) {
        cluster = payment.lead.cluster;
      }

      if (!cluster) continue;

      if (!clusterData[cluster]) {
        clusterData[cluster] = {
          cluster,
          clusterLabel: CLUSTER_LABELS[cluster] || cluster,
          revenue: 0,
          enrollments: 0,
          paymentCount: 0,
        };
      }

      clusterData[cluster].revenue += payment.amount;
      clusterData[cluster].paymentCount += 1;
    }

    // Count enrollments by cluster
    const enrollments = await db.enrollment.findMany({
      where: { status: { in: ['ENROLLED', 'COMPLETED'] } },
      include: {
        skillProgram: {
          select: {
            cluster: true,
          },
        },
      },
    });

    for (const enrollment of enrollments) {
      const cluster = enrollment.skillProgram?.cluster;
      if (!cluster) continue;

      if (!clusterData[cluster]) {
        clusterData[cluster] = {
          cluster,
          clusterLabel: CLUSTER_LABELS[cluster] || cluster,
          revenue: 0,
          enrollments: 0,
          paymentCount: 0,
        };
      }

      clusterData[cluster].enrollments += 1;
    }

    // Convert to array and sort by revenue descending
    const result = Object.values(clusterData).sort(
      (a, b) => b.revenue - a.revenue
    );

    // Calculate totals
    const totalRevenue = result.reduce((sum, item) => sum + item.revenue, 0);
    const totalEnrollments = result.reduce(
      (sum, item) => sum + item.enrollments,
      0
    );
    const totalPayments = result.reduce(
      (sum, item) => sum + item.paymentCount,
      0
    );

    return NextResponse.json({
      پیام: 'داده‌های درآمد بر اساس خوشه با موفقیت دریافت شد',
      داده‌ها: {
        clusters: result,
        totals: {
          revenue: totalRevenue,
          enrollments: totalEnrollments,
          paymentCount: totalPayments,
          clusterCount: result.length,
        },
      },
    });
  } catch (error) {
    console.error('Error fetching revenue by cluster:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت داده‌های درآمد' },
      { status: 500 }
    );
  }
}
