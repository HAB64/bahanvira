import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/appointments — List appointments
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const leadId = searchParams.get('leadId');
    const assignedTo = searchParams.get('assignedTo');
    const dateFrom = searchParams.get('dateFrom');
    const dateTo = searchParams.get('dateTo');

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (type) where.type = type;
    if (leadId) where.leadId = leadId;
    if (assignedTo) where.assignedTo = assignedTo;
    if (dateFrom || dateTo) {
      where.startTime = {
        ...(dateFrom && { gte: new Date(dateFrom) }),
        ...(dateTo && { lte: new Date(dateTo) }),
      };
    }

    const appointments = await db.appointment.findMany({
      where,
      orderBy: { startTime: 'asc' },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    // Upcoming vs past split
    const now = new Date();
    const upcoming = appointments.filter(a => new Date(a.startTime) >= now && a.status !== 'CANCELLED');
    const past = appointments.filter(a => new Date(a.startTime) < now || a.status === 'CANCELLED');

    return NextResponse.json({
      پیام: 'لیست قرارها دریافت شد',
      داده‌ها: appointments,
      پیش‌رو: upcoming.length,
      گذشته: past.length,
    });
  } catch (error) {
    console.error('Appointments list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت قرارها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/appointments — Create appointment
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, description, leadId, karAmuzId, startTime, endTime, location, meetingUrl, type, assignedTo } = body;

    if (!title || !startTime || !endTime) {
      return NextResponse.json({ خطا: 'عنوان، زمان شروع و پایان الزامی است' }, { status: 400 });
    }

    const appointment = await db.appointment.create({
      data: {
        title,
        description: description || null,
        leadId: leadId || null,
        karAmuzId: karAmuzId || null,
        startTime: new Date(startTime),
        endTime: new Date(endTime),
        location: location || null,
        meetingUrl: meetingUrl || null,
        type: type || 'CONSULTATION',
        status: 'SCHEDULED',
        assignedTo: assignedTo || '',
      },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    return NextResponse.json({ پیام: 'قرار با موفقیت ثبت شد', داده: appointment }, { status: 201 });
  } catch (error) {
    console.error('Appointment creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت قرار' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/appointments — Update appointment
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { appointmentId, status, title, startTime, endTime, location, meetingUrl, assignedTo } = body;

    if (!appointmentId) return NextResponse.json({ خطا: 'شناسه قرار الزامی است' }, { status: 400 });

    const updateData: Record<string, unknown> = {};
    if (status) updateData.status = status;
    if (title) updateData.title = title;
    if (startTime) updateData.startTime = new Date(startTime);
    if (endTime) updateData.endTime = new Date(endTime);
    if (location !== undefined) updateData.location = location;
    if (meetingUrl !== undefined) updateData.meetingUrl = meetingUrl;
    if (assignedTo !== undefined) updateData.assignedTo = assignedTo;

    const updated = await db.appointment.update({
      where: { id: appointmentId }, data: updateData,
      include: { lead: { select: { id: true, name: true } }, karAmuz: { select: { id: true, firstName: true, lastName: true } } },
    });

    return NextResponse.json({ پیام: 'قرار به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Appointment update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی قرار' }, { status: 500 });
  }
}
