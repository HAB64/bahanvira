import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/geo — Geographic analysis endpoint
 * Returns leads with lat/lng coordinates, supports radius search, city distribution stats
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const lat = searchParams.get('lat');
    const lng = searchParams.get('lng');
    const radiusKm = searchParams.get('radiusKm');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '50', 10)));
    const skip = (page - 1) * limit;

    // Base query: only leads with coordinates
    const where: Record<string, unknown> = {
      latitude: { not: null },
      longitude: { not: null },
    };

    // Radius search
    if (lat && lng && radiusKm) {
      const centerLat = parseFloat(lat);
      const centerLng = parseFloat(lng);
      const radius = parseFloat(radiusKm);

      if (isNaN(centerLat) || isNaN(centerLng) || isNaN(radius)) {
        return NextResponse.json({ خطا: 'مختصات و شعاع باید عدد باشند' }, { status: 400 });
      }

      // Approximate degree offsets for radius search
      // 1 degree latitude ≈ 111 km, 1 degree longitude ≈ 111 * cos(lat) km
      const latOffset = radius / 111;
      const lngOffset = radius / (111 * Math.cos((centerLat * Math.PI) / 180));

      where.AND = [
        { latitude: { gte: centerLat - latOffset, lte: centerLat + latOffset } },
        { longitude: { gte: centerLng - lngOffset, lte: centerLng + lngOffset } },
      ];
    }

    // Get leads with coordinates
    const [leads, total] = await Promise.all([
      db.lead.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          name: true,
          phone: true,
          latitude: true,
          longitude: true,
          geoCity: true,
          stage: true,
          cluster: true,
          segment: true,
          score: true,
          createdAt: true,
        },
      }),
      db.lead.count({ where }),
    ]);

    // If radius search, filter with Haversine formula for accuracy
    let filteredLeads = leads;
    if (lat && lng && radiusKm) {
      const centerLat = parseFloat(lat);
      const centerLng = parseFloat(lng);
      const radius = parseFloat(radiusKm);

      filteredLeads = leads.filter((lead) => {
        if (!lead.latitude || !lead.longitude) return false;
        const dLat = ((lead.latitude - centerLat) * Math.PI) / 180;
        const dLng = ((lead.longitude - centerLng) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos((centerLat * Math.PI) / 180) *
            Math.cos((lead.latitude * Math.PI) / 180) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const distance = 6371 * c; // Earth radius in km
        return distance <= radius;
      });
    }

    // City distribution stats
    const cityStats = await db.lead.groupBy({
      by: ['geoCity'],
      where: {
        latitude: { not: null },
        longitude: { not: null },
      },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
    });

    // Stage distribution for geo leads
    const stageStats = await db.lead.groupBy({
      by: ['stage'],
      where: {
        latitude: { not: null },
        longitude: { not: null },
      },
      _count: { id: true },
    });

    // Cluster distribution for geo leads
    const clusterStats = await db.lead.groupBy({
      by: ['cluster'],
      where: {
        latitude: { not: null },
        longitude: { not: null },
      },
      _count: { id: true },
    });

    return NextResponse.json({
      پیام: 'تحلیل جغرافیایی با موفقیت دریافت شد',
      داده‌ها: filteredLeads,
      آمار_شهر: cityStats.reduce(
        (acc, s) => ({ ...acc, [s.geoCity || 'نامشخص']: s._count.id }),
        {} as Record<string, number>
      ),
      آمار_مرحله: stageStats.reduce(
        (acc, s) => ({ ...acc, [s.stage]: s._count.id }),
        {} as Record<string, number>
      ),
      آمار_خوشه: clusterStats.reduce(
        (acc, s) => ({ ...acc, [s.cluster || 'نامشخص']: s._count.id }),
        {} as Record<string, number>
      ),
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
      جستجوی_شعاعی: lat && lng && radiusKm ? {
        مرکز: { عرض: parseFloat(lat), طول: parseFloat(lng) },
        شعاع_کیلومتر: parseFloat(radiusKm),
        تعداد_نتایج: filteredLeads.length,
      } : null,
    });
  } catch (error) {
    console.error('Geo analysis error:', error);
    return NextResponse.json({ خطا: 'خطا در تحلیل جغرافیایی' }, { status: 500 });
  }
}
