import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';
import {
  enrollInDrip,
  processDripTriggers,
  processDueDripSteps,
  exitDripForLead,
  seedDefaultDripCampaigns,
  type DripTrigger,
} from '@/lib/crm/drip-engine';

/**
 * POST /api/crm/drip
 * عملیات مختلف drip campaign
 *
 * Actions:
 *   - enroll: ثبت‌نام لید در drip
 *   - trigger: پردازش trigger و ثبت‌نام خودکار
 *   - process: پردازش step های سررسیدشده (cron)
 *   - exit: خروج لید از drip
 *   - seed: ایجاد drip های پیش‌فرض
 */
export async function POST(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const body = await request.json();
    const { action } = body;

    switch (action) {
      case 'enroll': {
        const { dripCampaignId, leadId, karAmuzId } = body;
        if (!dripCampaignId || !leadId) {
          return NextResponse.json(
            { خطا: 'شناسه drip campaign و lead الزامی است' },
            { status: 400 }
          );
        }

        const result = await enrollInDrip(dripCampaignId, leadId, karAmuzId);
        if (!result) {
          return NextResponse.json(
            { خطا: 'ثبت‌نام در drip ممکن نیست (غیرفعال یا قبلاً ثبت‌نام شده)' },
            { status: 400 }
          );
        }

        return NextResponse.json({
          پیام: 'ثبت‌نام در drip campaign با موفقیت انجام شد',
          داده: result,
        });
      }

      case 'trigger': {
        const { trigger, leadId, context } = body;
        if (!trigger || !leadId) {
          return NextResponse.json(
            { خطا: 'نوع trigger و leadId الزامی است' },
            { status: 400 }
          );
        }

        const result = await processDripTriggers(
          trigger as DripTrigger,
          leadId,
          context
        );

        return NextResponse.json({
          پیام: `${result.enrolled.length} drip campaign فعال شد`,
          داده: result,
        });
      }

      case 'process': {
        // پردازش step های سررسیدشده — فراخوانی از cron
        const result = await processDueDripSteps();

        return NextResponse.json({
          پیام: `${result.processed} drip step پردازش شد`,
          داده: result,
        });
      }

      case 'exit': {
        const { leadId, reason } = body;
        if (!leadId || !reason) {
          return NextResponse.json(
            { خطا: 'leadId و reason الزامی است' },
            { status: 400 }
          );
        }

        const result = await exitDripForLead(
          leadId,
          reason as 'REPLY' | 'ENROLL' | 'STAGE_CHANGE' | 'MANUAL' | 'UNSUBSCRIBE'
        );

        return NextResponse.json({
          پیام: `${result.exited} drip campaign متوقف شد`,
          داده: result,
        });
      }

      case 'seed': {
        await seedDefaultDripCampaigns();
        return NextResponse.json({ پیام: 'Drip campaign های پیش‌فرض ایجاد شدند' });
      }

      default:
        return NextResponse.json(
          { خطا: `عملیات "${action}" پشتیبانی نمی‌شود. عملیات مجاز: enroll, trigger, process, exit, seed` },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('[Drip API Error]', error);
    return NextResponse.json(
      { خطا: 'خطا در پردازش درخواست drip campaign' },
      { status: 500 }
    );
  }
}

/**
 * GET /api/crm/drip
 * لیست drip campaign ها و آمار
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const trigger = searchParams.get('trigger');

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (trigger) where.trigger = trigger;

    const drips = await db.dripCampaign.findMany({
      where,
      include: {
        _count: { select: { enrollments: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    // آمار کلی
    const [totalActive, totalEnrollments, totalCompleted, totalConverted] = await Promise.all([
      db.dripEnrollment.count({ where: { status: 'ACTIVE' } }),
      db.dripEnrollment.count(),
      db.dripEnrollment.count({ where: { status: 'COMPLETED' } }),
      db.dripEnrollment.count({ where: { convertedAt: { not: null } } }),
    ]);

    return NextResponse.json({
      پیام: 'لیست drip campaign ها',
      داده‌ها: drips,
      آمار: {
        enrollments_فعال: totalActive,
        کل_enrollments: totalEnrollments,
        تکمیل‌شده: totalCompleted,
        تبدیل‌شده: totalConverted,
        نرخ_تبدیل: totalCompleted > 0 ? Math.round((totalConverted / totalCompleted) * 100) : 0,
      },
    });
  } catch (error) {
    console.error('[Drip GET API Error]', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست drip campaign' },
      { status: 500 }
    );
  }
}
