import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
// GET: List projects with filters
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const karAmuzId = request.nextUrl.searchParams.get('karAmuzId');
    const skillProgramId = request.nextUrl.searchParams.get('skillProgramId');
    const status = request.nextUrl.searchParams.get('status');

    const where: Record<string, unknown> = {};
    if (karAmuzId) where.karAmuzId = karAmuzId;
    if (skillProgramId) where.skillProgramId = skillProgramId;
    if (status) where.status = status;

    const projects = await db.studentProject.findMany({
      where,
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            studentCode: true,
          },
        },
        skillProgram: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: { submittedAt: 'desc' },
    });

    return NextResponse.json({
      پیام: 'پروژه‌ها با موفقیت دریافت شد',
      داده‌ها: projects,
    });
  } catch (error) {
    console.error('Error fetching projects:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت پروژه‌ها' },
      { status: 500 }
    );
  }
}

// POST: Create project entry
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      karAmuzId,
      skillProgramId,
      title,
      description,
      fileUrl,
      fileName,
      fileSize,
      fileType,
    } = body;

    if (!karAmuzId || !skillProgramId || !title) {
      return NextResponse.json(
        { خطا: 'شناسه کارآموز، دوره مهارتی و عنوان پروژه الزامی است' },
        { status: 400 }
      );
    }

    // Check if karAmuz exists
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Check if skillProgram exists
    const skillProgram = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
    });

    if (!skillProgram) {
      return NextResponse.json(
        { خطا: 'دوره مهارتی مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const project = await db.studentProject.create({
      data: {
        karAmuzId,
        skillProgramId,
        title,
        description: description || null,
        fileUrl: fileUrl || null,
        fileName: fileName || null,
        fileSize: fileSize || null,
        fileType: fileType || null,
        status: 'SUBMITTED',
      },
      include: {
        karAmuz: {
          select: {
            firstName: true,
            lastName: true,
          },
        },
        skillProgram: {
          select: {
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'پروژه با موفقیت ثبت شد',
      داده‌ها: project,
    });
  } catch (error) {
    console.error('Error creating project:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت پروژه' },
      { status: 500 }
    );
  }
}

// PATCH: Review project
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status, score, reviewNotes, reviewerName } = body;

    if (!id) {
      return NextResponse.json(
        { خطا: 'شناسه پروژه الزامی است' },
        { status: 400 }
      );
    }

    const project = await db.studentProject.findUnique({
      where: { id },
    });

    if (!project) {
      return NextResponse.json(
        { خطا: 'پروژه مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const validStatuses = [
      'SUBMITTED',
      'UNDER_REVIEW',
      'APPROVED',
      'REJECTED',
      'NEEDS_REVISION',
    ];

    const updateData: Record<string, unknown> = {};

    if (status) {
      if (!validStatuses.includes(status)) {
        return NextResponse.json(
          { خطا: 'وضعیت نامعتبر است' },
          { status: 400 }
        );
      }
      updateData.status = status;
    }

    if (score !== undefined) {
      if (score < 0 || score > project.maxScore) {
        return NextResponse.json(
          { خطا: `نمره باید بین ۰ و ${project.maxScore} باشد` },
          { status: 400 }
        );
      }
      updateData.score = score;
    }

    if (reviewNotes !== undefined) {
      updateData.reviewNotes = reviewNotes;
    }

    if (reviewerName !== undefined) {
      updateData.reviewerName = reviewerName;
    }

    // Set reviewedAt if status changes to a review state
    if (
      status &&
      ['UNDER_REVIEW', 'APPROVED', 'REJECTED', 'NEEDS_REVISION'].includes(status)
    ) {
      updateData.reviewedAt = new Date();
    }

    const updated = await db.studentProject.update({
      where: { id },
      data: updateData,
      include: {
        karAmuz: {
          select: {
            firstName: true,
            lastName: true,
          },
        },
        skillProgram: {
          select: {
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'پروژه با موفقیت بررسی شد',
      داده‌ها: updated,
    });
  } catch (error) {
    console.error('Error reviewing project:', error);
    return NextResponse.json(
      { خطا: 'خطا در بررسی پروژه' },
      { status: 500 }
    );
  }
}
