import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
// GET: List waitlist entries with filters
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const skillProgramId = request.nextUrl.searchParams.get('skillProgramId');
    const status = request.nextUrl.searchParams.get('status');

    const where: Record<string, unknown> = {};
    if (skillProgramId) where.skillProgramId = skillProgramId;
    if (status) where.status = status;

    const entries = await db.waitlistEntry.findMany({
      where,
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            email: true,
          },
        },
        skillProgram: {
          select: {
            id: true,
            name: true,
            capacity: true,
          },
        },
        lead: {
          select: {
            id: true,
            name: true,
            phone: true,
          },
        },
      },
      orderBy: [{ priority: 'desc' }, { createdAt: 'asc' }],
    });

    return NextResponse.json({
      پیام: 'لیست انتظار با موفقیت دریافت شد',
      داده‌ها: entries,
    });
  } catch (error) {
    console.error('Error fetching waitlist:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت لیست انتظار', جزئیات: errorMessage },
      { status: 500 }
    );
  }
}

// POST: Add to waitlist
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { karAmuzId, skillProgramId, priority, notes, leadId } = body;

    if (!karAmuzId || !skillProgramId) {
      return NextResponse.json(
        { خطا: 'شناسه کارآموز و دوره مهارتی الزامی است' },
        { status: 400 }
      );
    }

    // Check if karAmuz exists
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Check if skillProgram exists
    const skillProgram = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
    });

    if (!skillProgram) {
      return NextResponse.json(
        { خطا: 'دوره مهارتی مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Check if already in waitlist for this program
    const existing = await db.waitlistEntry.findUnique({
      where: {
        karAmuzId_skillProgramId: {
          karAmuzId,
          skillProgramId,
        },
      },
    });

    if (existing) {
      return NextResponse.json(
        { خطا: 'این کارآموز قبلاً در لیست انتظار این دوره ثبت شده است' },
        { status: 400 }
      );
    }

    // Check if already enrolled
    const enrollment = await db.enrollment.findUnique({
      where: {
        karAmuzId_skillProgramId: {
          karAmuzId,
          skillProgramId,
        },
      },
    });

    if (enrollment && enrollment.status === 'ENROLLED') {
      return NextResponse.json(
        { خطا: 'این کارآموز قبلاً در این دوره ثبت‌نام شده است' },
        { status: 400 }
      );
    }

    const entry = await db.waitlistEntry.create({
      data: {
        karAmuzId,
        skillProgramId,
        leadId: leadId || karAmuz.leadId,
        priority: priority || 0,
        notes: notes || null,
        status: 'WAITING',
      },
      include: {
        karAmuz: {
          select: {
            firstName: true,
            lastName: true,
            phone: true,
          },
        },
        skillProgram: {
          select: {
            name: true,
          },
        },
      },
    });

    return NextResponse.json({
      پیام: 'با موفقیت به لیست انتظار اضافه شد',
      داده‌ها: entry,
    });
  } catch (error) {
    console.error('Error adding to waitlist:', error);
    return NextResponse.json(
      { خطا: 'خطا در افزودن به لیست انتظار' },
      { status: 500 }
    );
  }
}

// PATCH: Update waitlist entry status
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status } = body;

    if (!id || !status) {
      return NextResponse.json(
        { خطا: 'شناسه و وضعیت الزامی است' },
        { status: 400 }
      );
    }

    const validStatuses = ['WAITING', 'NOTIFIED', 'ENROLLED', 'CANCELLED'];
    if (!validStatuses.includes(status)) {
      return NextResponse.json(
        { خطا: 'وضعیت نامعتبر است' },
        { status: 400 }
      );
    }

    const entry = await db.waitlistEntry.findUnique({
      where: { id },
    });

    if (!entry) {
      return NextResponse.json(
        { خطا: 'مورد لیست انتظار یافت نشد' },
        { status: 404 }
      );
    }

    const updateData: Record<string, unknown> = { status };

    if (status === 'NOTIFIED') {
      updateData.notifiedAt = new Date();
    }

    if (status === 'ENROLLED') {
      updateData.enrolledAt = new Date();
    }

    const updated = await db.waitlistEntry.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({
      پیام: 'وضعیت لیست انتظار با موفقیت بروزرسانی شد',
      داده‌ها: updated,
    });
  } catch (error) {
    console.error('Error updating waitlist entry:', error);
    return NextResponse.json(
      { خطا: 'خطا در بروزرسانی لیست انتظار' },
      { status: 500 }
    );
  }
}
