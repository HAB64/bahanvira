import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/tickets/sla
 * Check SLA compliance for all open tickets.
 * Returns tickets that are approaching or breaching SLA thresholds.
 *
 * SLA Thresholds (configurable via SiteSetting in the future):
 * - First response: 2 hours (OPEN → IN_PROGRESS)
 * - Resolution: 48 hours from creation
 * - Urgent first response: 30 minutes
 * - Urgent resolution: 24 hours
 */
export async function GET() {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const now = new Date();

    // Fetch open/in-progress tickets
    const activeTickets = await db.ticket.findMany({
      where: {
        status: { in: ['OPEN', 'IN_PROGRESS', 'WAITING_CUSTOMER'] },
      },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
        responses: { orderBy: { createdAt: 'asc' }, take: 1 },
      },
      orderBy: { createdAt: 'asc' },
    });

    const slaBreaches: Array<{
      ticketId: string;
      subject: string;
      breachType: string;
      minutesOverdue: number;
      priority: string;
      assignedTo: string;
      leadName: string;
      leadPhone: string;
    }> = [];

    const slaWarnings: Array<{
      ticketId: string;
      subject: string;
      warningType: string;
      minutesRemaining: number;
      priority: string;
      assignedTo: string;
    }> = [];

    for (const ticket of activeTickets) {
      const createdDate = new Date(ticket.createdAt);
      const isUrgent = ticket.priority === 'URGENT';
      const firstResponseHours = isUrgent ? 0.5 : 2; // 30min or 2hr
      const resolutionHours = isUrgent ? 24 : 48;

      // Check first response SLA
      if (!ticket.firstResponseAt) {
        const minutesSinceCreation = (now.getTime() - createdDate.getTime()) / (1000 * 60);
        const firstResponseMinutes = firstResponseHours * 60;

        if (minutesSinceCreation > firstResponseMinutes) {
          slaBreaches.push({
            ticketId: ticket.id,
            subject: ticket.subject,
            breachType: 'FIRST_RESPONSE',
            minutesOverdue: Math.round(minutesSinceCreation - firstResponseMinutes),
            priority: ticket.priority,
            assignedTo: ticket.assignedTo,
            leadName: ticket.lead?.name || (ticket.karAmuz ? `${ticket.karAmuz.firstName} ${ticket.karAmuz.lastName}` : ''),
            leadPhone: ticket.lead?.phone || ticket.karAmuz?.phone || '',
          });
        } else if (minutesSinceCreation > firstResponseMinutes * 0.75) {
          slaWarnings.push({
            ticketId: ticket.id,
            subject: ticket.subject,
            warningType: 'FIRST_RESPONSE_APPROACHING',
            minutesRemaining: Math.round(firstResponseMinutes - minutesSinceCreation),
            priority: ticket.priority,
            assignedTo: ticket.assignedTo,
          });
        }
      }

      // Check resolution SLA
      const minutesSinceCreation = (now.getTime() - createdDate.getTime()) / (1000 * 60);
      const resolutionMinutes = resolutionHours * 60;

      if (minutesSinceCreation > resolutionMinutes && ticket.status !== 'RESOLVED' && ticket.status !== 'CLOSED') {
        slaBreaches.push({
          ticketId: ticket.id,
          subject: ticket.subject,
          breachType: 'RESOLUTION',
          minutesOverdue: Math.round(minutesSinceCreation - resolutionMinutes),
          priority: ticket.priority,
          assignedTo: ticket.assignedTo,
          leadName: ticket.lead?.name || (ticket.karAmuz ? `${ticket.karAmuz.firstName} ${ticket.karAmuz.lastName}` : ''),
          leadPhone: ticket.lead?.phone || ticket.karAmuz?.phone || '',
        });
      } else if (minutesSinceCreation > resolutionMinutes * 0.75 && ticket.status !== 'RESOLVED') {
        slaWarnings.push({
          ticketId: ticket.id,
          subject: ticket.subject,
          warningType: 'RESOLUTION_APPROACHING',
          minutesRemaining: Math.round(resolutionMinutes - minutesSinceCreation),
          priority: ticket.priority,
          assignedTo: ticket.assignedTo,
        });
      }
    }

    // Summary stats
    const summary = {
      totalActive: activeTickets.length,
      breaches: slaBreaches.length,
      warnings: slaWarnings.length,
      urgentOpen: activeTickets.filter(t => t.priority === 'URGENT' && t.status === 'OPEN').length,
      avgFirstResponseMinutes: 0,
    };

    // Calculate average first response time
    const resolvedWithResponse = activeTickets.filter(t => t.firstResponseAt);
    if (resolvedWithResponse.length > 0) {
      const totalMinutes = resolvedWithResponse.reduce((sum, t) => {
        return sum + (new Date(t.firstResponseAt!).getTime() - new Date(t.createdAt).getTime()) / (1000 * 60);
      }, 0);
      summary.avgFirstResponseMinutes = Math.round(totalMinutes / resolvedWithResponse.length);
    }

    return NextResponse.json({
      پیام: 'بررسی SLA انجام شد',
      نقض_سطح_خدمات: slaBreaches,
      هشدارها: slaWarnings,
      خلاصه: summary,
    });
  } catch (error) {
    console.error('SLA check error:', error);
    return NextResponse.json({ خطا: 'خطا در بررسی SLA' }, { status: 500 });
  }
}
