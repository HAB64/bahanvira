import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/tickets/responses?ticketId=xxx
 * List responses for a ticket.
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const ticketId = searchParams.get('ticketId');

    if (!ticketId) {
      return NextResponse.json({ خطا: 'شناسه تیکت الزامی است' }, { status: 400 });
    }

    const responses = await db.ticketResponse.findMany({
      where: { ticketId },
      orderBy: { createdAt: 'asc' },
    });

    return NextResponse.json({
      پیام: 'پاسخ‌های تیکت با موفقیت دریافت شد',
      داده‌ها: responses,
    });
  } catch (error) {
    console.error('Ticket responses list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت پاسخ‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/tickets/responses
 * Add a response to a ticket.
 * Body: { ticketId, content, authorType, authorName, isInternal? }
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { ticketId, content, authorType, authorName, isInternal } = body;

    if (!ticketId || !content || !authorType || !authorName) {
      return NextResponse.json(
        { خطا: 'شناسه تیکت، متن پاسخ، نوع و نام نویسنده الزامی است' },
        { status: 400 }
      );
    }

    const validAuthorTypes = ['ADMIN', 'CUSTOMER', 'SYSTEM'];
    if (!validAuthorTypes.includes(authorType)) {
      return NextResponse.json({ خطا: 'نوع نویسنده نامعتبر است' }, { status: 400 });
    }

    const ticket = await db.ticket.findUnique({ where: { id: ticketId } });
    if (!ticket) {
      return NextResponse.json({ خطا: 'تیکت مورد نظر یافت نشد' }, { status: 404 });
    }

    const response = await db.ticketResponse.create({
      data: {
        ticketId,
        content,
        authorType,
        authorName,
        isInternal: isInternal || false,
      },
    });

    // Auto-update ticket status based on response
    if (authorType === 'ADMIN' && !isInternal && ticket.status === 'OPEN') {
      await db.ticket.update({
        where: { id: ticketId },
        data: { status: 'IN_PROGRESS', firstResponseAt: ticket.firstResponseAt || new Date() },
      });
    } else if (authorType === 'CUSTOMER' && ticket.status === 'WAITING_CUSTOMER') {
      await db.ticket.update({
        where: { id: ticketId },
        data: { status: 'IN_PROGRESS' },
      });
    } else if (authorType === 'ADMIN' && !isInternal && ticket.status === 'RESOLVED') {
      await db.ticket.update({
        where: { id: ticketId },
        data: { status: 'IN_PROGRESS' },
      });
    }

    return NextResponse.json(
      { پیام: 'پاسخ با موفقیت ثبت شد', داده: response },
      { status: 201 }
    );
  } catch (error) {
    console.error('Ticket response creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت پاسخ' }, { status: 500 });
  }
}
