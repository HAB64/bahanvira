import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/tickets
 * List tickets with filtering, sorting, and pagination.
 * Query params: status, priority, category, assignedTo, leadId, karAmuzId, search, sort, order, page, limit
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);

    const status = searchParams.get('status');
    const priority = searchParams.get('priority');
    const category = searchParams.get('category');
    const assignedTo = searchParams.get('assignedTo');
    const leadId = searchParams.get('leadId');
    const karAmuzId = searchParams.get('karAmuzId');
    const search = searchParams.get('search');

    const sort = searchParams.get('sort') || 'createdAt';
    const order = searchParams.get('order') || 'desc';

    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (status) where.status = status;
    if (priority) where.priority = priority;
    if (category) where.category = category;
    if (assignedTo) where.assignedTo = assignedTo;
    if (leadId) where.leadId = leadId;
    if (karAmuzId) where.karAmuzId = karAmuzId;

    if (search) {
      where.OR = [
        { subject: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    const allowedSortFields = ['createdAt', 'subject', 'priority', 'status', 'category', 'updatedAt'];
    const sortField = allowedSortFields.includes(sort) ? sort : 'createdAt';
    const sortOrder = order === 'asc' ? 'asc' : 'desc';

    const [tickets, total] = await Promise.all([
      db.ticket.findMany({
        where,
        orderBy: { [sortField]: sortOrder },
        skip,
        take: limit,
        include: {
          lead: { select: { id: true, name: true, phone: true } },
          karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
          responses: { orderBy: { createdAt: 'desc' }, take: 1 },
          _count: { select: { responses: true } },
        },
      }),
      db.ticket.count({ where }),
    ]);

    // Summary stats
    const stats = await db.ticket.groupBy({
      by: ['status'],
      _count: { id: true },
    });

    return NextResponse.json({
      پیام: 'لیست تیکت‌ها با موفقیت دریافت شد',
      داده‌ها: tickets,
      آمار: stats.reduce((acc, s) => ({ ...acc, [s.status]: s._count.id }), {} as Record<string, number>),
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Tickets list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت لیست تیکت‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/tickets
 * Create a new ticket.
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      subject, description, category, priority, leadId, karAmuzId,
      assignedTo, source, sourceId,
    } = body;

    if (!subject || !description) {
      return NextResponse.json(
        { خطا: 'موضوع و توضیحات تیکت الزامی است' },
        { status: 400 }
      );
    }

    const ticket = await db.ticket.create({
      data: {
        subject,
        description,
        category: category || 'GENERAL',
        priority: priority || 'MEDIUM',
        status: 'OPEN',
        leadId: leadId || null,
        karAmuzId: karAmuzId || null,
        assignedTo: assignedTo || '',
        source: source || 'ADMIN',
        sourceId: sourceId || null,
      },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    return NextResponse.json(
      { پیام: 'تیکت با موفقیت ایجاد شد', داده: ticket },
      { status: 201 }
    );
  } catch (error) {
    console.error('Ticket creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت تیکت' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/tickets
 * Update ticket status, priority, assignment, or resolution.
 * Body: { ticketId, status?, priority?, assignedTo?, resolution?, satisfactionRating? }
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { ticketId, status, priority, assignedTo, resolution, satisfactionRating } = body;

    if (!ticketId) {
      return NextResponse.json({ خطا: 'شناسه تیکت الزامی است' }, { status: 400 });
    }

    const existing = await db.ticket.findUnique({ where: { id: ticketId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'تیکت مورد نظر یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};

    if (status) {
      const validStatuses = ['OPEN', 'IN_PROGRESS', 'WAITING_CUSTOMER', 'RESOLVED', 'CLOSED'];
      if (!validStatuses.includes(status)) {
        return NextResponse.json({ خطا: `وضعیت نامعتبر. مقادیر مجاز: ${validStatuses.join(', ')}` }, { status: 400 });
      }
      updateData.status = status;

      // Auto-set timestamps
      if (status === 'IN_PROGRESS' && !existing.firstResponseAt) {
        updateData.firstResponseAt = new Date();
      }
      if (status === 'RESOLVED') {
        updateData.resolvedAt = new Date();
      }
      if (status === 'CLOSED') {
        updateData.closedAt = new Date();
        if (!existing.resolvedAt) updateData.resolvedAt = new Date();
      }
    }

    if (priority) updateData.priority = priority;
    if (assignedTo !== undefined) updateData.assignedTo = assignedTo;
    if (resolution !== undefined) updateData.resolution = resolution;
    if (satisfactionRating !== undefined) updateData.satisfactionRating = satisfactionRating;

    const updated = await db.ticket.update({
      where: { id: ticketId },
      data: updateData,
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
        responses: { orderBy: { createdAt: 'desc' } },
      },
    });

    return NextResponse.json({
      پیام: 'تیکت با موفقیت به‌روزرسانی شد',
      داده: updated,
    });
  } catch (error) {
    console.error('Ticket update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی تیکت' }, { status: 500 });
  }
}
