import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { siteConfig } from '@/config/site';

import { getAdminSession } from '@/lib/admin-auth';
interface RouteParams {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/crm/invoices/[id]/pdf
 * Generates a printable HTML invoice that can be saved as PDF via browser print.
 */
export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { id } = await params;

    const invoice = await db.invoice.findUnique({
      where: { id },
      include: {
        lead: { select: { id: true, name: true, phone: true, email: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true, email: true, nationalId: true } },
      },
    });

    if (!invoice) {
      return NextResponse.json({ خطا: 'فاکتور یافت نشد' }, { status: 404 });
    }

    const items = (invoice.items as Array<{ title: string; description?: string; quantity: number; unitPrice: number; total: number }>) || [];
    const customerName = invoice.lead?.name || (invoice.karAmuz ? `${invoice.karAmuz.firstName} ${invoice.karAmuz.lastName}` : '—');
    const customerPhone = invoice.lead?.phone || invoice.karAmuz?.phone || '—';
    const customerEmail = invoice.lead?.email || invoice.karAmuz?.email || '';

    const statusMap: Record<string, { label: string; color: string; bg: string }> = {
      DRAFT: { label: 'پیش‌نویس', color: '#4b5563', bg: '#f3f4f6' },
      SENT: { label: 'ارسال شده', color: '#1d4ed8', bg: '#dbeafe' },
      PAID: { label: 'پرداخت شده', color: '#15803d', bg: '#dcfce7' },
      PARTIALLY_PAID: { label: 'پرداخت جزئی', color: '#a16207', bg: '#fef3c7' },
      CANCELLED: { label: 'لغو شده', color: '#b91c1c', bg: '#fee2e2' },
      REFUNDED: { label: 'بازگشت وجه', color: '#7e22ce', bg: '#f3e8ff' },
    };
    const statusInfo = statusMap[invoice.status] || statusMap.DRAFT;

    const formatRials = (n: number) => n.toLocaleString('fa-IR') + ' ریال';
    const formatDate = (d: string | Date | null) => {
      if (!d) return '—';
      return new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(d));
    };

    const issuedAt = invoice.issuedAt ? formatDate(invoice.issuedAt) : formatDate(invoice.createdAt);
    const dueDate = invoice.dueDate ? formatDate(invoice.dueDate) : '—';
    const remaining = invoice.totalAmount - invoice.paidAmount;

    const html = `<!DOCTYPE html>
<html dir="rtl" lang="fa">
<head>
  <meta charset="UTF-8">
  <title>فاکتور ${invoice.invoiceNumber}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap');
    
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    body {
      font-family: 'Vazirmatn', 'Tahoma', sans-serif;
      direction: rtl;
      color: #1f2937;
      background: #fff;
      font-size: 13px;
      line-height: 1.7;
    }

    @media print {
      body { margin: 0; }
      .no-print { display: none !important; }
      .page-container { box-shadow: none !important; margin: 0 !important; }
    }

    .page-container {
      max-width: 800px;
      margin: 20px auto;
      background: #fff;
      padding: 40px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }

    /* Header */
    .header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 32px;
      padding-bottom: 24px;
      border-bottom: 3px solid #0d9488;
    }

    .company-info {
      text-align: right;
    }

    .company-name {
      font-size: 22px;
      font-weight: 800;
      color: #0d9488;
      margin-bottom: 4px;
    }

    .company-subtitle {
      font-size: 11px;
      color: #6b7280;
      margin-bottom: 8px;
    }

    .company-contact {
      font-size: 11px;
      color: #9ca3af;
    }

    .invoice-badge {
      text-align: left;
    }

    .invoice-number {
      font-size: 16px;
      font-weight: 700;
      color: #374151;
      margin-bottom: 8px;
    }

    .invoice-date {
      font-size: 11px;
      color: #6b7280;
    }

    .status-badge {
      display: inline-block;
      padding: 4px 14px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
      color: ${statusInfo.color};
      background: ${statusInfo.bg};
      margin-top: 10px;
    }

    /* Customer Section */
    .customer-section {
      background: #f9fafb;
      border-radius: 10px;
      padding: 16px 20px;
      margin-bottom: 28px;
      border: 1px solid #e5e7eb;
    }

    .customer-section h3 {
      font-size: 12px;
      font-weight: 700;
      color: #6b7280;
      margin-bottom: 8px;
    }

    .customer-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 6px 24px;
    }

    .customer-field {
      font-size: 13px;
    }

    .customer-field span:first-child {
      color: #9ca3af;
      font-size: 11px;
    }

    .customer-field span:last-child {
      font-weight: 600;
      color: #374151;
      margin-right: 6px;
    }

    /* Items Table */
    .items-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 24px;
    }

    .items-table thead th {
      background: #0d9488;
      color: #fff;
      font-size: 11px;
      font-weight: 600;
      padding: 10px 14px;
      text-align: right;
    }

    .items-table thead th:first-child {
      border-radius: 0 8px 0 0;
    }

    .items-table thead th:last-child {
      border-radius: 8px 0 0 0;
      text-align: left;
    }

    .items-table tbody td {
      padding: 10px 14px;
      border-bottom: 1px solid #f3f4f6;
      font-size: 12px;
    }

    .items-table tbody tr:nth-child(even) {
      background: #f9fafb;
    }

    .items-table .item-desc {
      color: #9ca3af;
      font-size: 10px;
    }

    .items-table .text-left { text-align: left; }
    .items-table .text-center { text-align: center; }

    /* Totals */
    .totals-section {
      display: flex;
      justify-content: flex-start;
      margin-bottom: 32px;
    }

    .totals-box {
      min-width: 280px;
      margin-right: auto;
    }

    .total-row {
      display: flex;
      justify-content: space-between;
      padding: 6px 0;
      font-size: 12px;
    }

    .total-row.grand-total {
      border-top: 2px solid #0d9488;
      margin-top: 8px;
      padding-top: 10px;
      font-size: 15px;
      font-weight: 800;
      color: #0d9488;
    }

    .total-row.discount {
      color: #dc2626;
    }

    .total-row.paid {
      color: #16a34a;
    }

    .total-row.remaining {
      color: #dc2626;
      font-weight: 700;
    }

    /* Footer */
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #e5e7eb;
      text-align: center;
    }

    .footer-thanks {
      font-size: 13px;
      font-weight: 600;
      color: #0d9488;
      margin-bottom: 6px;
    }

    .footer-info {
      font-size: 10px;
      color: #9ca3af;
    }

    .footer-contact {
      font-size: 10px;
      color: #9ca3af;
      margin-top: 8px;
    }

    /* Print Button */
    .print-btn {
      position: fixed;
      bottom: 20px;
      left: 20px;
      padding: 12px 24px;
      background: #0d9488;
      color: #fff;
      border: none;
      border-radius: 8px;
      font-family: 'Vazirmatn', sans-serif;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(13,148,136,0.3);
      z-index: 100;
    }

    .print-btn:hover {
      background: #0f766e;
    }

    /* Notes */
    .notes-section {
      background: #fffbeb;
      border: 1px solid #fde68a;
      border-radius: 8px;
      padding: 12px 16px;
      margin-bottom: 20px;
      font-size: 11px;
      color: #92400e;
    }

    .notes-section strong {
      display: block;
      margin-bottom: 4px;
    }
  </style>
</head>
<body>
  <button class="print-btn no-print" onclick="window.print()">📥 دانلود / چاپ PDF</button>

  <div class="page-container">
    <!-- Header -->
    <div class="header">
      <div class="company-info">
        <div class="company-name">${siteConfig.name.fa}</div>
        <div class="company-subtitle">${siteConfig.institute.subtitle}</div>
        <div class="company-contact">
          ${siteConfig.contact.address.cityCountryEn}<br>
          تلفن: ${siteConfig.contact.phoneDisplay} | ایمیل: ${siteConfig.contact.email}
        </div>
      </div>
      <div class="invoice-badge">
        <div class="invoice-number">فاکتور ${invoice.invoiceNumber}</div>
        <div class="invoice-date">تاریخ صدور: ${issuedAt}</div>
        <div class="invoice-date">سررسید: ${dueDate}</div>
        <div class="status-badge">${statusInfo.label}</div>
      </div>
    </div>

    <!-- Customer Info -->
    <div class="customer-section">
      <h3>اطلاعات مشتری</h3>
      <div class="customer-grid">
        <div class="customer-field">
          <span>نام:</span>
          <span>${customerName}</span>
        </div>
        <div class="customer-field">
          <span>شماره تماس:</span>
          <span>${customerPhone}</span>
        </div>
        ${customerEmail ? `<div class="customer-field">
          <span>ایمیل:</span>
          <span>${customerEmail}</span>
        </div>` : ''}
        ${invoice.karAmuz?.nationalId ? `<div class="customer-field">
          <span>کد ملی:</span>
          <span>${invoice.karAmuz.nationalId}</span>
        </div>` : ''}
      </div>
    </div>

    <!-- Items Table -->
    <table class="items-table">
      <thead>
        <tr>
          <th style="width: 40%">شرح</th>
          <th style="width: 15%" class="text-center">تعداد</th>
          <th style="width: 20%" class="text-center">قیمت واحد</th>
          <th style="width: 25%" class="text-left">جمع</th>
        </tr>
      </thead>
      <tbody>
        ${items.map((item, idx) => `
        <tr>
          <td>
            <div>${item.title || '—'}</div>
            ${item.description ? `<div class="item-desc">${item.description}</div>` : ''}
          </td>
          <td class="text-center">${item.quantity.toLocaleString('fa-IR')}</td>
          <td class="text-center">${formatRials(item.unitPrice)}</td>
          <td class="text-left" style="font-weight: 600;">${formatRials(item.total)}</td>
        </tr>
        `).join('')}
      </tbody>
    </table>

    <!-- Totals -->
    <div class="totals-section">
      <div class="totals-box">
        <div class="total-row">
          <span>جمع کل:</span>
          <span>${formatRials(invoice.subtotal)}</span>
        </div>
        ${invoice.discountPct > 0 ? `
        <div class="total-row discount">
          <span>تخفیف (${invoice.discountPct.toLocaleString('fa-IR')}٪):</span>
          <span>-${formatRials(invoice.discountAmount)}</span>
        </div>
        ` : ''}
        <div class="total-row">
          <span>مالیات (۹٪):</span>
          <span>${formatRials(invoice.taxAmount)}</span>
        </div>
        <div class="total-row grand-total">
          <span>مبلغ نهایی:</span>
          <span>${formatRials(invoice.totalAmount)}</span>
        </div>
        ${invoice.paidAmount > 0 ? `
        <div class="total-row paid">
          <span>پرداخت شده:</span>
          <span>${formatRials(invoice.paidAmount)}</span>
        </div>
        ` : ''}
        ${remaining > 0 ? `
        <div class="total-row remaining">
          <span>مانده:</span>
          <span>${formatRials(remaining)}</span>
        </div>
        ` : ''}
      </div>
    </div>

    <!-- Notes -->
    ${invoice.notes ? `
    <div class="notes-section">
      <strong>📝 یادداشت:</strong>
      ${invoice.notes}
    </div>
    ` : ''}

    <!-- Footer -->
    <div class="footer">
      <div class="footer-thanks">با تشکر از اعتماد شما</div>
      <div class="footer-info">این فاکتور به صورت الکترونیکی صادر شده و اعتبار قانونی دارد.</div>
      <div class="footer-contact">
        ${siteConfig.name.fa} | ${siteConfig.contact.address.cityCountryEn} | ${siteConfig.contact.phoneDisplay} | ${siteConfig.contact.email}
      </div>
    </div>
  </div>

  <script>
    // Auto-focus for immediate print shortcut (Ctrl+P)
    document.addEventListener('keydown', function(e) {
      if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        window.print();
      }
    });
  </script>
</body>
</html>`;

    return new NextResponse(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
    });
  } catch (error) {
    console.error('Invoice PDF error:', error);
    return NextResponse.json(
      { خطا: 'خطا در تولید فاکتور PDF' },
      { status: 500 }
    );
  }
}
