import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/invoices — List invoices
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const leadId = searchParams.get('leadId');
    const karAmuzId = searchParams.get('karAmuzId');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (leadId) where.leadId = leadId;
    if (karAmuzId) where.karAmuzId = karAmuzId;
    if (search) {
      where.OR = [
        { invoiceNumber: { contains: search, mode: 'insensitive' } },
        { notes: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [invoices, total] = await Promise.all([
      db.invoice.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          lead: { select: { id: true, name: true, phone: true } },
          karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
        },
      }),
      db.invoice.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست فاکتورها دریافت شد',
      داده‌ها: invoices,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Invoices list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت فاکتورها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/invoices — Create invoice (standalone or from quote)
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { quoteId, items, discountPct, notes, leadId, karAmuzId, dueDate, issuedAt } = body;

    let invoiceItems = items;
    let subtotal = 0;
    let discPct = discountPct || 0;
    let invoiceLeadId = leadId;
    let invoiceKarAmuzId = karAmuzId;

    // If creating from a quote
    if (quoteId) {
      const quote = await db.quote.findUnique({ where: { id: quoteId } });
      if (!quote) return NextResponse.json({ خطا: 'پیشنهاد یافت نشد' }, { status: 404 });
      if (quote.status === 'CONVERTED') return NextResponse.json({ خطا: 'این پیشنهاد قبلاً تبدیل شده' }, { status: 400 });

      invoiceItems = quote.items as unknown as typeof invoiceItems;
      subtotal = quote.subtotal;
      discPct = quote.discountPct;
      invoiceLeadId = quote.leadId;
      invoiceKarAmuzId = quote.karAmuzId;

      // Mark quote as converted
      await db.quote.update({ where: { id: quoteId }, data: { status: 'CONVERTED' } });
    }

    if (!invoiceItems || !Array.isArray(invoiceItems) || invoiceItems.length === 0) {
      return NextResponse.json({ خطا: 'حداقل یک آیتم الزامی است' }, { status: 400 });
    }

    // Generate invoice number: INV-YYYY-XXXX
    const currentYear = new Date().getFullYear();
    const lastInvoice = await db.invoice.findFirst({
      where: { invoiceNumber: { startsWith: `INV-${currentYear}-` } },
      orderBy: { invoiceNumber: 'desc' },
    });
    let seq = 1;
    if (lastInvoice?.invoiceNumber) {
      const parts = lastInvoice.invoiceNumber.split('-');
      seq = (parseInt(parts[2] || '0', 10) || 0) + 1;
    }
    const invoiceNumber = `INV-${currentYear}-${seq.toString().padStart(4, '0')}`;

    // Calculate totals if not from quote
    if (!quoteId) {
      subtotal = invoiceItems.reduce((sum: number, item: { total?: number; unitPrice?: number; quantity?: number }) =>
        sum + (item.total || (item.unitPrice || 0) * (item.quantity || 1)), 0);
    }

    const discountAmount = Math.round(subtotal * Number(discPct) / 100);
    const afterDiscount = subtotal - discountAmount;
    const taxAmount = Math.round(afterDiscount * 0.09);
    const totalAmount = afterDiscount + taxAmount;

    const invoice = await db.invoice.create({
      data: {
        invoiceNumber,
        leadId: invoiceLeadId || null,
        karAmuzId: invoiceKarAmuzId || null,
        items: invoiceItems,
        subtotal,
        discountPct: discPct,
        discountAmount,
        taxAmount,
        totalAmount,
        status: 'DRAFT',
        issuedAt: issuedAt ? new Date(issuedAt) : null,
        dueDate: dueDate ? new Date(dueDate) : null,
        notes: notes || null,
      },
      include: {
        lead: { select: { id: true, name: true, phone: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true } },
      },
    });

    return NextResponse.json({ پیام: 'فاکتور با موفقیت ایجاد شد', داده: invoice }, { status: 201 });
  } catch (error) {
    console.error('Invoice creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت فاکتور' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/invoices — Update invoice
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { invoiceId, status, notes, paidAmount, dueDate } = body;

    if (!invoiceId) return NextResponse.json({ خطا: 'شناسه فاکتور الزامی است' }, { status: 400 });

    const existing = await db.invoice.findUnique({ where: { id: invoiceId } });
    if (!existing) return NextResponse.json({ خطا: 'فاکتور یافت نشد' }, { status: 404 });

    const updateData: Record<string, unknown> = {};

    if (status) {
      const validStatuses = ['DRAFT', 'SENT', 'PAID', 'PARTIALLY_PAID', 'CANCELLED', 'REFUNDED'];
      if (!validStatuses.includes(status)) return NextResponse.json({ خطا: 'وضعیت نامعتبر' }, { status: 400 });
      updateData.status = status;
    }

    if (paidAmount !== undefined) {
      updateData.paidAmount = paidAmount;
      // Auto-update status based on paid amount
      if (paidAmount >= existing.totalAmount) {
        updateData.status = 'PAID';
      } else if (paidAmount > 0) {
        updateData.status = 'PARTIALLY_PAID';
      }
    }

    if (notes !== undefined) updateData.notes = notes;
    if (dueDate !== undefined) updateData.dueDate = dueDate ? new Date(dueDate) : null;

    const updated = await db.invoice.update({
      where: { id: invoiceId }, data: updateData,
      include: { lead: { select: { id: true, name: true } }, karAmuz: { select: { id: true, firstName: true, lastName: true } } },
    });

    return NextResponse.json({ پیام: 'فاکتور به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Invoice update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی فاکتور' }, { status: 500 });
  }
}
