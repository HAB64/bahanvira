import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
// GET: List installments for an invoice
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const invoiceId = request.nextUrl.searchParams.get('invoiceId');

    if (!invoiceId) {
      return NextResponse.json(
        { خطا: 'شناسه فاکتور الزامی است' },
        { status: 400 }
      );
    }

    const invoice = await db.invoice.findUnique({
      where: { id: invoiceId },
    });

    if (!invoice) {
      return NextResponse.json(
        { خطا: 'فاکتور مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    const installments = await db.installmentSchedule.findMany({
      where: { invoiceId },
      orderBy: { installmentNo: 'asc' },
    });

    // Calculate summary
    const totalAmount = installments.reduce((sum, i) => sum + i.amount, 0);
    const paidAmount = installments
      .filter((i) => i.status === 'PAID')
      .reduce((sum, i) => sum + i.amount, 0);
    const pendingAmount = installments
      .filter((i) => i.status === 'PENDING')
      .reduce((sum, i) => sum + i.amount, 0);
    const overdueAmount = installments
      .filter((i) => i.status === 'OVERDUE')
      .reduce((sum, i) => sum + i.amount, 0);

    return NextResponse.json({
      پیام: 'اقساط با موفقیت دریافت شد',
      داده‌ها: {
        invoiceId,
        invoiceNumber: invoice.invoiceNumber,
        totalAmount,
        paidAmount,
        pendingAmount,
        overdueAmount,
        installments,
      },
    });
  } catch (error) {
    console.error('Error fetching installments:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت اقساط' },
      { status: 500 }
    );
  }
}

// POST: Create installment schedule from an invoice
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { invoiceId, installments } = body;

    if (!invoiceId || !installments || !Array.isArray(installments)) {
      return NextResponse.json(
        { خطا: 'شناسه فاکتور و لیست اقساط الزامی است' },
        { status: 400 }
      );
    }

    // Validate each installment
    for (const inst of installments) {
      if (!inst.amount || !inst.dueDate) {
        return NextResponse.json(
          { خطا: 'مبلغ و سررسید هر قسط الزامی است' },
          { status: 400 }
        );
      }
      if (inst.amount <= 0) {
        return NextResponse.json(
          { خطا: 'مبلغ قسط باید بزرگتر از صفر باشد' },
          { status: 400 }
        );
      }
    }

    // Check invoice exists
    const invoice = await db.invoice.findUnique({
      where: { id: invoiceId },
    });

    if (!invoice) {
      return NextResponse.json(
        { خطا: 'فاکتور مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Delete existing installments for this invoice
    await db.installmentSchedule.deleteMany({
      where: { invoiceId },
    });

    // Create new installments
    const createdInstallments = await db.$transaction(
      installments.map((inst: { amount: number; dueDate: string }, index: number) =>
        db.installmentSchedule.create({
          data: {
            invoiceId,
            installmentNo: index + 1,
            amount: inst.amount,
            dueDate: new Date(inst.dueDate),
            status: 'PENDING',
          },
        })
      )
    );

    // Update invoice status to PARTIALLY_PAID if it was DRAFT
    if (invoice.status === 'DRAFT') {
      await db.invoice.update({
        where: { id: invoiceId },
        data: { status: 'SENT' },
      });
    }

    return NextResponse.json({
      پیام: 'جدول اقساط با موفقیت ایجاد شد',
      داده‌ها: {
        invoiceId,
        count: createdInstallments.length,
        totalAmount: createdInstallments.reduce((sum, i) => sum + i.amount, 0),
        installments: createdInstallments,
      },
    });
  } catch (error) {
    console.error('Error creating installments:', error);
    return NextResponse.json(
      { خطا: 'خطا در ایجاد جدول اقساط' },
      { status: 500 }
    );
  }
}
