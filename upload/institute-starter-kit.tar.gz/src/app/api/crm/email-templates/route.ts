import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/crm/email-templates — List email templates
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const isActive = searchParams.get('isActive');
    const search = searchParams.get('search');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (category) where.category = category;
    if (isActive !== null && isActive !== undefined) {
      where.isActive = isActive === 'true';
    }
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { subject: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [templates, total] = await Promise.all([
      db.emailTemplate.findMany({
        where, skip, take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      db.emailTemplate.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست قالب‌های ایمیل با موفقیت دریافت شد',
      داده‌ها: templates,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('Email templates list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت قالب‌های ایمیل' }, { status: 500 });
  }
}

/**
 * POST /api/crm/email-templates — Create email template
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, subject, body: emailBody, category, variables, isDefault, isActive } = body;

    if (!name || !subject || !emailBody) {
      return NextResponse.json({ خطا: 'نام، موضوع و محتوای ایمیل الزامی است' }, { status: 400 });
    }

    const template = await db.emailTemplate.create({
      data: {
        name,
        subject,
        body: emailBody,
        category: category || 'GENERAL',
        variables: variables || '',
        isDefault: isDefault || false,
        isActive: isActive !== undefined ? isActive : true,
      },
    });

    return NextResponse.json({ پیام: 'قالب ایمیل با موفقیت ایجاد شد', داده: template }, { status: 201 });
  } catch (error) {
    console.error('Email template creation error:', error);
    return NextResponse.json({ خطا: 'خطا در ثبت قالب ایمیل' }, { status: 500 });
  }
}

/**
 * PATCH /api/crm/email-templates — Update email template
 */
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { templateId, ...otherFields } = body;

    if (!templateId) {
      return NextResponse.json({ خطا: 'شناسه قالب الزامی است' }, { status: 400 });
    }

    const existing = await db.emailTemplate.findUnique({ where: { id: templateId } });
    if (!existing) {
      return NextResponse.json({ خطا: 'قالب ایمیل یافت نشد' }, { status: 404 });
    }

    const allowedFields = ['name', 'subject', 'body', 'category', 'variables', 'isDefault', 'isActive'];
    const updateData: Record<string, unknown> = {};
    for (const field of allowedFields) {
      if (otherFields[field] !== undefined) {
        updateData[field] = otherFields[field];
      }
    }

    const updated = await db.emailTemplate.update({
      where: { id: templateId },
      data: updateData,
    });

    return NextResponse.json({ پیام: 'قالب ایمیل با موفقیت به‌روزرسانی شد', داده: updated });
  } catch (error) {
    console.error('Email template update error:', error);
    return NextResponse.json({ خطا: 'خطا در به‌روزرسانی قالب ایمیل' }, { status: 500 });
  }
}
