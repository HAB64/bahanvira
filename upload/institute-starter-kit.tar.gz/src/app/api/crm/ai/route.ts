import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { siteConfig } from '@/config/site';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * POST /api/crm/ai
 * Unified AI endpoint with multiple actions:
 * - lead_score: Score a lead and predict enrollment probability
 * - suggest_response: Suggest a response for a conversation
 * - summarize: Summarize a conversation
 * - churn_risk: Predict churn risk for a lead
 * - upsell: Suggest upsell/cross-sell courses
 * - ticket_suggest: Suggest ticket response
 */
export async function POST(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const body = await request.json();
    const { action } = body;

    switch (action) {
      case 'lead_score':
        return await handleLeadScore(body);
      case 'suggest_response':
        return await handleSuggestResponse(body);
      case 'summarize':
        return await handleSummarize(body);
      case 'churn_risk':
        return await handleChurnRisk(body);
      case 'upsell':
        return await handleUpsell(body);
      case 'ticket_suggest':
        return await handleTicketSuggest(body);
      default:
        return await handleLeadScore(body);
    }
  } catch (error) {
    console.error('[AI] Error:', error);
    return NextResponse.json({ خطا: 'خطا در پردازش هوشمند' }, { status: 500 });
  }
}

async function handleLeadScore(body: { leadId?: string }) {
  const { leadId } = body;
  if (!leadId) {
    return NextResponse.json({ خطا: 'شناسه لید الزامی است' }, { status: 400 });
  }

  const lead = await db.lead.findUnique({
    where: { id: leadId },
    include: {
      activityLogs: { take: 10, orderBy: { createdAt: 'desc' } },
      tags: { include: { tag: true } },
      payments: true,
      _count: { select: { activityLogs: true, payments: true } },
    },
  });

  if (!lead) {
    return NextResponse.json({ خطا: 'لید یافت نشد' }, { status: 404 });
  }

  const leadContext = {
    name: lead.name, phone: lead.phone, email: lead.email, course: lead.course,
    cluster: lead.cluster, stage: lead.stage, currentScore: lead.score,
    source: lead.source, segment: lead.segment, lifetimeValue: lead.lifetimeValue,
    activityCount: lead._count.activityLogs, paymentCount: lead._count.payments,
    tags: lead.tags.map(t => t.tag.name),
    recentActivities: lead.activityLogs.map(a => ({ type: a.type, content: a.content.substring(0, 100) })),
  };

  let aiResult: { enrollmentProb: number; analysis: string; recommendations: string[] } | null = null;

  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: `شما تحلیلگر CRM ${siteConfig.name.fa} هستید. احتمال ثبت‌نام (0 تا 1) و پیشنهادها را به JSON بدهید: {"enrollmentProb": number, "analysis": string, "recommendations": string[]}` },
        { role: 'user', content: `اطلاعات لید:\n${JSON.stringify(leadContext, null, 2)}` },
      ],
      temperature: 0.3,
      max_tokens: 500,
    });

    const content = completion.choices[0]?.message?.content || '';
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) aiResult = JSON.parse(jsonMatch[0]);
  } catch (aiError) {
    console.warn('[AI] Lead scoring fallback:', aiError);
  }

  if (!aiResult) {
    let prob = lead.score / 100;
    if (lead.stage === 'ENROLLED') prob = 1.0;
    else if (lead.stage === 'INTERESTED') prob = Math.max(prob, 0.6);
    else if (lead.stage === 'CONTACTED') prob = Math.max(prob, 0.35);
    else if (lead.stage === 'REJECTED') prob = 0;

    const recommendations: string[] = [];
    if (lead.stage === 'NEW') recommendations.push('در اسرع وقت تماس بگیرید');
    if (!lead.email) recommendations.push('ایمیل را دریافت کنید');
    if (lead._count.activityLogs < 2) recommendations.push('تعامل بیشتری داشته باشید');

    aiResult = {
      enrollmentProb: Math.round(prob * 100) / 100,
      analysis: `امتیاز: ${lead.score}/100، مرحله: ${lead.stage}`,
      recommendations,
    };
  }

  await db.lead.update({
    where: { id: leadId },
    data: {
      enrollmentProb: aiResult.enrollmentProb,
      aiMetadata: { analysis: aiResult.analysis, recommendations: aiResult.recommendations, scoredAt: new Date().toISOString() },
    },
  });

  return NextResponse.json({ پیام: 'تحلیل لید انجام شد', داده: aiResult });
}

async function handleSuggestResponse(body: { conversationId?: string; messages?: { role: string; content: string }[] }) {
  const { conversationId, messages } = body;

  let conversationMessages = messages || [];
  if (conversationId) {
    const conv = await db.conversation.findUnique({
      where: { id: conversationId },
      include: { messages: { orderBy: { timestamp: 'asc' } } },
    });
    if (conv) {
      conversationMessages = conv.messages.map(m => ({
        role: m.speaker === 'CUSTOMER' ? 'user' : 'assistant',
        content: m.content,
      }));
    }
  }

  if (conversationMessages.length === 0) {
    return NextResponse.json({ خطا: 'پیامی برای تحلیل یافت نشد' }, { status: 400 });
  }

  let suggestion = '';
  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: `شما دستیار فروش ${siteConfig.name.fa} (${siteConfig.institute.typeFa}) در ${siteConfig.contact.address.cityFa} هستید. یک پاسخ حرفه‌ای فارسی بنویسید. مختصر و مفید.` },
        ...conversationMessages.slice(-10).map((m: { role: string; content: string }) => ({
          role: (m.role === 'user' ? 'user' : 'assistant') as 'user' | 'assistant',
          content: m.content,
        })),
      ],
      temperature: 0.5,
      max_tokens: 300,
    });
    suggestion = completion.choices[0]?.message?.content || '';
  } catch {
    suggestion = `با سلام،\nممنون از تماس شما. در اسرع وقت پاسخ خواهیم داد.\nبا تشکر، ${siteConfig.name.fa}`;
  }

  return NextResponse.json({ پیام: 'پیشنهاد تولید شد', داده: { suggestion } });
}

async function handleSummarize(body: { conversationId?: string; messages?: { role: string; content: string }[] }) {
  const { conversationId, messages } = body;

  let conversationMessages: string[] = (messages || []).map((m: { role: string; content: string }) => `${m.role}: ${m.content}`);
  let convId = conversationId;

  if (convId) {
    const conv = await db.conversation.findUnique({
      where: { id: convId },
      include: { messages: { orderBy: { timestamp: 'asc' } } },
    });
    if (conv) {
      conversationMessages = conv.messages.map(m => `${m.speaker}: ${m.content}`);
    }
  }

  if (conversationMessages.length === 0) {
    return NextResponse.json({ خطا: 'مکالمه‌ای یافت نشد' }, { status: 400 });
  }

  const conversationText = conversationMessages.join('\n');

  let result = { summary: '', keyTopics: '', sentiment: 'NEUTRAL', actionItems: '' };

  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: `مکالمه زیر را تحلیل کنید و به JSON پاسخ دهید: {"summary": "خلاصه فارسی", "keyTopics": "موضوع1، موضوع2", "sentiment": "POSITIVE|NEUTRAL|NEGATIVE|MIXED", "actionItems": "اقدام1، اقدام2"}` },
        { role: 'user', content: conversationText },
      ],
      temperature: 0.2,
      max_tokens: 500,
    });

    const content = completion.choices[0]?.message?.content || '';
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) result = { ...result, ...JSON.parse(jsonMatch[0]) };
  } catch {
    result.summary = conversationMessages.slice(-3).join(' | ').substring(0, 200);
    result.sentiment = 'NEUTRAL';
  }

  // Update conversation in DB if we have an ID
  if (convId) {
    await db.conversation.update({
      where: { id: convId },
      data: { summary: result.summary, sentiment: result.sentiment, keyTopics: result.keyTopics, actionItems: result.actionItems },
    });
  }

  return NextResponse.json({ پیام: 'خلاصه‌سازی انجام شد', داده: result });
}

async function handleChurnRisk(body: { leadId?: string }) {
  const { leadId } = body;
  if (!leadId) {
    return NextResponse.json({ خطا: 'شناسه لید الزامی است' }, { status: 400 });
  }

  const lead = await db.lead.findUnique({
    where: { id: leadId },
    include: { payments: true, activityLogs: { take: 5, orderBy: { createdAt: 'desc' } } },
  });

  if (!lead) {
    return NextResponse.json({ خطا: 'لید یافت نشد' }, { status: 404 });
  }

  const daysSinceContact = lead.lastContactedAt
    ? Math.floor((Date.now() - new Date(lead.lastContactedAt).getTime()) / 86400000)
    : 999;

  const overduePayments = lead.payments.filter(p => p.status === 'OVERDUE').length;

  let riskLevel = 'LOW';
  let reasoning = '';

  if (lead.segment === 'CHURNED' || lead.stage === 'REJECTED') {
    riskLevel = 'CRITICAL';
    reasoning = 'مشتری قبلاً ریزش کرده یا درخواست رد شده';
  } else if (daysSinceContact > 30 || overduePayments > 1) {
    riskLevel = 'HIGH';
    reasoning = `بیش از ${daysSinceContact} روز از آخرین تماس گذشته یا ${overduePayments} پرداخت سررسید گذشته`;
  } else if (daysSinceContact > 14 || lead.segment === 'AT_RISK') {
    riskLevel = 'MEDIUM';
    reasoning = `فاصله تماس ${daysSinceContact} روز یا بخش‌بندی در معرض خطر`;
  } else {
    reasoning = 'تماس منظم و وضعیت پایدار';
  }

  // Try AI analysis
  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: `تحلیل ریزش مشتری آموزشگاه فنی حرفه‌ای. JSON: {"riskLevel": "LOW|MEDIUM|HIGH|CRITICAL", "reasoning": "string", "recommendedActions": "string"}` },
        { role: 'user', content: JSON.stringify({ stage: lead.stage, segment: lead.segment, daysSinceContact, overduePayments, lifetimeValue: lead.lifetimeValue, score: lead.score }) },
      ],
      temperature: 0.2,
      max_tokens: 300,
    });
    const content = completion.choices[0]?.message?.content || '';
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      riskLevel = parsed.riskLevel || riskLevel;
      reasoning = parsed.reasoning || reasoning;
    }
  } catch { /* use fallback */ }

  return NextResponse.json({
    پیام: 'تحلیل ریزش انجام شد',
    داده: { riskLevel, reasoning, daysSinceContact, overduePayments },
  });
}

async function handleUpsell(body: { leadId?: string }) {
  const { leadId } = body;
  if (!leadId) {
    return NextResponse.json({ خطا: 'شناسه لید الزامی است' }, { status: 400 });
  }

  const lead = await db.lead.findUnique({
    where: { id: leadId },
    include: { payments: true },
  });

  if (!lead) {
    return NextResponse.json({ خطا: 'لید یافت نشد' }, { status: 404 });
  }

  // Get available skill programs
  const programs = await db.skillProgram.findMany({
    where: { isActive: true, cluster: lead.cluster || undefined },
    take: 5,
  });

  // Rule-based upsell suggestions
  const suggestions = programs.map(p => ({
    id: p.id,
    name: p.name,
    cluster: p.cluster,
    price: p.price,
    reason: lead.cluster === p.cluster ? 'مرتبط با علاقه‌مندی شما' : 'دوره محبوب',
  }));

  return NextResponse.json({
    پیام: 'پیشنهادهای فروش تولید شد',
    داده: { suggestions },
  });
}

async function handleTicketSuggest(body: { ticketId?: string }) {
  const { ticketId } = body;
  if (!ticketId) {
    return NextResponse.json({ خطا: 'شناسه تیکت الزامی است' }, { status: 400 });
  }

  const ticket = await db.ticket.findUnique({
    where: { id: ticketId },
    include: { responses: { orderBy: { createdAt: 'asc' } } },
  });

  if (!ticket) {
    return NextResponse.json({ خطا: 'تیکت یافت نشد' }, { status: 404 });
  }

  let suggestion = '';
  try {
    const ZAI = (await import('z-ai-web-dev-sdk')).default;
    const zai = await ZAI.create();
    const threadSummary = ticket.responses.map(r => `${r.authorType}: ${r.content}`).join('\n');
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: `شما پشتیبان ${siteConfig.name.fa} هستید. پاسخ حرفه‌ای فارسی بنویسید.` },
        { role: 'user', content: `موضوع: ${ticket.subject}\nتوضیحات: ${ticket.description}\nگفتگو:\n${threadSummary}` },
      ],
      temperature: 0.4,
      max_tokens: 300,
    });
    suggestion = completion.choices[0]?.message?.content || '';
  } catch {
    suggestion = 'با سلام،\nدرخواست شما دریافت شد و در حال بررسی می‌باشد.\nبا تشکر';
  }

  return NextResponse.json({ پیام: 'پیشنهاد تولید شد', داده: { suggestion } });
}
