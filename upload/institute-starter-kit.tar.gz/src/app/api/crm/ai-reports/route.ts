import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
/**
 * GET /api/crm/ai-reports — List reports with type filter
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const period = searchParams.get('period');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};
    if (type) where.type = type;
    if (period) where.period = period;

    const [reports, total] = await Promise.all([
      db.aIReport.findMany({
        where, skip, take: limit,
        orderBy: { generatedAt: 'desc' },
      }),
      db.aIReport.count({ where }),
    ]);

    return NextResponse.json({
      پیام: 'لیست گزارش‌ها با موفقیت دریافت شد',
      داده‌ها: reports,
      صفحه‌بندی: { صفحه: page, حجم: limit, کل: total, تعداد_صفحات: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error('AI reports list error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت گزارش‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/crm/ai-reports — Generate a new report
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { title, type, period } = body;

    if (!title) {
      return NextResponse.json({ خطا: 'عنوان گزارش الزامی است' }, { status: 400 });
    }

    const reportType = type || 'INSIGHT';
    const reportPeriod = period || 'MONTHLY';

    // Generate report data based on type
    const reportData: Record<string, unknown> = {};
    const now = new Date();

    if (reportType === 'PERFORMANCE') {
      const [totalLeads, enrolledLeads, totalRevenue, totalKarAmuz] = await Promise.all([
        db.lead.count(),
        db.lead.count({ where: { stage: 'ENROLLED' } }),
        db.payment.aggregate({ where: { status: 'PAID' }, _sum: { amount: true } }),
        db.karAmuz.count(),
      ]);
      reportData.totalLeads = totalLeads;
      reportData.enrolledLeads = enrolledLeads;
      reportData.conversionRate = totalLeads > 0 ? (enrolledLeads / totalLeads * 100).toFixed(1) : '0';
      reportData.totalRevenue = totalRevenue._sum.amount || 0;
      reportData.totalKarAmuz = totalKarAmuz;
    } else if (reportType === 'INSIGHT') {
      const stageDistribution = await db.lead.groupBy({ by: ['stage'], _count: { stage: true } });
      const segmentDistribution = await db.lead.groupBy({ by: ['segment'], _count: { segment: true } });
      const clusterDistribution = await db.lead.groupBy({ by: ['cluster'], _count: { cluster: true } });
      reportData.stageDistribution = stageDistribution;
      reportData.segmentDistribution = segmentDistribution;
      reportData.clusterDistribution = clusterDistribution;
    } else if (reportType === 'FORECAST') {
      const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const [thisMonthLeads, lastMonthLeads] = await Promise.all([
        db.lead.count({ where: { createdAt: { gte: thisMonth } } }),
        db.lead.count({ where: { createdAt: { gte: lastMonth, lt: thisMonth } } }),
      ]);
      const growthRate = lastMonthLeads > 0 ? ((thisMonthLeads - lastMonthLeads) / lastMonthLeads * 100).toFixed(1) : '0';
      reportData.thisMonthLeads = thisMonthLeads;
      reportData.lastMonthLeads = lastMonthLeads;
      reportData.growthRate = growthRate;
      reportData.forecastNextMonth = Math.round(thisMonthLeads * (1 + parseFloat(growthRate) / 100));
    } else if (reportType === 'ANOMALY') {
      // Find leads with unusual patterns
      const staleLeads = await db.lead.count({
        where: {
          stage: { in: ['CONTACTED', 'INTERESTED'] },
          lastContactedAt: { lt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        },
      });
      const overduePayments = await db.payment.count({ where: { status: 'OVERDUE' } });
      reportData.staleLeads = staleLeads;
      reportData.overduePayments = overduePayments;
    } else if (reportType === 'TREND') {
      // Monthly trend for last 6 months
      const months: { month: string; leads: number }[] = [];
      for (let i = 5; i >= 0; i--) {
        const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
        const count = await db.lead.count({ where: { createdAt: { gte: start, lt: end } } });
        months.push({ month: start.toISOString().slice(0, 7), leads: count });
      }
      reportData.monthlyTrend = months;
    }

    // Generate AI summary (rule-based for now)
    const summary = `گزارش ${reportType === 'INSIGHT' ? 'بینش' : reportType === 'FORECAST' ? 'پیش‌بینی' : reportType === 'ANOMALY' ? 'ناهنجاری' : reportType === 'PERFORMANCE' ? 'عملکرد' : 'روند'} برای دوره ${reportPeriod === 'DAILY' ? 'روزانه' : reportPeriod === 'WEEKLY' ? 'هفتگی' : reportPeriod === 'MONTHLY' ? 'ماهانه' : reportPeriod === 'QUARTERLY' ? 'فصلی' : 'سالانه'} تولید شد.`;

    const report = await db.aIReport.create({
      data: {
        title,
        type: reportType,
        period: reportPeriod,
        data: JSON.parse(JSON.stringify(reportData)),
        summary,
        generatedAt: new Date(),
      },
    });

    return NextResponse.json({ پیام: 'گزارش با موفقیت تولید شد', داده: report }, { status: 201 });
  } catch (error) {
    console.error('AI report create error:', error);
    return NextResponse.json({ خطا: 'خطا در تولید گزارش' }, { status: 500 });
  }
}
