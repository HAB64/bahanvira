import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

import { getAdminSession } from '@/lib/admin-auth';
const prisma = new PrismaClient();

/**
 * GET /api/crm/follow-ups
 * Returns leads with overdue follow-ups (followUpAt has passed, not yet completed).
 *
 * Query params:
 * - type: "overdue" (default) | "today" | "upcoming"
 * - days: number of days ahead for "upcoming" (default: 3)
 */
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'overdue';
    const days = parseInt(searchParams.get('days') || '3', 10);

    const now = new Date();
    const futureDate = new Date(now);
    futureDate.setDate(futureDate.getDate() + days);

    // Find activity logs with followUpAt that are due
    const followUps = await prisma.activityLog.findMany({
      where: {
        type: 'REMINDER',
        followUpAt: {
          ...(type === 'overdue' ? { lte: now } : {}),
          ...(type === 'today'
            ? {
                gte: new Date(now.getFullYear(), now.getMonth(), now.getDate()),
                lte: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59),
              }
            : {}),
          ...(type === 'upcoming' ? { gte: now, lte: futureDate } : {}),
        },
      },
      orderBy: { followUpAt: 'asc' },
      include: {
        lead: {
          select: {
            id: true,
            name: true,
            phone: true,
            stage: true,
            score: true,
            cluster: true,
            course: true,
            lastContactedAt: true,
          },
        },
      },
    });

    // Group by lead for cleaner display
    const groupedByLead = followUps.reduce(
      (acc, log) => {
        const leadId = log.leadId;
        if (!acc[leadId]) {
          acc[leadId] = {
            lead: log.lead,
            followUps: [],
          };
        }
        acc[leadId].followUps.push({
          id: log.id,
          content: log.content,
          followUpAt: log.followUpAt,
          createdAt: log.createdAt,
        });
        return acc;
      },
      {} as Record<
        string,
        {
          lead: (typeof followUps)[0]['lead'];
          followUps: { id: string; content: string; followUpAt: Date | null; createdAt: Date }[];
        }
      >
    );

    const result = Object.values(groupedByLead);

    return NextResponse.json({
      پیام: 'یادآورهای پیگیری با موفقیت دریافت شد',
      تعداد: result.length,
      نوع: type,
      داده‌ها: result,
    });
  } catch (error) {
    console.error('Follow-ups fetch error:', error);
    return NextResponse.json(
      { خطا: 'خطا در دریافت یادآورهای پیگیری' },
      { status: 500 }
    );
  }
}
