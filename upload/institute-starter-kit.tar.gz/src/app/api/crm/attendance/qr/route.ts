import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import QRCode from 'qrcode';
import crypto from 'crypto';

import { getAdminSession } from '@/lib/admin-auth';
export async function GET(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const sessionId = request.nextUrl.searchParams.get('sessionId');

    if (!sessionId) {
      return NextResponse.json(
        { خطا: 'شناسه جلسه الزامی است' },
        { status: 400 }
      );
    }

    // Find the session
    const session = await db.session.findUnique({
      where: { id: sessionId },
      include: { skillProgram: true },
    });

    if (!session) {
      return NextResponse.json(
        { خطا: 'جلسه مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Generate a unique QR token
    const qrCodeToken = crypto.randomBytes(32).toString('hex');

    // Save the token to the session
    await db.session.update({
      where: { id: sessionId },
      data: { qrCodeToken },
    });

    // Generate QR code data URL with the token
    // The QR payload contains the token and session info for scanning
    const qrPayload = JSON.stringify({
      token: qrCodeToken,
      sessionId: session.id,
      skillProgramId: session.skillProgramId,
      date: session.date,
      title: session.title || session.skillProgram?.name,
    });

    const qrDataUrl = await QRCode.toDataURL(qrPayload, {
      width: 400,
      margin: 2,
      color: {
        dark: '#0d9488',
        light: '#ffffff',
      },
    });

    return NextResponse.json({
      پیام: 'کد QR با موفقیت تولید شد',
      داده‌ها: {
        sessionId: session.id,
        qrCodeToken,
        qrDataUrl,
        sessionDate: session.date,
        skillProgramName: session.skillProgram?.name,
      },
    });
  } catch (error) {
    console.error('Error generating QR code:', error);
    return NextResponse.json(
      { خطا: 'خطا در تولید کد QR' },
      { status: 500 }
    );
  }
}
