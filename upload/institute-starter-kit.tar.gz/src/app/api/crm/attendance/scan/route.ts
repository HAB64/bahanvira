import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

import { getAdminSession } from '@/lib/admin-auth';
export async function POST(request: NextRequest) {
  
  const session = await getAdminSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
try {
    const body = await request.json();
    const { qrCodeToken, karAmuzId } = body;

    if (!qrCodeToken || !karAmuzId) {
      return NextResponse.json(
        { خطا: 'توکن QR و شناسه کارآموز الزامی است' },
        { status: 400 }
      );
    }

    // Find the session by QR token
    const session = await db.session.findFirst({
      where: { qrCodeToken },
      include: { skillProgram: true },
    });

    if (!session) {
      return NextResponse.json(
        { خطا: 'جلسه‌ای با این توکن QR یافت نشد' },
        { status: 404 }
      );
    }

    // Validate that the session is for today
    const now = new Date();
    const sessionDate = new Date(session.date);
    const isToday =
      sessionDate.getFullYear() === now.getFullYear() &&
      sessionDate.getMonth() === now.getMonth() &&
      sessionDate.getDate() === now.getDate();

    if (!isToday) {
      return NextResponse.json(
        { خطا: 'این جلسه مربوط به امروز نیست' },
        { status: 400 }
      );
    }

    // Check if karAmuz exists
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
    });

    if (!karAmuz) {
      return NextResponse.json(
        { خطا: 'کارآموز مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Validate that the karAmuz is enrolled in the skillProgram
    const enrollment = await db.enrollment.findUnique({
      where: {
        karAmuzId_skillProgramId: {
          karAmuzId,
          skillProgramId: session.skillProgramId,
        },
      },
    });

    if (!enrollment || enrollment.status === 'DROPPED') {
      return NextResponse.json(
        { خطا: 'این کارآموز در دوره مربوط به این جلسه ثبت‌نام نشده است' },
        { status: 400 }
      );
    }

    // Calculate session hours
    const [startH, startM] = session.startTime.split(':').map(Number);
    const [endH, endM] = session.endTime.split(':').map(Number);
    const hours = (endH + endM / 60) - (startH + startM / 60);

    // Create or update attendance record
    const attendance = await db.attendance.upsert({
      where: {
        karAmuzId_sessionId: {
          karAmuzId,
          sessionId: session.id,
        },
      },
      create: {
        karAmuzId,
        sessionId: session.id,
        status: 'PRESENT',
        hours: Math.max(0, hours),
        notes: 'ثبت حضور از طریق اسکن QR',
      },
      update: {
        status: 'PRESENT',
        hours: Math.max(0, hours),
        notes: 'ثبت حضور از طریق اسکن QR (بروزرسانی)',
      },
    });

    return NextResponse.json({
      پیام: 'حضور با موفقیت ثبت شد',
      داده‌ها: {
        attendanceId: attendance.id,
        karAmuzName: `${karAmuz.firstName} ${karAmuz.lastName}`,
        sessionTitle: session.title || session.skillProgram?.name,
        status: attendance.status,
        hours: attendance.hours,
      },
    });
  } catch (error) {
    console.error('Error marking attendance:', error);
    return NextResponse.json(
      { خطا: 'خطا در ثبت حضور' },
      { status: 500 }
    );
  }
}
