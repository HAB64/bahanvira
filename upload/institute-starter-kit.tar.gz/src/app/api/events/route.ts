import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// ─── POST: Log an event (fire-and-forget for client) ────────
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      event,
      category,
      label,
      page,
      metadata,
      loadTime,
    } = body

    if (!event) {
      return NextResponse.json(
        { خطا: 'نوع رویداد الزامی است' },
        { status: 400 }
      )
    }

    // Read UTM data from cookie
    const cookieHeader = request.headers.get('cookie') || ''
    const sessionMatch = cookieHeader.match(/br_session=([^;]+)/)
    const utmMatch = cookieHeader.match(/br_campaign=([^;]+)/)
    const referrerMatch = cookieHeader.match(/br_referrer=([^;]+)/)
    
    let utmData = { source: '', medium: '', campaign: '' }
    if (utmMatch) {
      try {
        utmData = JSON.parse(decodeURIComponent(utmMatch[1]))
      } catch { /* ignore invalid JSON */ }
    }

    // Get client IP and user agent
    const forwarded = request.headers.get('x-forwarded-for')
    const ipAddress = forwarded ? forwarded.split(',')[0].trim() : null
    const userAgent = request.headers.get('user-agent') || null

    await db.eventLog.create({
      data: {
        event,
        category: category || '',
        label: label || '',
        page: page || '',
        referrer: referrerMatch ? decodeURIComponent(referrerMatch[1]) : '',
        sessionId: sessionMatch?.[1] || null,
        utmSource: utmData.source,
        utmMedium: utmData.medium,
        utmCampaign: utmData.campaign,
        metadata: metadata || null,
        ipAddress,
        userAgent,
        loadTime: loadTime || null,
      },
    })

    return NextResponse.json({ پیام: 'ثبت شد' }, { status: 200 })
  } catch (error) {
    console.error('Event log error:', error)
    // Still return 200 for fire-and-forget pattern
    return NextResponse.json({ پیام: 'ثبت شد' }, { status: 200 })
  }
}

// ─── GET: Event statistics (admin) ──────────────────────────
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const days = parseInt(searchParams.get('days') || '30')
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000)

    // Top pages
    const topPages = await db.eventLog.groupBy({
      by: ['page'],
      where: { createdAt: { gte: since }, page: { not: '' } },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
      take: 20,
    })

    // Top events
    const topEvents = await db.eventLog.groupBy({
      by: ['event'],
      where: { createdAt: { gte: since } },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
      take: 20,
    })

    // Top categories
    const topCategories = await db.eventLog.groupBy({
      by: ['category'],
      where: { createdAt: { gte: since }, category: { not: '' } },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
    })

    // UTM performance
    const utmPerformance = await db.eventLog.groupBy({
      by: ['utmSource', 'utmMedium', 'utmCampaign'],
      where: { 
        createdAt: { gte: since },
        utmSource: { not: '' },
      },
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
      take: 20,
    })

    // Conversion funnel (page_view → form_submit → cta_click)
    const funnelSteps = ['PAGE_VIEW', 'COURSE_VIEW', 'FORM_SUBMIT', 'CTA_CLICK']
    const funnel: Record<string, number> = {}
    for (const step of funnelSteps) {
      funnel[step] = await db.eventLog.count({
        where: { event: step, createdAt: { gte: since } },
      })
    }

    // Daily trend
    const dailyStats = await db.eventLog.groupBy({
      by: ['createdAt'],
      where: { createdAt: { gte: since } },
      _count: { id: true },
    })

    // Group by date (simplified)
    const dailyMap: Record<string, number> = {}
    for (const stat of dailyStats) {
      const dateKey = new Date(stat.createdAt).toISOString().split('T')[0]
      dailyMap[dateKey] = (dailyMap[dateKey] || 0) + stat._count.id
    }
    const dailyTrend = Object.entries(dailyMap)
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => a.date.localeCompare(b.date))

    // Total count
    const totalCount = await db.eventLog.count({
      where: { createdAt: { gte: since } },
    })

    // Unique sessions
    const uniqueSessions = await db.eventLog.groupBy({
      by: ['sessionId'],
      where: { createdAt: { gte: since }, sessionId: { not: null } },
    })

    return NextResponse.json({
      totalCount,
      uniqueSessions: uniqueSessions.length,
      topPages: topPages.map(p => ({ page: p.page, views: p._count.id })),
      topEvents: topEvents.map(e => ({ event: e.event, count: e._count.id })),
      topCategories: topCategories.map(c => ({ category: c.category, count: c._count.id })),
      utmPerformance: utmPerformance.map(u => ({
        source: u.utmSource,
        medium: u.utmMedium,
        campaign: u.utmCampaign,
        count: u._count.id,
      })),
      funnel,
      dailyTrend,
    })
  } catch (error) {
    console.error('Event stats error:', error)
    return NextResponse.json(
      { خطا: 'خطا در دریافت آمار رویدادها' },
      { status: 500 }
    )
  }
}
