import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/sqlite';

// GET /api/gated-content/[id] — Get a single lead magnet by ID
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const db = getDb();
    const { id } = await params;

    const magnet = db
      .prepare('SELECT * FROM LeadMagnet WHERE id = ? AND isActive = 1')
      .get(id) as Record<string, unknown> | null;

    if (!magnet) {
      return NextResponse.json(
        { error: 'محتوای مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Convert SQLite boolean fields
    const result = {
      ...magnet,
      requiresPhone: Number(magnet.requiresPhone) === 1,
      requiresEmail: Number(magnet.requiresEmail) === 1,
      isActive: Number(magnet.isActive) === 1,
    };

    return NextResponse.json({ magnet: result });
  } catch (error) {
    console.error('[GATED_CONTENT_GET_ID]', error);
    return NextResponse.json(
      { error: 'خطا در دریافت اطلاعات محتوا' },
      { status: 500 }
    );
  }
}
