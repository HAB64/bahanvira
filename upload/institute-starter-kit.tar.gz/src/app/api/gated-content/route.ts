import { NextRequest, NextResponse } from 'next/server';
import { getDb, generateId } from '@/lib/sqlite';

// GET /api/gated-content — List active lead magnets with optional filtering
export async function GET(request: NextRequest) {
  try {
    const db = getDb();
    const { searchParams } = new URL(request.url);
    const cluster = searchParams.get('cluster');
    const persona = searchParams.get('persona');

    let query = 'SELECT * FROM LeadMagnet WHERE isActive = 1';
    const params: unknown[] = [];

    if (cluster) {
      query += ' AND targetCluster = ?';
      params.push(cluster);
    }
    if (persona) {
      query += ' AND targetPersona = ?';
      params.push(persona);
    }

    query += ' ORDER BY createdAt DESC';

    const magnets = db.prepare(query).all(...params);

    // Convert SQLite boolean fields
    const result = magnets.map((m: Record<string, unknown>) => ({
      ...m,
      requiresPhone: Number(m.requiresPhone) === 1,
      requiresEmail: Number(m.requiresEmail) === 1,
      isActive: Number(m.isActive) === 1,
    }));

    return NextResponse.json({ magnets: result });
  } catch (error) {
    console.error('[GATED_CONTENT_GET]', error);
    return NextResponse.json(
      { error: 'خطا در دریافت لیست محتوا' },
      { status: 500 }
    );
  }
}

// POST /api/gated-content — Request access to a lead magnet
export async function POST(request: NextRequest) {
  try {
    const db = getDb();
    const body = await request.json();
    const { magnetId, phone, email } = body;

    // Validate magnetId
    if (!magnetId) {
      return NextResponse.json(
        { error: 'شناسه محتوا الزامی است' },
        { status: 400 }
      );
    }

    // Validate phone (Iranian format: 09xxxxxxxxx)
    const phoneRegex = /^09\d{9}$/;
    if (!phone || !phoneRegex.test(phone)) {
      return NextResponse.json(
        { error: 'شماره موبایل معتبر وارد کنید (مثال: 09123456789)' },
        { status: 400 }
      );
    }

    // Validate email if provided
    if (email && email.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return NextResponse.json(
          { error: 'ایمیل معتبر وارد کنید' },
          { status: 400 }
        );
      }
    }

    // Find the lead magnet
    const magnet = db
      .prepare('SELECT * FROM LeadMagnet WHERE id = ? AND isActive = 1')
      .get(magnetId) as Record<string, unknown> | null;

    if (!magnet) {
      return NextResponse.json(
        { error: 'محتوای مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Check if lead already exists by phone
    const existingLead = db
      .prepare('SELECT * FROM Lead WHERE phone = ?')
      .get(phone) as Record<string, unknown> | null;

    let isNewLead = false;
    let leadId: string;

    if (!existingLead) {
      // Create a new lead
      leadId = generateId();
      const now = new Date().toISOString();
      db.prepare(
        `INSERT INTO Lead (id, name, phone, email, goal, level, interest, course, company, serviceType, message, source, stage, score, cluster, assignedTo, segment, lifetimeValue, createdAt)
         VALUES (?, ?, ?, ?, '', '', '', '', '', '', ?, ?, ?, ?, ?, ?, '', 0, ?)`
      ).run(
        leadId,
        phone, // name = phone initially
        phone,
        email || '',
        `دانلود: ${magnet.title}`,
        'lead-magnet',
        'NEW',
        10, // base score for lead magnet
        (magnet.targetCluster as string) || '',
        '',
        now
      );
      isNewLead = true;
    } else {
      leadId = existingLead.id as string;
      // Update email if provided and not already set
      if (email && !existingLead.email) {
        db.prepare('UPDATE Lead SET email = ? WHERE id = ?').run(email, leadId);
      }
    }

    // Increment magnet stats
    db.prepare(
      'UPDATE LeadMagnet SET downloadCount = downloadCount + 1, updatedAt = ? WHERE id = ?'
    ).run(new Date().toISOString(), magnetId);

    if (isNewLead) {
      db.prepare(
        'UPDATE LeadMagnet SET leadCount = leadCount + 1 WHERE id = ?'
      ).run(magnetId);
    }

    // Log the event
    const eventLogId = generateId();
    db.prepare(
      `INSERT INTO EventLog (id, leadId, event, category, label, metadata, createdAt)
       VALUES (?, ?, 'DOWNLOAD', 'conversion', ?, ?, ?)`
    ).run(
      eventLogId,
      leadId,
      `دانلود محتوای دروازه‌ای: ${magnet.title}`,
      JSON.stringify({
        magnetId: magnet.id,
        magnetTitle: magnet.title,
        magnetType: magnet.type,
        isNewLead,
        phone,
        email: email || null,
      }),
      new Date().toISOString()
    );

    return NextResponse.json({
      success: true,
      fileUrl: magnet.fileUrl,
      magnetTitle: magnet.title,
      magnetType: magnet.type,
      isNewLead,
    });
  } catch (error) {
    console.error('[GATED_CONTENT_POST]', error);
    return NextResponse.json(
      { error: 'خطا در پردازش درخواست' },
      { status: 500 }
    );
  }
}
