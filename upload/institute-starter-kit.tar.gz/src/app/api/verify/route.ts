import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// ==========================================
// Persian Date Conversion Helper
// ==========================================

const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

function toPersianDigits(num: number | string): string {
  return num.toString().replace(/\d/g, (d) => persianDigits[parseInt(d)]);
}

/**
 * Converts a Gregorian date to a Jalali (Persian) date string formatted as "YYYY/MM/DD" in Persian digits.
 * Algorithm: well-tested conversion without external libraries.
 */
function gregorianToJalaliSimple(gy: number, gm: number, gd: number): string {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

  let gy2 = gy - 1600;
  let gm2 = gm - 1;
  let gd2 = gd - 1;

  let gDayNo =
    365 * gy2 +
    Math.floor((gy2 + 3) / 4) -
    Math.floor((gy2 + 99) / 100) +
    Math.floor((gy2 + 399) / 400) +
    g_d_m[gm2] +
    gd2;

  let jDayNo = gDayNo + 79;

  let jNp = Math.floor(jDayNo / 12053);
  jDayNo %= 12053;

  let jy = 979 + 33 * jNp + 4 * Math.floor(jDayNo / 1461);
  jDayNo %= 1461;

  if (jDayNo >= 366) {
    jy += Math.floor((jDayNo - 1) / 365);
    jDayNo = (jDayNo - 1) % 365;
  }

  let jm: number;
  let jd: number;

  if (jDayNo < 186) {
    jm = 1 + Math.floor(jDayNo / 31);
    jd = 1 + (jDayNo % 31);
  } else {
    jm = 7 + Math.floor((jDayNo - 186) / 30);
    jd = 1 + ((jDayNo - 186) % 30);
  }

  return `${toPersianDigits(jy)}/${toPersianDigits(jm.toString().padStart(2, '0'))}/${toPersianDigits(jd.toString().padStart(2, '0'))}`;
}

/**
 * Format a Date (or null/undefined) to a Persian Jalali date string.
 */
function formatPersianDate(date: Date | null | undefined): string {
  if (!date) return '—';
  return gregorianToJalaliSimple(
    date.getFullYear(),
    date.getMonth() + 1,
    date.getDate()
  );
}

// ==========================================
// Certificate Status Mapping
// ==========================================

const statusMap: Record<string, string> = {
  PENDING: 'در حال بررسی',
  EXAM_REGISTERED: 'ثبت‌نام آزمون',
  EXAM_PASSED: 'قبول در آزمون',
  EXAM_FAILED: 'مردود در آزمون',
  ISSUED: 'صادر شده',
};

function mapCertificateStatus(status: string): string {
  return statusMap[status] || status;
}

// ==========================================
// Mock Certificate Data (fallback)
// ==========================================

const mockCertificates = [
  {
    nationalId: '0012345678',
    trackingCode: 'BHR-1403-001',
    studentName: 'سارا محمدی',
    courseName: 'کاربر ICDL — سواد دیجیتال بین‌المللی',
    certificateNumber: 'ICDL-1403-4521',
    issueDate: '۱۴۰۳/۰۶/۱۵',
    status: 'valid' as const,
    issuer: 'سازمان آموزش فنی و حرفه‌ای ایران',
    certType: 'گواهینامه بین‌المللی ICDL',
  },
  {
    nationalId: '0023456789',
    trackingCode: 'BHR-1403-002',
    studentName: 'علی رضایی',
    courseName: 'برنامه‌نویس پایتون — برنامه‌نویسی حرفه‌ای و تحلیل داده',
    certificateNumber: 'TVTO-1403-7834',
    issueDate: '۱۴۰۳/۰۸/۲۰',
    status: 'valid' as const,
    issuer: 'سازمان آموزش فنی و حرفه‌ای ایران',
    certType: 'گواهی فنی و حرفه‌ای',
  },
  {
    nationalId: '0034567890',
    trackingCode: 'BHR-1402-015',
    studentName: 'مهدی تقوی',
    courseName: 'فارکس — مبانی معامله‌گری و پرایس اکشن',
    certificateNumber: 'TVTO-1402-2156',
    issueDate: '۱۴۰۲/۱۲/۰۱',
    status: 'expired' as const,
    issuer: 'سازمان آموزش فنی و حرفه‌ای ایران',
    certType: 'گواهی پایان دوره',
  },
];

// ==========================================
// Mock Fallback Handler
// ==========================================

function searchMockCertificates(nationalId: string | undefined, trackingCode: string | undefined) {
  return mockCertificates.filter(
    (cert) =>
      (nationalId && cert.nationalId === nationalId) ||
      (trackingCode && cert.trackingCode === trackingCode)
  );
}

// ==========================================
// Event Logging Helper
// ==========================================

async function logVerifyEvent(params: {
  nationalId?: string;
  trackingCode?: string;
  karAmuzId?: string;
  leadId?: string;
  resultCount: number;
  ipAddress?: string;
  userAgent?: string;
}) {
  try {
    await db.eventLog.create({
      data: {
        event: 'CERT_VERIFY',
        category: 'conversion',
        label: `استعلام گواهینامه — ${params.resultCount} نتیجه`,
        karAmuzId: params.karAmuzId || null,
        leadId: params.leadId || null,
        metadata: {
          nationalId: params.nationalId || null,
          trackingCode: params.trackingCode || null,
          resultCount: params.resultCount,
        },
        ipAddress: params.ipAddress || null,
        userAgent: params.userAgent || null,
      },
    });
  } catch {
    // Silently fail — logging should never break the main flow
    console.warn('Failed to log CERT_VERIFY event');
  }
}

// ==========================================
// Main POST Handler
// ==========================================

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { nationalId, trackingCode } = body;

    if (!nationalId && !trackingCode) {
      return NextResponse.json(
        { error: 'لطفاً کد ملی یا کد رهگیری را وارد کنید' },
        { status: 400 }
      );
    }

    // Extract request metadata for logging
    const ipAddress =
      request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      request.headers.get('x-real-ip') ||
      null;
    const userAgent = request.headers.get('user-agent') || null;

    // Attempt database lookup
    let useFallback = false;
    let results: Array<{
      studentName: string;
      courseName: string;
      certificateNumber: string | null;
      issueDate: string;
      status: string;
      issuer: string;
      certType: string;
      trackingCode: string | null;
    }> = [];
    let karAmuzIdForLog: string | undefined;
    let leadIdForLog: string | undefined;

    try {
      // --- Lookup by trackingCode (certificateNo) ---
      if (trackingCode) {
        const certByCode = await db.certificate.findUnique({
          where: { certificateNo: trackingCode },
          include: {
            karAmuz: { select: { id: true, firstName: true, lastName: true, nationalId: true, leadId: true } },
            skillProgram: { select: { id: true, name: true } },
          },
        });

        if (certByCode) {
          const certData = {
            studentName: `${certByCode.karAmuz.firstName} ${certByCode.karAmuz.lastName}`,
            courseName: certByCode.skillProgram.name,
            certificateNumber: certByCode.certificateNo,
            issueDate: formatPersianDate(certByCode.issueDate),
            status: mapCertificateStatus(certByCode.status),
            issuer: 'سازمان آموزش فنی و حرفه‌ای ایران',
            certType: 'گواهی فنی و حرفه‌ای',
            trackingCode: certByCode.certificateNo,
          };
          results.push(certData);
          karAmuzIdForLog = certByCode.karAmuz.id;
          leadIdForLog = certByCode.karAmuz.leadId ?? undefined;
        }
      }

      // --- Lookup by nationalId ---
      if (nationalId) {
        const karAmuz = await db.karAmuz.findUnique({
          where: { nationalId },
          include: {
            lead: { select: { id: true } },
            certificates: {
              include: {
                skillProgram: { select: { id: true, name: true } },
              },
            },
          },
        });

        if (karAmuz) {
          karAmuzIdForLog = karAmuz.id;
          leadIdForLog = karAmuz.leadId ?? undefined;

          // If both trackingCode and nationalId provided, filter to only matching certificate
          const certsToShow = trackingCode
            ? karAmuz.certificates.filter((c) => c.certificateNo === trackingCode)
            : karAmuz.certificates;

          for (const cert of certsToShow) {
            // Avoid duplicates if the trackingCode lookup already found the same cert
            const alreadyAdded = results.some(
              (r) => r.certificateNumber === cert.certificateNo
            );
            if (!alreadyAdded) {
              results.push({
                studentName: `${karAmuz.firstName} ${karAmuz.lastName}`,
                courseName: cert.skillProgram.name,
                certificateNumber: cert.certificateNo,
                issueDate: formatPersianDate(cert.issueDate),
                status: mapCertificateStatus(cert.status),
                issuer: 'سازمان آموزش فنی و حرفه‌ای ایران',
                certType: 'گواهی فنی و حرفه‌ای',
                trackingCode: cert.certificateNo,
              });
            }
          }
        }
      }
    } catch (dbError) {
      // Database connection error — fall back to mock data
      console.warn('Database lookup failed, falling back to mock data:', dbError);
      useFallback = true;
    }

    // --- Fallback to mock data if DB is unavailable ---
    if (useFallback) {
      const mockResults = searchMockCertificates(nationalId, trackingCode);
      if (mockResults.length === 0) {
        return NextResponse.json(
          { error: 'مدرکی با اطلاعات وارد شده یافت نشد. لطفاً اطلاعات را بررسی کنید.' },
          { status: 404 }
        );
      }

      // Return single result format for backward compatibility
      if (mockResults.length === 1) {
        const result = mockResults[0];
        return NextResponse.json({
          found: true,
          data: {
            studentName: result.studentName,
            courseName: result.courseName,
            certificateNumber: result.certificateNumber,
            issueDate: result.issueDate,
            status: result.status,
            issuer: result.issuer,
            certType: result.certType,
            trackingCode: result.trackingCode,
          },
        });
      }

      // Multiple mock results
      return NextResponse.json({
        found: true,
        data: mockResults.map((r) => ({
          studentName: r.studentName,
          courseName: r.courseName,
          certificateNumber: r.certificateNumber,
          issueDate: r.issueDate,
          status: r.status,
          issuer: r.issuer,
          certType: r.certType,
          trackingCode: r.trackingCode,
        })),
      });
    }

    // --- Log the verification event (non-blocking) ---
    // We log after the main flow so it doesn't slow down the response
    logVerifyEvent({
      nationalId,
      trackingCode,
      karAmuzId: karAmuzIdForLog,
      leadId: leadIdForLog,
      resultCount: results.length,
      ipAddress: ipAddress ?? undefined,
      userAgent: userAgent ?? undefined,
    });

    // --- Return results from database ---
    if (results.length === 0) {
      return NextResponse.json(
        { error: 'مدرکی با اطلاعات وارد شده یافت نشد. لطفاً اطلاعات را بررسی کنید.' },
        { status: 404 }
      );
    }

    // Single result — maintain backward-compatible format
    if (results.length === 1) {
      return NextResponse.json({
        found: true,
        data: results[0],
      });
    }

    // Multiple results — return array
    return NextResponse.json({
      found: true,
      data: results,
    });
  } catch {
    return NextResponse.json(
      { error: 'خطا در پردازش درخواست. لطفاً دوباره تلاش کنید.' },
      { status: 500 }
    );
  }
}
