import { NextResponse } from 'next/server'

/**
 * ═══════════════════════════════════════════════════════════
 * Cron Job — سیستم سایبرنتیک آموزشی
 * ═══════════════════════════════════════════════════════════
 *
 * این endpoint توسط Vercel Crontrigger می‌شود.
 * هر روز ساعت ۲ بامداد (UTC) اجرا می‌شود.
 *
 * فازهای اجرا:
 *   ۱. خودتنظیمی (Self-Regulation) — تشخیص ناهنجاری + اقدام اصلاحی
 *   ۲. بهینه‌سازی مسیرها (Path Optimization) — تحلیل رفتار + بهینه‌سازی
 *   ۳. پیش‌بینی (Prediction) — پیش‌بینی درآمد و ثبت‌نام
 *
 * فراخوانی مستقیم: POST /api/cron/cybernetic?secret=BR_CYBERNETIC_2024
 */
export async function POST(request: Request) {
  try {
    // ─── Verify cron secret ───
    const { searchParams } = new URL(request.url)
    const secret = searchParams.get('secret')
    if (secret !== 'BR_CYBERNETIC_2024') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
    const results: { phase: string; status: string; data?: unknown; error?: string }[] = []

    // ════════════════════════════════════════
    // فاز ۱: خودتنظیمی (Self-Regulation)
    // ════════════════════════════════════════
    try {
      const selfRegRes = await fetch(`${baseUrl}/api/ai/self-regulate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cycleType: 'DAILY' }),
      })

      if (selfRegRes.ok) {
        const selfRegData = await selfRegRes.json()
        results.push({ phase: 'self-regulation', status: 'success', data: selfRegData })
      } else {
        const errText = await selfRegRes.text()
        results.push({ phase: 'self-regulation', status: 'error', error: errText })
      }
    } catch (err) {
      results.push({ phase: 'self-regulation', status: 'error', error: String(err) })
    }

    // ════════════════════════════════════════
    // فاز ۲: بهینه‌سازی مسیرها (Path Optimization)
    // ════════════════════════════════════════
    try {
      const pathOptRes = await fetch(`${baseUrl}/api/ai/path-optimize`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      })

      if (pathOptRes.ok) {
        const pathOptData = await pathOptRes.json()
        results.push({ phase: 'path-optimization', status: 'success', data: pathOptData })
      } else {
        const errText = await pathOptRes.text()
        results.push({ phase: 'path-optimization', status: 'error', error: errText })
      }
    } catch (err) {
      results.push({ phase: 'path-optimization', status: 'error', error: String(err) })
    }

    // ════════════════════════════════════════
    // فاز ۳: پیش‌بینی (Prediction)
    // ════════════════════════════════════════
    try {
      const predRes = await fetch(`${baseUrl}/api/ai/predict`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ horizon: 'weekly' }),
      })

      if (predRes.ok) {
        const predData = await predRes.json()
        results.push({ phase: 'prediction', status: 'success', data: predData })
      } else {
        results.push({ phase: 'prediction', status: 'skipped' })
      }
    } catch {
      results.push({ phase: 'prediction', status: 'skipped' })
    }

    // ─── Summary ───
    const succeeded = results.filter(r => r.status === 'success').length
    const failed = results.filter(r => r.status === 'error').length

    return NextResponse.json({
      success: true,
      timestamp: new Date().toISOString(),
      summary: { total: results.length, succeeded, failed, skipped: results.length - succeeded - failed },
      results,
    })
  } catch (error) {
    console.error('Cybernetic cron error:', error)
    return NextResponse.json({ error: 'خطا در اجرای سیستم سایبرنتیک' }, { status: 500 })
  }
}

// Allow GET for Vercel Cron (Vercel sends GET for cron triggers)
export async function GET(request: Request) {
  return POST(request)
}
