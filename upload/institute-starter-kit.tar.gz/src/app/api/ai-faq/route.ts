import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { question } = body as { question: string }

    if (!question || typeof question !== 'string') {
      return NextResponse.json({ error: 'سوال الزامی است' }, { status: 400 })
    }

    // Search KnowledgeArticle for FAQ matches
    let faqArticles: { id: string; title: string; content: string; excerpt: string | null; tags: string; slug: string }[] = []
    try {
      faqArticles = await db.knowledgeArticle.findMany({
        where: {
          isPublished: true,
          isInternal: false,
          category: 'FAQ',
        },
        select: {
          id: true,
          title: true,
          content: true,
          excerpt: true,
          tags: true,
          slug: true,
        },
      })
    } catch {
      // KnowledgeArticle table might not have data
    }

    // Simple keyword matching to find best FAQ
    const qLower = question.toLowerCase()
    let bestMatch: { id: string; title: string; content: string; excerpt: string | null; tags: string; slug: string } | null = null
    let bestScore = 0

    for (const article of faqArticles) {
      let score = 0
      const tags = article.tags.split(',').map(t => t.trim().toLowerCase())
      for (const tag of tags) {
        if (tag && qLower.includes(tag)) {
          score += 3
        }
      }
      const titleWords = article.title.toLowerCase().split(/\s+/)
      for (const word of titleWords) {
        if (word.length > 2 && qLower.includes(word)) {
          score += 2
        }
      }
      const contentWords = article.content.toLowerCase().split(/\s+/).slice(0, 50)
      for (const word of contentWords) {
        if (word.length > 3 && qLower.includes(word)) {
          score += 1
        }
      }
      if (score > bestScore) {
        bestScore = score
        bestMatch = article
      }
    }

    // If good match found in FAQ, return it
    if (bestMatch && bestScore >= 3) {
      const relatedArticles = faqArticles
        .filter(a => a.id !== bestMatch!.id)
        .slice(0, 3)
        .map(a => a.title)

      return NextResponse.json({
        answer: bestMatch.excerpt || bestMatch.content.substring(0, 500),
        source: 'faq',
        sourceTitle: bestMatch.title,
        relatedQuestions: relatedArticles,
      })
    }

    // No good FAQ match - use AI to generate answer
    let answer = ''
    let relatedQuestions: string[] = []

    try {
      const ZAI = (await import('z-ai-web-dev-sdk')).default
      const zai = await ZAI.create()

      const faqContext = faqArticles.length > 0
        ? `\n\nسوالات متداول موجود:\n${faqArticles.map(a => `- ${a.title}`).join('\n')}`
        : ''

      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: `تو یک دستیار هوشمند سایت بهان رایانه هستی. به سوالات کاربران درباره دوره‌ها، شهریه، مدارک، و مسیرهای شغلی پاسخ بده. پاسخ‌ها باید مختصر (حداکثر ۳ پاراگراف) و کاربردی باشند. همیشه به فارسی پاسخ بده.

موسسه بهان رایانه با ۲۷ سال سابقه، ۳ خوشه و ۸ گروه آموزشی دارد: فن آوری اطلاعات، امور مالی و بازرگانی، خدمات آموزشی، خدمات حقوقی، معماری، ساختمان، صنایع پوشاک، هنرهای تجسمی.

همه دوره‌ها مدرک فنی حرفه‌ای دارند. شهریه قسط‌بندی ۲ تا ۳ ماهه بدون چک و بهره است.${faqContext}`,
          },
          { role: 'user', content: question },
        ],
      })

      answer = completion.choices?.[0]?.message?.content || ''
      relatedQuestions = [
        'شهریه دوره‌ها چقدر است؟',
        'آیا امکان قسط‌بندی وجود دارد؟',
        'مدارک صادرشده معتبر هستند؟',
      ]
    } catch (aiError) {
      console.error('AI FAQ fallback:', aiError)
      answer = generateFallbackFAQ(question)
      relatedQuestions = [
        'چگونه می‌توانم ثبت‌نام کنم؟',
        'مدارک دوره‌ها چه اعتباری دارند؟',
      ]
    }

    return NextResponse.json({
      answer,
      source: 'ai',
      relatedQuestions,
    })
  } catch (error) {
    console.error('AI FAQ error:', error)
    return NextResponse.json({ error: 'خطا در پردازش سوال' }, { status: 500 })
  }
}

function generateFallbackFAQ(question: string): string {
  const q = question.toLowerCase()

  if (q.includes('هزینه') || q.includes('شهریه') || q.includes('قیمت')) {
    return 'شهریه دوره‌ها بر اساس ساعات آموزش تعیین می‌شود. امکان قسط‌بندی ۲ تا ۳ ماهه بدون چک و بدون بهره وجود دارد. برای اطلاع از شهریه دقیق، با کارشناسان ما تماس بگیرید.'
  }

  if (q.includes('مدرک') || q.includes('گواهینامه') || q.includes('معتبر')) {
    return 'تمام دوره‌ها دارای مدرک معتبر فنی و حرفه‌ای هستند. این مدارک برای استخدام دولتی و غیردولتی معتبر هستند.'
  }

  if (q.includes('ثبت‌نام') || q.includes('نام‌نویسی') || q.includes('شرکت')) {
    return 'برای ثبت‌نام می‌توانید از فرم مشاوره رایگان سایت استفاده کنید، با شماره تلفن آموزشگاه تماس بگیرید، یا شخصاً به آموزشگاه مراجعه نمایید.'
  }

  if (q.includes('آنلاین') || q.includes('مجازی') || q.includes('دور')) {
    return 'در حال حاضر دوره‌ها به صورت حضوری در آموزشگاه بهان رایانه (محمودآباد) برگزار می‌شوند. برای اطلاعات درباره دوره‌های آنلاین، با کارشناسان ما تماس بگیرید.'
  }

  return 'بهان رایانه با ۲۷ سال سابقه، دوره‌های تخصصی در ۳ خوشه و ۸ گروه آموزشی ارائه می‌دهد. برای دریافت پاسخ دقیق سوال خود، با کارشناسان ما تماس بگیرید یا از مشاور هوشمند سایت استفاده نمایید.'
}
