import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

// GET /api/admin/exams/[examId]/questions - List questions for an exam
export async function GET(
  request: Request,
  { params }: { params: Promise<{ examId: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { examId } = await params;

    const questions = await db.examQuestion.findMany({
      where: { examId },
      orderBy: { order: 'asc' },
    });

    return NextResponse.json({ داده‌ها: questions });
  } catch (error) {
    console.error('Error fetching questions:', error);
    return NextResponse.json({ error: 'خطا در دریافت سوالات' }, { status: 500 });
  }
}

// POST /api/admin/exams/[examId]/questions - Add a question to an exam
export async function POST(
  request: Request,
  { params }: { params: Promise<{ examId: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { examId } = await params;
    const body = await request.json();

    const {
      text,
      type = 'MULTIPLE_CHOICE',
      options,
      correctAnswer,
      points = 1,
      difficulty = 'MEDIUM',
      explanation,
      order,
      image,
    } = body;

    if (!text?.trim()) {
      return NextResponse.json({ error: 'متن سوال الزامی است' }, { status: 400 });
    }

    if (!correctAnswer?.trim()) {
      return NextResponse.json({ error: 'پاسخ صحیح الزامی است' }, { status: 400 });
    }

    // Verify exam exists
    const exam = await db.exam.findUnique({ where: { id: examId } });
    if (!exam) {
      return NextResponse.json({ error: 'آزمون یافت نشد' }, { status: 404 });
    }

    // If order not specified, put at the end
    let questionOrder = order;
    if (questionOrder === undefined || questionOrder === null) {
      const maxOrder = await db.examQuestion.findFirst({
        where: { examId },
        orderBy: { order: 'desc' },
        select: { order: true },
      });
      questionOrder = (maxOrder?.order ?? -1) + 1;
    }

    // Validate options for MCQ
    if (type === 'MULTIPLE_CHOICE') {
      if (!options || !Array.isArray(options) || options.length < 2) {
        return NextResponse.json(
          { error: 'سوالات چهارگزینه‌ای باید حداقل ۲ گزینه داشته باشند' },
          { status: 400 }
        );
      }
    }

    const question = await db.examQuestion.create({
      data: {
        examId,
        text: text.trim(),
        type,
        options: options || null,
        correctAnswer: correctAnswer.trim(),
        points: parseFloat(points) || 1,
        difficulty,
        explanation: explanation?.trim() || null,
        order: questionOrder,
        image: image?.trim() || null,
      },
    });

    // Update exam maxScore
    await updateExamMaxScore(examId);

    return NextResponse.json(question, { status: 201 });
  } catch (error) {
    console.error('Error creating question:', error);
    return NextResponse.json({ error: 'خطا در ایجاد سوال' }, { status: 500 });
  }
}

// PUT /api/admin/exams/[examId]/questions - Bulk update question order
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ examId: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { examId } = await params;
    const body = await request.json();
    const { questions } = body as { questions: { id: string; order: number }[] };

    if (!Array.isArray(questions)) {
      return NextResponse.json({ error: 'فرمت داده نامعتبر' }, { status: 400 });
    }

    // Update order for each question
    await Promise.all(
      questions.map((q) =>
        db.examQuestion.update({
          where: { id: q.id },
          data: { order: q.order },
        })
      )
    );

    return NextResponse.json({ message: 'ترتیب سوالات بروزرسانی شد' });
  } catch (error) {
    console.error('Error reordering questions:', error);
    return NextResponse.json({ error: 'خطا در بروزرسانی ترتیب سوالات' }, { status: 500 });
  }
}

// Helper: recalculate exam maxScore
async function updateExamMaxScore(examId: string) {
  const result = await db.examQuestion.aggregate({
    where: { examId },
    _sum: { points: true },
  });

  const maxScore = result._sum.points || 0;

  // Update all IN_PROGRESS attempts' maxScore too
  await db.exam.update({
    where: { id: examId },
    data: { attempts: { updateMany: { where: { status: 'IN_PROGRESS' }, data: { maxScore } } } },
  });
}
