import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

// PATCH /api/admin/exams/[examId]/questions/[questionId] - Update a question
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ examId: string; questionId: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { examId, questionId } = await params;
    const body = await request.json();

    const existing = await db.examQuestion.findFirst({
      where: { id: questionId, examId },
    });
    if (!existing) {
      return NextResponse.json({ error: 'سوال یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};
    const allowedFields = [
      'text', 'type', 'options', 'correctAnswer',
      'points', 'difficulty', 'explanation', 'order', 'image',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        if (field === 'points') {
          updateData[field] = parseFloat(body[field]) || existing.points;
        } else if (field === 'order') {
          updateData[field] = parseInt(body[field]);
        } else if (field === 'options') {
          updateData[field] = body[field] || null;
        } else if (field === 'explanation' || field === 'image') {
          updateData[field] = body[field]?.trim() || null;
        } else {
          updateData[field] = body[field];
        }
      }
    }

    const question = await db.examQuestion.update({
      where: { id: questionId },
      data: updateData,
    });

    // Update exam maxScore if points changed
    if (body.points !== undefined) {
      const result = await db.examQuestion.aggregate({
        where: { examId },
        _sum: { points: true },
      });
      const maxScore = result._sum.points || 0;
      await db.exam.update({
        where: { id: examId },
        data: { attempts: { updateMany: { where: { status: 'IN_PROGRESS' }, data: { maxScore } } } },
      });
    }

    return NextResponse.json(question);
  } catch (error) {
    console.error('Error updating question:', error);
    return NextResponse.json({ error: 'خطا در بروزرسانی سوال' }, { status: 500 });
  }
}

// DELETE /api/admin/exams/[examId]/questions/[questionId] - Delete a question
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ examId: string; questionId: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { examId, questionId } = await params;

    const existing = await db.examQuestion.findFirst({
      where: { id: questionId, examId },
    });
    if (!existing) {
      return NextResponse.json({ error: 'سوال یافت نشد' }, { status: 404 });
    }

    await db.examQuestion.delete({
      where: { id: questionId },
    });

    // Reorder remaining questions
    const remaining = await db.examQuestion.findMany({
      where: { examId },
      orderBy: { order: 'asc' },
    });

    await Promise.all(
      remaining.map((q, index) =>
        db.examQuestion.update({
          where: { id: q.id },
          data: { order: index },
        })
      )
    );

    // Update exam maxScore
    const result = await db.examQuestion.aggregate({
      where: { examId },
      _sum: { points: true },
    });
    const maxScore = result._sum.points || 0;
    await db.exam.update({
      where: { id: examId },
      data: { attempts: { updateMany: { where: { status: 'IN_PROGRESS' }, data: { maxScore } } } },
    });

    return NextResponse.json({ message: 'سوال با موفقیت حذف شد' });
  } catch (error) {
    console.error('Error deleting question:', error);
    return NextResponse.json({ error: 'خطا در حذف سوال' }, { status: 500 });
  }
}
