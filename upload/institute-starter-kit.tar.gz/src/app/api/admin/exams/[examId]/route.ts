import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

// GET /api/admin/exams/[examId] - Get exam details with questions
export async function GET(
  request: Request,
  { params }: { params: Promise<{ examId: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { examId } = await params;

    const exam = await db.exam.findUnique({
      where: { id: examId },
      include: {
        skillProgram: { select: { id: true, name: true } },
        questions: { orderBy: { order: 'asc' } },
        _count: { select: { questions: true, attempts: true } },
        attempts: {
          select: {
            id: true,
            karAmuzId: true,
            status: true,
            score: true,
            maxScore: true,
            percentage: true,
            isPassed: true,
            startedAt: true,
            submittedAt: true,
            timeSpentSec: true,
            karAmuz: {
              select: { id: true, firstName: true, lastName: true, phone: true },
            },
          },
          orderBy: { startedAt: 'desc' },
          take: 50,
        },
      },
    });

    if (!exam) {
      return NextResponse.json({ error: 'آزمون یافت نشد' }, { status: 404 });
    }

    // Compute stats
    const completedAttempts = exam.attempts.filter(
      (a) => a.status === 'SUBMITTED' || a.status === 'TIMED_OUT' || a.status === 'AUTO_SUBMITTED'
    );
    const totalScore = completedAttempts.reduce((sum, a) => sum + (a.percentage || 0), 0);
    const avgScore = completedAttempts.length > 0 ? totalScore / completedAttempts.length : 0;
    const passCount = completedAttempts.filter((a) => a.isPassed).length;
    const passRate = completedAttempts.length > 0 ? (passCount / completedAttempts.length) * 100 : 0;

    return NextResponse.json({
      ...exam,
      stats: {
        totalAttempts: exam.attempts.length,
        completedAttempts: completedAttempts.length,
        inProgressAttempts: exam.attempts.filter((a) => a.status === 'IN_PROGRESS').length,
        avgScore: Math.round(avgScore * 10) / 10,
        passRate: Math.round(passRate * 10) / 10,
        passCount,
        failCount: completedAttempts.length - passCount,
      },
    });
  } catch (error) {
    console.error('Error fetching exam:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات آزمون' }, { status: 500 });
  }
}

// PATCH /api/admin/exams/[examId] - Update exam
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ examId: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { examId } = await params;
    const body = await request.json();

    const existing = await db.exam.findUnique({ where: { id: examId } });
    if (!existing) {
      return NextResponse.json({ error: 'آزمون یافت نشد' }, { status: 404 });
    }

    const updateData: Record<string, unknown> = {};
    const allowedFields = [
      'title', 'description', 'skillProgramId', 'type',
      'durationMinutes', 'passingScore', 'maxAttempts',
      'shuffleQuestions', 'showResults', 'isActive', 'openAt', 'closeAt',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        if (field === 'openAt' || field === 'closeAt') {
          updateData[field] = body[field] ? new Date(body[field]) : null;
        } else if (field === 'durationMinutes' || field === 'maxAttempts') {
          updateData[field] = parseInt(body[field]) || existing[field as keyof typeof existing];
        } else if (field === 'passingScore') {
          updateData[field] = parseFloat(body[field]) || existing[field as keyof typeof existing];
        } else if (field === 'shuffleQuestions' || field === 'isActive') {
          updateData[field] = Boolean(body[field]);
        } else if (field === 'skillProgramId') {
          updateData[field] = body[field] || null;
        } else if (field === 'description') {
          updateData[field] = body[field]?.trim() || null;
        } else {
          updateData[field] = body[field];
        }
      }
    }

    const exam = await db.exam.update({
      where: { id: examId },
      data: updateData,
      include: {
        skillProgram: { select: { id: true, name: true } },
        _count: { select: { questions: true, attempts: true } },
      },
    });

    return NextResponse.json(exam);
  } catch (error) {
    console.error('Error updating exam:', error);
    return NextResponse.json({ error: 'خطا در بروزرسانی آزمون' }, { status: 500 });
  }
}

// DELETE /api/admin/exams/[examId] - Soft delete (deactivate)
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ examId: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { examId } = await params;

    const existing = await db.exam.findUnique({ where: { id: examId } });
    if (!existing) {
      return NextResponse.json({ error: 'آزمون یافت نشد' }, { status: 404 });
    }

    await db.exam.update({
      where: { id: examId },
      data: { isActive: false },
    });

    return NextResponse.json({ message: 'آزمون با موفقیت غیرفعال شد' });
  } catch (error) {
    console.error('Error deleting exam:', error);
    return NextResponse.json({ error: 'خطا در حذف آزمون' }, { status: 500 });
  }
}
