import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

// GET /api/admin/exams - List all exams with stats
export async function GET(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search') || '';
    const type = searchParams.get('type') || '';
    const isActive = searchParams.get('isActive') || '';
    const skillProgramId = searchParams.get('skillProgramId') || '';

    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (type) where.type = type;
    if (isActive === 'true') where.isActive = true;
    if (isActive === 'false') where.isActive = false;
    if (skillProgramId) where.skillProgramId = skillProgramId;

    const [exams, total] = await Promise.all([
      db.exam.findMany({
        where,
        include: {
          skillProgram: { select: { id: true, name: true } },
          _count: { select: { questions: true, attempts: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.exam.count({ where }),
    ]);

    return NextResponse.json({
      داده‌ها: exams,
      صفحه‌بندی: {
        صفحه: page,
        حجم: limit,
        کل: total,
        تعداد_صفحات: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching exams:', error);
    return NextResponse.json({ error: 'خطا در دریافت آزمون‌ها' }, { status: 500 });
  }
}

// POST /api/admin/exams - Create new exam
export async function POST(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const body = await request.json();
    const {
      title,
      description,
      skillProgramId,
      type = 'QUIZ',
      durationMinutes = 30,
      passingScore = 10,
      maxAttempts = 1,
      shuffleQuestions = true,
      showResults = 'AFTER_SUBMIT',
      isActive = true,
      openAt,
      closeAt,
    } = body;

    if (!title?.trim()) {
      return NextResponse.json({ error: 'عنوان آزمون الزامی است' }, { status: 400 });
    }

    const exam = await db.exam.create({
      data: {
        title: title.trim(),
        description: description?.trim() || null,
        skillProgramId: skillProgramId || null,
        type,
        durationMinutes: parseInt(durationMinutes) || 30,
        passingScore: parseFloat(passingScore) || 10,
        maxAttempts: parseInt(maxAttempts) || 1,
        shuffleQuestions: Boolean(shuffleQuestions),
        showResults,
        isActive: Boolean(isActive),
        openAt: openAt ? new Date(openAt) : null,
        closeAt: closeAt ? new Date(closeAt) : null,
      },
      include: {
        skillProgram: { select: { id: true, name: true } },
        _count: { select: { questions: true, attempts: true } },
      },
    });

    return NextResponse.json(exam, { status: 201 });
  } catch (error) {
    console.error('Error creating exam:', error);
    return NextResponse.json({ error: 'خطا در ایجاد آزمون' }, { status: 500 });
  }
}
