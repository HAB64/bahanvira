import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, setAdminSession } from '@/lib/admin-auth';

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json(
        { error: 'نام کاربری و رمز عبور الزامی است' },
        { status: 400 }
      );
    }

    // Use Prisma with Neon PostgreSQL
    let admin: { id: string; username: string; passwordHash: string } | null = null;
    try {
      admin = await db.adminUser.findUnique({
        where: { username },
        select: { id: true, username: true, passwordHash: true },
      });
    } catch (dbError) {
      console.error('Database connection error:', dbError);
      return NextResponse.json(
        { error: 'اتصال به دیتابیس برقرار نیست. لطفاً دیتابیس را بررسی کنید.' },
        { status: 503 }
      );
    }

    if (!admin || admin.passwordHash !== hashPassword(password)) {
      return NextResponse.json(
        { error: 'نام کاربری یا رمز عبور اشتباه است' },
        { status: 401 }
      );
    }

    await setAdminSession(username);

    return NextResponse.json({ success: true, username });
  } catch {
    return NextResponse.json(
      { error: 'خطا در ورود' },
      { status: 500 }
    );
  }
}
