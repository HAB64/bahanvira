/**
 * Web Vitals Reporter API — دریافت متریک‌های واقعی از کلاینت
 * ذخیره در EventLog برای تحلیل تاریخی
 */
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, value, rating, url } = body;

    if (!name || value === undefined) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Store in EventLog for historical analysis
    try {
      await db.eventLog.create({
        data: {
          event: `WEB_VITAL_${name}`,
          category: 'performance',
          label: `${name}: ${value} (${rating || 'unknown'})`,
          page: url || '',
          metadata: {
            name,
            value,
            rating,
            url,
            timestamp: new Date().toISOString(),
          },
        },
      });
    } catch {
      // EventLog may not exist — silently fail
      console.warn('[WebVitals] Could not save to EventLog');
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('[WebVitals Error]', error);
    return NextResponse.json({ error: 'Failed to process web vital' }, { status: 500 });
  }
}

/**
 * GET — دریافت آخرین متریک‌های جمع‌آوری‌شده
 */
export async function GET(req: NextRequest) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const hasSession = cookieHeader.includes('admin_session');
    if (!hasSession) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get last 100 web vital events
    let vitals: any[] = [];
    try {
      vitals = await db.eventLog.findMany({
        where: { event: { startsWith: 'WEB_VITAL_' } },
        orderBy: { createdAt: 'desc' },
        take: 100,
      });
    } catch {
      // EventLog may not exist
    }

    // Aggregate by metric name
    const aggregated: Record<string, { values: number[]; avg: number; p75: number; count: number; rating: string }> = {};

    for (const v of vitals) {
      const data = v.metadata as any;
      if (!data?.name) continue;

      if (!aggregated[data.name]) {
        aggregated[data.name] = { values: [], avg: 0, p75: 0, count: 0, rating: '' };
      }

      aggregated[data.name].values.push(Number(data.value));
      aggregated[data.name].count++;
    }

    // Calculate statistics
    for (const [name, agg] of Object.entries(aggregated)) {
      const sorted = agg.values.sort((a, b) => a - b);
      agg.avg = Math.round((sorted.reduce((s, v) => s + v, 0) / sorted.length) * 100) / 100;
      const p75Index = Math.floor(sorted.length * 0.75);
      agg.p75 = Math.round(sorted[p75Index] * 100) / 100;

      // Determine rating based on metric type and p75
      const p75 = agg.p75;
      if (name === 'LCP') agg.rating = p75 <= 2.5 ? 'good' : p75 <= 4 ? 'needs-improvement' : 'poor';
      else if (name === 'INP') agg.rating = p75 <= 200 ? 'good' : p75 <= 500 ? 'needs-improvement' : 'poor';
      else if (name === 'CLS') agg.rating = p75 <= 0.1 ? 'good' : p75 <= 0.25 ? 'needs-improvement' : 'poor';
      else if (name === 'FCP') agg.rating = p75 <= 1.8 ? 'good' : p75 <= 3 ? 'needs-improvement' : 'poor';
      else if (name === 'TTFB') agg.rating = p75 <= 0.8 ? 'good' : p75 <= 1.8 ? 'needs-improvement' : 'poor';
      else agg.rating = 'needs-improvement';
    }

    return NextResponse.json({ aggregated, totalRecords: vitals.length });
  } catch (error) {
    console.error('[WebVitals GET Error]', error);
    return NextResponse.json({ error: 'Failed to fetch web vitals' }, { status: 500 });
  }
}
