import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/white-label/[tenantId] — Get White-Label config for tenant
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ tenantId: string }> }
) {
  try {
    const { tenantId } = await params;
    const config = await db.whiteLabelConfig.findUnique({
      where: { tenantId },
      include: {
        tenant: { select: { id: true, name: true, slug: true, plan: true, status: true, domain: true } },
      },
    });

    if (!config) {
      return NextResponse.json({ error: 'تنظیمات White-Label یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ config });
  } catch (error: unknown) {
    console.error('White-label get error:', error);
    return NextResponse.json({ error: 'خطا در دریافت تنظیمات' }, { status: 500 });
  }
}

// PUT /api/admin/white-label/[tenantId] — Update White-Label config
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ tenantId: string }> }
) {
  try {
    const { tenantId } = await params;
    const body = await req.json();

    const config = await db.whiteLabelConfig.findUnique({
      where: { tenantId },
    });
    if (!config) {
      return NextResponse.json({ error: 'تنظیمات White-Label یافت نشد' }, { status: 404 });
    }

    const updated = await db.whiteLabelConfig.update({
      where: { tenantId },
      data: {
        ...(body.brandName && { brandName: body.brandName }),
        ...(body.brandSlogan !== undefined && { brandSlogan: body.brandSlogan }),
        ...(body.logoUrl !== undefined && { logoUrl: body.logoUrl }),
        ...(body.faviconUrl !== undefined && { faviconUrl: body.faviconUrl }),
        ...(body.primaryColor && { primaryColor: body.primaryColor }),
        ...(body.secondaryColor !== undefined && { secondaryColor: body.secondaryColor }),
        ...(body.accentColor !== undefined && { accentColor: body.accentColor }),
        ...(body.fontFamily !== undefined && { fontFamily: body.fontFamily }),
        ...(body.borderRadius !== undefined && { borderRadius: body.borderRadius }),
        ...(body.customDomain !== undefined && { customDomain: body.customDomain }),
        ...(body.customEmailFrom !== undefined && { customEmailFrom: body.customEmailFrom }),
        ...(body.customSmsFrom !== undefined && { customSmsFrom: body.customSmsFrom }),
        ...(body.loginPageTitle !== undefined && { loginPageTitle: body.loginPageTitle }),
        ...(body.loginPageSubtitle !== undefined && { loginPageSubtitle: body.loginPageSubtitle }),
        ...(body.loginBackground !== undefined && { loginBackground: body.loginBackground }),
        ...(body.footerText !== undefined && { footerText: body.footerText }),
        ...(body.termsUrl !== undefined && { termsUrl: body.termsUrl }),
        ...(body.privacyUrl !== undefined && { privacyUrl: body.privacyUrl }),
        ...(body.isActive !== undefined && { isActive: body.isActive }),
      },
    });

    return NextResponse.json({ config: updated });
  } catch (error: unknown) {
    console.error('White-label update error:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی تنظیمات' }, { status: 500 });
  }
}
