import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/white-label — List all White-Label configs
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const tenantId = url.searchParams.get('tenantId');

    const where: Record<string, unknown> = {};
    if (tenantId) where.tenantId = tenantId;

    const configs = await db.whiteLabelConfig.findMany({
      where,
      include: {
        tenant: { select: { id: true, name: true, slug: true, plan: true, status: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    const totalConfigs = await db.whiteLabelConfig.count();
    const activeConfigs = await db.whiteLabelConfig.count({ where: { isActive: true } });

    return NextResponse.json({
      configs,
      stats: { total: totalConfigs, active: activeConfigs },
    });
  } catch (error: unknown) {
    console.error('White-label list error:', error);
    return NextResponse.json({ error: 'خطا در دریافت تنظیمات White-Label' }, { status: 500 });
  }
}

// POST /api/admin/white-label — Create White-Label config
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      tenantId, brandName, brandSlogan, logoUrl, faviconUrl,
      primaryColor, secondaryColor, accentColor, fontFamily, borderRadius,
      customDomain, customEmailFrom, customSmsFrom,
      loginPageTitle, loginPageSubtitle, loginBackground,
      footerText, termsUrl, privacyUrl,
    } = body;

    if (!tenantId || !brandName) {
      return NextResponse.json({ error: 'Tenant و نام برند الزامی است' }, { status: 400 });
    }

    // Check if config already exists for this tenant
    const existing = await db.whiteLabelConfig.findUnique({
      where: { tenantId },
    });
    if (existing) {
      return NextResponse.json({ error: 'تنظیمات White-Label برای این Tenant قبلاً وجود دارد' }, { status: 409 });
    }

    const config = await db.whiteLabelConfig.create({
      data: {
        tenantId,
        brandName,
        brandSlogan: brandSlogan || null,
        logoUrl: logoUrl || null,
        faviconUrl: faviconUrl || null,
        primaryColor: primaryColor || '#0d9488',
        secondaryColor: secondaryColor || null,
        accentColor: accentColor || null,
        fontFamily: fontFamily || null,
        borderRadius: borderRadius || '0.5rem',
        customDomain: customDomain || null,
        customEmailFrom: customEmailFrom || null,
        customSmsFrom: customSmsFrom || null,
        loginPageTitle: loginPageTitle || null,
        loginPageSubtitle: loginPageSubtitle || null,
        loginBackground: loginBackground || null,
        footerText: footerText || null,
        termsUrl: termsUrl || null,
        privacyUrl: privacyUrl || null,
      },
    });

    return NextResponse.json({ config });
  } catch (error: unknown) {
    console.error('White-label create error:', error);
    return NextResponse.json({ error: 'خطا در ایجاد تنظیمات White-Label' }, { status: 500 });
  }
}
