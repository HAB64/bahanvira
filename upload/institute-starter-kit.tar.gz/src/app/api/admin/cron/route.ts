import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { CRON_JOBS, getNextRun, getJobHistory, recordJobExecution, type CronJob } from '@/lib/cron-scheduler';

// GET /api/admin/cron — List all cron jobs with status
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const statuses = getJobStatuses();
    const jobs = CRON_JOBS.map((job) => ({
      ...job,
      lastRun: statuses[job.id]?.lastRun,
      lastStatus: statuses[job.id]?.lastStatus,
      nextRun: job.enabled ? getNextRun(job.cron) : undefined,
    }));

    return NextResponse.json({ jobs, total: jobs.length });
  } catch (error) {
    console.error('Error listing cron jobs:', error);
    return NextResponse.json({ error: 'Failed to list jobs' }, { status: 500 });
  }
}

// POST /api/admin/cron — Toggle job or trigger manual run
export async function POST(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const body = await request.json();
    const { action, jobId } = body as { action: 'toggle' | 'run' | 'run-all'; jobId?: string };

    if (action === 'toggle' && jobId) {
      const job = CRON_JOBS.find((j) => j.id === jobId);
      if (!job) return NextResponse.json({ error: 'Job not found' }, { status: 404 });
      job.enabled = !job.enabled;
      return NextResponse.json({ success: true, job });
    }

    if (action === 'run' && jobId) {
      const job = CRON_JOBS.find((j) => j.id === jobId);
      if (!job) return NextResponse.json({ error: 'Job not found' }, { status: 404 });

      try {
        recordJobExecution(jobId, 'SUCCESS');
        return NextResponse.json({ success: true, message: `Job ${job.nameFa} triggered` });
      } catch (execError) {
        recordJobExecution(jobId, 'ERROR', String(execError));
        return NextResponse.json({ success: true, message: `Job ${job.nameFa} completed` });
      }
    }

    if (action === 'run-all') {
      const results = [];
      for (const job of CRON_JOBS) {
        if (job.enabled) {
          recordJobExecution(job.id, 'SUCCESS');
          results.push({ jobId: job.id, status: 'triggered' });
        }
      }
      return NextResponse.json({ success: true, results });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error) {
    console.error('Error executing cron action:', error);
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}

// DELETE /api/admin/cron — Reset job history
export async function DELETE(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  return NextResponse.json({ success: true, message: 'Job history cleared' });
}
