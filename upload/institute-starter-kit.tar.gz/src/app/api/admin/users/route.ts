import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword } from '@/lib/admin-auth';

// GET /api/admin/users — List all admin users with their roles
export async function GET() {
  try {
    const users = await db.adminUser.findMany({
      include: {
        role: {
          include: {
            permissions: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Don't expose passwordHash
    const sanitized = users.map(({ passwordHash, ...user }) => ({
      ...user,
      role: user.role
        ? {
            ...user.role,
            permissions: user.role.permissions,
          }
        : null,
    }));

    return NextResponse.json(sanitized);
  } catch (error) {
    console.error('Failed to fetch users:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت لیست کاربران' },
      { status: 500 }
    );
  }
}

// POST /api/admin/users — Create a new admin user
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { username, password, displayName, roleId, isActive } = body;

    if (!username || !password) {
      return NextResponse.json(
        { error: 'نام کاربری و رمز عبور الزامی است' },
        { status: 400 }
      );
    }

    if (username.length < 3) {
      return NextResponse.json(
        { error: 'نام کاربری باید حداقل ۳ کاراکتر باشد' },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' },
        { status: 400 }
      );
    }

    // Check if username already exists
    const existing = await db.adminUser.findUnique({
      where: { username },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'این نام کاربری قبلاً ثبت شده است' },
        { status: 409 }
      );
    }

    // If roleId provided, verify it exists
    if (roleId) {
      const role = await db.adminRole.findUnique({
        where: { id: roleId },
      });
      if (!role) {
        return NextResponse.json(
          { error: 'نقش مشخص شده وجود ندارد' },
          { status: 400 }
        );
      }
    }

    const passwordHash = hashPassword(password);

    const user = await db.adminUser.create({
      data: {
        username,
        passwordHash,
        displayName: displayName || '',
        roleId: roleId || null,
        isActive: isActive !== undefined ? isActive : true,
      },
      include: {
        role: {
          include: {
            permissions: true,
          },
        },
      },
    });

    // Don't expose passwordHash in response
    const { passwordHash: _, ...sanitized } = user;

    return NextResponse.json(sanitized, { status: 201 });
  } catch (error) {
    console.error('Failed to create user:', error);
    return NextResponse.json(
      { error: 'خطا در ایجاد کاربر' },
      { status: 500 }
    );
  }
}
