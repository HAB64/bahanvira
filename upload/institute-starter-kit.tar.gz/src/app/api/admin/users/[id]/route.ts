import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword } from '@/lib/admin-auth';

// GET /api/admin/users/[id] — Get a single user
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const user = await db.adminUser.findUnique({
      where: { id },
      include: {
        role: {
          include: {
            permissions: true,
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'کاربر یافت نشد' },
        { status: 404 }
      );
    }

    const { passwordHash, ...sanitized } = user;
    return NextResponse.json(sanitized);
  } catch (error) {
    console.error('Failed to fetch user:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت اطلاعات کاربر' },
      { status: 500 }
    );
  }
}

// PUT /api/admin/users/[id] — Update a user
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { username, password, displayName, roleId, isActive } = body;

    // Check if user exists
    const existing = await db.adminUser.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: 'کاربر یافت نشد' },
        { status: 404 }
      );
    }

    // If username changed, check uniqueness
    if (username && username !== existing.username) {
      const duplicate = await db.adminUser.findUnique({
        where: { username },
      });
      if (duplicate) {
        return NextResponse.json(
          { error: 'این نام کاربری قبلاً ثبت شده است' },
          { status: 409 }
        );
      }
    }

    // If roleId provided, verify it exists
    if (roleId) {
      const role = await db.adminRole.findUnique({
        where: { id: roleId },
      });
      if (!role) {
        return NextResponse.json(
          { error: 'نقش مشخص شده وجود ندارد' },
          { status: 400 }
        );
      }
    }

    // Build update data
    const updateData: Record<string, unknown> = {};
    if (username !== undefined) updateData.username = username;
    if (displayName !== undefined) updateData.displayName = displayName;
    if (roleId !== undefined) updateData.roleId = roleId || null;
    if (isActive !== undefined) updateData.isActive = isActive;

    // Only update password if a new one is provided
    if (password && password.length >= 6) {
      updateData.passwordHash = hashPassword(password);
    }

    const user = await db.adminUser.update({
      where: { id },
      data: updateData,
      include: {
        role: {
          include: {
            permissions: true,
          },
        },
      },
    });

    const { passwordHash, ...sanitized } = user;
    return NextResponse.json(sanitized);
  } catch (error) {
    console.error('Failed to update user:', error);
    return NextResponse.json(
      { error: 'خطا در به‌روزرسانی کاربر' },
      { status: 500 }
    );
  }
}

// DELETE /api/admin/users/[id] — Delete a user
export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const existing = await db.adminUser.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: 'کاربر یافت نشد' },
        { status: 404 }
      );
    }

    await db.adminUser.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to delete user:', error);
    return NextResponse.json(
      { error: 'خطا در حذف کاربر' },
      { status: 500 }
    );
  }
}
