import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { db } from '@/lib/db';
import { predictChurn } from '@/lib/ai/prediction-engine';

// GET /api/admin/predictions/churn — Get churn predictions
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const existing = await db.churnPrediction.findMany({
      include: {
        lead: { select: { id: true, name: true, phone: true, stage: true, cluster: true } },
      },
      orderBy: { riskScore: 'desc' },
    });

    return NextResponse.json({
      highRisk: existing.filter((p) => p.riskLevel === 'HIGH' || p.riskLevel === 'CRITICAL').length,
      mediumRisk: existing.filter((p) => p.riskLevel === 'MEDIUM').length,
      lowRisk: existing.filter((p) => p.riskLevel === 'LOW').length,
      predictions: existing,
    });
  } catch (error) {
    console.error('Error fetching churn predictions:', error);
    return NextResponse.json({ error: 'Failed to fetch churn predictions' }, { status: 500 });
  }
}

// POST /api/admin/predictions/churn — Run churn prediction analysis
export async function POST(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const result = await predictChurn();
    return NextResponse.json(result);
  } catch (error) {
    console.error('Error running churn prediction:', error);
    return NextResponse.json({ error: 'Failed to run churn prediction' }, { status: 500 });
  }
}
