import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { predictRevenue, savePrediction } from '@/lib/ai/prediction-engine';

// GET /api/admin/predictions/revenue — Get revenue predictions (next 3 months)
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const result = await predictRevenue(3);
    await savePrediction('REVENUE', 'MONTHLY', result.predictions, 'LINEAR');
    return NextResponse.json(result);
  } catch (error) {
    console.error('Error generating revenue predictions:', error);
    return NextResponse.json({ error: 'Failed to generate revenue predictions' }, { status: 500 });
  }
}
