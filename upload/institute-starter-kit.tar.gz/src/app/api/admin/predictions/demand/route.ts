import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { predictCourseDemand } from '@/lib/ai/prediction-engine';

// GET /api/admin/predictions/demand — Get course demand predictions
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const result = await predictCourseDemand();
    return NextResponse.json({ demands: result });
  } catch (error) {
    console.error('Error generating demand predictions:', error);
    return NextResponse.json({ error: 'Failed to generate demand predictions' }, { status: 500 });
  }
}
