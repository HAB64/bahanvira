import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { db } from '@/lib/db';
import {
  predictRevenue,
  predictEnrollment,
  predictChurn,
  predictCourseDemand,
  savePrediction,
} from '@/lib/ai/prediction-engine';

// GET /api/admin/predictions — Get all predictions with optional type filter
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const period = searchParams.get('period');
    const limit = parseInt(searchParams.get('limit') ?? '50');

    const where: Record<string, unknown> = {};
    if (type) where.type = type;
    if (period) where.period = period;

    const predictions = await db.prediction.findMany({
      where,
      orderBy: { targetDate: 'desc' },
      take: limit,
    });

    return NextResponse.json({ predictions, total: predictions.length });
  } catch (error) {
    console.error('Error fetching predictions:', error);
    return NextResponse.json({ error: 'Failed to fetch predictions' }, { status: 500 });
  }
}

// POST /api/admin/predictions — Generate new predictions for a specific type
export async function POST(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { type, monthsAhead = 3 } = body as { type: string; monthsAhead?: number };

    if (!type) {
      return NextResponse.json({ error: 'Type is required' }, { status: 400 });
    }

    let result: unknown;
    const months = Math.min(12, Math.max(1, monthsAhead));

    switch (type) {
      case 'REVENUE': {
        const revenue = await predictRevenue(months);
        await savePrediction('REVENUE', 'MONTHLY', revenue.predictions, 'LINEAR');
        result = revenue;
        break;
      }
      case 'ENROLLMENT': {
        const enrollment = await predictEnrollment(months);
        await savePrediction('ENROLLMENT', 'MONTHLY', enrollment.predictions, 'EXPONENTIAL');
        result = enrollment;
        break;
      }
      case 'CHURN': {
        const churn = await predictChurn();
        result = churn;
        break;
      }
      case 'DEMAND': {
        const demand = await predictCourseDemand();
        result = demand;
        break;
      }
      default:
        return NextResponse.json({ error: `Unknown prediction type: ${type}` }, { status: 400 });
    }

    return NextResponse.json({ success: true, type, result });
  } catch (error) {
    console.error('Error generating predictions:', error);
    return NextResponse.json({ error: 'Failed to generate predictions' }, { status: 500 });
  }
}
