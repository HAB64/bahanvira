import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { predictEnrollment, savePrediction } from '@/lib/ai/prediction-engine';

// GET /api/admin/predictions/enrollment — Get enrollment predictions (next 3 months)
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const result = await predictEnrollment(3);
    await savePrediction('ENROLLMENT', 'MONTHLY', result.predictions, 'EXPONENTIAL');
    return NextResponse.json(result);
  } catch (error) {
    console.error('Error generating enrollment predictions:', error);
    return NextResponse.json({ error: 'Failed to generate enrollment predictions' }, { status: 500 });
  }
}
