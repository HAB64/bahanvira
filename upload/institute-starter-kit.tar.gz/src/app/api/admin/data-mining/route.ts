import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import {
  runCustomerClustering,
  mineCourseAssociations,
  analyzeCohorts,
  computeRFMScores,
} from '@/lib/data-mining';

// GET /api/admin/data-mining — Run data mining operations
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const operation = searchParams.get('op') || 'clusters';
  const k = parseInt(searchParams.get('k') || '5');

  try {
    switch (operation) {
      case 'clusters': {
        const result = await runCustomerClustering(k);
        return NextResponse.json({ operation: 'clustering', ...result });
      }
      case 'associations': {
        const rules = await mineCourseAssociations(
          parseFloat(searchParams.get('support') || '0.1'),
          parseFloat(searchParams.get('confidence') || '0.5')
        );
        return NextResponse.json({ operation: 'association_rules', rules });
      }
      case 'cohorts': {
        const result = await analyzeCohorts();
        return NextResponse.json({ operation: 'cohort_analysis', ...result });
      }
      case 'rfm': {
        const scores = await computeRFMScores();
        return NextResponse.json({ operation: 'rfm_analysis', customers: scores });
      }
      default:
        return NextResponse.json({ error: `Unknown operation: ${operation}` }, { status: 400 });
    }
  } catch (error) {
    console.error('Data mining error:', error);
    return NextResponse.json(
      { error: 'Data mining failed', details: String(error) },
      { status: 500 }
    );
  }
}
