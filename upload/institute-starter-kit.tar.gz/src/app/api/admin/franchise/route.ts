import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/franchise — List franchise contracts
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const status = url.searchParams.get('status');

    const where: Record<string, unknown> = {};
    if (status) where.status = status;

    const contracts = await db.franchiseContract.findMany({
      where,
      include: {
        tenant: { select: { id: true, name: true, slug: true, primaryColor: true } },
        parentTenant: { select: { id: true, name: true, slug: true } },
        _count: { select: { payments: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Stats
    const totalContracts = await db.franchiseContract.count();
    const activeContracts = await db.franchiseContract.count({ where: { status: 'ACTIVE' } });
    const pendingContracts = await db.franchiseContract.count({ where: { status: 'PENDING' } });

    // Total royalty from paid payments
    const paidPayments = await db.franchisePayment.findMany({
      where: { status: 'PAID' },
      select: { royaltyAmount: true },
    });
    const totalRoyalty = paidPayments.reduce((sum, p) => sum + p.royaltyAmount, 0);

    // Pending payments
    const pendingPayments = await db.franchisePayment.findMany({
      where: { status: 'PENDING' },
      select: { royaltyAmount: true },
    });
    const pendingRoyalty = pendingPayments.reduce((sum, p) => sum + p.royaltyAmount, 0);

    return NextResponse.json({
      contracts,
      stats: {
        total: totalContracts,
        active: activeContracts,
        pending: pendingContracts,
        totalRoyalty,
        pendingRoyalty,
      },
    });
  } catch (error: unknown) {
    console.error('Franchise list error:', error);
    return NextResponse.json({ error: 'خطا در دریافت قراردادها' }, { status: 500 });
  }
}

// POST /api/admin/franchise — Create franchise contract
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      tenantId, parentTenantId, contractNumber,
      startDate, endDate, royaltyPercent, fixedRoyalty,
      minRevenue, terms, notes,
    } = body;

    if (!tenantId || !parentTenantId || !contractNumber || !startDate || !endDate) {
      return NextResponse.json({ error: 'فیلدهای الزامی ناقص است' }, { status: 400 });
    }

    // Check contract number uniqueness
    const existing = await db.franchiseContract.findUnique({
      where: { contractNumber },
    });
    if (existing) {
      return NextResponse.json({ error: 'شماره قرارداد تکراری است' }, { status: 409 });
    }

    const contract = await db.franchiseContract.create({
      data: {
        tenantId,
        parentTenantId,
        contractNumber,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        status: 'PENDING',
        royaltyPercent: royaltyPercent || 0,
        fixedRoyalty: fixedRoyalty || null,
        minRevenue: minRevenue || null,
        terms: terms || null,
        notes: notes || null,
      },
      include: {
        tenant: { select: { name: true, slug: true } },
        parentTenant: { select: { name: true, slug: true } },
      },
    });

    return NextResponse.json({ contract });
  } catch (error: unknown) {
    console.error('Franchise create error:', error);
    return NextResponse.json({ error: 'خطا در ایجاد قرارداد' }, { status: 500 });
  }
}
