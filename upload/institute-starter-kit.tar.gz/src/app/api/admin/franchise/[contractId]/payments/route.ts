import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/franchise/[contractId]/payments — List payments for contract
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ contractId: string }> }
) {
  try {
    const { contractId } = await params;
    const payments = await db.franchisePayment.findMany({
      where: { contractId },
      orderBy: { periodStart: 'desc' },
    });

    return NextResponse.json({ payments });
  } catch (error: unknown) {
    console.error('Franchise payments list error:', error);
    return NextResponse.json({ error: 'خطا در دریافت پرداخت‌ها' }, { status: 500 });
  }
}

// POST /api/admin/franchise/[contractId]/payments — Record a payment
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ contractId: string }> }
) {
  try {
    const { contractId } = await params;
    const body = await req.json();
    const { periodStart, periodEnd, revenue, royaltyAmount, status, receiptNumber, notes } = body;

    if (!periodStart || !periodEnd) {
      return NextResponse.json({ error: 'تاریخ شروع و پایان دوره الزامی است' }, { status: 400 });
    }

    const contract = await db.franchiseContract.findUnique({
      where: { id: contractId },
    });
    if (!contract) {
      return NextResponse.json({ error: 'قرارداد یافت نشد' }, { status: 404 });
    }

    // Auto-calculate royalty if not provided
    let calculatedRoyalty = royaltyAmount || 0;
    if (!royaltyAmount && revenue && contract.royaltyPercent) {
      calculatedRoyalty = (revenue * contract.royaltyPercent) / 100;
      if (contract.fixedRoyalty) {
        calculatedRoyalty += contract.fixedRoyalty;
      }
    }

    const payment = await db.franchisePayment.create({
      data: {
        contractId,
        periodStart: new Date(periodStart),
        periodEnd: new Date(periodEnd),
        revenue: revenue || 0,
        royaltyAmount: calculatedRoyalty,
        status: status || 'PENDING',
        receiptNumber: receiptNumber || null,
        notes: notes || null,
        ...(status === 'PAID' && { paidAt: new Date() }),
      },
    });

    return NextResponse.json({ payment });
  } catch (error: unknown) {
    console.error('Franchise payment create error:', error);
    return NextResponse.json({ error: 'خطا در ثبت پرداخت' }, { status: 500 });
  }
}
