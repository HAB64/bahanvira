import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/franchise/[contractId] — Get contract details
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ contractId: string }> }
) {
  try {
    const { contractId } = await params;
    const contract = await db.franchiseContract.findUnique({
      where: { id: contractId },
      include: {
        tenant: { select: { id: true, name: true, slug: true, primaryColor: true, domain: true } },
        parentTenant: { select: { id: true, name: true, slug: true } },
        payments: { orderBy: { periodStart: 'desc' } },
      },
    });

    if (!contract) {
      return NextResponse.json({ error: 'قرارداد یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ contract });
  } catch (error: unknown) {
    console.error('Franchise get error:', error);
    return NextResponse.json({ error: 'خطا در دریافت قرارداد' }, { status: 500 });
  }
}

// PUT /api/admin/franchise/[contractId] — Update contract
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ contractId: string }> }
) {
  try {
    const { contractId } = await params;
    const body = await req.json();

    const contract = await db.franchiseContract.findUnique({
      where: { id: contractId },
    });
    if (!contract) {
      return NextResponse.json({ error: 'قرارداد یافت نشد' }, { status: 404 });
    }

    const updated = await db.franchiseContract.update({
      where: { id: contractId },
      data: {
        ...(body.status && { status: body.status }),
        ...(body.royaltyPercent !== undefined && { royaltyPercent: body.royaltyPercent }),
        ...(body.fixedRoyalty !== undefined && { fixedRoyalty: body.fixedRoyalty }),
        ...(body.minRevenue !== undefined && { minRevenue: body.minRevenue }),
        ...(body.terms !== undefined && { terms: body.terms }),
        ...(body.notes !== undefined && { notes: body.notes }),
        ...(body.startDate && { startDate: new Date(body.startDate) }),
        ...(body.endDate && { endDate: new Date(body.endDate) }),
      },
    });

    return NextResponse.json({ contract: updated });
  } catch (error: unknown) {
    console.error('Franchise update error:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی قرارداد' }, { status: 500 });
  }
}
