/**
 * A/B Testing Admin API — مدیریت و گزارش آزمایش‌ها
 */
import { NextRequest, NextResponse } from 'next/server';
import { EXPERIMENTS } from '@/lib/ab-testing';
import { getExperimentResults } from '@/lib/ab-testing/server';

export async function GET(req: NextRequest) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const hasSession = cookieHeader.includes('admin_session');
    if (!hasSession) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const experimentId = req.nextUrl.searchParams.get('experiment');

    if (experimentId) {
      const results = await getExperimentResults(experimentId);
      const experiment = EXPERIMENTS.find(e => e.id === experimentId);
      return NextResponse.json({ experiment, results });
    }

    const allResults = await Promise.all(
      EXPERIMENTS.map(async (exp) => ({
        ...exp,
        results: await getExperimentResults(exp.id),
      }))
    );

    return NextResponse.json({ experiments: allResults });
  } catch (error) {
    console.error('[AB Testing API Error]', error);
    return NextResponse.json({ error: 'Failed to fetch experiment data' }, { status: 500 });
  }
}
