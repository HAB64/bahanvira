import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * POST /api/admin/migrate-indexes
 * One-time endpoint to create database indexes on Neon PostgreSQL.
 * Call this once after deploying the new schema.
 * After successful execution, this endpoint can be removed.
 */
export async function POST() {
  try {
    const results: string[] = [];

    const allIndexes = [
      // Lead indexes
      'CREATE INDEX IF NOT EXISTS "Lead_stage_idx" ON "Lead"("stage")',
      'CREATE INDEX IF NOT EXISTS "Lead_cluster_idx" ON "Lead"("cluster")',
      'CREATE INDEX IF NOT EXISTS "Lead_createdAt_idx" ON "Lead"("createdAt")',
      'CREATE INDEX IF NOT EXISTS "Lead_source_idx" ON "Lead"("source")',
      'CREATE INDEX IF NOT EXISTS "Lead_assignedTo_idx" ON "Lead"("assignedTo")',
      'CREATE INDEX IF NOT EXISTS "Lead_referrerId_idx" ON "Lead"("referrerId")',
      'CREATE INDEX IF NOT EXISTS "Lead_stage_createdAt_idx" ON "Lead"("stage", "createdAt")',
      // ActivityLog indexes
      'CREATE INDEX IF NOT EXISTS "ActivityLog_leadId_idx" ON "ActivityLog"("leadId")',
      'CREATE INDEX IF NOT EXISTS "ActivityLog_followUpAt_idx" ON "ActivityLog"("followUpAt")',
      'CREATE INDEX IF NOT EXISTS "ActivityLog_type_idx" ON "ActivityLog"("type")',
      'CREATE INDEX IF NOT EXISTS "ActivityLog_leadId_type_idx" ON "ActivityLog"("leadId", "type")',
      // Payment indexes
      'CREATE INDEX IF NOT EXISTS "Payment_status_idx" ON "Payment"("status")',
      'CREATE INDEX IF NOT EXISTS "Payment_leadId_idx" ON "Payment"("leadId")',
      'CREATE INDEX IF NOT EXISTS "Payment_paidAt_idx" ON "Payment"("paidAt")',
      'CREATE INDEX IF NOT EXISTS "Payment_status_paidAt_idx" ON "Payment"("status", "paidAt")',
      // Task indexes
      'CREATE INDEX IF NOT EXISTS "Task_status_idx" ON "Task"("status")',
      'CREATE INDEX IF NOT EXISTS "Task_assignedTo_idx" ON "Task"("assignedTo")',
      'CREATE INDEX IF NOT EXISTS "Task_dueDate_idx" ON "Task"("dueDate")',
      'CREATE INDEX IF NOT EXISTS "Task_leadId_idx" ON "Task"("leadId")',
      'CREATE INDEX IF NOT EXISTS "Task_karAmuzId_idx" ON "Task"("karAmuzId")',
      // Ticket indexes
      'CREATE INDEX IF NOT EXISTS "Ticket_status_idx" ON "Ticket"("status")',
      'CREATE INDEX IF NOT EXISTS "Ticket_assignedTo_idx" ON "Ticket"("assignedTo")',
      'CREATE INDEX IF NOT EXISTS "Ticket_leadId_idx" ON "Ticket"("leadId")',
      'CREATE INDEX IF NOT EXISTS "Ticket_karAmuzId_idx" ON "Ticket"("karAmuzId")',
      // TicketResponse indexes
      'CREATE INDEX IF NOT EXISTS "TicketResponse_ticketId_idx" ON "TicketResponse"("ticketId")',
    ];

    for (const sql of allIndexes) {
      try {
        await db.$executeRawUnsafe(sql);
        results.push(`✓ ${sql}`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        results.push(`✗ ${sql} — ${msg}`);
      }
    }

    return NextResponse.json({
      پیام: 'ایندکس‌های دیتابیس ایجاد شدند',
      تعداد: allIndexes.length,
      نتایج: results,
    });
  } catch (error) {
    console.error('Migration error:', error);
    return NextResponse.json(
      { خطا: 'خطا در ایجاد ایندکس‌ها' },
      { status: 500 }
    );
  }
}
