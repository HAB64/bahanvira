import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { retryFailedSync } from '@/lib/tvet-integration';

// POST /api/admin/tvet/retry/[syncId] — Retry failed sync
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ syncId: string }> },
) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { syncId } = await params;
    const result = await retryFailedSync(syncId);
    return NextResponse.json({ success: true, result });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to retry sync';
    console.error('Error retrying TVET sync:', error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
