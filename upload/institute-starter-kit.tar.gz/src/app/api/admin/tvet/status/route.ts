import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { getSyncStatus, getTVETReport } from '@/lib/tvet-integration';

// GET /api/admin/tvet/status — Get sync status and compliance report
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const entityType = searchParams.get('entityType') ?? undefined;
    const entityId = searchParams.get('entityId') ?? undefined;
    const includeReport = searchParams.get('report') === 'true';

    const [syncStatus, report] = await Promise.all([
      getSyncStatus(entityType, entityId),
      includeReport ? getTVETReport() : Promise.resolve(null),
    ]);

    return NextResponse.json({
      syncs: syncStatus.syncs,
      total: syncStatus.total,
      ...(report ? { report } : {}),
    });
  } catch (error) {
    console.error('Error fetching TVET sync status:', error);
    return NextResponse.json({ error: 'Failed to fetch sync status' }, { status: 500 });
  }
}
