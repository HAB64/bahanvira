import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { syncSkillProgram, syncCertificate, syncAttendance } from '@/lib/tvet-integration';

// POST /api/admin/tvet/sync — Trigger sync for an entity
export async function POST(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { entityType, entityId, sessionId } = body as {
      entityType: 'SKILL_PROGRAM' | 'CERTIFICATE' | 'ATTENDANCE';
      entityId: string;
      sessionId?: string; // Required for ATTENDANCE sync
    };

    if (!entityType || !entityId) {
      return NextResponse.json(
        { error: 'entityType and entityId are required' },
        { status: 400 },
      );
    }

    let result;

    switch (entityType) {
      case 'SKILL_PROGRAM':
        result = await syncSkillProgram(entityId);
        break;
      case 'CERTIFICATE':
        result = await syncCertificate(entityId);
        break;
      case 'ATTENDANCE':
        if (!sessionId) {
          return NextResponse.json(
            { error: 'sessionId is required for ATTENDANCE sync' },
            { status: 400 },
          );
        }
        result = await syncAttendance(entityId, sessionId);
        break;
      default:
        return NextResponse.json(
          { error: `Unknown entity type: ${entityType}` },
          { status: 400 },
        );
    }

    return NextResponse.json({ success: true, result });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to sync';
    console.error('Error syncing with TVET:', error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
