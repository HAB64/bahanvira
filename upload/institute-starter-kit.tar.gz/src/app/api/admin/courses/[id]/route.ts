import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { id } = await params;
    const course = await db.course.findUnique({
      where: { id },
      include: {
        modules: { orderBy: { order: 'asc' } },
        reviews: true,
      },
    });

    if (!course) {
      return NextResponse.json({ error: 'دوره یافت نشد' }, { status: 404 });
    }

    return NextResponse.json(course);
  } catch {
    return NextResponse.json({ error: 'خطا در دریافت دوره' }, { status: 500 });
  }
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { id } = await params;
    const body = await request.json();
    const { modules, reviews, ...courseFields } = body;

    // Delete existing modules and reviews, then recreate
    await db.courseModule.deleteMany({ where: { courseId: id } });
    await db.courseReview.deleteMany({ where: { courseId: id } });

    const course = await db.course.update({
      where: { id },
      data: {
        ...courseFields,
        modules: {
          create: modules?.map((m: { title: string; lessons: string; duration: string; type: string; order: number }) => ({
            title: m.title,
            lessons: m.lessons,
            duration: m.duration,
            type: m.type,
            order: m.order,
          })) || [],
        },
        reviews: {
          create: reviews?.map((r: { name: string; role: string; rating: number; text: string; date: string }) => ({
            name: r.name,
            role: r.role,
            rating: r.rating,
            text: r.text,
            date: r.date,
          })) || [],
        },
      },
      include: {
        modules: { orderBy: { order: 'asc' } },
        reviews: true,
      },
    });

    return NextResponse.json(course);
  } catch (error) {
    console.error('Error updating course:', error);
    return NextResponse.json({ error: 'خطا در بروزرسانی دوره' }, { status: 500 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { id } = await params;
    await db.course.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'خطا در حذف دوره' }, { status: 500 });
  }
}
