import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

export async function GET() {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const courses = await db.course.findMany({
      include: {
        modules: { orderBy: { order: 'asc' } },
        reviews: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(courses);
  } catch {
    return NextResponse.json({ error: 'خطا در دریافت دوره‌ها' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const body = await request.json();
    const { modules, reviews, ...courseFields } = body;

    const course = await db.course.create({
      data: {
        ...courseFields,
        modules: {
          create: modules?.map((m: { title: string; lessons: string; duration: string; type: string; order: number }) => ({
            title: m.title,
            lessons: m.lessons,
            duration: m.duration,
            type: m.type,
            order: m.order,
          })) || [],
        },
        reviews: {
          create: reviews?.map((r: { name: string; role: string; rating: number; text: string; date: string }) => ({
            name: r.name,
            role: r.role,
            rating: r.rating,
            text: r.text,
            date: r.date,
          })) || [],
        },
      },
      include: {
        modules: { orderBy: { order: 'asc' } },
        reviews: true,
      },
    });

    return NextResponse.json(course, { status: 201 });
  } catch (error) {
    console.error('Error creating course:', error);
    return NextResponse.json({ error: 'خطا در ایجاد دوره' }, { status: 500 });
  }
}
