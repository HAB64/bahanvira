import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    // Lightweight KPI queries — avoids OOM from heavy aggregations
    const [totalLeads, activeEnrollments, totalRevenue, pendingTickets] = await Promise.all([
      db.lead.count({ where: { deletedAt: null } }).catch(() => 0),
      db.enrollment.count({ where: { status: 'ACTIVE' } }).catch(() => 0),
      db.payment.aggregate({ _sum: { amount: true }, where: { status: 'PAID' } })
        .then(r => r._sum.amount || 0).catch(() => 0),
      db.ticket.count({ where: { status: { in: ['OPEN', 'IN_PROGRESS'] } } }).catch(() => 0),
    ]);

    return NextResponse.json({
      status: 'ok',
      kpis: {
        totalLeads: Number(totalLeads) || 0,
        activeEnrollments: Number(activeEnrollments) || 0,
        revenue: Number(totalRevenue) || 0,
        pendingTickets: Number(pendingTickets) || 0,
      },
    }, {
      headers: { 'Cache-Control': 'no-store, max-age=0' },
    });
  } catch (error) {
    console.error('Dashboard KPI error:', error);
    return NextResponse.json({
      status: 'ok',
      kpis: {
        totalLeads: 0,
        activeEnrollments: 0,
        revenue: 0,
        pendingTickets: 0,
      },
    }, {
      headers: { 'Cache-Control': 'no-store, max-age=0' },
    });
  }
}
