import { NextResponse } from 'next/server';
import { getDb } from '@/lib/sqlite';

export const dynamic = 'force-dynamic';

export async function POST() {
  try {
    const db = getDb();

    // Check if already initialized
    const adminCount = db.prepare('SELECT COUNT(*) as c FROM AdminUser').get() as { c: number };

    if (adminCount.c > 0) {
      // Already has admin - just return credentials info
      const admin = db.prepare('SELECT username FROM AdminUser LIMIT 1').get() as { username: string };
      return NextResponse.json({
        adminUser: admin.username,
        adminPassword: 'admin123',
        tables: db.prepare("SELECT COUNT(*) as c FROM sqlite_master WHERE type='table'").get() as { c: number },
        message: 'دیتابیس قبلاً راه‌اندازی شده است',
      });
    }

    // This shouldn't happen normally since we seed the admin during first run
    return NextResponse.json({
      adminUser: 'admin',
      adminPassword: 'admin123',
      tables: db.prepare("SELECT COUNT(*) as c FROM sqlite_master WHERE type='table'").get() as { c: number },
    });
  } catch (error) {
    console.error('Database initialization error:', error);
    return NextResponse.json(
      { error: 'خطا در راه‌اندازی دیتابیس. لطفاً دوباره تلاش کنید.' },
      { status: 500 }
    );
  }
}
