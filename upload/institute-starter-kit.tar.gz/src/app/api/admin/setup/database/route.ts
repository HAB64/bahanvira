import { NextResponse } from 'next/server';
import { createHash } from 'crypto';
import { siteConfig } from '@/config/site';

function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

export async function POST(request: Request) {
  try {
    const { databaseUrl, directUrl } = await request.json();

    if (!databaseUrl) {
      return NextResponse.json(
        { error: 'آدرس دیتابیس الزامی است' },
        { status: 400 }
      );
    }

    const effectiveDirectUrl = directUrl || databaseUrl;

    // Use Neon serverless driver for setup
    const { neon } = await import('@neondatabase/serverless');
    const sql = neon(effectiveDirectUrl);

    // Test connection
    try {
      await sql`SELECT 1 as test`;
    } catch {
      return NextResponse.json(
        { error: 'اتصال به دیتابیس ناموفق بود. لطفاً آدرس را بررسی کنید.' },
        { status: 400 }
      );
    }

    // Create tables
    try {
      // Course table
      await sql`
        CREATE TABLE IF NOT EXISTS "Course" (
          "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
          "slug" TEXT UNIQUE NOT NULL,
          "title" TEXT NOT NULL,
          "subtitle" TEXT NOT NULL,
          "cluster" TEXT NOT NULL,
          "clusterLabel" TEXT NOT NULL,
          "level" TEXT NOT NULL,
          "levelOrder" INTEGER NOT NULL,
          "duration" TEXT NOT NULL,
          "sessions" INTEGER NOT NULL,
          "price" TEXT NOT NULL,
          "priceNote" TEXT,
          "description" TEXT NOT NULL,
          "highlights" TEXT NOT NULL,
          "icon" TEXT NOT NULL,
          "color" TEXT NOT NULL,
          "colorLight" TEXT NOT NULL,
          "colorDark" TEXT NOT NULL,
          "prerequisites" TEXT,
          "certificate" TEXT NOT NULL,
          "targetAudience" TEXT NOT NULL,
          "learningOutcomes" TEXT NOT NULL,
          "published" BOOLEAN NOT NULL DEFAULT true,
          "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
          "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW()
        )
      `;

      // CourseModule table
      await sql`
        CREATE TABLE IF NOT EXISTS "CourseModule" (
          "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
          "title" TEXT NOT NULL,
          "lessons" TEXT NOT NULL,
          "duration" TEXT NOT NULL,
          "type" TEXT NOT NULL,
          "order" INTEGER NOT NULL,
          "courseId" TEXT NOT NULL REFERENCES "Course"("id") ON DELETE CASCADE ON UPDATE CASCADE
        )
      `;

      // CourseReview table
      await sql`
        CREATE TABLE IF NOT EXISTS "CourseReview" (
          "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
          "name" TEXT NOT NULL,
          "role" TEXT NOT NULL,
          "rating" INTEGER NOT NULL,
          "text" TEXT NOT NULL,
          "date" TEXT NOT NULL,
          "courseId" TEXT NOT NULL REFERENCES "Course"("id") ON DELETE CASCADE ON UPDATE CASCADE
        )
      `;

      // BlogPost table
      await sql`
        CREATE TABLE IF NOT EXISTS "BlogPost" (
          "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
          "title" TEXT NOT NULL,
          "slug" TEXT UNIQUE NOT NULL,
          "content" TEXT NOT NULL,
          "excerpt" TEXT,
          "published" BOOLEAN NOT NULL DEFAULT false,
          "coverImage" TEXT,
          "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
          "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW()
        )
      `;

      // SiteSetting table
      await sql`
        CREATE TABLE IF NOT EXISTS "SiteSetting" (
          "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
          "key" TEXT UNIQUE NOT NULL,
          "value" TEXT NOT NULL
        )
      `;

      // AdminUser table
      await sql`
        CREATE TABLE IF NOT EXISTS "AdminUser" (
          "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
          "username" TEXT UNIQUE NOT NULL,
          "passwordHash" TEXT NOT NULL
        )
      `;

    } catch (tableError) {
      console.error('Table creation error:', tableError);
      return NextResponse.json(
        { error: 'خطا در ایجاد جداول دیتابیس. ممکن است جداول از قبل وجود داشته باشند.' },
        { status: 500 }
      );
    }

    // Create admin user (if not exists)
    try {
      const adminPasswordHash = hashPassword(siteConfig.defaultAdminPassword);
      await sql`
        INSERT INTO "AdminUser" ("username", "passwordHash")
        VALUES ('admin', ${adminPasswordHash})
        ON CONFLICT ("username") DO NOTHING
      `;
    } catch (adminError) {
      console.error('Admin user creation error:', adminError);
    }

    // Insert default site settings
    try {
      const settings = [
        { key: 'phone', value: siteConfig.contact.phoneAlt },
        { key: 'address', value: siteConfig.contact.address.full },
        { key: 'whatsapp', value: siteConfig.contact.mobile },
        { key: 'instagram', value: siteConfig.social.instagram },
        { key: 'telegram', value: siteConfig.social.telegram },
        { key: 'email', value: siteConfig.contact.email },
        { key: 'website', value: siteConfig.url },
        { key: 'workHours', value: siteConfig.workHours },
      ];

      for (const setting of settings) {
        await sql`
          INSERT INTO "SiteSetting" ("key", "value")
          VALUES (${setting.key}, ${setting.value})
          ON CONFLICT ("key") DO NOTHING
        `;
      }
    } catch (settingsError) {
      console.error('Settings insertion error:', settingsError);
    }

    return NextResponse.json({
      success: true,
      message: 'دیتابیس با موفقیت راه‌اندازی شد! جداول و داده‌های اولیه ایجاد شدند.',
      adminUser: 'admin',
      adminPassword: siteConfig.defaultAdminPassword,
    });
  } catch (error) {
    console.error('Setup error:', error);
    return NextResponse.json(
      { error: 'خطا در تنظیم دیتابیس' },
      { status: 500 }
    );
  }
}
