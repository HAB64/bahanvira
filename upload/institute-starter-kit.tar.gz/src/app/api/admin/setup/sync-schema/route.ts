import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * POST /api/admin/setup/sync-schema
 * Syncs the database schema with the current Prisma schema.
 * Now uses Prisma ORM instead of raw SQL — AdminRole and AdminPermission
 * are proper models in schema.prisma.
 * No auth required — this is a setup endpoint.
 */
export async function POST() {
  try {
    const results: string[] = [];

    // ─── Ensure default admin user exists with correct password ───
    try {
      const { createHash } = await import('crypto');
      const { siteConfig } = await import('@/config/site');
      const adminPasswordHash = createHash('sha256').update(siteConfig.defaultAdminPassword).digest('hex');

      const existing = await db.adminUser.findUnique({ where: { username: 'admin' } });
      if (existing) {
        await db.adminUser.update({
          where: { username: 'admin' },
          data: { passwordHash: adminPasswordHash, updatedAt: new Date() },
        });
        results.push('Admin user updated');
      } else {
        await db.adminUser.create({
          data: {
            username: 'admin',
            passwordHash: adminPasswordHash,
            displayName: 'مدیر سیستم',
            isActive: true,
          },
        });
        results.push('Admin user created');
      }
    } catch (err: any) {
      results.push(`Admin user: ${err.message?.slice(0, 100)}`);
    }

    // ─── Seed default roles using Prisma ORM ───
    const RESOURCES = [
      'leads', 'courses', 'payments', 'reports', 'settings', 'exams',
      'users', 'roles', 'blog', 'karamuz', 'invoices', 'tickets',
      'campaigns', 'automation', 'analytics', 'knowledge_base',
      'service_contracts', 'referrers', 'api_keys', 'employment', 'skill_programs',
    ];
    const ACTIONS = ['view', 'create', 'edit', 'delete', 'manage', 'export'];

    const defaultRoles = [
      {
        name: 'SUPER_ADMIN',
        label: 'مدیر ارشد',
        description: 'دسترسی کامل به تمام بخش‌های سیستم',
        isSystem: true,
        perms: RESOURCES.flatMap((r) => ACTIONS.map((a) => ({ resource: r, action: a }))),
      },
      {
        name: 'ADMIN',
        label: 'مدیر',
        description: 'دسترسی مدیریتی به اکثر بخش‌ها',
        isSystem: true,
        perms: RESOURCES.filter((r) => r !== 'roles' && r !== 'settings').flatMap((r) =>
          ACTIONS.filter((a) => a !== 'delete').map((a) => ({ resource: r, action: a }))
        ),
      },
      {
        name: 'SALES',
        label: 'فروش',
        description: 'دسترسی به سرنخ‌ها و پرداخت‌ها',
        isSystem: true,
        perms: ['leads', 'payments', 'invoices', 'referrers', 'campaigns', 'analytics'].flatMap((r) =>
          ['view', 'create', 'edit'].map((a) => ({ resource: r, action: a }))
        ),
      },
      {
        name: 'INSTRUCTOR',
        label: 'استاد',
        description: 'دسترسی به دوره‌ها و آزمون‌ها',
        isSystem: true,
        perms: ['courses', 'exams', 'karamuz', 'skill_programs'].flatMap((r) =>
          ['view', 'create', 'edit'].map((a) => ({ resource: r, action: a }))
        ),
      },
      {
        name: 'STAFF',
        label: 'کارمند',
        description: 'دسترسی محدود اداری',
        isSystem: true,
        perms: [
          ...['leads', 'tickets'].flatMap((r) =>
            ['view', 'create', 'edit'].map((a) => ({ resource: r, action: a }))
          ),
          { resource: 'reports', action: 'view' },
          { resource: 'analytics', action: 'view' },
        ],
      },
    ];

    for (const dr of defaultRoles) {
      try {
        const exists = await db.adminRole.findUnique({ where: { name: dr.name } });
        if (!exists) {
          await db.adminRole.create({
            data: {
              name: dr.name,
              label: dr.label,
              description: dr.description,
              isSystem: dr.isSystem,
              permissions: { create: dr.perms },
            },
          });
          results.push(`Role created: ${dr.label}`);
        } else {
          results.push(`Role exists: ${dr.label}`);
        }
      } catch (err: any) {
        results.push(`Role ${dr.name}: ${err.message?.slice(0, 100)}`);
      }
    }

    // ─── Assign SUPER_ADMIN role to admin user if not already ───
    try {
      const superAdmin = await db.adminRole.findUnique({ where: { name: 'SUPER_ADMIN' } });
      const adminUser = await db.adminUser.findUnique({ where: { username: 'admin' } });
      if (superAdmin && adminUser && !adminUser.roleId) {
        await db.adminUser.update({
          where: { username: 'admin' },
          data: { roleId: superAdmin.id },
        });
        results.push('SUPER_ADMIN assigned to admin user');
      } else if (adminUser?.roleId) {
        results.push('Admin user already has a role');
      }
    } catch (err: any) {
      results.push(`Role assignment: ${err.message?.slice(0, 100)}`);
    }

    return NextResponse.json({
      success: true,
      message: 'اسکیما دیتابیس با موفقیت هماهنگ شد!',
      results,
    });
  } catch (error: any) {
    console.error('Schema sync error:', error);
    return NextResponse.json(
      { error: 'خطا در هماهنگ‌سازی اسکیما', detail: error.message?.slice(0, 300) },
      { status: 500 }
    );
  }
}
