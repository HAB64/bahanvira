import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAdminSession } from '@/lib/admin-auth'

interface ReorderItem {
  id: string
  order: number
}

/**
 * PUT /api/admin/lms/reorder
 * Reorder lessons — accepts { lessons: [{ id, order }] } array
 */
export async function PUT(request: Request) {
  const auth = await getAdminSession(request)
  if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const body = await request.json()
    const { lessons } = body as { lessons: ReorderItem[] }

    // Validate input
    if (!Array.isArray(lessons) || lessons.length === 0) {
      return NextResponse.json(
        { error: 'lessons must be a non-empty array of { id, order } objects' },
        { status: 400 }
      )
    }

    // Validate each item has id and order
    for (const item of lessons) {
      if (!item.id || typeof item.order !== 'number') {
        return NextResponse.json(
          { error: 'Each lesson item must have an id (string) and order (number)' },
          { status: 400 }
        )
      }
    }

    // Verify all lesson IDs exist
    const lessonIds = lessons.map((l) => l.id)
    const existingLessons = await db.lesson.findMany({
      where: { id: { in: lessonIds } },
      select: { id: true },
    })

    const existingIds = new Set(existingLessons.map((l) => l.id))
    const missingIds = lessonIds.filter((id) => !existingIds.has(id))
    if (missingIds.length > 0) {
      return NextResponse.json(
        { error: `Lessons not found: ${missingIds.join(', ')}` },
        { status: 404 }
      )
    }

    // Perform batch update using a transaction
    await db.$transaction(
      lessons.map((item) =>
        db.lesson.update({
          where: { id: item.id },
          data: { order: item.order },
        })
      )
    )

    // Fetch updated lessons to return
    const updatedLessons = await db.lesson.findMany({
      where: { id: { in: lessonIds } },
      orderBy: { order: 'asc' },
      select: {
        id: true,
        title: true,
        order: true,
        skillProgramId: true,
      },
    })

    return NextResponse.json({ data: updatedLessons })
  } catch (error) {
    console.error('Error reordering lessons:', error)
    return NextResponse.json({ error: 'Failed to reorder lessons' }, { status: 500 })
  }
}
