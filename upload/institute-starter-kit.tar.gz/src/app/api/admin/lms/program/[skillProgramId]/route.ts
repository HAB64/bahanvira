import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAdminSession } from '@/lib/admin-auth'

/**
 * GET /api/admin/lms/program/[skillProgramId]
 * List all lessons for a specific SkillProgram (ordered by `order` field)
 * Also includes lesson progress stats (enrollment count, average completion %)
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ skillProgramId: string }> }
) {
  const auth = await getAdminSession(request)
  if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { skillProgramId } = await params

    // Verify the SkillProgram exists
    const program = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
      select: {
        id: true,
        name: true,
        code: true,
        description: true,
        totalHours: true,
        isActive: true,
      },
    })

    if (!program) {
      return NextResponse.json({ error: 'SkillProgram not found' }, { status: 404 })
    }

    // Fetch lessons ordered by `order` field
    const lessons = await db.lesson.findMany({
      where: { skillProgramId },
      orderBy: { order: 'asc' },
      include: {
        progress: {
          select: {
            status: true,
            progressPercent: true,
          },
        },
      },
    })

    // Compute per-lesson progress stats
    const lessonsWithStats = lessons.map((lesson) => {
      const totalEnrollments = lesson.progress.length
      const completedCount = lesson.progress.filter((p) => p.status === 'COMPLETED').length
      const inProgressCount = lesson.progress.filter((p) => p.status === 'IN_PROGRESS').length
      const avgCompletion =
        totalEnrollments > 0
          ? Math.round(
              lesson.progress.reduce((sum, p) => sum + p.progressPercent, 0) / totalEnrollments
            )
          : 0

      const { progress: _progress, ...lessonData } = lesson

      return {
        ...lessonData,
        stats: {
          totalEnrollments,
          completedCount,
          inProgressCount,
          averageCompletionPercent: avgCompletion,
        },
      }
    })

    // Compute program-level progress stats
    const totalEnrollments = await db.enrollment.count({
      where: { skillProgramId },
    })

    // Get all lesson progress records for this program's enrollments
    const allProgress = await db.lessonProgress.findMany({
      where: {
        enrollment: { skillProgramId },
      },
      select: {
        status: true,
        progressPercent: true,
      },
    })

    const programAvgCompletion =
      allProgress.length > 0
        ? Math.round(
            allProgress.reduce((sum, p) => sum + p.progressPercent, 0) / allProgress.length
          )
        : 0

    const totalCompletedEnrollments = await db.enrollment.count({
      where: { skillProgramId, status: 'COMPLETED' },
    })

    return NextResponse.json({
      data: {
        program,
        lessons: lessonsWithStats,
        programStats: {
          totalEnrollments,
          completedEnrollments: totalCompletedEnrollments,
          averageCompletionPercent: programAvgCompletion,
          totalLessons: lessons.length,
          publishedLessons: lessons.filter((l) => l.isPublished).length,
          totalDurationMinutes: lessons.reduce((sum, l) => sum + l.estimatedMinutes, 0),
        },
      },
    })
  } catch (error) {
    console.error('Error fetching program lessons:', error)
    return NextResponse.json({ error: 'Failed to fetch program lessons' }, { status: 500 })
  }
}
