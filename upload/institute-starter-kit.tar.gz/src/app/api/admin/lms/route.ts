import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAdminSession } from '@/lib/admin-auth'

const VALID_LESSON_TYPES = ['VIDEO', 'TEXT', 'QUIZ', 'DOCUMENT', 'LIVE_SESSION'] as const
type LessonType = (typeof VALID_LESSON_TYPES)[number]

/**
 * GET /api/admin/lms
 * List all SkillPrograms with their lesson count and total duration
 */
export async function GET(request: Request) {
  const auth = await getAdminSession(request)
  if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const programs = await db.skillProgram.findMany({
      where: { isActive: true },
      include: {
        lessons: {
          select: {
            id: true,
            estimatedMinutes: true,
            isPublished: true,
          },
        },
        _count: {
          select: { enrollments: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    const data = programs.map((program) => {
      const lessonCount = program.lessons.length
      const publishedCount = program.lessons.filter((l) => l.isPublished).length
      const totalDuration = program.lessons.reduce((sum, l) => sum + l.estimatedMinutes, 0)

      return {
        id: program.id,
        code: program.code,
        name: program.name,
        description: program.description,
        totalHours: program.totalHours,
        cluster: program.cluster,
        level: program.level,
        instructorName: program.instructorName,
        isActive: program.isActive,
        lessonCount,
        publishedLessonCount: publishedCount,
        totalDurationMinutes: totalDuration,
        enrollmentCount: program._count.enrollments,
        createdAt: program.createdAt,
        updatedAt: program.updatedAt,
      }
    })

    return NextResponse.json({ data })
  } catch (error) {
    console.error('Error listing LMS programs:', error)
    return NextResponse.json({ error: 'Failed to fetch programs' }, { status: 500 })
  }
}

/**
 * POST /api/admin/lms
 * Create a new lesson in a SkillProgram
 */
export async function POST(request: Request) {
  const auth = await getAdminSession(request)
  if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const body = await request.json()
    const {
      skillProgramId,
      title,
      description,
      type,
      content,
      videoUrl,
      videoDuration,
      documentUrl,
      order,
      isPublished,
      isFree,
      estimatedMinutes,
    } = body as {
      skillProgramId: string
      title: string
      description?: string
      type?: string
      content?: string
      videoUrl?: string
      videoDuration?: number
      documentUrl?: string
      order?: number
      isPublished?: boolean
      isFree?: boolean
      estimatedMinutes?: number
    }

    // Validate required fields
    if (!skillProgramId || !title) {
      return NextResponse.json(
        { error: 'skillProgramId and title are required' },
        { status: 400 }
      )
    }

    // Validate skillProgramId exists
    const program = await db.skillProgram.findUnique({ where: { id: skillProgramId } })
    if (!program) {
      return NextResponse.json({ error: 'SkillProgram not found' }, { status: 404 })
    }

    // Validate lesson type
    const lessonType: LessonType = (type as LessonType) || 'VIDEO'
    if (!VALID_LESSON_TYPES.includes(lessonType)) {
      return NextResponse.json(
        { error: `Invalid lesson type. Must be one of: ${VALID_LESSON_TYPES.join(', ')}` },
        { status: 400 }
      )
    }

    // If order not specified, place it at the end
    let lessonOrder = order
    if (lessonOrder === undefined || lessonOrder === null) {
      const maxOrderLesson = await db.lesson.findFirst({
        where: { skillProgramId },
        orderBy: { order: 'desc' },
        select: { order: true },
      })
      lessonOrder = (maxOrderLesson?.order ?? -1) + 1
    }

    const lesson = await db.lesson.create({
      data: {
        skillProgramId,
        title,
        description: description || null,
        type: lessonType,
        content: content || null,
        videoUrl: videoUrl || null,
        videoDuration: videoDuration || null,
        documentUrl: documentUrl || null,
        order: lessonOrder,
        isPublished: isPublished ?? false,
        isFree: isFree ?? false,
        estimatedMinutes: estimatedMinutes ?? 0,
      },
      include: {
        skillProgram: {
          select: { id: true, name: true },
        },
      },
    })

    return NextResponse.json({ data: lesson }, { status: 201 })
  } catch (error) {
    console.error('Error creating lesson:', error)
    return NextResponse.json({ error: 'Failed to create lesson' }, { status: 500 })
  }
}
