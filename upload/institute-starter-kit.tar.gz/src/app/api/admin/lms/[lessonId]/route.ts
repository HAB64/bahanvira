import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAdminSession } from '@/lib/admin-auth'

const VALID_LESSON_TYPES = ['VIDEO', 'TEXT', 'QUIZ', 'DOCUMENT', 'LIVE_SESSION'] as const
type LessonType = (typeof VALID_LESSON_TYPES)[number]

/**
 * GET /api/admin/lms/[lessonId]
 * Get lesson details by ID
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ lessonId: string }> }
) {
  const auth = await getAdminSession(request)
  if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { lessonId } = await params

    const lesson = await db.lesson.findUnique({
      where: { id: lessonId },
      include: {
        skillProgram: {
          select: { id: true, name: true, code: true },
        },
        progress: {
          select: {
            id: true,
            status: true,
            progressPercent: true,
          },
        },
      },
    })

    if (!lesson) {
      return NextResponse.json({ error: 'Lesson not found' }, { status: 404 })
    }

    // Compute progress stats
    const totalProgress = lesson.progress.length
    const completedCount = lesson.progress.filter((p) => p.status === 'COMPLETED').length
    const inProgressCount = lesson.progress.filter((p) => p.status === 'IN_PROGRESS').length
    const avgCompletion =
      totalProgress > 0
        ? Math.round(
            lesson.progress.reduce((sum, p) => sum + p.progressPercent, 0) / totalProgress
          )
        : 0

    const { progress, ...lessonData } = lesson

    return NextResponse.json({
      data: {
        ...lessonData,
        stats: {
          totalEnrollments: totalProgress,
          completedCount,
          inProgressCount,
          averageCompletionPercent: avgCompletion,
        },
      },
    })
  } catch (error) {
    console.error('Error fetching lesson:', error)
    return NextResponse.json({ error: 'Failed to fetch lesson' }, { status: 500 })
  }
}

/**
 * PUT /api/admin/lms/[lessonId]
 * Update lesson fields
 */
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ lessonId: string }> }
) {
  const auth = await getAdminSession(request)
  if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { lessonId } = await params
    const body = await request.json()

    const {
      title,
      description,
      type,
      content,
      videoUrl,
      videoDuration,
      documentUrl,
      order,
      isPublished,
      isFree,
      estimatedMinutes,
    } = body as {
      title?: string
      description?: string | null
      type?: string
      content?: string | null
      videoUrl?: string | null
      videoDuration?: number | null
      documentUrl?: string | null
      order?: number
      isPublished?: boolean
      isFree?: boolean
      estimatedMinutes?: number
    }

    // Validate lesson type if provided
    if (type !== undefined) {
      const lessonType = type as LessonType
      if (!VALID_LESSON_TYPES.includes(lessonType)) {
        return NextResponse.json(
          { error: `Invalid lesson type. Must be one of: ${VALID_LESSON_TYPES.join(', ')}` },
          { status: 400 }
        )
      }
    }

    // Verify lesson exists
    const existing = await db.lesson.findUnique({ where: { id: lessonId } })
    if (!existing) {
      return NextResponse.json({ error: 'Lesson not found' }, { status: 404 })
    }

    // Build update data — only include fields that were provided
    const updateData: Record<string, unknown> = {}
    if (title !== undefined) updateData.title = title
    if (description !== undefined) updateData.description = description
    if (type !== undefined) updateData.type = type
    if (content !== undefined) updateData.content = content
    if (videoUrl !== undefined) updateData.videoUrl = videoUrl
    if (videoDuration !== undefined) updateData.videoDuration = videoDuration
    if (documentUrl !== undefined) updateData.documentUrl = documentUrl
    if (order !== undefined) updateData.order = order
    if (isPublished !== undefined) updateData.isPublished = isPublished
    if (isFree !== undefined) updateData.isFree = isFree
    if (estimatedMinutes !== undefined) updateData.estimatedMinutes = estimatedMinutes

    const lesson = await db.lesson.update({
      where: { id: lessonId },
      data: updateData,
      include: {
        skillProgram: {
          select: { id: true, name: true },
        },
      },
    })

    return NextResponse.json({ data: lesson })
  } catch (error) {
    console.error('Error updating lesson:', error)
    return NextResponse.json({ error: 'Failed to update lesson' }, { status: 500 })
  }
}

/**
 * DELETE /api/admin/lms/[lessonId]
 * Delete a lesson
 */
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ lessonId: string }> }
) {
  const auth = await getAdminSession(request)
  if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { lessonId } = await params

    // Verify lesson exists
    const existing = await db.lesson.findUnique({ where: { id: lessonId } })
    if (!existing) {
      return NextResponse.json({ error: 'Lesson not found' }, { status: 404 })
    }

    await db.lesson.delete({ where: { id: lessonId } })

    return NextResponse.json({ data: { success: true, id: lessonId } })
  } catch (error) {
    console.error('Error deleting lesson:', error)
    return NextResponse.json({ error: 'Failed to delete lesson' }, { status: 500 })
  }
}
