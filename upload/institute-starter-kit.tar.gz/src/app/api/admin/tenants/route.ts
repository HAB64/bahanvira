import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PLAN_LIMITS } from '@/lib/tenant';

// GET /api/admin/tenants — List all tenants
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const status = url.searchParams.get('status');
    const plan = url.searchParams.get('plan');
    const search = url.searchParams.get('search');

    const where: Record<string, unknown> = {};

    if (status) where.status = status;
    if (plan) where.plan = plan;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { slug: { contains: search } },
        { domain: { contains: search } },
      ];
    }

    const tenants = await db.tenant.findMany({
      where,
      include: {
        _count: { select: { children: true, billingRecords: true, usageLogs: true } },
        whiteLabel: { select: { brandName: true, isActive: true } },
        parent: { select: { id: true, name: true, slug: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Stats
    const totalTenants = await db.tenant.count();
    const activeTenants = await db.tenant.count({ where: { status: 'ACTIVE' } });
    const trialTenants = await db.tenant.count({ where: { status: 'TRIAL' } });
    const expiredTenants = await db.tenant.count({ where: { status: 'EXPIRED' } });

    return NextResponse.json({
      tenants,
      stats: { total: totalTenants, active: activeTenants, trial: trialTenants, expired: expiredTenants },
    });
  } catch (error: unknown) {
    console.error('Tenants list error:', error);
    return NextResponse.json({ error: 'خطا در دریافت لیست Tenantها' }, { status: 500 });
  }
}

// POST /api/admin/tenants — Create a new tenant
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      name, slug, domain, plan, parentId,
      primaryColor, secondaryColor, locale, currency, timezone,
    } = body;

    if (!name || !slug) {
      return NextResponse.json({ error: 'نام و شناسه الزامی است' }, { status: 400 });
    }

    // Check slug uniqueness
    const existing = await db.tenant.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json({ error: 'این شناسه قبلاً ثبت شده' }, { status: 409 });
    }

    const planLimits = PLAN_LIMITS[plan as keyof typeof PLAN_LIMITS] || PLAN_LIMITS.BASIC;

    const tenant = await db.tenant.create({
      data: {
        name,
        slug,
        domain: domain || null,
        plan: plan || 'BASIC',
        status: 'TRIAL',
        primaryColor: primaryColor || '#0d9488',
        secondaryColor: secondaryColor || null,
        locale: locale || 'fa',
        currency: currency || 'IRR',
        timezone: timezone || 'Asia/Tehran',
        parentId: parentId || null,
        maxUsers: planLimits.maxUsers === -1 ? 999999 : planLimits.maxUsers,
        maxStorage: planLimits.maxStorage === -1 ? 999999 : planLimits.maxStorage,
        maxApiCalls: planLimits.maxApiCalls === -1 ? 999999 : planLimits.maxApiCalls,
      },
    });

    return NextResponse.json({ tenant });
  } catch (error: unknown) {
    console.error('Tenant create error:', error);
    return NextResponse.json({ error: 'خطا در ایجاد Tenant' }, { status: 500 });
  }
}
