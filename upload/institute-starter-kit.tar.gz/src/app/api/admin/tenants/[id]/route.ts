import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/tenants/[id] — Get tenant details
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const tenant = await db.tenant.findUnique({
      where: { id },
      include: {
        parent: { select: { id: true, name: true, slug: true } },
        children: { select: { id: true, name: true, slug: true, status: true } },
        whiteLabel: true,
        _count: {
          select: {
            franchises: true,
            parentFranchises: true,
            apiApps: true,
            billingRecords: true,
            usageLogs: true,
          },
        },
      },
    });

    if (!tenant) {
      return NextResponse.json({ error: 'Tenant یافت نشد' }, { status: 404 });
    }

    // Get current month usage
    const now = new Date();
    const period = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const usageLogs = await db.tenantUsageLog.findMany({
      where: { tenantId: id, period },
    });

    return NextResponse.json({ tenant, currentUsage: usageLogs });
  } catch (error: unknown) {
    console.error('Tenant get error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات Tenant' }, { status: 500 });
  }
}

// PUT /api/admin/tenants/[id] — Update tenant
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const tenant = await db.tenant.findUnique({ where: { id } });
    if (!tenant) {
      return NextResponse.json({ error: 'Tenant یافت نشد' }, { status: 404 });
    }

    const updated = await db.tenant.update({
      where: { id },
      data: {
        ...(body.name && { name: body.name }),
        ...(body.domain !== undefined && { domain: body.domain || null }),
        ...(body.primaryColor && { primaryColor: body.primaryColor }),
        ...(body.secondaryColor !== undefined && { secondaryColor: body.secondaryColor || null }),
        ...(body.plan && { plan: body.plan }),
        ...(body.status && { status: body.status }),
        ...(body.locale && { locale: body.locale }),
        ...(body.currency && { currency: body.currency }),
        ...(body.timezone && { timezone: body.timezone }),
        ...(body.maxUsers !== undefined && { maxUsers: body.maxUsers }),
        ...(body.maxStorage !== undefined && { maxStorage: body.maxStorage }),
        ...(body.maxApiCalls !== undefined && { maxApiCalls: body.maxApiCalls }),
        ...(body.parentId !== undefined && { parentId: body.parentId || null }),
        ...(body.config !== undefined && { config: body.config }),
      },
    });

    return NextResponse.json({ tenant: updated });
  } catch (error: unknown) {
    console.error('Tenant update error:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی Tenant' }, { status: 500 });
  }
}

// DELETE /api/admin/tenants/[id] — Suspend tenant (soft delete)
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const tenant = await db.tenant.findUnique({ where: { id } });
    if (!tenant) {
      return NextResponse.json({ error: 'Tenant یافت نشد' }, { status: 404 });
    }

    // Soft delete: suspend instead of actual deletion
    const updated = await db.tenant.update({
      where: { id },
      data: { status: 'SUSPENDED' },
    });

    return NextResponse.json({ tenant: updated });
  } catch (error: unknown) {
    console.error('Tenant delete error:', error);
    return NextResponse.json({ error: 'خطا در حذف Tenant' }, { status: 500 });
  }
}
