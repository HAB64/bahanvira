import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/marketplace — List marketplace apps
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const status = url.searchParams.get('status');
    const category = url.searchParams.get('category');

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (category) where.category = category;

    const apps = await db.marketplaceApp.findMany({
      where,
      include: {
        tenant: { select: { id: true, name: true, slug: true } },
        _count: { select: { subscriptions: true, reviews: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Stats
    const totalApps = await db.marketplaceApp.count();
    const approvedApps = await db.marketplaceApp.count({ where: { status: 'APPROVED' } });
    const pendingApps = await db.marketplaceApp.count({ where: { status: 'PENDING_REVIEW' } });
    const totalDownloads = await db.marketplaceApp.aggregate({ _sum: { downloads: true } });
    const totalSubs = await db.appSubscription.count({ where: { status: 'ACTIVE' } });

    // Category breakdown
    const categories = await db.marketplaceApp.groupBy({
      by: ['category'],
      _count: true,
    });

    return NextResponse.json({
      apps,
      stats: {
        total: totalApps,
        approved: approvedApps,
        pending: pendingApps,
        totalDownloads: totalDownloads._sum.downloads || 0,
        totalSubscriptions: totalSubs,
        categories,
      },
    });
  } catch (error: unknown) {
    console.error('Marketplace list error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اپلیکیشن‌ها' }, { status: 500 });
  }
}

// POST /api/admin/marketplace — Create a marketplace app
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      tenantId, name, slug, description, shortDesc,
      category, iconUrl, version, apiEndpoints, requiredScopes,
      pricingModel, price, monthlyPrice,
      developerName, developerEmail, supportUrl, documentationUrl,
    } = body;

    if (!tenantId || !name || !slug || !description || !category) {
      return NextResponse.json({ error: 'فیلدهای الزامی ناقص است' }, { status: 400 });
    }

    // Check slug uniqueness
    const existing = await db.marketplaceApp.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json({ error: 'این شناسه قبلاً ثبت شده' }, { status: 409 });
    }

    const app = await db.marketplaceApp.create({
      data: {
        tenantId,
        name,
        slug,
        description,
        shortDesc: shortDesc || null,
        category,
        iconUrl: iconUrl || null,
        version: version || '1.0.0',
        apiEndpoints: apiEndpoints || null,
        requiredScopes: requiredScopes || null,
        pricingModel: pricingModel || 'FREE',
        price: price || 0,
        monthlyPrice: monthlyPrice || null,
        status: 'DRAFT',
        developerName: developerName || null,
        developerEmail: developerEmail || null,
        supportUrl: supportUrl || null,
        documentationUrl: documentationUrl || null,
      },
    });

    return NextResponse.json({ app });
  } catch (error: unknown) {
    console.error('Marketplace create error:', error);
    return NextResponse.json({ error: 'خطا در ایجاد اپلیکیشن' }, { status: 500 });
  }
}
