import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/marketplace/[appId] — Get app details
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ appId: string }> }
) {
  try {
    const { appId } = await params;
    const app = await db.marketplaceApp.findUnique({
      where: { id: appId },
      include: {
        tenant: { select: { id: true, name: true, slug: true } },
        subscriptions: {
          include: {
            app: { select: { name: true } },
          },
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
        reviews: { orderBy: { createdAt: 'desc' }, take: 20 },
      },
    });

    if (!app) {
      return NextResponse.json({ error: 'اپلیکیشن یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ app });
  } catch (error: unknown) {
    console.error('Marketplace app get error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اپلیکیشن' }, { status: 500 });
  }
}

// PUT /api/admin/marketplace/[appId] — Update app (review, approve, etc.)
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ appId: string }> }
) {
  try {
    const { appId } = await params;
    const body = await req.json();

    const app = await db.marketplaceApp.findUnique({ where: { id: appId } });
    if (!app) {
      return NextResponse.json({ error: 'اپلیکیشن یافت نشد' }, { status: 404 });
    }

    const updated = await db.marketplaceApp.update({
      where: { id: appId },
      data: {
        ...(body.name && { name: body.name }),
        ...(body.description && { description: body.description }),
        ...(body.shortDesc !== undefined && { shortDesc: body.shortDesc }),
        ...(body.status && { status: body.status }),
        ...(body.reviewNotes !== undefined && { reviewNotes: body.reviewNotes }),
        ...(body.pricingModel && { pricingModel: body.pricingModel }),
        ...(body.price !== undefined && { price: body.price }),
        ...(body.monthlyPrice !== undefined && { monthlyPrice: body.monthlyPrice }),
        ...(body.version && { version: body.version }),
        ...(body.apiEndpoints !== undefined && { apiEndpoints: body.apiEndpoints }),
        ...(body.requiredScopes !== undefined && { requiredScopes: body.requiredScopes }),
        ...(body.iconUrl !== undefined && { iconUrl: body.iconUrl }),
        ...(body.supportUrl !== undefined && { supportUrl: body.supportUrl }),
        ...(body.documentationUrl !== undefined && { documentationUrl: body.documentationUrl }),
      },
    });

    return NextResponse.json({ app: updated });
  } catch (error: unknown) {
    console.error('Marketplace app update error:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی اپلیکیشن' }, { status: 500 });
  }
}
