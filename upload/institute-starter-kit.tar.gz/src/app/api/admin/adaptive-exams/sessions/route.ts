import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { db } from '@/lib/db';

// GET /api/admin/adaptive-exams/sessions — List adaptive exam sessions
export async function GET(request: NextRequest) {
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status'); // 'active' or 'completed'
    const examId = searchParams.get('examId');
    const limit = parseInt(searchParams.get('limit') ?? '50');

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const where: any = {};
    if (status === 'active') where.isCompleted = false;
    if (status === 'completed') where.isCompleted = true;
    if (examId) where.examId = examId;

    const sessions = await db.adaptiveExamSession.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    // Fetch related exam and karAmuz data separately (no Prisma relations defined)
    const examIds = [...new Set(sessions.map(s => s.examId))];
    const karAmuzIds = [...new Set(sessions.map(s => s.karAmuzId))];

    const [exams, karAmuzs] = await Promise.all([
      db.exam.findMany({
        where: { id: { in: examIds } },
        select: { id: true, title: true },
      }),
      db.karAmuz.findMany({
        where: { id: { in: karAmuzIds } },
        select: { id: true, firstName: true, lastName: true },
      }),
    ]);

    const examMap = new Map(exams.map(e => [e.id, e]));
    const karAmuzMap = new Map(karAmuzs.map(k => [k.id, k]));

    return NextResponse.json({
      sessions: sessions.map(s => ({
        id: s.id,
        examId: s.examId,
        karAmuzId: s.karAmuzId,
        currentDifficulty: s.currentDifficulty,
        abilityEstimate: s.abilityEstimate,
        currentQuestionIndex: s.currentQuestionIndex,
        isCompleted: s.isCompleted,
        finalScore: s.finalScore,
        finalLevel: s.finalLevel,
        responses: s.responses,
        exam: examMap.get(s.examId) ?? null,
        karAmuz: karAmuzMap.get(s.karAmuzId) ?? null,
        createdAt: s.createdAt.toISOString(),
        completedAt: s.completedAt?.toISOString() ?? null,
      })),
      total: sessions.length,
    });
  } catch (error) {
    console.error('Error fetching adaptive exam sessions:', error);
    return NextResponse.json({ error: 'Failed to fetch sessions' }, { status: 500 });
  }
}
