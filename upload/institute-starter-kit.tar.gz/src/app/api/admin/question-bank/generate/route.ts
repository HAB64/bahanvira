import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

// POST /api/admin/question-bank/generate - Generate exam from question bank
export async function POST(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const body = await request.json();
    const {
      title,
      description,
      skillProgramId,
      categoryId,
      tags = [],
      type = 'QUIZ',
      durationMinutes = 30,
      passingScore = 60,
      maxAttempts = 1,
      shuffleQuestions = true,
      showResults = 'AFTER_SUBMIT',
      // Question selection params
      totalQuestions = 20,
      easyCount = 5,
      mediumCount = 10,
      hardCount = 4,
      expertCount = 1,
      // Types distribution
      includeTypes = [], // empty = all types
      // Exclude questions
      excludeIds = [],
    } = body;

    if (!title?.trim()) {
      return NextResponse.json(
        { error: 'عنوان آزمون الزامی است' },
        { status: 400 }
      );
    }

    const totalCount = easyCount + mediumCount + hardCount + expertCount;
    const finalTotal = Math.max(totalQuestions, totalCount);

    // Build the where clause for question selection
    const where: Record<string, unknown> = {
      isActive: true,
      id: excludeIds?.length ? { notIn: excludeIds } : undefined,
    };

    if (categoryId) where.categoryId = categoryId;
    if (tags?.length) where.tags = { hasSome: tags };
    if (includeTypes?.length) where.type = { in: includeTypes };

    // Remove undefined values
    Object.keys(where).forEach((key) => {
      if (where[key] === undefined) delete where[key];
    });

    // Fetch questions by difficulty
    const [easyQs, mediumQs, hardQs, expertQs] = await Promise.all([
      easyCount > 0
        ? db.questionBank.findMany({
            where: { ...where, difficulty: 'EASY' },
            select: { id: true },
          })
        : Promise.resolve([]),
      mediumCount > 0
        ? db.questionBank.findMany({
            where: { ...where, difficulty: 'MEDIUM' },
            select: { id: true },
          })
        : Promise.resolve([]),
      hardCount > 0
        ? db.questionBank.findMany({
            where: { ...where, difficulty: 'HARD' },
            select: { id: true },
          })
        : Promise.resolve([]),
      expertCount > 0
        ? db.questionBank.findMany({
            where: { ...where, difficulty: 'EXPERT' },
            select: { id: true },
          })
        : Promise.resolve([]),
    ]);

    // Shuffle and select
    const shuffle = (arr: { id: string }[]) =>
      arr.sort(() => Math.random() - 0.5);

    const selectedEasy = shuffle(easyQs).slice(0, easyCount);
    const selectedMedium = shuffle(mediumQs).slice(0, mediumCount);
    const selectedHard = shuffle(hardQs).slice(0, hardCount);
    const selectedExpert = shuffle(expertQs).slice(0, expertCount);

    let selectedIds = [
      ...selectedEasy.map((q) => q.id),
      ...selectedMedium.map((q) => q.id),
      ...selectedHard.map((q) => q.id),
      ...selectedExpert.map((q) => q.id),
    ];

    // If we need more questions (fill remaining from medium)
    if (selectedIds.length < finalTotal) {
      const remaining = finalTotal - selectedIds.length;
      const usedIds = new Set(selectedIds);
      const allQs = await db.questionBank.findMany({
        where: { ...where, id: { notIn: [...usedIds, ...(excludeIds || [])] } },
        select: { id: true },
      });
      const extra = shuffle(allQs).slice(0, remaining);
      selectedIds = [...selectedIds, ...extra.map((q) => q.id)];
    }

    if (selectedIds.length === 0) {
      return NextResponse.json(
        { error: 'سوال مناسبی در بانک سوال یافت نشد. لطفاً فیلترها را بررسی کنید.' },
        { status: 400 }
      );
    }

    // Fetch full question data
    const fullQuestions = await db.questionBank.findMany({
      where: { id: { in: selectedIds } },
    });

    // Create the exam
    const exam = await db.exam.create({
      data: {
        title: title.trim(),
        description: description?.trim() || null,
        skillProgramId: skillProgramId || null,
        type,
        durationMinutes: parseInt(durationMinutes) || 30,
        passingScore: parseFloat(passingScore) || 60,
        maxAttempts: parseInt(maxAttempts) || 1,
        shuffleQuestions: Boolean(shuffleQuestions),
        showResults,
        isActive: true,
      },
    });

    // Create exam questions from bank questions
    let order = 0;
    const examQuestionsData = fullQuestions.map((q) => ({
      examId: exam.id,
      text: q.text,
      type: q.type,
      options: q.options,
      correctAnswer: q.correctAnswer,
      points: q.points,
      difficulty: q.difficulty,
      explanation: q.explanation,
      order: order++,
      image: q.imageUrl,
    }));

    await db.examQuestion.createMany({ data: examQuestionsData });

    // Update usage count for selected questions
    await db.questionBank.updateMany({
      where: { id: { in: selectedIds } },
      data: { usageCount: { increment: 1 } },
    });

    // Store generation record
    await db.generatedExam.create({
      data: {
        title: exam.title,
        description: exam.description,
        categoryId: categoryId || null,
        skillProgramId: skillProgramId || null,
        totalQuestions: selectedIds.length,
        easyCount: selectedEasy.length,
        mediumCount: selectedMedium.length,
        hardCount: selectedHard.length,
        expertCount: selectedExpert.length,
        durationMinutes: parseInt(durationMinutes) || 30,
        passingScore: parseFloat(passingScore) || 60,
        shuffleEnabled: Boolean(shuffleQuestions),
        examId: exam.id,
        selectedQuestions: selectedIds,
        generatedBy: session.username || null,
      },
    });

    // Calculate total points
    const totalPoints = fullQuestions.reduce((sum, q) => sum + q.points, 0);

    return NextResponse.json({
      exam: {
        id: exam.id,
        title: exam.title,
        type: exam.type,
        durationMinutes: exam.durationMinutes,
        passingScore: exam.passingScore,
        totalQuestions: selectedIds.length,
        totalPoints,
        difficultyBreakdown: {
          easy: selectedEasy.length,
          medium: selectedMedium.length,
          hard: selectedHard.length,
          expert: selectedExpert.length,
        },
      },
      message: `آزمون "${exam.title}" با ${selectedIds.length} سوال از بانک سوال ساخته شد`,
    }, { status: 201 });
  } catch (error) {
    console.error('Error generating exam:', error);
    return NextResponse.json(
      { error: 'خطا در تولید آزمون' },
      { status: 500 }
    );
  }
}

// GET /api/admin/question-bank/generate - Get generation history
export async function GET(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const skip = (page - 1) * limit;

    const [generations, total] = await Promise.all([
      db.generatedExam.findMany({
        include: {
          exam: { select: { id: true, title: true, type: true, isActive: true } },
          category: { select: { id: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.generatedExam.count(),
    ]);

    return NextResponse.json({
      data: generations,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Error fetching generation history:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت تاریخچه تولید' },
      { status: 500 }
    );
  }
}
