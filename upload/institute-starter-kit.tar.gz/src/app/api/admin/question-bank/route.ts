import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

// GET /api/admin/question-bank - List questions with filters
export async function GET(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search') || '';
    const type = searchParams.get('type') || '';
    const difficulty = searchParams.get('difficulty') || '';
    const categoryId = searchParams.get('categoryId') || '';
    const tag = searchParams.get('tag') || '';
    const isActive = searchParams.get('isActive') || '';
    const sortBy = searchParams.get('sortBy') || 'createdAt';
    const sortOrder = searchParams.get('sortOrder') || 'desc';

    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (search) {
      where.OR = [
        { text: { contains: search, mode: 'insensitive' } },
        { explanation: { contains: search, mode: 'insensitive' } },
        { tags: { has: search } },
      ];
    }
    if (type) where.type = type;
    if (difficulty) where.difficulty = difficulty;
    if (categoryId) where.categoryId = categoryId;
    if (tag) where.tags = { has: tag };
    if (isActive === 'true') where.isActive = true;
    if (isActive === 'false') where.isActive = false;

    const orderBy: Record<string, string> = {};
    orderBy[sortBy] = sortOrder;

    const [questions, total] = await Promise.all([
      db.questionBank.findMany({
        where,
        include: {
          category: { select: { id: true, name: true, color: true } },
        },
        orderBy,
        skip,
        take: limit,
      }),
      db.questionBank.count({ where }),
    ]);

    // Get stats
    const stats = await db.questionBank.aggregate({
      _count: { id: true },
      _avg: { successRate: true, points: true },
    });

    const difficultyBreakdown = await db.questionBank.groupBy({
      by: ['difficulty'],
      _count: { id: true },
      where: { isActive: true },
    });

    const typeBreakdown = await db.questionBank.groupBy({
      by: ['type'],
      _count: { id: true },
      where: { isActive: true },
    });

    return NextResponse.json({
      data: questions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
      stats: {
        totalQuestions: stats._count.id,
        avgSuccessRate: stats._avg.successRate,
        avgPoints: stats._avg.points,
        difficultyBreakdown: difficultyBreakdown.map((d) => ({
          difficulty: d.difficulty,
          count: d._count.id,
        })),
        typeBreakdown: typeBreakdown.map((t) => ({
          type: t.type,
          count: t._count.id,
        })),
      },
    });
  } catch (error) {
    console.error('Error fetching question bank:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت سوالات' },
      { status: 500 }
    );
  }
}

// POST /api/admin/question-bank - Create single question
export async function POST(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const body = await request.json();
    const {
      text,
      type = 'MULTIPLE_CHOICE',
      options,
      correctAnswer,
      explanation,
      categoryId,
      tags = [],
      difficulty = 'MEDIUM',
      bloomLevel,
      points = 1,
      estimatedTime = 60,
      imageUrl,
    } = body;

    if (!text?.trim()) {
      return NextResponse.json(
        { error: 'متن سوال الزامی است' },
        { status: 400 }
      );
    }

    if (!correctAnswer?.toString().trim()) {
      return NextResponse.json(
        { error: 'پاسخ صحیح الزامی است' },
        { status: 400 }
      );
    }

    const question = await db.questionBank.create({
      data: {
        text: text.trim(),
        type,
        options: options || null,
        correctAnswer: correctAnswer.toString().trim(),
        explanation: explanation?.trim() || null,
        categoryId: categoryId || null,
        tags: Array.isArray(tags) ? tags : [],
        difficulty,
        bloomLevel: bloomLevel || null,
        points: parseFloat(points) || 1,
        estimatedTime: parseInt(estimatedTime) || 60,
        imageUrl: imageUrl || null,
      },
      include: {
        category: { select: { id: true, name: true, color: true } },
      },
    });

    return NextResponse.json(question, { status: 201 });
  } catch (error) {
    console.error('Error creating question:', error);
    return NextResponse.json(
      { error: 'خطا در ایجاد سوال' },
      { status: 500 }
    );
  }
}

// PUT /api/admin/question-bank - Bulk update questions
export async function PUT(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const body = await request.json();
    const { ids, updates } = body;

    if (!ids?.length || !updates) {
      return NextResponse.json(
        { error: 'شناسه‌ها و تغییرات الزامی است' },
        { status: 400 }
      );
    }

    const result = await db.questionBank.updateMany({
      where: { id: { in: ids } },
      data: updates,
    });

    return NextResponse.json({
      message: `${result.count} سوال بروزرسانی شد`,
      count: result.count,
    });
  } catch (error) {
    console.error('Error bulk updating questions:', error);
    return NextResponse.json(
      { error: 'خطا در بروزرسانی سوالات' },
      { status: 500 }
    );
  }
}

// DELETE /api/admin/question-bank - Bulk delete questions
export async function DELETE(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const ids = searchParams.get('ids')?.split(',').filter(Boolean);
    const categoryId = searchParams.get('categoryId');
    const confirmDeleteAll = searchParams.get('deleteAll') === 'true';

    if (!ids?.length && !categoryId && !confirmDeleteAll) {
      return NextResponse.json(
        { error: 'شناسه یا دسته‌بندی الزامی است' },
        { status: 400 }
      );
    }

    let where: Record<string, unknown> = {};

    if (ids?.length) {
      where.id = { in: ids };
    } else if (categoryId) {
      where.categoryId = categoryId;
    }

    const result = await db.questionBank.deleteMany({ where });

    return NextResponse.json({
      message: `${result.count} سوال حذف شد`,
      count: result.count,
    });
  } catch (error) {
    console.error('Error deleting questions:', error);
    return NextResponse.json(
      { error: 'خطا در حذف سوالات' },
      { status: 500 }
    );
  }
}
