import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

// Supported CSV/Excel format columns (headers can be in Persian or English):
// text / سوال - Question text
// type / نوع - Question type (MULTIPLE_CHOICE, TRUE_FALSE, SHORT_ANSWER, etc.)
// option1 / گزینه۱ - Option 1 text
// option2 / گزینه۲ - Option 2 text
// option3 / گزینه۳ - Option 3 text
// option4 / گزینه۴ - Option 4 text
// correctAnswer / پاسخ - Correct answer (text or option number like "1", "2", "3", "4")
// explanation / توضیح - Explanation
// difficulty / سختی - EASY, MEDIUM, HARD, EXPERT
// points / نمره - Points
// category / دسته‌بندی - Category name
// tags / برچسب - Tags (comma separated)

function normalizeHeader(header: string): string {
  const h = header.trim().toLowerCase();
  const map: Record<string, string> = {
    'سوال': 'text', 'text': 'text', 'question': 'text', 'متن': 'text',
    'نوع': 'type', 'type': 'type', 'question_type': 'type', 'questiontype': 'type',
    'گزینه ۱': 'option1', 'گزینه۱': 'option1', 'option 1': 'option1', 'option1': 'option1', 'option_1': 'option1',
    'گزینه ۲': 'option2', 'گزینه۲': 'option2', 'option 2': 'option2', 'option2': 'option2', 'option_2': 'option2',
    'گزینه ۳': 'option3', 'گزینه۳': 'option3', 'option 3': 'option3', 'option3': 'option3', 'option_3': 'option3',
    'گزینه ۴': 'option4', 'گزینه۴': 'option4', 'option 4': 'option4', 'option4': 'option4', 'option_4': 'option4',
    'گزینه ۵': 'option5', 'گزینه۵': 'option5', 'option 5': 'option5', 'option5': 'option5', 'option_5': 'option5',
    'پاسخ': 'correctAnswer', 'correctanswer': 'correctAnswer', 'correct_answer': 'correctAnswer',
    'correct': 'correctAnswer', 'answer': 'correctAnswer', 'پاسخ صحیح': 'correctAnswer', 'جواب': 'correctAnswer',
    'توضیح': 'explanation', 'explanation': 'explanation',
    'سختی': 'difficulty', 'difficulty': 'difficulty', 'level': 'difficulty', 'سطح': 'difficulty',
    'نمره': 'points', 'points': 'points', 'point': 'points', 'score': 'points', 'امتیاز': 'points',
    'دسته‌بندی': 'category', 'category': 'category', 'دسته بندی': 'category',
    'برچسب': 'tags', 'tags': 'tags', 'tag': 'tags',
    'تصویر': 'imageUrl', 'image': 'imageUrl', 'imageUrl': 'imageUrl',
  };
  return map[h] || h;
}

function parseCSV(text: string): Record<string, string>[] {
  const lines = text.split(/\r?\n/).filter((l) => l.trim());
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(normalizeHeader);
  return lines.slice(1).map((line) => {
    const values = parseCSVLine(line);
    const row: Record<string, string> = {};
    headers.forEach((header, i) => {
      row[header] = values[i] || '';
    });
    return row;
  });
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (inQuotes) {
      if (char === '"' && line[i + 1] === '"') {
        current += '"';
        i++;
      } else if (char === '"') {
        inQuotes = false;
      } else {
        current += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
  }
  result.push(current.trim());
  return result;
}

function mapRowToQuestion(row: Record<string, string>, categoryMap: Map<string, string>) {
  const typeMap: Record<string, string> = {
    'تست': 'MULTIPLE_CHOICE', 'چهارگزینه': 'MULTIPLE_CHOICE', 'multiple_choice': 'MULTIPLE_CHOICE',
    'صحیح غلط': 'TRUE_FALSE', 'true_false': 'TRUE_FALSE', 'true/false': 'TRUE_FALSE',
    'تشریحی': 'SHORT_ANSWER', 'short_answer': 'SHORT_ANSWER',
    'چند انتخابی': 'MULTI_SELECT', 'multi_select': 'MULTI_SELECT',
  };

  const difficultyMap: Record<string, string> = {
    'آسان': 'EASY', 'easy': 'EASY', '1': 'EASY',
    'متوسط': 'MEDIUM', 'medium': 'MEDIUM', '2': 'MEDIUM',
    'سخت': 'HARD', 'hard': 'HARD', '3': 'HARD',
    'تخصصی': 'EXPERT', 'expert': 'EXPERT', '4': 'EXPERT',
  };

  const rawType = (row.type || '').trim();
  const rawDifficulty = (row.difficulty || '').trim();

  // Build options
  const options: { id: number; text: string; isCorrect: boolean }[] = [];
  const correctAnswerText = row.correctAnswer?.trim() || '';

  for (let i = 1; i <= 6; i++) {
    const optText = (row[`option${i}`] || '').trim();
    if (optText) {
      const isCorrect =
        correctAnswerText === String(i) ||
        correctAnswerText === optText ||
        correctAnswerText === `گزینه ${i}` ||
        correctAnswerText === `گزینه ${toPersianNum(i)}`;
      options.push({ id: i, text: optText, isCorrect });
    }
  }

  // For TRUE/FALSE
  if (rawType && (typeMap[rawType.toLowerCase()] === 'TRUE_FALSE' || rawType === 'TRUE_FALSE')) {
    const isTrue = correctAnswerText === 'صحیح' || correctAnswerText === 'true' || correctAnswerText === 'TRUE' || correctAnswerText === '1';
    return {
      text: row.text?.trim() || '',
      type: 'TRUE_FALSE',
      options: [{ id: 1, text: 'صحیح', isCorrect: isTrue }, { id: 2, text: 'غلط', isCorrect: !isTrue }],
      correctAnswer: isTrue ? 'صحیح' : 'غلط',
      explanation: row.explanation?.trim() || null,
      categoryId: categoryMap.get(row.category?.trim()) || null,
      tags: row.tags ? row.tags.split(/[،,]/).map((t) => t.trim()).filter(Boolean) : [],
      difficulty: difficultyMap[rawDifficulty.toLowerCase()] || 'MEDIUM',
      points: parseFloat(row.points) || 1,
      estimatedTime: 60,
    };
  }

  // For SHORT_ANSWER
  if (rawType && (typeMap[rawType.toLowerCase()] === 'SHORT_ANSWER' || rawType === 'SHORT_ANSWER')) {
    return {
      text: row.text?.trim() || '',
      type: 'SHORT_ANSWER',
      options: null,
      correctAnswer: correctAnswerText,
      explanation: row.explanation?.trim() || null,
      categoryId: categoryMap.get(row.category?.trim()) || null,
      tags: row.tags ? row.tags.split(/[،,]/).map((t) => t.trim()).filter(Boolean) : [],
      difficulty: difficultyMap[rawDifficulty.toLowerCase()] || 'MEDIUM',
      points: parseFloat(row.points) || 1,
      estimatedTime: 120,
    };
  }

  // Default: MULTIPLE_CHOICE
  // If correctAnswer is text, find matching option
  let actualCorrectAnswer = correctAnswerText;
  if (options.length > 0 && !options.some((o) => o.isCorrect)) {
    // Try to find by number
    const num = parseInt(correctAnswerText);
    if (!isNaN(num) && num >= 1 && num <= options.length) {
      options[num - 1].isCorrect = true;
      actualCorrectAnswer = options[num - 1].text;
    } else {
      // Try to find by text match
      const found = options.find((o) => o.text === correctAnswerText);
      if (found) {
        found.isCorrect = true;
      } else if (options.length > 0) {
        // Default to first option
        options[0].isCorrect = true;
        actualCorrectAnswer = options[0].text;
      }
    }
  } else if (options.length > 0) {
    actualCorrectAnswer = options.find((o) => o.isCorrect)?.text || correctAnswerText;
  }

  return {
    text: row.text?.trim() || '',
    type: typeMap[rawType.toLowerCase()] || 'MULTIPLE_CHOICE',
    options: options.length > 0 ? options : null,
    correctAnswer: actualCorrectAnswer,
    explanation: row.explanation?.trim() || null,
    categoryId: categoryMap.get(row.category?.trim()) || null,
    tags: row.tags ? row.tags.split(/[،,]/).map((t) => t.trim()).filter(Boolean) : [],
    difficulty: difficultyMap[rawDifficulty.toLowerCase()] || 'MEDIUM',
    points: parseFloat(row.points) || 1,
    estimatedTime: 60,
  };
}

function toPersianNum(num: number): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(num).replace(/\d/g, (d) => persianDigits[parseInt(d)]);
}

export async function POST(request: Request) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    const format = formData.get('format') as string; // csv, json, questionbank_json
    const categoryId = formData.get('categoryId') as string || '';
    const defaultDifficulty = formData.get('difficulty') as string || 'MEDIUM';
    const defaultType = formData.get('type') as string || 'MULTIPLE_CHOICE';

    if (!file) {
      return NextResponse.json({ error: 'فایل الزامی است' }, { status: 400 });
    }

    const fileContent = await file.text();
    let questions: Record<string, unknown>[] = [];
    let isQuestionBankFormat = false;

    if (format === 'questionbank_json' || file.name.endsWith('.json')) {
      try {
        const parsed = JSON.parse(fileContent);
        const arr = Array.isArray(parsed) ? parsed : parsed.questions || parsed.data || [parsed];
        // Check if this is question bank format (has options with id/text/isCorrect)
        if (arr.length > 0 && arr[0]?.options?.[0]?.id !== undefined) {
          isQuestionBankFormat = true;
          questions = arr;
        } else {
          questions = arr;
        }
      } catch {
        return NextResponse.json(
          { error: 'فرمت JSON نامعتبر است' },
          { status: 400 }
        );
      }
    } else {
      // CSV format
      questions = parseCSV(fileContent);
    }

    if (questions.length === 0) {
      return NextResponse.json(
        { error: 'هیچ سوالی در فایل یافت نشد' },
        { status: 400 }
      );
    }

    // Build category map
    const categoryMap = new Map<string, string>();
    if (categoryId) {
      categoryMap.set('', categoryId);
    } else {
      // Auto-create categories found in data
      const allCategories = [...new Set(questions.map((q: Record<string, unknown>) => String(q.category || '').trim()).filter(Boolean))];
      const existingCats = await db.questionBankCategory.findMany({
        where: { name: { in: allCategories } },
      });
      existingCats.forEach((cat) => categoryMap.set(cat.name, cat.id));

      for (const catName of allCategories) {
        if (!categoryMap.has(catName)) {
          const newCat = await db.questionBankCategory.create({
            data: { name: catName, color: getRandomColor() },
          });
          categoryMap.set(catName, newCat.id);
        }
      }
    }

    // Parse and insert questions
    let imported = 0;
    let skipped = 0;
    let errors: string[] = [];

    for (let i = 0; i < questions.length; i++) {
      try {
        const row = questions[i] as Record<string, unknown>;
        let qData;

        if (isQuestionBankFormat) {
          // Direct question bank format with options array
          const opts = (row.options as { id: number; text: string; isCorrect: boolean }[] | null);
          qData = {
            text: String(row.text || '').trim(),
            type: String(row.type || 'MULTIPLE_CHOICE'),
            options: opts,
            correctAnswer: String(row.correctAnswer || ''),
            explanation: row.explanation ? String(row.explanation) : null,
            categoryId: row.category ? (categoryMap.get(String(row.category)) || null) : (categoryId || null),
            tags: Array.isArray(row.tags) ? row.tags.map(String) : [],
            difficulty: String(row.difficulty || defaultDifficulty),
            points: Number(row.points) || 1,
            estimatedTime: 60,
          };
        } else {
          qData = mapRowToQuestion(row as Record<string, string>, categoryMap);
          // Override defaults if no value in row
          if (!row.type) qData.type = defaultType;
          if (!row.difficulty) qData.difficulty = defaultDifficulty;
          if (categoryId && !qData.categoryId) qData.categoryId = categoryId;
        }

        if (!qData.text) {
          skipped++;
          continue;
        }

        await db.questionBank.create({
          data: qData,
        });
        imported++;
      } catch (err) {
        errors.push(`سطر ${i + 1}: ${err instanceof Error ? err.message : 'خطای ناشناخته'}`);
        skipped++;
      }
    }

    return NextResponse.json({
      message: `ایمپورت تکمیل شد`,
      total: questions.length,
      imported,
      skipped,
      errors: errors.slice(0, 20), // max 20 errors
    });
  } catch (error) {
    console.error('Error importing questions:', error);
    return NextResponse.json(
      { error: 'خطا در ایمپورت سوالات' },
      { status: 500 }
    );
  }
}

function getRandomColor(): string {
  const colors = [
    '#6366f1', '#8b5cf6', '#a855f7', '#ec4899', '#f43f5e',
    '#ef4444', '#f97316', '#eab308', '#22c55e', '#14b8a6',
    '#06b6d4', '#3b82f6', '#1d4ed8', '#7c3aed', '#c026d3',
  ];
  return colors[Math.floor(Math.random() * colors.length)];
}
