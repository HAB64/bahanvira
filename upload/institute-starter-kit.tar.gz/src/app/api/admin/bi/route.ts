import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

// Persian month names (Jalali calendar)
const PERSIAN_MONTHS = [
  'فروردین', 'اردیبهشت', 'خرداد',
  'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر',
  'دی', 'بهمن', 'اسفند',
];

// Cluster label mapping
const CLUSTER_LABELS: Record<string, string> = {
  'tech-ai': 'فناوری',
  'financial': 'مالی',
  'management': 'مدیریت',
  'entrepreneurship': 'کارآفرینی',
  'capital-market': 'بازار سرمایه',
  'educational-services': 'خدمات آموزشی',
  'legal-services': 'خدمات حقوقی',
};

/**
 * Convert a Gregorian date to approximate Jalali month index (0-based).
 * Uses approximate boundary dates; for a production app use a proper library.
 *
 * Jalali month boundaries (approximate):
 *   Farvardin  ≈ Mar 21 – Apr 20   (index 0)
 *   Ordibehesht ≈ Apr 21 – May 21   (index 1)
 *   Khordad    ≈ May 22 – Jun 21   (index 2)
 *   Tir        ≈ Jun 22 – Jul 22   (index 3)
 *   Mordad     ≈ Jul 23 – Aug 22   (index 4)
 *   Shahrivar  ≈ Aug 23 – Sep 22   (index 5)
 *   Mehr       ≈ Sep 23 – Oct 22   (index 6)
 *   Aban       ≈ Oct 23 – Nov 21   (index 7)
 *   Azar       ≈ Nov 22 – Dec 21   (index 8)
 *   Dey        ≈ Dec 22 – Jan 20   (index 9)
 *   Bahman     ≈ Jan 21 – Feb 19   (index 10)
 *   Esfand     ≈ Feb 20 – Mar 20   (index 11)
 */
function gregorianToJalaliMonth(date: Date): number {
  const m = date.getMonth(); // 0-based: Jan=0
  const d = date.getDate();

  if (m === 2 && d >= 21) return 0;  // Farvardin
  if (m === 3 && d < 21) return 0;   // Farvardin (early April)
  if (m === 3 && d >= 21) return 1;  // Ordibehesht
  if (m === 4 && d < 22) return 1;   // Ordibehesht (early May)
  if (m === 4 && d >= 22) return 2;  // Khordad
  if (m === 5 && d < 22) return 2;   // Khordad (early June)
  if (m === 5 && d >= 22) return 3;  // Tir
  if (m === 6 && d < 23) return 3;   // Tir (early July)
  if (m === 6 && d >= 23) return 4;  // Mordad
  if (m === 7 && d < 23) return 4;   // Mordad (early August)
  if (m === 7 && d >= 23) return 5;  // Shahrivar
  if (m === 8 && d < 23) return 5;   // Shahrivar (early September)
  if (m === 8 && d >= 23) return 6;  // Mehr
  if (m === 9 && d < 23) return 6;   // Mehr (early October)
  if (m === 9 && d >= 23) return 7;  // Aban
  if (m === 10 && d < 22) return 7;  // Aban (early November)
  if (m === 10 && d >= 22) return 8; // Azar
  if (m === 11 && d < 22) return 8;  // Azar (early December)
  if (m === 11 && d >= 22) return 9; // Dey
  if (m === 0 && d < 21) return 9;   // Dey (early January)
  if (m === 0 && d >= 21) return 10;  // Bahman
  if (m === 1 && d < 20) return 10;  // Bahman (early February)
  if (m === 1 && d >= 20) return 11;  // Esfand
  if (m === 2 && d < 21) return 11;  // Esfand (early March)

  return 0; // Fallback
}

/**
 * Get the start and end of a Gregorian month for a given offset from current month.
 */
function getMonthRange(monthOffset: number): { start: Date; end: Date } {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth() - monthOffset, 1, 0, 0, 0, 0);
  const end = new Date(now.getFullYear(), now.getMonth() - monthOffset + 1, 0, 23, 59, 59, 999);
  return { start, end };
}

export async function GET(request: Request) {
  // Verify admin authentication
  const admin = await getAdminSession(request);
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    // Run all data-fetching in parallel for best performance
    const [
      totalLeads,
      totalLeadsLastMonth,
      totalEnrollments,
      totalEnrollmentsLastMonth,
      totalKarAmuz,
      activePrograms,
      paidPaymentsAgg,
      paidPaymentsLastMonthAgg,
      overduePendingAgg,
      allPaymentsAgg,
      paymentsByType,
      leadsByStage,
      leadsBySource,
      enrolledLeadsForConversion,
      leadsByAssignedTo,
      totalLessons,
      publishedLessons,
      allLessonProgress,
      allLessons,
      allEnrollments,
      allAttendances,
      allSessions,
      monthlyPayments,
      enrollmentsByProgramRaw,
      monthlyEnrollmentsRaw,
      monthlyAttendanceRaw,
    ] = await Promise.all([
      // Total leads (all time)
      db.lead.count(),

      // Total leads last month (for growth calc)
      db.lead.count({
        where: { createdAt: { gte: getMonthRange(1).start, lte: getMonthRange(1).end } },
      }),

      // Total enrollments (all time)
      db.enrollment.count(),

      // Total enrollments last month
      db.enrollment.count({
        where: { enrollmentDate: { gte: getMonthRange(1).start, lte: getMonthRange(1).end } },
      }),

      // Total KarAmuz
      db.karAmuz.count(),

      // Active programs
      db.skillProgram.count({ where: { isActive: true } }),

      // Total revenue (sum of PAID payments)
      db.payment.aggregate({
        _sum: { amount: true },
        _count: true,
        where: { status: 'PAID' },
      }),

      // Revenue last month (for growth)
      db.payment.aggregate({
        _sum: { amount: true },
        where: {
          status: 'PAID',
          paidAt: { gte: getMonthRange(1).start, lte: getMonthRange(1).end },
        },
      }),

      // Outstanding (OVERDUE + PENDING)
      db.payment.aggregate({
        _sum: { amount: true },
        where: { status: { in: ['OVERDUE', 'PENDING'] } },
      }),

      // All payments (for collection rate)
      db.payment.aggregate({
        _sum: { amount: true },
        _count: true,
      }),

      // Payments grouped by type
      db.payment.groupBy({
        by: ['type'],
        _sum: { amount: true },
        where: { status: 'PAID' },
      }),

      // Leads by stage
      db.lead.groupBy({
        by: ['stage'],
        _count: { id: true },
      }),

      // Leads by source
      db.lead.groupBy({
        by: ['source'],
        _count: { id: true },
      }),

      // Leads with stage ENROLLED (for conversion rate)
      db.lead.count({ where: { stage: 'ENROLLED' } }),

      // Leads by assignedTo (for top consultants)
      db.lead.groupBy({
        by: ['assignedTo'],
        _count: { id: true },
        where: { assignedTo: { not: '' } },
      }),

      // Total lessons
      db.lesson.count(),

      // Published lessons
      db.lesson.count({ where: { isPublished: true } }),

      // All lesson progress records
      db.lessonProgress.findMany({
        select: {
          progressPercent: true,
          status: true,
          lessonId: true,
          karAmuzId: true,
          lesson: {
            select: {
              id: true,
              title: true,
              type: true,
              skillProgramId: true,
              skillProgram: {
                select: { name: true },
              },
            },
          },
        },
      }),

      // All lessons with their program info
      db.lesson.findMany({
        select: {
          id: true,
          title: true,
          type: true,
          isPublished: true,
          skillProgramId: true,
          skillProgram: {
            select: { name: true, id: true },
          },
        },
      }),

      // All enrollments with program info
      db.enrollment.findMany({
        select: {
          id: true,
          status: true,
          skillProgramId: true,
          enrollmentDate: true,
          skillProgram: {
            select: { name: true, cluster: true, id: true },
          },
        },
      }),

      // All attendances
      db.attendance.findMany({
        select: {
          status: true,
          sessionId: true,
          session: {
            select: {
              date: true,
              skillProgramId: true,
              skillProgram: {
                select: { name: true },
              },
            },
          },
        },
      }),

      // All sessions (for attendance denominator)
      db.session.findMany({
        select: {
          id: true,
          date: true,
          skillProgramId: true,
          skillProgram: {
            select: { name: true },
          },
        },
      }),

      // Monthly payments (last 6 months)
      Promise.all(
        Array.from({ length: 6 }, async (_, i) => {
          const { start, end } = getMonthRange(5 - i);
          const agg = await db.payment.aggregate({
            _sum: { amount: true },
            _count: true,
            where: {
              status: 'PAID',
              paidAt: { gte: start, lte: end },
            },
          });
          return {
            monthIndex: gregorianToJalaliMonth(start),
            amount: agg._sum.amount ?? 0,
            count: agg._count,
          };
        })
      ),

      // Enrollments grouped by skillProgram
      db.enrollment.groupBy({
        by: ['skillProgramId'],
        _count: { id: true },
        where: { status: { in: ['ENROLLED', 'COMPLETED', 'DROPPED'] } },
      }),

      // Monthly enrollments (last 6 months)
      Promise.all(
        Array.from({ length: 6 }, async (_, i) => {
          const { start, end } = getMonthRange(5 - i);
          const count = await db.enrollment.count({
            where: { enrollmentDate: { gte: start, lte: end } },
          });
          return {
            monthIndex: gregorianToJalaliMonth(start),
            count,
          };
        })
      ),

      // Monthly attendance (last 6 months)
      Promise.all(
        Array.from({ length: 6 }, async (_, i) => {
          const { start, end } = getMonthRange(5 - i);
          const monthAttendances = await db.attendance.findMany({
            where: {
              session: { date: { gte: start, lte: end } },
            },
            select: { status: true },
          });
          const total = monthAttendances.length;
          const present = monthAttendances.filter(
            (a) => a.status === 'PRESENT' || a.status === 'LATE'
          ).length;
          return {
            monthIndex: gregorianToJalaliMonth(start),
            rate: total > 0 ? Math.round((present / total) * 100) : 0,
          };
        })
      ),
    ]);

    // ─── Revenue by cluster ───
    // Get paid payments with their related karAmuz -> enrollments -> skillProgram
    const paymentsWithCluster = await db.payment.findMany({
      where: { status: 'PAID' },
      include: {
        karAmuz: {
          include: {
            enrollments: {
              where: { status: { in: ['ENROLLED', 'COMPLETED'] } },
              include: {
                skillProgram: { select: { cluster: true } },
              },
            },
          },
        },
        lead: { select: { cluster: true } },
      },
    });

    const revenueByClusterMap: Record<string, { amount: number; count: number }> = {};
    for (const payment of paymentsWithCluster) {
      let cluster = '';
      if (payment.karAmuzId && payment.karAmuz) {
        const enrollment = payment.karAmuz.enrollments[0];
        if (enrollment?.skillProgram?.cluster) {
          cluster = enrollment.skillProgram.cluster;
        }
      }
      if (!cluster && payment.leadId && payment.lead) {
        cluster = payment.lead.cluster;
      }
      if (!cluster) continue;

      if (!revenueByClusterMap[cluster]) {
        revenueByClusterMap[cluster] = { amount: 0, count: 0 };
      }
      revenueByClusterMap[cluster].amount += payment.amount;
      revenueByClusterMap[cluster].count += 1;
    }

    const revenueByCluster = Object.entries(revenueByClusterMap).map(([cluster, data]) => ({
      cluster: CLUSTER_LABELS[cluster] || cluster,
      amount: data.amount,
      count: data.count,
    }));

    // ─── Current month revenue for growth ───
    const currentMonthRev = await db.payment.aggregate({
      _sum: { amount: true },
      where: {
        status: 'PAID',
        paidAt: { gte: getMonthRange(0).start, lte: getMonthRange(0).end },
      },
    });

    // ─── Current month leads for growth ───
    const currentMonthLeads = await db.lead.count({
      where: { createdAt: { gte: getMonthRange(0).start, lte: getMonthRange(0).end } },
    });

    // ─── Current month enrollments for growth ───
    const currentMonthEnrollments = await db.enrollment.count({
      where: { enrollmentDate: { gte: getMonthRange(0).start, lte: getMonthRange(0).end } },
    });

    // ─── Growth calculations ───
    const leadsGrowth = totalLeadsLastMonth > 0
      ? Math.round(((currentMonthLeads - totalLeadsLastMonth) / totalLeadsLastMonth) * 100)
      : 0;
    const enrollmentGrowth = totalEnrollmentsLastMonth > 0
      ? Math.round(((currentMonthEnrollments - totalEnrollmentsLastMonth) / totalEnrollmentsLastMonth) * 100)
      : 0;
    const lastMonthRevenue = paidPaymentsLastMonthAgg._sum.amount ?? 0;
    const thisMonthRevenue = currentMonthRev._sum.amount ?? 0;
    const revenueGrowth = lastMonthRevenue > 0
      ? Math.round(((thisMonthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100)
      : 0;

    // ─── Revenue section ───
    const totalRevenue = paidPaymentsAgg._sum.amount ?? 0;
    const outstanding = overduePendingAgg._sum.amount ?? 0;
    const totalAllPayments = allPaymentsAgg._sum.amount ?? 0;
    const collectionRate = totalAllPayments > 0
      ? Math.round((totalRevenue / totalAllPayments) * 100)
      : 0;

    const revenueByPaymentType = paymentsByType.map((p) => ({
      type: p.type,
      amount: p._sum.amount ?? 0,
    }));

    // Monthly revenue
    const revenueMonthly = monthlyPayments.map((m) => ({
      month: PERSIAN_MONTHS[m.monthIndex],
      amount: m.amount,
      count: m.count,
    }));

    // ─── Enrollments section ───
    // Get skill program names for enrollment grouping
    const skillPrograms = await db.skillProgram.findMany({
      select: { id: true, name: true, cluster: true },
    });
    const spMap = new Map(skillPrograms.map((sp) => [sp.id, sp]));

    // Enrollment counts by program with status breakdown
    const enrollmentByProgramMap: Record<string, {
      programName: string;
      count: number;
      activeCount: number;
      completedCount: number;
    }> = {};

    for (const enr of allEnrollments) {
      const spId = enr.skillProgramId;
      const sp = spMap.get(spId);
      const name = sp?.name || 'نامشخص';

      if (!enrollmentByProgramMap[spId]) {
        enrollmentByProgramMap[spId] = {
          programName: name,
          count: 0,
          activeCount: 0,
          completedCount: 0,
        };
      }
      enrollmentByProgramMap[spId].count += 1;
      if (enr.status === 'ENROLLED') {
        enrollmentByProgramMap[spId].activeCount += 1;
      }
      if (enr.status === 'COMPLETED') {
        enrollmentByProgramMap[spId].completedCount += 1;
      }
    }

    const enrollmentByProgram = Object.values(enrollmentByProgramMap);

    // Enrollment by cluster
    const enrollmentByClusterMap: Record<string, number> = {};
    for (const enr of allEnrollments) {
      const cluster = enr.skillProgram?.cluster || '';
      if (cluster) {
        enrollmentByClusterMap[cluster] = (enrollmentByClusterMap[cluster] || 0) + 1;
      }
    }
    const enrollmentByCluster = Object.entries(enrollmentByClusterMap).map(([cluster, count]) => ({
      cluster: CLUSTER_LABELS[cluster] || cluster,
      count,
    }));

    // Monthly enrollments
    const enrollmentByMonth = monthlyEnrollmentsRaw.map((m) => ({
      month: PERSIAN_MONTHS[m.monthIndex],
      count: m.count,
    }));

    // Dropout & completion rates
    const totalEnrolledStatus = allEnrollments.filter(
      (e) => e.status === 'ENROLLED' || e.status === 'COMPLETED' || e.status === 'DROPPED' || e.status === 'FAILED'
    ).length;
    const droppedCount = allEnrollments.filter((e) => e.status === 'DROPPED').length;
    const completedCount = allEnrollments.filter((e) => e.status === 'COMPLETED').length;
    const dropoutRate = totalEnrolledStatus > 0
      ? Math.round((droppedCount / totalEnrolledStatus) * 100)
      : 0;
    const completionRate = totalEnrolledStatus > 0
      ? Math.round((completedCount / totalEnrolledStatus) * 100)
      : 0;

    // ─── LMS section ───
    const totalProgressRecords = allLessonProgress.length;
    const avgCompletionPercent = totalProgressRecords > 0
      ? Math.round(
          allLessonProgress.reduce((sum, lp) => sum + lp.progressPercent, 0) / totalProgressRecords
        )
      : 0;

    // timeSpent is not tracked in the schema; default to 0
    const avgTimeSpent = 0;

    // LMS by program
    const lmsByProgramMap: Record<string, {
      programName: string;
      totalLessons: number;
      totalProgress: number;
      progressCount: number;
      enrolledCount: number;
    }> = {};

    // Count lessons per program
    for (const lesson of allLessons) {
      const spId = lesson.skillProgramId;
      const spName = lesson.skillProgram?.name || 'نامشخص';
      if (!lmsByProgramMap[spId]) {
        lmsByProgramMap[spId] = {
          programName: spName,
          totalLessons: 0,
          totalProgress: 0,
          progressCount: 0,
          enrolledCount: 0,
        };
      }
      lmsByProgramMap[spId].totalLessons += 1;
    }

    // Sum progress per program
    for (const lp of allLessonProgress) {
      const lesson = lp.lesson;
      const spId = lesson.skillProgramId;
      if (lmsByProgramMap[spId]) {
        lmsByProgramMap[spId].totalProgress += lp.progressPercent;
        lmsByProgramMap[spId].progressCount += 1;
      }
    }

    // Count enrolled per program
    for (const enr of allEnrollments) {
      const spId = enr.skillProgramId;
      if (lmsByProgramMap[spId]) {
        lmsByProgramMap[spId].enrolledCount += 1;
      }
    }

    const lmsByProgram = Object.values(lmsByProgramMap).map((p) => ({
      programName: p.programName,
      totalLessons: p.totalLessons,
      avgProgress: p.progressCount > 0 ? Math.round(p.totalProgress / p.progressCount) : 0,
      enrolledCount: p.enrolledCount,
    }));

    // Popular lessons (by completion rate)
    const lessonProgressMap: Record<string, {
      title: string;
      type: string;
      totalRecords: number;
      completedRecords: number;
    }> = {};

    for (const lp of allLessonProgress) {
      const lessonId = lp.lessonId;
      if (!lessonProgressMap[lessonId]) {
        lessonProgressMap[lessonId] = {
          title: lp.lesson.title,
          type: lp.lesson.type,
          totalRecords: 0,
          completedRecords: 0,
        };
      }
      lessonProgressMap[lessonId].totalRecords += 1;
      if (lp.status === 'COMPLETED') {
        lessonProgressMap[lessonId].completedRecords += 1;
      }
    }

    const popularLessons = Object.values(lessonProgressMap)
      .map((l) => ({
        title: l.title,
        type: l.type,
        completionRate: l.totalRecords > 0 ? Math.round((l.completedRecords / l.totalRecords) * 100) : 0,
      }))
      .sort((a, b) => b.completionRate - a.completionRate)
      .slice(0, 10);

    // ─── CRM section ───
    const crmLeadsByStage = leadsByStage.map((item) => ({
      stage: item.stage,
      count: item._count.id,
    }));

    const crmLeadsBySource = leadsBySource.map((item) => ({
      source: item.source || 'نامشخص',
      count: item._count.id,
    }));

    // Conversion rate (% of leads that become ENROLLED)
    const conversionRate = totalLeads > 0
      ? Math.round((enrolledLeadsForConversion / totalLeads) * 100)
      : 0;

    // Average time to enroll (days from lead creation to becoming ENROLLED)
    // We'll look at leads that have stage ENROLLED and have a KarAmuz (which means they were enrolled)
    const enrolledLeadsWithDates = await db.lead.findMany({
      where: { stage: 'ENROLLED' },
      select: {
        createdAt: true,
        karAmuz: {
          select: { createdAt: true },
        },
      },
    });

    let avgTimeToEnroll = 0;
    if (enrolledLeadsWithDates.length > 0) {
      const totalDays = enrolledLeadsWithDates.reduce((sum, lead) => {
        if (lead.karAmuz) {
          const diffMs = new Date(lead.karAmuz.createdAt).getTime() - new Date(lead.createdAt).getTime();
          return sum + diffMs / (1000 * 60 * 60 * 24);
        }
        return sum;
      }, 0);
      const leadsWithKarAmuz = enrolledLeadsWithDates.filter((l) => l.karAmuz).length;
      avgTimeToEnroll = leadsWithKarAmuz > 0 ? Math.round(totalDays / leadsWithKarAmuz) : 0;
    }

    // Top consultants
    // For each assignedTo, count total leads and conversions (ENROLLED)
    const consultantIds = leadsByAssignedTo.map((l) => l.assignedTo).filter(Boolean);
    const consultantConversionMap: Record<string, { leads: number; conversions: number }> = {};

    for (const item of leadsByAssignedTo) {
      consultantConversionMap[item.assignedTo] = {
        leads: item._count.id,
        conversions: 0,
      };
    }

    // Get conversions per consultant
    const conversionsByAssignedTo = await db.lead.groupBy({
      by: ['assignedTo'],
      _count: { id: true },
      where: {
        assignedTo: { in: consultantIds },
        stage: 'ENROLLED',
      },
    });

    for (const item of conversionsByAssignedTo) {
      if (consultantConversionMap[item.assignedTo]) {
        consultantConversionMap[item.assignedTo].conversions = item._count.id;
      }
    }

    // Get admin display names
    const adminUsers = await db.adminUser.findMany({
      where: { username: { in: consultantIds } },
      select: { username: true, displayName: true },
    });
    const adminNameMap = new Map(adminUsers.map((u) => [u.username, u.displayName || u.username]));

    const topConsultants = Object.entries(consultantConversionMap)
      .map(([username, data]) => ({
        name: adminNameMap.get(username) || username,
        leads: data.leads,
        conversions: data.conversions,
      }))
      .sort((a, b) => b.conversions - a.conversions)
      .slice(0, 10);

    // ─── Attendance section ───
    const totalAttendanceRecords = allAttendances.length;
    const presentOrLate = allAttendances.filter(
      (a) => a.status === 'PRESENT' || a.status === 'LATE'
    ).length;
    const overallAttendanceRate = totalAttendanceRecords > 0
      ? Math.round((presentOrLate / totalAttendanceRecords) * 100)
      : 0;

    // Attendance by program
    const attendanceByProgramMap: Record<string, { total: number; present: number }> = {};
    for (const att of allAttendances) {
      const programName = att.session?.skillProgram?.name || 'نامشخص';
      if (!attendanceByProgramMap[programName]) {
        attendanceByProgramMap[programName] = { total: 0, present: 0 };
      }
      attendanceByProgramMap[programName].total += 1;
      if (att.status === 'PRESENT' || att.status === 'LATE') {
        attendanceByProgramMap[programName].present += 1;
      }
    }

    const attendanceByProgram = Object.entries(attendanceByProgramMap).map(([programName, data]) => ({
      programName,
      rate: data.total > 0 ? Math.round((data.present / data.total) * 100) : 0,
    }));

    // Attendance trend (last 6 months)
    const attendanceTrend = monthlyAttendanceRaw.map((m) => ({
      month: PERSIAN_MONTHS[m.monthIndex],
      rate: m.rate,
    }));

    // ─── Build final response ───
    const response = {
      overview: {
        totalLeads,
        totalEnrollments,
        totalRevenue,
        totalKarAmuz,
        activePrograms,
        leadsGrowth,
        enrollmentGrowth,
        revenueGrowth,
      },
      revenue: {
        monthly: revenueMonthly,
        byCluster: revenueByCluster,
        byPaymentType: revenueByPaymentType,
        outstanding,
        collectionRate,
      },
      enrollments: {
        byProgram: enrollmentByProgram,
        byCluster: enrollmentByCluster,
        byMonth: enrollmentByMonth,
        dropoutRate,
        completionRate,
      },
      lms: {
        totalLessons,
        publishedLessons,
        avgCompletionPercent,
        byProgram: lmsByProgram,
        popularLessons,
        avgTimeSpent,
      },
      crm: {
        leadsByStage: crmLeadsByStage,
        leadsBySource: crmLeadsBySource,
        avgTimeToEnroll,
        conversionRate,
        topConsultants,
      },
      attendance: {
        overallRate: overallAttendanceRate,
        byProgram: attendanceByProgram,
        trend: attendanceTrend,
      },
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error('BI Dashboard API error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch BI dashboard data' },
      { status: 500 }
    );
  }
}
