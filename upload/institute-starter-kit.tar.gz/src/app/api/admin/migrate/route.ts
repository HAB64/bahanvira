import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * POST /api/admin/migrate
 * اجرای مایگریشن دیتابیس — ایجاد جداول ناقص (فقط ادمین)
 * Creates missing database tables using Prisma's raw SQL
 */
export async function POST(request: NextRequest) {
  try {
    // Allow admin session OR secret key (for CLI migration)
    const authHeader = request.headers.get('Authorization');
    const secretKey = authHeader?.replace('Bearer ', '');
    const adminSession = await getAdminSession();
    const migrationSecret = process.env.MIGRATION_SECRET || 'bahan-migrate-2024';

    if (!adminSession && secretKey !== migrationSecret) {
      return NextResponse.json({ error: 'احراز هویت نشده' }, { status: 401 });
    }

    const results: string[] = [];

    // Create Exam table
    await db.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS "Exam" (
        "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        "title" TEXT NOT NULL,
        "description" TEXT,
        "skillProgramId" TEXT,
        "type" TEXT NOT NULL DEFAULT 'QUIZ',
        "durationMinutes" INTEGER NOT NULL DEFAULT 30,
        "passingScore" DOUBLE PRECISION NOT NULL DEFAULT 10,
        "maxAttempts" INTEGER NOT NULL DEFAULT 1,
        "shuffleQuestions" BOOLEAN NOT NULL DEFAULT true,
        "showResults" TEXT NOT NULL DEFAULT 'AFTER_SUBMIT',
        "isActive" BOOLEAN NOT NULL DEFAULT true,
        "openAt" TIMESTAMP,
        "closeAt" TIMESTAMP,
        "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);
    results.push('Exam table created/verified');

    // Create ExamQuestion table
    await db.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS "ExamQuestion" (
        "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        "examId" TEXT NOT NULL REFERENCES "Exam"("id") ON DELETE CASCADE ON UPDATE CASCADE,
        "text" TEXT NOT NULL,
        "type" TEXT NOT NULL DEFAULT 'MULTIPLE_CHOICE',
        "options" JSONB,
        "correctAnswer" TEXT NOT NULL,
        "points" DOUBLE PRECISION NOT NULL DEFAULT 1,
        "difficulty" TEXT NOT NULL DEFAULT 'MEDIUM',
        "explanation" TEXT,
        "order" INTEGER NOT NULL DEFAULT 0,
        "image" TEXT,
        "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);
    results.push('ExamQuestion table created/verified');

    // Create ExamAttempt table
    await db.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS "ExamAttempt" (
        "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        "examId" TEXT NOT NULL REFERENCES "Exam"("id") ON DELETE CASCADE ON UPDATE CASCADE,
        "karAmuzId" TEXT NOT NULL REFERENCES "KarAmuz"("id") ON DELETE CASCADE ON UPDATE CASCADE,
        "status" TEXT NOT NULL DEFAULT 'IN_PROGRESS',
        "score" DOUBLE PRECISION,
        "maxScore" DOUBLE PRECISION,
        "percentage" DOUBLE PRECISION,
        "isPassed" BOOLEAN,
        "startedAt" TIMESTAMP NOT NULL DEFAULT NOW(),
        "submittedAt" TIMESTAMP,
        "timeSpentSec" INTEGER,
        "savedAnswers" JSONB,
        "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);
    results.push('ExamAttempt table created/verified');

    // Create ExamAnswer table
    await db.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS "ExamAnswer" (
        "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
        "attemptId" TEXT NOT NULL REFERENCES "ExamAttempt"("id") ON DELETE CASCADE ON UPDATE CASCADE,
        "questionId" TEXT NOT NULL REFERENCES "ExamQuestion"("id") ON DELETE CASCADE ON UPDATE CASCADE,
        "selectedAnswer" TEXT,
        "isCorrect" BOOLEAN,
        "pointsEarned" DOUBLE PRECISION NOT NULL DEFAULT 0,
        "createdAt" TIMESTAMP NOT NULL DEFAULT NOW(),
        "updatedAt" TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `);
    results.push('ExamAnswer table created/verified');

    // Create indexes
    const indexes = [
      `CREATE INDEX IF NOT EXISTS "Exam_skillProgramId_idx" ON "Exam"("skillProgramId")`,
      `CREATE INDEX IF NOT EXISTS "Exam_isActive_idx" ON "Exam"("isActive")`,
      `CREATE INDEX IF NOT EXISTS "Exam_type_idx" ON "Exam"("type")`,
      `CREATE INDEX IF NOT EXISTS "ExamQuestion_examId_idx" ON "ExamQuestion"("examId")`,
      `CREATE INDEX IF NOT EXISTS "ExamQuestion_difficulty_idx" ON "ExamQuestion"("difficulty")`,
      `CREATE INDEX IF NOT EXISTS "ExamAttempt_examId_idx" ON "ExamAttempt"("examId")`,
      `CREATE INDEX IF NOT EXISTS "ExamAttempt_karAmuzId_idx" ON "ExamAttempt"("karAmuzId")`,
      `CREATE INDEX IF NOT EXISTS "ExamAttempt_status_idx" ON "ExamAttempt"("status")`,
      `CREATE INDEX IF NOT EXISTS "ExamAttempt_karAmuzId_examId_idx" ON "ExamAttempt"("karAmuzId", "examId")`,
      `CREATE INDEX IF NOT EXISTS "ExamAnswer_attemptId_idx" ON "ExamAnswer"("attemptId")`,
      `CREATE INDEX IF NOT EXISTS "ExamAnswer_questionId_idx" ON "ExamAnswer"("questionId")`,
    ];

    for (const idxSql of indexes) {
      await db.$executeRawUnsafe(idxSql);
    }
    results.push(`${indexes.length} indexes created/verified`);

    // Create unique constraint for ExamAnswer
    try {
      await db.$executeRawUnsafe(`
        ALTER TABLE "ExamAnswer" ADD CONSTRAINT "ExamAnswer_attemptId_questionId_key" UNIQUE ("attemptId", "questionId")
      `);
      results.push('ExamAnswer unique constraint added');
    } catch {
      results.push('ExamAnswer unique constraint already exists');
    }

    // Add foreign key for Exam -> SkillProgram
    try {
      await db.$executeRawUnsafe(`
        ALTER TABLE "Exam" ADD CONSTRAINT "Exam_skillProgramId_fkey" 
        FOREIGN KEY ("skillProgramId") REFERENCES "SkillProgram"("id") ON DELETE SET NULL ON UPDATE CASCADE
      `);
      results.push('Exam->SkillProgram FK added');
    } catch {
      results.push('Exam->SkillProgram FK already exists');
    }

    return NextResponse.json({
      success: true,
      message: 'مایگریشن با موفقیت اجرا شد',
      results,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'خطای ناشناخته';
    console.error('Migration error:', message);
    return NextResponse.json(
      { error: 'خطا در اجرای مایگریشن', details: message.slice(-500) },
      { status: 500 }
    );
  }
}
