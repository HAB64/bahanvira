import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/roles/[id] — Get a single role
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const role = await db.adminRole.findUnique({
      where: { id },
      include: {
        permissions: true,
        _count: {
          select: { users: true },
        },
      },
    });

    if (!role) {
      return NextResponse.json(
        { error: 'نقش یافت نشد' },
        { status: 404 }
      );
    }

    return NextResponse.json(role);
  } catch (error) {
    console.error('Failed to fetch role:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت اطلاعات نقش' },
      { status: 500 }
    );
  }
}

// PUT /api/admin/roles/[id] — Update a role
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, label, description, permissions } = body;

    const existing = await db.adminRole.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: 'نقش یافت نشد' },
        { status: 404 }
      );
    }

    // Prevent modification of system role name
    if (existing.isSystem && name && name !== existing.name) {
      return NextResponse.json(
        { error: 'نام نقش‌های سیستمی قابل تغییر نیست' },
        { status: 400 }
      );
    }

    // If name changed, check uniqueness
    if (name && name !== existing.name) {
      const duplicate = await db.adminRole.findUnique({
        where: { name },
      });
      if (duplicate) {
        return NextResponse.json(
          { error: 'نقشی با این نام قبلاً وجود دارد' },
          { status: 409 }
        );
      }
    }

    // Update role
    const updateData: Record<string, unknown> = {};
    if (name !== undefined) updateData.name = name;
    if (label !== undefined) updateData.label = label;
    if (description !== undefined) updateData.description = description;

    // If permissions array provided, replace all permissions
    if (permissions !== undefined) {
      // Delete existing permissions
      await db.adminPermission.deleteMany({
        where: { roleId: id },
      });

      // Create new permissions
      if (permissions.length > 0) {
        await db.adminPermission.createMany({
          data: permissions.map((p: { resource: string; action: string }) => ({
            roleId: id,
            resource: p.resource,
            action: p.action,
          })),
        });
      }
    }

    const role = await db.adminRole.update({
      where: { id },
      data: updateData,
      include: {
        permissions: true,
        _count: {
          select: { users: true },
        },
      },
    });

    return NextResponse.json(role);
  } catch (error) {
    console.error('Failed to update role:', error);
    return NextResponse.json(
      { error: 'خطا در به‌روزرسانی نقش' },
      { status: 500 }
    );
  }
}

// DELETE /api/admin/roles/[id] — Delete a role
export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const existing = await db.adminRole.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: 'نقش یافت نشد' },
        { status: 404 }
      );
    }

    // Prevent deletion of system roles
    if (existing.isSystem) {
      return NextResponse.json(
        { error: 'نقش‌های سیستمی قابل حذف نیستند' },
        { status: 400 }
      );
    }

    // Check if any users are assigned to this role
    const usersWithRole = await db.adminUser.count({
      where: { roleId: id },
    });

    if (usersWithRole > 0) {
      return NextResponse.json(
        { error: `این نقش به ${usersWithRole} کاربر اختصاص داده شده و قابل حذف نیست. ابتدا نقش کاربران را تغییر دهید.` },
        { status: 400 }
      );
    }

    // Delete permissions first, then role
    await db.adminPermission.deleteMany({
      where: { roleId: id },
    });

    await db.adminRole.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to delete role:', error);
    return NextResponse.json(
      { error: 'خطا در حذف نقش' },
      { status: 500 }
    );
  }
}
