import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/admin/roles — List all roles with permissions
export async function GET() {
  try {
    const roles = await db.adminRole.findMany({
      include: {
        permissions: true,
        _count: {
          select: { users: true },
        },
      },
      orderBy: { createdAt: 'asc' },
    });

    return NextResponse.json(roles);
  } catch (error) {
    console.error('Failed to fetch roles:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت لیست نقش‌ها' },
      { status: 500 }
    );
  }
}

// POST /api/admin/roles — Create a new role
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, label, description, isSystem, permissions } = body;

    if (!name || !label) {
      return NextResponse.json(
        { error: 'نام و عنوان نقش الزامی است' },
        { status: 400 }
      );
    }

    // Check if role name already exists
    const existing = await db.adminRole.findUnique({
      where: { name },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'نقشی با این نام قبلاً وجود دارد' },
        { status: 409 }
      );
    }

    // Create role with permissions
    const role = await db.adminRole.create({
      data: {
        name,
        label,
        description: description || '',
        isSystem: isSystem || false,
        permissions: permissions
          ? {
              create: permissions.map((p: { resource: string; action: string }) => ({
                resource: p.resource,
                action: p.action,
              })),
            }
          : undefined,
      },
      include: {
        permissions: true,
        _count: {
          select: { users: true },
        },
      },
    });

    return NextResponse.json(role, { status: 201 });
  } catch (error) {
    console.error('Failed to create role:', error);
    return NextResponse.json(
      { error: 'خطا در ایجاد نقش' },
      { status: 500 }
    );
  }
}
