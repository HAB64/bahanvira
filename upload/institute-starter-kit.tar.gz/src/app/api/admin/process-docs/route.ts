import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAdminSession } from '@/lib/admin-auth'

// ═══════════════════════════════════════════════════════
// GET — List all process documents (with optional category filter)
// ═══════════════════════════════════════════════════════

export async function GET(request: NextRequest) {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')

    const where = category && category !== 'all' ? { category } : {}

    const docs = await db.processDocument.findMany({
      where,
      orderBy: [{ createdAt: 'desc' }],
    })

    return NextResponse.json(docs)
  } catch (error) {
    console.error('[ProcessDocs GET]', error)
    return NextResponse.json({ error: 'خطا در دریافت فرآیندها' }, { status: 500 })
  }
}

// ═══════════════════════════════════════════════════════
// POST — Create a new process document
// ═══════════════════════════════════════════════════════

export async function POST(request: NextRequest) {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await request.json()
    const {
      name, description, category, isoClause, owner, department,
      supplier, inputs, processSteps, outputs, customers,
      feedbackMethods, kpis, risks,
    } = body

    if (!name?.trim()) {
      return NextResponse.json({ error: 'نام فرآیند الزامی است' }, { status: 400 })
    }

    const doc = await db.processDocument.create({
      data: {
        name: name.trim(),
        description: description || '',
        category: category || 'general',
        isoClause: isoClause || '4.4',
        owner: owner || '',
        department: department || '',
        supplier: supplier || '',
        inputs: inputs || '',
        processSteps: typeof processSteps === 'string' ? processSteps : JSON.stringify(processSteps || []),
        outputs: outputs || '',
        customers: customers || '',
        feedbackMethods: feedbackMethods || '',
        kpis: typeof kpis === 'string' ? kpis : JSON.stringify(kpis || []),
        risks: typeof risks === 'string' ? risks : JSON.stringify(risks || []),
      },
    })

    return NextResponse.json(doc, { status: 201 })
  } catch (error) {
    console.error('[ProcessDocs POST]', error)
    return NextResponse.json({ error: 'خطا در ایجاد فرآیند' }, { status: 500 })
  }
}