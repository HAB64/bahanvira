import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAdminSession } from '@/lib/admin-auth'

// ═══════════════════════════════════════════════════════
// GET — Single process document
// ═══════════════════════════════════════════════════════

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await params
    const doc = await db.processDocument.findUnique({ where: { id } })
    if (!doc) {
      return NextResponse.json({ error: 'یافت نشد' }, { status: 404 })
    }
    return NextResponse.json(doc)
  } catch (error) {
    console.error('[ProcessDocs GET /:id]', error)
    return NextResponse.json({ error: 'خطا در دریافت فرآیند' }, { status: 500 })
  }
}

// ═══════════════════════════════════════════════════════
// PUT — Update a process document
// ═══════════════════════════════════════════════════════

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await params
    const body = await request.json()

    const existing = await db.processDocument.findUnique({ where: { id } })
    if (!existing) {
      return NextResponse.json({ error: 'یافت نشد' }, { status: 404 })
    }

    const doc = await db.processDocument.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name.trim() }),
        ...(body.description !== undefined && { description: body.description }),
        ...(body.category !== undefined && { category: body.category }),
        ...(body.isoClause !== undefined && { isoClause: body.isoClause }),
        ...(body.isActive !== undefined && { isActive: body.isActive }),
        ...(body.owner !== undefined && { owner: body.owner }),
        ...(body.department !== undefined && { department: body.department }),
        ...(body.supplier !== undefined && { supplier: body.supplier }),
        ...(body.inputs !== undefined && { inputs: body.inputs }),
        ...(body.processSteps !== undefined && {
          processSteps: typeof body.processSteps === 'string' ? body.processSteps : JSON.stringify(body.processSteps),
        }),
        ...(body.outputs !== undefined && { outputs: body.outputs }),
        ...(body.customers !== undefined && { customers: body.customers }),
        ...(body.feedbackMethods !== undefined && { feedbackMethods: body.feedbackMethods }),
        ...(body.kpis !== undefined && {
          kpis: typeof body.kpis === 'string' ? body.kpis : JSON.stringify(body.kpis),
        }),
        ...(body.risks !== undefined && {
          risks: typeof body.risks === 'string' ? body.risks : JSON.stringify(body.risks),
        }),
        ...(body.lastReviewedAt !== undefined && { lastReviewedAt: body.lastReviewedAt ? new Date(body.lastReviewedAt) : null }),
        ...(body.reviewedBy !== undefined && { reviewedBy: body.reviewedBy }),
        version: (body.version !== undefined ? body.version : existing.version) + (body._bumpVersion ? 1 : 0),
      },
    })

    return NextResponse.json(doc)
  } catch (error) {
    console.error('[ProcessDocs PUT /:id]', error)
    return NextResponse.json({ error: 'خطا در بروزرسانی فرآیند' }, { status: 500 })
  }
}

// ═══════════════════════════════════════════════════════
// DELETE — Remove a process document
// ═══════════════════════════════════════════════════════

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await getAdminSession()
  if (!admin) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { id } = await params
    await db.processDocument.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('[ProcessDocs DELETE /:id]', error)
    return NextResponse.json({ error: 'خطا در حذف فرآیند' }, { status: 500 })
  }
}