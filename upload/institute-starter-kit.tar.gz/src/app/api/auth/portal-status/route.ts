/**
 * Portal Auth Status API — بررسی وضعیت ورود کاربر پورتال
 * برای نمایش در هدر سایت
 */
import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';

export async function GET(req: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(req);

    if (!user) {
      return NextResponse.json({ authenticated: false });
    }

    return NextResponse.json({
      authenticated: true,
      user: {
        name: user.karAmuz
          ? `${user.karAmuz.firstName} ${user.karAmuz.lastName}`
          : user.lead?.name || user.username,
        username: user.username,
        type: user.karAmuzId ? 'karamuz' : user.leadId ? 'lead' : 'portal',
      },
    });
  } catch {
    return NextResponse.json({ authenticated: false });
  }
}
