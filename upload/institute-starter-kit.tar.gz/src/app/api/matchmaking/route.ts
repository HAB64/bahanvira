import { NextResponse } from 'next/server'
import { matchmake, type MatchmakingInput } from '@/lib/skill-graph'
import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { age, interests, goal, source } = body as MatchmakingInput

    if (!goal || !interests || !Array.isArray(interests)) {
      return NextResponse.json(
        { خطا: 'goal و interests الزامی هستند' },
        { status: 400 }
      )
    }

    // Run matchmaking algorithm
    const result = matchmake({ age, interests, goal, source })

    // Log the matchmaking request to EventLog (fire-and-forget)
    try {
      const cookieHeader = request.headers.get('cookie') || ''
      const sessionMatch = cookieHeader.match(/br_session=([^;]+)/)
      const utmMatch = cookieHeader.match(/br_campaign=([^;]+)/)
      
      let utmData = { source: '', medium: '', campaign: '' }
      if (utmMatch) {
        try {
          utmData = JSON.parse(decodeURIComponent(utmMatch[1]))
        } catch { /* ignore */ }
      }

      await db.eventLog.create({
        data: {
          event: 'QUIZ_COMPLETE',
          category: 'engagement',
          label: `Matchmaking: ${goal}`,
          page: '/api/matchmaking',
          sessionId: sessionMatch?.[1] || null,
          utmSource: utmData.source,
          utmMedium: utmData.medium,
          utmCampaign: utmData.campaign,
          metadata: {
            age,
            interests,
            goal,
            source,
            topRecommendation: result.recommendedPrograms[0]?.slug || '',
            confidenceScore: result.confidenceScore,
          },
        },
      })
    } catch {
      // Don't fail the request if logging fails
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error('Matchmaking error:', error)
    return NextResponse.json(
      { خطا: 'خطا در پردازش درخواست مسیریابی' },
      { status: 500 }
    )
  }
}
