import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * POST /api/instructor/evaluations
 * Bulk create/update evaluations for a program.
 * Body: { skillProgramId, type, evaluations: [{ karAmuzId, score, status }] }
 * type: MIDTERM | FINAL | PROJECT | PRACTICAL
 * status: PASS | FAIL | PENDING
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Verify authentication
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده‌اید' }, { status: 401 });
    }

    // 2. Verify INSTRUCTOR role
    const adminUser = await db.adminUser.findUnique({
      where: { username: session.username },
      include: { role: true },
    });

    if (!adminUser || !adminUser.role || adminUser.role.name !== 'INSTRUCTOR') {
      return NextResponse.json({ error: 'شما دسترسی استاد ندارید' }, { status: 403 });
    }

    if (!adminUser.isActive) {
      return NextResponse.json({ error: 'حساب کاربری شما غیرفعال است' }, { status: 403 });
    }

    // 3. Parse body
    const body = await request.json();
    const { skillProgramId, type, evaluations } = body;

    if (!skillProgramId || !type || !Array.isArray(evaluations) || evaluations.length === 0) {
      return NextResponse.json(
        { error: 'شناسه برنامه، نوع ارزیابی و لیست نمرات الزامی است' },
        { status: 400 }
      );
    }

    const validTypes = ['MIDTERM', 'FINAL', 'PROJECT', 'PRACTICAL'];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { error: `نوع ارزیابی نامعتبر. مقادیر مجاز: ${validTypes.join(', ')}` },
        { status: 400 }
      );
    }

    // 4. Verify instructor owns the program
    const program = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
    });

    if (!program) {
      return NextResponse.json({ error: 'برنامه مهارتی یافت نشد' }, { status: 404 });
    }

    if (program.instructorName !== adminUser.displayName) {
      return NextResponse.json({ error: 'شما مجوز دسترسی به این برنامه را ندارید' }, { status: 403 });
    }

    // 5. Build title
    const typeLabels: Record<string, string> = {
      MIDTERM: 'میان‌ترم',
      FINAL: 'پایان‌ترم',
      PROJECT: 'پروژه',
      PRACTICAL: 'عملی',
    };
    const evaluationTitle = `${typeLabels[type] || type} - ${program.name}`;

    // 6. Process each evaluation
    const results = await Promise.all(
      evaluations.map(async (ev: { karAmuzId: string; score: number | null; status?: string; notes?: string }) => {
        if (!ev.karAmuzId) return null;

        // Determine effective score based on status if score is not provided
        let effectiveScore = ev.score;
        let maxScore = 20;

        if (ev.status === 'PASS' && effectiveScore === null) effectiveScore = 12;
        if (ev.status === 'FAIL' && effectiveScore === null) effectiveScore = 0;

        // Check for existing evaluation
        const existing = await db.evaluation.findFirst({
          where: {
            karAmuzId: ev.karAmuzId,
            skillProgramId,
            type,
          },
        });

        if (existing) {
          return db.evaluation.update({
            where: { id: existing.id },
            data: {
              title: evaluationTitle,
              score: effectiveScore !== null ? Number(effectiveScore) : null,
              maxScore,
              notes: ev.notes || null,
              date: new Date(),
            },
          });
        } else {
          return db.evaluation.create({
            data: {
              karAmuzId: ev.karAmuzId,
              skillProgramId,
              type,
              title: evaluationTitle,
              score: effectiveScore !== null ? Number(effectiveScore) : null,
              maxScore,
              notes: ev.notes || null,
              date: new Date(),
            },
          });
        }
      })
    );

    const savedResults = results.filter(Boolean);

    return NextResponse.json({
      message: 'نمرات با موفقیت ثبت شدند',
      count: savedResults.length,
    });
  } catch (error) {
    console.error('Instructor bulk evaluations error:', error);
    return NextResponse.json({ error: 'خطا در ثبت نمرات' }, { status: 500 });
  }
}