import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * GET /api/instructor/program/[skillProgramId]
 * Returns program details with students, sessions, evaluations.
 * - Verify auth and that instructor owns this program
 * - Include: enrolled KarAmuz list, sessions list, evaluation summary
 */
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ skillProgramId: string }> }
) {
  try {
    const { skillProgramId } = await params;

    // 1. Verify authentication
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده‌اید' }, { status: 401 });
    }

    // 2. Get the admin user and verify INSTRUCTOR role
    const adminUser = await db.adminUser.findUnique({
      where: { username: session.username },
      include: { role: true },
    });

    if (!adminUser || !adminUser.role || adminUser.role.name !== 'INSTRUCTOR') {
      return NextResponse.json({ error: 'شما دسترسی استاد ندارید' }, { status: 403 });
    }

    if (!adminUser.isActive) {
      return NextResponse.json({ error: 'حساب کاربری شما غیرفعال است' }, { status: 403 });
    }

    // 3. Get the program and verify ownership
    const program = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
    });

    if (!program) {
      return NextResponse.json({ error: 'برنامه مهارتی یافت نشد' }, { status: 404 });
    }

    if (program.instructorName !== adminUser.displayName) {
      return NextResponse.json({ error: 'شما مجوز دسترسی به این برنامه را ندارید' }, { status: 403 });
    }

    // 4. Get enrolled students
    const enrollments = await db.enrollment.findMany({
      where: { skillProgramId },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            phone: true,
            nationalId: true,
            studentCode: true,
            photo: true,
            status: true,
          },
        },
      },
      orderBy: { enrollmentDate: 'desc' },
    });

    // 5. Get sessions
    const sessions = await db.session.findMany({
      where: { skillProgramId },
      orderBy: { date: 'desc' },
      include: {
        _count: {
          select: { attendances: true },
        },
      },
    });

    // 6. Get evaluations
    const evaluations = await db.evaluation.findMany({
      where: { skillProgramId },
      orderBy: { date: 'desc' },
      include: {
        karAmuz: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            studentCode: true,
          },
        },
      },
    });

    // 7. Compute per-student stats
    const karAmuzIds = enrollments.map((e) => e.karAmuzId);
    const sessionIds = sessions.map((s) => s.id);

    // Attendance per student for this program
    const studentAttendanceMap: Record<string, { present: number; late: number; absent: number; excused: number; total: number }> = {};
    if (sessionIds.length > 0 && karAmuzIds.length > 0) {
      const attendances = await db.attendance.findMany({
        where: {
          sessionId: { in: sessionIds },
          karAmuzId: { in: karAmuzIds },
        },
      });

      for (const att of attendances) {
        if (!studentAttendanceMap[att.karAmuzId]) {
          studentAttendanceMap[att.karAmuzId] = { present: 0, late: 0, absent: 0, excused: 0, total: 0 };
        }
        studentAttendanceMap[att.karAmuzId].total++;
        if (att.status === 'PRESENT') studentAttendanceMap[att.karAmuzId].present++;
        else if (att.status === 'LATE') studentAttendanceMap[att.karAmuzId].late++;
        else if (att.status === 'ABSENT') studentAttendanceMap[att.karAmuzId].absent++;
        else if (att.status === 'EXCUSED') studentAttendanceMap[att.karAmuzId].excused++;
      }
    }

    // Evaluations per student
    const studentEvaluationMap: Record<string, Array<{ type: string; score: number | null; maxScore: number; title: string }>> = {};
    for (const ev of evaluations) {
      if (!studentEvaluationMap[ev.karAmuzId]) {
        studentEvaluationMap[ev.karAmuzId] = [];
      }
      studentEvaluationMap[ev.karAmuzId].push({
        type: ev.type,
        score: ev.score,
        maxScore: ev.maxScore,
        title: ev.title,
      });
    }

    // Build student list with stats
    const students = enrollments.map((enrollment) => {
      const attStats = studentAttendanceMap[enrollment.karAmuzId] || { present: 0, late: 0, absent: 0, excused: 0, total: 0 };
      const attendanceRate = attStats.total > 0
        ? Math.round(((attStats.present + attStats.late) / attStats.total) * 100 * 10) / 10
        : 0;
      const studentEvals = studentEvaluationMap[enrollment.karAmuzId] || [];
      const avgScore = studentEvals.length > 0 && studentEvals.some(e => e.score !== null)
        ? Math.round(
            (studentEvals
              .filter(e => e.score !== null)
              .reduce((sum, e) => sum + ((e.score! / e.maxScore) * 20), 0) /
            studentEvals.filter(e => e.score !== null).length) * 10
          ) / 10
        : null;

      return {
        enrollmentId: enrollment.id,
        enrollmentStatus: enrollment.status,
        enrollmentDate: enrollment.enrollmentDate,
        finalGrade: enrollment.finalGrade,
        isPassed: enrollment.isPassed,
        karAmuz: enrollment.karAmuz,
        attendanceStats: attStats,
        attendanceRate,
        evaluations: studentEvals,
        avgScore,
      };
    });

    // Evaluation summary by type
    const evaluationTypeSummary: Record<string, { count: number; avgScore: number }> = {};
    for (const ev of evaluations) {
      if (!evaluationTypeSummary[ev.type]) {
        evaluationTypeSummary[ev.type] = { count: 0, avgScore: 0 };
      }
      evaluationTypeSummary[ev.type].count++;
    }
    // Calculate averages
    for (const type of Object.keys(evaluationTypeSummary)) {
      const typeEvals = evaluations.filter((e) => e.type === type && e.score !== null);
      if (typeEvals.length > 0) {
        evaluationTypeSummary[type].avgScore = Math.round(
          (typeEvals.reduce((sum, e) => sum + ((e.score! / e.maxScore) * 20), 0) / typeEvals.length) * 10
        ) / 10;
      }
    }

    // Overall attendance stats
    const allAttendances = await db.attendance.findMany({
      where: {
        sessionId: { in: sessionIds },
        karAmuzId: { in: karAmuzIds },
      },
    });

    const overallAttendance = {
      total: allAttendances.length,
      present: allAttendances.filter((a) => a.status === 'PRESENT').length,
      late: allAttendances.filter((a) => a.status === 'LATE').length,
      absent: allAttendances.filter((a) => a.status === 'ABSENT').length,
      excused: allAttendances.filter((a) => a.status === 'EXCUSED').length,
    };

    return NextResponse.json({
      program: {
        id: program.id,
        code: program.code,
        name: program.name,
        description: program.description,
        totalHours: program.totalHours,
        theoryHours: program.theoryHours,
        practicalHours: program.practicalHours,
        minAttendancePct: program.minAttendancePct,
        price: program.price,
        capacity: program.capacity,
        isActive: program.isActive,
        cluster: program.cluster,
        instructorName: program.instructorName,
        level: program.level,
      },
      students,
      sessions: sessions.map((s) => ({
        id: s.id,
        date: s.date,
        startTime: s.startTime,
        endTime: s.endTime,
        title: s.title,
        type: s.type,
        instructorName: s.instructorName,
        attendanceCount: s._count.attendances,
      })),
      evaluations,
      evaluationTypeSummary,
      overallAttendance,
      totalEnrollments: enrollments.length,
      activeEnrollments: enrollments.filter((e) => e.status === 'ENROLLED').length,
    });
  } catch (error) {
    console.error('Instructor program detail error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات برنامه' }, { status: 500 });
  }
}
