import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * GET /api/instructor/dashboard
 * Returns instructor's dashboard data.
 * - Verify admin auth (admin_session cookie)
 * - Verify user has INSTRUCTOR role
 * - Get programs where instructorName matches displayName
 * - For each program: enrollment count, average attendance, average grade
 * - Recent attendance/evaluation records
 */
export async function GET(_request: NextRequest) {
  try {
    // 1. Verify authentication
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده‌اید' }, { status: 401 });
    }

    // 2. Get the admin user and verify INSTRUCTOR role
    const adminUser = await db.adminUser.findUnique({
      where: { username: session.username },
      include: { role: true },
    });

    if (!adminUser) {
      return NextResponse.json({ error: 'کاربر یافت نشد' }, { status: 404 });
    }

    if (!adminUser.role || adminUser.role.name !== 'INSTRUCTOR') {
      return NextResponse.json({ error: 'شما دسترسی استاد ندارید' }, { status: 403 });
    }

    if (!adminUser.isActive) {
      return NextResponse.json({ error: 'حساب کاربری شما غیرفعال است' }, { status: 403 });
    }

    const instructorName = adminUser.displayName;
    if (!instructorName) {
      return NextResponse.json({ error: 'نام نمایشی استاد تنظیم نشده است' }, { status: 400 });
    }

    // 3. Get programs where instructorName matches displayName
    const programs = await db.skillProgram.findMany({
      where: {
        instructorName,
        isActive: true,
      },
      include: {
        _count: {
          select: {
            enrollments: true,
            sessions: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // 4. Compute stats for each program
    const programStats = await Promise.all(
      programs.map(async (program) => {
        // Get enrollments with student info
        const enrollments = await db.enrollment.findMany({
          where: {
            skillProgramId: program.id,
            status: 'ENROLLED',
          },
          select: { id: true, karAmuzId: true },
        });

        const enrollmentCount = enrollments.length;

        // Get attendance stats for this program
        const sessions = await db.session.findMany({
          where: { skillProgramId: program.id },
          select: { id: true },
        });

        const sessionIds = sessions.map((s) => s.id);

        let attendanceStats = { total: 0, present: 0, late: 0, absent: 0, excused: 0 };
        let avgAttendance = 0;

        if (sessionIds.length > 0) {
          const attendances = await db.attendance.findMany({
            where: { sessionId: { in: sessionIds } },
            select: { status: true },
          });

          attendanceStats.total = attendances.length;
          attendanceStats.present = attendances.filter((a) => a.status === 'PRESENT').length;
          attendanceStats.late = attendances.filter((a) => a.status === 'LATE').length;
          attendanceStats.absent = attendances.filter((a) => a.status === 'ABSENT').length;
          attendanceStats.excused = attendances.filter((a) => a.status === 'EXCUSED').length;

          if (attendances.length > 0) {
            avgAttendance = ((attendanceStats.present + attendanceStats.late) / attendances.length) * 100;
          }
        }

        // Get evaluation stats
        const evaluations = await db.evaluation.findMany({
          where: { skillProgramId: program.id },
          select: { score: true, maxScore: true },
        });

        let avgGrade = 0;
        const gradedEvals = evaluations.filter((e) => e.score !== null);
        if (gradedEvals.length > 0) {
          const totalNormalized = gradedEvals.reduce((sum, e) => {
            return sum + ((e.score! / e.maxScore) * 100);
          }, 0);
          avgGrade = totalNormalized / gradedEvals.length;
        }

        return {
          id: program.id,
          name: program.name,
          code: program.code,
          description: program.description,
          totalHours: program.totalHours,
          theoryHours: program.theoryHours,
          practicalHours: program.practicalHours,
          level: program.level,
          cluster: program.cluster,
          capacity: program.capacity,
          enrollmentCount,
          sessionCount: sessions.length,
          attendanceStats,
          avgAttendance: Math.round(avgAttendance * 10) / 10,
          avgGrade: Math.round(avgGrade * 10) / 10,
          evaluationCount: evaluations.length,
          _count: program._count,
        };
      })
    );

    // 5. Get recent activity
    // Recent attendances from instructor's programs
    const programIds = programs.map((p) => p.id);
    const programSessionIds = await db.session.findMany({
      where: { skillProgramId: { in: programIds } },
      select: { id: true },
    });
    const allSessionIds = programSessionIds.map((s) => s.id);

    const recentAttendances = allSessionIds.length > 0
      ? await db.attendance.findMany({
          where: { sessionId: { in: allSessionIds } },
          orderBy: { createdAt: 'desc' },
          take: 10,
          include: {
            karAmuz: {
              select: { id: true, firstName: true, lastName: true, studentCode: true },
            },
            session: {
              select: {
                id: true,
                date: true,
                title: true,
                startTime: true,
                endTime: true,
                skillProgram: { select: { id: true, name: true } },
              },
            },
          },
        })
      : [];

    const recentEvaluations = programIds.length > 0
      ? await db.evaluation.findMany({
          where: { skillProgramId: { in: programIds } },
          orderBy: { createdAt: 'desc' },
          take: 10,
          include: {
            karAmuz: {
              select: { id: true, firstName: true, lastName: true, studentCode: true },
            },
          },
        })
      : [];

    // 6. Overall stats
    const totalStudents = programStats.reduce((sum, p) => sum + p.enrollmentCount, 0);
    const overallAvgAttendance = programStats.length > 0
      ? Math.round((programStats.reduce((sum, p) => sum + p.avgAttendance, 0) / programStats.length) * 10) / 10
      : 0;
    const overallAvgGrade = programStats.length > 0
      ? Math.round((programStats.reduce((sum, p) => sum + p.avgGrade, 0) / programStats.length) * 10) / 10
      : 0;

    return NextResponse.json({
      instructor: {
        id: adminUser.id,
        username: adminUser.username,
        displayName: adminUser.displayName,
      },
      stats: {
        totalPrograms: programs.length,
        totalStudents,
        avgAttendance: overallAvgAttendance,
        avgGrade: overallAvgGrade,
      },
      programs: programStats,
      recentAttendances,
      recentEvaluations,
    });
  } catch (error) {
    console.error('Instructor dashboard error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات داشبورد' }, { status: 500 });
  }
}
