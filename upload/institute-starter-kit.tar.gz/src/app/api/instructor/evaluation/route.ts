import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * POST /api/instructor/evaluation
 * Create/update evaluation.
 * Body: { karAmuzId, skillProgramId, type, score, maxScore, note }
 * type: MIDTERM | FINAL | PROJECT | PRACTICAL
 * Upsert evaluation record
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Verify authentication
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده‌اید' }, { status: 401 });
    }

    // 2. Get the admin user and verify INSTRUCTOR role
    const adminUser = await db.adminUser.findUnique({
      where: { username: session.username },
      include: { role: true },
    });

    if (!adminUser || !adminUser.role || adminUser.role.name !== 'INSTRUCTOR') {
      return NextResponse.json({ error: 'شما دسترسی استاد ندارید' }, { status: 403 });
    }

    if (!adminUser.isActive) {
      return NextResponse.json({ error: 'حساب کاربری شما غیرفعال است' }, { status: 403 });
    }

    // 3. Parse request body
    const body = await request.json();
    const { karAmuzId, skillProgramId, type, score, maxScore, note, title } = body;

    // 4. Validate required fields
    if (!karAmuzId || !skillProgramId || !type) {
      return NextResponse.json(
        { error: 'شناسه کارآموز، شناسه برنامه مهارتی و نوع ارزیابی الزامی است' },
        { status: 400 }
      );
    }

    // 5. Validate type
    const validTypes = ['MIDTERM', 'FINAL', 'PROJECT', 'PRACTICAL'];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { error: `نوع ارزیابی نامعتبر. مقادیر مجاز: ${validTypes.join(', ')}` },
        { status: 400 }
      );
    }

    // 6. Verify instructor owns the program
    const program = await db.skillProgram.findUnique({
      where: { id: skillProgramId },
    });

    if (!program) {
      return NextResponse.json({ error: 'برنامه مهارتی یافت نشد' }, { status: 404 });
    }

    if (program.instructorName !== adminUser.displayName) {
      return NextResponse.json({ error: 'شما مجوز دسترسی به این برنامه را ندارید' }, { status: 403 });
    }

    // 7. Verify karAmuz exists and is enrolled
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: karAmuzId },
    });

    if (!karAmuz) {
      return NextResponse.json({ error: 'کارآموز یافت نشد' }, { status: 404 });
    }

    const enrollment = await db.enrollment.findUnique({
      where: {
        karAmuzId_skillProgramId: {
          karAmuzId,
          skillProgramId,
        },
      },
    });

    if (!enrollment) {
      return NextResponse.json(
        { error: 'کارآموز در این برنامه ثبت‌نام نشده است' },
        { status: 400 }
      );
    }

    // 8. Validate score
    const effectiveMaxScore = maxScore !== undefined ? Number(maxScore) : 20;
    if (score !== undefined && Number(score) > effectiveMaxScore) {
      return NextResponse.json(
        { error: `نمره (${score}) نمی‌تواند بیشتر از نمره کل (${effectiveMaxScore}) باشد` },
        { status: 400 }
      );
    }

    // 9. Determine the title
    const typeLabels: Record<string, string> = {
      MIDTERM: 'میان‌ترم',
      FINAL: 'پایان‌ترم',
      PROJECT: 'پروژه',
      PRACTICAL: 'عملی',
    };
    const evaluationTitle = title || `${typeLabels[type] || type} - ${program.name}`;

    // 10. Check if evaluation already exists for this student+program+type combination
    const existingEvaluation = await db.evaluation.findFirst({
      where: {
        karAmuzId,
        skillProgramId,
        type,
      },
    });

    let evaluation;
    if (existingEvaluation) {
      // Update existing
      evaluation = await db.evaluation.update({
        where: { id: existingEvaluation.id },
        data: {
          title: evaluationTitle,
          score: score !== undefined ? Number(score) : null,
          maxScore: effectiveMaxScore,
          notes: note || null,
          date: new Date(),
        },
        include: {
          karAmuz: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              studentCode: true,
            },
          },
        },
      });
    } else {
      // Create new
      evaluation = await db.evaluation.create({
        data: {
          karAmuzId,
          skillProgramId,
          type,
          title: evaluationTitle,
          score: score !== undefined ? Number(score) : null,
          maxScore: effectiveMaxScore,
          date: new Date(),
          notes: note || null,
        },
        include: {
          karAmuz: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              studentCode: true,
            },
          },
        },
      });
    }

    return NextResponse.json({
      message: 'ارزیابی با موفقیت ثبت شد',
      data: evaluation,
    });
  } catch (error) {
    console.error('Instructor evaluation error:', error);
    return NextResponse.json({ error: 'خطا در ثبت ارزیابی' }, { status: 500 });
  }
}
