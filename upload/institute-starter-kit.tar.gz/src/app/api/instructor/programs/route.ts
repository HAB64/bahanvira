import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * GET /api/instructor/programs
 * Returns all programs the instructor manages, each with its enrolled KarAmuz students.
 */
export async function GET(_request: NextRequest) {
  try {
    // 1. Verify authentication
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده‌اید' }, { status: 401 });
    }

    // 2. Get the admin user and verify INSTRUCTOR role
    const adminUser = await db.adminUser.findUnique({
      where: { username: session.username },
      include: { role: true },
    });

    if (!adminUser || !adminUser.role || adminUser.role.name !== 'INSTRUCTOR') {
      return NextResponse.json({ error: 'شما دسترسی استاد ندارید' }, { status: 403 });
    }

    if (!adminUser.isActive) {
      return NextResponse.json({ error: 'حساب کاربری شما غیرفعال است' }, { status: 403 });
    }

    const instructorName = adminUser.displayName;
    if (!instructorName) {
      return NextResponse.json({ error: 'نام نمایشی استاد تنظیم نشده است' }, { status: 400 });
    }

    // 3. Get programs with enrolled students
    const programs = await db.skillProgram.findMany({
      where: {
        instructorName,
        isActive: true,
      },
      include: {
        enrollments: {
          where: { status: 'ENROLLED' },
          include: {
            karAmuz: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                studentCode: true,
                phone: true,
              },
            },
          },
          orderBy: { enrollmentDate: 'desc' },
        },
        sessions: {
          orderBy: { date: 'desc' },
          select: {
            id: true,
            date: true,
            title: true,
            startTime: true,
            endTime: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // 4. Format response
    const formattedPrograms = programs.map((program) => ({
      id: program.id,
      name: program.name,
      code: program.code,
      description: program.description,
      totalHours: program.totalHours,
      theoryHours: program.theoryHours,
      practicalHours: program.practicalHours,
      level: program.level,
      cluster: program.cluster,
      capacity: program.capacity,
      students: program.enrollments.map((e) => ({
        id: e.karAmuz.id,
        firstName: e.karAmuz.firstName,
        lastName: e.karAmuz.lastName,
        studentCode: e.karAmuz.studentCode,
        phone: e.karAmuz.phone,
        enrollmentId: e.id,
      })),
      sessions: program.sessions,
    }));

    return NextResponse.json({ programs: formattedPrograms });
  } catch (error) {
    console.error('Instructor programs error:', error);
    return NextResponse.json({ error: 'خطا در دریافت لیست برنامه‌ها' }, { status: 500 });
  }
}