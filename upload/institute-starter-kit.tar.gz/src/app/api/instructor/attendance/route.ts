import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getAdminSession } from '@/lib/admin-auth';

/**
 * GET /api/instructor/attendance?sessionId=xxx
 * Fetch existing attendance records for a specific session.
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده‌اید' }, { status: 401 });
    }

    const adminUser = await db.adminUser.findUnique({
      where: { username: session.username },
      include: { role: true },
    });

    if (!adminUser || !adminUser.role || adminUser.role.name !== 'INSTRUCTOR') {
      return NextResponse.json({ error: 'شما دسترسی استاد ندارید' }, { status: 403 });
    }

    const sessionId = request.nextUrl.searchParams.get('sessionId');
    if (!sessionId) {
      return NextResponse.json({ error: 'شناسه جلسه الزامی است' }, { status: 400 });
    }

    // Verify instructor owns the session's program
    const sessionData = await db.session.findUnique({
      where: { id: sessionId },
      include: { skillProgram: true },
    });

    if (!sessionData) {
      return NextResponse.json({ error: 'جلسه یافت نشد' }, { status: 404 });
    }

    if (sessionData.skillProgram.instructorName !== adminUser.displayName) {
      return NextResponse.json({ error: 'شما مجوز دسترسی به این جلسه را ندارید' }, { status: 403 });
    }

    const attendances = await db.attendance.findMany({
      where: { sessionId },
      include: {
        karAmuz: {
          select: { id: true, firstName: true, lastName: true, studentCode: true },
        },
      },
    });

    return NextResponse.json({
      sessionId,
      date: sessionData.date,
      title: sessionData.title,
      attendances: attendances.map((a) => ({
        id: a.id,
        karAmuzId: a.karAmuzId,
        status: a.status,
        hours: a.hours,
        notes: a.notes,
        karAmuz: a.karAmuz,
      })),
    });
  } catch (error) {
    console.error('Instructor attendance GET error:', error);
    return NextResponse.json({ error: 'خطا در دریافت حضور و غیاب' }, { status: 500 });
  }
}

/**
 * POST /api/instructor/attendance
 * Take attendance for a session.
 * Body: { sessionId, records: [{ karAmuzId, status }] }
 * status: PRESENT | ABSENT | LATE | EXCUSED
 * Upsert attendance records
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Verify authentication
    const session = await getAdminSession();
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت نشده‌اید' }, { status: 401 });
    }

    // 2. Get the admin user and verify INSTRUCTOR role
    const adminUser = await db.adminUser.findUnique({
      where: { username: session.username },
      include: { role: true },
    });

    if (!adminUser || !adminUser.role || adminUser.role.name !== 'INSTRUCTOR') {
      return NextResponse.json({ error: 'شما دسترسی استاد ندارید' }, { status: 403 });
    }

    if (!adminUser.isActive) {
      return NextResponse.json({ error: 'حساب کاربری شما غیرفعال است' }, { status: 403 });
    }

    // 3. Parse request body
    const body = await request.json();
    const { sessionId, records } = body;

    if (!sessionId || !Array.isArray(records) || records.length === 0) {
      return NextResponse.json(
        { error: 'شناسه جلسه و لیست حضور و غیاب الزامی است' },
        { status: 400 }
      );
    }

    // 4. Validate the session exists and instructor owns the program
    const sessionData = await db.session.findUnique({
      where: { id: sessionId },
      include: { skillProgram: true },
    });

    if (!sessionData) {
      return NextResponse.json({ error: 'جلسه یافت نشد' }, { status: 404 });
    }

    if (sessionData.skillProgram.instructorName !== adminUser.displayName) {
      return NextResponse.json({ error: 'شما مجوز دسترسی به این جلسه را ندارید' }, { status: 403 });
    }

    // 5. Validate status values
    const validStatuses = ['PRESENT', 'ABSENT', 'LATE', 'EXCUSED'];
    for (const record of records) {
      if (!record.karAmuzId || !record.status) {
        return NextResponse.json(
          { error: 'هر رکورد باید شامل شناسه کارآموز و وضعیت باشد' },
          { status: 400 }
        );
      }
      if (!validStatuses.includes(record.status)) {
        return NextResponse.json(
          { error: `وضعیت نامعتبر: ${record.status}. مقادیر مجاز: ${validStatuses.join(', ')}` },
          { status: 400 }
        );
      }
    }

    // 6. Validate that all karAmuzIds are enrolled in the program
    const karAmuzIds = records.map((r: { karAmuzId: string }) => r.karAmuzId);
    const enrollments = await db.enrollment.findMany({
      where: {
        karAmuzId: { in: karAmuzIds },
        skillProgramId: sessionData.skillProgramId,
        status: 'ENROLLED',
      },
    });

    const enrolledIds = new Set(enrollments.map((e) => e.karAmuzId));
    const notEnrolled = karAmuzIds.filter((id: string) => !enrolledIds.has(id));
    if (notEnrolled.length > 0) {
      return NextResponse.json(
        { error: 'برخی کارآموزان در این برنامه ثبت‌نام نشده‌اند' },
        { status: 400 }
      );
    }

    // 7. Upsert attendance records
    const results = await Promise.all(
      records.map(async (record: { karAmuzId: string; status: string; hours?: number; notes?: string }) => {
        const hours = record.hours !== undefined ? Number(record.hours) : (record.status === 'PRESENT' ? 2 : 0);
        return db.attendance.upsert({
          where: {
            karAmuzId_sessionId: {
              karAmuzId: record.karAmuzId,
              sessionId,
            },
          },
          update: {
            status: record.status,
            hours,
            notes: record.notes || null,
          },
          create: {
            karAmuzId: record.karAmuzId,
            sessionId,
            status: record.status,
            hours,
            notes: record.notes || null,
          },
          include: {
            karAmuz: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                studentCode: true,
              },
            },
          },
        });
      })
    );

    return NextResponse.json({
      message: 'حضور و غیاب با موفقیت ثبت شد',
      count: results.length,
      data: results,
    });
  } catch (error) {
    console.error('Instructor attendance error:', error);
    return NextResponse.json({ error: 'خطا در ثبت حضور و غیاب' }, { status: 500 });
  }
}
