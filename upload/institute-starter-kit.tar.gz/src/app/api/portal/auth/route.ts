import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, createPortalToken } from '@/lib/portal-auth';

/**
 * Normalize phone: handle Persian/Arabic digits, +98/98 prefixes
 */
function normalizePhone(raw: string): string {
  const persianDigits = '۰۱۲۳۴۵۶۷۸۹';
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  let s = raw.trim();
  // Convert Persian/Arabic digits to Latin
  for (let i = 0; i < 10; i++) {
    s = s.replaceAll(persianDigits[i], String(i));
    s = s.replaceAll(arabicDigits[i], String(i));
  }
  // Remove spaces, dashes, parens
  s = s.replace(/[\s\-\(\)]/g, '');
  // Remove +98 or 98 prefix
  if (s.startsWith('+98')) s = '0' + s.slice(3);
  else if (s.startsWith('98') && s.length >= 11) s = '0' + s.slice(2);
  return s;
}

/**
 * POST /api/portal/auth — Portal login
 * 
 * Logic:
 * 1. Try normal CustomerPortalUser login
 * 2. If fails and username === password, treat both as phone number
 * 3. Search KarAmuz and Lead tables for the phone
 * 4. Auto-create CustomerPortalUser if found
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body;

    if (!username || !password) {
      return NextResponse.json({ error: 'نام کاربری و رمز عبور الزامی است' }, { status: 400 });
    }

    const passwordHash = hashPassword(password);

    // ── Step 1: Try normal login ──
    const user = await db.customerPortalUser.findUnique({
      where: { username },
      include: {
        lead: { select: { id: true, name: true, phone: true, email: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true, email: true } },
      },
    });

    if (user && user.passwordHash === passwordHash) {
      if (!user.isActive) {
        return NextResponse.json({ error: 'حساب کاربری غیرفعال است' }, { status: 403 });
      }

      await db.customerPortalUser.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      const token = createPortalToken(user.id);
      const { passwordHash: _, ...safeUser } = user;
      const displayName = safeUser.karAmuz
        ? `${safeUser.karAmuz.firstName} ${safeUser.karAmuz.lastName}`
        : safeUser.lead?.name || safeUser.username;

      return NextResponse.json({
        message: 'ورود موفقیت‌آمیز',
        data: { ...safeUser, displayName },
        token,
      });
    }

    // ── Step 2: If user not found OR password wrong, try phone-as-credentials ──
    // Only proceed if username and password are the same (phone login mode)
    if (username.trim() !== password.trim()) {
      return NextResponse.json({ error: 'نام کاربری یا رمز عبور اشتباه است' }, { status: 401 });
    }

    const normalizedPhone = normalizePhone(username);
    const last10 = normalizedPhone.length >= 10 ? normalizedPhone.slice(-10) : normalizedPhone;

    // Search KarAmuz with multiple phone format variants
    let karAmuz = await db.karAmuz.findFirst({
      where: { phone: normalizedPhone },
    });

    if (!karAmuz) {
      // Try with +98 prefix
      karAmuz = await db.karAmuz.findFirst({
        where: { phone: '+98' + normalizedPhone.slice(1) },
      });
    }

    if (!karAmuz) {
      // Try with 98 prefix (no +)
      karAmuz = await db.karAmuz.findFirst({
        where: { phone: '98' + normalizedPhone.slice(1) },
      });
    }

    if (!karAmuz) {
      // endsWith fallback
      karAmuz = await db.karAmuz.findFirst({
        where: { phone: { endsWith: last10 } },
      });
    }

    if (karAmuz) {
      // Check if portal user already exists for this karAmuz
      let portalUser = await db.customerPortalUser.findUnique({
        where: { karAmuzId: karAmuz.id },
      });

      if (!portalUser) {
        // Auto-create portal user
        portalUser = await db.customerPortalUser.create({
          data: {
            username: normalizedPhone,
            passwordHash,
            karAmuzId: karAmuz.id,
            isActive: true,
          },
        });
      } else {
        // Update password to match the new format
        await db.customerPortalUser.update({
          where: { id: portalUser.id },
          data: { passwordHash, username: normalizedPhone },
        });
      }

      await db.customerPortalUser.update({
        where: { id: portalUser.id },
        data: { lastLoginAt: new Date() },
      });

      const token = createPortalToken(portalUser.id);
      const fullUser = await db.customerPortalUser.findUnique({
        where: { id: portalUser.id },
        include: {
          karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true, email: true } },
        },
      });

      const { passwordHash: _, ...safeUser } = fullUser!;
      const displayName = safeUser.karAmuz
        ? `${safeUser.karAmuz.firstName} ${safeUser.karAmuz.lastName}`
        : safeUser.username;

      return NextResponse.json({
        message: 'ورود موفقیت‌آمیز',
        data: { ...safeUser, displayName },
        token,
      });
    }

    // Search Lead table with same logic
    let lead = await db.lead.findFirst({
      where: { phone: normalizedPhone },
    });

    if (!lead) {
      lead = await db.lead.findFirst({
        where: { phone: { endsWith: last10 } },
      });
    }

    if (lead) {
      let portalUser = await db.customerPortalUser.findUnique({
        where: { leadId: lead.id },
      });

      if (!portalUser) {
        portalUser = await db.customerPortalUser.create({
          data: {
            username: normalizedPhone,
            passwordHash,
            leadId: lead.id,
            isActive: true,
          },
        });
      } else {
        await db.customerPortalUser.update({
          where: { id: portalUser.id },
          data: { passwordHash, username: normalizedPhone },
        });
      }

      await db.customerPortalUser.update({
        where: { id: portalUser.id },
        data: { lastLoginAt: new Date() },
      });

      const token = createPortalToken(portalUser.id);
      const fullUser = await db.customerPortalUser.findUnique({
        where: { id: portalUser.id },
        include: {
          lead: { select: { id: true, name: true, phone: true, email: true } },
        },
      });

      const { passwordHash: _, ...safeUser } = fullUser!;
      const displayName = safeUser.lead?.name || safeUser.username;

      return NextResponse.json({
        message: 'ورود موفقیت‌آمیز',
        data: { ...safeUser, displayName },
        token,
      });
    }

    // Not found anywhere
    return NextResponse.json({ error: 'شماره همراه در سیستم ثبت نشده است' }, { status: 404 });

  } catch (error) {
    console.error('Portal auth error:', error);
    return NextResponse.json({ error: 'خطا در ورود' }, { status: 500 });
  }
}

/**
 * GET /api/portal/auth — Check if portal session is valid
 */
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader) {
      return NextResponse.json({ authenticated: false }, { status: 401 });
    }

    const { verifyPortalToken } = await import('@/lib/portal-auth');
    const token = authHeader.replace('Bearer ', '');
    const decoded = verifyPortalToken(token);

    if (!decoded) {
      return NextResponse.json({ authenticated: false }, { status: 401 });
    }

    const user = await db.customerPortalUser.findUnique({
      where: { id: decoded.userId },
      include: {
        lead: { select: { id: true, name: true, phone: true, email: true } },
        karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true, email: true } },
      },
    });

    if (!user || !user.isActive) {
      return NextResponse.json({ authenticated: false }, { status: 401 });
    }

    const { passwordHash: _, ...safeUser } = user;
    const displayName = safeUser.karAmuz
      ? `${safeUser.karAmuz.firstName} ${safeUser.karAmuz.lastName}`
      : safeUser.lead?.name || safeUser.username;

    return NextResponse.json({
      authenticated: true,
      data: { ...safeUser, displayName },
    });
  } catch {
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }
}