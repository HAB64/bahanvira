import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/dashboard — Customer portal dashboard data
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    // Build dashboard data
    const dashboard: Record<string, unknown> = {
      user: {
        id: user.id,
        username: user.username,
        name: user.karAmuz
          ? `${user.karAmuz.firstName} ${user.karAmuz.lastName}`
          : user.lead?.name || '',
        phone: user.karAmuz?.phone || user.lead?.phone || '',
      },
    };

    if (user.karAmuzId) {
      const ka = await db.karAmuz.findUnique({
        where: { id: user.karAmuzId },
        include: {
          enrollments: {
            include: { skillProgram: { select: { id: true, name: true, totalHours: true, price: true } } },
          },
          certificates: {
            include: { skillProgram: { select: { id: true, name: true } } },
          },
          payments: { where: { status: 'PAID' } },
          attendances: { take: 10, orderBy: { createdAt: 'desc' } },
          invoices: {
            orderBy: { createdAt: 'desc' },
            take: 5,
          },
          tickets: {
            orderBy: { createdAt: 'desc' },
            take: 5,
            include: {
              _count: { select: { responses: true } },
            },
          },
        },
      });

      if (ka) {
        dashboard.enrollments = ka.enrollments.map(e => ({
          id: e.id,
          status: e.status,
          programName: e.skillProgram.name,
          totalHours: e.skillProgram.totalHours,
          enrollmentDate: e.enrollmentDate,
          completionDate: e.completionDate,
          finalGrade: e.finalGrade,
        }));

        dashboard.certificates = ka.certificates.map(c => ({
          id: c.id,
          certificateNo: c.certificateNo,
          status: c.status,
          programName: c.skillProgram.name,
          issueDate: c.issueDate,
        }));

        dashboard.payments = ka.payments.map(p => ({
          id: p.id,
          amount: p.amount,
          type: p.type,
          status: p.status,
          paidAt: p.paidAt,
        }));

        // Upcoming sessions
        const upcomingSessions = await db.session.findMany({
          where: {
            skillProgramId: { in: ka.enrollments.filter(e => e.status === 'ENROLLED').map(e => e.skillProgramId) },
            date: { gte: new Date() },
          },
          orderBy: { date: 'asc' },
          take: 5,
          include: { skillProgram: { select: { name: true } } },
        });

        dashboard.upcomingSessions = upcomingSessions.map(s => ({
          id: s.id,
          title: s.title || s.skillProgram.name,
          date: s.date,
          startTime: s.startTime,
          endTime: s.endTime,
          type: s.type,
          programName: s.skillProgram.name,
        }));

        // Attendance summary
        const totalAttendances = ka.attendances.length;
        const presentCount = ka.attendances.filter(a => a.status === 'PRESENT').length;
        dashboard.attendanceRate = totalAttendances > 0 ? Math.round(presentCount / totalAttendances * 100) : 0;

        // Recent invoices
        dashboard.recentInvoices = ka.invoices.map(inv => ({
          id: inv.id,
          invoiceNumber: inv.invoiceNumber,
          totalAmount: inv.totalAmount,
          status: inv.status,
          dueDate: inv.dueDate,
          createdAt: inv.createdAt,
        }));

        // Open tickets count
        const openTickets = await db.ticket.count({
          where: {
            karAmuzId: user.karAmuzId,
            status: { in: ['OPEN', 'IN_PROGRESS', 'WAITING_CUSTOMER'] },
          },
        });

        dashboard.recentTickets = ka.tickets.map(t => ({
          id: t.id,
          subject: t.subject,
          status: t.status,
          priority: t.priority,
          category: t.category,
          responseCount: t._count.responses,
          createdAt: t.createdAt,
        }));

        dashboard.openTicketsCount = openTickets;
        dashboard.openInvoicesCount = await db.invoice.count({
          where: {
            karAmuzId: user.karAmuzId,
            status: { in: ['DRAFT', 'SENT', 'PARTIALLY_PAID'] },
          },
        });
      }
    } else if (user.leadId) {
      // Lead-based user
      const lead = await db.lead.findUnique({
        where: { id: user.leadId },
        include: {
          invoices: {
            orderBy: { createdAt: 'desc' },
            take: 5,
          },
          tickets: {
            orderBy: { createdAt: 'desc' },
            take: 5,
            include: {
              _count: { select: { responses: true } },
            },
          },
          payments: { where: { status: 'PAID' } },
        },
      });

      if (lead) {
        dashboard.recentInvoices = lead.invoices.map(inv => ({
          id: inv.id,
          invoiceNumber: inv.invoiceNumber,
          totalAmount: inv.totalAmount,
          status: inv.status,
          dueDate: inv.dueDate,
          createdAt: inv.createdAt,
        }));

        dashboard.recentTickets = lead.tickets.map(t => ({
          id: t.id,
          subject: t.subject,
          status: t.status,
          priority: t.priority,
          category: t.category,
          responseCount: t._count.responses,
          createdAt: t.createdAt,
        }));

        dashboard.payments = lead.payments.map(p => ({
          id: p.id,
          amount: p.amount,
          type: p.type,
          status: p.status,
          paidAt: p.paidAt,
        }));

        dashboard.openTicketsCount = await db.ticket.count({
          where: {
            leadId: user.leadId,
            status: { in: ['OPEN', 'IN_PROGRESS', 'WAITING_CUSTOMER'] },
          },
        });

        dashboard.openInvoicesCount = await db.invoice.count({
          where: {
            leadId: user.leadId,
            status: { in: ['DRAFT', 'SENT', 'PARTIALLY_PAID'] },
          },
        });

        dashboard.enrollments = [];
      }
    }

    return NextResponse.json({
      data: dashboard,
    });
  } catch (error) {
    console.error('Portal dashboard error:', error);
    return NextResponse.json({ error: 'خطا در دریافت داده‌های داشبورد' }, { status: 500 });
  }
}
