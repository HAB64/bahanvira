import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/lms/lessons?skillProgramId=xxx — List lessons for an enrolled SkillProgram
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getPortalUserFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { karAmuzId } = session;
    const { searchParams } = new URL(request.url);
    const skillProgramId = searchParams.get('skillProgramId');

    if (!skillProgramId) {
      return NextResponse.json(
        { error: 'شناسه برنامه مهارت الزامی است' },
        { status: 400 }
      );
    }

    // Check if student has an active enrollment for this program
    const enrollment = await db.enrollment.findFirst({
      where: {
        karAmuzId,
        skillProgramId,
        status: { in: ['ENROLLED', 'COMPLETED'] },
      },
    });

    if (!enrollment) {
      return NextResponse.json(
        { error: 'شما در این دوره ثبت‌نام نکرده‌اید' },
        { status: 403 }
      );
    }

    // Fetch only published lessons, ordered by their display order
    const lessons = await db.lesson.findMany({
      where: {
        skillProgramId,
        isPublished: true,
      },
      orderBy: { order: 'asc' },
      select: {
        id: true,
        title: true,
        description: true,
        type: true,
        order: true,
        isFree: true,
        estimatedMinutes: true,
        videoDuration: true,
        createdAt: true,
      },
    });

    // Fetch progress for all lessons of this enrollment in one query
    const progressRecords = await db.lessonProgress.findMany({
      where: { enrollmentId: enrollment.id },
      select: {
        lessonId: true,
        status: true,
        progressPercent: true,
        timeSpent: true,
        lastPosition: true,
        completedAt: true,
        updatedAt: true,
      },
    });

    // Create a map for quick lookup
    const progressMap = new Map(progressRecords.map((p) => [p.lessonId, p]));

    // Merge lesson data with progress
    const lessonsWithProgress = lessons.map((lesson) => {
      const progress = progressMap.get(lesson.id);

      return {
        id: lesson.id,
        title: lesson.title,
        description: lesson.description,
        type: lesson.type,
        order: lesson.order,
        isFree: lesson.isFree,
        estimatedMinutes: lesson.estimatedMinutes,
        videoDuration: lesson.videoDuration,
        createdAt: lesson.createdAt,
        progress: progress
          ? {
              status: progress.status,
              progressPercent: progress.progressPercent,
              timeSpent: progress.timeSpent,
              lastPosition: progress.lastPosition,
              completedAt: progress.completedAt,
              updatedAt: progress.updatedAt,
            }
          : {
              status: 'NOT_STARTED',
              progressPercent: 0,
              timeSpent: 0,
              lastPosition: 0,
              completedAt: null,
              updatedAt: null,
            },
      };
    });

    return NextResponse.json({
      data: {
        skillProgramId,
        enrollmentId: enrollment.id,
        enrollmentStatus: enrollment.status,
        lessons: lessonsWithProgress,
      },
    });
  } catch (error) {
    console.error('Portal LMS lessons error:', error);
    return NextResponse.json({ error: 'خطا در دریافت دروس' }, { status: 500 });
  }
}
