import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/lms/courses — List enrolled courses for the authenticated student
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getPortalUserFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { karAmuzId } = session;

    // Fetch all enrollments for this student with program, lessons, and progress
    const enrollments = await db.enrollment.findMany({
      where: { karAmuzId },
      include: {
        skillProgram: {
          select: {
            id: true,
            name: true,
            instructorName: true,
            level: true,
            totalHours: true,
            description: true,
          },
        },
        lessonProgress: {
          include: {
            lesson: {
              select: { id: true, isPublished: true },
            },
          },
        },
      },
      orderBy: { enrollmentDate: 'desc' },
    });

    // For each enrollment, compute progress
    const courses = await Promise.all(
      enrollments.map(async (enrollment) => {
        // Get total and published lesson counts for the program
        const [totalLessons, publishedLessons] = await Promise.all([
          db.lesson.count({ where: { skillProgramId: enrollment.skillProgramId } }),
          db.lesson.count({ where: { skillProgramId: enrollment.skillProgramId, isPublished: true } }),
        ]);

        // Count completed lessons from progress records
        const completedLessons = enrollment.lessonProgress.filter(
          (lp) => lp.status === 'COMPLETED'
        ).length;

        // Overall completion percent (based on total published lessons)
        const overallCompletionPercent =
          publishedLessons > 0 ? Math.round((completedLessons / publishedLessons) * 100) : 0;

        return {
          enrollmentId: enrollment.id,
          skillProgramId: enrollment.skillProgramId,
          program: {
            id: enrollment.skillProgram.id,
            name: enrollment.skillProgram.name,
            instructor: enrollment.skillProgram.instructorName,
            level: enrollment.skillProgram.level,
            totalHours: enrollment.skillProgram.totalHours,
            description: enrollment.skillProgram.description,
          },
          lessonCount: totalLessons,
          publishedLessonCount: publishedLessons,
          progress: {
            completedLessons,
            totalLessons: publishedLessons,
            overallCompletionPercent,
          },
          enrollmentStatus: enrollment.status,
          enrollmentDate: enrollment.enrollmentDate,
          completionDate: enrollment.completionDate,
        };
      })
    );

    return NextResponse.json({ data: courses });
  } catch (error) {
    console.error('Portal LMS courses error:', error);
    return NextResponse.json({ error: 'خطا در دریافت دوره‌ها' }, { status: 500 });
  }
}
