import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/lms/lesson/[lessonId] — Get full lesson content
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ lessonId: string }> }
) {
  try {
    const session = await getPortalUserFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { karAmuzId } = session;
    const { lessonId } = await params;

    // Fetch the lesson
    const lesson = await db.lesson.findUnique({
      where: { id: lessonId },
      include: {
        skillProgram: {
          select: {
            id: true,
            name: true,
            instructorName: true,
            level: true,
          },
        },
      },
    });

    if (!lesson) {
      return NextResponse.json({ error: 'درس یافت نشد' }, { status: 404 });
    }

    // Access control: lesson must be published OR isFree
    if (!lesson.isPublished && !lesson.isFree) {
      return NextResponse.json({ error: 'این درس هنوز منتشر نشده است' }, { status: 403 });
    }

    // Check if the student has an active enrollment for this lesson's program
    const enrollment = await db.enrollment.findFirst({
      where: {
        karAmuzId,
        skillProgramId: lesson.skillProgramId,
        status: { in: ['ENROLLED', 'COMPLETED'] },
      },
    });

    // If lesson is not free, enrollment is required
    if (!lesson.isFree && !enrollment) {
      return NextResponse.json(
        { error: 'شما در این دوره ثبت‌نام نکرده‌اید' },
        { status: 403 }
      );
    }

    // Fetch progress if enrollment exists
    let progress = null;
    if (enrollment) {
      const progressRecord = await db.lessonProgress.findUnique({
        where: {
          enrollmentId_lessonId: {
            enrollmentId: enrollment.id,
            lessonId: lesson.id,
          },
        },
      });

      if (progressRecord) {
        progress = {
          status: progressRecord.status,
          progressPercent: progressRecord.progressPercent,
          timeSpent: progressRecord.timeSpent,
          lastPosition: progressRecord.lastPosition,
          completedAt: progressRecord.completedAt,
          updatedAt: progressRecord.updatedAt,
        };
      } else {
        progress = {
          status: 'NOT_STARTED',
          progressPercent: 0,
          timeSpent: 0,
          lastPosition: 0,
          completedAt: null,
          updatedAt: null,
        };
      }
    }

    // Build response — include full content only if enrolled or free
    const response: Record<string, unknown> = {
      id: lesson.id,
      title: lesson.title,
      description: lesson.description,
      type: lesson.type,
      order: lesson.order,
      isFree: lesson.isFree,
      isPublished: lesson.isPublished,
      estimatedMinutes: lesson.estimatedMinutes,
      videoDuration: lesson.videoDuration,
      createdAt: lesson.createdAt,
      updatedAt: lesson.updatedAt,
      program: lesson.skillProgram,
      progress,
    };

    // Include content fields only for enrolled or free lessons
    if (enrollment || lesson.isFree) {
      response.videoUrl = lesson.videoUrl;
      response.content = lesson.content;
      response.documentUrl = lesson.documentUrl;
    }

    return NextResponse.json({ data: response });
  } catch (error) {
    console.error('Portal LMS lesson detail error:', error);
    return NextResponse.json({ error: 'خطا در دریافت محتوای درس' }, { status: 500 });
  }
}
