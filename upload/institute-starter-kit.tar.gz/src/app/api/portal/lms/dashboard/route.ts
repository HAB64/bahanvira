import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/lms/dashboard — Student learning dashboard summary
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getPortalUserFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { karAmuzId } = session;

    // 1. Total enrolled programs count
    const enrollmentCount = await db.enrollment.count({
      where: {
        karAmuzId,
        status: { in: ['ENROLLED', 'COMPLETED'] },
      },
    });

    // 2. Fetch all active enrollments with their progress data
    const enrollments = await db.enrollment.findMany({
      where: {
        karAmuzId,
        status: { in: ['ENROLLED', 'COMPLETED'] },
      },
      include: {
        skillProgram: {
          select: {
            id: true,
            name: true,
          },
        },
        lessonProgress: {
          select: {
            status: true,
            progressPercent: true,
            timeSpent: true,
            lessonId: true,
            updatedAt: true,
            completedAt: true,
            lesson: {
              select: {
                id: true,
                title: true,
                isPublished: true,
                skillProgramId: true,
                estimatedMinutes: true,
              },
            },
          },
        },
      },
    });

    // 3. Overall progress across all programs
    let totalCompletedLessons = 0;
    let totalPublishedLessons = 0;

    const programProgresses = await Promise.all(
      enrollments.map(async (enrollment) => {
        const publishedCount = await db.lesson.count({
          where: {
            skillProgramId: enrollment.skillProgramId,
            isPublished: true,
          },
        });

        const completedCount = enrollment.lessonProgress.filter(
          (lp) => lp.status === 'COMPLETED'
        ).length;

        totalCompletedLessons += completedCount;
        totalPublishedLessons += publishedCount;

        return {
          skillProgramId: enrollment.skillProgramId,
          programName: enrollment.skillProgram.name,
          completedLessons: completedCount,
          totalLessons: publishedCount,
          completionPercent: publishedCount > 0 ? Math.round((completedCount / publishedCount) * 100) : 0,
        };
      })
    );

    const overallCompletionPercent =
      totalPublishedLessons > 0
        ? Math.round((totalCompletedLessons / totalPublishedLessons) * 100)
        : 0;

    // 4. Recently accessed lessons (last 5 by updatedAt)
    const allProgressRecords = enrollments.flatMap((e) => e.lessonProgress);
    const recentlyAccessed = allProgressRecords
      .filter((lp) => lp.status !== 'NOT_STARTED' && lp.updatedAt)
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, 5)
      .map((lp) => ({
        lessonId: lp.lesson.id,
        lessonTitle: lp.lesson.title,
        skillProgramId: lp.lesson.skillProgramId,
        status: lp.status,
        progressPercent: lp.progressPercent,
        timeSpent: lp.timeSpent,
        updatedAt: lp.updatedAt,
      }));

    // 5. Upcoming deadlines (sessions in the near future)
    const activeProgramIds = enrollments
      .filter((e) => e.status === 'ENROLLED')
      .map((e) => e.skillProgramId);

    const upcomingSessions = activeProgramIds.length > 0
      ? await db.session.findMany({
          where: {
            skillProgramId: { in: activeProgramIds },
            date: { gte: new Date() },
          },
          orderBy: { date: 'asc' },
          take: 5,
          include: {
            skillProgram: {
              select: { name: true },
            },
          },
        })
      : [];

    const upcomingDeadlines = upcomingSessions.map((s) => ({
      id: s.id,
      title: s.title || s.skillProgram.name,
      date: s.date,
      startTime: s.startTime,
      endTime: s.endTime,
      type: s.type,
      programName: s.skillProgram.name,
    }));

    // 6. Total learning time (sum of timeSpent across all progress records)
    const totalLearningTime = allProgressRecords.reduce(
      (sum, lp) => sum + lp.timeSpent,
      0
    );

    return NextResponse.json({
      data: {
        totalEnrolledPrograms: enrollmentCount,
        overallProgress: {
          completedLessons: totalCompletedLessons,
          totalLessons: totalPublishedLessons,
          overallCompletionPercent,
        },
        programProgresses,
        recentlyAccessedLessons: recentlyAccessed,
        upcomingDeadlines,
        totalLearningTimeSeconds: totalLearningTime,
        totalLearningTimeMinutes: Math.round(totalLearningTime / 60),
      },
    });
  } catch (error) {
    console.error('Portal LMS dashboard error:', error);
    return NextResponse.json({ error: 'خطا در دریافت داشبورد' }, { status: 500 });
  }
}
