import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

interface ProgressRequestBody {
  lessonId: string;
  status?: string;
  progressPercent?: number;
  timeSpent?: number;
  lastPosition?: number;
}

/**
 * POST /api/portal/lms/progress — Update lesson progress (upsert)
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getPortalUserFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { karAmuzId } = session;
    const body: ProgressRequestBody = await request.json();
    const { lessonId, status, progressPercent, timeSpent, lastPosition } = body;

    if (!lessonId) {
      return NextResponse.json(
        { error: 'شناسه درس الزامی است' },
        { status: 400 }
      );
    }

    // Validate status value
    const validStatuses = ['NOT_STARTED', 'IN_PROGRESS', 'COMPLETED'];
    if (status && !validStatuses.includes(status)) {
      return NextResponse.json(
        { error: 'وضعیت نامعتبر است' },
        { status: 400 }
      );
    }

    // Validate progressPercent range
    if (progressPercent !== undefined && (progressPercent < 0 || progressPercent > 100)) {
      return NextResponse.json(
        { error: 'درصد پیشرفت باید بین ۰ تا ۱۰۰ باشد' },
        { status: 400 }
      );
    }

    // Find the lesson
    const lesson = await db.lesson.findUnique({
      where: { id: lessonId },
      select: { id: true, skillProgramId: true, isPublished: true },
    });

    if (!lesson) {
      return NextResponse.json({ error: 'درس یافت نشد' }, { status: 404 });
    }

    // Check active enrollment
    const enrollment = await db.enrollment.findFirst({
      where: {
        karAmuzId,
        skillProgramId: lesson.skillProgramId,
        status: { in: ['ENROLLED', 'COMPLETED'] },
      },
    });

    if (!enrollment) {
      return NextResponse.json(
        { error: 'شما در این دوره ثبت‌نام نکرده‌اید' },
        { status: 403 }
      );
    }

    // Determine final values based on status
    const isCompleting = status === 'COMPLETED';
    const finalProgressPercent = isCompleting ? 100 : (progressPercent ?? 0);
    const finalStatus = status ?? 'IN_PROGRESS';
    const finalCompletedAt = isCompleting ? new Date() : null;

    // Upsert lesson progress
    const progressRecord = await db.lessonProgress.upsert({
      where: {
        enrollmentId_lessonId: {
          enrollmentId: enrollment.id,
          lessonId: lesson.id,
        },
      },
      create: {
        enrollmentId: enrollment.id,
        lessonId: lesson.id,
        status: finalStatus,
        progressPercent: finalProgressPercent,
        timeSpent: timeSpent ?? 0,
        lastPosition: lastPosition ?? 0,
        completedAt: finalCompletedAt,
      },
      update: {
        ...(finalStatus !== undefined && { status: finalStatus }),
        ...(progressPercent !== undefined && !isCompleting && { progressPercent: finalProgressPercent }),
        ...(isCompleting && { progressPercent: 100 }),
        ...(timeSpent !== undefined && { timeSpent }),
        ...(lastPosition !== undefined && { lastPosition }),
        ...(isCompleting && { completedAt: finalCompletedAt }),
      },
    });

    return NextResponse.json({ data: progressRecord });
  } catch (error) {
    console.error('Portal LMS progress update error:', error);
    return NextResponse.json({ error: 'خطا در ذخیره پیشرفت' }, { status: 500 });
  }
}
