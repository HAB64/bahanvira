import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest, hashPassword } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * POST /api/portal/profile/password — Change password
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const body = await request.json();
    const { currentPassword, newPassword } = body;

    if (!currentPassword || !newPassword) {
      return NextResponse.json({ error: 'رمز عبور فعلی و جدید الزامی است' }, { status: 400 });
    }

    if (newPassword.length < 6) {
      return NextResponse.json({ error: 'رمز عبور جدید باید حداقل ۶ کاراکتر باشد' }, { status: 400 });
    }

    // Verify current password
    const fullUser = await db.customerPortalUser.findUnique({ where: { id: user.id } });
    if (!fullUser) {
      return NextResponse.json({ error: 'کاربر یافت نشد' }, { status: 404 });
    }

    const currentHash = hashPassword(currentPassword);
    if (currentHash !== fullUser.passwordHash) {
      return NextResponse.json({ error: 'رمز عبور فعلی اشتباه است' }, { status: 400 });
    }

    // Update password
    const newHash = hashPassword(newPassword);
    await db.customerPortalUser.update({
      where: { id: user.id },
      data: { passwordHash: newHash },
    });

    return NextResponse.json({ message: 'رمز عبور با موفقیت تغییر کرد' });
  } catch (error) {
    console.error('Portal password change error:', error);
    return NextResponse.json({ error: 'خطا در تغییر رمز عبور' }, { status: 500 });
  }
}
