import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/profile — Get current user profile
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const profile = {
      id: user.id,
      username: user.username,
      displayName: user.karAmuz
        ? `${user.karAmuz.firstName} ${user.karAmuz.lastName}`
        : user.lead?.name || user.username,
      phone: user.karAmuz?.phone || user.lead?.phone || '',
      email: user.karAmuz?.email || user.lead?.email || '',
      address: user.karAmuz?.address || '',
      nationalId: user.karAmuz?.nationalId || '',
      type: user.karAmuzId ? 'karAmuz' : 'lead',
      leadId: user.leadId,
      karAmuzId: user.karAmuzId,
    };

    return NextResponse.json({ data: profile });
  } catch (error) {
    console.error('Portal profile error:', error);
    return NextResponse.json({ error: 'خطا در دریافت پروفایل' }, { status: 500 });
  }
}

/**
 * PATCH /api/portal/profile — Update profile
 */
export async function PATCH(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const body = await request.json();
    const { phone, email, address } = body;

    // Update the related record (Lead or KarAmuz)
    if (user.karAmuzId) {
      await db.karAmuz.update({
        where: { id: user.karAmuzId },
        data: {
          ...(phone !== undefined && { phone }),
          ...(email !== undefined && { email }),
          ...(address !== undefined && { address }),
        },
      });
    } else if (user.leadId) {
      await db.lead.update({
        where: { id: user.leadId },
        data: {
          ...(phone !== undefined && { phone }),
          ...(email !== undefined && { email }),
        },
      });
    }

    return NextResponse.json({ message: 'پروفایل با موفقیت به‌روزرسانی شد' });
  } catch (error) {
    console.error('Portal profile update error:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی پروفایل' }, { status: 500 });
  }
}
