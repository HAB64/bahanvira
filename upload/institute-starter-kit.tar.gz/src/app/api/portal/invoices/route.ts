import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/invoices — List invoices for the current portal user
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    // Filter by the user's leadId or karAmuzId
    if (user.karAmuzId) {
      where.karAmuzId = user.karAmuzId;
    } else if (user.leadId) {
      where.leadId = user.leadId;
    } else {
      // No associated record, return empty
      return NextResponse.json({ data: [], pagination: { page, limit, total: 0, totalPages: 0 } });
    }

    if (status) where.status = status;

    const [invoices, total] = await Promise.all([
      db.invoice.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      db.invoice.count({ where }),
    ]);

    // Summary
    const summary = await db.invoice.aggregate({
      where: user.karAmuzId ? { karAmuzId: user.karAmuzId } : { leadId: user.leadId },
      _sum: { totalAmount: true, paidAmount: true },
      _count: { id: true },
    });

    const openInvoices = await db.invoice.count({
      where: {
        ...(user.karAmuzId ? { karAmuzId: user.karAmuzId } : { leadId: user.leadId }),
        status: { in: ['DRAFT', 'SENT', 'PARTIALLY_PAID'] },
      },
    });

    return NextResponse.json({
      data: invoices,
      summary: {
        totalInvoices: summary._count.id,
        totalAmount: summary._sum.totalAmount || 0,
        totalPaid: summary._sum.paidAmount || 0,
        totalRemaining: (summary._sum.totalAmount || 0) - (summary._sum.paidAmount || 0),
        openInvoices,
      },
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Portal invoices error:', error);
    return NextResponse.json({ error: 'خطا در دریافت فاکتورها' }, { status: 500 });
  }
}
