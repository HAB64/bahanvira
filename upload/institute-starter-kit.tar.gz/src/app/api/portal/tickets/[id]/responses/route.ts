import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest, getPortalUserName } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * POST /api/portal/tickets/[id]/responses — Add response to a ticket
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { id } = await params;

    // Verify ticket ownership
    const ticket = await db.ticket.findUnique({ where: { id } });
    if (!ticket) {
      return NextResponse.json({ error: 'تیکت یافت نشد' }, { status: 404 });
    }

    if (user.karAmuzId && ticket.karAmuzId !== user.karAmuzId) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }
    if (user.leadId && ticket.leadId !== user.leadId) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    if (ticket.status === 'CLOSED') {
      return NextResponse.json({ error: 'تیکت بسته شده و امکان ارسال پاسخ وجود ندارد' }, { status: 400 });
    }

    const body = await request.json();
    const { content } = body;

    if (!content || !content.trim()) {
      return NextResponse.json({ error: 'متن پاسخ الزامی است' }, { status: 400 });
    }

    const authorName = getPortalUserName(user as Parameters<typeof getPortalUserName>[0]);

    const response = await db.ticketResponse.create({
      data: {
        ticketId: id,
        content: content.trim(),
        authorType: 'CUSTOMER',
        authorName,
        isInternal: false,
      },
    });

    // Update ticket status
    if (ticket.status === 'WAITING_CUSTOMER') {
      await db.ticket.update({
        where: { id },
        data: { status: 'IN_PROGRESS' },
      });
    }

    return NextResponse.json({ data: response, message: 'پاسخ با موفقیت ثبت شد' }, { status: 201 });
  } catch (error) {
    console.error('Portal ticket response error:', error);
    return NextResponse.json({ error: 'خطا در ثبت پاسخ' }, { status: 500 });
  }
}
