import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/tickets/[id] — Get single ticket detail
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { id } = await params;

    const ticket = await db.ticket.findUnique({
      where: { id },
      include: {
        responses: {
          where: { isInternal: false },
          orderBy: { createdAt: 'asc' },
        },
      },
    });

    if (!ticket) {
      return NextResponse.json({ error: 'تیکت یافت نشد' }, { status: 404 });
    }

    // Verify ownership
    if (user.karAmuzId && ticket.karAmuzId !== user.karAmuzId) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }
    if (user.leadId && ticket.leadId !== user.leadId) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    return NextResponse.json({ data: ticket });
  } catch (error) {
    console.error('Portal ticket detail error:', error);
    return NextResponse.json({ error: 'خطا در دریافت جزئیات تیکت' }, { status: 500 });
  }
}
