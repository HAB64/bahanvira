import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest, getPortalUserName } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/portal/tickets — List tickets for the current portal user
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '20', 10)));
    const skip = (page - 1) * limit;

    const where: Record<string, unknown> = {};

    if (user.karAmuzId) {
      where.karAmuzId = user.karAmuzId;
    } else if (user.leadId) {
      where.leadId = user.leadId;
    } else {
      return NextResponse.json({ data: [], pagination: { page, limit, total: 0, totalPages: 0 } });
    }

    if (status) where.status = status;

    const [tickets, total] = await Promise.all([
      db.ticket.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          responses: {
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
          _count: { select: { responses: true } },
        },
      }),
      db.ticket.count({ where }),
    ]);

    // Stats
    const openTickets = await db.ticket.count({
      where: {
        ...(user.karAmuzId ? { karAmuzId: user.karAmuzId } : { leadId: user.leadId }),
        status: { in: ['OPEN', 'IN_PROGRESS', 'WAITING_CUSTOMER'] },
      },
    });

    return NextResponse.json({
      data: tickets,
      stats: {
        openTickets,
        totalTickets: total,
      },
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Portal tickets error:', error);
    return NextResponse.json({ error: 'خطا در دریافت تیکت‌ها' }, { status: 500 });
  }
}

/**
 * POST /api/portal/tickets — Create a new ticket from portal
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const body = await request.json();
    const { subject, description, category, priority } = body;

    if (!subject || !description) {
      return NextResponse.json({ error: 'موضوع و توضیحات تیکت الزامی است' }, { status: 400 });
    }

    const ticket = await db.ticket.create({
      data: {
        subject,
        description,
        category: category || 'GENERAL',
        priority: priority || 'MEDIUM',
        status: 'OPEN',
        leadId: user.leadId || null,
        karAmuzId: user.karAmuzId || null,
        assignedTo: '',
        source: 'WEB_FORM',
      },
      include: {
        responses: true,
      },
    });

    return NextResponse.json({ data: ticket, message: 'تیکت با موفقیت ایجاد شد' }, { status: 201 });
  } catch (error) {
    console.error('Portal ticket creation error:', error);
    return NextResponse.json({ error: 'خطا در ثبت تیکت' }, { status: 500 });
  }
}
