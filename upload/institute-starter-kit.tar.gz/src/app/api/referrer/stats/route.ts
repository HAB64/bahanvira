import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getCommissionRate, TIER_LABELS, TIER_RATES, calculateTier } from '@/lib/referrer';

/**
 * GET /api/referrer/stats?referrerId=xxx
 * Get referrer dashboard stats (for referrer's own dashboard)
 */
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const referrerId = searchParams.get('referrerId');

    if (!referrerId) {
      return NextResponse.json({ error: 'referrerId is required' }, { status: 400 });
    }

    const referrer = await db.referrer.findUnique({
      where: { id: referrerId },
      include: {
        commissions: {
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
      },
    });

    if (!referrer) {
      return NextResponse.json({ error: 'معرف یافت نشد' }, { status: 404 });
    }

    // Monthly stats
    const now = new Date();
    const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

    const [thisMonthLeads, thisMonthEnrollments, lastMonthLeads, thisMonthCommission, pendingCommission] = await Promise.all([
      db.lead.count({ where: { referrerId, createdAt: { gte: thisMonth } } }),
      db.lead.count({ where: { referrerId, stage: 'ENROLLED', createdAt: { gte: thisMonth } } }),
      db.lead.count({ where: { referrerId, createdAt: { gte: lastMonth, lt: thisMonth } } }),
      db.referralCommission.aggregate({ where: { referrerId, createdAt: { gte: thisMonth } }, _sum: { amount: true } }),
      db.referralCommission.aggregate({ where: { referrerId, status: 'PENDING' }, _sum: { amount: true } }),
    ]);

    const nextTier = (() => {
      const tiers = ['BRONZE', 'SILVER', 'GOLD', 'PLATINUM'];
      const idx = tiers.indexOf(referrer.tier);
      return idx < tiers.length - 1 ? tiers[idx + 1] : null;
    })();

    const nextTierProgress = (() => {
      const TIER_THRESHOLDS: Record<string, number> = { BRONZE: 0, SILVER: 5, GOLD: 15, PLATINUM: 30 };
      const enrollments = referrer.totalEnrollments;
      if (enrollments >= 30) return { current: enrollments, target: 30, percentage: 100 };
      if (enrollments >= 15) return { current: enrollments, target: 30, percentage: Math.round(((enrollments - 15) / 15) * 100) };
      if (enrollments >= 5) return { current: enrollments, target: 15, percentage: Math.round(((enrollments - 5) / 10) * 100) };
      return { current: enrollments, target: 5, percentage: Math.round((enrollments / 5) * 100) };
    })();

    const stats = {
      thisMonthLeads,
      thisMonthEnrollments,
      lastMonthLeads,
      thisMonthCommission: thisMonthCommission._sum.amount ?? 0,
      pendingCommission: pendingCommission._sum.amount ?? 0,
      conversionRate: referrer.totalReferrals > 0 ? Math.round((referrer.totalEnrollments / referrer.totalReferrals) * 100) : 0,
      currentRate: getCommissionRate(referrer),
      nextTier,
      nextTierProgress,
    };

    return NextResponse.json({ referrer, stats, commissions: referrer.commissions });
  } catch (error) {
    console.error('Error fetching referrer stats:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات' }, { status: 500 });
  }
}
