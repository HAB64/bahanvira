import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import crypto from 'crypto';

// Cluster labels mapping for Persian
const CLUSTER_LABELS: Record<string, string> = {
  'tech-ai': 'فناوری و هوش مصنوعی',
  'financial': 'مالی و سرمایه‌گذاری',
  'management': 'مدیریت و کسب‌وکار',
  'entrepreneurship': 'کارآفرینی',
  'capital-market': 'بازار سرمایه',
  'educational-services': 'خدمات آموزشی',
  'legal-services': 'خدمات حقوقی',
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { invoiceId, gateway, callbackUrl } = body;

    if (!invoiceId) {
      return NextResponse.json(
        { خطا: 'شناسه فاکتور الزامی است' },
        { status: 400 }
      );
    }

    // Validate invoice exists
    const invoice = await db.invoice.findUnique({
      where: { id: invoiceId },
      include: {
        lead: true,
        karAmuz: true,
      },
    });

    if (!invoice) {
      return NextResponse.json(
        { خطا: 'فاکتور مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    // Calculate remaining amount
    const remainingAmount = invoice.totalAmount - invoice.paidAmount;

    if (remainingAmount <= 0) {
      return NextResponse.json(
        { خطا: 'این فاکتور قبلاً پرداخت شده است' },
        { status: 400 }
      );
    }

    const selectedGateway = gateway || 'IDPAY';

    // Create OnlinePayment record
    const onlinePayment = await db.onlinePayment.create({
      data: {
        invoiceId,
        karAmuzId: invoice.karAmuzId,
        leadId: invoice.leadId,
        amount: remainingAmount,
        gateway: selectedGateway,
        status: 'PENDING',
        description: `پرداخت فاکتور ${invoice.invoiceNumber}`,
      },
    });

    // Placeholder implementation for payment gateway integration
    // In production, this would make actual API calls to IDPay/ZarinPal/Zibal
    let paymentUrl = '';
    const gatewayRefId = `SIM-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;

    switch (selectedGateway) {
      case 'IDPAY':
        // Placeholder: In production, call IDPay API
        // POST https://api.idpay.ir/v1.1/payment
        // Headers: X-API-KEY, X-SANDBOX
        // Body: { order_id, amount, name, phone, mail, desc, callback }
        paymentUrl = `/api/payment/verify?orderId=${onlinePayment.id}&gateway=IDPAY`;
        break;

      case 'ZARINPAL':
        // Placeholder: In production, call ZarinPal API
        // POST https://api.zarinpal.com/pg/v4/payment/request.json
        paymentUrl = `/api/payment/verify?orderId=${onlinePayment.id}&gateway=ZARINPAL`;
        break;

      case 'ZIBAL':
        // Placeholder: In production, call Zibal API
        // POST https://gateway.zibal.ir/v1/request
        paymentUrl = `/api/payment/verify?orderId=${onlinePayment.id}&gateway=ZIBAL`;
        break;

      default:
        return NextResponse.json(
          { خطا: 'درگاه پرداخت نامعتبر است' },
          { status: 400 }
        );
    }

    // Update the OnlinePayment with gateway reference
    await db.onlinePayment.update({
      where: { id: onlinePayment.id },
      data: {
        gatewayRefId,
        callbackData: {
          invoiceNumber: invoice.invoiceNumber,
          amount: remainingAmount,
          gateway: selectedGateway,
          callbackUrl: callbackUrl || '',
          createdAt: new Date().toISOString(),
        },
      },
    });

    return NextResponse.json({
      پیام: 'درخواست پرداخت با موفقیت ایجاد شد',
      داده‌ها: {
        paymentId: onlinePayment.id,
        amount: remainingAmount,
        gateway: selectedGateway,
        gatewayRefId,
        paymentUrl,
        invoiceNumber: invoice.invoiceNumber,
      },
    });
  } catch (error) {
    console.error('Error creating payment request:', error);
    return NextResponse.json(
      { خطا: 'خطا در ایجاد درخواست پرداخت' },
      { status: 500 }
    );
  }
}
