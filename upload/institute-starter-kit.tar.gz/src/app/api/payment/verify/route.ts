import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, orderId, trackId } = body;

    // Find the online payment by id or orderId
    const paymentId = id || orderId;
    if (!paymentId) {
      return NextResponse.json(
        { خطا: 'شناسه پرداخت الزامی است' },
        { status: 400 }
      );
    }

    const onlinePayment = await db.onlinePayment.findUnique({
      where: { id: paymentId },
      include: {
        invoice: true,
      },
    });

    if (!onlinePayment) {
      return NextResponse.json(
        { خطا: 'پرداخت مورد نظر یافت نشد' },
        { status: 404 }
      );
    }

    if (onlinePayment.status === 'PAID') {
      return NextResponse.json(
        { خطا: 'این پرداخت قبلاً تایید شده است' },
        { status: 400 }
      );
    }

    // Placeholder verification logic
    // In production, this would call the gateway's verify API:
    // - IDPay: POST https://api.idpay.ir/v1.1/payment/verify
    // - ZarinPal: POST https://api.zarinpal.com/pg/v4/payment/verify.json
    // - Zibal: POST https://gateway.zibal.ir/v1/verify

    // For now, assume payment is successful if trackId is provided
    const isPaymentSuccessful = !!trackId;

    if (isPaymentSuccessful) {
      // Update OnlinePayment status
      await db.onlinePayment.update({
        where: { id: paymentId },
        data: {
          status: 'PAID',
          trackingCode: trackId || `VERIFY-${Date.now()}`,
          paidAt: new Date(),
          callbackData: {
            ...(typeof onlinePayment.callbackData === 'object' && onlinePayment.callbackData !== null
              ? onlinePayment.callbackData as Record<string, unknown>
              : {}),
            verifiedAt: new Date().toISOString(),
            trackId: trackId || null,
            verified: true,
          },
        },
      });

      // Update Invoice paidAmount
      if (onlinePayment.invoiceId) {
        const invoice = await db.invoice.findUnique({
          where: { id: onlinePayment.invoiceId },
        });

        if (invoice) {
          const newPaidAmount = invoice.paidAmount + onlinePayment.amount;
          const newStatus =
            newPaidAmount >= invoice.totalAmount ? 'PAID' : 'PARTIALLY_PAID';

          await db.invoice.update({
            where: { id: onlinePayment.invoiceId },
            data: {
              paidAmount: newPaidAmount,
              status: newStatus,
            },
          });
        }
      }

      // Create Payment record
      await db.payment.create({
        data: {
          leadId: onlinePayment.leadId,
          karAmuzId: onlinePayment.karAmuzId,
          amount: onlinePayment.amount,
          type: 'CASH',
          status: 'PAID',
          paidAt: new Date(),
          note: `پرداخت آنلاین - ${onlinePayment.gateway} - کد پیگیری: ${trackId || 'N/A'}`,
        },
      });

      // Update lead lifetime value if lead exists
      if (onlinePayment.leadId) {
        const lead = await db.lead.findUnique({
          where: { id: onlinePayment.leadId },
        });

        if (lead) {
          await db.lead.update({
            where: { id: onlinePayment.leadId },
            data: {
              lifetimeValue: lead.lifetimeValue + onlinePayment.amount,
            },
          });
        }
      }

      return NextResponse.json({
        پیام: 'پرداخت با موفقیت تایید شد',
        داده‌ها: {
          paymentId: onlinePayment.id,
          amount: onlinePayment.amount,
          gateway: onlinePayment.gateway,
          trackingCode: trackId,
          invoiceStatus: onlinePayment.invoiceId ? 'updated' : 'no_invoice',
        },
      });
    } else {
      // Payment failed
      await db.onlinePayment.update({
        where: { id: paymentId },
        data: {
          status: 'FAILED',
          callbackData: {
            ...(typeof onlinePayment.callbackData === 'object' && onlinePayment.callbackData !== null
              ? onlinePayment.callbackData as Record<string, unknown>
              : {}),
            verifiedAt: new Date().toISOString(),
            verified: false,
            reason: 'تراکنش ناموفق',
          },
        },
      });

      return NextResponse.json(
        { خطا: 'پرداخت ناموفق بود', داده‌ها: { paymentId: onlinePayment.id } },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Error verifying payment:', error);
    return NextResponse.json(
      { خطا: 'خطا در تایید پرداخت' },
      { status: 500 }
    );
  }
}
