import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// ─── POST: Create a new survey result ────────────────────────
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      karAmuzId,
      skillProgramId,
      type,
      instructorName,
      contentQuality,
      instructorScore,
      facilitiesScore,
      overallScore,
      npsScore,
      comment,
      suggestion,
      wouldRecommend,
      source,
      isAnonymous,
    } = body

    // Basic validation
    if (!type) {
      return NextResponse.json(
        { خطا: 'نوع نظرسنجی الزامی است' },
        { status: 400 }
      )
    }

    // Validate score ranges
    const scores = [contentQuality, instructorScore, facilitiesScore, overallScore].filter(s => s !== undefined && s !== null)
    if (scores.some(s => s < 0 || s > 5)) {
      return NextResponse.json(
        { خطا: 'امتیازات باید بین ۰ تا ۵ باشند' },
        { status: 400 }
      )
    }

    if (npsScore !== undefined && npsScore !== null && (npsScore < 0 || npsScore > 10)) {
      return NextResponse.json(
        { خطا: 'امتیاز NPS باید بین ۰ تا ۱۰ باشد' },
        { status: 400 }
      )
    }

    const survey = await db.surveyResult.create({
      data: {
        karAmuzId: isAnonymous ? null : (karAmuzId || null),
        skillProgramId: skillProgramId || null,
        instructorName: instructorName || null,
        type,
        contentQuality: contentQuality || 0,
        instructorScore: instructorScore || 0,
        facilitiesScore: facilitiesScore || 0,
        overallScore: overallScore || 0,
        npsScore: npsScore || 0,
        comment: comment || null,
        suggestion: suggestion || null,
        wouldRecommend: wouldRecommend ?? null,
        source: source || 'WEB',
        isAnonymous: isAnonymous || false,
      },
    })

    return NextResponse.json({
      پیام: 'نظرسنجی با موفقیت ثبت شد',
      شناسه: survey.id,
    }, { status: 201 })
  } catch (error) {
    console.error('Survey creation error:', error)
    return NextResponse.json(
      { خطا: 'خطا در ثبت نظرسنجی' },
      { status: 500 }
    )
  }
}

// ─── GET: Survey statistics (admin) ─────────────────────────
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const skillProgramId = searchParams.get('skillProgramId')
    const instructorName = searchParams.get('instructorName')
    const type = searchParams.get('type')

    // Build where clause
    const where: Record<string, unknown> = {}
    if (skillProgramId) where.skillProgramId = skillProgramId
    if (instructorName) where.instructorName = instructorName
    if (type) where.type = type

    // Get total count
    const totalCount = await db.surveyResult.count({ where })

    // Get aggregated stats
    const surveys = await db.surveyResult.findMany({
      where,
      select: {
        contentQuality: true,
        instructorScore: true,
        facilitiesScore: true,
        overallScore: true,
        npsScore: true,
        wouldRecommend: true,
        type: true,
        instructorName: true,
        skillProgramId: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    })

    // Calculate averages
    const avgContentQuality = surveys.length > 0
      ? surveys.reduce((sum, s) => sum + s.contentQuality, 0) / surveys.length
      : 0
    const avgInstructorScore = surveys.length > 0
      ? surveys.reduce((sum, s) => sum + s.instructorScore, 0) / surveys.length
      : 0
    const avgFacilitiesScore = surveys.length > 0
      ? surveys.reduce((sum, s) => sum + s.facilitiesScore, 0) / surveys.length
      : 0
    const avgOverallScore = surveys.length > 0
      ? surveys.reduce((sum, s) => sum + s.overallScore, 0) / surveys.length
      : 0
    const avgNps = surveys.length > 0
      ? surveys.reduce((sum, s) => sum + s.npsScore, 0) / surveys.length
      : 0
    const recommendRate = surveys.length > 0
      ? surveys.filter(s => s.wouldRecommend === true).length / surveys.length * 100
      : 0

    // NPS categorization
    const promoters = surveys.filter(s => s.npsScore >= 9).length
    const passives = surveys.filter(s => s.npsScore >= 7 && s.npsScore <= 8).length
    const detractors = surveys.filter(s => s.npsScore <= 6).length
    const npsValue = surveys.length > 0
      ? Math.round((promoters - detractors) / surveys.length * 100)
      : 0

    // Group by instructor
    const instructorStats: Record<string, { count: number; avgOverall: number; avgInstructor: number }> = {}
    for (const s of surveys) {
      const key = s.instructorName || 'نامشخص'
      if (!instructorStats[key]) {
        instructorStats[key] = { count: 0, avgOverall: 0, avgInstructor: 0 }
      }
      instructorStats[key].count++
      instructorStats[key].avgOverall += s.overallScore
      instructorStats[key].avgInstructor += s.instructorScore
    }
    // Finalize averages
    for (const key of Object.keys(instructorStats)) {
      const stat = instructorStats[key]
      stat.avgOverall = Number((stat.avgOverall / stat.count).toFixed(2))
      stat.avgInstructor = Number((stat.avgInstructor / stat.count).toFixed(2))
    }

    // Group by type
    const typeStats: Record<string, { count: number; avgOverall: number }> = {}
    for (const s of surveys) {
      if (!typeStats[s.type]) {
        typeStats[s.type] = { count: 0, avgOverall: 0 }
      }
      typeStats[s.type].count++
      typeStats[s.type].avgOverall += s.overallScore
    }
    for (const key of Object.keys(typeStats)) {
      typeStats[key].avgOverall = Number((typeStats[key].avgOverall / typeStats[key].count).toFixed(2))
    }

    // Recent trend (last 30 days vs previous 30 days)
    const now = new Date()
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000)
    
    const recentSurveys = surveys.filter(s => new Date(s.createdAt) >= thirtyDaysAgo)
    const previousSurveys = surveys.filter(s => {
      const d = new Date(s.createdAt)
      return d >= sixtyDaysAgo && d < thirtyDaysAgo
    })

    const recentAvg = recentSurveys.length > 0
      ? recentSurveys.reduce((sum, s) => sum + s.overallScore, 0) / recentSurveys.length
      : 0
    const previousAvg = previousSurveys.length > 0
      ? previousSurveys.reduce((sum, s) => sum + s.overallScore, 0) / previousSurveys.length
      : 0

    return NextResponse.json({
      totalCount,
      averages: {
        contentQuality: Number(avgContentQuality.toFixed(2)),
        instructorScore: Number(avgInstructorScore.toFixed(2)),
        facilitiesScore: Number(avgFacilitiesScore.toFixed(2)),
        overallScore: Number(avgOverallScore.toFixed(2)),
        nps: Number(avgNps.toFixed(2)),
        recommendRate: Number(recommendRate.toFixed(1)),
      },
      npsBreakdown: {
        promoters,
        passives,
        detractors,
        npsValue,
      },
      instructorStats,
      typeStats,
      trend: {
        recentAvg: Number(recentAvg.toFixed(2)),
        previousAvg: Number(previousAvg.toFixed(2)),
        change: Number((recentAvg - previousAvg).toFixed(2)),
      },
    })
  } catch (error) {
    console.error('Survey stats error:', error)
    return NextResponse.json(
      { خطا: 'خطا در دریافت آمار نظرسنجی' },
      { status: 500 }
    )
  }
}
