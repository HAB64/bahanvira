/**
 * A/B Tracking API — ثبت رویدادهای exposure و conversion
 */
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { experimentId, variantId, event, conversionType } = body;

    if (!experimentId || !variantId || !event) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
    }

    await db.eventLog.create({
      data: {
        type: event === 'exposure'
          ? `AB_EXPOSURE_${experimentId}`
          : `AB_CONVERSION_${experimentId}`,
        data: {
          experimentId,
          variantId,
          event,
          conversionType: conversionType || null,
          timestamp: new Date().toISOString(),
        },
      },
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error('[AB Track Error]', error);
    return NextResponse.json({ ok: true });
  }
}
