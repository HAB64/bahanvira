import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * POST /api/exams/submit — Submit exam and grade it
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    if (!user.karAmuzId) {
      return NextResponse.json({ error: 'کارآموز یافت نشد' }, { status: 403 });
    }

    const body = await request.json();
    const { attemptId, answers } = body;

    if (!attemptId) {
      return NextResponse.json({ error: 'شناسه تلاش آزمون الزامی است' }, { status: 400 });
    }

    // Find the attempt
    const attempt = await db.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: {
          include: {
            questions: true,
            skillProgram: { select: { name: true } },
          },
        },
      },
    });

    if (!attempt || attempt.karAmuzId !== user.karAmuzId) {
      return NextResponse.json({ error: 'تلاش آزمون یافت نشد' }, { status: 404 });
    }

    if (attempt.status !== 'IN_PROGRESS') {
      return NextResponse.json({ error: 'این آزمون قبلاً تحویل داده شده است' }, { status: 400 });
    }

    const now = new Date();
    const startedAt = new Date(attempt.startedAt);
    const timeSpentSec = Math.floor((now.getTime() - startedAt.getTime()) / 1000);

    // Merge saved answers with submitted answers
    const savedAnswers = (attempt.savedAnswers as Record<string, string>) || {};
    const finalAnswers = { ...savedAnswers, ...(answers || {}) };

    // Grade the exam
    let totalScore = 0;
    const maxScore = attempt.exam.questions.reduce((sum, q) => sum + q.points, 0);
    const examAnswers: Array<{
      questionId: string;
      selectedAnswer: string | null;
      isCorrect: boolean | null;
      pointsEarned: number;
    }> = [];

    // Helper: resolve the correct option label/index from any format
    function resolveCorrectLabel(question: typeof attempt.exam.questions[0]): string[] {
      const opts = question.options as unknown[] | null;
      if (!opts || !Array.isArray(opts)) return [question.correctAnswer];
      const correct = question.correctAnswer;
      const labels: string[] = [];
      // Try matching by label/key
      for (let i = 0; i < opts.length; i++) {
        const o = opts[i] as Record<string, unknown>;
        if (!o || typeof o !== 'object') continue;
        // Check if this option IS the correct one by label, key, or text match
        if (o.label === correct || o.key === correct || String(o.label) === correct || String(o.key) === correct) {
          labels.push(String(o.label || o.key || i + 1));
        }
        // If correctAnswer is a text match (e.g., correctAnswer = "the text itself")
        if (String(o.text) === correct) {
          const persianLetters = ['الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ'];
          labels.push(String(o.label || o.key || persianLetters[i] || String(i + 1)));
        }
      }
      // If correctAnswer is a number index (0-based or 1-based)
      const idx = parseInt(correct, 10);
      if (!isNaN(idx)) {
        const realIdx = idx === 0 ? 0 : idx - 1; // handle both 0-based and 1-based
        if (realIdx >= 0 && realIdx < opts.length) {
          const o = opts[realIdx] as Record<string, unknown>;
          labels.push(String(o?.label || o?.key || correct));
        }
      }
      if (labels.length === 0) labels.push(correct);
      return labels;
    }

    for (const question of attempt.exam.questions) {
      const selectedAnswer = finalAnswers[question.id] || null;
      let isCorrect: boolean | null = null;
      let pointsEarned = 0;

      if (selectedAnswer !== null && selectedAnswer !== undefined && selectedAnswer !== '') {
        if (question.type === 'SHORT_ANSWER') {
          // For short answer, case-insensitive comparison and trim
          const normalizedSelected = selectedAnswer.trim().toLowerCase();
          const normalizedCorrect = question.correctAnswer.trim().toLowerCase();
          isCorrect = normalizedSelected === normalizedCorrect;
        } else {
          // For MCQ/TF: match selected label against correct answer
          // Direct match first
          if (selectedAnswer === question.correctAnswer) {
            isCorrect = true;
          } else {
            // Try flexible matching via option resolution
            const correctLabels = resolveCorrectLabel(question);
            isCorrect = correctLabels.includes(selectedAnswer);
          }
        }

        if (isCorrect) {
          pointsEarned = question.points;
          totalScore += pointsEarned;
        }
      }

      examAnswers.push({
        questionId: question.id,
        selectedAnswer,
        isCorrect,
        pointsEarned,
      });
    }

    const percentage = maxScore > 0 ? Math.round((totalScore / maxScore) * 100 * 100) / 100 : 0;
    const isPassed = totalScore >= attempt.exam.passingScore;

    // Update attempt
    await db.examAttempt.update({
      where: { id: attemptId },
      data: {
        status: 'SUBMITTED',
        score: totalScore,
        maxScore,
        percentage,
        isPassed,
        submittedAt: now,
        timeSpentSec,
        savedAnswers: finalAnswers,
      },
    });

    // Create ExamAnswer records
    for (const ans of examAnswers) {
      await db.examAnswer.upsert({
        where: {
          attemptId_questionId: {
            attemptId,
            questionId: ans.questionId,
          },
        },
        create: {
          attemptId,
          questionId: ans.questionId,
          selectedAnswer: ans.selectedAnswer,
          isCorrect: ans.isCorrect,
          pointsEarned: ans.pointsEarned,
        },
        update: {
          selectedAnswer: ans.selectedAnswer,
          isCorrect: ans.isCorrect,
          pointsEarned: ans.pointsEarned,
        },
      });
    }

    // Determine what to return based on showResults setting
    const exam = attempt.exam;
    const showResults = exam.showResults;

    if (showResults === 'NEVER') {
      return NextResponse.json({
        داده: {
          attemptId,
          status: 'SUBMITTED',
          message: 'آزمون با موفقیت تحویل داده شد. نتایج بعداً اعلام خواهد شد.',
        },
      });
    }

    if (showResults === 'AFTER_DEADLINE' && exam.closeAt && now < exam.closeAt) {
      return NextResponse.json({
        داده: {
          attemptId,
          status: 'SUBMITTED',
          message: 'آزمون با موفقیت تحویل داده شد. نتایج پس از پایان مهلت آزمون اعلام خواهد شد.',
          resultsAvailableAt: exam.closeAt,
        },
      });
    }

    // AFTER_SUBMIT or AFTER_DEADLINE with deadline passed — show results
    return NextResponse.json({
      داده: {
        attemptId,
        status: 'SUBMITTED',
        score: totalScore,
        maxScore,
        percentage,
        isPassed,
        timeSpentSec,
        examTitle: exam.title,
        examType: exam.type,
        passingScore: exam.passingScore,
        programName: exam.skillProgram?.name || null,
      },
    });
  } catch (error) {
    console.error('Exam submit error:', error);
    return NextResponse.json({ error: 'خطا در تحویل آزمون' }, { status: 500 });
  }
}
