import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/exams/[examId] — Get exam details with questions (for taking the exam)
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ examId: string }> }
) {
  try {
    const { examId } = await params;

    // Verify auth
    const authHeader = request.headers.get('Authorization');
    if (!authHeader) {
      return NextResponse.json({ خطا: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = Buffer.from(token, 'base64').toString();
    const [userId] = decoded.split(':');

    const portalUser = await db.customerPortalUser.findUnique({
      where: { id: userId },
    });

    if (!portalUser || !portalUser.isActive) {
      return NextResponse.json({ خطا: 'کاربر یافت نشد یا غیرفعال است' }, { status: 401 });
    }

    const exam = await db.exam.findUnique({
      where: { id: examId },
      include: {
        questions: {
          orderBy: { order: 'asc' },
          select: {
            id: true,
            text: true,
            type: true,
            options: true,
            points: true,
            difficulty: true,
            order: true,
            image: true,
            // NOTE: correctAnswer is NOT sent to the client
          },
        },
        skillProgram: { select: { id: true, name: true } },
      },
    });

    if (!exam || !exam.isActive) {
      return NextResponse.json({ خطا: 'آزمون یافت نشد یا غیرفعال است' }, { status: 404 });
    }

    // Check if exam is within open/close time
    const now = new Date();
    if (exam.openAt && now < exam.openAt) {
      return NextResponse.json({ خطا: 'آزمون هنوز شروع نشده است' }, { status: 400 });
    }
    if (exam.closeAt && now > exam.closeAt) {
      return NextResponse.json({ خطا: 'مهلت آزمون به پایان رسیده است' }, { status: 400 });
    }

    // Check if student is enrolled in the related program
    if (exam.skillProgramId && portalUser.karAmuzId) {
      const enrollment = await db.enrollment.findFirst({
        where: {
          karAmuzId: portalUser.karAmuzId,
          skillProgramId: exam.skillProgramId,
          status: 'ENROLLED',
        },
      });
      if (!enrollment) {
        return NextResponse.json({ خطا: 'شما در دوره مرتبط ثبت‌نام نکرده‌اید' }, { status: 403 });
      }
    }

    // Shuffle questions if enabled
    let questions = exam.questions;
    if (exam.shuffleQuestions) {
      questions = [...questions].sort(() => Math.random() - 0.5);
    }

    // Calculate total points
    const maxScore = questions.reduce((sum, q) => sum + q.points, 0);

    // Check for existing in-progress attempt
    let attempt = null;
    if (portalUser.karAmuzId) {
      attempt = await db.examAttempt.findFirst({
        where: {
          examId,
          karAmuzId: portalUser.karAmuzId,
          status: 'IN_PROGRESS',
        },
      });

      // Check if max attempts reached
      if (!attempt) {
        const completedCount = await db.examAttempt.count({
          where: {
            examId,
            karAmuzId: portalUser.karAmuzId,
            status: { in: ['SUBMITTED', 'TIMED_OUT', 'AUTO_SUBMITTED'] },
          },
        });

        if (completedCount >= exam.maxAttempts) {
          return NextResponse.json({ خطا: 'حداکثر دفعات شرکت در آزمون استفاده شده است' }, { status: 400 });
        }
      }
    }

    return NextResponse.json({
      پیام: 'جزئیات آزمون با موفقیت دریافت شد',
      داده: {
        id: exam.id,
        title: exam.title,
        description: exam.description,
        type: exam.type,
        durationMinutes: exam.durationMinutes,
        passingScore: exam.passingScore,
        maxScore,
        questionCount: questions.length,
        skillProgram: exam.skillProgram,
        questions,
        existingAttemptId: attempt?.id || null,
        savedAnswers: attempt?.savedAnswers || null,
        showResults: exam.showResults,
      },
    });
  } catch (error) {
    console.error('Exam details error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت جزئیات آزمون' }, { status: 500 });
  }
}
