import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * POST /api/exams/attempt — Start a new exam attempt
 * Body: { examId: string }
 */
export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader) {
      return NextResponse.json({ خطا: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = Buffer.from(token, 'base64').toString();
    const [userId] = decoded.split(':');

    const portalUser = await db.customerPortalUser.findUnique({
      where: { id: userId },
    });

    if (!portalUser || !portalUser.isActive || !portalUser.karAmuzId) {
      return NextResponse.json({ خطا: 'کاربر یافت نشد یا غیرفعال است' }, { status: 401 });
    }

    const body = await request.json();
    const { examId } = body;

    if (!examId) {
      return NextResponse.json({ خطا: 'شناسه آزمون الزامی است' }, { status: 400 });
    }

    const exam = await db.exam.findUnique({
      where: { id: examId },
    });

    if (!exam || !exam.isActive) {
      return NextResponse.json({ خطا: 'آزمون یافت نشد' }, { status: 404 });
    }

    // Check exam timing
    const now = new Date();
    if (exam.openAt && now < exam.openAt) {
      return NextResponse.json({ خطا: 'آزمون هنوز شروع نشده است' }, { status: 400 });
    }
    if (exam.closeAt && now > exam.closeAt) {
      return NextResponse.json({ خطا: 'مهلت آزمون به پایان رسیده است' }, { status: 400 });
    }

    // Check for existing in-progress attempt
    const existingAttempt = await db.examAttempt.findFirst({
      where: {
        examId,
        karAmuzId: portalUser.karAmuzId,
        status: 'IN_PROGRESS',
      },
    });

    if (existingAttempt) {
      // Return the existing attempt instead of creating a new one
      return NextResponse.json({
        پیام: 'آزمون از قبل شروع شده است',
        داده: {
          attemptId: existingAttempt.id,
          examId: existingAttempt.examId,
          startedAt: existingAttempt.startedAt,
          savedAnswers: existingAttempt.savedAnswers,
        },
      });
    }

    // Check max attempts
    const completedCount = await db.examAttempt.count({
      where: {
        examId,
        karAmuzId: portalUser.karAmuzId,
        status: { in: ['SUBMITTED', 'TIMED_OUT', 'AUTO_SUBMITTED'] },
      },
    });

    if (completedCount >= exam.maxAttempts) {
      return NextResponse.json({ خطا: 'حداکثر دفعات شرکت استفاده شده' }, { status: 400 });
    }

    // Create new attempt
    const attempt = await db.examAttempt.create({
      data: {
        examId,
        karAmuzId: portalUser.karAmuzId,
        status: 'IN_PROGRESS',
        startedAt: new Date(),
        savedAnswers: {},
      },
    });

    return NextResponse.json({
      پیام: 'آزمون با موفقیت شروع شد',
      داده: {
        attemptId: attempt.id,
        examId: attempt.examId,
        startedAt: attempt.startedAt,
      },
    });
  } catch (error) {
    console.error('Start exam attempt error:', error);
    return NextResponse.json({ خطا: 'خطا در شروع آزمون' }, { status: 500 });
  }
}

/**
 * PUT /api/exams/attempt — Save answers or submit the exam
 * Body: { attemptId: string, action: 'save' | 'submit', answers: Record<string, string> }
 */
export async function PUT(request: NextRequest) {
  try {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader) {
      return NextResponse.json({ خطا: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = Buffer.from(token, 'base64').toString();
    const [userId] = decoded.split(':');

    const portalUser = await db.customerPortalUser.findUnique({
      where: { id: userId },
    });

    if (!portalUser || !portalUser.isActive || !portalUser.karAmuzId) {
      return NextResponse.json({ خطا: 'کاربر یافت نشد یا غیرفعال است' }, { status: 401 });
    }

    const body = await request.json();
    const { attemptId, action, answers } = body;

    if (!attemptId || !action) {
      return NextResponse.json({ خطا: 'پارامترهای ناقص' }, { status: 400 });
    }

    // Find the attempt
    const attempt = await db.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: {
          include: { questions: true },
        },
      },
    });

    if (!attempt || attempt.karAmuzId !== portalUser.karAmuzId) {
      return NextResponse.json({ خطا: 'تلاش آزمون یافت نشد' }, { status: 404 });
    }

    if (attempt.status !== 'IN_PROGRESS') {
      return NextResponse.json({ خطا: 'این آزمون قبلاً تحویل داده شده است' }, { status: 400 });
    }

    // Check if time has expired
    const now = new Date();
    const startTime = new Date(attempt.startedAt);
    const elapsedSeconds = Math.floor((now.getTime() - startTime.getTime()) / 1000);
    const maxSeconds = attempt.exam.durationMinutes * 60;

    if (elapsedSeconds > maxSeconds) {
      // Auto-submit due to time out
      await autoGradeAndSubmit(attemptId, attempt.exam.questions, answers || attempt.savedAnswers as Record<string, string> || {}, 'AUTO_SUBMITTED', elapsedSeconds);
      return NextResponse.json({
        پیام: 'زمان آزمون به پایان رسید و پاسخ‌ها خودکار تحویل داده شد',
        داده: { status: 'AUTO_SUBMITTED', timedOut: true },
      });
    }

    if (action === 'save') {
      // Just save answers (auto-save every 30s)
      await db.examAttempt.update({
        where: { id: attemptId },
        data: {
          savedAnswers: answers || {},
        },
      });

      return NextResponse.json({
        پیام: 'پاسخ‌ها ذخیره شد',
        داده: { saved: true, remainingSeconds: maxSeconds - elapsedSeconds },
      });
    }

    if (action === 'submit') {
      // Submit and grade
      await autoGradeAndSubmit(attemptId, attempt.exam.questions, answers || {}, 'SUBMITTED', elapsedSeconds);

      return NextResponse.json({
        پیام: 'آزمون با موفقیت تحویل داده شد',
        داده: { status: 'SUBMITTED' },
      });
    }

    return NextResponse.json({ خطا: 'عملکرد نامعتبر' }, { status: 400 });
  } catch (error) {
    console.error('Save/submit exam error:', error);
    return NextResponse.json({ خطا: 'خطا در ذخیره/تحویل آزمون' }, { status: 500 });
  }
}

/**
 * Auto-grade exam and create answer records
 */
async function autoGradeAndSubmit(
  attemptId: string,
  questions: { id: string; correctAnswer: string; points: number }[],
  answers: Record<string, string>,
  status: 'SUBMITTED' | 'AUTO_SUBMITTED',
  timeSpentSec: number
) {
  let totalScore = 0;
  let maxScore = 0;

  // Create answer records
  const answerRecords = questions.map(q => {
    const selectedAnswer = answers[q.id] || null;
    const isCorrect = selectedAnswer?.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase();
    const pointsEarned = isCorrect ? q.points : 0;

    totalScore += pointsEarned;
    maxScore += q.points;

    return {
      attemptId,
      questionId: q.id,
      selectedAnswer,
      isCorrect,
      pointsEarned,
    };
  });

  // Create all answer records
  await db.examAnswer.createMany({ data: answerRecords });

  // Calculate results
  const percentage = maxScore > 0 ? (totalScore / maxScore) * 100 : 0;
  const exam = await db.exam.findUnique({ where: { id: (await db.examAttempt.findUnique({ where: { id: attemptId } }))!.examId } });
  const passingScore = exam?.passingScore || 10;
  const passingPct = (passingScore / 20) * 100;
  const isPassed = percentage >= passingPct;

  // Update attempt
  await db.examAttempt.update({
    where: { id: attemptId },
    data: {
      status,
      score: totalScore,
      maxScore,
      percentage,
      isPassed,
      submittedAt: new Date(),
      timeSpentSec,
      savedAnswers: answers,
    },
  });
}
