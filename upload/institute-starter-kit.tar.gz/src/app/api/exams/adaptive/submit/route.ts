import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { submitAdaptiveAnswer } from '@/lib/ai/adaptive-exam';

// POST /api/exams/adaptive/submit — Submit answer and get next question
export async function POST(request: NextRequest) {
  try {
    const session = await getPortalUserFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { sessionId, questionId, answer } = body as {
      sessionId: string;
      questionId: string;
      answer: string;
    };

    if (!sessionId || !questionId || answer === undefined) {
      return NextResponse.json(
        { error: 'sessionId, questionId, and answer are required' },
        { status: 400 },
      );
    }

    const result = await submitAdaptiveAnswer(sessionId, questionId, answer);
    return NextResponse.json(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to submit answer';
    console.error('Error submitting adaptive answer:', error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
