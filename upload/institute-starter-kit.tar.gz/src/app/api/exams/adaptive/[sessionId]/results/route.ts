import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { getAdaptiveResults } from '@/lib/ai/adaptive-exam';

// GET /api/exams/adaptive/[sessionId]/results — Get adaptive exam results
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ sessionId: string }> },
) {
  try {
    const session = await getPortalUserFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { sessionId } = await params;
    const result = await getAdaptiveResults(sessionId);
    return NextResponse.json(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to get results';
    console.error('Error getting adaptive results:', error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
