import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { startAdaptiveExam } from '@/lib/ai/adaptive-exam';

// POST /api/exams/adaptive/start — Start adaptive exam session
export async function POST(request: NextRequest) {
  try {
    const session = await getPortalUserFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { examId } = body as { examId: string };

    if (!examId) {
      return NextResponse.json({ error: 'examId is required' }, { status: 400 });
    }

    const result = await startAdaptiveExam(examId, session.karAmuzId);
    return NextResponse.json(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to start adaptive exam';
    console.error('Error starting adaptive exam:', error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
