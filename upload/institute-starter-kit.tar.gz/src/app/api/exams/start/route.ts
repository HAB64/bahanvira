import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * POST /api/exams/start — Start an exam attempt
 * Creates a new attempt or returns existing IN_PROGRESS attempt
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    if (!user.karAmuzId) {
      return NextResponse.json({ error: 'کارآموز یافت نشد' }, { status: 403 });
    }

    const body = await request.json();
    const { examId } = body;

    if (!examId) {
      return NextResponse.json({ error: 'شناسه آزمون الزامی است' }, { status: 400 });
    }

    // Get exam with questions
    const exam = await db.exam.findUnique({
      where: { id: examId },
      include: {
        questions: { orderBy: { order: 'asc' } },
        skillProgram: { select: { name: true } },
      },
    });

    if (!exam || !exam.isActive) {
      return NextResponse.json({ error: 'آزمون یافت نشد یا غیرفعال است' }, { status: 404 });
    }

    // Check time window
    const now = new Date();
    if (exam.openAt && now < exam.openAt) {
      return NextResponse.json({ error: 'زمان شروع آزمون فرانرسیده است' }, { status: 400 });
    }
    if (exam.closeAt && now > exam.closeAt) {
      return NextResponse.json({ error: 'مهلت آزمون به پایان رسیده است' }, { status: 400 });
    }

    // Check if enrolled in the program
    if (exam.skillProgramId) {
      const enrollment = await db.enrollment.findFirst({
        where: {
          karAmuzId: user.karAmuzId,
          skillProgramId: exam.skillProgramId,
        },
      });
      if (!enrollment) {
        return NextResponse.json({ error: 'شما در این دوره ثبت‌نام نکرده‌اید' }, { status: 403 });
      }
    }

    // Check for existing IN_PROGRESS attempt
    const existingAttempt = await db.examAttempt.findFirst({
      where: {
        examId,
        karAmuzId: user.karAmuzId,
        status: 'IN_PROGRESS',
      },
    });

    if (existingAttempt) {
      // Check if time expired for existing attempt
      const startedAt = new Date(existingAttempt.startedAt);
      const deadline = new Date(startedAt.getTime() + exam.durationMinutes * 60 * 1000);
      const remainingSeconds = Math.max(0, Math.floor((deadline.getTime() - now.getTime()) / 1000));

      if (remainingSeconds <= 0) {
        // Auto-submit expired attempt
        await db.examAttempt.update({
          where: { id: existingAttempt.id },
          data: { status: 'TIMED_OUT', submittedAt: now },
        });
        return NextResponse.json({ error: 'زمان آزمون به پایان رسیده است' }, { status: 400 });
      }

      // Prepare questions (hide correctAnswer)
      let questions = exam.questions.map(q => ({
        id: q.id,
        text: q.text,
        type: q.type,
        options: q.options,
        points: q.points,
        difficulty: q.difficulty,
        image: q.image,
      }));

      if (exam.shuffleQuestions) {
        // Use seeded shuffle based on attemptId for consistency
        const seed = existingAttempt.id;
        questions = seededShuffle(questions, seed);
      }

      return NextResponse.json({
        داده: {
          attemptId: existingAttempt.id,
          exam: {
            id: exam.id,
            title: exam.title,
            description: exam.description,
            type: exam.type,
            durationMinutes: exam.durationMinutes,
            passingScore: exam.passingScore,
            showResults: exam.showResults,
            programName: exam.skillProgram?.name || null,
          },
          questions,
          savedAnswers: existingAttempt.savedAnswers || {},
          startedAt: existingAttempt.startedAt,
          remainingSeconds,
        },
      });
    }

    // Check attempt count limit
    const completedAttempts = await db.examAttempt.count({
      where: {
        examId,
        karAmuzId: user.karAmuzId,
        status: { in: ['SUBMITTED', 'TIMED_OUT', 'AUTO_SUBMITTED'] },
      },
    });

    if (completedAttempts >= exam.maxAttempts) {
      return NextResponse.json({ error: 'حداکثر تعداد مجاز آزمون استفاده شده است' }, { status: 400 });
    }

    // Create new attempt
    const attempt = await db.examAttempt.create({
      data: {
        examId,
        karAmuzId: user.karAmuzId,
        status: 'IN_PROGRESS',
        maxScore: exam.questions.reduce((sum, q) => sum + q.points, 0),
        startedAt: now,
        savedAnswers: {},
      },
    });

    // Prepare questions (hide correctAnswer)
    let questions = exam.questions.map(q => ({
      id: q.id,
      text: q.text,
      type: q.type,
      options: q.options,
      points: q.points,
      difficulty: q.difficulty,
      image: q.image,
    }));

    if (exam.shuffleQuestions) {
      const seed = attempt.id;
      questions = seededShuffle(questions, seed);
    }

    const remainingSeconds = exam.durationMinutes * 60;

    return NextResponse.json({
      داده: {
        attemptId: attempt.id,
        exam: {
          id: exam.id,
          title: exam.title,
          description: exam.description,
          type: exam.type,
          durationMinutes: exam.durationMinutes,
          passingScore: exam.passingScore,
          showResults: exam.showResults,
          programName: exam.skillProgram?.name || null,
        },
        questions,
        savedAnswers: {},
        startedAt: attempt.startedAt,
        remainingSeconds,
      },
    });
  } catch (error) {
    console.error('Exam start error:', error);
    return NextResponse.json({ error: 'خطا در شروع آزمون' }, { status: 500 });
  }
}

/**
 * Seeded shuffle for consistent question order per attempt
 */
function seededShuffle<T>(array: T[], seed: string): T[] {
  const result = [...array];
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    const char = seed.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }

  for (let i = result.length - 1; i > 0; i--) {
    hash = ((hash << 5) - hash) + i;
    hash = hash & hash;
    const j = Math.abs(hash) % (i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}
