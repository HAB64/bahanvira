import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/exams/results/[attemptId] — Get exam attempt results with detailed answers
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ attemptId: string }> }
) {
  try {
    const { attemptId } = await params;

    // Verify auth
    const authHeader = request.headers.get('Authorization');
    if (!authHeader) {
      return NextResponse.json({ خطا: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = Buffer.from(token, 'base64').toString();
    const [userId] = decoded.split(':');

    const portalUser = await db.customerPortalUser.findUnique({
      where: { id: userId },
    });

    if (!portalUser || !portalUser.isActive) {
      return NextResponse.json({ خطا: 'کاربر یافت نشد یا غیرفعال است' }, { status: 401 });
    }

    // Get attempt with answers
    const attempt = await db.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: {
          select: {
            id: true,
            title: true,
            type: true,
            durationMinutes: true,
            passingScore: true,
            showResults: true,
            skillProgram: { select: { id: true, name: true } },
            questions: {
              select: {
                id: true,
                text: true,
                type: true,
                options: true,
                correctAnswer: true,
                points: true,
                explanation: true,
                order: true,
              },
              orderBy: { order: 'asc' },
            },
          },
        },
        answers: true,
      },
    });

    if (!attempt) {
      return NextResponse.json({ خطا: 'تلاش آزمون یافت نشد' }, { status: 404 });
    }

    // Verify this attempt belongs to this user
    if (attempt.karAmuzId !== portalUser.karAmuzId) {
      return NextResponse.json({ خطا: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    // Check if results should be shown
    if (attempt.exam.showResults === 'NEVER') {
      return NextResponse.json({
        پیام: 'نتایج این آزمون نمایش داده نمی‌شود',
        داده: {
          id: attempt.id,
          examId: attempt.examId,
          status: attempt.status,
          score: attempt.score,
          maxScore: attempt.maxScore,
          percentage: attempt.percentage,
          isPassed: attempt.isPassed,
          startedAt: attempt.startedAt,
          submittedAt: attempt.submittedAt,
          timeSpentSec: attempt.timeSpentSec,
          exam: {
            id: attempt.exam.id,
            title: attempt.exam.title,
            type: attempt.exam.type,
            durationMinutes: attempt.exam.durationMinutes,
            passingScore: attempt.exam.passingScore,
            skillProgram: attempt.exam.skillProgram,
            questions: [], // No question details
          },
        },
      });
    }

    if (attempt.exam.showResults === 'AFTER_DEADLINE' && attempt.exam.closeAt && new Date() < attempt.exam.closeAt) {
      return NextResponse.json({
        پیام: 'نتایج پس از پایان مهلت آزمون نمایش داده خواهد شد',
        داده: {
          id: attempt.id,
          examId: attempt.examId,
          status: attempt.status,
          score: attempt.score,
          maxScore: attempt.maxScore,
          percentage: attempt.percentage,
          isPassed: attempt.isPassed,
          startedAt: attempt.startedAt,
          submittedAt: attempt.submittedAt,
          timeSpentSec: attempt.timeSpentSec,
          exam: {
            id: attempt.exam.id,
            title: attempt.exam.title,
            type: attempt.exam.type,
            durationMinutes: attempt.exam.durationMinutes,
            passingScore: attempt.exam.passingScore,
            skillProgram: attempt.exam.skillProgram,
            questions: [],
          },
        },
      });
    }

    // Build question results with answer details
    const answerMap = new Map(attempt.answers.map(a => [a.questionId, a]));

    const questionResults = attempt.exam.questions.map(q => {
      const answer = answerMap.get(q.id);
      return {
        id: q.id,
        text: q.text,
        type: q.type,
        options: q.options,
        correctAnswer: q.correctAnswer,
        selectedAnswer: answer?.selectedAnswer || null,
        isCorrect: answer?.isCorrect || null,
        pointsEarned: answer?.pointsEarned || 0,
        points: q.points,
        explanation: q.explanation,
      };
    });

    return NextResponse.json({
      پیام: 'نتایج آزمون با موفقیت دریافت شد',
      داده: {
        id: attempt.id,
        examId: attempt.examId,
        status: attempt.status,
        score: attempt.score,
        maxScore: attempt.maxScore,
        percentage: attempt.percentage,
        isPassed: attempt.isPassed,
        startedAt: attempt.startedAt,
        submittedAt: attempt.submittedAt,
        timeSpentSec: attempt.timeSpentSec,
        exam: {
          id: attempt.exam.id,
          title: attempt.exam.title,
          type: attempt.exam.type,
          durationMinutes: attempt.exam.durationMinutes,
          passingScore: attempt.exam.passingScore,
          skillProgram: attempt.exam.skillProgram,
          questions: questionResults,
        },
      },
    });
  } catch (error) {
    console.error('Exam results error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت نتایج آزمون' }, { status: 500 });
  }
}
