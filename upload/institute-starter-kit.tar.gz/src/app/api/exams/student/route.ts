import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/exams/student — Get exam data for the logged-in student
 * Returns past attempts and available active exams
 */
export async function GET(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    if (!user.karAmuzId) {
      return NextResponse.json({
        داده: [],
        آزمون‌های_فعال: [],
      });
    }

    // Get enrolled program IDs
    const enrollments = await db.enrollment.findMany({
      where: { karAmuzId: user.karAmuzId },
      select: { skillProgramId: true },
    });
    const programIds = enrollments.map(e => e.skillProgramId);

    // Get past exam attempts
    const attemptHistory = await db.examAttempt.findMany({
      where: { karAmuzId: user.karAmuzId },
      include: {
        exam: {
          select: {
            id: true,
            title: true,
            type: true,
            durationMinutes: true,
            passingScore: true,
            maxAttempts: true,
            skillProgram: { select: { name: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Get available active exams within open/close time window
    const now = new Date();
    const hasPrograms = programIds.length > 0;
    const availableExams = await db.exam.findMany({
      where: {
        isActive: true,
        AND: [
          {
            OR: [
              ...(hasPrograms ? [{ skillProgramId: { in: programIds } }] : []),
              { skillProgramId: null }, // General exams not tied to a program
            ],
          },
          {
            OR: [
              { openAt: null, closeAt: null },
              { openAt: { lte: now }, closeAt: { gte: now } },
              { openAt: { lte: now }, closeAt: null },
              { openAt: null, closeAt: { gte: now } },
            ],
          },
        ],
      },
      include: {
        skillProgram: { select: { name: true } },
        _count: { select: { questions: true } },
        attempts: {
          where: { karAmuzId: user.karAmuzId },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Filter out exams where max attempts reached
    const filteredExams = availableExams.filter(exam => {
      const completedAttempts = exam.attempts.filter(
        a => a.status === 'SUBMITTED' || a.status === 'TIMED_OUT' || a.status === 'AUTO_SUBMITTED'
      );
      return completedAttempts.length < exam.maxAttempts;
    });

    const formattedAvailable = filteredExams.map(exam => {
      const completedAttempts = exam.attempts.filter(
        a => a.status === 'SUBMITTED' || a.status === 'TIMED_OUT' || a.status === 'AUTO_SUBMITTED'
      );
      const hasInProgress = exam.attempts.some(a => a.status === 'IN_PROGRESS');
      const bestAttempt = completedAttempts.length > 0
        ? completedAttempts.reduce((best, a) =>
            (a.percentage ?? 0) > (best.percentage ?? 0) ? a : best
          )
        : null;

      return {
        id: exam.id,
        title: exam.title,
        type: exam.type,
        durationMinutes: exam.durationMinutes,
        passingScore: exam.passingScore,
        maxAttempts: exam.maxAttempts,
        questionCount: exam._count.questions,
        programName: exam.skillProgram?.name || null,
        openAt: exam.openAt,
        closeAt: exam.closeAt,
        attemptsUsed: completedAttempts.length,
        hasInProgress,
        bestScore: bestAttempt?.percentage ?? null,
        bestIsPassed: bestAttempt?.isPassed ?? null,
      };
    });

    const formattedAttempts = attemptHistory.map(attempt => ({
      id: attempt.id,
      examId: attempt.examId,
      examTitle: attempt.exam.title,
      examType: attempt.exam.type,
      programName: attempt.exam.skillProgram?.name || null,
      status: attempt.status,
      score: attempt.score,
      maxScore: attempt.maxScore,
      percentage: attempt.percentage,
      isPassed: attempt.isPassed,
      startedAt: attempt.startedAt,
      submittedAt: attempt.submittedAt,
      timeSpentSec: attempt.timeSpentSec,
    }));

    return NextResponse.json({
      داده: formattedAttempts,
      آزمون‌های_فعال: formattedAvailable,
    });
  } catch (error) {
    console.error('Exam student fetch error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات آزمون' }, { status: 500 });
  }
}
