import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * GET /api/exams/student/[karAmuzId] — Get exam attempts for a student
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ karAmuzId: string }> }
) {
  try {
    const { karAmuzId } = await params;

    // Verify auth
    const authHeader = request.headers.get('Authorization');
    if (!authHeader) {
      return NextResponse.json({ خطا: 'احراز هویت الزامی است' }, { status: 401 });
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = Buffer.from(token, 'base64').toString();
    const [userId] = decoded.split(':');

    const portalUser = await db.customerPortalUser.findUnique({
      where: { id: userId },
    });

    if (!portalUser || !portalUser.isActive) {
      return NextResponse.json({ خطا: 'کاربر یافت نشد یا غیرفعال است' }, { status: 401 });
    }

    // Verify this karAmuzId belongs to this user
    if (portalUser.karAmuzId !== karAmuzId) {
      return NextResponse.json({ خطا: 'دسترسی غیرمجاز' }, { status: 403 });
    }

    // Get all exam attempts for this student
    const attempts = await db.examAttempt.findMany({
      where: { karAmuzId },
      include: {
        exam: {
          select: {
            id: true,
            title: true,
            type: true,
            durationMinutes: true,
            passingScore: true,
            skillProgram: {
              select: { id: true, name: true },
            },
          },
        },
      },
      orderBy: { startedAt: 'desc' },
    });

    // Also get available exams (active exams for enrolled programs that student hasn't exhausted attempts for)
    const enrollments = await db.enrollment.findMany({
      where: { karAmuzId, status: 'ENROLLED' },
      select: { skillProgramId: true },
    });

    const enrolledProgramIds = enrollments.map(e => e.skillProgramId);

    const now = new Date();
    const availableExams = await db.exam.findMany({
      where: {
        isActive: true,
        AND: [
          {
            OR: [
              { skillProgramId: { in: enrolledProgramIds } },
              { skillProgramId: null },
            ],
          },
          {
            OR: [
              { openAt: null, closeAt: null },
              { openAt: { lte: now }, closeAt: { gte: now } },
              { openAt: { lte: now }, closeAt: null },
              { openAt: null, closeAt: { gte: now } },
            ],
          },
        ],
      },
      include: {
        _count: { select: { questions: true } },
        skillProgram: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Filter out exams where student has used all attempts
    const availableWithAttempts = availableExams
      .map(exam => {
        const studentAttempts = attempts.filter(a => a.examId === exam.id);
        const completedAttempts = studentAttempts.filter(a =>
          ['SUBMITTED', 'TIMED_OUT', 'AUTO_SUBMITTED'].includes(a.status)
        );
        const inProgressAttempt = studentAttempts.find(a => a.status === 'IN_PROGRESS');

        return {
          id: exam.id,
          title: exam.title,
          type: exam.type,
          durationMinutes: exam.durationMinutes,
          passingScore: exam.passingScore,
          questionCount: exam._count.questions,
          skillProgram: exam.skillProgram,
          openAt: exam.openAt,
          closeAt: exam.closeAt,
          maxAttempts: exam.maxAttempts,
          attemptsUsed: completedAttempts.length,
          canStart: completedAttempts.length < exam.maxAttempts,
          inProgressAttemptId: inProgressAttempt?.id || null,
        };
      });

    // Format attempts for response
    const formattedAttempts = attempts.map(attempt => ({
      id: attempt.id,
      examId: attempt.examId,
      status: attempt.status,
      score: attempt.score,
      maxScore: attempt.maxScore,
      percentage: attempt.percentage,
      isPassed: attempt.isPassed,
      startedAt: attempt.startedAt,
      submittedAt: attempt.submittedAt,
      timeSpentSec: attempt.timeSpentSec,
      exam: attempt.exam,
    }));

    return NextResponse.json({
      پیام: 'آزمون‌های کارآموز با موفقیت دریافت شد',
      داده: formattedAttempts,
      آزمون‌های_فعال: availableWithAttempts,
    });
  } catch (error) {
    console.error('Exams student error:', error);
    return NextResponse.json({ خطا: 'خطا در دریافت اطلاعات آزمون' }, { status: 500 });
  }
}
