import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * Exam API — Direct Prisma Implementation
 *
 * Handles all /api/exams/* requests using Prisma directly.
 * Works on both Vercel (serverless) and self-hosted deployments.
 *
 * Routes:
 *   GET    /api/exams                        — List all exams
 *   POST   /api/exams                        — Create exam
 *   GET    /api/exams/:id                    — Get exam with questions
 *   PUT    /api/exams/:id                    — Update exam
 *   DELETE /api/exams/:id                    — Delete exam
 *   POST   /api/exams/:id/questions          — Add question
 *   PUT    /api/exams/questions/:id          — Update question
 *   DELETE /api/exams/questions/:id          — Delete question
 *   GET    /api/exams/:id/attempts           — Get attempts for exam
 *   GET    /api/exams/:id/start              — Start exam attempt
 *   POST   /api/exams/attempts/:id/save      — Auto-save answers
 *   POST   /api/exams/attempts/:id/submit    — Submit exam
 *   GET    /api/exams/attempts/:id/results   — Get results
 *   GET    /api/exams/student/:karAmuzId     — Get student attempts
 */

/* ─────────── Helpers ─────────── */

function ok(data: unknown, message?: string) {
  return NextResponse.json({ پیام: message || 'عملیات با موفقیت انجام شد', داده: data });
}

function err(message: string, status = 400) {
  return NextResponse.json({ خطا: message }, { status });
}

function parsePath(path: string[]): { resource: string; id?: string; sub?: string; subId?: string } {
  // e.g., ['exams', 'abc123', 'start'] or ['exams', 'attempts', 'xyz', 'save']
  if (path.length === 0) return { resource: 'exams' };

  if (path[0] === 'exams') {
    if (path.length === 1) return { resource: 'exams' };
    if (path[1] === 'student') return { resource: 'student', id: path[2] };
    if (path[1] === 'attempts') return { resource: 'attempts', id: path[2], sub: path[3] };
    if (path[1] === 'questions') return { resource: 'questions', subId: path[2] };

    // /api/exams/:id/...
    const examId = path[1];
    if (path.length === 2) return { resource: 'exam', id: examId };
    if (path[2] === 'questions') {
      if (path.length === 3) return { resource: 'exam_questions', id: examId };
      return { resource: 'question', subId: path[3] };
    }
    if (path[2] === 'attempts') return { resource: 'exam_attempts', id: examId };
    if (path[2] === 'start') return { resource: 'start_exam', id: examId };
    return { resource: 'exam', id: examId, sub: path[2] };
  }

  return { resource: 'unknown' };
}

async function authenticatePortalUser(authHeader: string | null) {
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;

  try {
    const decoded = Buffer.from(token, 'base64').toString('utf-8');
    const [userId] = decoded.split(':');
    if (!userId) return null;

    const portalUser = await db.customerPortalUser.findUnique({
      where: { id: userId },
      include: { karAmuz: { select: { id: true, firstName: true, lastName: true } } },
    });

    if (!portalUser || !portalUser.isActive || !portalUser.karAmuzId) return null;

    return { portalUser, karAmuzId: portalUser.karAmuzId, karAmuz: portalUser.karAmuz };
  } catch {
    return null;
  }
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

/* ─────────── GET Handler ─────────── */

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const pathStr = url.pathname.replace('/api/', '');
    const path = pathStr.split('/').filter(Boolean);
    const route = parsePath(path);

    // GET /api/exams — List all exams
    if (route.resource === 'exams') {
      const exams = await db.exam.findMany({
        orderBy: { createdAt: 'desc' },
        include: {
          _count: { select: { questions: true, attempts: true } },
          skillProgram: { select: { id: true, name: true } },
        },
      });

      const examStats = await Promise.all(
        exams.map(async (exam) => {
          const passedAttempts = await db.examAttempt.count({
            where: { examId: exam.id, isPassed: true },
          });
          const avgScore = await db.examAttempt.aggregate({
            where: { examId: exam.id, score: { not: null } },
            _avg: { score: true },
          });
          return {
            ...exam,
            questionCount: exam._count.questions,
            totalAttempts: exam._count.attempts,
            passedAttempts,
            averageScore: avgScore._avg.score ?? 0,
          };
        })
      );

      return ok(examStats, 'لیست آزمون‌ها با موفقیت دریافت شد');
    }

    // GET /api/exams/:id — Get exam with questions
    if (route.resource === 'exam' && route.id) {
      const exam = await db.exam.findUnique({
        where: { id: route.id },
        include: {
          questions: { orderBy: { order: 'asc' } },
          skillProgram: { select: { id: true, name: true } },
          _count: { select: { attempts: true } },
        },
      });

      if (!exam) return err('آزمون یافت نشد', 404);
      return ok(exam, 'اطلاعات آزمون با موفقیت دریافت شد');
    }

    // GET /api/exams/:id/attempts — Get attempts for exam
    if (route.resource === 'exam_attempts' && route.id) {
      const attempts = await db.examAttempt.findMany({
        where: { examId: route.id },
        include: {
          karAmuz: { select: { id: true, firstName: true, lastName: true, studentCode: true } },
        },
        orderBy: { createdAt: 'desc' },
      });
      return ok(attempts, 'لیست شرکت‌کنندگان با موفقیت دریافت شد');
    }

    // GET /api/exams/:id/start — Start exam attempt
    if (route.resource === 'start_exam' && route.id) {
      const auth = await authenticatePortalUser(request.headers.get('Authorization'));
      if (!auth) return err('دسترسی غیرمجاز. لطفاً وارد شوید.', 401);

      const { karAmuzId } = auth;
      const examId = route.id;

      const exam = await db.exam.findUnique({
        where: { id: examId },
        include: { questions: { orderBy: { order: 'asc' } } },
      });

      if (!exam) return err('آزمون یافت نشد', 404);
      if (!exam.isActive) return err('این آزمون فعال نیست');

      const now = new Date();
      if (exam.openAt && now < exam.openAt) return err('زمان شروع آزمون هنوز فرانرسیده است');
      if (exam.closeAt && now > exam.closeAt) return err('زمان آزمون به پایان رسیده است');

      const existingAttempts = await db.examAttempt.count({
        where: { examId, karAmuzId, status: { in: ['IN_PROGRESS', 'SUBMITTED', 'TIMED_OUT', 'AUTO_SUBMITTED'] } },
      });
      if (existingAttempts >= exam.maxAttempts) {
        return err(`حداکثر تعداد شرکت در آزمون (${exam.maxAttempts} بار) به پایان رسیده است`);
      }

      // Check for in-progress attempt
      const inProgressAttempt = await db.examAttempt.findFirst({
        where: { examId, karAmuzId, status: 'IN_PROGRESS' },
      });

      if (inProgressAttempt) {
        const timeElapsed = Math.floor((now.getTime() - inProgressAttempt.startedAt.getTime()) / 1000);
        const timeRemaining = Math.max(0, exam.durationMinutes * 60 - timeElapsed);

        if (timeRemaining <= 0) {
          await db.examAttempt.update({
            where: { id: inProgressAttempt.id },
            data: { status: 'TIMED_OUT', submittedAt: now },
          });
          return err('زمان آزمون منقضی شده است. لطفاً دوباره تلاش کنید.');
        }

        const safeQuestions = exam.questions.map((q) => ({
          id: q.id, text: q.text, type: q.type, options: q.options,
          points: q.points, difficulty: q.difficulty, order: q.order, image: q.image,
        }));

        return ok({
          attemptId: inProgressAttempt.id,
          exam: { id: exam.id, title: exam.title, description: exam.description, type: exam.type, durationMinutes: exam.durationMinutes, passingScore: exam.passingScore, shuffleQuestions: exam.shuffleQuestions },
          questions: exam.shuffleQuestions ? shuffleArray(safeQuestions) : safeQuestions,
          timeRemaining,
          savedAnswers: inProgressAttempt.savedAnswers || {},
        }, 'آزمون از سر گرفته شد');
      }

      // Create new attempt
      const attempt = await db.examAttempt.create({
        data: { examId, karAmuzId, status: 'IN_PROGRESS', maxScore: exam.questions.reduce((sum, q) => sum + q.points, 0) },
      });

      const safeQuestions = exam.questions.map((q) => ({
        id: q.id, text: q.text, type: q.type, options: q.options,
        points: q.points, difficulty: q.difficulty, order: q.order, image: q.image,
      }));

      return ok({
        attemptId: attempt.id,
        exam: { id: exam.id, title: exam.title, description: exam.description, type: exam.type, durationMinutes: exam.durationMinutes, passingScore: exam.passingScore, shuffleQuestions: exam.shuffleQuestions },
        questions: exam.shuffleQuestions ? shuffleArray(safeQuestions) : safeQuestions,
        timeRemaining: exam.durationMinutes * 60,
        savedAnswers: {},
      }, 'آزمون با موفقیت شروع شد');
    }

    // GET /api/exams/attempts/:attemptId/results — Get results
    if (route.resource === 'attempts' && route.id && route.sub === 'results') {
      const auth = await authenticatePortalUser(request.headers.get('Authorization'));
      if (!auth) return err('دسترسی غیرمجاز', 401);

      const attempt = await db.examAttempt.findUnique({
        where: { id: route.id },
        include: { exam: { include: { questions: true } }, answers: { include: { question: true } } },
      });

      if (!attempt) return err('تلاش آزمون یافت نشد', 404);
      if (attempt.karAmuzId !== auth.karAmuzId) return err('دسترسی غیرمجاز', 403);
      if (attempt.status === 'IN_PROGRESS') return err('آزمون هنوز تحویل داده نشده است');

      const showResults = attempt.exam.showResults;
      const canShowDetailed = (() => {
        switch (showResults) {
          case 'AFTER_SUBMIT': return true;
          case 'AFTER_DEADLINE': return !attempt.exam.closeAt || new Date() > attempt.exam.closeAt;
          case 'NEVER': return false;
          default: return false;
        }
      })();

      const responseData: Record<string, unknown> = {
        attemptId: attempt.id, examTitle: attempt.exam.title,
        score: attempt.score, maxScore: attempt.maxScore,
        percentage: attempt.percentage, isPassed: attempt.isPassed,
        status: attempt.status, startedAt: attempt.startedAt,
        submittedAt: attempt.submittedAt, timeSpentSec: attempt.timeSpentSec,
      };

      if (canShowDetailed) {
        responseData.answers = attempt.answers.map((a) => ({
          questionId: a.questionId, questionText: a.question?.text,
          questionType: a.question?.type, selectedAnswer: a.selectedAnswer,
          isCorrect: a.isCorrect, pointsEarned: a.pointsEarned,
          correctAnswer: a.question?.correctAnswer, explanation: a.question?.explanation,
        }));
      } else {
        responseData.نکته = 'نتایج دقیق بر اساس تنظیمات آزمون در حال حاضر نمایش داده نمی‌شود';
      }

      return ok(responseData, 'نتایج آزمون با موفقیت دریافت شد');
    }

    // GET /api/exams/student/:karAmuzId — Get student attempts
    if (route.resource === 'student' && route.id) {
      const auth = await authenticatePortalUser(request.headers.get('Authorization'));
      if (!auth) return err('دسترسی غیرمجاز', 401);
      if (route.id !== auth.karAmuzId) return err('دسترسی غیرمجاز', 403);

      const attempts = await db.examAttempt.findMany({
        where: { karAmuzId: route.id },
        include: { exam: { select: { id: true, title: true, type: true, durationMinutes: true, passingScore: true, skillProgram: { select: { id: true, name: true } } } } },
        orderBy: { createdAt: 'desc' },
      });

      return ok(attempts, 'لیست آزمون‌های کارآموز با موفقیت دریافت شد');
    }

    return err('مسیر نامعتبر', 404);
  } catch (error) {
    console.error('Exam GET error:', error);
    return err('خطای سرور داخلی', 500);
  }
}

/* ─────────── POST Handler ─────────── */

export async function POST(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const pathStr = url.pathname.replace('/api/', '');
    const path = pathStr.split('/').filter(Boolean);
    const route = parsePath(path);

    // POST /api/exams — Create exam
    if (route.resource === 'exams') {
      const body = await request.json();
      const { title, description, skillProgramId, type, durationMinutes, passingScore, maxAttempts, shuffleQuestions, showResults, isActive, openAt, closeAt } = body;

      if (!title) return err('عنوان آزمون الزامی است');

      const exam = await db.exam.create({
        data: {
          title, description, skillProgramId: skillProgramId || null,
          type: type || 'QUIZ', durationMinutes: durationMinutes ?? 30,
          passingScore: passingScore ?? 10, maxAttempts: maxAttempts ?? 1,
          shuffleQuestions: shuffleQuestions ?? true, showResults: showResults || 'AFTER_SUBMIT',
          isActive: isActive ?? true, openAt: openAt ? new Date(openAt) : null, closeAt: closeAt ? new Date(closeAt) : null,
        },
      });

      return ok(exam, 'آزمون با موفقیت ایجاد شد');
    }

    // POST /api/exams/:id/questions — Add question
    if (route.resource === 'exam_questions' && route.id) {
      const body = await request.json();
      const exam = await db.exam.findUnique({ where: { id: route.id } });
      if (!exam) return err('آزمون یافت نشد', 404);

      const { text, type, options, correctAnswer, points, difficulty, explanation, order, image } = body;
      if (!text || !correctAnswer) return err('متن سوال و پاسخ صحیح الزامی است');

      const question = await db.examQuestion.create({
        data: { examId: route.id, text, type: type || 'MULTIPLE_CHOICE', options: options || null, correctAnswer, points: points ?? 1, difficulty: difficulty || 'MEDIUM', explanation: explanation || null, order: order ?? 0, image: image || null },
      });

      return ok(question, 'سوال با موفقیت اضافه شد');
    }

    // POST /api/exams/attempts/:attemptId/save — Auto-save
    if (route.resource === 'attempts' && route.id && route.sub === 'save') {
      const auth = await authenticatePortalUser(request.headers.get('Authorization'));
      if (!auth) return err('دسترسی غیرمجاز', 401);

      const body = await request.json();
      const { answers } = body;
      if (!answers || typeof answers !== 'object') return err('فرمت پاسخ‌ها نامعتبر است');

      const attempt = await db.examAttempt.findUnique({ where: { id: route.id } });
      if (!attempt) return err('تلاش آزمون یافت نشد', 404);
      if (attempt.karAmuzId !== auth.karAmuzId) return err('دسترسی غیرمجاز', 403);
      if (attempt.status !== 'IN_PROGRESS') return err('این تلاش آزمون قابل ویرایش نیست');

      const exam = await db.exam.findUnique({ where: { id: attempt.examId } });
      if (exam) {
        const timeElapsed = Math.floor((Date.now() - attempt.startedAt.getTime()) / 1000);
        if (timeElapsed > exam.durationMinutes * 60) {
          await db.examAttempt.update({ where: { id: route.id }, data: { status: 'TIMED_OUT', submittedAt: new Date() } });
          return err('زمان آزمون منقضی شده است');
        }
      }

      const existingAnswers = (attempt.savedAnswers as Record<string, string>) || {};
      const mergedAnswers = { ...existingAnswers, ...answers };

      await db.examAttempt.update({ where: { id: route.id }, data: { savedAnswers: mergedAnswers } });
      return ok(null, 'پاسخ‌ها با موفقیت ذخیره شد');
    }

    // POST /api/exams/attempts/:attemptId/submit — Submit exam
    if (route.resource === 'attempts' && route.id && route.sub === 'submit') {
      const auth = await authenticatePortalUser(request.headers.get('Authorization'));
      if (!auth) return err('دسترسی غیرمجاز', 401);

      const body = await request.json();
      const { answers } = body as { answers?: Record<string, string> };

      const attempt = await db.examAttempt.findUnique({
        where: { id: route.id },
        include: { exam: { include: { questions: true } } },
      });

      if (!attempt) return err('تلاش آزمون یافت نشد', 404);
      if (attempt.karAmuzId !== auth.karAmuzId) return err('دسترسی غیرمجاز', 403);
      if (attempt.status !== 'IN_PROGRESS') return err('این آزمون قبلاً تحویل داده شده است');

      const savedAnswers = (attempt.savedAnswers as Record<string, string>) || {};
      const finalAnswers = { ...savedAnswers, ...(answers || {}) };

      const submittedAt = new Date();
      const timeSpentSec = Math.floor((submittedAt.getTime() - attempt.startedAt.getTime()) / 1000);

      let totalScore = 0;
      const maxScore = attempt.exam.questions.reduce((sum, q) => sum + q.points, 0);
      const answerRecords: { questionId: string; selectedAnswer: string | null; isCorrect: boolean | null; pointsEarned: number }[] = [];

      // Helper: flexible correct answer matching for MCQ
      function mcqIsCorrect(question: typeof attempt.exam.questions[0], selected: string): boolean {
        if (selected === question.correctAnswer) return true;
        const opts = question.options as unknown[] | null;
        if (!opts || !Array.isArray(opts)) return false;
        for (let i = 0; i < opts.length; i++) {
          const o = opts[i] as Record<string, unknown>;
          if (!o || typeof o !== 'object') continue;
          const label = String(o.label || o.key || '');
          const text = String(o.text || '');
          // If the stored correctAnswer matches this option's label/key
          if ((o.label === question.correctAnswer || o.key === question.correctAnswer) && label === selected) return true;
          // If the stored correctAnswer matches this option's text, check selected against generated label
          if (text === question.correctAnswer) {
            const persianLetters = ['الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ'];
            if (selected === (label || persianLetters[i] || String(i + 1))) return true;
          }
        }
        // Index-based matching
        const idx = parseInt(question.correctAnswer, 10);
        if (!isNaN(idx)) {
          const realIdx = idx === 0 ? 0 : idx - 1;
          if (realIdx >= 0 && realIdx < opts.length) {
            const o = opts[realIdx] as Record<string, unknown>;
            if (selected === String(o?.label || o?.key || question.correctAnswer)) return true;
          }
        }
        return false;
      }

      for (const question of attempt.exam.questions) {
        const selectedAnswer = finalAnswers[question.id] || null;
        let isCorrect: boolean | null = null;
        let pointsEarned = 0;

        switch (question.type) {
          case 'MULTIPLE_CHOICE': {
            if (selectedAnswer) { isCorrect = mcqIsCorrect(question, selectedAnswer); pointsEarned = isCorrect ? question.points : 0; }
            break;
          }
          case 'TRUE_FALSE': {
            if (selectedAnswer) { isCorrect = selectedAnswer.toLowerCase().trim() === question.correctAnswer.toLowerCase().trim(); pointsEarned = isCorrect ? question.points : 0; }
            break;
          }
          case 'SHORT_ANSWER': { isCorrect = null; pointsEarned = 0; break; }
          default: { isCorrect = null; pointsEarned = 0; }
        }

        totalScore += pointsEarned;
        answerRecords.push({ questionId: question.id, selectedAnswer, isCorrect, pointsEarned });
      }

      const percentage = maxScore > 0 ? (totalScore / maxScore) * 100 : 0;
      const passingPercentage = maxScore > 0 ? (attempt.exam.passingScore / maxScore) * 100 : 0;
      const isPassed = percentage >= passingPercentage;

      const result = await db.$transaction(async (tx) => {
        for (const answer of answerRecords) {
          await tx.examAnswer.upsert({
            where: { attemptId_questionId: { attemptId: route.id!, questionId: answer.questionId } },
            create: { attemptId: route.id!, questionId: answer.questionId, selectedAnswer: answer.selectedAnswer, isCorrect: answer.isCorrect, pointsEarned: answer.pointsEarned },
            update: { selectedAnswer: answer.selectedAnswer, isCorrect: answer.isCorrect, pointsEarned: answer.pointsEarned },
          });
        }

        return await tx.examAttempt.update({
          where: { id: route.id },
          data: { status: 'SUBMITTED', score: totalScore, maxScore, percentage, isPassed, submittedAt, timeSpentSec },
        });
      });

      const responseData: Record<string, unknown> = {
        attemptId: result.id, score: result.score, maxScore: result.maxScore,
        percentage: result.percentage, isPassed: result.isPassed, timeSpentSec: result.timeSpentSec,
      };

      if (attempt.exam.showResults === 'AFTER_SUBMIT') {
        responseData.answers = answerRecords.map((a) => {
          const question = attempt.exam.questions.find((q) => q.id === a.questionId);
          return { questionId: a.questionId, questionText: question?.text, selectedAnswer: a.selectedAnswer, isCorrect: a.isCorrect, pointsEarned: a.pointsEarned, correctAnswer: question?.correctAnswer, explanation: question?.explanation };
        });
      } else if (attempt.exam.showResults === 'AFTER_DEADLINE') {
        if (attempt.exam.closeAt && submittedAt > attempt.exam.closeAt) {
          responseData.answers = answerRecords.map((a) => {
            const question = attempt.exam.questions.find((q) => q.id === a.questionId);
            return { questionId: a.questionId, questionText: question?.text, selectedAnswer: a.selectedAnswer, isCorrect: a.isCorrect, pointsEarned: a.pointsEarned, correctAnswer: question?.correctAnswer, explanation: question?.explanation };
          });
        } else {
          responseData.نکته = 'نتایج دقیق پس از پایان مهلت آزمون نمایش داده خواهد شد';
        }
      }

      return ok(responseData, 'آزمون با موفقیت تحویل داده شد');
    }

    return err('مسیر نامعتبر', 404);
  } catch (error) {
    console.error('Exam POST error:', error);
    return err('خطای سرور داخلی', 500);
  }
}

/* ─────────── PUT Handler ─────────── */

export async function PUT(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const pathStr = url.pathname.replace('/api/', '');
    const path = pathStr.split('/').filter(Boolean);
    const route = parsePath(path);

    // PUT /api/exams/:id — Update exam
    if (route.resource === 'exam' && route.id) {
      const body = await request.json();
      const existing = await db.exam.findUnique({ where: { id: route.id } });
      if (!existing) return err('آزمون یافت نشد', 404);

      const updateData: Record<string, unknown> = {};
      const allowedFields = ['title', 'description', 'skillProgramId', 'type', 'durationMinutes', 'passingScore', 'maxAttempts', 'shuffleQuestions', 'showResults', 'isActive'];

      for (const field of allowedFields) {
        if (body[field] !== undefined) updateData[field] = body[field];
      }
      if (body.openAt !== undefined) updateData.openAt = body.openAt ? new Date(body.openAt) : null;
      if (body.closeAt !== undefined) updateData.closeAt = body.closeAt ? new Date(body.closeAt) : null;

      const exam = await db.exam.update({ where: { id: route.id }, data: updateData });
      return ok(exam, 'آزمون با موفقیت بروزرسانی شد');
    }

    // PUT /api/exams/questions/:id — Update question
    if (route.resource === 'question' && route.subId) {
      const body = await request.json();
      const existing = await db.examQuestion.findUnique({ where: { id: route.subId } });
      if (!existing) return err('سوال یافت نشد', 404);

      const updateData: Record<string, unknown> = {};
      const allowedFields = ['text', 'type', 'options', 'correctAnswer', 'points', 'difficulty', 'explanation', 'order', 'image'];

      for (const field of allowedFields) {
        if (body[field] !== undefined) updateData[field] = body[field];
      }

      const question = await db.examQuestion.update({ where: { id: route.subId }, data: updateData });
      return ok(question, 'سوال با موفقیت بروزرسانی شد');
    }

    return err('مسیر نامعتبر', 404);
  } catch (error) {
    console.error('Exam PUT error:', error);
    return err('خطای سرور داخلی', 500);
  }
}

/* ─────────── DELETE Handler ─────────── */

export async function DELETE(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const pathStr = url.pathname.replace('/api/', '');
    const path = pathStr.split('/').filter(Boolean);
    const route = parsePath(path);

    // DELETE /api/exams/:id — Delete exam
    if (route.resource === 'exam' && route.id) {
      const existing = await db.exam.findUnique({ where: { id: route.id } });
      if (!existing) return err('آزمون یافت نشد', 404);

      await db.exam.delete({ where: { id: route.id } });
      return ok(null, 'آزمون با موفقیت حذف شد');
    }

    // DELETE /api/exams/questions/:id — Delete question
    if (route.resource === 'question' && route.subId) {
      const existing = await db.examQuestion.findUnique({ where: { id: route.subId } });
      if (!existing) return err('سوال یافت نشد', 404);

      await db.examQuestion.delete({ where: { id: route.subId } });
      return ok(null, 'سوال با موفقیت حذف شد');
    }

    return err('مسیر نامعتبر', 404);
  } catch (error) {
    console.error('Exam DELETE error:', error);
    return err('خطای سرور داخلی', 500);
  }
}

/* ─────────── CORS Preflight ─────────── */

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-admin-key',
      'Access-Control-Max-Age': '86400',
    },
  });
}
