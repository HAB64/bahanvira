import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * POST /api/exams/save — Save answers during exam
 * Auto-submits if time has expired
 */
export async function POST(request: NextRequest) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    if (!user.karAmuzId) {
      return NextResponse.json({ error: 'کارآموز یافت نشد' }, { status: 403 });
    }

    const body = await request.json();
    const { attemptId, answers } = body;

    if (!attemptId || !answers) {
      return NextResponse.json({ error: 'اطلاعات ناقص است' }, { status: 400 });
    }

    // Find the attempt
    const attempt = await db.examAttempt.findUnique({
      where: { id: attemptId },
      include: { exam: true },
    });

    if (!attempt || attempt.karAmuzId !== user.karAmuzId) {
      return NextResponse.json({ error: 'تلاش آزمون یافت نشد' }, { status: 404 });
    }

    if (attempt.status !== 'IN_PROGRESS') {
      return NextResponse.json({ error: 'این آزمون قبلاً تحویل داده شده است' }, { status: 400 });
    }

    // Check if time expired
    const now = new Date();
    const startedAt = new Date(attempt.startedAt);
    const deadline = new Date(startedAt.getTime() + attempt.exam.durationMinutes * 60 * 1000);
    const remainingSeconds = Math.max(0, Math.floor((deadline.getTime() - now.getTime()) / 1000));

    // Merge saved answers with new answers
    const currentAnswers = (attempt.savedAnswers as Record<string, string>) || {};
    const mergedAnswers = { ...currentAnswers, ...answers };

    if (remainingSeconds <= 0) {
      // Time expired — auto-submit
      await db.examAttempt.update({
        where: { id: attemptId },
        data: {
          savedAnswers: mergedAnswers,
          status: 'AUTO_SUBMITTED',
          submittedAt: now,
          timeSpentSec: Math.floor((now.getTime() - startedAt.getTime()) / 1000),
        },
      });

      return NextResponse.json({
        داده: {
          remainingSeconds: 0,
          autoSubmitted: true,
          message: 'زمان آزمون به پایان رسید و پاسخ‌ها به‌صورت خودکار تحویل داده شد',
        },
      });
    }

    // Save answers
    await db.examAttempt.update({
      where: { id: attemptId },
      data: { savedAnswers: mergedAnswers },
    });

    return NextResponse.json({
      داده: {
        remainingSeconds,
        autoSubmitted: false,
      },
    });
  } catch (error) {
    console.error('Exam save error:', error);
    return NextResponse.json({ error: 'خطا در ذخیره پاسخ‌ها' }, { status: 500 });
  }
}
