import { NextRequest, NextResponse } from 'next/server';
import { getPortalUserFromRequest } from '@/lib/portal-auth';
import { db } from '@/lib/db';

/**
 * GET /api/exams/attempts/[attemptId] — Get detailed attempt results
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ attemptId: string }> }
) {
  try {
    const user = await getPortalUserFromRequest(request);
    if (!user) {
      return NextResponse.json({ error: 'احراز هویت الزامی است' }, { status: 401 });
    }

    if (!user.karAmuzId) {
      return NextResponse.json({ error: 'کارآموز یافت نشد' }, { status: 403 });
    }

    const { attemptId } = await params;

    const attempt = await db.examAttempt.findUnique({
      where: { id: attemptId },
      include: {
        exam: {
          include: {
            questions: { orderBy: { order: 'asc' } },
            skillProgram: { select: { name: true } },
          },
        },
        answers: true,
      },
    });

    if (!attempt || attempt.karAmuzId !== user.karAmuzId) {
      return NextResponse.json({ error: 'تلاش آزمون یافت نشد' }, { status: 404 });
    }

    // Check if results should be shown
    const exam = attempt.exam;
    const showResults = exam.showResults;
    const now = new Date();

    if (attempt.status === 'IN_PROGRESS') {
      return NextResponse.json({ error: 'آزمون هنوز تحویل داده نشده است' }, { status: 400 });
    }

    const canShowResults =
      showResults === 'AFTER_SUBMIT' ||
      (showResults === 'AFTER_DEADLINE' && exam.closeAt && now >= exam.closeAt) ||
      (showResults === 'AFTER_DEADLINE' && !exam.closeAt);

    if (!canShowResults) {
      return NextResponse.json({
        داده: {
          attemptId: attempt.id,
          status: attempt.status,
          submittedAt: attempt.submittedAt,
          examTitle: exam.title,
          examType: exam.type,
          programName: exam.skillProgram?.name || null,
          message: showResults === 'NEVER'
            ? 'نمایش نتایج این آزمون مجاز نیست'
            : 'نتایج پس از پایان مهلت آزمون قابل مشاهده خواهد بود',
          resultsAvailableAt: showResults === 'AFTER_DEADLINE' ? exam.closeAt : null,
        },
      });
    }

    // Build question-level results
    const answerMap = new Map(attempt.answers.map(a => [a.questionId, a]));
    const questionResults = exam.questions.map(q => {
      const answer = answerMap.get(q.id);
      return {
        questionId: q.id,
        text: q.text,
        type: q.type,
        options: q.options,
        points: q.points,
        difficulty: q.difficulty,
        explanation: q.explanation,
        image: q.image,
        selectedAnswer: answer?.selectedAnswer || null,
        correctAnswer: q.correctAnswer,
        isCorrect: answer?.isCorrect ?? null,
        pointsEarned: answer?.pointsEarned ?? 0,
      };
    });

    return NextResponse.json({
      داده: {
        attemptId: attempt.id,
        status: attempt.status,
        score: attempt.score,
        maxScore: attempt.maxScore,
        percentage: attempt.percentage,
        isPassed: attempt.isPassed,
        startedAt: attempt.startedAt,
        submittedAt: attempt.submittedAt,
        timeSpentSec: attempt.timeSpentSec,
        exam: {
          id: exam.id,
          title: exam.title,
          type: exam.type,
          description: exam.description,
          passingScore: exam.passingScore,
          programName: exam.skillProgram?.name || null,
        },
        questions: questionResults,
      },
    });
  } catch (error) {
    console.error('Exam attempt fetch error:', error);
    return NextResponse.json({ error: 'خطا در دریافت نتایج آزمون' }, { status: 500 });
  }
}
