import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const N8N_API_KEY = process.env.N8N_WEBHOOK_SECRET || 'bahan-n8n-webhook-2024'

export async function POST(request: Request) {
  try {
    // Verify API key
    const signature = request.headers.get('x-n8n-signature')
    if (!signature || signature !== N8N_API_KEY) {
      return NextResponse.json({ error: 'امضای نامعتبر' }, { status: 401 })
    }

    const body = await request.json()
    const { action, payload } = body as {
      action: string
      payload: Record<string, unknown>
    }

    if (!action) {
      return NextResponse.json({ error: 'نوع عملیات الزامی است' }, { status: 400 })
    }

    let result: Record<string, unknown> = {}

    switch (action) {
      case 'CREATE_LEAD': {
        const { name, phone, email, goal, interest, source, cluster, utmSource, utmMedium, utmCampaign } = payload as {
          name?: string; phone?: string; email?: string; goal?: string; interest?: string; source?: string
          cluster?: string; utmSource?: string; utmMedium?: string; utmCampaign?: string
        }

        if (!name || !phone) {
          return NextResponse.json({ error: 'نام و شماره تلفن الزامی است' }, { status: 400 })
        }

        const lead = await db.lead.create({
          data: {
            name: String(name),
            phone: String(phone),
            email: email ? String(email) : '',
            goal: goal ? String(goal) : '',
            interest: interest ? String(interest) : '',
            source: source ? String(source) : 'n8n-webhook',
            cluster: cluster ? String(cluster) : '',
            utmSource: utmSource ? String(utmSource) : '',
            utmMedium: utmMedium ? String(utmMedium) : '',
            utmCampaign: utmCampaign ? String(utmCampaign) : '',
          },
        })

        result = { leadId: lead.id, message: 'لید با موفقیت ایجاد شد' }
        break
      }

      case 'UPDATE_LEAD_STAGE': {
        const { leadId, stage } = payload as { leadId?: string; stage?: string }

        if (!leadId || !stage) {
          return NextResponse.json({ error: 'leadId و stage الزامی هستند' }, { status: 400 })
        }

        const validStages = ['NEW', 'CONTACTED', 'INTERESTED', 'ENROLLED', 'REJECTED', 'ARCHIVED']
        if (!validStages.includes(stage)) {
          return NextResponse.json({ error: `stage باید یکی از ${validStages.join(', ')} باشد` }, { status: 400 })
        }

        const lead = await db.lead.update({
          where: { id: String(leadId) },
          data: {
            stage: String(stage),
            lastContactedAt: new Date(),
          },
        })

        result = { leadId: lead.id, stage: lead.stage, message: 'مرحله لید به‌روزرسانی شد' }
        break
      }

      case 'SEND_NOTIFICATION': {
        const { target, message, channel } = payload as { target?: string; message?: string; channel?: string }

        if (!target || !message) {
          return NextResponse.json({ error: 'target و message الزامی هستند' }, { status: 400 })
        }

        // Log notification as an event
        try {
          await db.eventLog.create({
            data: {
              event: 'NOTIFICATION_SENT',
              category: 'notification',
              label: `Channel: ${channel || 'unknown'}`,
              page: '/api/webhooks/n8n',
              metadata: { target, message: message.substring(0, 500), channel },
            },
          })
        } catch {
          // EventLog might not exist
        }

        result = { message: 'اعلان ثبت شد', target, channel: channel || 'unknown' }
        break
      }

      case 'TRIGGER_CAMPAIGN': {
        const { campaignId, segment, cluster } = payload as { campaignId?: string; segment?: string; cluster?: string }

        if (!campaignId) {
          return NextResponse.json({ error: 'campaignId الزامی است' }, { status: 400 })
        }

        // Find campaign and set it to running
        try {
          const campaign = await db.campaign.findUnique({
            where: { id: String(campaignId) },
          })

          if (!campaign) {
            return NextResponse.json({ error: 'کمپین یافت نشد' }, { status: 404 })
          }

          await db.campaign.update({
            where: { id: String(campaignId) },
            data: {
              status: 'RUNNING',
              startDate: new Date(),
              ...(segment ? { targetSegment: String(segment) } : {}),
              ...(cluster ? { targetCluster: String(cluster) } : {}),
            },
          })

          result = { campaignId, message: 'کمپین فعال شد' }
        } catch {
          result = { campaignId, message: 'خطا در فعال‌سازی کمپین' }
        }
        break
      }

      default:
        return NextResponse.json({ error: `عملیات "${action}" پشتیبانی نمی‌شود` }, { status: 400 })
    }

    return NextResponse.json({ success: true, action, result })
  } catch (error) {
    console.error('n8n webhook error:', error)
    return NextResponse.json({ error: 'خطا در پردازش وب‌هوک' }, { status: 500 })
  }
}
