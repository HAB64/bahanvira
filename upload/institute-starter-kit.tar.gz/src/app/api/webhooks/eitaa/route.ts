import { NextRequest, NextResponse } from 'next/server';
import { processInboundMessage, type InboundMessage } from '@/lib/crm/messaging-unified';
import { db } from '@/lib/db';

/**
 * POST /api/webhooks/eitaa
 * دریافت وب‌هوک از ایتا — پیام‌های دریافتی، callback queries
 *
 * نحوه تنظیم:
 *   1. دریافت bot_token از @bot_eitaayar
 *   2. تنظیم EITAA_BOT_TOKEN در .env.local
 *   3. تنظیم وب‌هوک: POST /api/crm/messaging/setup-webhook { channel: 'EITAA' }
 *   4. ایتا update ها را به این endpoint ارسال می‌کند
 */
export async function POST(request: NextRequest) {
  try {
    // اعتبارسنجی ساده — در صورت نیاز می‌توان secret_token اضافه کرد
    const botConfig = await db.messengerBotConfig.findFirst({
      where: { channel: 'EITAA', isActive: true },
    });

    if (!botConfig) {
      return NextResponse.json({ error: 'Eitaa bot not configured' }, { status: 404 });
    }

    // اعتبارسنجی token (اختیاری)
    const authHeader = request.headers.get('X-Telegram-Bot-Api-Secret-Token')
      || request.headers.get('X-Bot-Secret');
    if (botConfig.webhookSecret && authHeader !== botConfig.webhookSecret) {
      return NextResponse.json({ error: 'Invalid webhook secret' }, { status: 401 });
    }

    const body = await request.json();

    // پردازش پیام متنی
    if (body.message?.text) {
      const msg = body.message;
      const inbound: InboundMessage = {
        channel: 'EITAA',
        senderId: String(msg.chat.id),
        senderName: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' '),
        content: msg.text,
        externalId: String(msg.message_id),
        contact: {
          username: msg.from.username,
          firstName: msg.from.first_name,
          lastName: msg.from.last_name,
        },
        metadata: {
          update_id: body.update_id,
          chat_type: msg.chat.type,
        },
      };

      // پردازش async — منتظر نمان
      processInboundMessage(inbound).catch(err => {
        console.error('[Eitaa Webhook] Error processing inbound message:', err);
      });
    }

    // پردازش callback query (دکمه شیشه‌ای)
    if (body.callback_query) {
      const cb = body.callback_query;
      const inbound: InboundMessage = {
        channel: 'EITAA',
        senderId: String(cb.from.id),
        senderName: cb.from.first_name,
        content: cb.data || '',
        externalId: cb.id,
        callbackData: cb.data,
        metadata: {
          update_id: body.update_id,
          callback_query_id: cb.id,
        },
      };

      processInboundMessage(inbound).catch(err => {
        console.error('[Eitaa Webhook] Error processing callback:', err);
      });
    }

    // پردازش ارسال شماره تماس
    if (body.message?.contact) {
      const msg = body.message;
      const inbound: InboundMessage = {
        channel: 'EITAA',
        senderId: String(msg.chat.id),
        senderName: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' '),
        content: `[شماره تماس: ${msg.contact.phone_number}]`,
        externalId: String(msg.message_id),
        contact: {
          phone: msg.contact.phone_number,
          firstName: msg.contact.first_name,
          lastName: msg.contact.last_name,
        },
        metadata: {
          update_id: body.update_id,
          type: 'contact_share',
        },
      };

      processInboundMessage(inbound).catch(err => {
        console.error('[Eitaa Webhook] Error processing contact:', err);
      });
    }

    // پردازش location
    if (body.message?.location) {
      const msg = body.message;
      const inbound: InboundMessage = {
        channel: 'EITAA',
        senderId: String(msg.chat.id),
        senderName: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' '),
        content: `[موقعیت مکانی: ${msg.location.latitude}, ${msg.location.longitude}]`,
        externalId: String(msg.message_id),
        location: {
          latitude: msg.location.latitude,
          longitude: msg.location.longitude,
        },
        contact: {
          firstName: msg.from.first_name,
          lastName: msg.from.last_name,
        },
        metadata: {
          update_id: body.update_id,
          type: 'location_share',
        },
      };

      processInboundMessage(inbound).catch(err => {
        console.error('[Eitaa Webhook] Error processing location:', err);
      });
    }

    // ایتا نیاز به پاسخ 200 دارد
    return NextResponse.json({ ok: true });

  } catch (error) {
    console.error('[Eitaa Webhook] Error:', error);
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 });
  }
}

// GET برای تأیید تنظیم وب‌هوک
export async function GET(request: NextRequest) {
  const mode = new URL(request.url).searchParams.get('hub.mode');
  const token = new URL(request.url).searchParams.get('hub.verify_token');

  // بعضی پلتفرم‌ها verify می‌کنند
  return NextResponse.json({ status: 'eitaa_webhook_active', timestamp: new Date().toISOString() });
}
