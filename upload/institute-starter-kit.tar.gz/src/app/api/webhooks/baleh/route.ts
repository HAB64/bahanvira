import { NextRequest, NextResponse } from 'next/server';
import { processInboundMessage, type InboundMessage } from '@/lib/crm/messaging-unified';
import { db } from '@/lib/db';

/**
 * POST /api/webhooks/baleh
 * دریافت وب‌هوک از بله — پیام‌های دریافتی، callback queries
 *
 * بله API شبیه Telegram Bot API است
 */
export async function POST(request: NextRequest) {
  try {
    const botConfig = await db.messengerBotConfig.findFirst({
      where: { channel: 'BALEH', isActive: true },
    });

    if (!botConfig) {
      return NextResponse.json({ error: 'Baleh bot not configured' }, { status: 404 });
    }

    const authHeader = request.headers.get('X-Telegram-Bot-Api-Secret-Token')
      || request.headers.get('X-Bot-Secret');
    if (botConfig.webhookSecret && authHeader !== botConfig.webhookSecret) {
      return NextResponse.json({ error: 'Invalid webhook secret' }, { status: 401 });
    }

    const body = await request.json();

    // پردازش پیام متنی
    if (body.message?.text) {
      const msg = body.message;
      const inbound: InboundMessage = {
        channel: 'BALEH',
        senderId: String(msg.chat.id),
        senderName: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' '),
        content: msg.text,
        externalId: String(msg.message_id),
        contact: {
          username: msg.from.username,
          firstName: msg.from.first_name,
          lastName: msg.from.last_name,
        },
        metadata: {
          update_id: body.update_id,
          chat_type: msg.chat.type,
        },
      };

      processInboundMessage(inbound).catch(err => {
        console.error('[Baleh Webhook] Error processing inbound message:', err);
      });
    }

    // پردازش callback query
    if (body.callback_query) {
      const cb = body.callback_query;
      const inbound: InboundMessage = {
        channel: 'BALEH',
        senderId: String(cb.from.id),
        senderName: cb.from.first_name,
        content: cb.data || '',
        externalId: cb.id,
        callbackData: cb.data,
        metadata: {
          update_id: body.update_id,
          callback_query_id: cb.id,
        },
      };

      processInboundMessage(inbound).catch(err => {
        console.error('[Baleh Webhook] Error processing callback:', err);
      });
    }

    // پردازش ارسال شماره تماس
    if (body.message?.contact) {
      const msg = body.message;
      const inbound: InboundMessage = {
        channel: 'BALEH',
        senderId: String(msg.chat.id),
        senderName: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' '),
        content: `[شماره تماس: ${msg.contact.phone_number}]`,
        externalId: String(msg.message_id),
        contact: {
          phone: msg.contact.phone_number,
          firstName: msg.contact.first_name,
          lastName: msg.contact.last_name,
        },
        metadata: { update_id: body.update_id, type: 'contact_share' },
      };

      processInboundMessage(inbound).catch(err => {
        console.error('[Baleh Webhook] Error processing contact:', err);
      });
    }

    // پردازش location
    if (body.message?.location) {
      const msg = body.message;
      const inbound: InboundMessage = {
        channel: 'BALEH',
        senderId: String(msg.chat.id),
        senderName: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' '),
        content: `[موقعیت مکانی: ${msg.location.latitude}, ${msg.location.longitude}]`,
        externalId: String(msg.message_id),
        location: { latitude: msg.location.latitude, longitude: msg.location.longitude },
        contact: { firstName: msg.from.first_name, lastName: msg.from.last_name },
        metadata: { update_id: body.update_id, type: 'location_share' },
      };

      processInboundMessage(inbound).catch(err => {
        console.error('[Baleh Webhook] Error processing location:', err);
      });
    }

    return NextResponse.json({ ok: true });

  } catch (error) {
    console.error('[Baleh Webhook] Error:', error);
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  return NextResponse.json({ status: 'baleh_webhook_active', timestamp: new Date().toISOString() });
}
