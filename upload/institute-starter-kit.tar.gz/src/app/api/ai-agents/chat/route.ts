/**
 * POST /api/ai-agents/chat — شروع یا ادامه مکالمه با عامل AI
 *
 * Body: { agentId?, conversationId?, message, context? }
 * - اگر conversationId نباشد، مکالمه جدید شروع می‌شود
 * - اگر conversationId باشد، مکالمه ادامه می‌یابد
 * - خروجی: { conversationId, reply, suggestedActions, sentiment }
 */

import { NextRequest, NextResponse } from 'next/server';
import { startConversation, sendMessage } from '@/lib/ai/agent-engine';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { agentId, conversationId, message, context, leadId, karAmuzId, channel } = body;

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return NextResponse.json(
        { error: 'پیام الزامی است' },
        { status: 400 }
      );
    }

    // محدودیت طول پیام
    if (message.length > 2000) {
      return NextResponse.json(
        { error: 'پیام خیلی طولانی است (حداکثر ۲۰۰۰ کاراکتر)' },
        { status: 400 }
      );
    }

    let convId = conversationId;

    // اگر مکالمه‌ای وجود ندارد، مکالمه جدید شروع کن
    if (!convId) {
      if (!agentId) {
        return NextResponse.json(
          { error: 'شناسه عامل یا مکالمه الزامی است' },
          { status: 400 }
        );
      }

      const conversation = await startConversation({
        agentId,
        leadId,
        karAmuzId,
        channel: channel || 'WEB',
        context,
      });

      convId = conversation.id;
    }

    // ارسال پیام و دریافت پاسخ
    const result = await sendMessage(convId, message.trim());

    return NextResponse.json(result);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'خطای ناشناخته';
    console.error('Error in AI chat:', error);

    // اگر خطای شناخته‌شده است
    if (errorMessage.includes('یافت نشد') || errorMessage.includes('غیرفعال')) {
      return NextResponse.json({ error: errorMessage }, { status: 400 });
    }

    return NextResponse.json(
      { error: 'خطا در پردازش پیام. لطفاً دوباره تلاش کنید.' },
      { status: 500 }
    );
  }
}
