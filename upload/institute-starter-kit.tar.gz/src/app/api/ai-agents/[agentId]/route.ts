/**
 * GET /api/ai-agents/[agentId] — دریافت جزئیات عامل با آمار
 * PUT /api/ai-agents/[agentId] — به‌روزرسانی تنظیمات عامل
 * DELETE /api/ai-agents/[agentId] — حذف عامل
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { db } from '@/lib/db';
import { getAgentStats } from '@/lib/ai/agent-engine';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ agentId: string }> }
) {
  try {
    const admin = await getAdminSession(request);
    if (!admin) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 401 });
    }

    const { agentId } = await params;
    const stats = await getAgentStats(agentId);

    if (!stats) {
      return NextResponse.json({ error: 'عامل یافت نشد' }, { status: 404 });
    }

    return NextResponse.json(stats);
  } catch (error) {
    console.error('Error fetching agent:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت اطلاعات عامل' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ agentId: string }> }
) {
  try {
    const admin = await getAdminSession(request);
    if (!admin) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 401 });
    }

    const { agentId } = await params;
    const body = await request.json();

    const updateData: Record<string, unknown> = {};
    const allowedFields = [
      'name', 'description', 'systemPrompt', 'isActive',
      'maxConversations', 'responseDelayMs', 'handoffToHuman', 'handoffCondition',
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field];
      }
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json(
        { error: 'هیچ فیلدی برای به‌روزرسانی مشخص نشده' },
        { status: 400 }
      );
    }

    const agent = await db.aIAgent.update({
      where: { id: agentId },
      data: updateData,
    });

    return NextResponse.json({ agent });
  } catch (error) {
    console.error('Error updating agent:', error);
    return NextResponse.json(
      { error: 'خطا در به‌روزرسانی عامل' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ agentId: string }> }
) {
  try {
    const admin = await getAdminSession(request);
    if (!admin) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 401 });
    }

    const { agentId } = await params;

    // بررسی وجود مکالمات فعال
    const activeConversations = await db.aIAgentConversation.count({
      where: { agentId, status: 'ACTIVE' },
    });

    if (activeConversations > 0) {
      return NextResponse.json(
        { error: `عامل ${activeConversations} مکالمه فعال دارد. ابتدا مکالمات را پایان دهید.` },
        { status: 400 }
      );
    }

    await db.aIAgent.delete({
      where: { id: agentId },
    });

    return NextResponse.json({ message: 'عامل حذف شد' });
  } catch (error) {
    console.error('Error deleting agent:', error);
    return NextResponse.json(
      { error: 'خطا در حذف عامل' },
      { status: 500 }
    );
  }
}
