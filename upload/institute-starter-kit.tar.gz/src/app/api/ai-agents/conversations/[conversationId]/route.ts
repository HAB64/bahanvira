/**
 * GET /api/ai-agents/conversations/[conversationId] — دریافت مکالمه با تمام پیام‌ها
 * PUT /api/ai-agents/conversations/[conversationId] — به‌روزرسانی مکالمه (پایان، ارجاع)
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { db } from '@/lib/db';
import { endConversation, handoffToHuman } from '@/lib/ai/agent-engine';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ conversationId: string }> }
) {
  try {
    const admin = await getAdminSession(request);
    if (!admin) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 401 });
    }

    const { conversationId } = await params;

    const conversation = await db.aIAgentConversation.findUnique({
      where: { id: conversationId },
      include: {
        agent: {
          select: { id: true, name: true, type: true },
        },
        messages: {
          orderBy: { createdAt: 'asc' },
        },
      },
    });

    if (!conversation) {
      return NextResponse.json({ error: 'مکالمه یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ conversation });
  } catch (error) {
    console.error('Error fetching conversation:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت مکالمه' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ conversationId: string }> }
) {
  try {
    const admin = await getAdminSession(request);
    if (!admin) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 401 });
    }

    const { conversationId } = await params;
    const body = await request.json();
    const { action, outcome, reason } = body;

    if (action === 'end') {
      const conversation = await endConversation(conversationId, outcome || 'INFORMED');
      return NextResponse.json({ conversation });
    }

    if (action === 'handoff') {
      if (!reason) {
        return NextResponse.json(
          { error: 'دلیل ارجاع الزامی است' },
          { status: 400 }
        );
      }
      const conversation = await handoffToHuman(conversationId, reason);
      return NextResponse.json({ conversation });
    }

    return NextResponse.json(
      { error: 'عملیات نامعتبر. از "end" یا "handoff" استفاده کنید.' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Error updating conversation:', error);
    return NextResponse.json(
      { error: 'خطا در به‌روزرسانی مکالمه' },
      { status: 500 }
    );
  }
}
