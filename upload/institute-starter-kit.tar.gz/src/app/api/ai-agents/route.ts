/**
 * GET /api/ai-agents — لیست عامل‌های AI با آمار
 * POST /api/ai-agents — ایجاد عامل AI جدید
 */

import { NextRequest, NextResponse } from 'next/server';
import { getAdminSession } from '@/lib/admin-auth';
import { db } from '@/lib/db';
import { createAgent, seedDefaultAgents } from '@/lib/ai/agent-engine';
import type { AgentType } from '@/lib/ai/agent-engine';

export async function GET(request: NextRequest) {
  try {
    const admin = await getAdminSession(request);
    if (!admin) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 401 });
    }

    const agents = await db.aIAgent.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: {
          select: { conversations: true },
        },
      },
    });

    // دریافت آمار هر عامل
    const agentsWithStats = await Promise.all(
      agents.map(async (agent) => {
        const totalConversations = await db.aIAgentConversation.count({
          where: { agentId: agent.id },
        });

        const activeConversations = await db.aIAgentConversation.count({
          where: { agentId: agent.id, status: 'ACTIVE' },
        });

        const enrolledConversations = await db.aIAgentConversation.count({
          where: { agentId: agent.id, outcome: 'ENROLLED' },
        });

        const handedOffConversations = await db.aIAgentConversation.count({
          where: { agentId: agent.id, status: 'HANDED_OFF' },
        });

        const conversionRate = totalConversations > 0
          ? Math.round((enrolledConversations / totalConversations) * 1000) / 10
          : 0;

        return {
          ...agent,
          stats: {
            totalConversations,
            activeConversations,
            enrolledConversations,
            handedOffConversations,
            conversionRate,
          },
        };
      })
    );

    return NextResponse.json({ agents: agentsWithStats });
  } catch (error) {
    console.error('Error fetching AI agents:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت عامل‌ها' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const admin = await getAdminSession(request);
    if (!admin) {
      return NextResponse.json({ error: 'دسترسی غیرمجاز' }, { status: 401 });
    }

    const body = await request.json();
    const { name, type, description, systemPrompt, isActive, maxConversations, responseDelayMs, handoffToHuman, handoffCondition } = body;

    if (!name || !type) {
      return NextResponse.json(
        { error: 'نام و نوع عامل الزامی است' },
        { status: 400 }
      );
    }

    const validTypes: AgentType[] = ['SALES', 'SUPPORT', 'CONSULTANT', 'FOLLOW_UP', 'RETENTION'];
    if (!validTypes.includes(type)) {
      return NextResponse.json(
        { error: 'نوع عامل نامعتبر است' },
        { status: 400 }
      );
    }

    const agent = await createAgent({
      name,
      type,
      description,
      systemPrompt,
      isActive,
      maxConversations,
      responseDelayMs,
      handoffToHuman,
      handoffCondition,
    });

    // اگر درخواست seed است
    if (body.action === 'seed') {
      const result = await seedDefaultAgents();
      return NextResponse.json(result);
    }

    return NextResponse.json({ agent }, { status: 201 });
  } catch (error) {
    console.error('Error creating AI agent:', error);
    return NextResponse.json(
      { error: 'خطا در ایجاد عامل' },
      { status: 500 }
    );
  }
}
