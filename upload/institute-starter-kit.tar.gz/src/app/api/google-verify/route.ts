import { NextResponse } from "next/server";

export async function GET() {
  return new NextResponse("google-site-verification: googlec78c0e1dea756f41.html", {
    status: 200,
    headers: {
      "Content-Type": "text/plain",
    },
  });
}
