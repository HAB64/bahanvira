import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { executeAutomationRules, seedDefaultAutomationRules } from '@/lib/crm/automation-engine';

/**
 * POST /api/leads
 * Public endpoint for lead creation from website forms (hero, career quiz, etc.)
 * Auto lead-scoring + automation trigger.
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      name,
      phone,
      email,
      goal,
      level,
      interest,
      course,
      company,
      serviceType,
      message,
      result,
      source,
      cluster,
      assignedTo,
      utmSource,
      utmMedium,
      utmCampaign,
    } = body;

    // Validate required fields
    if (!name || !phone) {
      return NextResponse.json(
        { error: 'نام و شماره تماس الزامی است' },
        { status: 400 }
      );
    }

    // Validate phone format (Iranian mobile)
    const phoneRegex = /^09[0-9]{9}$/;
    if (!phoneRegex.test(phone)) {
      return NextResponse.json(
        { error: 'شماره موبایل نامعتبر است (فرمت: 09123456789)' },
        { status: 400 }
      );
    }

    // Auto lead-scoring logic
    let score = 30; // Base score

    // +20 if course specified (high intent)
    if (course && course.trim() !== '') {
      score += 20;
    }

    // +15 if cluster is "finance" or "tech-ai" (high-value clusters)
    if (cluster === 'finance' || cluster === 'tech-ai') {
      score += 15;
    }

    // +10 if source is "hero-form" (direct inquiry)
    if (source === 'hero-form') {
      score += 10;
    }

    // +15 if phone is valid Iranian mobile (already validated above)
    score += 15;

    // +10 if email provided
    if (email && email.trim() !== '') {
      score += 10;
    }

    // Cap at 100
    score = Math.min(score, 100);

    // Auto-segment based on score
    let segment = 'NEW';
    if (score >= 80) segment = 'VIP';
    else if (score >= 50) segment = 'REGULAR';

    const lead = await db.lead.create({
      data: {
        name,
        phone,
        email: email || '',
        goal: goal || '',
        level: level || '',
        interest: interest || '',
        course: course || '',
        company: company || '',
        serviceType: serviceType || '',
        message: message || '',
        result: result || null,
        source: source || 'career-quiz',
        stage: 'NEW',
        score,
        cluster: cluster || '',
        assignedTo: assignedTo || '',
        utmSource: utmSource || '',
        utmMedium: utmMedium || '',
        utmCampaign: utmCampaign || '',
        segment,
      },
    });

    // Ensure default automation rules exist
    await seedDefaultAutomationRules();

    // Execute automation rules: LEAD_CREATED (async — don't block response)
    executeAutomationRules('LEAD_CREATED', {
      leadId: lead.id,
      stage: 'NEW',
      cluster: lead.cluster,
      assignedTo: lead.assignedTo,
      leadName: lead.name,
      leadPhone: lead.phone,
      courseTitle: course || '',
    }).catch((err) => {
      console.error('Automation execution error (LEAD_CREATED):', err);
    });

    return NextResponse.json({ success: true, id: lead.id }, { status: 201 });
  } catch (error) {
    console.error('Lead creation error:', error);
    return NextResponse.json(
      { error: 'خطا در ثبت اطلاعات' },
      { status: 500 }
    );
  }
}
