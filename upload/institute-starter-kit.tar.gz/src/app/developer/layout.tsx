import { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: `Developer Portal | ${siteConfig.name.fullName}`,
  description: `API Marketplace و مستندات توسعه‌دهندگان پلتفرم ${siteConfig.name.fa}. اپلیکیشن‌ها، افزونه‌ها و اتصالات.`,
  robots: { index: true, follow: true },
  alternates: {
    canonical: `${siteConfig.url.base}/developer`,
  },
};

export default function DeveloperLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
