'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Package,
  Search,
  Star,
  Download,
  ExternalLink,
  Code2,
  CreditCard,
  BarChart3,
  MessageSquare,
  Zap,
  Plug,
  ArrowLeft,
  ChevronRight,
  Free,
} from 'lucide-react';

/* ──── Types ──── */

interface PublicApp {
  id: string;
  name: string;
  slug: string;
  shortDesc: string | null;
  category: string;
  iconUrl: string | null;
  pricingModel: string;
  price: number;
  monthlyPrice: number | null;
  downloads: number;
  rating: number;
  reviewCount: number;
  developerName: string | null;
  version: string;
  createdAt: string;
}

interface CategoryCount {
  category: string;
  _count: number;
}

/* ──── Helpers ──── */

const categoryLabels: Record<string, string> = {
  INTEGRATION: 'اتصال',
  PLUGIN: 'افزونه',
  ANALYTICS: 'تحلیل',
  PAYMENT: 'پرداخت',
  COMMUNICATION: 'ارتباط',
  OTHER: 'سایر',
};

const categoryIcons: Record<string, unknown> = {
  INTEGRATION: Plug,
  PLUGIN: Package,
  ANALYTICS: BarChart3,
  PAYMENT: CreditCard,
  COMMUNICATION: MessageSquare,
  OTHER: Zap,
};

const pricingLabels: Record<string, string> = {
  FREE: 'رایگان',
  ONE_TIME: 'یک‌باره',
  SUBSCRIPTION: 'اشتراکی',
  USAGE_BASED: 'مبتنی بر مصرف',
};

const pricingColors: Record<string, string> = {
  FREE: 'bg-green-100 text-green-700',
  ONE_TIME: 'bg-blue-100 text-blue-700',
  SUBSCRIPTION: 'bg-purple-100 text-purple-700',
  USAGE_BASED: 'bg-amber-100 text-amber-700',
};

function formatPrice(price: number, model: string): string {
  if (model === 'FREE') return 'رایگان';
  return price.toLocaleString('fa-IR') + ' ریال';
}

function renderStars(rating: number) {
  return Array.from({ length: 5 }, (_, i) => (
    <Star
      key={i}
      className={`w-3 h-3 ${i < Math.round(rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'}`}
    />
  ));
}

const categoryColors: Record<string, string> = {
  INTEGRATION: 'bg-indigo-100 text-indigo-700',
  PLUGIN: 'bg-teal-100 text-teal-700',
  ANALYTICS: 'bg-cyan-100 text-cyan-700',
  PAYMENT: 'bg-emerald-100 text-emerald-700',
  COMMUNICATION: 'bg-rose-100 text-rose-700',
  OTHER: 'bg-gray-100 text-gray-700',
};

/* ──── Main ──── */

export default function DeveloperPortalPage() {
  const [apps, setApps] = useState<PublicApp[]>([]);
  const [categories, setCategories] = useState<CategoryCount[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'popular' | 'rating'>('newest');

  const fetchApps = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (activeCategory !== 'all') params.set('category', activeCategory);
      if (search) params.set('search', search);
      params.set('sort', sortBy);

      const res = await fetch(`/api/marketplace?${params}`);
      const data = await res.json();

      if (res.ok) {
        setApps(data.apps || []);
        setCategories(data.categories || []);
      }
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  }, [activeCategory, search, sortBy]);

  useEffect(() => {
    fetchApps();
  }, [fetchApps]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white" dir="rtl">
      {/* Hero */}
      <div className="bg-gradient-to-l from-teal-600 to-teal-700 text-white">
        <div className="max-w-6xl mx-auto px-6 py-16">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-white/20 backdrop-blur-sm">
              <Code2 className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-3xl font-black">Developer Portal</h1>
              <p className="text-teal-100 text-sm">API Marketplace بهان رایانه</p>
            </div>
          </div>
          <p className="text-teal-100 max-w-2xl leading-relaxed text-base">
            اپلیکیشن‌ها، افزونه‌ها و اتصالاتی که پلتفرم آموزشی شما را قدرتمندتر می‌کنند.
            از درگاه‌های پرداخت ایرانی تا ابزارهای تحلیل داده — همه در یک مکان.
          </p>

          {/* Search */}
          <div className="mt-8 max-w-xl">
            <div className="relative">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-teal-300" />
              <Input
                placeholder="جستجوی اپلیکیشن..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-12 h-12 bg-white/10 border-white/20 text-white placeholder:text-teal-200 focus:bg-white/20 text-base"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Stats Bar */}
        <div className="flex items-center gap-6 mb-8 flex-wrap">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Package className="w-4 h-4 text-teal-600" />
            <span className="font-bold">{apps.length}</span> اپلیکیشن
          </div>
          <div className="flex items-center gap-4">
            {categories.map((cat) => (
              <button
                key={cat.category}
                onClick={() => setActiveCategory(activeCategory === cat.category ? 'all' : cat.category)}
                className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                  activeCategory === cat.category
                    ? 'bg-teal-50 border-teal-200 text-teal-700 font-bold'
                    : 'bg-white border-gray-200 text-gray-600 hover:border-teal-200'
                }`}
              >
                {categoryLabels[cat.category] || cat.category} ({cat._count})
              </button>
            ))}
          </div>
          <div className="mr-auto flex items-center gap-2">
            <span className="text-xs text-gray-500">مرتب‌سازی:</span>
            {[
              { key: 'newest', label: 'جدیدترین' },
              { key: 'popular', label: 'محبوب‌ترین' },
              { key: 'rating', label: 'بالاترین امتیاز' },
            ].map((s) => (
              <button
                key={s.key}
                onClick={() => setSortBy(s.key as typeof sortBy)}
                className={`text-xs px-2 py-1 rounded ${
                  sortBy === s.key ? 'bg-teal-50 text-teal-700 font-bold' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        {/* Apps Grid */}
        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-52 rounded-xl" />
            ))}
          </div>
        ) : apps.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-16 text-center">
              <Package className="w-16 h-16 text-gray-200 mx-auto mb-4" />
              <p className="text-gray-500 font-medium text-lg">اپلیکیشنی یافت نشد</p>
              <p className="text-gray-400 text-sm mt-1">فیلترها را تغییر دهید یا عبارت دیگری جستجو کنید</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {apps.map((app) => {
              const CatIcon = (categoryIcons[app.category] as React.ComponentType<{ className?: string }>) || Zap;
              return (
                <Card
                  key={app.id}
                  className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer group"
                >
                  <CardContent className="p-5">
                    <div className="flex items-start gap-3 mb-3">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${categoryColors[app.category] || 'bg-gray-100'}`}>
                        {app.iconUrl ? (
                          <img src={app.iconUrl} alt={app.name} className="w-8 h-8" />
                        ) : (
                          <CatIcon className="w-6 h-6" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-gray-900 text-sm group-hover:text-teal-700 transition-colors truncate">
                          {app.name}
                        </h3>
                        <p className="text-xs text-gray-400 font-mono">v{app.version}</p>
                      </div>
                    </div>

                    <p className="text-sm text-gray-600 leading-relaxed mb-3 line-clamp-2">
                      {app.shortDesc || app.description?.substring(0, 100) + '...'}
                    </p>

                    <div className="flex items-center gap-2 mb-3 flex-wrap">
                      <Badge className={`${categoryColors[app.category] || 'bg-gray-100'} text-[10px] border-0`}>
                        {categoryLabels[app.category] || app.category}
                      </Badge>
                      <Badge className={`${pricingColors[app.pricingModel] || 'bg-gray-100'} text-[10px] border-0`}>
                        {pricingLabels[app.pricingModel] || app.pricingModel}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-gray-50">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          {renderStars(app.rating)}
                          <span className="text-xs text-gray-400 mr-1">({app.reviewCount})</span>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-gray-400">
                          <Download className="w-3 h-3" />
                          {app.downloads.toLocaleString('fa-IR')}
                        </div>
                      </div>
                      <div className="text-sm font-bold text-teal-700">
                        {formatPrice(app.price, app.pricingModel)}
                      </div>
                    </div>

                    {app.developerName && (
                      <p className="text-xs text-gray-400 mt-2">توسعه‌دهنده: {app.developerName}</p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* API Documentation CTA */}
        <Card className="border-0 shadow-sm mt-12 bg-gradient-to-l from-gray-50 to-white">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200">
                <Code2 className="w-10 h-10 text-teal-600" />
              </div>
              <div className="flex-1 text-center md:text-right">
                <h3 className="font-bold text-gray-900 text-lg mb-1">API Documentation</h3>
                <p className="text-gray-500 text-sm leading-relaxed">
                  مستندات کامل API پلتفرم بهان رایانه — شامل احراز هویت OAuth 2.0، SDK برای JavaScript و Python، محیط Sandbox و نمونه کد.
                </p>
              </div>
              <Button className="bg-teal-600 hover:bg-teal-700 text-white gap-2">
                <ExternalLink className="w-4 h-4" />
                مشاهده مستندات
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
