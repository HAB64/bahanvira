import { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: 'سامانه اشتغال | از آموزش تا اشتغال',
  description:
    'سامانه اشتغال آموزشگاه بهان رایانه — اتصال فارغ‌التحصیلان به فرصت‌های شغلی محمودآباد و مازندران. ثبت‌نام کارجو و کارفرما، کاریابی رایگان.',
  keywords: [
    'کاریابی محمودآباد',
    'استخدام مازندران',
    'فرصت شغلی محمودآباد',
    'فارغ‌التحصیلان بهان رایانه',
    'از آموزش تا اشتغال',
    'ثبت‌نام کارجو',
    'ثبت‌نام کارفرما',
  ],
  openGraph: {
    title: 'سامانه اشتغال بهان رایانه | از آموزش تا اشتغال',
    description:
      'فرصت‌های شغلی مناسب فارغ‌التحصیلان — ثبت‌نام رایگان کارجو و کارفرما در محمودآباد مازندران',
    type: 'website',
    locale: 'fa_IR',
    siteName: siteConfig.name.fa,
    url: `${siteConfig.url.base}/jobs`,
  },
  twitter: {
    card: 'summary_large_image',
    title: 'سامانه اشتغال بهان رایانه',
    description: 'فرصت‌های شغلی مناسب فارغ‌التحصیلان — از آموزش تا اشتغال',
  },
  alternates: {
    canonical: `${siteConfig.url.base}/jobs`,
  },
};

export default function JobsLayout({ children }: { children: React.ReactNode }) {
  return children;
}
