'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowRight, CheckCircle, Building2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function RegisterEmployerPage() {
  const [form, setForm] = useState({
    companyName: '', contactPerson: '', phone: '', email: '',
    address: '', city: 'Mahmoudabad', industry: '', website: '', description: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.companyName || !form.contactPerson || !form.phone) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/employment/employers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, source: 'WEB_FORM' }),
      });
      const data = await res.json();
      if (data?.پیام) {
        setSuccess(true);
      } else {
        alert(data?.خطا || 'خطا در ثبت‌نام');
      }
    } catch {
      alert('خطا در ثبت‌نام. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center" dir="rtl">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="p-8 text-center">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 mb-2">ثبت‌نام با موفقیت انجام شد!</h2>
            <p className="text-sm text-gray-500 mb-6">
              اطلاعات شرکت شما ثبت شد. پس از بررسی و تأیید توسط تیم ما، می‌توانید فرصت‌های شغلی ثبت کنید.
            </p>
            <Link href="/jobs">
              <Button className="gap-2">
                <ArrowRight className="h-4 w-4" /> بازگشت به فرصت‌های شغلی
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-purple-600 to-purple-700 text-white">
        <div className="max-w-3xl mx-auto px-4 py-10">
          <Link href="/jobs" className="text-purple-200 hover:text-white text-sm flex items-center gap-1 mb-4">
            <ArrowRight className="h-4 w-4" /> بازگشت به فرصت‌های شغلی
          </Link>
          <h1 className="text-2xl sm:text-3xl font-bold">ثبت‌نام کارفرما</h1>
          <p className="text-purple-100 mt-2">شرکت خود را ثبت کنید تا فارغ‌التحصیلان ماهر را استخدام کنید</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        <form onSubmit={handleSubmit}>
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Building2 className="h-5 w-5 text-purple-600" /> اطلاعات شرکت</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2"><Label>نام شرکت / سازمان *</Label><Input value={form.companyName} onChange={e => setForm({ ...form, companyName: e.target.value })} required /></div>
              <div><Label>نام شخص مسئول *</Label><Input value={form.contactPerson} onChange={e => setForm({ ...form, contactPerson: e.target.value })} required /></div>
              <div><Label>شماره تماس *</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="01144746665" required /></div>
              <div><Label>ایمیل</Label><Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
              <div><Label>شهر</Label><Input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
              <div><Label>صنعت / حوزه فعالیت</Label><Input value={form.industry} onChange={e => setForm({ ...form, industry: e.target.value })} placeholder="فناوری اطلاعات، مالی، آموزش، ..." /></div>
              <div><Label>وب‌سایت</Label><Input value={form.website} onChange={e => setForm({ ...form, website: e.target.value })} placeholder="https://example.com" /></div>
              <div className="sm:col-span-2"><Label>آدرس</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
              <div className="sm:col-span-2"><Label>توضیحات شرکت</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} placeholder="معرفی مختصر شرکت و حوزه فعالیت..." /></div>
            </CardContent>
          </Card>

          <Button type="submit" size="lg" className="w-full mt-6 gap-2 bg-purple-600 hover:bg-purple-700" disabled={submitting}>
            {submitting ? 'در حال ثبت...' : 'ثبت‌نام'}
          </Button>
        </form>
      </div>
    </div>
  );
}
