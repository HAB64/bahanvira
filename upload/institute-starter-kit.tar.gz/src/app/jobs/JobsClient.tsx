'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import {
  Briefcase, Search, MapPin, Clock, Building2,
  ChevronLeft, Users, ArrowRight,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface JobListing {
  id: string; title: string; description: string;
  category: string; jobType: string; experienceLevel: string;
  salaryMin: number | null; salaryMax: number | null;
  requiredSkills: string; city: string; isRemote: boolean;
  deadline: string | null; createdAt: string;
  employer: { id: string; companyName: string; city: string; isVerified: boolean };
  _count: { applications: number };
}

const jobTypeLabels: Record<string, string> = {
  FULL_TIME: 'تمام‌وقت', PART_TIME: 'پاره‌وقت', CONTRACT: 'قراردادی',
  INTERNSHIP: 'کارآموزی', REMOTE: 'دورکاری',
};
const categoryLabels: Record<string, string> = {
  'tech-ai': 'فناوری و AI', financial: 'بازارهای مالی', management: 'مدیریت', other: 'سایر',
};
const expLabels: Record<string, string> = {
  JUNIOR: 'تازه‌کار', MID: 'متوسط', SENIOR: 'ارشد', ENTRY_LEVEL: 'مبتدی',
};

const categoryColors: Record<string, string> = {
  'tech-ai': 'from-teal-500 to-cyan-500',
  financial: 'from-amber-500 to-orange-500',
  management: 'from-purple-500 to-violet-500',
  other: 'from-gray-500 to-slate-500',
};

export default function JobsClient() {
  const [jobs, setJobs] = useState<JobListing[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [jobType, setJobType] = useState('');
  const [loading, setLoading] = useState(true);
  const [applyDialogOpen, setApplyDialogOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState<JobListing | null>(null);
  const [applyForm, setApplyForm] = useState({ name: '', phone: '', email: '', coverLetter: '', proposedSalary: '' });
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: '12', status: 'ACTIVE' });
      if (search) params.set('search', search);
      if (category) params.set('category', category);
      if (jobType) params.set('jobType', jobType);
      const res = await fetch(`/api/crm/employment/job-listings?${params}`);
      const data = await res.json();
      setJobs(data?.داده‌ها || []);
      setTotal(data?.صفحه‌بندی?.کل || 0);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, search, category, jobType]);

  useEffect(() => { fetchJobs(); }, [fetchJobs]);

  const handleApply = async () => {
    if (!selectedJob || !applyForm.name || !applyForm.phone) return;
    setSubmitting(true);
    try {
      const [firstName, ...rest] = applyForm.name.split(' ');
      const lastName = rest.join(' ') || firstName;
      const seekerRes = await fetch('/api/crm/employment/job-seekers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ firstName, lastName, phone: applyForm.phone, email: applyForm.email, source: 'WEB_FORM' }),
      });
      const seekerData = await seekerRes.json();
      if (!seekerData?.داده?.id) {
        alert('خطا در ثبت اطلاعات. لطفاً دوباره تلاش کنید.');
        return;
      }
      const appRes = await fetch('/api/crm/employment/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobListingId: selectedJob.id,
          jobSeekerId: seekerData.داده.id,
          coverLetter: applyForm.coverLetter || null,
          proposedSalary: applyForm.proposedSalary ? parseInt(applyForm.proposedSalary) : null,
        }),
      });
      const appData = await appRes.json();
      if (appData?.پیام) {
        setSuccessMsg('درخواست شما با موفقیت ثبت شد! با شما تماس خواهیم گرفت.');
        setApplyDialogOpen(false);
        setApplyForm({ name: '', phone: '', email: '', coverLetter: '', proposedSalary: '' });
        setTimeout(() => setSuccessMsg(''), 5000);
      } else {
        alert(appData?.خطا || 'خطا در ثبت درخواست');
      }
    } catch (e) {
      console.error(e);
      alert('خطا در ثبت درخواست');
    } finally {
      setSubmitting(false);
    }
  };

  const openApply = (job: JobListing) => {
    setSelectedJob(job);
    setApplyDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Hero */}
      <div className="bg-gradient-to-l from-teal-600 to-teal-700 text-white">
        <div className="max-w-7xl mx-auto px-4 py-12 sm:py-16">
          <div className="max-w-2xl">
            <h1 className="text-3xl sm:text-4xl font-bold mb-4">فرصت‌های شغلی</h1>
            <p className="text-teal-100 text-lg mb-6">
              فرصت‌های شغلی مناسب فارغ‌التحصیلان و متخصصان — از آموزش تا اشتغال
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/jobs/register-seeker">
                <Button className="bg-white text-teal-700 hover:bg-teal-50 gap-2">
                  <Users className="h-4 w-4" /> ثبت‌نام کارجو
                </Button>
              </Link>
              <Link href="/jobs/register-employer">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 gap-2">
                  <Building2 className="h-4 w-4" /> ثبت‌نام کارفرما
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {successMsg && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-800 text-sm">
            {successMsg}
          </div>
        )}

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-3 items-center">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input placeholder="جستجوی عنوان، مهارت..." value={search}
                  onChange={e => { setSearch(e.target.value); setPage(1); }} className="pr-9" />
              </div>
              <Tabs value={category || 'all'} onValueChange={v => { setCategory(v === 'all' ? '' : v); setPage(1); }}>
                <TabsList>
                  <TabsTrigger value="all">همه</TabsTrigger>
                  <TabsTrigger value="tech-ai">فناوری</TabsTrigger>
                  <TabsTrigger value="financial">مالی</TabsTrigger>
                  <TabsTrigger value="management">مدیریت</TabsTrigger>
                </TabsList>
              </Tabs>
              <Select value={jobType || 'ALL'} onValueChange={v => { setJobType(v === 'ALL' ? '' : v); setPage(1); }}>
                <SelectTrigger className="w-32"><SelectValue placeholder="نوع شغل" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">همه</SelectItem>
                  {Object.entries(jobTypeLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Job Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-teal-600 border-t-transparent" />
          </div>
        ) : jobs.length === 0 ? (
          <div className="text-center py-20">
            <Briefcase className="h-16 w-16 text-gray-200 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-500">فرصت شغلی فعالی یافت نشد</h3>
            <p className="text-sm text-gray-400 mt-1">بعداً دوباره مراجعه کنید</p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link href="/jobs/register-seeker">
                <Button variant="outline" className="gap-2">
                  <Users className="h-4 w-4" /> ثبت‌نام کارجو
                </Button>
              </Link>
              <Link href="/jobs/register-employer">
                <Button variant="outline" className="gap-2">
                  <Building2 className="h-4 w-4" /> ثبت‌نام کارفرما
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {jobs.map(job => {
              const catColor = categoryColors[job.category] || categoryColors.other;
              return (
                <Card key={job.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-5">
                    {/* Category Badge */}
                    <div className="flex items-center gap-2 mb-3">
                      <div className={`px-2.5 py-1 rounded-full text-xs text-white bg-gradient-to-l ${catColor}`}>
                        {categoryLabels[job.category] || 'سایر'}
                      </div>
                      {job.isRemote && (
                        <Badge variant="secondary" className="bg-blue-50 text-blue-700 text-xs">دورکاری</Badge>
                      )}
                      {job.employer?.isVerified && (
                        <Badge variant="secondary" className="bg-green-50 text-green-700 text-xs">تأیید شده</Badge>
                      )}
                    </div>

                    <h3 className="font-bold text-gray-900 text-lg mb-1">{job.title}</h3>
                    <p className="text-sm text-gray-500 flex items-center gap-1 mb-3">
                      <Building2 className="h-3.5 w-3.5" /> {job.employer?.companyName}
                    </p>

                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="outline" className="text-xs gap-1">
                        <Clock className="h-3 w-3" /> {jobTypeLabels[job.jobType] || job.jobType}
                      </Badge>
                      <Badge variant="outline" className="text-xs gap-1">
                        <MapPin className="h-3 w-3" /> {job.city}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {expLabels[job.experienceLevel] || job.experienceLevel}
                      </Badge>
                    </div>

                    {/* Salary */}
                    {(job.salaryMin || job.salaryMax) && (
                      <p className="text-sm font-medium text-teal-700 mb-3">
                        {job.salaryMin ? `${(job.salaryMin / 1000000).toFixed(0)}` : '?'} - {job.salaryMax ? `${(job.salaryMax / 1000000).toFixed(0)}` : '?'} میلیون ریال
                      </p>
                    )}

                    {/* Skills */}
                    {job.requiredSkills && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {job.requiredSkills.split(',').slice(0, 3).map((s, i) => (
                          <span key={i} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{s.trim()}</span>
                        ))}
                        {job.requiredSkills.split(',').length > 3 && (
                          <span className="text-xs text-gray-400">+{job.requiredSkills.split(',').length - 3}</span>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-100">
                      <span className="text-xs text-gray-400">{new Date(job.createdAt).toLocaleDateString('fa-IR')}</span>
                      <Button size="sm" onClick={() => openApply(job)} className="gap-1">
                        ارسال رزومه <ArrowRight className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {total > 12 && (
          <div className="flex items-center justify-center gap-3 mt-8">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
              <ChevronLeft className="h-4 w-4" /> قبلی
            </Button>
            <span className="text-sm text-gray-500">صفحه {page} از {Math.ceil(total / 12)}</span>
            <Button variant="outline" size="sm" disabled={page * 12 >= total} onClick={() => setPage(p => p + 1)}>
              بعدی <ChevronLeft className="h-4 w-4 rotate-180" />
            </Button>
          </div>
        )}
      </div>

      {/* Apply Dialog */}
      <Dialog open={applyDialogOpen} onOpenChange={setApplyDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>ارسال رزومه برای: {selectedJob?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>نام و نام خانوادگی *</Label><Input value={applyForm.name} onChange={e => setApplyForm({ ...applyForm, name: e.target.value })} /></div>
            <div><Label>شماره تماس *</Label><Input value={applyForm.phone} onChange={e => setApplyForm({ ...applyForm, phone: e.target.value })} placeholder="09123456789" /></div>
            <div><Label>ایمیل</Label><Input value={applyForm.email} onChange={e => setApplyForm({ ...applyForm, email: e.target.value })} /></div>
            <div><Label>حقوق پیشنهادی (ریال)</Label><Input type="number" value={applyForm.proposedSalary} onChange={e => setApplyForm({ ...applyForm, proposedSalary: e.target.value })} /></div>
            <div><Label>نامه همراه</Label><Textarea value={applyForm.coverLetter} onChange={e => setApplyForm({ ...applyForm, coverLetter: e.target.value })} rows={3} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setApplyDialogOpen(false)}>انصراف</Button>
            <Button onClick={handleApply} disabled={submitting || !applyForm.name || !applyForm.phone}>
              {submitting ? 'در حال ارسال...' : 'ارسال درخواست'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
