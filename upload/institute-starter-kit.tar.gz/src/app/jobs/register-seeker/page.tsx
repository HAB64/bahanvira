'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowRight, CheckCircle, UserPlus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function RegisterSeekerPage() {
  const [form, setForm] = useState({
    firstName: '', lastName: '', phone: '', email: '', gender: '',
    city: 'Mahmoudabad', education: '', fieldOfStudy: '', skills: '',
    certifications: '', experienceYears: '', currentJob: '', desiredJob: '',
    desiredSalary: '', desiredJobType: 'FULL_TIME', availableFrom: '',
    coverLetter: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.firstName || !form.lastName || !form.phone) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/employment/job-seekers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          experienceYears: parseInt(form.experienceYears) || 0,
          desiredSalary: form.desiredSalary ? parseInt(form.desiredSalary) : null,
          availableFrom: form.availableFrom || null,
          source: 'WEB_FORM',
        }),
      });
      const data = await res.json();
      if (data?.پیام) {
        setSuccess(true);
      } else {
        alert(data?.خطا || 'خطا در ثبت‌نام');
      }
    } catch {
      alert('خطا در ثبت‌نام. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center" dir="rtl">
        <Card className="max-w-md w-full mx-4">
          <CardContent className="p-8 text-center">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-gray-900 mb-2">ثبت‌نام با موفقیت انجام شد!</h2>
            <p className="text-sm text-gray-500 mb-6">
              پروفایل شما در سیستم کاریابی ثبت شد. در صورت وجود فرصت شغلی مناسب، با شما تماس خواهیم گرفت.
            </p>
            <Link href="/jobs">
              <Button className="gap-2">
                <ArrowRight className="h-4 w-4" /> بازگشت به فرصت‌های شغلی
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-teal-600 to-teal-700 text-white">
        <div className="max-w-3xl mx-auto px-4 py-10">
          <Link href="/jobs" className="text-teal-200 hover:text-white text-sm flex items-center gap-1 mb-4">
            <ArrowRight className="h-4 w-4" /> بازگشت به فرصت‌های شغلی
          </Link>
          <h1 className="text-2xl sm:text-3xl font-bold">ثبت‌نام کارجو</h1>
          <p className="text-teal-100 mt-2">پروفایل خود را بسازید تا کارفرمایان شما را پیدا کنند</p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-8">
        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            {/* Personal Info */}
            <Card>
              <CardHeader><CardTitle className="text-base flex items-center gap-2"><UserPlus className="h-5 w-5 text-teal-600" /> اطلاعات شخصی</CardTitle></CardHeader>
              <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div><Label>نام *</Label><Input value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} required /></div>
                <div><Label>نام خانوادگی *</Label><Input value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} required /></div>
                <div><Label>شماره موبایل *</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="09123456789" required /></div>
                <div><Label>ایمیل</Label><Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
                <div><Label>شهر</Label><Input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
                <div><Label>جنسیت</Label>
                  <Select value={form.gender} onValueChange={v => setForm({ ...form, gender: v })}>
                    <SelectTrigger><SelectValue placeholder="انتخاب" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MALE">مرد</SelectItem>
                      <SelectItem value="FEMALE">زن</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Professional Info */}
            <Card>
              <CardHeader><CardTitle className="text-base">اطلاعات حرفه‌ای</CardTitle></CardHeader>
              <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div><Label>تحصیلات</Label>
                  <Select value={form.education} onValueChange={v => setForm({ ...form, education: v })}>
                    <SelectTrigger><SelectValue placeholder="انتخاب" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="دیپلم">دیپلم</SelectItem>
                      <SelectItem value="کاردانی">کاردانی</SelectItem>
                      <SelectItem value="کارشناسی">کارشناسی</SelectItem>
                      <SelectItem value="کارشناسی ارشد">کارشناسی ارشد</SelectItem>
                      <SelectItem value="دکتری">دکتری</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>رشته تحصیلی</Label><Input value={form.fieldOfStudy} onChange={e => setForm({ ...form, fieldOfStudy: e.target.value })} /></div>
                <div className="sm:col-span-2"><Label>مهارت‌ها</Label><Input value={form.skills} onChange={e => setForm({ ...form, skills: e.target.value })} placeholder="با کاما جدا کنید: برنامه‌نویسی Python، طراحی وب، ..." /></div>
                <div><Label>سابقه کار (سال)</Label><Input type="number" value={form.experienceYears} onChange={e => setForm({ ...form, experienceYears: e.target.value })} /></div>
                <div><Label>شغل فعلی</Label><Input value={form.currentJob} onChange={e => setForm({ ...form, currentJob: e.target.value })} /></div>
                <div><Label>گواهینامه‌ها</Label><Input value={form.certifications} onChange={e => setForm({ ...form, certifications: e.target.value })} placeholder="با کاما جدا کنید" /></div>
              </CardContent>
            </Card>

            {/* Job Preferences */}
            <Card>
              <CardHeader><CardTitle className="text-base">ترجیحات شغلی</CardTitle></CardHeader>
              <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div><Label>شغل مورد نظر</Label><Input value={form.desiredJob} onChange={e => setForm({ ...form, desiredJob: e.target.value })} /></div>
                <div><Label>نوع شغل</Label>
                  <Select value={form.desiredJobType} onValueChange={v => setForm({ ...form, desiredJobType: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="FULL_TIME">تمام‌وقت</SelectItem>
                      <SelectItem value="PART_TIME">پاره‌وقت</SelectItem>
                      <SelectItem value="CONTRACT">قراردادی</SelectItem>
                      <SelectItem value="REMOTE">دورکاری</SelectItem>
                      <SelectItem value="ANY">هر نوع</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>حقوق مورد انتظار (ریال)</Label><Input type="number" value={form.desiredSalary} onChange={e => setForm({ ...form, desiredSalary: e.target.value })} /></div>
                <div><Label>آمادگی شروع کار</Label><Input type="date" value={form.availableFrom} onChange={e => setForm({ ...form, availableFrom: e.target.value })} /></div>
              </CardContent>
            </Card>

            <Button type="submit" size="lg" className="w-full gap-2" disabled={submitting}>
              {submitting ? 'در حال ثبت...' : 'ثبت‌نام'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
