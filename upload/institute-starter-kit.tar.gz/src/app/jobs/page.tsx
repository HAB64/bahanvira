import { Metadata } from 'next';
import JobsClient from './JobsClient';
import { siteConfig } from '@/config/site';

// Metadata is defined in layout.tsx

export default function JobsPage() {
  // JSON-LD schema for employment service
  const employmentSchema = {
    '@context': 'https://schema.org',
    '@type': 'JobPosting',
    title: 'فرصت‌های شغلی فارغ‌التحصیلان بهان رایانه',
    description: 'سامانه اشتغال آموزشگاه بهان رایانه — اتصال فارغ‌التحصیلان به فرصت‌های شغلی در محمودآباد و مازندران',
    hiringOrganization: {
      '@type': 'EducationalOrganization',
      name: siteConfig.name.fullName,
      url: siteConfig.url.base,
      address: {
        '@type': 'PostalAddress',
        addressLocality: siteConfig.location.city,
        addressRegion: siteConfig.location.province,
        addressCountry: siteConfig.location.countryEn,
      },
    },
    jobLocation: {
      '@type': 'Place',
      address: {
        '@type': 'PostalAddress',
        addressLocality: siteConfig.location.city,
        addressRegion: siteConfig.location.province,
        addressCountry: siteConfig.location.countryEn,
      },
    },
    employmentType: 'FULL_TIME, PART_TIME, CONTRACT, INTERNSHIP, REMOTE',
  };

  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'خانه', item: siteConfig.url.base },
      { '@type': 'ListItem', position: 2, name: 'سامانه اشتغال', item: `${siteConfig.url.base}/jobs` },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(employmentSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <JobsClient />
    </>
  );
}
