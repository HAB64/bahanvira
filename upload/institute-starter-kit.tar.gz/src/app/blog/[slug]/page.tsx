import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Calendar, Clock, ArrowLeft, User, ChevronLeft } from 'lucide-react';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { blogPosts, blogCategories } from '@/data/blog';
import { siteConfig } from '@/config/site';

// ─── Static Params for SSG ──────────────────────────────────────
export function generateStaticParams() {
  return blogPosts.map((post) => ({
    slug: post.slug,
  }));
}

// ─── Metadata for SEO ───────────────────────────────────────────
export function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Metadata {
  const post = blogPosts.find((p) => p.slug === params.slug);
  if (!post) return { title: 'مقاله پیدا نشد' };

  return {
    title: `${post.title} | وبلاگ ${siteConfig.name.fa}`,
    description: post.excerpt,
    keywords: post.keywords,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      type: 'article',
      publishedTime: post.date,
      authors: [post.author],
      tags: post.keywords,
      locale: 'fa_IR',
      siteName: siteConfig.name.fullName,
    },
    twitter: {
      card: 'summary_large_image',
      title: post.title,
      description: post.excerpt,
    },
    alternates: {
      canonical: `${siteConfig.url.base}/blog/${post.slug}`,
    },
  };
}

// ─── BlogPosting Schema ─────────────────────────────────────────
function BlogPostingSchema({ post }: { post: (typeof blogPosts)[0] }) {
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: post.title,
    description: post.excerpt,
    datePublished: post.date,
    image: `${siteConfig.url.base}${siteConfig.assets.ogImage}`,
    author: {
      '@type': 'Person',
      name: post.author,
    },
    publisher: {
      '@type': 'Organization',
      name: siteConfig.name.fullName,
      url: siteConfig.url.base,
      logo: {
        '@type': 'ImageObject',
        url: `${siteConfig.url.base}${siteConfig.assets.logo}`,
      },
    },
    keywords: post.keywords.join(', '),
    articleSection: post.category,
    inLanguage: 'fa-IR',
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `${siteConfig.url.base}/blog/${post.slug}`,
    },
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
    />
  );
}

// ─── Simple Markdown-like Renderer ───────────────────────────────
function renderContent(content: string) {
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let key = 0;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      continue;
    }
    if (trimmed.startsWith('## ')) {
      elements.push(
        <h2 key={key++} className="text-xl font-bold text-[#0f172a] mt-8 mb-4">
          {trimmed.slice(3)}
        </h2>
      );
    } else if (trimmed.startsWith('**') && trimmed.endsWith('**')) {
      elements.push(
        <p key={key++} className="font-bold text-[#0f172a] mt-4 mb-2 leading-relaxed">
          {trimmed.slice(2, -2)}
        </p>
      );
    } else {
      elements.push(
        <p key={key++} className="text-[#475569] leading-relaxed mb-3">
          {trimmed}
        </p>
      );
    }
  }
  return elements;
}

// ─── Page Component ─────────────────────────────────────────────
export default function BlogPostPage({
  params,
}: {
  params: { slug: string };
}) {
  const post = blogPosts.find((p) => p.slug === params.slug);
  if (!post) notFound();

  const category = blogCategories.find((c) => c.id === post.categorySlug);
  const relatedPosts = blogPosts
    .filter((p) => p.slug !== post.slug && p.categorySlug === post.categorySlug)
    .slice(0, 2);

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <BlogPostingSchema post={post} />
      <main className="flex-1">
        {/* Hero */}
        <div className="py-10 sm:py-14" style={{ backgroundColor: post.color + '08' }}>
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-sm text-[#64748b] mb-6" dir="rtl">
              <Link href="/" className="hover:text-[#0d9488] transition-colors">خانه</Link>
              <ChevronLeft className="w-3.5 h-3.5" />
              <Link href="/blog" className="hover:text-[#0d9488] transition-colors">وبلاگ</Link>
              <ChevronLeft className="w-3.5 h-3.5" />
              <span className="text-[#0f172a] font-medium truncate">{post.title}</span>
            </nav>

            {/* Category Badge */}
            {category && (
              <span
                className="inline-block text-xs font-medium px-3 py-1 rounded-full mb-4"
                style={{ backgroundColor: category.color + '15', color: category.color }}
              >
                {category.label}
              </span>
            )}

            {/* Title */}
            <h1 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4 leading-tight">
              {post.title}
            </h1>

            {/* Meta */}
            <div className="flex items-center gap-4 text-sm text-[#64748b]">
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                <span>{post.date}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                <span>{post.readTime}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <User className="w-4 h-4" />
                <span>{post.author}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <article className="prose-custom">
            {renderContent(post.content)}
          </article>

          {/* Tags */}
          <div className="mt-10 pt-6 border-t border-gray-100">
            <p className="text-xs font-medium text-[#64748b] mb-3">کلیدواژه‌ها:</p>
            <div className="flex flex-wrap gap-2">
              {post.keywords.map((kw) => (
                <span
                  key={kw}
                  className="text-xs bg-gray-100 text-[#475569] px-3 py-1 rounded-full"
                >
                  {kw}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="bg-gray-50 py-10 sm:py-14">
            <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
              <h2 className="text-lg font-bold text-[#0f172a] mb-6">مقالات مرتبط</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {relatedPosts.map((relPost) => (
                  <Link
                    key={relPost.slug}
                    href={`/blog/${relPost.slug}`}
                    className="group bg-white rounded-xl border border-gray-100 p-5 hover:shadow-md transition-all"
                  >
                    <span
                      className="text-xs font-medium px-2 py-0.5 rounded-full inline-block mb-2"
                      style={{ backgroundColor: relPost.color + '15', color: relPost.color }}
                    >
                      {relPost.category}
                    </span>
                    <h3 className="font-bold text-sm text-[#0f172a] group-hover:text-[#0d9488] transition-colors line-clamp-2 mb-2">
                      {relPost.title}
                    </h3>
                    <p className="text-xs text-[#64748b] line-clamp-2">{relPost.excerpt}</p>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
