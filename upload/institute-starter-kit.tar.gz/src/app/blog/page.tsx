import Link from 'next/link';
import { Calendar, ArrowLeft, Clock, Tag } from 'lucide-react';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { blogPosts, blogCategories } from '@/data/blog';
import { siteConfig } from '@/config/site';

export default function BlogPage() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <main className="flex-1">
        {/* Hero */}
        <div className="bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#0f766e] py-12 sm:py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">اتاق فکر و وبلاگ</h1>
            <p className="text-white/80 max-w-2xl mx-auto leading-relaxed">
              مقالات تخصصی، تحلیل‌های بازار کار و راهنماهای شغلی. دانشی که مسیر حرفه‌ای شما را روشن می‌کند.
            </p>
          </div>
        </div>

        {/* Category Filter Visual */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
          <div className="flex flex-wrap items-center justify-center gap-3">
            <span className="bg-white shadow-md rounded-full px-5 py-2 text-sm font-medium text-[#0f172a]">
              همه مقالات
            </span>
            {blogCategories.map((cat) => (
              <span
                key={cat.id}
                className="bg-white shadow-sm rounded-full px-4 py-2 text-xs font-medium border border-gray-100"
                style={{ color: cat.color }}
              >
                {cat.label}
              </span>
            ))}
          </div>
        </div>

        {/* Blog Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {blogPosts.map((post) => (
              <Link
                key={post.slug}
                href={`/blog/${post.slug}`}
                className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                {/* Color Bar */}
                <div className="h-2" style={{ backgroundColor: post.color }} />

                {/* Placeholder Image */}
                <div
                  className="h-48 flex items-center justify-center"
                  style={{ backgroundColor: post.color + '10' }}
                >
                  <div className="text-center">
                    <div
                      className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3"
                      style={{ backgroundColor: post.color + '20' }}
                    >
                      <Tag className="w-8 h-8" style={{ color: post.color }} />
                    </div>
                    <p className="text-sm font-medium" style={{ color: post.color }}>
                      {post.category}
                    </p>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  {/* Meta */}
                  <div className="flex items-center gap-3 text-xs text-[#64748b] mb-3">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{post.readTime}</span>
                    </div>
                  </div>

                  {/* Title */}
                  <h2 className="font-bold text-[#0f172a] mb-2 line-clamp-2 group-hover:text-[#0d9488] transition-colors">
                    {post.title}
                  </h2>

                  {/* Excerpt */}
                  <p className="text-sm text-[#64748b] leading-relaxed line-clamp-3 mb-4">
                    {post.excerpt}
                  </p>

                  {/* Read More */}
                  <div className="flex items-center gap-1 text-sm font-medium text-[#0d9488] group-hover:gap-2 transition-all">
                    ادامه مطلب
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
