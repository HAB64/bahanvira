import { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: `وبلاگ آموزشگاه فنی و حرفه‌ای ${siteConfig.name.fa} | مقالات آموزشی و تحلیل بازار کار`,
  description: `مقالات تخصصی ${siteConfig.name.fullName} شامل آموزش برنامه‌نویسی، فارکس، هوش مصنوعی و کارآفرینی. دانشی که مسیر حرفه‌ای شما را روشن می‌کند.`,
  keywords: ['وبلاگ آموزشی', `مقاله ${siteConfig.institute.typeFa}`, 'آموزش برنامه‌نویسی', 'آموزش فارکس', `آموزشگاه فنی و حرفه‌ای ${siteConfig.location.city}`],
  alternates: {
    canonical: `${siteConfig.url.base}/blog`,
  },
  openGraph: {
    title: `وبلاگ آموزشگاه فنی و حرفه‌ای ${siteConfig.name.fa} | مقالات آموزشی`,
    description: 'مقالات تخصصی، تحلیل‌های بازار کار و راهنماهای شغلی',
    locale: 'fa_IR',
    url: `${siteConfig.url.base}/blog`,
    siteName: siteConfig.name.fullName,
    type: 'website',
  },
};

export default function BlogLayout({ children }: { children: React.ReactNode }) {
  return children;
}
