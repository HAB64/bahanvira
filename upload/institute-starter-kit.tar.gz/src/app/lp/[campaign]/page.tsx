'use client'

import { useState, useEffect, useCallback, type FormEvent } from 'react'
import { 
  GraduationCap, Phone, MessageCircle, CheckCircle2, 
  Loader2, Star, Shield, BookOpen, Users, Send, Award
} from 'lucide-react'
import { useUTM } from '@/hooks/use-utm'

interface CampaignData {
  name: string
  description?: string
  targetCluster?: string
  utmCampaign?: string
}

interface LPProps {
  params: Promise<{ campaign: string }>
}

export default function CampaignLandingPage({ params }: LPProps) {
  const [campaignSlug, setCampaignSlug] = useState('')
  const [campaignData, setCampaigData] = useState<CampaignData | null>(null)
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [course, setCourse] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const utm = useUTM()

  // Unwrap params
  useEffect(() => {
    params.then(p => setCampaignSlug(p.campaign))
  }, [params])

  // Fetch campaign data + track page view
  useEffect(() => {
    if (!campaignSlug) return

    // Fetch campaign from API
    fetch(`/api/crm/campaigns?search=${encodeURIComponent(campaignSlug)}&limit=1`)
      .then(res => res.json())
      .then(data => {
        if (data['داده‌ها'] && data['داده‌ها'].length > 0) {
          setCampaigData(data['داده‌ها'][0])
        }
      })
      .catch(() => {
        // No campaign data, use generic template
      })

    // Track page view
    fetch('/api/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: 'PAGE_VIEW',
        category: 'navigation',
        label: `Landing: ${campaignSlug}`,
        page: `/lp/${campaignSlug}`,
      }),
    }).catch(() => { /* fire-and-forget */ })
  }, [campaignSlug])

  // Determine personalized content based on campaign slug
  const getCampaignPersonalization = useCallback(() => {
    const slug = campaignSlug.toLowerCase()
    
    if (slug.includes('icdl') || slug.includes('office') || slug.includes('computer')) {
      return {
        title: 'گواهینامه بین‌المللی ICDL',
        subtitle: 'کلید ورود به بازار کار و استخدام دولتی',
        highlight: 'مدرک معتبر برای استخدام‌های دولتی و مراکز غیردولتی',
        cluster: 'tech-ai',
        color: 'from-teal-600 to-teal-800',
        courses: [
          { value: 'icdl', label: 'ICDL' },
          { value: 'python', label: 'برنامه‌نویسی پایتون' },
          { value: 'local-ai', label: 'هوش مصنوعی محلی' },
        ],
      }
    }
    
    if (slug.includes('forex') || slug.includes('trading') || slug.includes('financial')) {
      return {
        title: 'دوره‌های بازارهای مالی',
        subtitle: 'یادگیری حرفه‌ای معاملات فارکس و الگوریتمی',
        highlight: 'از مبانی فارکس تا ساخت ربات‌های معامله‌گر',
        cluster: 'finance',
        color: 'from-amber-600 to-orange-700',
        courses: [
          { value: 'forex', label: 'فارکس (مبانی)' },
          { value: 'mql5', label: 'MQL5 الگوریتمی' },
        ],
      }
    }
    
    if (slug.includes('python') || slug.includes('coding') || slug.includes('programming')) {
      return {
        title: 'برنامه‌نویسی پایتون',
        subtitle: 'یادگیری پرتقاضاترین زبان برنامه‌نویسی جهان',
        highlight: 'از مبتدی تا سطح حرفه‌ای — با پروژه‌های عملی',
        cluster: 'tech-ai',
        color: 'from-blue-600 to-indigo-800',
        courses: [
          { value: 'icdl', label: 'ICDL (پیش‌نیاز)' },
          { value: 'python', label: 'برنامه‌نویسی پایتون' },
          { value: 'local-ai', label: 'هوش مصنوعی محلی' },
        ],
      }
    }
    
    if (slug.includes('kid') || slug.includes('teen') || slug.includes('scratch') || slug.includes('child')) {
      return {
        title: 'دوره‌های کودکان و نوجوانان',
        subtitle: 'یادگیری منطق برنامه‌نویسی از طریق بازی‌سازی',
        highlight: 'Scratch: آموزش کدنویسی به شیوه‌ای جذاب برای کودکان',
        cluster: 'tech-ai',
        color: 'from-yellow-500 to-orange-600',
        courses: [
          { value: 'scratch', label: 'Scratch کودکان' },
          { value: 'icdl', label: 'ICDL (نوجوانان)' },
        ],
      }
    }
    
    if (slug.includes('art') || slug.includes('design') || slug.includes('creative') || slug.includes('photoshop')) {
      return {
        title: 'دوره‌های خلاقیت و هنر کاربردی',
        subtitle: 'توسعه مهارت‌های خلاقانه و هنری',
        highlight: 'Photoshop، AutoCAD و مدلسازی سه‌بعدی',
        cluster: 'entrepreneurship',
        color: 'from-rose-600 to-pink-800',
        courses: [
          { value: 'photoshop', label: 'Photoshop' },
          { value: 'autocad', label: 'AutoCAD' },
          { value: '3dmax', label: 'سه‌بعدی (3D Max)' },
        ],
      }
    }
    
    // Default / generic template
    return {
      title: 'دوره‌های تخصصی فنی و حرفه‌ای',
      subtitle: 'با ۲۷ سال اصالت آموزشی در محمودآباد',
      highlight: 'مدرک معتبر فنی و حرفه‌ای — قسط‌بندی بدون چک',
      cluster: '',
      color: 'from-teal-700 to-emerald-900',
      courses: [
        { value: 'icdl', label: 'ICDL' },
        { value: 'python', label: 'برنامه‌نویسی پایتون' },
        { value: 'forex', label: 'فارکس' },
        { value: 'accounting', label: 'حسابداری و مالی' },
        { value: 'photoshop', label: 'Photoshop' },
        { value: 'entrepreneurship', label: 'کارآفرینی' },
      ],
    }
  }, [campaignSlug])

  const personalization = getCampaignPersonalization()

  // Use campaign data if available
  const displayTitle = campaignData?.name || personalization.title
  const displaySubtitle = campaignData?.description || personalization.subtitle

  const validatePhone = (p: string) => /^09[0-9]{9}$/.test(p)

  const handleSubmit = useCallback(async (e: FormEvent) => {
    e.preventDefault()
    setError('')

    if (!name.trim()) {
      setError('لطفاً نام خود را وارد کنید')
      return
    }
    if (!validatePhone(phone)) {
      setError('شماره موبایل نامعتبر است (فرمت: 09123456789)')
      return
    }

    setLoading(true)
    try {
      // Submit lead
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          phone,
          course: personalization.courses.find(c => c.value === course)?.label || '',
          cluster: personalization.cluster,
          source: `lp-${campaignSlug}`,
          utmSource: utm.utmSource,
          utmMedium: utm.utmMedium,
          utmCampaign: utm.utmCampaign || campaignSlug,
        }),
      })

      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'خطا در ثبت درخواست')
        return
      }
      
      setSuccess(true)

      // Track form submission
      fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'FORM_SUBMIT',
          category: 'conversion',
          label: `LP Form: ${campaignSlug}`,
          page: `/lp/${campaignSlug}`,
          metadata: { course, cluster: personalization.cluster },
        }),
      }).catch(() => {})
    } catch {
      setError('خطا در ارتباط با سرور')
    } finally {
      setLoading(false)
    }
  }, [name, phone, course, campaignSlug, personalization, utm])

  // JSON-LD structured data
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: displayTitle,
    description: displaySubtitle,
    url: `https://bahanrayaneh.ir/lp/${campaignSlug}`,
    publisher: {
      '@type': 'EducationalOrganization',
      name: 'آموزشگاه فنی و حرفه‌ای بهان رایانه',
      url: 'https://bahanrayaneh.ir',
    },
  }

  return (
    <div dir="rtl" className="min-h-screen flex flex-col bg-white">
      {/* JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* Hero Section */}
      <div className={`bg-gradient-to-bl ${personalization.color} py-12 sm:py-20`}>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            {/* Content */}
            <div className="text-center lg:text-right">
              <div className="inline-flex items-center gap-2 text-sm font-medium text-white/80 bg-white/10 rounded-full px-4 py-1.5 mb-4">
                <GraduationCap className="w-4 h-4" />
                آموزشگاه بهان رایانه
              </div>
              <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4 leading-tight">
                {displayTitle}
              </h1>
              <p className="text-white/80 text-lg leading-relaxed mb-4">
                {displaySubtitle}
              </p>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-white/90 text-sm">
                {personalization.highlight}
              </div>
              
              {/* Trust badges */}
              <div className="flex flex-wrap justify-center lg:justify-start gap-4 mt-6">
                <div className="flex items-center gap-2 text-white/80 text-xs">
                  <Shield className="w-4 h-4" />
                  مجوز رسمی فنی و حرفه‌ای
                </div>
                <div className="flex items-center gap-2 text-white/80 text-xs">
                  <Award className="w-4 h-4" />
                  مدرک بین‌المللی ICDL
                </div>
                <div className="flex items-center gap-2 text-white/80 text-xs">
                  <BookOpen className="w-4 h-4" />
                  ۲۷ سال تجربه
                </div>
              </div>
            </div>

            {/* Form */}
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
              {success ? (
                <div className="p-8 text-center">
                  <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    درخواست شما ثبت شد!
                  </h3>
                  <p className="text-gray-600 mb-4">
                    مشاوران ما به زودی با شما تماس خواهند گرفت
                  </p>
                  <div className="flex gap-3 justify-center">
                    <a
                      href="tel:01144746665"
                      className="flex items-center gap-2 bg-teal-600 text-white font-bold py-2.5 px-5 rounded-xl text-sm hover:bg-teal-500 transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      تماس مستقیم
                    </a>
                    <a
                      href="https://wa.me/989111277194"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 bg-green-600 text-white font-bold py-2.5 px-5 rounded-xl text-sm hover:bg-green-500 transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      واتساپ
                    </a>
                  </div>
                </div>
              ) : (
                <>
                  <div className="bg-gray-50 px-6 py-4 border-b">
                    <h2 className="font-bold text-gray-900 text-base">
                      ثبت‌نام و مشاوره رایگان
                    </h2>
                    <p className="text-gray-500 text-xs mt-1">
                      اطلاعات خود را وارد کنید تا مشاوران ما تماس بگیرند
                    </p>
                  </div>
                  <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="نام و نام خانوادگی"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm"
                        disabled={loading}
                      />
                    </div>
                    <div>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^0-9]/g, '')
                          if (val.length <= 11) setPhone(val)
                        }}
                        placeholder="شماره موبایل (۰۹۱۲۳۴۵۶۷۸۹)"
                        dir="ltr"
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm text-left"
                        disabled={loading}
                      />
                    </div>
                    <div>
                      <select
                        value={course}
                        onChange={(e) => setCourse(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm bg-white"
                        disabled={loading}
                      >
                        <option value="" disabled>دوره مورد علاقه</option>
                        {personalization.courses.map(c => (
                          <option key={c.value} value={c.value}>{c.label}</option>
                        ))}
                      </select>
                    </div>
                    {error && (
                      <div className="text-red-500 text-xs bg-red-50 rounded-lg px-3 py-2">
                        {error}
                      </div>
                    )}
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-teal-600 hover:bg-teal-500 disabled:bg-teal-600/50 text-white font-bold py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-lg"
                    >
                      {loading ? (
                        <><Loader2 className="w-4 h-4 animate-spin" /> در حال ثبت...</>
                      ) : (
                        <><Send className="w-4 h-4" /> ثبت‌نام و دریافت مشاوره رایگان</>
                      )}
                    </button>
                    <p className="text-center text-xs text-gray-400">
                      قسط‌بندی ۲ تا ۳ ماهه بدون چک و بدون بهره
                    </p>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid sm:grid-cols-3 gap-6">
          <div className="text-center p-6 rounded-2xl border border-gray-100 hover:shadow-md transition-all">
            <div className="w-14 h-14 rounded-xl bg-teal-50 flex items-center justify-center mx-auto mb-4">
              <Shield className="w-7 h-7 text-teal-600" />
            </div>
            <h3 className="font-bold text-gray-900 mb-2">مدرک معتبر</h3>
            <p className="text-sm text-gray-500">گواهینامه فنی و حرفه‌ای معتبر در سطح ملی</p>
          </div>
          <div className="text-center p-6 rounded-2xl border border-gray-100 hover:shadow-md transition-all">
            <div className="w-14 h-14 rounded-xl bg-amber-50 flex items-center justify-center mx-auto mb-4">
              <Star className="w-7 h-7 text-amber-600" />
            </div>
            <h3 className="font-bold text-gray-900 mb-2">۲۷ سال تجربه</h3>
            <p className="text-sm text-gray-500">قدیمی‌ترین آموزشگاه فنی و حرفه‌ای محمودآباد</p>
          </div>
          <div className="text-center p-6 rounded-2xl border border-gray-100 hover:shadow-md transition-all">
            <div className="w-14 h-14 rounded-xl bg-purple-50 flex items-center justify-center mx-auto mb-4">
              <Users className="w-7 h-7 text-purple-600" />
            </div>
            <h3 className="font-bold text-gray-900 mb-2">۵۰۰۰+ فارغ‌التحصیل</h3>
            <p className="text-sm text-gray-500">هزاران نفر مسیر شغلی خود را با ما آغاز کرده‌اند</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-auto bg-gray-900 text-white/70 py-6">
        <div className="max-w-5xl mx-auto px-4 text-center text-xs">
          <p>آموزشگاه فنی و حرفه‌ای بهان رایانه — محمودآباد مازندران</p>
          <p className="mt-1">مازندران، محمودآباد، خیابان امام، کوچه آسیاب (نسیم ۴)، انتهای کوچه</p>
          <p className="mt-1">تلفن: ۰۱۱-۴۴۷۴۶۶۶۵</p>
        </div>
      </footer>
    </div>
  )
}
