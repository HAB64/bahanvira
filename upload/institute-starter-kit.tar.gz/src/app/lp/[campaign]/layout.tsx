import type { Metadata } from 'next'

interface LPLayoutProps {
  params: Promise<{ campaign: string }>
}

export async function generateMetadata({ params }: LPLayoutProps): Promise<Metadata> {
  const { campaign } = await params
  const title = campaign 
    ? `${campaign} | آموزشگاه بهان رایانه` 
    : 'آموزشگاه فنی و حرفه‌ای بهان رایانه'
  
  return {
    title,
    description: 'دوره‌های تخصصی فنی و حرفه‌ای با مدرک معتبر — بهان رایانه محمودآباد',
    robots: { index: true, follow: true },
  }
}

export default function LPLayout({ children }: { children: React.ReactNode }) {
  return children
}
