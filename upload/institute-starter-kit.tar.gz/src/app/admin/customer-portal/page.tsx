'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Globe,
  Plus,
  Loader2,
  AlertTriangle,
  Power,
  PowerOff,
  Users,
  Clock,
  UserPlus,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface PortalUser {
  id: string;
  username: string;
  isActive: boolean;
  lastLoginAt: string | null;
  leadId: string | null;
  karAmuzId: string | null;
  lead: { id: string; name: string; phone: string } | null;
  karAmuz: { id: string; firstName: string; lastName: string; phone: string } | null;
  createdAt: string;
}

interface PortalStats {
  کاربران_فعال: number;
  آخرین_ورود: string | null;
  ثبت‌نام_ماهانه: number;
}

interface LeadOption {
  id: string;
  name: string;
  phone: string;
}

interface KarAmuzOption {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
}

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string | null) {
  if (!dateStr) return '-';
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
  }).format(new Date(dateStr));
}

function getRelatedName(user: PortalUser): string {
  if (user.karAmuz) return `${user.karAmuz.firstName} ${user.karAmuz.lastName}`;
  if (user.lead) return user.lead.name;
  return '-';
}

/* ─────────── Main Component ─────────── */

export default function CustomerPortalPage() {
  const [users, setUsers] = useState<PortalUser[]>([]);
  const [stats, setStats] = useState<PortalStats>({ کاربران_فعال: 0, آخرین_ورود: null, ثبت‌نام_ماهانه: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formType, setFormType] = useState<'lead' | 'karAmuz'>('lead');
  const [formPersonId, setFormPersonId] = useState('');
  const [formUsername, setFormUsername] = useState('');
  const [formPassword, setFormPassword] = useState('');

  // Search
  const [leadOptions, setLeadOptions] = useState<LeadOption[]>([]);
  const [karAmuzOptions, setKarAmuzOptions] = useState<KarAmuzOption[]>([]);
  const [personSearch, setPersonSearch] = useState('');
  const [personLoading, setPersonLoading] = useState(false);

  /* ── Data fetching ── */

  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/crm/customer-portal');
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت کاربران');
        return;
      }

      setUsers(data['داده‌ها'] || []);
      setStats(data['آمار'] || { کاربران_فعال: 0, آخرین_ورود: null, ثبت‌نام_ماهانه: 0 });
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  /* ── Person search ── */

  const searchPersons = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setLeadOptions([]); setKarAmuzOptions([]); return; }
    setPersonLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');

      if (formType === 'lead') {
        const res = await fetch(`/api/crm/leads?${params.toString()}`);
        const data = await res.json();
        if (res.ok) setLeadOptions((data['داده‌ها'] || []).map((l: LeadOption) => ({ id: l.id, name: l.name, phone: l.phone })));
      } else {
        const res = await fetch(`/api/crm/karamuz?${params.toString()}`);
        const data = await res.json();
        if (res.ok) setKarAmuzOptions((data['داده‌ها'] || []).map((k: KarAmuzOption) => ({ id: k.id, firstName: k.firstName, lastName: k.lastName, phone: k.phone })));
      }
    } catch { /* silent */ } finally { setPersonLoading(false); }
  }, [formType]);

  /* ── Handlers ── */

  const openAddDialog = () => {
    setFormType('lead');
    setFormPersonId('');
    setFormUsername('');
    setFormPassword('');
    setPersonSearch('');
    setLeadOptions([]);
    setKarAmuzOptions([]);
    setAddDialogOpen(true);
  };

  const handlePersonSelect = (id: string, phone: string) => {
    setFormPersonId(id);
    // Auto-generate username from phone (remove leading 0, add prefix)
    const cleanPhone = phone.replace(/^0/, '');
    setFormUsername(`user_${cleanPhone}`);
    setPersonSearch('');
    setLeadOptions([]);
    setKarAmuzOptions([]);
  };

  const handleSubmit = async () => {
    if (!formUsername.trim() || !formPassword.trim()) return;

    setSubmitting(true);
    try {
      const payload: Record<string, unknown> = {
        username: formUsername,
        password: formPassword,
      };
      if (formType === 'lead') payload.leadId = formPersonId || null;
      else payload.karAmuzId = formPersonId || null;

      const res = await fetch('/api/crm/customer-portal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        setAddDialogOpen(false);
        fetchUsers();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const toggleActive = async (userId: string, currentActive: boolean) => {
    try {
      const res = await fetch('/api/crm/customer-portal', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, isActive: !currentActive }),
      });
      if (res.ok) fetchUsers();
    } catch { /* silent */ }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Globe className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">پورتال مشتری</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(users.length)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت دسترسی مشتریان به پورتال</p>
          </div>
        </div>
        <Button onClick={openAddDialog} className="bg-teal-600 hover:bg-teal-700 text-white gap-2">
          <Plus className="w-4 h-4" />
          کاربر جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کاربران فعال</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.کاربران_فعال)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <Users className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">آخرین ورود</p>
                <p className="text-sm font-bold mt-1 text-gray-700">
                  {loading ? <Skeleton className="h-8 w-24" /> : formatPersianDate(stats.آخرین_ورود)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">ثبت‌نام ماهانه</p>
                <p className="text-2xl font-bold mt-1 text-teal-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.ثبت‌نام_ماهانه)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                <UserPlus className="w-5 h-5 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchUsers}>تلاش مجدد</Button>
          </CardContent>
        </Card>
      ) : users.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Globe className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">کاربری یافت نشد</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">نام کاربری</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">شخص مرتبط</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">وضعیت</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">آخرین ورود</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id} className="hover:bg-gray-50/50">
                    <TableCell className="font-mono text-sm">{user.username}</TableCell>
                    <TableCell className="text-sm">
                      <div>
                        <span className="font-medium">{getRelatedName(user)}</span>
                        {user.lead && (
                          <Badge variant="secondary" className="bg-gray-100 text-gray-500 text-xs border-0 mr-1">لید</Badge>
                        )}
                        {user.karAmuz && (
                          <Badge variant="secondary" className="bg-purple-50 text-purple-600 text-xs border-0 mr-1">کارآموز</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="secondary"
                        className={`${user.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'} text-xs border-0`}
                      >
                        {user.isActive ? 'فعال' : 'غیرفعال'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {formatPersianDate(user.lastLoginAt)}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className={`h-8 w-8 ${user.isActive ? 'text-red-500 hover:bg-red-50' : 'text-green-500 hover:bg-green-50'}`}
                        onClick={() => toggleActive(user.id, user.isActive)}
                        title={user.isActive ? 'غیرفعال کردن' : 'فعال کردن'}
                      >
                        {user.isActive ? <PowerOff className="w-4 h-4" /> : <Power className="w-4 h-4" />}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Add Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Globe className="w-5 h-5 text-teal-600" />
              کاربر پورتال جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Select type */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نوع شخص</Label>
              <Select value={formType} onValueChange={(v) => { setFormType(v as 'lead' | 'karAmuz'); setFormPersonId(''); setPersonSearch(''); setLeadOptions([]); setKarAmuzOptions([]); }}>
                <SelectTrigger className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lead">لید</SelectItem>
                  <SelectItem value="karAmuz">کارآموز</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Search person */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">شخص مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder={formType === 'lead' ? 'جستجوی لید...' : 'جستجوی کارآموز...'}
                  value={personSearch}
                  onChange={(e) => {
                    setPersonSearch(e.target.value);
                    searchPersons(e.target.value);
                  }}
                />
                {personLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {leadOptions.length > 0 && formType === 'lead' && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {leadOptions.map((lead) => (
                    <button
                      key={lead.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-teal-50 transition-colors ${
                        formPersonId === lead.id ? 'bg-teal-50 text-teal-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => handlePersonSelect(lead.id, lead.phone)}
                    >
                      {lead.name} — {toPersianNumber(lead.phone)}
                    </button>
                  ))}
                </div>
              )}
              {karAmuzOptions.length > 0 && formType === 'karAmuz' && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {karAmuzOptions.map((ka) => (
                    <button
                      key={ka.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-purple-50 transition-colors ${
                        formPersonId === ka.id ? 'bg-purple-50 text-purple-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => handlePersonSelect(ka.id, ka.phone)}
                    >
                      {ka.firstName} {ka.lastName} — {toPersianNumber(ka.phone)}
                    </button>
                  ))}
                </div>
              )}
              {formPersonId && (
                <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">شخص انتخاب شد</Badge>
              )}
            </div>

            {/* Username */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نام کاربری</Label>
              <Input
                placeholder="نام کاربری..."
                value={formUsername}
                onChange={(e) => setFormUsername(e.target.value)}
                dir="ltr"
              />
              <p className="text-xs text-gray-400">خودکار از شماره تلفن تولید می‌شود</p>
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">رمز عبور اولیه</Label>
              <Input
                type="text"
                placeholder="رمز عبور..."
                value={formPassword}
                onChange={(e) => setFormPassword(e.target.value)}
                dir="ltr"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>انصراف</Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !formUsername.trim() || !formPassword.trim()}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ایجاد کاربر
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
