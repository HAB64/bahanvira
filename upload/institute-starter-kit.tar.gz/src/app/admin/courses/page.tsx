'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Search, Pencil, Trash2, Eye, EyeOff } from 'lucide-react';
import { toast } from 'sonner';

interface Course {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  cluster: string;
  clusterLabel: string;
  level: string;
  duration: string;
  sessions: number;
  published: boolean;
  modules: { id: string }[];
  reviews: { id: string }[];
}

const clusterLabels: Record<string, string> = {
  'tech-ai': 'فناوری و AI',
  financial: 'بازارهای مالی',
  management: 'مدیریت و کارآفرینی',
  creative: 'صنایع خلاق',
};

const levelLabels: Record<string, string> = {
  'پایه': 'پایه',
  'متوسط': 'متوسط',
  'پیشرفته': 'پیشرفته',
};

export default function AdminCoursesPage() {
  const router = useRouter();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [clusterFilter, setClusterFilter] = useState('all');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const res = await fetch('/api/admin/courses');
      const data = await res.json();
      setCourses(data);
    } catch {
      toast.error('خطا در دریافت دوره‌ها');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/admin/courses/${deleteId}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('دوره با موفقیت حذف شد');
        setCourses(courses.filter((c) => c.id !== deleteId));
      } else {
        toast.error('خطا در حذف دوره');
      }
    } catch {
      toast.error('خطا در حذف دوره');
    }
    setDeleteId(null);
  };

  const togglePublished = async (course: Course) => {
    try {
      const res = await fetch(`/api/admin/courses/${course.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...course, published: !course.published }),
      });
      if (res.ok) {
        toast.success(course.published ? 'دوره غیرفعال شد' : 'دوره منتشر شد');
        setCourses(
          courses.map((c) =>
            c.id === course.id ? { ...c, published: !c.published } : c
          )
        );
      }
    } catch {
      toast.error('خطا در تغییر وضعیت');
    }
  };

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.includes(search) ||
      course.slug.includes(search) ||
      course.subtitle.includes(search);
    const matchesCluster =
      clusterFilter === 'all' || course.cluster === clusterFilter;
    return matchesSearch && matchesCluster;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">مدیریت دوره‌ها</h1>
          <p className="text-gray-500 mt-1">{courses.length} دوره ثبت شده</p>
        </div>
        <Link href="/admin/courses/new">
          <Button className="bg-teal-600 hover:bg-teal-700 gap-2">
            <Plus className="h-4 w-4" />
            افزودن دوره جدید
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="جستجوی دوره..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={clusterFilter} onValueChange={setClusterFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="فیلتر خوشه" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه خوشه‌ها</SelectItem>
                <SelectItem value="tech-ai">فناوری و AI</SelectItem>
                <SelectItem value="financial">بازارهای مالی</SelectItem>
                <SelectItem value="management">مدیریت و کارآفرینی</SelectItem>
                <SelectItem value="creative">صنایع خلاق</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Course list */}
      <div className="space-y-3">
        {loading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm animate-pulse">
              <CardContent className="p-4">
                <div className="h-6 bg-gray-100 rounded w-1/3 mb-3" />
                <div className="h-4 bg-gray-100 rounded w-2/3 mb-2" />
                <div className="h-4 bg-gray-100 rounded w-1/4" />
              </CardContent>
            </Card>
          ))
        ) : filteredCourses.length === 0 ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">دوره‌ای یافت نشد</p>
            </CardContent>
          </Card>
        ) : (
          filteredCourses.map((course) => (
            <Card key={course.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-gray-900 truncate">
                        {course.title}
                      </h3>
                      <Badge
                        variant={course.published ? 'default' : 'secondary'}
                        className={
                          course.published
                            ? 'bg-teal-100 text-teal-700 hover:bg-teal-100'
                            : 'bg-gray-100 text-gray-500'
                        }
                      >
                        {course.published ? 'منتشر شده' : 'پیش‌نویس'}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500 truncate">
                      {course.subtitle}
                    </p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
                      <span>{clusterLabels[course.cluster] || course.clusterLabel}</span>
                      <span>•</span>
                      <span>سطح {levelLabels[course.level] || course.level}</span>
                      <span>•</span>
                      <span>{course.duration}</span>
                      <span>•</span>
                      <span>{course.modules?.length || 0} ماژول</span>
                      <span>•</span>
                      <span>{course.reviews?.length || 0} نظر</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => togglePublished(course)}
                      title={course.published ? 'لغو انتشار' : 'انتشار'}
                    >
                      {course.published ? (
                        <Eye className="h-4 w-4 text-teal-600" />
                      ) : (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => router.push(`/admin/courses/${course.id}`)}
                      title="ویرایش"
                    >
                      <Pencil className="h-4 w-4 text-gray-600" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeleteId(course.id)}
                      title="حذف"
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف دوره</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف این دوره اطمینان دارید؟ این عمل قابل بازگشت نیست و تمام ماژول‌ها و نظرات مرتبط نیز حذف خواهند شد.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
