'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import dynamic from 'next/dynamic';
import {
  MapPin,
  Search,
  AlertTriangle,
  Users,
  Building2,
  PieChart,
  Navigation,
  RefreshCw,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

// Dynamic import to avoid SSR issues with Leaflet
const CustomerMap = dynamic(() => import('@/components/admin/CustomerMap'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-[450px] rounded-xl bg-gray-50 flex items-center justify-center border border-gray-200">
      <div className="text-center">
        <MapPin className="w-8 h-8 text-gray-300 mx-auto mb-2 animate-pulse" />
        <p className="text-gray-400 text-sm">در حال بارگذاری نقشه...</p>
      </div>
    </div>
  ),
});

/* ─────────── Types ─────────── */

interface GeoLead {
  id: string;
  name: string;
  phone: string;
  latitude: number | null;
  longitude: number | null;
  geoCity: string | null;
  stage: string;
  cluster: string;
  segment: string;
  score: number;
  createdAt: string;
}

interface GeoStats {
  آمار_شهر: Record<string, number>;
  آمار_مرحله: Record<string, number>;
  آمار_خوشه: Record<string, number>;
}

/* ─────────── Constants ─────────── */

const STAGE_LABELS: Record<string, string> = {
  NEW: 'جدید',
  CONTACTED: 'تماس شده',
  INTERESTED: 'علاقه‌مند',
  ENROLLED: 'ثبت‌نام شده',
  REJECTED: 'رد شده',
  ARCHIVED: 'بایگانی',
};

const CLUSTER_LABELS: Record<string, string> = {
  'tech-ai': 'فناوری و هوش مصنوعی',
  financial: 'مالی',
  management: 'مدیریت',
  entrepreneurship: 'کارآفرینی',
};

const SEGMENT_LABELS: Record<string, string> = {
  VIP: 'VIP',
  REGULAR: 'عادی',
  LOYAL: 'وفادار',
  AT_RISK: 'در خطر',
  CHURNED: 'از دست رفته',
  NEW: 'جدید',
};

const CLUSTER_OPTIONS = [
  { value: 'all', label: 'همه خوشه‌ها' },
  { value: 'tech-ai', label: 'فناوری و هوش مصنوعی' },
  { value: 'financial', label: 'مالی' },
  { value: 'management', label: 'مدیریت' },
  { value: 'entrepreneurship', label: 'کارآفرینی' },
];

const SEGMENT_OPTIONS = [
  { value: 'all', label: 'همه بخش‌ها' },
  { value: 'VIP', label: 'VIP' },
  { value: 'REGULAR', label: 'عادی' },
  { value: 'LOYAL', label: 'وفادار' },
  { value: 'AT_RISK', label: 'در خطر' },
  { value: 'CHURNED', label: 'از دست رفته' },
  { value: 'NEW', label: 'جدید' },
];

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function GeoPage() {
  /* ── State ── */
  const [leads, setLeads] = useState<GeoLead[]>([]);
  const [geoStats, setGeoStats] = useState<GeoStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterCluster, setFilterCluster] = useState<string>('all');
  const [filterSegment, setFilterSegment] = useState<string>('all');
  const [filterCity, setFilterCity] = useState<string>('all');

  /* ── Data fetching ── */

  const fetchGeoData = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '100');

      const res = await fetch(`/api/crm/geo?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت داده‌ها');
        return;
      }

      setLeads(data['داده‌ها'] || []);
      setGeoStats({
        آمار_شهر: data['آمار_شهر'] || {},
        آمار_مرحله: data['آمار_مرحله'] || {},
        آمار_خوشه: data['آمار_خوشه'] || {},
      });
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchGeoData();
  }, [fetchGeoData]);

  /* ── Computed ── */

  const cityOptions = useMemo(() => {
    const cities = Object.keys(geoStats?.آمار_شهر || {});
    return [
      { value: 'all', label: 'همه شهرها' },
      ...cities.map(c => ({ value: c, label: c })),
    ];
  }, [geoStats]);

  const filteredLeads = useMemo(() => {
    return leads.filter(lead => {
      if (search) {
        const q = search.toLowerCase();
        if (!lead.name.toLowerCase().includes(q) && !lead.phone.includes(q)) return false;
      }
      if (filterCluster !== 'all' && lead.cluster !== filterCluster) return false;
      if (filterSegment !== 'all' && lead.segment !== filterSegment) return false;
      if (filterCity !== 'all' && lead.geoCity !== filterCity) return false;
      return true;
    });
  }, [leads, search, filterCluster, filterSegment, filterCity]);

  const topCities = useMemo(() => {
    const cities = geoStats?.آمار_شهر || {};
    return Object.entries(cities)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10);
  }, [geoStats]);

  const maxCityCount = useMemo(() => {
    if (topCities.length === 0) return 1;
    return Math.max(...topCities.map(([, count]) => count));
  }, [topCities]);

  const totalWithCoords = leads.length;

  const clusterCounts = useMemo(() => {
    const stats = geoStats?.آمار_خوشه || {};
    return Object.entries(stats).map(([key, count]) => ({
      key,
      label: CLUSTER_LABELS[key] || key,
      count,
    }));
  }, [geoStats]);

  const segmentCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    leads.forEach(l => {
      if (l.segment) {
        counts[l.segment] = (counts[l.segment] || 0) + 1;
      }
    });
    return Object.entries(counts).map(([key, count]) => ({
      key,
      label: SEGMENT_LABELS[key] || key,
      count,
    }));
  }, [leads]);

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <MapPin className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">نقشه مشتریان</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {loading ? <Skeleton className="h-4 w-6" /> : toPersianNumber(totalWithCoords)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">تحلیل جغرافیایی مشتریان و لیدها</p>
          </div>
        </div>
        <Button
          onClick={fetchGeoData}
          variant="outline"
          className="gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          به‌روزرسانی
        </Button>
      </div>

      {/* Interactive Map */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-gray-700">نقشه تعاملی مشتریان</h3>
            <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs border-0">
              {toPersianNumber(leads.filter(l => l.latitude && l.longitude).length)} نقطه
            </Badge>
          </div>
          <CustomerMap
            leads={leads.filter((l): l is GeoLead & { latitude: number; longitude: number } => !!(l.latitude && l.longitude)).map(l => ({
              ...l,
              latitude: l.latitude!,
              longitude: l.longitude!,
            }))}
            center={[36.6350, 52.5500]}
            zoom={10}
          />
          <p className="text-xs text-gray-400 mt-2 text-center">
            نقشه بر اساس مختصات ثبت‌شده لیدها نمایش داده می‌شود. بر روی هر نقطه کلیک کنید.
          </p>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">دارای مختصات</p>
                <p className="text-2xl font-bold mt-1 text-teal-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(totalWithCoords)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                <Navigation className="w-5 h-5 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">شهرها</p>
                <p className="text-2xl font-bold mt-1 text-orange-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(topCities.length)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200">
                <Building2 className="w-5 h-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">خوشه‌ها</p>
                <p className="text-2xl font-bold mt-1 text-blue-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(clusterCounts.length)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">بخش‌بندی</p>
                <p className="text-2xl font-bold mt-1 text-purple-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(segmentCounts.length)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200">
                <PieChart className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* City distribution chart */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-6">
          <h3 className="text-sm font-bold text-gray-700 mb-4">توزیع شهری</h3>
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-8 rounded-lg" />
              ))}
            </div>
          ) : topCities.length === 0 ? (
            <p className="text-gray-400 text-center py-8">داده‌ای موجود نیست</p>
          ) : (
            <div className="space-y-2.5">
              {topCities.map(([city, count]) => (
                <div key={city} className="flex items-center gap-3">
                  <span className="text-sm text-gray-600 w-28 text-left truncate">{city}</span>
                  <div className="flex-1 bg-gray-100 rounded-full h-7 overflow-hidden">
                    <div
                      className="bg-teal-500 h-full rounded-full flex items-center justify-end px-2 transition-all duration-500"
                      style={{ width: `${Math.max((count / maxCityCount) * 100, 8)}%` }}
                    >
                      <span className="text-white text-xs font-bold">{toPersianNumber(count)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Cluster & Segment breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <h3 className="text-sm font-bold text-gray-700 mb-4">توزیع خوشه‌ای</h3>
            {clusterCounts.length === 0 ? (
              <p className="text-gray-400 text-center py-4">داده‌ای موجود نیست</p>
            ) : (
              <div className="space-y-2">
                {clusterCounts.map(({ key, label, count }) => (
                  <div key={key} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-700">{label}</span>
                    <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                      {toPersianNumber(count)}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <h3 className="text-sm font-bold text-gray-700 mb-4">توزیع بخش‌بندی</h3>
            {segmentCounts.length === 0 ? (
              <p className="text-gray-400 text-center py-4">داده‌ای موجود نیست</p>
            ) : (
              <div className="space-y-2">
                {segmentCounts.map(({ key, label, count }) => (
                  <div key={key} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                    <span className="text-sm text-gray-700">{label}</span>
                    <Badge variant="secondary" className="bg-purple-50 text-purple-700 text-xs">
                      {toPersianNumber(count)}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="جستجوی نام یا تلفن..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10 bg-white"
          />
        </div>
        <Select value={filterCluster} onValueChange={setFilterCluster}>
          <SelectTrigger className="w-full sm:w-44 bg-white">
            <SelectValue placeholder="خوشه" />
          </SelectTrigger>
          <SelectContent>
            {CLUSTER_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterSegment} onValueChange={setFilterSegment}>
          <SelectTrigger className="w-full sm:w-36 bg-white">
            <SelectValue placeholder="بخش" />
          </SelectTrigger>
          <SelectContent>
            {SEGMENT_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterCity} onValueChange={setFilterCity}>
          <SelectTrigger className="w-full sm:w-36 bg-white">
            <SelectValue placeholder="شهر" />
          </SelectTrigger>
          <SelectContent>
            {cityOptions.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchGeoData}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : filteredLeads.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">لیدی با مختصات یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              برای نمایش در نقشه، مختصات جغرافیایی لیدها باید ثبت شود
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">نام</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">تلفن</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">شهر</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">خوشه</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">بخش</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">مختصات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLeads.map((lead) => (
                  <TableRow key={lead.id} className="hover:bg-gray-50/50">
                    <TableCell className="text-sm font-medium">
                      {lead.name}
                    </TableCell>
                    <TableCell className="text-sm text-gray-600 font-mono" dir="ltr">
                      {lead.phone}
                    </TableCell>
                    <TableCell className="text-sm">
                      {lead.geoCity || (
                        <span className="text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs border-0">
                        {CLUSTER_LABELS[lead.cluster] || lead.cluster || '-'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {lead.segment ? (
                        <Badge variant="secondary" className="bg-purple-50 text-purple-700 text-xs border-0">
                          {SEGMENT_LABELS[lead.segment] || lead.segment}
                        </Badge>
                      ) : (
                        <span className="text-gray-400 text-xs">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-gray-500 font-mono" dir="ltr">
                      {lead.latitude && lead.longitude
                        ? `${lead.latitude.toFixed(4)}, ${lead.longitude.toFixed(4)}`
                        : '-'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}
    </div>
  );
}
