'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Shield,
  Plus,
  Edit2,
  Trash2,
  ShieldCheck,
  ShieldAlert,
  Loader2,
  Users,
  Lock,
  Unlock,
  CheckSquare,
  Square,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Permission {
  id: string;
  resource: string;
  action: string;
}

interface Role {
  id: string;
  name: string;
  label: string;
  description: string;
  isSystem: boolean;
  createdAt: string;
  updatedAt: string;
  permissions: Permission[];
  _count?: { users: number };
}

/* ─────────── Constants ─────────── */

const RESOURCES = [
  'leads',
  'courses',
  'payments',
  'reports',
  'settings',
  'exams',
  'users',
  'roles',
  'blog',
  'karamuz',
  'invoices',
  'tickets',
  'campaigns',
  'automation',
  'analytics',
  'knowledge_base',
  'service_contracts',
  'referrers',
  'api_keys',
  'employment',
  'skill_programs',
] as const;

const ACTIONS = ['view', 'create', 'edit', 'delete', 'manage', 'export'] as const;

const RESOURCE_LABELS: Record<string, string> = {
  leads: 'سرنخ‌ها',
  courses: 'دوره‌ها',
  payments: 'پرداخت‌ها',
  reports: 'گزارش‌ها',
  settings: 'تنظیمات',
  exams: 'آزمون‌ها',
  users: 'کاربران',
  roles: 'نقش‌ها',
  blog: 'بلاگ',
  karamuz: 'کارآموزان',
  invoices: 'فاکتورها',
  tickets: 'تیکت‌ها',
  campaigns: 'کمپین‌ها',
  automation: 'اتوماسیون',
  analytics: 'تحلیل‌ها',
  knowledge_base: 'پایگاه دانش',
  service_contracts: 'قراردادها',
  referrers: 'معرف‌ها',
  api_keys: 'کلیدهای API',
  employment: 'استخدام',
  skill_programs: 'دوره‌های مهارتی',
};

const ACTION_LABELS: Record<string, string> = {
  view: 'مشاهده',
  create: 'ایجاد',
  edit: 'ویرایش',
  delete: 'حذف',
  manage: 'مدیریت کامل',
  export: 'خروجی',
};

const ACTION_COLORS: Record<string, string> = {
  view: 'bg-blue-100 text-blue-700',
  create: 'bg-green-100 text-green-700',
  edit: 'bg-yellow-100 text-yellow-700',
  delete: 'bg-red-100 text-red-700',
  manage: 'bg-purple-100 text-purple-700',
  export: 'bg-gray-100 text-gray-700',
};

// Pre-defined role templates
const ROLE_TEMPLATES = [
  {
    name: 'SUPER_ADMIN',
    label: 'مدیر ارشد',
    description: 'دسترسی کامل به تمام بخش‌های سیستم',
    isSystem: true,
    permissions: RESOURCES.flatMap((r) => ACTIONS.map((a) => ({ resource: r, action: a }))),
  },
  {
    name: 'ADMIN',
    label: 'مدیر',
    description: 'دسترسی مدیریتی به اکثر بخش‌ها',
    isSystem: true,
    permissions: RESOURCES.filter((r) => r !== 'roles' && r !== 'settings').flatMap((r) =>
      ACTIONS.filter((a) => a !== 'delete').map((a) => ({ resource: r, action: a }))
    ),
  },
  {
    name: 'SALES',
    label: 'فروش',
    description: 'دسترسی به سرنخ‌ها، پرداخت‌ها و فاکتورها',
    isSystem: true,
    permissions: ['leads', 'payments', 'invoices', 'referrers', 'campaigns', 'analytics'].flatMap((r) =>
      ['view', 'create', 'edit'].map((a) => ({ resource: r, action: a }))
    ),
  },
  {
    name: 'INSTRUCTOR',
    label: 'استاد',
    description: 'دسترسی به دوره‌ها، آزمون‌ها و کارآموزان',
    isSystem: true,
    permissions: ['courses', 'exams', 'karamuz', 'skill_programs', 'knowledge_base'].flatMap((r) =>
      ['view', 'create', 'edit'].map((a) => ({ resource: r, action: a }))
    ),
  },
  {
    name: 'VIEWER',
    label: 'ناظر',
    description: 'فقط مشاهده اطلاعات، بدون امکان ویرایش',
    isSystem: true,
    permissions: RESOURCES.map((r) => ({ resource: r, action: 'view' })),
  },
];

/* ─────────── Component ─────────── */

export default function AdminRolesPage() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedRole, setExpandedRole] = useState<string | null>(null);

  // Dialog states
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showSeedDialog, setShowSeedDialog] = useState(false);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [saving, setSaving] = useState(false);

  // Form states
  const [formName, setFormName] = useState('');
  const [formLabel, setFormLabel] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formPermissions, setFormPermissions] = useState<Set<string>>(new Set());

  const fetchRoles = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/roles');
      if (res.ok) {
        const data = await res.json();
        setRoles(data);
      }
    } catch (error) {
      console.error('Failed to fetch roles:', error);
    }
  }, []);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await fetchRoles();
      setLoading(false);
    };
    load();
  }, [fetchRoles]);

  // ─── Permission Helpers ───
  const permKey = (resource: string, action: string) => `${resource}:${action}`;

  const isPermissionChecked = (resource: string, action: string) => {
    return formPermissions.has(permKey(resource, action));
  };

  const togglePermission = (resource: string, action: string) => {
    setFormPermissions((prev) => {
      const next = new Set(prev);
      const key = permKey(resource, action);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const toggleAllForResource = (resource: string, checked: boolean) => {
    setFormPermissions((prev) => {
      const next = new Set(prev);
      ACTIONS.forEach((action) => {
        const key = permKey(resource, action);
        if (checked) {
          next.add(key);
        } else {
          next.delete(key);
        }
      });
      return next;
    });
  };

  const toggleAllActions = (action: string, checked: boolean) => {
    setFormPermissions((prev) => {
      const next = new Set(prev);
      RESOURCES.forEach((resource) => {
        const key = permKey(resource, action);
        if (checked) {
          next.add(key);
        } else {
          next.delete(key);
        }
      });
      return next;
    });
  };

  const toggleAll = (checked: boolean) => {
    if (checked) {
      const all = new Set<string>();
      RESOURCES.forEach((r) => ACTIONS.forEach((a) => all.add(permKey(r, a))));
      setFormPermissions(all);
    } else {
      setFormPermissions(new Set());
    }
  };

  const formPermissionsToArray = (): { resource: string; action: string }[] => {
    return Array.from(formPermissions).map((key) => {
      const [resource, action] = key.split(':');
      return { resource, action };
    });
  };

  // ─── Create Role ───
  const handleCreate = async () => {
    if (!formName || !formLabel) return;
    setSaving(true);
    try {
      const res = await fetch('/api/admin/roles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          label: formLabel,
          description: formDescription,
          permissions: formPermissionsToArray(),
        }),
      });
      if (res.ok) {
        await fetchRoles();
        resetForm();
        setShowCreateDialog(false);
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در ایجاد نقش');
      }
    } catch {
      alert('خطا در ایجاد نقش');
    } finally {
      setSaving(false);
    }
  };

  // ─── Update Role ───
  const handleUpdate = async () => {
    if (!selectedRole || !formName || !formLabel) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/roles/${selectedRole.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          label: formLabel,
          description: formDescription,
          permissions: formPermissionsToArray(),
        }),
      });
      if (res.ok) {
        await fetchRoles();
        resetForm();
        setShowEditDialog(false);
        setSelectedRole(null);
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در به‌روزرسانی نقش');
      }
    } catch {
      alert('خطا در به‌روزرسانی نقش');
    } finally {
      setSaving(false);
    }
  };

  // ─── Delete Role ───
  const handleDelete = async () => {
    if (!selectedRole) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/roles/${selectedRole.id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        await fetchRoles();
        setShowDeleteDialog(false);
        setSelectedRole(null);
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در حذف نقش');
      }
    } catch {
      alert('خطا در حذف نقش');
    } finally {
      setSaving(false);
    }
  };

  // ─── Seed Default Roles ───
  const handleSeedRoles = async () => {
    setSaving(true);
    try {
      for (const template of ROLE_TEMPLATES) {
        // Check if role already exists
        const existing = roles.find((r) => r.name === template.name);
        if (!existing) {
          await fetch('/api/admin/roles', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(template),
          });
        }
      }
      await fetchRoles();
      setShowSeedDialog(false);
    } catch {
      alert('خطا در ایجاد نقش‌های پیش‌فرض');
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setFormName('');
    setFormLabel('');
    setFormDescription('');
    setFormPermissions(new Set());
  };

  const openEditDialog = (role: Role) => {
    setSelectedRole(role);
    setFormName(role.name);
    setFormLabel(role.label);
    setFormDescription(role.description);
    const perms = new Set<string>();
    role.permissions.forEach((p) => {
      perms.add(permKey(p.resource, p.action));
    });
    setFormPermissions(perms);
    setShowEditDialog(true);
  };

  const openDeleteDialog = (role: Role) => {
    setSelectedRole(role);
    setShowDeleteDialog(true);
  };

  // Stats
  const totalRoles = roles.length;
  const totalPermissions = roles.reduce((sum, r) => sum + r.permissions.length, 0);
  const systemRoles = roles.filter((r) => r.isSystem).length;
  const customRoles = roles.filter((r) => !r.isSystem).length;
  const hasDefaultRoles = ROLE_TEMPLATES.every((t) => roles.some((r) => r.name === t.name));

  /* ─────────── Permission Matrix Component ─────────── */
  const PermissionMatrix = () => (
    <div className="border rounded-lg overflow-hidden">
      <div className="overflow-x-auto max-h-80 overflow-y-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 sticky top-0">
            <tr>
              <th className="px-3 py-2 text-right font-medium text-gray-700 min-w-[140px] border-b border-l">
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={formPermissions.size === RESOURCES.length * ACTIONS.length}
                    onCheckedChange={(checked) => toggleAll(!!checked)}
                  />
                  <span>منبع</span>
                </div>
              </th>
              {ACTIONS.map((action) => (
                <th key={action} className="px-2 py-2 text-center font-medium text-gray-700 min-w-[70px] border-b border-l">
                  <div className="flex flex-col items-center gap-1">
                    <Checkbox
                      checked={RESOURCES.every((r) => formPermissions.has(permKey(r, action)))}
                      onCheckedChange={(checked) => toggleAllActions(action, !!checked)}
                    />
                    <span className={`text-xs px-1.5 py-0.5 rounded ${ACTION_COLORS[action]}`}>
                      {ACTION_LABELS[action]}
                    </span>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {RESOURCES.map((resource) => {
              const allChecked = ACTIONS.every((a) => formPermissions.has(permKey(resource, a)));
              const someChecked = ACTIONS.some((a) => formPermissions.has(permKey(resource, a)));
              return (
                <tr key={resource} className="border-b last:border-b-0 hover:bg-gray-50/50">
                  <td className="px-3 py-2 border-l">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        checked={allChecked}
                        ref={(el) => {
                          if (el) {
                            (el as unknown as HTMLInputElement).dataset.state = someChecked && !allChecked ? 'indeterminate' : allChecked ? 'checked' : 'unchecked';
                          }
                        }}
                        onCheckedChange={(checked) => toggleAllForResource(resource, !!checked)}
                      />
                      <span className="text-gray-800 font-medium text-xs">
                        {RESOURCE_LABELS[resource] || resource}
                      </span>
                    </div>
                  </td>
                  {ACTIONS.map((action) => (
                    <td key={`${resource}-${action}`} className="px-2 py-2 text-center border-l">
                      <Checkbox
                        checked={isPermissionChecked(resource, action)}
                        onCheckedChange={() => togglePermission(resource, action)}
                      />
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  /* ─────────── Render ─────────── */

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
            <Shield className="h-5 w-5 text-purple-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">مدیریت نقش‌ها و دسترسی‌ها</h1>
            <p className="text-sm text-gray-500">تعریف نقش‌ها و سطح دسترسی کاربران به بخش‌های مختلف سیستم</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {!hasDefaultRoles && (
            <Button
              variant="outline"
              onClick={() => setShowSeedDialog(true)}
              className="gap-2"
            >
              <Lock className="h-4 w-4" />
              ایجاد نقش‌های پیش‌فرض
            </Button>
          )}
          <Button onClick={() => { resetForm(); setShowCreateDialog(true); }} className="gap-2">
            <Plus className="h-4 w-4" />
            نقش جدید
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center">
              <Shield className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(totalRoles)}</p>
              <p className="text-xs text-gray-500">کل نقش‌ها</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
              <Lock className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(systemRoles)}</p>
              <p className="text-xs text-gray-500">نقش‌های سیستمی</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
              <Unlock className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(customRoles)}</p>
              <p className="text-xs text-gray-500">نقش‌های سفارشی</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-50 flex items-center justify-center">
              <ShieldCheck className="h-5 w-5 text-orange-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(totalPermissions)}</p>
              <p className="text-xs text-gray-500">کل دسترسی‌ها</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Roles List */}
      <div className="space-y-3">
        {roles.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-16 text-gray-400">
              <Shield className="h-12 w-12 mb-3" />
              <p className="text-sm mb-2">هنوز نقشی تعریف نشده است</p>
              <p className="text-xs">با کلیک روی &quot;ایجاد نقش‌های پیش‌فرض&quot; نقش‌های استاندارد سیستم را ایجاد کنید</p>
            </CardContent>
          </Card>
        ) : (
          roles.map((role) => (
            <Card key={role.id} className="overflow-hidden">
              <div
                className="p-4 cursor-pointer flex items-center justify-between hover:bg-gray-50/50"
                onClick={() => setExpandedRole(expandedRole === role.id ? null : role.id)}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    role.isSystem ? 'bg-blue-100' : 'bg-green-100'
                  }`}>
                    {role.isSystem ? (
                      <Lock className="h-5 w-5 text-blue-600" />
                    ) : (
                      <Unlock className="h-5 w-5 text-green-600" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-gray-900">{role.label}</h3>
                      <code className="text-xs bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded" dir="ltr">
                        {role.name}
                      </code>
                      {role.isSystem && (
                        <Badge className="bg-blue-100 text-blue-700 text-xs">سیستمی</Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 mt-0.5">{role.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-left">
                    <div className="flex items-center gap-1.5 text-sm text-gray-600">
                      <Users className="h-4 w-4" />
                      <span>{toPersianNumber(role._count?.users || 0)} کاربر</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-sm text-gray-500">
                      <ShieldCheck className="h-3.5 w-3.5" />
                      <span>{toPersianNumber(role.permissions.length)} دسترسی</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEditDialog(role)}
                      title="ویرایش"
                    >
                      <Edit2 className="h-4 w-4 text-gray-500" />
                    </Button>
                    {!role.isSystem && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openDeleteDialog(role)}
                        title="حذف"
                      >
                        <Trash2 className="h-4 w-4 text-red-400" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              {/* Expanded permissions */}
              {expandedRole === role.id && (
                <div className="border-t bg-gray-50/50 p-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-3">دسترسی‌های تعریف شده:</h4>
                  {role.permissions.length === 0 ? (
                    <p className="text-sm text-gray-400">هیچ دسترسی تعریف نشده است</p>
                  ) : (
                    <div className="space-y-2">
                      {RESOURCES.filter((r) => role.permissions.some((p) => p.resource === r)).map((resource) => {
                        const resourcePerms = role.permissions.filter((p) => p.resource === resource);
                        return (
                          <div key={resource} className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-medium text-gray-600 min-w-[100px]">
                              {RESOURCE_LABELS[resource]}:
                            </span>
                            <div className="flex gap-1 flex-wrap">
                              {resourcePerms.map((p) => (
                                <Badge
                                  key={`${p.resource}-${p.action}`}
                                  variant="secondary"
                                  className={`text-xs ${ACTION_COLORS[p.action] || ''}`}
                                >
                                  {ACTION_LABELS[p.action] || p.action}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </Card>
          ))
        )}
      </div>

      {/* Create Role Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-teal-600" />
              ایجاد نقش جدید
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">
                  نام نقش (انگلیسی) <span className="text-red-500">*</span>
                </label>
                <Input
                  placeholder="مثلاً: CONTENT_MANAGER"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value.toUpperCase().replace(/\s+/g, '_'))}
                  dir="ltr"
                />
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">
                  عنوان نمایشی <span className="text-red-500">*</span>
                </label>
                <Input
                  placeholder="مثلاً: مدیر محتوا"
                  value={formLabel}
                  onChange={(e) => setFormLabel(e.target.value)}
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                توضیحات
              </label>
              <Input
                placeholder="توضیح مختصری از نقش و مسئولیت‌های آن"
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                ماتریس دسترسی‌ها
              </label>
              <PermissionMatrix />
              <p className="text-xs text-gray-400 mt-2">
                {toPersianNumber(formPermissions.size)} دسترسی انتخاب شده از {toPersianNumber(RESOURCES.length * ACTIONS.length)} مورد
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
            >
              انصراف
            </Button>
            <Button
              onClick={handleCreate}
              disabled={!formName || !formLabel || saving}
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin ml-2" />
              ) : (
                <Plus className="h-4 w-4 ml-2" />
              )}
              ایجاد نقش
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Role Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit2 className="h-5 w-5 text-teal-600" />
              ویرایش نقش: {selectedRole?.label}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">
                  نام نقش (انگلیسی)
                </label>
                <Input
                  value={formName}
                  onChange={(e) => setFormName(e.target.value.toUpperCase().replace(/\s+/g, '_'))}
                  dir="ltr"
                  disabled={selectedRole?.isSystem}
                />
                {selectedRole?.isSystem && (
                  <p className="text-xs text-blue-500 mt-1">نام نقش‌های سیستمی قابل تغییر نیست</p>
                )}
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700 mb-1 block">
                  عنوان نمایشی
                </label>
                <Input
                  value={formLabel}
                  onChange={(e) => setFormLabel(e.target.value)}
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                توضیحات
              </label>
              <Input
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">
                ماتریس دسترسی‌ها
              </label>
              <PermissionMatrix />
              <p className="text-xs text-gray-400 mt-2">
                {toPersianNumber(formPermissions.size)} دسترسی انتخاب شده از {toPersianNumber(RESOURCES.length * ACTIONS.length)} مورد
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
            >
              انصراف
            </Button>
            <Button
              onClick={handleUpdate}
              disabled={!formName || !formLabel || saving}
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin ml-2" />
              ) : null}
              ذخیره تغییرات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-red-500" />
              حذف نقش
            </AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف نقش <strong>{selectedRole?.label}</strong> اطمینان دارید؟
              تمام دسترسی‌های مرتبط با این نقش حذف خواهند شد.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : null}
              حذف نقش
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Seed Default Roles Confirmation */}
      <AlertDialog open={showSeedDialog} onOpenChange={setShowSeedDialog}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-blue-500" />
              ایجاد نقش‌های پیش‌فرض
            </AlertDialogTitle>
            <AlertDialogDescription>
              نقش‌های استاندارد سیستم شامل <strong>مدیر ارشد، مدیر، فروش، استاد و ناظر</strong> ایجاد خواهند شد.
              نقش‌هایی که قبلاً ایجاد شده‌اند دوباره ساخته نمی‌شوند.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleSeedRoles}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : null}
              ایجاد نقش‌ها
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
