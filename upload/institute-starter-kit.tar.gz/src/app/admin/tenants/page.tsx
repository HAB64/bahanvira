'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Building2,
  Plus,
  Search,
  Edit2,
  Ban,
  Loader2,
  CheckCircle2,
  Clock,
  XCircle,
  Users,
  Palette,
  Globe,
  ShieldAlert,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface WhiteLabel {
  brandName: string;
  isActive: boolean;
}

interface TenantParent {
  id: string;
  name: string;
  slug: string;
}

interface Tenant {
  id: string;
  name: string;
  slug: string;
  domain: string | null;
  primaryColor: string;
  plan: string;
  status: string;
  maxUsers: number;
  locale: string;
  currency: string;
  parentId: string | null;
  createdAt: string;
  updatedAt: string;
  parent?: TenantParent | null;
  whiteLabel?: WhiteLabel | null;
  _count?: {
    children: number;
    billingRecords: number;
    usageLogs: number;
  };
}

interface TenantStats {
  total: number;
  active: number;
  trial: number;
  expired: number;
}

/* ─────────── Constants ─────────── */

const STATUS_MAP: Record<string, { label: string; color: string; icon: React.ElementType }> = {
  ACTIVE: { label: 'فعال', color: 'bg-green-100 text-green-700 border-green-200', icon: CheckCircle2 },
  TRIAL: { label: 'آزمایشی', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: Clock },
  SUSPENDED: { label: 'معلق', color: 'bg-red-100 text-red-700 border-red-200', icon: XCircle },
  EXPIRED: { label: 'منقضی', color: 'bg-gray-100 text-gray-600 border-gray-200', icon: ShieldAlert },
};

const PLAN_MAP: Record<string, { label: string; color: string; description: string }> = {
  BASIC: {
    label: 'پایه',
    color: 'bg-gray-100 text-gray-700 border-gray-200',
    description: 'تا ۵۰ کاربر — ۱ گیگابایت فضای ذخیره‌سازی',
  },
  PROFESSIONAL: {
    label: 'حرفه‌ای',
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    description: 'تا ۲۰۰ کاربر — ۱۰ گیگابایت فضای ذخیره‌سازی',
  },
  ENTERPRISE: {
    label: 'سازمانی',
    color: 'bg-amber-100 text-amber-700 border-amber-200',
    description: 'نامحدود کاربر — فضای ذخیره‌سازی نامحدود',
  },
};

/* ─────────── Slug Helper ─────────── */

function nameToSlug(name: string): string {
  return name
    .trim()
    .replace(/[\s]+/g, '-')
    .replace(/[^\u0600-\u06FFa-zA-Z0-9\-]/g, '')
    .toLowerCase();
}

/* ─────────── Component ─────────── */

export default function TenantsPage() {
  /* ─── State ─── */
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [stats, setStats] = useState<TenantStats>({ total: 0, active: 0, trial: 0, expired: 0 });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [planFilter, setPlanFilter] = useState<string>('ALL');

  // Dialog
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedTenant, setSelectedTenant] = useState<Tenant | null>(null);

  // Form
  const [formName, setFormName] = useState('');
  const [formSlug, setFormSlug] = useState('');
  const [formDomain, setFormDomain] = useState('');
  const [formPlan, setFormPlan] = useState('BASIC');
  const [formPrimaryColor, setFormPrimaryColor] = useState('#0d9488');
  const [formLocale, setFormLocale] = useState('fa');
  const [formCurrency, setFormCurrency] = useState('IRR');
  const [formParentId, setFormParentId] = useState<string>('NONE');
  const [slugManual, setSlugManual] = useState(false);

  /* ─── Data Fetching ─── */

  const fetchTenants = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (statusFilter && statusFilter !== 'ALL') params.set('status', statusFilter);
      if (planFilter && planFilter !== 'ALL') params.set('plan', planFilter);
      if (searchQuery.trim()) params.set('search', searchQuery.trim());

      const res = await fetch(`/api/admin/tenants?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setTenants(data.tenants || []);
        setStats(data.stats || { total: 0, active: 0, trial: 0, expired: 0 });
      }
    } catch (error) {
      console.error('Failed to fetch tenants:', error);
    }
  }, [statusFilter, planFilter, searchQuery]);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await fetchTenants();
      setLoading(false);
    };
    load();
  }, [fetchTenants]);

  /* ─── Form Helpers ─── */

  const resetForm = () => {
    setFormName('');
    setFormSlug('');
    setFormDomain('');
    setFormPlan('BASIC');
    setFormPrimaryColor('#0d9488');
    setFormLocale('fa');
    setFormCurrency('IRR');
    setFormParentId('NONE');
    setSlugManual(false);
  };

  const handleNameChange = (value: string) => {
    setFormName(value);
    if (!slugManual) {
      setFormSlug(nameToSlug(value));
    }
  };

  const handleSlugChange = (value: string) => {
    setFormSlug(value);
    setSlugManual(true);
  };

  const openEditDialog = (tenant: Tenant) => {
    setSelectedTenant(tenant);
    setFormName(tenant.name);
    setFormSlug(tenant.slug);
    setFormDomain(tenant.domain || '');
    setFormPlan(tenant.plan);
    setFormPrimaryColor(tenant.primaryColor);
    setFormLocale(tenant.locale);
    setFormCurrency(tenant.currency);
    setFormParentId(tenant.parentId || 'NONE');
    setSlugManual(true);
    setShowEditDialog(true);
  };

  const openCreateDialog = () => {
    resetForm();
    setShowCreateDialog(true);
  };

  /* ─── CRUD ─── */

  const handleCreate = async () => {
    if (!formName || !formSlug) return;
    setSaving(true);
    try {
      const res = await fetch('/api/admin/tenants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          slug: formSlug,
          domain: formDomain || null,
          plan: formPlan,
          primaryColor: formPrimaryColor,
          locale: formLocale,
          currency: formCurrency,
          parentId: formParentId === 'NONE' ? null : formParentId,
        }),
      });
      if (res.ok) {
        await fetchTenants();
        setShowCreateDialog(false);
        resetForm();
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در ایجاد Tenant');
      }
    } catch {
      alert('خطا در ایجاد Tenant');
    } finally {
      setSaving(false);
    }
  };

  const handleUpdate = async () => {
    if (!selectedTenant) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/tenants/${selectedTenant.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          domain: formDomain || null,
          plan: formPlan,
          primaryColor: formPrimaryColor,
          locale: formLocale,
          currency: formCurrency,
          parentId: formParentId === 'NONE' ? null : formParentId,
        }),
      });
      if (res.ok) {
        await fetchTenants();
        setShowEditDialog(false);
        setSelectedTenant(null);
        resetForm();
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در به‌روزرسانی Tenant');
      }
    } catch {
      alert('خطا در به‌روزرسانی Tenant');
    } finally {
      setSaving(false);
    }
  };

  const handleSuspend = async (tenant: Tenant) => {
    const newStatus = tenant.status === 'SUSPENDED' ? 'ACTIVE' : 'SUSPENDED';
    const confirmMsg =
      newStatus === 'SUSPENDED'
        ? `آیا از تعلیق Tenant «${tenant.name}» اطمینان دارید؟`
        : `آیا از فعال‌سازی مجدد Tenant «${tenant.name}» اطمینان دارید؟`;

    if (!confirm(confirmMsg)) return;

    setSaving(true);
    try {
      const res = await fetch(`/api/admin/tenants/${tenant.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        await fetchTenants();
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در تغییر وضعیت Tenant');
      }
    } catch {
      alert('خطا در تغییر وضعیت Tenant');
    } finally {
      setSaving(false);
    }
  };

  /* ─────────── Render ─────────── */

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* ─── Header ─── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center">
            <Building2 className="h-5 w-5 text-teal-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">مدیریت Tenantها</h1>
            <p className="text-sm text-gray-500">معماری Multi-Tenant — مدیریت سازمان‌ها و شعب</p>
          </div>
        </div>
        <Button onClick={openCreateDialog} className="gap-2">
          <Plus className="h-4 w-4" />
          ایجاد Tenant
        </Button>
      </div>

      {/* ─── Stats Cards ─── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center">
              <Building2 className="h-5 w-5 text-gray-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(stats.total)}</p>
              <p className="text-xs text-gray-500">کل Tenantها</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(stats.active)}</p>
              <p className="text-xs text-gray-500">فعال</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
              <Clock className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(stats.trial)}</p>
              <p className="text-xs text-gray-500">آزمایشی</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-50 flex items-center justify-center">
              <XCircle className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(stats.expired)}</p>
              <p className="text-xs text-gray-500">منقضی</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ─── Filters ─── */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="جستجو بر اساس نام، شناسه یا دامنه..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[160px]">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه وضعیت‌ها</SelectItem>
                <SelectItem value="ACTIVE">فعال</SelectItem>
                <SelectItem value="TRIAL">آزمایشی</SelectItem>
                <SelectItem value="SUSPENDED">معلق</SelectItem>
                <SelectItem value="EXPIRED">منقضی</SelectItem>
              </SelectContent>
            </Select>
            <Select value={planFilter} onValueChange={setPlanFilter}>
              <SelectTrigger className="w-full sm:w-[160px]">
                <SelectValue placeholder="پلن" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه پلن‌ها</SelectItem>
                <SelectItem value="BASIC">پایه</SelectItem>
                <SelectItem value="PROFESSIONAL">حرفه‌ای</SelectItem>
                <SelectItem value="ENTERPRISE">سازمانی</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* ─── Tenants Table ─── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">لیست Tenantها</CardTitle>
          <CardDescription>
            {toPersianNumber(tenants.length)} Tenant یافت شد
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {tenants.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-gray-400">
              <Building2 className="h-12 w-12 mb-3" />
              <p className="text-sm">هیچ Tenantی یافت نشد</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">نام</TableHead>
                    <TableHead className="text-right">شناسه</TableHead>
                    <TableHead className="text-right">دامنه</TableHead>
                    <TableHead className="text-right">پلن</TableHead>
                    <TableHead className="text-right">وضعیت</TableHead>
                    <TableHead className="text-right">حداکثر کاربران</TableHead>
                    <TableHead className="text-right">فرزند</TableHead>
                    <TableHead className="text-right">White-Label</TableHead>
                    <TableHead className="text-right">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tenants.map((tenant) => {
                    const statusInfo = STATUS_MAP[tenant.status] || STATUS_MAP.ACTIVE;
                    const planInfo = PLAN_MAP[tenant.plan] || PLAN_MAP.BASIC;
                    const hasWhiteLabel = !!(tenant.whiteLabel && tenant.whiteLabel.isActive);
                    const StatusIcon = statusInfo.icon;

                    return (
                      <TableRow key={tenant.id} className="group">
                        {/* نام */}
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span
                              className="w-3 h-3 rounded-full flex-shrink-0 border border-white shadow-sm"
                              style={{ backgroundColor: tenant.primaryColor }}
                            />
                            <span className="font-medium text-gray-900">{tenant.name}</span>
                          </div>
                        </TableCell>

                        {/* شناسه */}
                        <TableCell>
                          <code className="text-xs bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded font-mono">
                            {tenant.slug}
                          </code>
                        </TableCell>

                        {/* دامنه */}
                        <TableCell>
                          {tenant.domain ? (
                            <span className="text-sm text-gray-700 flex items-center gap-1">
                              <Globe className="h-3.5 w-3.5 text-gray-400" />
                              {tenant.domain}
                            </span>
                          ) : (
                            <span className="text-xs text-gray-400">—</span>
                          )}
                        </TableCell>

                        {/* پلن */}
                        <TableCell>
                          <Badge variant="outline" className={planInfo.color}>
                            {planInfo.label}
                          </Badge>
                        </TableCell>

                        {/* وضعیت */}
                        <TableCell>
                          <Badge variant="outline" className={`${statusInfo.color} gap-1`}>
                            <StatusIcon className="h-3 w-3" />
                            {statusInfo.label}
                          </Badge>
                        </TableCell>

                        {/* حداکثر کاربران */}
                        <TableCell className="text-center">
                          <span className="text-sm flex items-center justify-center gap-1">
                            <Users className="h-3.5 w-3.5 text-gray-400" />
                            {toPersianNumber(tenant.maxUsers)}
                          </span>
                        </TableCell>

                        {/* فرزند */}
                        <TableCell className="text-center">
                          <span className="text-sm text-gray-600">
                            {toPersianNumber(tenant._count?.children ?? 0)}
                          </span>
                        </TableCell>

                        {/* White-Label */}
                        <TableCell className="text-center">
                          {hasWhiteLabel ? (
                            <Badge className="bg-green-100 text-green-700 hover:bg-green-100 border-0 text-xs">
                              بله
                            </Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-500 hover:bg-gray-100 border-0 text-xs">
                              خیر
                            </Badge>
                          )}
                        </TableCell>

                        {/* عملیات */}
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-gray-500 hover:text-teal-600"
                              onClick={() => openEditDialog(tenant)}
                              title="ویرایش"
                            >
                              <Edit2 className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className={`h-8 w-8 ${
                                tenant.status === 'SUSPENDED'
                                  ? 'text-green-500 hover:text-green-700'
                                  : 'text-red-500 hover:text-red-700'
                              }`}
                              onClick={() => handleSuspend(tenant)}
                              title={tenant.status === 'SUSPENDED' ? 'فعال‌سازی' : 'تعلیق'}
                              disabled={saving}
                            >
                              <Ban className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ─── Create Dialog ─── */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-teal-600" />
              ایجاد Tenant جدید
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {/* نام */}
            <div className="space-y-2">
              <Label htmlFor="create-name">
                نام <span className="text-red-500">*</span>
              </Label>
              <Input
                id="create-name"
                placeholder="نام سازمان یا شعبه"
                value={formName}
                onChange={(e) => handleNameChange(e.target.value)}
              />
            </div>

            {/* شناسه */}
            <div className="space-y-2">
              <Label htmlFor="create-slug">
                شناسه <span className="text-red-500">*</span>
              </Label>
              <Input
                id="create-slug"
                placeholder="شناسه یکتا (مثال: beehan-rayaneh)"
                value={formSlug}
                onChange={(e) => handleSlugChange(e.target.value)}
                className="font-mono text-sm"
                dir="ltr"
              />
              <p className="text-xs text-gray-400">
                این شناسه در URL استفاده می‌شود و باید یکتا باشد
              </p>
            </div>

            {/* دامنه */}
            <div className="space-y-2">
              <Label htmlFor="create-domain">دامنه اختصاصی</Label>
              <Input
                id="create-domain"
                placeholder="مثال: example.com"
                value={formDomain}
                onChange={(e) => setFormDomain(e.target.value)}
                dir="ltr"
              />
            </div>

            {/* پلن */}
            <div className="space-y-2">
              <Label>پلن</Label>
              <Select value={formPlan} onValueChange={setFormPlan}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BASIC">
                    <div className="flex flex-col items-start">
                      <span>پایه (BASIC)</span>
                      <span className="text-xs text-gray-400">
                        {PLAN_MAP.BASIC.description}
                      </span>
                    </div>
                  </SelectItem>
                  <SelectItem value="PROFESSIONAL">
                    <div className="flex flex-col items-start">
                      <span>حرفه‌ای (PROFESSIONAL)</span>
                      <span className="text-xs text-gray-400">
                        {PLAN_MAP.PROFESSIONAL.description}
                      </span>
                    </div>
                  </SelectItem>
                  <SelectItem value="ENTERPRISE">
                    <div className="flex flex-col items-start">
                      <span>سازمانی (ENTERPRISE)</span>
                      <span className="text-xs text-gray-400">
                        {PLAN_MAP.ENTERPRISE.description}
                      </span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* رنگ اصلی */}
            <div className="space-y-2">
              <Label htmlFor="create-color" className="flex items-center gap-2">
                <Palette className="h-4 w-4" />
                رنگ اصلی
              </Label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  id="create-color"
                  value={formPrimaryColor}
                  onChange={(e) => setFormPrimaryColor(e.target.value)}
                  className="w-10 h-10 rounded-lg border border-gray-200 cursor-pointer p-0.5"
                />
                <Input
                  value={formPrimaryColor}
                  onChange={(e) => setFormPrimaryColor(e.target.value)}
                  className="w-32 font-mono text-sm"
                  dir="ltr"
                  maxLength={7}
                />
                <span
                  className="w-6 h-6 rounded-full border border-gray-200 flex-shrink-0"
                  style={{ backgroundColor: formPrimaryColor }}
                />
              </div>
            </div>

            {/* زبان و واحد پول */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>زبان</Label>
                <Select value={formLocale} onValueChange={setFormLocale}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fa">فارسی (fa)</SelectItem>
                    <SelectItem value="en">انگلیسی (en)</SelectItem>
                    <SelectItem value="ar">عربی (ar)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>واحد پول</Label>
                <Select value={formCurrency} onValueChange={setFormCurrency}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="IRR">ریال (IRR)</SelectItem>
                    <SelectItem value="IRT">تومان (IRT)</SelectItem>
                    <SelectItem value="USD">دلار (USD)</SelectItem>
                    <SelectItem value="EUR">یورو (EUR)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Tenant والد */}
            <div className="space-y-2">
              <Label>Tenant والد</Label>
              <Select value={formParentId} onValueChange={setFormParentId}>
                <SelectTrigger>
                  <SelectValue placeholder="بدون والد" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="NONE">بدون والد (Tenant اصلی)</SelectItem>
                  {tenants
                    .filter((t) => t.id !== selectedTenant?.id)
                    .map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.name} ({t.slug})
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-400">
                Tenant والد برای ساختار فرانچایزی و شعب استفاده می‌شود
              </p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
              disabled={saving}
            >
              انصراف
            </Button>
            <Button onClick={handleCreate} disabled={saving || !formName || !formSlug}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin ml-2" />
                  در حال ایجاد...
                </>
              ) : (
                'ایجاد Tenant'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Edit Dialog ─── */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit2 className="h-5 w-5 text-teal-600" />
              ویرایش Tenant
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {/* نام */}
            <div className="space-y-2">
              <Label htmlFor="edit-name">
                نام <span className="text-red-500">*</span>
              </Label>
              <Input
                id="edit-name"
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
              />
            </div>

            {/* شناسه (readonly) */}
            <div className="space-y-2">
              <Label htmlFor="edit-slug">شناسه</Label>
              <Input
                id="edit-slug"
                value={formSlug}
                readOnly
                className="font-mono text-sm bg-gray-50 text-gray-500"
                dir="ltr"
              />
              <p className="text-xs text-gray-400">شناسه پس از ایجاد قابل تغییر نیست</p>
            </div>

            {/* دامنه */}
            <div className="space-y-2">
              <Label htmlFor="edit-domain">دامنه اختصاصی</Label>
              <Input
                id="edit-domain"
                placeholder="مثال: example.com"
                value={formDomain}
                onChange={(e) => setFormDomain(e.target.value)}
                dir="ltr"
              />
            </div>

            {/* پلن */}
            <div className="space-y-2">
              <Label>پلن</Label>
              <Select value={formPlan} onValueChange={setFormPlan}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BASIC">
                    <div className="flex flex-col items-start">
                      <span>پایه (BASIC)</span>
                      <span className="text-xs text-gray-400">
                        {PLAN_MAP.BASIC.description}
                      </span>
                    </div>
                  </SelectItem>
                  <SelectItem value="PROFESSIONAL">
                    <div className="flex flex-col items-start">
                      <span>حرفه‌ای (PROFESSIONAL)</span>
                      <span className="text-xs text-gray-400">
                        {PLAN_MAP.PROFESSIONAL.description}
                      </span>
                    </div>
                  </SelectItem>
                  <SelectItem value="ENTERPRISE">
                    <div className="flex flex-col items-start">
                      <span>سازمانی (ENTERPRISE)</span>
                      <span className="text-xs text-gray-400">
                        {PLAN_MAP.ENTERPRISE.description}
                      </span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* رنگ اصلی */}
            <div className="space-y-2">
              <Label htmlFor="edit-color" className="flex items-center gap-2">
                <Palette className="h-4 w-4" />
                رنگ اصلی
              </Label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  id="edit-color"
                  value={formPrimaryColor}
                  onChange={(e) => setFormPrimaryColor(e.target.value)}
                  className="w-10 h-10 rounded-lg border border-gray-200 cursor-pointer p-0.5"
                />
                <Input
                  value={formPrimaryColor}
                  onChange={(e) => setFormPrimaryColor(e.target.value)}
                  className="w-32 font-mono text-sm"
                  dir="ltr"
                  maxLength={7}
                />
                <span
                  className="w-6 h-6 rounded-full border border-gray-200 flex-shrink-0"
                  style={{ backgroundColor: formPrimaryColor }}
                />
              </div>
            </div>

            {/* زبان و واحد پول */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>زبان</Label>
                <Select value={formLocale} onValueChange={setFormLocale}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fa">فارسی (fa)</SelectItem>
                    <SelectItem value="en">انگلیسی (en)</SelectItem>
                    <SelectItem value="ar">عربی (ar)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>واحد پول</Label>
                <Select value={formCurrency} onValueChange={setFormCurrency}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="IRR">ریال (IRR)</SelectItem>
                    <SelectItem value="IRT">تومان (IRT)</SelectItem>
                    <SelectItem value="USD">دلار (USD)</SelectItem>
                    <SelectItem value="EUR">یورو (EUR)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Tenant والد */}
            <div className="space-y-2">
              <Label>Tenant والد</Label>
              <Select value={formParentId} onValueChange={setFormParentId}>
                <SelectTrigger>
                  <SelectValue placeholder="بدون والد" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="NONE">بدون والد (Tenant اصلی)</SelectItem>
                  {tenants
                    .filter((t) => t.id !== selectedTenant?.id)
                    .map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.name} ({t.slug})
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setShowEditDialog(false);
                setSelectedTenant(null);
                resetForm();
              }}
              disabled={saving}
            >
              انصراف
            </Button>
            <Button onClick={handleUpdate} disabled={saving || !formName}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin ml-2" />
                  در حال ذخیره...
                </>
              ) : (
                'ذخیره تغییرات'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
