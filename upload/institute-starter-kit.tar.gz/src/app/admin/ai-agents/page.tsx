'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Bot, Plus, Power, Trash2, Edit3, MessageSquare, Eye,
  BarChart3, Users, TrendingUp, Clock, AlertCircle,
  Search, Filter, ChevronLeft, Send, X, Sparkles,
  ArrowRightLeft, CheckCircle2, XCircle, Activity,
  Zap, RefreshCw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

// ─── Types ────────────────────────────────────────────────────────────────────

interface AgentStats {
  totalConversations: number;
  activeConversations: number;
  enrolledConversations: number;
  handedOffConversations: number;
  conversionRate: number;
}

interface Agent {
  id: string;
  name: string;
  type: string;
  description: string;
  systemPrompt: string;
  isActive: boolean;
  maxConversations: number;
  responseDelayMs: number;
  handoffToHuman: boolean;
  handoffCondition: string | null;
  createdAt: string;
  updatedAt: string;
  stats: AgentStats;
}

interface ConversationMessage {
  id: string;
  role: string;
  content: string;
  metadata: Record<string, unknown> | null;
  createdAt: string;
}

interface Conversation {
  id: string;
  agentId: string;
  leadId: string | null;
  karAmuzId: string | null;
  sessionId: string;
  channel: string;
  status: string;
  context: Record<string, unknown> | null;
  sentiment: string | null;
  outcome: string | null;
  startedAt: string;
  endedAt: string | null;
  agent: { id: string; name: string; type: string };
  _count: { messages: number };
  messages?: ConversationMessage[];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const AGENT_TYPE_LABELS: Record<string, string> = {
  SALES: 'فروش',
  SUPPORT: 'پشتیبانی',
  CONSULTANT: 'مشاور',
  FOLLOW_UP: 'پیگیری',
  RETENTION: 'حفظ مشتری',
};

const AGENT_TYPE_COLORS: Record<string, string> = {
  SALES: 'bg-green-100 text-green-800',
  SUPPORT: 'bg-blue-100 text-blue-800',
  CONSULTANT: 'bg-purple-100 text-purple-800',
  FOLLOW_UP: 'bg-amber-100 text-amber-800',
  RETENTION: 'bg-rose-100 text-rose-800',
};

const STATUS_LABELS: Record<string, string> = {
  ACTIVE: 'فعال',
  COMPLETED: 'تکمیل‌شده',
  HANDED_OFF: 'ارجاع‌شده',
  EXPIRED: 'منقضی',
};

const STATUS_COLORS: Record<string, string> = {
  ACTIVE: 'bg-green-100 text-green-800',
  COMPLETED: 'bg-gray-100 text-gray-800',
  HANDED_OFF: 'bg-amber-100 text-amber-800',
  EXPIRED: 'bg-red-100 text-red-800',
};

const SENTIMENT_LABELS: Record<string, string> = {
  POSITIVE: 'مثبت',
  NEUTRAL: 'خنثی',
  NEGATIVE: 'منفی',
};

const SENTIMENT_COLORS: Record<string, string> = {
  POSITIVE: 'bg-green-100 text-green-700',
  NEUTRAL: 'bg-gray-100 text-gray-700',
  NEGATIVE: 'bg-red-100 text-red-700',
};

const OUTCOME_LABELS: Record<string, string> = {
  ENROLLED: 'ثبت‌نام',
  INFORMED: 'اطلاع‌رسانی',
  HANDED_OFF: 'ارجاع',
  ABANDONED: 'رها شده',
};

function formatDate(dateStr: string) {
  try {
    const date = new Date(dateStr);
    return date.toLocaleDateString('fa-IR', {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function AIAgentsPage() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('agents');

  // Agent dialog state
  const [agentDialogOpen, setAgentDialogOpen] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [agentForm, setAgentForm] = useState({
    name: '',
    type: 'SALES' as string,
    description: '',
    systemPrompt: '',
    isActive: true,
    maxConversations: 50,
    responseDelayMs: 1000,
    handoffToHuman: true,
    handoffCondition: '',
  });

  // Conversation filters
  const [convFilter, setConvFilter] = useState({
    agentId: '',
    status: '',
  });

  // Chat test state
  const [chatAgentId, setChatAgentId] = useState('');
  const [chatConversationId, setChatConversationId] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ role: string; content: string }>>([]);
  const [chatLoading, setChatLoading] = useState(false);

  // ─── Data Fetching ────────────────────────────────────────────────────────

  const fetchAgents = useCallback(async () => {
    try {
      const res = await fetch('/api/ai-agents');
      if (res.ok) {
        const data = await res.json();
        setAgents(data.agents || []);
      }
    } catch (error) {
      console.error('Error fetching agents:', error);
    }
  }, []);

  const fetchConversations = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (convFilter.agentId) params.set('agentId', convFilter.agentId);
      if (convFilter.status) params.set('status', convFilter.status);

      const res = await fetch(`/api/ai-agents/conversations?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations || []);
      }
    } catch (error) {
      console.error('Error fetching conversations:', error);
    }
  }, [convFilter]);

  useEffect(() => {
    fetchAgents().then(() => setIsLoading(false));
  }, [fetchAgents]);

  useEffect(() => {
    if (activeTab === 'conversations' || activeTab === 'monitor') {
      fetchConversations();
    }
  }, [activeTab, fetchConversations]);

  // ─── Agent CRUD ───────────────────────────────────────────────────────────

  const handleCreateAgent = () => {
    setEditingAgent(null);
    setAgentForm({
      name: '',
      type: 'SALES',
      description: '',
      systemPrompt: '',
      isActive: true,
      maxConversations: 50,
      responseDelayMs: 1000,
      handoffToHuman: true,
      handoffCondition: '',
    });
    setAgentDialogOpen(true);
  };

  const handleEditAgent = (agent: Agent) => {
    setEditingAgent(agent);
    setAgentForm({
      name: agent.name,
      type: agent.type,
      description: agent.description || '',
      systemPrompt: agent.systemPrompt || '',
      isActive: agent.isActive,
      maxConversations: agent.maxConversations,
      responseDelayMs: agent.responseDelayMs,
      handoffToHuman: agent.handoffToHuman,
      handoffCondition: agent.handoffCondition || '',
    });
    setAgentDialogOpen(true);
  };

  const handleSaveAgent = async () => {
    try {
      if (editingAgent) {
        // Update
        await fetch(`/api/ai-agents/${editingAgent.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(agentForm),
        });
      } else {
        // Create
        await fetch('/api/ai-agents', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(agentForm),
        });
      }
      setAgentDialogOpen(false);
      fetchAgents();
    } catch (error) {
      console.error('Error saving agent:', error);
    }
  };

  const handleToggleAgent = async (agent: Agent) => {
    try {
      await fetch(`/api/ai-agents/${agent.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !agent.isActive }),
      });
      fetchAgents();
    } catch (error) {
      console.error('Error toggling agent:', error);
    }
  };

  const handleDeleteAgent = async (agentId: string) => {
    if (!confirm('آیا از حذف این عامل مطمئن هستید؟')) return;
    try {
      await fetch(`/api/ai-agents/${agentId}`, { method: 'DELETE' });
      fetchAgents();
    } catch (error) {
      console.error('Error deleting agent:', error);
    }
  };

  const handleSeedAgents = async () => {
    if (!confirm('عامل‌های پیش‌فرض ایجاد شوند؟')) return;
    try {
      await fetch('/api/ai-agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'seed' }),
      });
      fetchAgents();
    } catch (error) {
      console.error('Error seeding agents:', error);
    }
  };

  // ─── Conversation Detail ──────────────────────────────────────────────────

  const handleViewConversation = async (conv: Conversation) => {
    try {
      const res = await fetch(`/api/ai-agents/conversations/${conv.id}`);
      if (res.ok) {
        const data = await res.json();
        setSelectedConversation(data.conversation);
      }
    } catch (error) {
      console.error('Error fetching conversation:', error);
    }
  };

  const handleEndConversation = async (convId: string) => {
    try {
      await fetch(`/api/ai-agents/conversations/${convId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'end', outcome: 'INFORMED' }),
      });
      fetchConversations();
      if (selectedConversation?.id === convId) {
        setSelectedConversation(null);
      }
    } catch (error) {
      console.error('Error ending conversation:', error);
    }
  };

  const handleHandoffConversation = async (convId: string) => {
    try {
      await fetch(`/api/ai-agents/conversations/${convId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'handoff', reason: 'درخواست مدیر' }),
      });
      fetchConversations();
      if (selectedConversation?.id === convId) {
        setSelectedConversation(null);
      }
    } catch (error) {
      console.error('Error handing off conversation:', error);
    }
  };

  // ─── Chat Test ────────────────────────────────────────────────────────────

  const handleSendChat = async () => {
    if (!chatInput.trim()) return;
    if (!chatAgentId && !chatConversationId) return;

    setChatLoading(true);
    const userMsg = chatInput.trim();
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', content: userMsg }]);

    try {
      const res = await fetch('/api/ai-agents/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: chatConversationId ? undefined : chatAgentId,
          conversationId: chatConversationId || undefined,
          message: userMsg,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setChatConversationId(data.conversationId);
        setChatMessages(prev => [...prev, { role: 'assistant', content: data.reply }]);
      } else {
        const data = await res.json();
        setChatMessages(prev => [...prev, { role: 'system', content: `خطا: ${data.error}` }]);
      }
    } catch {
      setChatMessages(prev => [...prev, { role: 'system', content: 'خطا در اتصال. لطفاً دوباره تلاش کنید.' }]);
    } finally {
      setChatLoading(false);
    }
  };

  const resetChat = () => {
    setChatAgentId('');
    setChatConversationId('');
    setChatInput('');
    setChatMessages([]);
  };

  // ─── Stats Calculation ────────────────────────────────────────────────────

  const totalConversations = agents.reduce(
    (sum, a) => sum + (a.stats?.totalConversations || 0), 0
  );
  const totalEnrolled = agents.reduce(
    (sum, a) => sum + (a.stats?.enrolledConversations || 0), 0
  );
  const overallConversionRate = totalConversations > 0
    ? Math.round((totalEnrolled / totalConversations) * 1000) / 10
    : 0;
  const totalHandedOff = agents.reduce(
    (sum, a) => sum + (a.stats?.handedOffConversations || 0), 0
  );
  const activeConversationsCount = agents.reduce(
    (sum, a) => sum + (a.stats?.activeConversations || 0), 0
  );

  // ─── Render ───────────────────────────────────────────────────────────────

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-violet-600 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-violet-600 flex items-center justify-center">
            <Bot className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">عامل‌های هوش مصنوعی</h1>
            <p className="text-sm text-gray-500">مدیریت عامل‌های فروش، پشتیبانی و مشاوره</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={handleSeedAgents}
            variant="outline"
            className="gap-2 border-violet-200 text-violet-700 hover:bg-violet-50"
          >
            <Sparkles className="h-4 w-4" />
            ایجاد پیش‌فرض
          </Button>
          <Button
            onClick={handleCreateAgent}
            className="gap-2 bg-violet-600 hover:bg-violet-700"
          >
            <Plus className="h-4 w-4" />
            عامل جدید
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-violet-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">کل مکالمات</p>
                <p className="text-2xl font-bold text-gray-900">{totalConversations}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-violet-100 flex items-center justify-center">
                <MessageSquare className="h-5 w-5 text-violet-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">نرخ تبدیل</p>
                <p className="text-2xl font-bold text-green-700">{overallConversionRate}%</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-amber-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">مکالمات فعال</p>
                <p className="text-2xl font-bold text-amber-700">{activeConversationsCount}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                <Activity className="h-5 w-5 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-rose-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">ارجاع به انسان</p>
                <p className="text-2xl font-bold text-rose-700">{totalHandedOff}</p>
              </div>
              <div className="w-10 h-10 rounded-lg bg-rose-100 flex items-center justify-center">
                <ArrowRightLeft className="h-5 w-5 text-rose-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-violet-50">
          <TabsTrigger value="agents" className="data-[state=active]:bg-violet-600 data-[state=active]:text-white">
            <Bot className="h-4 w-4 ml-2" />
            عامل‌ها
          </TabsTrigger>
          <TabsTrigger value="conversations" className="data-[state=active]:bg-violet-600 data-[state=active]:text-white">
            <MessageSquare className="h-4 w-4 ml-2" />
            مکالمات
          </TabsTrigger>
          <TabsTrigger value="monitor" className="data-[state=active]:bg-violet-600 data-[state=active]:text-white">
            <Eye className="h-4 w-4 ml-2" />
            نظارت
          </TabsTrigger>
          <TabsTrigger value="test" className="data-[state=active]:bg-violet-600 data-[state=active]:text-white">
            <Zap className="h-4 w-4 ml-2" />
            آزمایش
          </TabsTrigger>
        </TabsList>

        {/* ─── Agents Tab ──────────────────────────────────────────────────── */}
        <TabsContent value="agents" className="mt-4">
          {agents.length === 0 ? (
            <Card className="border-dashed border-2 border-violet-200">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Bot className="h-12 w-12 text-violet-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-700 mb-2">هنوز عاملی ایجاد نشده</h3>
                <p className="text-sm text-gray-500 mb-4">
                  عامل‌های پیش‌فرض را ایجاد کنید یا عامل جدید بسازید
                </p>
                <div className="flex gap-2">
                  <Button onClick={handleSeedAgents} variant="outline" className="gap-2">
                    <Sparkles className="h-4 w-4" />
                    ایجاد پیش‌فرض
                  </Button>
                  <Button onClick={handleCreateAgent} className="gap-2 bg-violet-600 hover:bg-violet-700">
                    <Plus className="h-4 w-4" />
                    عامل جدید
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {agents.map(agent => (
                <Card
                  key={agent.id}
                  className={`border transition-all ${
                    agent.isActive
                      ? 'border-violet-200 hover:shadow-md'
                      : 'border-gray-200 opacity-60'
                  }`}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          agent.isActive ? 'bg-violet-100' : 'bg-gray-100'
                        }`}>
                          <Bot className={`h-5 w-5 ${agent.isActive ? 'text-violet-600' : 'text-gray-400'}`} />
                        </div>
                        <div>
                          <CardTitle className="text-base">{agent.name}</CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className={AGENT_TYPE_COLORS[agent.type] || 'bg-gray-100 text-gray-800'}>
                              {AGENT_TYPE_LABELS[agent.type] || agent.type}
                            </Badge>
                            {agent.isActive ? (
                              <Badge className="bg-green-100 text-green-800">فعال</Badge>
                            ) : (
                              <Badge className="bg-red-100 text-red-800">غیرفعال</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEditAgent(agent)}
                          title="ویرایش"
                        >
                          <Edit3 className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleToggleAgent(agent)}
                          title={agent.isActive ? 'غیرفعال کردن' : 'فعال کردن'}
                        >
                          <Power className={`h-4 w-4 ${agent.isActive ? 'text-green-600' : 'text-gray-400'}`} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteAgent(agent.id)}
                          title="حذف"
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-sm text-gray-500 mb-3 line-clamp-2">
                      {agent.description || 'بدون توضیحات'}
                    </p>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-violet-50 rounded-lg p-2">
                        <p className="text-lg font-bold text-violet-700">
                          {agent.stats?.totalConversations || 0}
                        </p>
                        <p className="text-xs text-gray-500">مکالمه</p>
                      </div>
                      <div className="bg-green-50 rounded-lg p-2">
                        <p className="text-lg font-bold text-green-700">
                          {agent.stats?.conversionRate || 0}%
                        </p>
                        <p className="text-xs text-gray-500">تبدیل</p>
                      </div>
                      <div className="bg-amber-50 rounded-lg p-2">
                        <p className="text-lg font-bold text-amber-700">
                          {agent.stats?.handedOffConversations || 0}
                        </p>
                        <p className="text-xs text-gray-500">ارجاع</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-3 text-xs text-gray-400">
                      <span>تأخیر: {agent.responseDelayMs}ms</span>
                      <span>حداکثر: {agent.maxConversations} مکالمه</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ─── Conversations Tab ───────────────────────────────────────────── */}
        <TabsContent value="conversations" className="mt-4">
          {/* Filters */}
          <div className="flex gap-3 mb-4 flex-wrap">
            <Select
              value={convFilter.agentId}
              onValueChange={(v) => setConvFilter(prev => ({ ...prev, agentId: v === 'ALL' ? '' : v }))}
            >
              <SelectTrigger className="w-48">
                <Filter className="h-4 w-4 ml-2" />
                <SelectValue placeholder="همه عامل‌ها" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه عامل‌ها</SelectItem>
                {agents.map(a => (
                  <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={convFilter.status}
              onValueChange={(v) => setConvFilter(prev => ({ ...prev, status: v === 'ALL' ? '' : v }))}
            >
              <SelectTrigger className="w-40">
                <SelectValue placeholder="همه وضعیت‌ها" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه وضعیت‌ها</SelectItem>
                <SelectItem value="ACTIVE">فعال</SelectItem>
                <SelectItem value="COMPLETED">تکمیل‌شده</SelectItem>
                <SelectItem value="HANDED_OFF">ارجاع‌شده</SelectItem>
                <SelectItem value="EXPIRED">منقضی</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" size="icon" onClick={fetchConversations}>
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>

          {conversations.length === 0 ? (
            <Card className="border-dashed border-2 border-gray-200">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <MessageSquare className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-700">مکالمه‌ای یافت نشد</h3>
              </CardContent>
            </Card>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-right px-4 py-3 font-medium text-gray-500">عامل</th>
                    <th className="text-right px-4 py-3 font-medium text-gray-500">کانال</th>
                    <th className="text-right px-4 py-3 font-medium text-gray-500">وضعیت</th>
                    <th className="text-right px-4 py-3 font-medium text-gray-500">احساس</th>
                    <th className="text-right px-4 py-3 font-medium text-gray-500">نتیجه</th>
                    <th className="text-right px-4 py-3 font-medium text-gray-500">پیام‌ها</th>
                    <th className="text-right px-4 py-3 font-medium text-gray-500">تاریخ</th>
                    <th className="text-right px-4 py-3 font-medium text-gray-500">عملیات</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {conversations.map(conv => (
                    <tr key={conv.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Bot className="h-4 w-4 text-violet-500" />
                          <span>{conv.agent?.name || '—'}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="outline">{conv.channel}</Badge>
                      </td>
                      <td className="px-4 py-3">
                        <Badge className={STATUS_COLORS[conv.status] || ''}>
                          {STATUS_LABELS[conv.status] || conv.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        {conv.sentiment ? (
                          <Badge className={SENTIMENT_COLORS[conv.sentiment] || ''}>
                            {SENTIMENT_LABELS[conv.sentiment] || conv.sentiment}
                          </Badge>
                        ) : '—'}
                      </td>
                      <td className="px-4 py-3">
                        {conv.outcome ? (
                          <span className="text-xs">{OUTCOME_LABELS[conv.outcome] || conv.outcome}</span>
                        ) : '—'}
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-gray-500">{conv._count?.messages || 0}</span>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500">
                        {formatDate(conv.startedAt)}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewConversation(conv)}
                            title="مشاهده"
                          >
                            <Eye className="h-3.5 w-3.5" />
                          </Button>
                          {conv.status === 'ACTIVE' && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEndConversation(conv.id)}
                                title="پایان"
                                className="text-amber-600"
                              >
                                <CheckCircle2 className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleHandoffConversation(conv.id)}
                                title="ارجاع"
                                className="text-blue-600"
                              >
                                <ArrowRightLeft className="h-3.5 w-3.5" />
                              </Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </TabsContent>

        {/* ─── Monitor Tab ─────────────────────────────────────────────────── */}
        <TabsContent value="monitor" className="mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Conversation List */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">مکالمات اخیر</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-96">
                    {conversations.filter(c => c.status === 'ACTIVE').length === 0 ? (
                      <div className="flex items-center justify-center py-8 text-gray-400 text-sm">
                        مکالمه فعالی وجود ندارد
                      </div>
                    ) : (
                      <div className="divide-y">
                        {conversations
                          .filter(c => c.status === 'ACTIVE')
                          .map(conv => (
                            <button
                              key={conv.id}
                              onClick={() => handleViewConversation(conv)}
                              className={`w-full text-right p-3 hover:bg-violet-50 transition-colors ${
                                selectedConversation?.id === conv.id ? 'bg-violet-50 border-r-2 border-violet-500' : ''
                              }`}
                            >
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm font-medium">{conv.agent?.name}</span>
                                <Badge className={STATUS_COLORS[conv.status]}>
                                  {STATUS_LABELS[conv.status]}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-2 text-xs text-gray-500">
                                <span>{conv.channel}</span>
                                <span>•</span>
                                <span>{conv._count?.messages || 0} پیام</span>
                                {conv.sentiment && (
                                  <>
                                    <span>•</span>
                                    <Badge className={SENTIMENT_COLORS[conv.sentiment]}>
                                      {SENTIMENT_LABELS[conv.sentiment]}
                                    </Badge>
                                  </>
                                )}
                              </div>
                            </button>
                          ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>

            {/* Conversation Detail */}
            <div className="lg:col-span-2">
              {selectedConversation ? (
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-base">
                          مکالمه با {selectedConversation.agent?.name}
                        </CardTitle>
                        <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                          <Badge className={STATUS_COLORS[selectedConversation.status]}>
                            {STATUS_LABELS[selectedConversation.status]}
                          </Badge>
                          <span>کانال: {selectedConversation.channel}</span>
                          <span>•</span>
                          <span>{formatDate(selectedConversation.startedAt)}</span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        {selectedConversation.status === 'ACTIVE' && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEndConversation(selectedConversation.id)}
                              className="gap-1"
                            >
                              <CheckCircle2 className="h-3.5 w-3.5" />
                              پایان
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleHandoffConversation(selectedConversation.id)}
                              className="gap-1"
                            >
                              <ArrowRightLeft className="h-3.5 w-3.5" />
                              ارجاع
                            </Button>
                          </>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setSelectedConversation(null)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-80">
                      <div className="space-y-3">
                        {selectedConversation.messages?.map(msg => (
                          <div
                            key={msg.id}
                            className={`flex ${
                              msg.role === 'USER' ? 'justify-start' : 'justify-end'
                            }`}
                          >
                            <div
                              className={`max-w-[80%] rounded-lg p-3 ${
                                msg.role === 'USER'
                                  ? 'bg-gray-100 text-gray-800'
                                  : msg.role === 'ASSISTANT'
                                  ? 'bg-violet-100 text-violet-900'
                                  : 'bg-amber-50 text-amber-800'
                              }`}
                            >
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs font-medium">
                                  {msg.role === 'USER' ? '👤 کاربر' :
                                   msg.role === 'ASSISTANT' ? '🤖 دستیار' : '⚙️ سیستم'}
                                </span>
                                {msg.metadata?.sentiment && (
                                  <Badge className={`text-xs ${SENTIMENT_COLORS[msg.metadata.sentiment as string] || ''}`}>
                                    {SENTIMENT_LABELS[msg.metadata.sentiment as string] || ''}
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                              <p className="text-xs text-gray-400 mt-1">
                                {formatDate(msg.createdAt)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              ) : (
                <Card className="border-dashed border-2">
                  <CardContent className="flex flex-col items-center justify-center py-16">
                    <Eye className="h-12 w-12 text-gray-300 mb-4" />
                    <h3 className="text-lg font-medium text-gray-700 mb-2">
                      مکالمه‌ای انتخاب نشده
                    </h3>
                    <p className="text-sm text-gray-500">
                      از لیست سمت راست یک مکالمه فعال را انتخاب کنید
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        {/* ─── Test Tab ─────────────────────────────────────────────────────── */}
        <TabsContent value="test" className="mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Chat Window */}
            <div className="lg:col-span-2">
              <Card className="h-[500px] flex flex-col">
                <CardHeader className="pb-3 border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-violet-100 flex items-center justify-center">
                        <Bot className="h-4 w-4 text-violet-600" />
                      </div>
                      <div>
                        <CardTitle className="text-sm">آزمایش چت</CardTitle>
                        <p className="text-xs text-gray-500">
                          {chatConversationId
                            ? `مکالمه: ${chatConversationId.substring(0, 12)}...`
                            : 'مکالمه جدید'}
                        </p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={resetChat} className="gap-1">
                      <RefreshCw className="h-3.5 w-3.5" />
                      شروع مجدد
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden p-0">
                  <ScrollArea className="h-full p-4">
                    {chatMessages.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-64 text-gray-400">
                        <MessageSquare className="h-12 w-12 mb-3" />
                        <p className="text-sm">یک عامل انتخاب کنید و شروع به چت کنید</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {chatMessages.map((msg, idx) => (
                          <div
                            key={idx}
                            className={`flex ${
                              msg.role === 'user' ? 'justify-start' : 'justify-end'
                            }`}
                          >
                            <div
                              className={`max-w-[80%] rounded-lg p-3 ${
                                msg.role === 'user'
                                  ? 'bg-gray-100 text-gray-800'
                                  : msg.role === 'assistant'
                                  ? 'bg-violet-100 text-violet-900'
                                  : 'bg-red-50 text-red-700'
                              }`}
                            >
                              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            </div>
                          </div>
                        ))}
                        {chatLoading && (
                          <div className="flex justify-end">
                            <div className="bg-violet-100 rounded-lg p-3">
                              <div className="flex gap-1">
                                <div className="h-2 w-2 bg-violet-400 rounded-full animate-bounce" />
                                <div className="h-2 w-2 bg-violet-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                                <div className="h-2 w-2 bg-violet-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
                <div className="border-t p-3">
                  <div className="flex gap-2">
                    <Input
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendChat();
                        }
                      }}
                      placeholder="پیام خود را بنویسید..."
                      disabled={chatLoading || (!chatAgentId && !chatConversationId)}
                      className="flex-1"
                    />
                    <Button
                      onClick={handleSendChat}
                      disabled={chatLoading || !chatInput.trim() || (!chatAgentId && !chatConversationId)}
                      className="bg-violet-600 hover:bg-violet-700"
                      size="icon"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            </div>

            {/* Agent Selection */}
            <div>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">انتخاب عامل</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {agents.filter(a => a.isActive).length === 0 ? (
                    <div className="text-center text-gray-400 text-sm py-4">
                      عامل فعالی وجود ندارد
                    </div>
                  ) : (
                    agents.filter(a => a.isActive).map(agent => (
                      <button
                        key={agent.id}
                        onClick={() => {
                          setChatAgentId(agent.id);
                          if (!chatConversationId) {
                            setChatMessages([]);
                          }
                        }}
                        className={`w-full text-right p-3 rounded-lg border transition-colors ${
                          chatAgentId === agent.id
                            ? 'border-violet-500 bg-violet-50'
                            : 'border-gray-200 hover:border-violet-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-violet-100 flex items-center justify-center">
                            <Bot className="h-4 w-4 text-violet-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">{agent.name}</p>
                            <Badge className={AGENT_TYPE_COLORS[agent.type]}>
                              {AGENT_TYPE_LABELS[agent.type]}
                            </Badge>
                          </div>
                        </div>
                      </button>
                    ))
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* ─── Agent Create/Edit Dialog ──────────────────────────────────────── */}
      <Dialog open={agentDialogOpen} onOpenChange={setAgentDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-violet-600" />
              {editingAgent ? 'ویرایش عامل' : 'ایجاد عامل جدید'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="agent-name">نام عامل</Label>
                <Input
                  id="agent-name"
                  value={agentForm.name}
                  onChange={(e) => setAgentForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="مثلاً: عامل فروش"
                />
              </div>
              <div>
                <Label htmlFor="agent-type">نوع عامل</Label>
                <Select
                  value={agentForm.type}
                  onValueChange={(v) => setAgentForm(prev => ({ ...prev, type: v }))}
                >
                  <SelectTrigger id="agent-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SALES">فروش</SelectItem>
                    <SelectItem value="SUPPORT">پشتیبانی</SelectItem>
                    <SelectItem value="CONSULTANT">مشاور</SelectItem>
                    <SelectItem value="FOLLOW_UP">پیگیری</SelectItem>
                    <SelectItem value="RETENTION">حفظ مشتری</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="agent-desc">توضیحات</Label>
              <Input
                id="agent-desc"
                value={agentForm.description}
                onChange={(e) => setAgentForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="توضیح کوتاه درباره وظیفه این عامل"
              />
            </div>

            <div>
              <Label htmlFor="agent-prompt">System Prompt (دستورالعمل عامل)</Label>
              <Textarea
                id="agent-prompt"
                value={agentForm.systemPrompt}
                onChange={(e) => setAgentForm(prev => ({ ...prev, systemPrompt: e.target.value }))}
                placeholder="دستورالعمل‌ها و قوانین عامل AI را اینجا بنویسید... (خالی = استفاده از پیش‌فرض)"
                rows={8}
                className="font-mono text-sm"
              />
            </div>

            <Separator />

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="agent-max">حداکثر مکالمات همزمان</Label>
                <Input
                  id="agent-max"
                  type="number"
                  value={agentForm.maxConversations}
                  onChange={(e) => setAgentForm(prev => ({ ...prev, maxConversations: parseInt(e.target.value) || 50 }))}
                />
              </div>
              <div>
                <Label htmlFor="agent-delay">تأخیر پاسخ (میلی‌ثانیه)</Label>
                <Input
                  id="agent-delay"
                  type="number"
                  value={agentForm.responseDelayMs}
                  onChange={(e) => setAgentForm(prev => ({ ...prev, responseDelayMs: parseInt(e.target.value) || 1000 }))}
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Switch
                  checked={agentForm.isActive}
                  onCheckedChange={(v) => setAgentForm(prev => ({ ...prev, isActive: v }))}
                />
                <Label>فعال</Label>
              </div>
              <div className="flex items-center gap-3">
                <Switch
                  checked={agentForm.handoffToHuman}
                  onCheckedChange={(v) => setAgentForm(prev => ({ ...prev, handoffToHuman: v }))}
                />
                <Label>ارجاع به انسان</Label>
              </div>
            </div>

            {agentForm.handoffToHuman && (
              <div>
                <Label htmlFor="agent-handoff">شرط ارجاع</Label>
                <Input
                  id="agent-handoff"
                  value={agentForm.handoffCondition}
                  onChange={(e) => setAgentForm(prev => ({ ...prev, handoffCondition: e.target.value }))}
                  placeholder="مثلاً: sentiment=negative,intent=complaint"
                />
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setAgentDialogOpen(false)}
            >
              انصراف
            </Button>
            <Button
              onClick={handleSaveAgent}
              disabled={!agentForm.name}
              className="bg-violet-600 hover:bg-violet-700"
            >
              {editingAgent ? 'ذخیره تغییرات' : 'ایجاد عامل'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
