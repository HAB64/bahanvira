'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Radar,
  Plus,
  Loader2,
  AlertTriangle,
  Power,
  PowerOff,
  Pencil,
  Trash2,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface AutoLeadRule {
  id: string;
  name: string;
  description: string | null;
  source: string;
  conditions: Record<string, unknown>;
  actions: Record<string, unknown>;
  isActive: boolean;
  priority: number;
  matchCount: number;
  lastMatchAt: string | null;
  createdAt: string;
}

/* ─────────── Constants ─────────── */

const SOURCE_LABELS: Record<string, string> = {
  WEB_FORM: 'فرم وب',
  WHATSAPP: 'واتساپ',
  PHONE: 'تلفن',
  EMAIL: 'ایمیل',
  SOCIAL: 'شبکه اجتماعی',
};

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string | null) {
  if (!dateStr) return '-';
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric', month: 'short', day: 'numeric',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function AutoLeadRulesPage() {
  const [rules, setRules] = useState<AutoLeadRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [dialogOpen, setDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingRuleId, setEditingRuleId] = useState('');

  // Form fields
  const [formName, setFormName] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formSource, setFormSource] = useState('WEB_FORM');
  const [formConditions, setFormConditions] = useState('');
  const [formActions, setFormActions] = useState('');
  const [formPriority, setFormPriority] = useState(0);
  const [formIsActive, setFormIsActive] = useState(true);

  // Delete confirmation
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteRuleId, setDeleteRuleId] = useState('');
  const [deleteRuleName, setDeleteRuleName] = useState('');
  const [deleteSubmitting, setDeleteSubmitting] = useState(false);

  /* ── Data fetching ── */

  const fetchRules = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/crm/auto-lead-rules');
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت قوانین');
        return;
      }

      setRules(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRules();
  }, [fetchRules]);

  /* ── Handlers ── */

  const resetForm = () => {
    setFormName('');
    setFormDescription('');
    setFormSource('WEB_FORM');
    setFormConditions('{"stage": "NEW"}');
    setFormActions('[{"type": "ADD_TAG", "tag": "new-lead"}]');
    setFormPriority(0);
    setFormIsActive(true);
  };

  const openAddDialog = () => {
    resetForm();
    setIsEditing(false);
    setEditingRuleId('');
    setDialogOpen(true);
  };

  const openEditDialog = (rule: AutoLeadRule) => {
    setFormName(rule.name);
    setFormDescription(rule.description || '');
    setFormSource(rule.source);
    setFormConditions(JSON.stringify(rule.conditions, null, 2));
    setFormActions(JSON.stringify(rule.actions, null, 2));
    setFormPriority(rule.priority);
    setFormIsActive(rule.isActive);
    setIsEditing(true);
    setEditingRuleId(rule.id);
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formName.trim()) return;

    let conditions, actions;
    try {
      conditions = JSON.parse(formConditions);
    } catch {
      setError('فرمت JSON شروط نامعتبر است');
      return;
    }
    try {
      actions = JSON.parse(formActions);
    } catch {
      setError('فرمت JSON اقدامات نامعتبر است');
      return;
    }

    setSubmitting(true);
    try {
      if (isEditing && editingRuleId) {
        // Update existing rule
        const res = await fetch('/api/crm/auto-lead-rules', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ruleId: editingRuleId,
            name: formName,
            description: formDescription || null,
            source: formSource,
            conditions,
            actions,
            priority: formPriority,
            isActive: formIsActive,
          }),
        });
        if (res.ok) {
          setDialogOpen(false);
          fetchRules();
        }
      } else {
        // Create new rule
        const res = await fetch('/api/crm/auto-lead-rules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formName,
            description: formDescription || null,
            source: formSource,
            conditions,
            actions,
            priority: formPriority,
            isActive: formIsActive,
          }),
        });

        if (res.ok) {
          setDialogOpen(false);
          fetchRules();
        }
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const toggleActive = async (ruleId: string, currentActive: boolean) => {
    try {
      const res = await fetch('/api/crm/auto-lead-rules', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ruleId, isActive: !currentActive }),
      });
      if (res.ok) fetchRules();
    } catch { /* silent */ }
  };

  const openDeleteDialog = (rule: AutoLeadRule) => {
    setDeleteRuleId(rule.id);
    setDeleteRuleName(rule.name);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!deleteRuleId) return;
    setDeleteSubmitting(true);
    try {
      const res = await fetch('/api/crm/auto-lead-rules', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ruleId: deleteRuleId }),
      });
      if (res.ok) {
        setDeleteDialogOpen(false);
        fetchRules();
      }
    } catch { /* silent */ } finally { setDeleteSubmitting(false); }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Radar className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">قوانین تشخیص خودکار لید</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(rules.length)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">تنظیم قوانین خودکار برای لیدهای ورودی</p>
          </div>
        </div>
        <Button onClick={openAddDialog} className="bg-teal-600 hover:bg-teal-700 text-white gap-2">
          <Plus className="w-4 h-4" />
          قانون جدید
        </Button>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchRules}>تلاش مجدد</Button>
          </CardContent>
        </Card>
      ) : rules.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Radar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">قانونی یافت نشد</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">نام</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">منبع</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">شروط</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">وضعیت</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">تعداد تطبیق</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">آخرین تطبیق</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rules.map((rule) => (
                  <TableRow key={rule.id} className="hover:bg-gray-50/50">
                    <TableCell>
                      <div className="font-medium text-sm">{rule.name}</div>
                      {rule.description && (
                        <div className="text-xs text-gray-500 truncate max-w-48">{rule.description}</div>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-gray-100 text-gray-700 text-xs border-0">
                        {SOURCE_LABELS[rule.source] || rule.source}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-gray-500 max-w-32 truncate font-mono">
                      {JSON.stringify(rule.conditions).slice(0, 40)}...
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="secondary"
                        className={`${rule.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'} text-xs border-0`}
                      >
                        {rule.isActive ? 'فعال' : 'غیرفعال'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {toPersianNumber(rule.matchCount)}
                    </TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {formatPersianDate(rule.lastMatchAt)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`h-8 w-8 ${rule.isActive ? 'text-red-500 hover:bg-red-50' : 'text-green-500 hover:bg-green-50'}`}
                          onClick={() => toggleActive(rule.id, rule.isActive)}
                          title={rule.isActive ? 'غیرفعال کردن' : 'فعال کردن'}
                        >
                          {rule.isActive ? <PowerOff className="w-4 h-4" /> : <Power className="w-4 h-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-blue-500 hover:bg-blue-50"
                          onClick={() => openEditDialog(rule)}
                          title="ویرایش"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-red-500 hover:bg-red-50"
                          onClick={() => openDeleteDialog(rule)}
                          title="حذف"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Radar className="w-5 h-5 text-teal-600" />
              {isEditing ? 'ویرایش قانون تشخیص خودکار' : 'قانون تشخیص خودکار جدید'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نام قانون</Label>
              <Input
                placeholder="نام قانون..."
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">توضیحات</Label>
              <Input
                placeholder="توضیحات..."
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">منبع لید</Label>
                <Select value={formSource} onValueChange={setFormSource}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="WEB_FORM">فرم وب</SelectItem>
                    <SelectItem value="WHATSAPP">واتساپ</SelectItem>
                    <SelectItem value="PHONE">تلفن</SelectItem>
                    <SelectItem value="EMAIL">ایمیل</SelectItem>
                    <SelectItem value="SOCIAL">شبکه اجتماعی</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">اولویت</Label>
                <Input
                  type="number"
                  min={0}
                  value={formPriority}
                  onChange={(e) => setFormPriority(parseInt(e.target.value) || 0)}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">شروط تطبیق (JSON)</Label>
              <Textarea
                placeholder='{"stage": "NEW", "cluster": "tech-ai"}'
                value={formConditions}
                onChange={(e) => setFormConditions(e.target.value)}
                rows={3}
                className="font-mono text-xs"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">اقدامات خودکار (JSON)</Label>
              <Textarea
                placeholder='[{"type": "ADD_TAG", "tag": "new-lead"}]'
                value={formActions}
                onChange={(e) => setFormActions(e.target.value)}
                rows={3}
                className="font-mono text-xs"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="isActive"
                checked={formIsActive}
                onChange={(e) => setFormIsActive(e.target.checked)}
                className="rounded border-gray-300"
              />
              <Label htmlFor="isActive" className="text-sm">فعال</Label>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>انصراف</Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !formName.trim()}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : isEditing ? <Pencil className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
              {isEditing ? 'به‌روزرسانی' : 'ثبت قانون'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-right">حذف قانون</AlertDialogTitle>
            <AlertDialogDescription className="text-right">
              آیا از حذف قانون <strong>&laquo;{deleteRuleName}&raquo;</strong> اطمینان دارید؟ این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleteSubmitting}
              className="bg-red-600 hover:bg-red-700 text-white gap-2"
            >
              {deleteSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
