'use client';

import { useState } from 'react';
import {
  Layers,
  Users,
  GraduationCap,
  Wallet,
  MonitorSmartphone,
  Presentation,
  BrainCircuit,
  BarChart3,
  Bot,
  Plug,
  ChevronDown,
  ChevronLeft,
  Sparkles,
  CheckCircle2,
  Shield,
  BookOpen,
  PhoneCall,
  DollarSign,
  UserCog,
  ClipboardList,
  Target,
  TrendingUp,
  Cpu,
  Cog,
  MessageSquare,
  LineChart,
  Globe,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { siteConfig } from '@/config/site';

/* ───────── Layer Data ───────── */
const architectureLayers = [
  {
    id: 'core-erp',
    number: 1,
    title: 'هسته مرکزی',
    subtitle: 'Core ERP',
    icon: Shield,
    color: '#6366f1',
    bgColor: 'bg-indigo-50',
    textColor: 'text-indigo-700',
    borderColor: 'border-indigo-200',
    items: ['مدیریت کاربران', 'نقش‌ها و سطوح دسترسی (RBAC)', 'مدیریت شعب', 'مدیریت اساتید', 'مدیریت کارکنان', 'مدیریت کارآموزان', 'مدیریت مدارک', 'مدیریت فرم‌ها', 'مدیریت فرآیندها (BPM)', 'مرکز اعلان‌ها'],
    description: 'ستون فقرات پلتفرم — مدیریت هویت، دسترسی‌ها و فرآیندهای سازمانی. همه ماژول‌ها از طریق این لایه احراز هویت و مجوز دریافت می‌کنند.',
    status: 'تکمیل‌شده' as const,
    progress: 100,
  },
  {
    id: 'lms',
    number: 2,
    title: 'آموزش',
    subtitle: 'LMS',
    icon: BookOpen,
    color: '#0d9488',
    bgColor: 'bg-teal-50',
    textColor: 'text-teal-700',
    borderColor: 'border-teal-200',
    items: ['تعریف دوره', 'سرفصل‌ها', 'کلاس حضوری / آنلاین', 'محتوای آموزشی', 'تکالیف و پروژه‌ها', 'حضور و غیاب', 'تقویم آموزشی', 'بانک سوالات', 'آزمون آنلاین / عملی / تطبیقی', 'صدور گواهینامه', 'آرشیو سوابق'],
    description: 'موتور آموزش پلتفرم — از طراحی دوره و محتوا تا ارزیابی هوشمند و صدور گواهینامه. پشتیبانی از سه مدل آزمون: استاندارد، عملی و Adaptive.',
    status: 'تکمیل‌شده' as const,
    progress: 100,
  },
  {
    id: 'crm',
    number: 3,
    title: 'CRM آموزشی',
    subtitle: 'Educational CRM',
    icon: PhoneCall,
    color: '#f59e0b',
    bgColor: 'bg-amber-50',
    textColor: 'text-amber-700',
    borderColor: 'border-amber-200',
    items: ['لید (Lead)', 'قیف فروش', 'مشاوره آموزشی', 'پیگیری تماس', 'کمپین تبلیغاتی', 'پیامک / واتساپ / ایمیل', 'باشگاه مشتریان', 'سیستم ارجاع', 'نظرسنجی رضایت'],
    description: 'مزیت رقابتی اصلی — مدیریت هوشمند ارتباط با مشتری از لحظه لید تا تبدیل به فارغ‌التحصیل وفادار. قیف فروش آموزشی و اتوماسیون پیگیری.',
    status: 'تکمیل‌شده' as const,
    progress: 100,
  },
  {
    id: 'finance',
    number: 4,
    title: 'مالی',
    subtitle: 'Finance',
    icon: DollarSign,
    color: '#10b981',
    bgColor: 'bg-emerald-50',
    textColor: 'text-emerald-700',
    borderColor: 'border-emerald-200',
    items: ['ثبت درآمد / هزینه', 'شهریه و اقساط', 'صندوق و بانک', 'فاکتور', 'حقوق و دستمزد', 'گزارش سود و زیان', 'بودجه‌بندی'],
    description: 'مدیریت مالی یکپارچه — از شهریه و اقساط کارآموزان تا حقوق کارکنان و گزارش‌های سود و زیان. اتصال مستقیم به CRM و LMS.',
    status: 'تکمیل‌شده' as const,
    progress: 100,
  },
  {
    id: 'student-portal',
    number: 5,
    title: 'پورتال کارآموز',
    subtitle: 'Student Portal',
    icon: MonitorSmartphone,
    color: '#3b82f6',
    bgColor: 'bg-blue-50',
    textColor: 'text-blue-700',
    borderColor: 'border-blue-200',
    items: ['پروفایل', 'انتخاب دوره', 'پرداخت آنلاین', 'مشاهده کلاس‌ها', 'آزمون‌ها و کارنامه', 'گواهینامه‌ها', 'تیکت پشتیبانی'],
    description: 'دسترسی خودکار کارآموز به همه خدمات — از ثبت‌نام و پرداخت تا شرکت در آزمون و دریافت گواهینامه. رابط کاربری ساده و واکنش‌گرا.',
    status: 'تکمیل‌شده' as const,
    progress: 100,
  },
  {
    id: 'instructor-portal',
    number: 6,
    title: 'پورتال استاد',
    subtitle: 'Instructor Portal',
    icon: UserCog,
    color: '#8b5cf6',
    bgColor: 'bg-violet-50',
    textColor: 'text-violet-700',
    borderColor: 'border-violet-200',
    items: ['مدیریت کلاس', 'ثبت حضور', 'بارگذاری محتوا', 'طراحی آزمون', 'تصحیح آزمون', 'گزارش عملکرد'],
    description: 'پنل اختصاصی اساتید — مدیریت کلاس‌ها، بارگذاری محتوا، طراحی و تصحیح آزمون‌ها و مشاهده گزارش عملکرد کارآموزان.',
    status: 'تکمیل‌شده' as const,
    progress: 100,
  },
  {
    id: 'smart-exam',
    number: 7,
    title: 'آزمون هوشمند',
    subtitle: 'Smart Assessment',
    icon: BrainCircuit,
    color: '#ec4899',
    bgColor: 'bg-pink-50',
    textColor: 'text-pink-700',
    borderColor: 'border-pink-200',
    items: ['تولید سوال با AI', 'تحلیل کیفیت سوال', 'تشخیص تقلب', 'بانک ICDL / Python / Scratch', 'آزمون شبیه‌ساز فنی‌وحرفه‌ای'],
    description: 'آزمون‌ساز هوشمند مبتنی بر AI — تولید خودکار سوال، تحلیل دشواری، تشخیص تقلب و بانک سوالات تخصصی ICDL، پایتون و اسکرچ.',
    status: 'تکمیل‌شده' as const,
    progress: 100,
  },
  {
    id: 'bi',
    number: 8,
    title: 'BI و هوش تجاری',
    subtitle: 'Business Intelligence',
    icon: BarChart3,
    color: '#06b6d4',
    bgColor: 'bg-cyan-50',
    textColor: 'text-cyan-700',
    borderColor: 'border-cyan-200',
    items: ['KPI داشبورد مدیرعامل', 'نرخ تبدیل ثبت‌نام', 'CAC / LTV', 'نرخ ریزش', 'عملکرد اساتید', 'درآمد دوره‌ها', 'پیش‌بینی ثبت‌نام'],
    description: 'هوش تجاری تصمیم‌ساز — داشبورد مدیریتی با KPIهای کلیدی، تحلیل نرخ تبدیل، ارزش طول عمر مشتری و پیش‌بینی هوشمند ثبت‌نام.',
    status: 'تکمیل‌شده' as const,
    progress: 95,
  },
  {
    id: 'ai-agents',
    number: 9,
    title: 'AI Agent Layer',
    subtitle: 'Intelligent Automation',
    icon: Bot,
    color: '#f43f5e',
    bgColor: 'bg-rose-50',
    textColor: 'text-rose-700',
    borderColor: 'border-rose-200',
    items: ['Agent مشاور آموزشی', 'Agent فروش', 'Agent پشتیبانی', 'Agent تولید محتوا', 'Agent آزمون‌ساز', 'Agent تحلیل کسب‌وکار', 'Agent پیش‌بینی درآمد', 'Agent گزارش‌ساز مدیریتی'],
    description: 'لایه هوش مصنوعی — عامل‌های خودکاری که مشاوره می‌دهند، می‌فروشند، پشتیبانی می‌کنند، محتوا تولید می‌کنند و گزارش مدیریتی می‌سازند.',
    status: 'تکمیل‌شده' as const,
    progress: 100,
  },
  {
    id: 'integrations',
    number: 10,
    title: 'اتصال به بیرون',
    subtitle: 'Integrations',
    icon: Plug,
    color: '#78716c',
    bgColor: 'bg-stone-50',
    textColor: 'text-stone-700',
    borderColor: 'border-stone-200',
    items: ['سامانه فنی‌وحرفه‌ای', 'درگاه پرداخت', 'پیامک', 'واتساپ', 'ایمیل', 'Moodle', 'n8n', 'Telegram', 'Google Calendar'],
    description: 'اتصال API-First به اکوسیستم خارجی — از درگاه پرداخت و پیامک تا سامانه فنی‌وحرفه‌ای و Moodle. طراحی Microservices برای مقیاس‌پذیری.',
    status: 'در حال اجرا' as const,
    progress: 90,
  },
];

/* ───────── Phase Data ───────── */
const implementationPhases = [
  {
    phase: 1,
    title: 'فاز ۱ — ضروری',
    subtitle: 'MVP + Core Revenue',
    color: '#0d9488',
    status: 'تکمیل‌شده',
    modules: ['CRM آموزشی', 'LMS', 'مالی', 'آزمون آنلاین'],
    description: 'حداقل محصول پذیرفتنی — CRM برای جذب مشتری، LMS برای ارائه آموزش، مالی برای مدیریت درآمد و آزمون آنلاین برای ارزیابی. این فاز پایه درآمدزایی پلتفرم را فراهم می‌کند.',
  },
  {
    phase: 2,
    title: 'فاز ۲ — تحلیلی',
    subtitle: 'Analytics + Automation',
    color: '#3b82f6',
    status: 'تکمیل‌شده',
    modules: ['BI و هوش تجاری', 'اتوماسیون فرآیندها', 'پورتال استاد', 'پورتال کارآموز'],
    description: 'هوش تجاری و اتوماسیون — داشبوردهای تحلیلی مدیریتی، پورتال‌های اختصاصی اساتید و کارآموزان و خودکارسازی فرآیندهای تکراری.',
  },
  {
    phase: 3,
    title: 'فاز ۳ — هوشمند',
    subtitle: 'AI + Prediction',
    color: '#8b5cf6',
    status: 'تکمیل‌شده',
    modules: ['AI Agent Layer', 'تحلیل پیش‌بینی', 'اتصال کامل فنی‌وحرفه‌ای', 'آزمون تطبیقی'],
    description: 'لایه هوش مصنوعی و پیش‌بینی — عامل‌های AI برای مشاوره، فروش و پشتیبانی خودکار. پیش‌بینی درآمد و نرخ ثبت‌نام. اتصال کامل به سامانه فنی‌وحرفه‌ای.',
  },
  {
    phase: 4,
    title: 'فاز ۴ — مقیاس',
    subtitle: 'Multi-Tenant + Franchise',
    color: '#f59e0b',
    status: 'در حال اجرا',
    modules: ['فرانچایز', 'چندشعبه‌ای (Multi-Tenant)', 'API Marketplace', 'White-Label'],
    description: 'مقیاس‌پذیری ملی — معماری Multi-Tenant برای فرانچایز و چندشعبه‌ای. API Marketplace برای توسعه‌دهندگان و نسخه White-Label برای شرکا.',
  },
];

/* ───────── Strategic Insight ───────── */
const strategicInsights = [
  {
    icon: Target,
    title: 'مزیت رقابتی پایدار',
    description: 'ارزش واقعی در «CRM آموزشی + BI + AI Agent» است، نه صرفاً LMS. بسیاری آموزشگاه‌ها LMS دارند؛ مزیت پایدار از داده، اتوماسیون و هوش مصنوعی ایجاد می‌شود.',
    color: '#0d9488',
    bgColor: 'bg-teal-50',
    borderColor: 'border-teal-200',
  },
  {
    icon: Cog,
    title: 'API-First و Microservices',
    description: 'معماری از ابتدا API-First و مبتنی بر Microservices طراحی شده تا در آینده به یک ERP آموزشی ملی تبدیل گردد. هر لایه مستقل مقیاس‌پذیر است.',
    color: '#6366f1',
    bgColor: 'bg-indigo-50',
    borderColor: 'border-indigo-200',
  },
  {
    icon: TrendingUp,
    title: 'داده محور',
    description: '۲۷ سال سابقه آموزشگاه بهان رایانه، بزرگترین دارایی داده‌ای است. تحلیل این داده با BI و AI، مزیت رقابتی غیرقابل کپی ایجاد می‌کند.',
    color: '#f59e0b',
    bgColor: 'bg-amber-50',
    borderColor: 'border-amber-200',
  },
];

function getStatusBadge(status: string) {
  switch (status) {
    case 'تکمیل‌شده':
      return <Badge className="bg-teal-100 text-teal-700 hover:bg-teal-100 border-teal-200 text-[10px]">{status}</Badge>;
    case 'در حال اجرا':
      return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200 text-[10px]">{status}</Badge>;
    case 'برنامه‌ریزی':
      return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-blue-200 text-[10px]">{status}</Badge>;
    case 'آینده':
      return <Badge className="bg-gray-100 text-gray-600 hover:bg-gray-100 border-gray-200 text-[10px]">{status}</Badge>;
    default:
      return <Badge variant="secondary" className="text-[10px]">{status}</Badge>;
  }
}

export default function ArchitecturePage() {
  const [activeLayer, setActiveLayer] = useState<number | null>(null);

  // Calculate overall progress
  const totalProgress = architectureLayers.reduce((sum, l) => sum + l.progress, 0);
  const overallProgress = Math.round(totalProgress / architectureLayers.length);

  return (
    <div className="space-y-6">
      {/* ── Header ── */}
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-indigo-100">
            <Layers className="h-6 w-6 text-indigo-700" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">معماری Enterprise</h1>
            <p className="text-gray-500 text-sm">پلتفرم یکپارچه {siteConfig.name.fullName} — ۱۰ لایه + ۴ فاز اجرایی</p>
          </div>
        </div>
      </div>

      {/* ── Overall Progress ── */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-bold text-gray-900">پیشرفت کلی پلتفرم</p>
              <p className="text-xs text-gray-500">میانگین پیشرفت ۱۰ لایه معماری</p>
            </div>
            <span className="text-2xl font-black text-indigo-600">{overallProgress}٪</span>
          </div>
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-indigo-500 to-teal-500 rounded-full"
              style={{ width: `${overallProgress}%` }}
            />
          </div>
          <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-emerald-500" />
              {architectureLayers.filter(l => l.status === 'در حال اجرا').length} لایه فعال
            </span>
            <span className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-blue-500" />
              {architectureLayers.filter(l => l.status === 'برنامه‌ریزی').length} لایه برنامه‌ریزی
            </span>
            <span className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-gray-400" />
              {architectureLayers.filter(l => l.status === 'آینده').length} لایه آینده
            </span>
          </div>
        </CardContent>
      </Card>

      {/* ── 10 Layers Grid ── */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Cpu className="h-5 w-5 text-indigo-600" />
            ۱۰ لایه معماری
          </CardTitle>
          <CardDescription>هر لایه را انتخاب کنید تا جزئیات ماژول‌ها و وضعیت اجرا را ببینید</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mb-6">
            {architectureLayers.map((layer, idx) => {
              const Icon = layer.icon;
              const isActive = activeLayer === idx;
              return (
                <button
                  key={layer.id}
                  onClick={() => setActiveLayer(isActive ? null : idx)}
                  className={`p-3 rounded-xl border-2 text-center ${
                    isActive
                      ? `${layer.bgColor} ${layer.borderColor}`
                      : 'border-gray-100 bg-white hover:bg-gray-50 hover:border-gray-200'
                  }`}
                >
                  <div
                    className={`w-10 h-10 rounded-lg flex items-center justify-center mx-auto mb-2 ${isActive ? '' : layer.bgColor}`}
                  >
                    <Icon className="w-5 h-5" style={{ color: layer.color }} />
                  </div>
                  <p className={`text-xs font-bold ${isActive ? 'text-gray-900' : 'text-gray-700'}`}>
                    {layer.title}
                  </p>
                  <p className="text-[10px] text-gray-400 font-mono">{layer.subtitle}</p>
                  <div className="mt-2 h-1 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${layer.progress}%`, backgroundColor: layer.color }}
                    />
                  </div>
                  <p className="text-[10px] text-gray-400 mt-1">{layer.progress}٪</p>
                </button>
              );
            })}
          </div>

          {/* Active Layer Detail */}
          {activeLayer !== null && (() => {
            const layer = architectureLayers[activeLayer];
            const Icon = layer.icon;
            return (
              <div className={`rounded-xl border-2 p-5 ${layer.bgColor} ${layer.borderColor}`}>
                <div className="flex items-start gap-4 mb-4">
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: layer.color + '15' }}
                  >
                    <Icon className="w-7 h-7" style={{ color: layer.color }} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge
                        className="text-white text-[10px] border-0"
                        style={{ backgroundColor: layer.color }}
                      >
                        لایه {layer.number}
                      </Badge>
                      <span className="text-xs text-gray-500 font-mono">{layer.subtitle}</span>
                      {getStatusBadge(layer.status)}
                    </div>
                    <h4 className="text-lg font-bold text-gray-900">{layer.title}</h4>
                  </div>
                  <div className="text-left">
                    <p className="text-2xl font-black" style={{ color: layer.color }}>{layer.progress}٪</p>
                    <p className="text-[10px] text-gray-500">پیشرفت</p>
                  </div>
                </div>
                <p className="text-sm text-gray-600 leading-relaxed mb-4">
                  {layer.description}
                </p>
                <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {layer.items.map((item) => (
                    <div
                      key={item}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/80 border border-gray-100"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" style={{ color: layer.color }} />
                      <span className="text-sm text-gray-700">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}

          {/* Layer Stack Table */}
          <div className="mt-6 space-y-1">
            {architectureLayers.map((layer, idx) => {
              const Icon = layer.icon;
              return (
                <button
                  key={layer.id}
                  onClick={() => setActiveLayer(activeLayer === idx ? null : idx)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg border text-right ${
                    activeLayer === idx
                      ? `${layer.bgColor} ${layer.borderColor}`
                      : 'border-gray-100 bg-white hover:bg-gray-50'
                  }`}
                >
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: layer.color + '15' }}
                  >
                    <Icon className="w-4 h-4" style={{ color: layer.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-gray-900">{layer.title}</span>
                      <span className="text-[10px] text-gray-400 font-mono hidden sm:inline">{layer.subtitle}</span>
                    </div>
                  </div>
                  {getStatusBadge(layer.status)}
                  <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden flex-shrink-0">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${layer.progress}%`, backgroundColor: layer.color }}
                    />
                  </div>
                  <span className="text-xs text-gray-500 w-8 text-left flex-shrink-0">{layer.progress}٪</span>
                  <ChevronLeft className={`w-4 h-4 text-gray-400 ${activeLayer === idx ? '-rotate-90' : ''}`} />
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── Implementation Phases ── */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-teal-600" />
            فازبندی اجرا
          </CardTitle>
          <CardDescription>پیاده‌سازی تدریجی و اثبات‌شده — از MVP تا مقیاس ملی</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {implementationPhases.map((phase) => {
              const statusColor = phase.status === 'در حال اجرا' ? '#10b981' : phase.status === 'برنامه‌ریزی' ? '#3b82f6' : '#6b7280';
              return (
                <div
                  key={phase.phase}
                  className="rounded-xl border-2 p-5 relative overflow-hidden"
                  style={{ borderColor: phase.color + '30', backgroundColor: phase.color + '08' }}
                >
                  {/* Phase number */}
                  <div className="absolute top-2 left-2">
                    <span
                      className="text-4xl font-black"
                      style={{ color: phase.color + '15' }}
                    >
                      {phase.phase}
                    </span>
                  </div>

                  {/* Status */}
                  <div className="mb-3">
                    <span
                      className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white"
                      style={{ backgroundColor: statusColor }}
                    >
                      {phase.status}
                    </span>
                  </div>

                  {/* Title */}
                  <h4 className="font-bold text-gray-900 text-sm mb-0.5">{phase.title}</h4>
                  <p className="text-[10px] font-mono text-gray-400 mb-3">{phase.subtitle}</p>

                  {/* Description */}
                  <p className="text-xs text-gray-500 leading-relaxed mb-4">
                    {phase.description}
                  </p>

                  {/* Modules */}
                  <div className="space-y-1.5">
                    {phase.modules.map((mod) => (
                      <div key={mod} className="flex items-center gap-1.5 text-xs">
                        <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: phase.color }} />
                        <span className="text-gray-700">{mod}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── Strategic Insights ── */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Target className="h-5 w-5 text-amber-600" />
            تحلیل استراتژیک
          </CardTitle>
          <CardDescription>چرا این معماری؟ مزیت رقابتی پلتفرم</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-3 gap-4">
            {strategicInsights.map((insight) => {
              const Icon = insight.icon;
              return (
                <div
                  key={insight.title}
                  className={`rounded-xl border-2 p-5 ${insight.bgColor} ${insight.borderColor}`}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: insight.color + '15' }}
                  >
                    <Icon className="w-6 h-6" style={{ color: insight.color }} />
                  </div>
                  <h4 className="font-bold text-gray-900 text-sm mb-2">{insight.title}</h4>
                  <p className="text-xs text-gray-600 leading-relaxed">{insight.description}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
