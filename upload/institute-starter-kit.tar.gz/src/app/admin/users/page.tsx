'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  Shield,
  ShieldCheck,
  ShieldX,
  UserCheck,
  UserX,
  Loader2,
  KeyRound,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Permission {
  id: string;
  resource: string;
  action: string;
}

interface Role {
  id: string;
  name: string;
  label: string;
  description: string;
  isSystem: boolean;
  permissions: Permission[];
  _count?: { users: number };
}

interface AdminUser {
  id: string;
  username: string;
  displayName: string;
  roleId: string | null;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  role: Role | null;
}

/* ─────────── Constants ─────────── */

const RESOURCE_LABELS: Record<string, string> = {
  leads: 'سرنخ‌ها',
  courses: 'دوره‌ها',
  payments: 'پرداخت‌ها',
  reports: 'گزارش‌ها',
  settings: 'تنظیمات',
  exams: 'آزمون‌ها',
  users: 'کاربران',
  roles: 'نقش‌ها',
  blog: 'بلاگ',
  karamuz: 'کارآموزان',
  invoices: 'فاکتورها',
  tickets: 'تیکت‌ها',
  campaigns: 'کمپین‌ها',
  automation: 'اتوماسیون',
  analytics: 'تحلیل‌ها',
  knowledge_base: 'پایگاه دانش',
  service_contracts: 'قراردادها',
  referrers: 'معرف‌ها',
  api_keys: 'کلیدهای API',
  employment: 'استخدام',
  skill_programs: 'دوره‌های مهارتی',
};

const ACTION_LABELS: Record<string, string> = {
  view: 'مشاهده',
  create: 'ایجاد',
  edit: 'ویرایش',
  delete: 'حذف',
  manage: 'مدیریت کامل',
  export: 'خروجی',
};

/* ─────────── Component ─────────── */

export default function AdminUsersPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  // Dialog states
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [saving, setSaving] = useState(false);

  // Form states
  const [formUsername, setFormUsername] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formDisplayName, setFormDisplayName] = useState('');
  const [formRoleId, setFormRoleId] = useState('');
  const [formIsActive, setFormIsActive] = useState(true);

  const fetchUsers = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        setUsers(data);
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
  }, []);

  const fetchRoles = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/roles');
      if (res.ok) {
        const data = await res.json();
        setRoles(data);
      }
    } catch (error) {
      console.error('Failed to fetch roles:', error);
    }
  }, []);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await Promise.all([fetchUsers(), fetchRoles()]);
      setLoading(false);
    };
    load();
  }, [fetchUsers, fetchRoles]);

  // ─── Create User ───
  const handleCreate = async () => {
    if (!formUsername || !formPassword) return;
    setSaving(true);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: formUsername,
          password: formPassword,
          displayName: formDisplayName,
          roleId: formRoleId || null,
          isActive: formIsActive,
        }),
      });
      if (res.ok) {
        await fetchUsers();
        resetForm();
        setShowCreateDialog(false);
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در ایجاد کاربر');
      }
    } catch {
      alert('خطا در ایجاد کاربر');
    } finally {
      setSaving(false);
    }
  };

  // ─── Update User ───
  const handleUpdate = async () => {
    if (!selectedUser) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/users/${selectedUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: formUsername,
          password: formPassword || undefined,
          displayName: formDisplayName,
          roleId: formRoleId || null,
          isActive: formIsActive,
        }),
      });
      if (res.ok) {
        await fetchUsers();
        resetForm();
        setShowEditDialog(false);
        setSelectedUser(null);
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در به‌روزرسانی کاربر');
      }
    } catch {
      alert('خطا در به‌روزرسانی کاربر');
    } finally {
      setSaving(false);
    }
  };

  // ─── Delete User ───
  const handleDelete = async () => {
    if (!selectedUser) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/users/${selectedUser.id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        await fetchUsers();
        setShowDeleteDialog(false);
        setSelectedUser(null);
      } else {
        const data = await res.json();
        alert(data.error || 'خطا در حذف کاربر');
      }
    } catch {
      alert('خطا در حذف کاربر');
    } finally {
      setSaving(false);
    }
  };

  // ─── Toggle Active ───
  const handleToggleActive = async (user: AdminUser) => {
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !user.isActive }),
      });
      if (res.ok) {
        await fetchUsers();
      }
    } catch {
      alert('خطا در تغییر وضعیت کاربر');
    }
  };

  const resetForm = () => {
    setFormUsername('');
    setFormPassword('');
    setFormDisplayName('');
    setFormRoleId('');
    setFormIsActive(true);
  };

  const openEditDialog = (user: AdminUser) => {
    setSelectedUser(user);
    setFormUsername(user.username);
    setFormPassword('');
    setFormDisplayName(user.displayName);
    setFormRoleId(user.roleId || '');
    setFormIsActive(user.isActive);
    setShowEditDialog(true);
  };

  const openDeleteDialog = (user: AdminUser) => {
    setSelectedUser(user);
    setShowDeleteDialog(true);
  };

  // Filter users by search
  const filteredUsers = users.filter((user) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      user.username.toLowerCase().includes(q) ||
      user.displayName.toLowerCase().includes(q) ||
      (user.role?.label && user.role.label.includes(q))
    );
  });

  // Stats
  const totalUsers = users.length;
  const activeUsers = users.filter((u) => u.isActive).length;
  const inactiveUsers = users.filter((u) => !u.isActive).length;
  const usersWithRole = users.filter((u) => u.roleId).length;

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('fa-IR');
  };

  /* ─────────── Render ─────────── */

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center">
            <Users className="h-5 w-5 text-teal-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">مدیریت کاربران</h1>
            <p className="text-sm text-gray-500">مدیریت کاربران مدیر سیستم و سطح دسترسی آن‌ها</p>
          </div>
        </div>
        <Button onClick={() => { resetForm(); setShowCreateDialog(true); }} className="gap-2">
          <Plus className="h-4 w-4" />
          کاربر جدید
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
              <Users className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(totalUsers)}</p>
              <p className="text-xs text-gray-500">کل کاربران</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-green-50 flex items-center justify-center">
              <UserCheck className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(activeUsers)}</p>
              <p className="text-xs text-gray-500">فعال</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-50 flex items-center justify-center">
              <UserX className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(inactiveUsers)}</p>
              <p className="text-xs text-gray-500">غیرفعال</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-50 flex items-center justify-center">
              <ShieldCheck className="h-5 w-5 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(usersWithRole)}</p>
              <p className="text-xs text-gray-500">دارای نقش</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="جستجو بر اساس نام کاربری، نام نمایشی یا نقش..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">لیست کاربران</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredUsers.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-gray-400">
              <Users className="h-12 w-12 mb-3" />
              <p className="text-sm">کاربری یافت نشد</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">نام کاربری</TableHead>
                    <TableHead className="text-right">نام نمایشی</TableHead>
                    <TableHead className="text-right">نقش</TableHead>
                    <TableHead className="text-right">وضعیت</TableHead>
                    <TableHead className="text-right">آخرین ورود</TableHead>
                    <TableHead className="text-right">تاریخ ایجاد</TableHead>
                    <TableHead className="text-center">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                            <span className="text-xs font-bold text-gray-600">
                              {user.username.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          {user.username}
                        </div>
                      </TableCell>
                      <TableCell>{user.displayName || '—'}</TableCell>
                      <TableCell>
                        {user.role ? (
                          <Badge
                            variant="secondary"
                            className="gap-1"
                            style={{
                              backgroundColor: user.role.isSystem ? '#EFF6FF' : '#F0FDF4',
                              color: user.role.isSystem ? '#1D4ED8' : '#16A34A',
                            }}
                          >
                            <Shield className="h-3 w-3" />
                            {user.role.label}
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-gray-400">
                            بدون نقش
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <button
                          onClick={() => handleToggleActive(user)}
                          className="cursor-pointer"
                        >
                          {user.isActive ? (
                            <Badge className="bg-green-100 text-green-700 hover:bg-green-200">
                              فعال
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-700 hover:bg-red-200">
                              غیرفعال
                            </Badge>
                          )}
                        </button>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatDate(user.lastLoginAt)}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatDate(user.createdAt)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(user)}
                            title="ویرایش"
                          >
                            <Edit2 className="h-4 w-4 text-gray-500" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openDeleteDialog(user)}
                            title="حذف"
                          >
                            <Trash2 className="h-4 w-4 text-red-400" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create User Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserCheck className="h-5 w-5 text-teal-600" />
              ایجاد کاربر جدید
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                نام کاربری <span className="text-red-500">*</span>
              </label>
              <Input
                placeholder="مثلاً: admin2"
                value={formUsername}
                onChange={(e) => setFormUsername(e.target.value)}
                dir="ltr"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                رمز عبور <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <Input
                  type="password"
                  placeholder="حداقل ۶ کاراکتر"
                  value={formPassword}
                  onChange={(e) => setFormPassword(e.target.value)}
                  dir="ltr"
                />
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                نام نمایشی
              </label>
              <Input
                placeholder="مثلاً: علی محمدی"
                value={formDisplayName}
                onChange={(e) => setFormDisplayName(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                نقش
              </label>
              <Select value={formRoleId} onValueChange={setFormRoleId}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب نقش..." />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role.id} value={role.id}>
                      <div className="flex items-center gap-2">
                        <Shield className="h-3 w-3" />
                        {role.label}
                        {role.isSystem && (
                          <span className="text-xs text-blue-500">(سیستمی)</span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium text-gray-700">وضعیت:</label>
              <button
                onClick={() => setFormIsActive(!formIsActive)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium ${
                  formIsActive
                    ? 'bg-green-100 text-green-700'
                    : 'bg-red-100 text-red-700'
                }`}
              >
                {formIsActive ? (
                  <>
                    <UserCheck className="h-4 w-4" />
                    فعال
                  </>
                ) : (
                  <>
                    <UserX className="h-4 w-4" />
                    غیرفعال
                  </>
                )}
              </button>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
            >
              انصراف
            </Button>
            <Button
              onClick={handleCreate}
              disabled={!formUsername || !formPassword || saving}
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin ml-2" />
              ) : (
                <Plus className="h-4 w-4 ml-2" />
              )}
              ایجاد کاربر
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit2 className="h-5 w-5 text-teal-600" />
              ویرایش کاربر: {selectedUser?.username}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                نام کاربری
              </label>
              <Input
                value={formUsername}
                onChange={(e) => setFormUsername(e.target.value)}
                dir="ltr"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                رمز عبور جدید
                <span className="text-xs text-gray-400 font-normal mr-2">
                  (خالی بگذارید اگر نمی‌خواهید تغییر کند)
                </span>
              </label>
              <div className="relative">
                <Input
                  type="password"
                  placeholder="رمز عبور جدید (اختیاری)"
                  value={formPassword}
                  onChange={(e) => setFormPassword(e.target.value)}
                  dir="ltr"
                />
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                نام نمایشی
              </label>
              <Input
                value={formDisplayName}
                onChange={(e) => setFormDisplayName(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">
                نقش
              </label>
              <Select value={formRoleId} onValueChange={setFormRoleId}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب نقش..." />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role.id} value={role.id}>
                      <div className="flex items-center gap-2">
                        <Shield className="h-3 w-3" />
                        {role.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium text-gray-700">وضعیت:</label>
              <button
                onClick={() => setFormIsActive(!formIsActive)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium ${
                  formIsActive
                    ? 'bg-green-100 text-green-700'
                    : 'bg-red-100 text-red-700'
                }`}
              >
                {formIsActive ? (
                  <>
                    <UserCheck className="h-4 w-4" />
                    فعال
                  </>
                ) : (
                  <>
                    <UserX className="h-4 w-4" />
                    غیرفعال
                  </>
                )}
              </button>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
            >
              انصراف
            </Button>
            <Button
              onClick={handleUpdate}
              disabled={!formUsername || saving}
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin ml-2" />
              ) : null}
              ذخیره تغییرات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <ShieldX className="h-5 w-5 text-red-500" />
              حذف کاربر
            </AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف کاربر <strong>{selectedUser?.username}</strong> اطمینان دارید؟
              این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin ml-2" /> : null}
              حذف کاربر
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
