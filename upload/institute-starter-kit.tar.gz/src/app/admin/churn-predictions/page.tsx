'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Brain,
  AlertTriangle,
  Loader2,
  Eye,
  Play,
  ShieldAlert,
  ShieldX,
  ShieldCheck,
  Shield,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface ChurnPrediction {
  id: string;
  leadId: string;
  riskLevel: string;
  riskScore: number;
  factors: Record<string, string> | null;
  reasoning: string | null;
  recommendedActions: string | null;
  predictedAt: string;
  lead: {
    id: string;
    name: string;
    phone: string;
    segment: string;
    cluster: string;
    stage: string;
  };
}

/* ─────────── Constants ─────────── */

const RISK_META: Record<string, { label: string; color: string; bgColor: string; icon: React.ElementType }> = {
  LOW: { label: 'کم', color: 'text-green-700', bgColor: 'bg-green-100', icon: ShieldCheck },
  MEDIUM: { label: 'متوسط', color: 'text-yellow-700', bgColor: 'bg-yellow-100', icon: Shield },
  HIGH: { label: 'بالا', color: 'text-orange-700', bgColor: 'bg-orange-100', icon: ShieldAlert },
  CRITICAL: { label: 'بحرانی', color: 'text-red-700', bgColor: 'bg-red-100', icon: ShieldX },
};

const CLUSTER_LABELS: Record<string, string> = {
  'tech-ai': 'فناوری و هوش مصنوعی',
  'financial': 'مالی و ارزدیجیتال',
  'management': 'مدیریت و بازاریابی',
  'entrepreneurship': 'کارآفرینی',
};

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric', month: 'short', day: 'numeric',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function ChurnPredictionsPage() {
  const [predictions, setPredictions] = useState<ChurnPrediction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState<Record<string, number>>({});

  const [filterRisk, setFilterRisk] = useState<string>('all');
  const [batchRunning, setBatchRunning] = useState(false);

  const [detailPrediction, setDetailPrediction] = useState<ChurnPrediction | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);

  /* ── Data fetching ── */

  const fetchPredictions = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (filterRisk && filterRisk !== 'all') params.set('riskLevel', filterRisk);

      const res = await fetch(`/api/crm/churn-predictions?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت پیش‌بینی‌ها');
        return;
      }

      setPredictions(data['داده‌ها'] || []);
      setStats(data['آمار'] || {});
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [filterRisk]);

  useEffect(() => {
    fetchPredictions();
  }, [fetchPredictions]);

  /* ── Batch prediction ── */

  const runBatchPrediction = async () => {
    setBatchRunning(true);
    try {
      const res = await fetch('/api/crm/churn-predictions/batch', { method: 'POST' });
      if (res.ok) {
        fetchPredictions();
      }
    } catch { /* silent */ } finally { setBatchRunning(false); }
  };

  /* ── Computed ── */

  const riskDistribution = useMemo(() => {
    const total = predictions.length || 1;
    return {
      LOW: { count: stats.LOW || 0, pct: ((stats.LOW || 0) / total) * 100 },
      MEDIUM: { count: stats.MEDIUM || 0, pct: ((stats.MEDIUM || 0) / total) * 100 },
      HIGH: { count: stats.HIGH || 0, pct: ((stats.HIGH || 0) / total) * 100 },
      CRITICAL: { count: stats.CRITICAL || 0, pct: ((stats.CRITICAL || 0) / total) * 100 },
    };
  }, [stats, predictions]);

  const openDetail = (p: ChurnPrediction) => {
    setDetailPrediction(p);
    setDetailDialogOpen(true);
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Brain className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">پیش‌بینی ریزش مشتری</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(predictions.length)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">تحلیل هوشمند ریسک ترک مشتری</p>
          </div>
        </div>
        <Button
          onClick={runBatchPrediction}
          disabled={batchRunning}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          {batchRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
          تحلیل همه لیدها
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const).map(level => {
          const meta = RISK_META[level];
          const Icon = meta.icon;
          return (
            <Card key={level} className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500">{meta.label}</p>
                    <p className="text-2xl font-bold mt-1" style={{ color: level === 'LOW' ? '#15803d' : level === 'MEDIUM' ? '#a16207' : level === 'HIGH' ? '#c2410c' : '#b91c1c' }}>
                      {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(riskDistribution[level].count)}
                    </p>
                  </div>
                  <div className={`p-2.5 rounded-xl ${meta.bgColor} border border-gray-200`}>
                    <Icon className="w-5 h-5" style={{ color: level === 'LOW' ? '#15803d' : level === 'MEDIUM' ? '#a16207' : level === 'HIGH' ? '#c2410c' : '#b91c1c' }} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Risk Distribution Chart (CSS bars) */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <p className="text-sm font-bold text-gray-600 mb-3">توزیع سطح ریسک</p>
          <div className="flex gap-2 items-end h-32">
            {(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const).map(level => {
              const meta = RISK_META[level];
              const height = Math.max(riskDistribution[level].pct, 8);
              return (
                <div key={level} className="flex-1 flex flex-col items-center gap-1">
                  <span className="text-xs font-medium">{toPersianNumber(riskDistribution[level].count)}</span>
                  <div
                    className="w-full rounded-t-md transition-all duration-500"
                    style={{
                      height: `${height}%`,
                      backgroundColor: level === 'LOW' ? '#22c55e' : level === 'MEDIUM' ? '#eab308' : level === 'HIGH' ? '#f97316' : '#ef4444',
                    }}
                  />
                  <span className={`text-xs ${meta.color}`}>{meta.label}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Filter */}
      <div className="flex gap-3">
        <Select value={filterRisk} onValueChange={setFilterRisk}>
          <SelectTrigger className="w-full sm:w-44 bg-white">
            <SelectValue placeholder="سطح ریسک" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه سطوح</SelectItem>
            <SelectItem value="LOW">کم</SelectItem>
            <SelectItem value="MEDIUM">متوسط</SelectItem>
            <SelectItem value="HIGH">بالا</SelectItem>
            <SelectItem value="CRITICAL">بحرانی</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchPredictions}>تلاش مجدد</Button>
          </CardContent>
        </Card>
      ) : predictions.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Brain className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">پیش‌بینی‌ای یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">با تحلیل لیدها شروع کنید</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">مشتری</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">بخش‌بندی</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">سطح ریسک</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">امتیاز ریسک</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عوامل</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">تاریخ تحلیل</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {predictions.map((p) => {
                  const meta = RISK_META[p.riskLevel] || RISK_META.LOW;
                  const factors = p.factors as Record<string, string> | null;
                  return (
                    <TableRow key={p.id} className="hover:bg-gray-50/50">
                      <TableCell className="text-sm">
                        <div className="font-medium">{p.lead.name}</div>
                        <div className="text-xs text-gray-500">{toPersianNumber(p.lead.phone)}</div>
                      </TableCell>
                      <TableCell className="text-sm">
                        {CLUSTER_LABELS[p.lead.cluster] || p.lead.cluster || '-'}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`${meta.bgColor} ${meta.color} text-xs border-0`}>
                          {meta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm font-mono">
                        {toPersianNumber((p.riskScore * 100).toFixed(0))}٪
                      </TableCell>
                      <TableCell className="text-sm text-gray-500 max-w-48 truncate">
                        {factors ? Object.keys(factors).map(k => k).join('، ') : '-'}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatPersianDate(p.predictedAt)}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                          onClick={() => openDetail(p)}
                          title="مشاهده جزئیات"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto" dir="rtl">
          {detailPrediction && (() => {
            const meta = RISK_META[detailPrediction.riskLevel] || RISK_META.LOW;
            const factors = detailPrediction.factors as Record<string, string> | null;
            const actions = detailPrediction.recommendedActions
              ? JSON.parse(detailPrediction.recommendedActions)
              : [];
            return (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2 text-right">
                    <Brain className="w-5 h-5 text-teal-600" />
                    جزئیات تحلیل ریزش — {detailPrediction.lead.name}
                  </DialogTitle>
                </DialogHeader>

                <div className="space-y-4 py-2">
                  {/* Risk level & score */}
                  <div className="flex items-center gap-4">
                    <Badge className={`${meta.bgColor} ${meta.color} text-sm border-0`}>
                      ریسک {meta.label}
                    </Badge>
                    <span className="text-sm text-gray-600">
                      امتیاز: {toPersianNumber((detailPrediction.riskScore * 100).toFixed(0))} از ۱۰۰
                    </span>
                  </div>

                  {/* Risk score bar */}
                  <div className="space-y-1">
                    <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${detailPrediction.riskScore * 100}%`,
                          backgroundColor: detailPrediction.riskLevel === 'LOW' ? '#22c55e' : detailPrediction.riskLevel === 'MEDIUM' ? '#eab308' : detailPrediction.riskLevel === 'HIGH' ? '#f97316' : '#ef4444',
                        }}
                      />
                    </div>
                  </div>

                  {/* Factors */}
                  {factors && Object.keys(factors).length > 0 && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 mb-2">عوامل ریسک:</p>
                      <div className="space-y-1.5">
                        {Object.entries(factors).map(([key, value]) => (
                          <div key={key} className="flex items-center gap-2 bg-gray-50 rounded-lg p-2">
                            <div className="w-2 h-2 rounded-full bg-orange-400" />
                            <span className="text-sm font-medium text-gray-700">{key}:</span>
                            <span className="text-sm text-gray-500">{value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recommended actions */}
                  {actions.length > 0 && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 mb-2">اقدامات توصیه‌شده:</p>
                      <div className="space-y-1.5">
                        {actions.map((action: string, idx: number) => (
                          <div key={idx} className="flex items-center gap-2 bg-teal-50 rounded-lg p-2">
                            <div className="w-2 h-2 rounded-full bg-teal-500" />
                            <span className="text-sm text-teal-700">{action}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* AI Reasoning */}
                  {detailPrediction.reasoning && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 mb-1">تحلیل AI:</p>
                      <p className="text-sm text-gray-700 bg-gray-50 rounded-lg p-3 leading-7">
                        {detailPrediction.reasoning}
                      </p>
                    </div>
                  )}

                  {/* Lead info */}
                  <div className="border-t pt-3">
                    <p className="text-xs font-bold text-gray-500 mb-2">اطلاعات مشتری:</p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>نام: <span className="font-medium">{detailPrediction.lead.name}</span></div>
                      <div>تلفن: <span className="font-medium">{toPersianNumber(detailPrediction.lead.phone)}</span></div>
                      <div>مرحله: <span className="font-medium">{detailPrediction.lead.stage}</span></div>
                      <div>بخش: <span className="font-medium">{detailPrediction.lead.segment || '-'}</span></div>
                    </div>
                  </div>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
