'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  ArrowRight,
  Plus,
  Pencil,
  Trash2,
  ChevronDown,
  ChevronUp,
  Loader2,
  ListChecks,
  Users,
  Trophy,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileCheck,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Question {
  id: string;
  text: string;
  type: string;
  options: { label: string; text: string }[] | null;
  correctAnswer: string;
  points: number;
  difficulty: string;
  explanation: string | null;
  order: number;
  image: string | null;
}

interface ExamDetail {
  id: string;
  title: string;
  description: string | null;
  type: string;
  durationMinutes: number;
  passingScore: number;
  maxAttempts: number;
  shuffleQuestions: boolean;
  showResults: string;
  isActive: boolean;
  openAt: string | null;
  closeAt: string | null;
  skillProgram: { id: string; name: string } | null;
  questions: Question[];
  stats: {
    totalAttempts: number;
    completedAttempts: number;
    inProgressAttempts: number;
    avgScore: number;
    passRate: number;
    passCount: number;
    failCount: number;
  };
  attempts: {
    id: string;
    karAmuzId: string;
    status: string;
    score: number | null;
    maxScore: number | null;
    percentage: number | null;
    isPassed: boolean | null;
    startedAt: string;
    submittedAt: string | null;
    timeSpentSec: number | null;
    karAmuz: { id: string; firstName: string; lastName: string; phone: string };
  }[];
}

interface QuestionFormData {
  text: string;
  type: string;
  options: { label: string; text: string }[];
  correctAnswer: string;
  points: string;
  difficulty: string;
  explanation: string;
}

/* ─────────── Constants ─────────── */

const TYPE_MAP: Record<string, { label: string; bg: string }> = {
  QUIZ: { label: 'آزمون کوتاه', bg: 'bg-blue-50 border-blue-200 text-blue-700' },
  MIDTERM: { label: 'میان‌ترم', bg: 'bg-amber-50 border-amber-200 text-amber-700' },
  FINAL: { label: 'پایان‌ترم', bg: 'bg-red-50 border-red-200 text-red-700' },
  DIAGNOSTIC: { label: 'تشخیصی', bg: 'bg-purple-50 border-purple-200 text-purple-700' },
  PRACTICAL: { label: 'عملی', bg: 'bg-emerald-50 border-emerald-200 text-emerald-700' },
};

const DIFFICULTY_MAP: Record<string, { label: string; color: string }> = {
  EASY: { label: 'آسان', color: 'bg-green-100 text-green-700' },
  MEDIUM: { label: 'متوسط', color: 'bg-yellow-100 text-yellow-700' },
  HARD: { label: 'سخت', color: 'bg-red-100 text-red-700' },
};

const QUESTION_TYPE_MAP: Record<string, string> = {
  MULTIPLE_CHOICE: 'چهارگزینه‌ای',
  TRUE_FALSE: 'صحیح/غلط',
  SHORT_ANSWER: 'تشریحی',
};

const STATUS_MAP: Record<string, { label: string; color: string }> = {
  IN_PROGRESS: { label: 'در حال انجام', color: 'bg-blue-100 text-blue-700' },
  SUBMITTED: { label: 'ارسال شده', color: 'bg-green-100 text-green-700' },
  TIMED_OUT: { label: 'زمان تمام شده', color: 'bg-orange-100 text-orange-700' },
  AUTO_SUBMITTED: { label: 'ارسال خودکار', color: 'bg-amber-100 text-amber-700' },
};

const EMPTY_QUESTION_FORM: QuestionFormData = {
  text: '',
  type: 'MULTIPLE_CHOICE',
  options: [
    { label: 'الف', text: '' },
    { label: 'ب', text: '' },
    { label: 'ج', text: '' },
    { label: 'د', text: '' },
  ],
  correctAnswer: 'الف',
  points: '1',
  difficulty: 'MEDIUM',
  explanation: '',
};

const OPTION_LABELS = ['الف', 'ب', 'ج', 'د', 'هـ', 'و'];

/* ─────────── Main Component ─────────── */

export default function ExamDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const router = useRouter();
  const [examId, setExamId] = useState<string>('');

  useEffect(() => {
    params.then((p) => setExamId(p.id));
  }, [params]);

  /* ── State ── */
  const [exam, setExam] = useState<ExamDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('questions');

  // Question modal
  const [questionModalOpen, setQuestionModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [questionForm, setQuestionForm] = useState<QuestionFormData>(EMPTY_QUESTION_FORM);
  const [submitting, setSubmitting] = useState(false);

  // Delete
  const [deleteQuestionId, setDeleteQuestionId] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchExam = useCallback(async () => {
    if (!examId) return;
    try {
      const res = await fetch(`/api/admin/exams/${examId}`);
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || 'خطا در دریافت اطلاعات آزمون');
        return;
      }
      setExam(data);
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [examId]);

  useEffect(() => {
    fetchExam();
  }, [fetchExam]);

  /* ── Question handlers ── */

  const openCreateQuestionModal = () => {
    setEditingQuestion(null);
    setQuestionForm(EMPTY_QUESTION_FORM);
    setQuestionModalOpen(true);
  };

  const openEditQuestionModal = (q: Question) => {
    setEditingQuestion(q);
    setQuestionForm({
      text: q.text,
      type: q.type,
      options: q.options
        ? (q.options as { label: string; text: string }[])
        : [
            { label: 'الف', text: '' },
            { label: 'ب', text: '' },
            { label: 'ج', text: '' },
            { label: 'د', text: '' },
          ],
      correctAnswer: q.correctAnswer,
      points: q.points.toString(),
      difficulty: q.difficulty,
      explanation: q.explanation || '',
    });
    setQuestionModalOpen(true);
  };

  const handleQuestionSubmit = async () => {
    if (!questionForm.text.trim()) {
      toast.error('متن سوال الزامی است');
      return;
    }
    if (!questionForm.correctAnswer.trim()) {
      toast.error('پاسخ صحیح الزامی است');
      return;
    }

    if (questionForm.type === 'MULTIPLE_CHOICE') {
      const filledOptions = questionForm.options.filter((o) => o.text.trim());
      if (filledOptions.length < 2) {
        toast.error('حداقل ۲ گزینه وارد کنید');
        return;
      }
    }

    setSubmitting(true);

    try {
      const payload = {
        text: questionForm.text.trim(),
        type: questionForm.type,
        options: questionForm.type === 'MULTIPLE_CHOICE' ? questionForm.options.filter((o) => o.text.trim()) : null,
        correctAnswer:
          questionForm.type === 'TRUE_FALSE'
            ? questionForm.correctAnswer
            : questionForm.correctAnswer.trim(),
        points: parseFloat(questionForm.points) || 1,
        difficulty: questionForm.difficulty,
        explanation: questionForm.explanation.trim() || null,
      };

      let res: Response;

      if (editingQuestion) {
        res = await fetch(`/api/admin/exams/${examId}/questions/${editingQuestion.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch(`/api/admin/exams/${examId}/questions`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'خطا در ذخیره‌سازی');
        return;
      }

      toast.success(editingQuestion ? 'سوال با موفقیت ویرایش شد' : 'سوال جدید با موفقیت اضافه شد');
      setQuestionModalOpen(false);
      fetchExam();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteQuestion = async () => {
    if (!deleteQuestionId) return;

    try {
      const res = await fetch(`/api/admin/exams/${examId}/questions/${deleteQuestionId}`, {
        method: 'DELETE',
      });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error || 'خطا در حذف سوال');
        return;
      }
      toast.success('سوال با موفقیت حذف شد');
      fetchExam();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    }

    setDeleteQuestionId(null);
  };

  const moveQuestion = async (questionId: string, direction: 'up' | 'down') => {
    if (!exam) return;
    const questions = [...exam.questions];
    const idx = questions.findIndex((q) => q.id === questionId);
    if (idx < 0) return;

    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= questions.length) return;

    // Swap
    [questions[idx], questions[swapIdx]] = [questions[swapIdx], questions[idx]];

    // Optimistic update
    setExam({ ...exam, questions });

    try {
      await fetch(`/api/admin/exams/${examId}/questions`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questions: questions.map((q, i) => ({ id: q.id, order: i })),
        }),
      });
    } catch {
      toast.error('خطا در تغییر ترتیب');
      fetchExam();
    }
  };

  /* ── Helper ── */

  const formatTime = (sec: number | null): string => {
    if (!sec) return '—';
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${toPersianNumber(m)}:${toPersianNumber(s.toString().padStart(2, '0'))}`;
  };

  /* ──── Render ──── */

  if (loading) {
    return (
      <div className="space-y-4" dir="rtl">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!exam) {
    return (
      <div className="text-center py-12" dir="rtl">
        <AlertTriangle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
        <p className="text-gray-500">آزمون یافت نشد</p>
        <Button onClick={() => router.push('/admin/exams')} className="mt-4 gap-2">
          <ArrowRight className="w-4 h-4" />
          بازگشت به لیست آزمون‌ها
        </Button>
      </div>
    );
  }

  const typeMeta = TYPE_MAP[exam.type] || TYPE_MAP.QUIZ;
  const totalPoints = exam.questions.reduce((sum, q) => sum + q.points, 0);
  const s = exam.stats;

  return (
    <div className="space-y-6" dir="rtl">
      {/* Back button + Header */}
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.push('/admin/exams')}
          className="shrink-0"
        >
          <ArrowRight className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-gray-900">{exam.title}</h1>
            <Badge variant="outline" className={`text-[10px] ${typeMeta.bg}`}>
              {typeMeta.label}
            </Badge>
            <Badge
              variant="secondary"
              className={
                exam.isActive
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px]'
                  : 'bg-red-50 text-red-700 border border-red-200 text-[11px]'
              }
            >
              {exam.isActive ? 'فعال' : 'غیرفعال'}
            </Badge>
          </div>
          {exam.skillProgram && (
            <p className="text-sm text-gray-500 mt-1">
              دوره: {exam.skillProgram.name}
            </p>
          )}
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <ListChecks className="w-5 h-5 text-blue-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-gray-900">{toPersianNumber(exam.questions.length)}</p>
            <p className="text-[10px] text-gray-500">سوال</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <FileCheck className="w-5 h-5 text-purple-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-gray-900">{toPersianNumber(totalPoints)}</p>
            <p className="text-[10px] text-gray-500">بارم کل</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <Users className="w-5 h-5 text-amber-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-gray-900">{toPersianNumber(s.totalAttempts)}</p>
            <p className="text-[10px] text-gray-500">شرکت‌کننده</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <Trophy className="w-5 h-5 text-emerald-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-emerald-700">{toPersianNumber(Math.round(s.avgScore))}٪</p>
            <p className="text-[10px] text-gray-500">میانگین نمره</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <CheckCircle2 className="w-5 h-5 text-green-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-green-700">{toPersianNumber(s.passCount)}</p>
            <p className="text-[10px] text-gray-500">قبول</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-3 text-center">
            <XCircle className="w-5 h-5 text-red-500 mx-auto mb-1" />
            <p className="text-lg font-bold text-red-700">{toPersianNumber(s.failCount)}</p>
            <p className="text-[10px] text-gray-500">مردود</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-gray-100">
          <TabsTrigger value="questions" className="gap-1.5">
            <ListChecks className="w-4 h-4" />
            سوالات ({toPersianNumber(exam.questions.length)})
          </TabsTrigger>
          <TabsTrigger value="results" className="gap-1.5">
            <Users className="w-4 h-4" />
            نتایج ({toPersianNumber(s.completedAttempts)})
          </TabsTrigger>
        </TabsList>

        {/* Questions Tab */}
        <TabsContent value="questions" className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">
              بارم کل: {toPersianNumber(totalPoints)} | حداقل نمره قبولی: {toPersianNumber(exam.passingScore)} | مدت: {toPersianNumber(exam.durationMinutes)} دقیقه
            </p>
            <Button
              onClick={openCreateQuestionModal}
              className="bg-teal-600 hover:bg-teal-700 gap-2 text-white"
            >
              <Plus className="h-4 w-4" />
              سوال جدید
            </Button>
          </div>

          {exam.questions.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <ListChecks className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">هنوز سوالی اضافه نشده</p>
                <p className="text-gray-400 text-sm mt-1">
                  اولین سوال آزمون را اضافه کنید
                </p>
                <Button
                  onClick={openCreateQuestionModal}
                  className="mt-4 bg-teal-600 hover:bg-teal-700 gap-2 text-white"
                >
                  <Plus className="h-4 w-4" />
                  سوال جدید
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {exam.questions.map((q, index) => {
                const diffMeta = DIFFICULTY_MAP[q.difficulty] || DIFFICULTY_MAP.MEDIUM;
                return (
                  <Card key={q.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        {/* Order number */}
                        <div className="w-8 h-8 rounded-full bg-teal-50 border border-teal-200 flex items-center justify-center shrink-0">
                          <span className="text-sm font-bold text-teal-700">
                            {toPersianNumber(index + 1)}
                          </span>
                        </div>

                        <div className="flex-1 min-w-0">
                          {/* Question text */}
                          <p className="text-gray-900 font-medium leading-relaxed mb-2">
                            {q.text}
                          </p>

                          {/* Options for MCQ */}
                          {q.type === 'MULTIPLE_CHOICE' && q.options && (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 mb-2">
                              {(q.options as { label: string; text: string }[]).map((opt) => (
                                <div
                                  key={opt.label}
                                  className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-sm ${
                                    opt.label === q.correctAnswer
                                      ? 'bg-green-50 border border-green-200 text-green-700 font-medium'
                                      : 'bg-gray-50 border border-gray-100 text-gray-600'
                                  }`}
                                >
                                  <span className="font-bold text-xs">{opt.label}</span>
                                  <span>{opt.text}</span>
                                  {opt.label === q.correctAnswer && (
                                    <CheckCircle2 className="w-3.5 h-3.5 mr-auto text-green-600" />
                                  )}
                                </div>
                              ))}
                            </div>
                          )}

                          {/* True/False answer */}
                          {q.type === 'TRUE_FALSE' && (
                            <div className="flex gap-2 mb-2">
                              <Badge
                                className={
                                  q.correctAnswer === 'صحیح'
                                    ? 'bg-green-50 text-green-700 border border-green-200'
                                    : 'bg-gray-50 text-gray-500 border border-gray-200'
                                }
                              >
                                صحیح {q.correctAnswer === 'صحیح' && '✓'}
                              </Badge>
                              <Badge
                                className={
                                  q.correctAnswer === 'غلط'
                                    ? 'bg-green-50 text-green-700 border border-green-200'
                                    : 'bg-gray-50 text-gray-500 border border-gray-200'
                                }
                              >
                                غلط {q.correctAnswer === 'غلط' && '✓'}
                              </Badge>
                            </div>
                          )}

                          {/* Short answer */}
                          {q.type === 'SHORT_ANSWER' && (
                            <div className="mb-2">
                              <Badge className="bg-green-50 text-green-700 border border-green-200">
                                پاسخ: {q.correctAnswer}
                              </Badge>
                            </div>
                          )}

                          {/* Explanation */}
                          {q.explanation && (
                            <div className="text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-1.5 mb-2">
                              💡 {q.explanation}
                            </div>
                          )}

                          {/* Badges row */}
                          <div className="flex flex-wrap items-center gap-1.5">
                            <Badge variant="secondary" className="text-[10px] bg-gray-50 text-gray-600">
                              {QUESTION_TYPE_MAP[q.type] || q.type}
                            </Badge>
                            <Badge variant="secondary" className={`text-[10px] ${diffMeta.color}`}>
                              {diffMeta.label}
                            </Badge>
                            <Badge variant="secondary" className="text-[10px] bg-blue-50 text-blue-600">
                              {toPersianNumber(q.points)} نمره
                            </Badge>
                          </div>
                        </div>

                        {/* Action buttons */}
                        <div className="flex flex-col gap-1 shrink-0">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => moveQuestion(q.id, 'up')}
                            disabled={index === 0}
                          >
                            <ChevronUp className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={() => moveQuestion(q.id, 'down')}
                            disabled={index === exam.questions.length - 1}
                          >
                            <ChevronDown className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-gray-500 hover:text-teal-600"
                            onClick={() => openEditQuestionModal(q)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 text-gray-500 hover:text-red-600"
                            onClick={() => setDeleteQuestionId(q.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* Results Tab */}
        <TabsContent value="results" className="space-y-4">
          {/* Pass rate bar */}
          {s.completedAttempts > 0 && (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">نرخ قبولی</span>
                  <span className="text-sm font-bold text-emerald-700">
                    {toPersianNumber(Math.round(s.passRate))}٪
                  </span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-3">
                  <div
                    className="h-3 rounded-full bg-emerald-500 transition-all duration-500"
                    style={{ width: `${Math.round(s.passRate)}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>{toPersianNumber(s.passCount)} قبول</span>
                  <span>{toPersianNumber(s.failCount)} مردود</span>
                </div>
              </CardContent>
            </Card>
          )}

          {exam.attempts.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">هنوز کسی در این آزمون شرکت نکرده</p>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="px-4 py-3 text-right font-medium text-gray-600">نام کارآموز</th>
                      <th className="px-4 py-3 text-center font-medium text-gray-600">وضعیت</th>
                      <th className="px-4 py-3 text-center font-medium text-gray-600">نمره</th>
                      <th className="px-4 py-3 text-center font-medium text-gray-600">درصد</th>
                      <th className="px-4 py-3 text-center font-medium text-gray-600">نتیجه</th>
                      <th className="px-4 py-3 text-center font-medium text-gray-600">زمان</th>
                      <th className="px-4 py-3 text-center font-medium text-gray-600">تاریخ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {exam.attempts.map((attempt) => {
                      const statusMeta = STATUS_MAP[attempt.status] || STATUS_MAP.SUBMITTED;
                      return (
                        <tr key={attempt.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <span className="font-medium text-gray-900">
                              {attempt.karAmuz.firstName} {attempt.karAmuz.lastName}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <Badge variant="secondary" className={`text-[10px] ${statusMeta.color}`}>
                              {statusMeta.label}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-center font-mono">
                            {attempt.score !== null
                              ? `${toPersianNumber(attempt.score)} / ${toPersianNumber(attempt.maxScore || 0)}`
                              : '—'}
                          </td>
                          <td className="px-4 py-3 text-center">
                            {attempt.percentage !== null ? (
                              <span
                                className={`font-bold ${
                                  attempt.isPassed ? 'text-emerald-600' : 'text-red-600'
                                }`}
                              >
                                {toPersianNumber(Math.round(attempt.percentage))}٪
                              </span>
                            ) : (
                              '—'
                            )}
                          </td>
                          <td className="px-4 py-3 text-center">
                            {attempt.isPassed !== null ? (
                              attempt.isPassed ? (
                                <CheckCircle2 className="w-5 h-5 text-emerald-600 mx-auto" />
                              ) : (
                                <XCircle className="w-5 h-5 text-red-500 mx-auto" />
                              )
                            ) : (
                              '—'
                            )}
                          </td>
                          <td className="px-4 py-3 text-center text-gray-600">
                            {formatTime(attempt.timeSpentSec)}
                          </td>
                          <td className="px-4 py-3 text-center text-gray-500 text-xs">
                            {new Date(attempt.submittedAt || attempt.startedAt).toLocaleDateString('fa-IR')}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Add/Edit Question Modal */}
      <Dialog open={questionModalOpen} onOpenChange={setQuestionModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingQuestion ? 'ویرایش سوال' : 'افزودن سوال جدید'}
            </DialogTitle>
            <DialogDescription>
              {editingQuestion
                ? 'محتوای سوال را ویرایش کنید'
                : `سوال شماره ${toPersianNumber((exam?.questions.length || 0) + 1)}`}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
            {/* Question Text */}
            <div className="sm:col-span-2">
              <Label htmlFor="qText" className="text-sm font-medium text-gray-700">
                متن سوال <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="qText"
                value={questionForm.text}
                onChange={(e) => setQuestionForm({ ...questionForm, text: e.target.value })}
                placeholder="متن سوال را وارد کنید..."
                className="mt-1.5 min-h-[80px]"
              />
            </div>

            {/* Question Type */}
            <div>
              <Label className="text-sm font-medium text-gray-700">نوع سوال</Label>
              <Select
                value={questionForm.type}
                onValueChange={(val) => {
                  const newForm = { ...questionForm, type: val };
                  if (val === 'TRUE_FALSE') {
                    newForm.correctAnswer = 'صحیح';
                    newForm.options = [];
                  } else if (val === 'SHORT_ANSWER') {
                    newForm.options = [];
                  } else {
                    newForm.options = [
                      { label: 'الف', text: '' },
                      { label: 'ب', text: '' },
                      { label: 'ج', text: '' },
                      { label: 'د', text: '' },
                    ];
                    newForm.correctAnswer = 'الف';
                  }
                  setQuestionForm(newForm);
                }}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MULTIPLE_CHOICE">چهارگزینه‌ای</SelectItem>
                  <SelectItem value="TRUE_FALSE">صحیح/غلط</SelectItem>
                  <SelectItem value="SHORT_ANSWER">تشریحی</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Difficulty */}
            <div>
              <Label className="text-sm font-medium text-gray-700">سختی</Label>
              <Select
                value={questionForm.difficulty}
                onValueChange={(val) => setQuestionForm({ ...questionForm, difficulty: val })}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="EASY">آسان</SelectItem>
                  <SelectItem value="MEDIUM">متوسط</SelectItem>
                  <SelectItem value="HARD">سخت</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Points */}
            <div>
              <Label htmlFor="qPoints" className="text-sm font-medium text-gray-700">
                نمره سوال
              </Label>
              <Input
                id="qPoints"
                type="number"
                min={0.5}
                step={0.5}
                value={questionForm.points}
                onChange={(e) => setQuestionForm({ ...questionForm, points: e.target.value })}
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* MCQ Options */}
            {questionForm.type === 'MULTIPLE_CHOICE' && (
              <div className="sm:col-span-2">
                <Label className="text-sm font-medium text-gray-700 mb-2 block">گزینه‌ها</Label>
                <div className="space-y-2">
                  {questionForm.options.map((opt, idx) => (
                    <div key={opt.label} className="flex items-center gap-2">
                      <Button
                        type="button"
                        variant={questionForm.correctAnswer === opt.label ? 'default' : 'outline'}
                        size="sm"
                        className={`w-8 h-8 p-0 font-bold shrink-0 ${
                          questionForm.correctAnswer === opt.label
                            ? 'bg-green-600 hover:bg-green-700 text-white'
                            : ''
                        }`}
                        onClick={() =>
                          setQuestionForm({ ...questionForm, correctAnswer: opt.label })
                        }
                        title="انتخاب به عنوان پاسخ صحیح"
                      >
                        {opt.label}
                      </Button>
                      <Input
                        value={opt.text}
                        onChange={(e) => {
                          const newOptions = [...questionForm.options];
                          newOptions[idx] = { ...newOptions[idx], text: e.target.value };
                          setQuestionForm({ ...questionForm, options: newOptions });
                        }}
                        placeholder={`گزینه ${opt.label}`}
                        className="flex-1"
                      />
                      {questionForm.correctAnswer === opt.label && (
                        <CheckCircle2 className="w-5 h-5 text-green-600 shrink-0" />
                      )}
                    </div>
                  ))}
                  {/* Add option button */}
                  {questionForm.options.length < 6 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="gap-1 text-xs"
                      onClick={() => {
                        const nextLabel = OPTION_LABELS[questionForm.options.length];
                        setQuestionForm({
                          ...questionForm,
                          options: [...questionForm.options, { label: nextLabel, text: '' }],
                        });
                      }}
                    >
                      <Plus className="w-3 h-3" />
                      افزودن گزینه
                    </Button>
                  )}
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  روی حرف گزینه کلیک کنید تا به عنوان پاسخ صحیح انتخاب شود
                </p>
              </div>
            )}

            {/* True/False answer */}
            {questionForm.type === 'TRUE_FALSE' && (
              <div className="sm:col-span-2">
                <Label className="text-sm font-medium text-gray-700 mb-2 block">پاسخ صحیح</Label>
                <div className="flex gap-3">
                  <Button
                    type="button"
                    variant={questionForm.correctAnswer === 'صحیح' ? 'default' : 'outline'}
                    className={
                      questionForm.correctAnswer === 'صحیح'
                        ? 'bg-green-600 hover:bg-green-700 text-white'
                        : ''
                    }
                    onClick={() =>
                      setQuestionForm({ ...questionForm, correctAnswer: 'صحیح' })
                    }
                  >
                    صحیح
                  </Button>
                  <Button
                    type="button"
                    variant={questionForm.correctAnswer === 'غلط' ? 'default' : 'outline'}
                    className={
                      questionForm.correctAnswer === 'غلط'
                        ? 'bg-red-600 hover:bg-red-700 text-white'
                        : ''
                    }
                    onClick={() =>
                      setQuestionForm({ ...questionForm, correctAnswer: 'غلط' })
                    }
                  >
                    غلط
                  </Button>
                </div>
              </div>
            )}

            {/* Short answer */}
            {questionForm.type === 'SHORT_ANSWER' && (
              <div className="sm:col-span-2">
                <Label htmlFor="qCorrect" className="text-sm font-medium text-gray-700">
                  پاسخ صحیح <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="qCorrect"
                  value={questionForm.correctAnswer}
                  onChange={(e) =>
                    setQuestionForm({ ...questionForm, correctAnswer: e.target.value })
                  }
                  placeholder="پاسخ صحیح را وارد کنید"
                  className="mt-1.5"
                />
                <p className="text-xs text-gray-400 mt-1">
                  مقایسه بدون حساسیت به حروف بزرگ/کوچک انجام می‌شود
                </p>
              </div>
            )}

            {/* Explanation */}
            <div className="sm:col-span-2">
              <Label htmlFor="qExplanation" className="text-sm font-medium text-gray-700">
                توضیح پاسخ (اختیاری)
              </Label>
              <Textarea
                id="qExplanation"
                value={questionForm.explanation}
                onChange={(e) =>
                  setQuestionForm({ ...questionForm, explanation: e.target.value })
                }
                placeholder="توضیحی که بعد از آزمون به کارآموز نمایش داده می‌شود..."
                className="mt-1.5 min-h-[60px]"
              />
            </div>
          </div>

          <DialogFooter className="gap-2 mt-2">
            <Button
              variant="outline"
              onClick={() => setQuestionModalOpen(false)}
              disabled={submitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleQuestionSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editingQuestion ? 'ذخیره تغییرات' : 'افزودن سوال'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Question Confirmation */}
      <AlertDialog open={!!deleteQuestionId} onOpenChange={() => setDeleteQuestionId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف سوال</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف این سوال اطمینان دارید؟ این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteQuestion}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
