'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  ClipboardCheck,
  Plus,
  Search,
  Pencil,
  Trash2,
  CheckCircle,
  XCircle,
  ChevronLeft,
  ChevronRight,
  Clock,
  Loader2,
  Eye,
  ListChecks,
  Users,
  Trophy,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface SkillProgram {
  id: string;
  name: string;
}

interface Exam {
  id: string;
  title: string;
  description: string | null;
  type: string;
  durationMinutes: number;
  passingScore: number;
  maxAttempts: number;
  shuffleQuestions: boolean;
  showResults: string;
  isActive: boolean;
  openAt: string | null;
  closeAt: string | null;
  createdAt: string;
  skillProgram: { id: string; name: string } | null;
  _count: {
    questions: number;
    attempts: number;
  };
}

interface PaginationInfo {
  صفحه: number;
  حجم: number;
  کل: number;
  تعداد_صفحات: number;
}

interface FormData {
  title: string;
  description: string;
  skillProgramId: string;
  type: string;
  durationMinutes: string;
  passingScore: string;
  maxAttempts: string;
  shuffleQuestions: boolean;
  showResults: string;
  isActive: boolean;
  openAt: string;
  closeAt: string;
}

/* ─────────── Constants ─────────── */

const TYPE_MAP: Record<string, { label: string; color: string; bg: string }> = {
  QUIZ: { label: 'آزمون کوتاه', color: 'text-blue-700', bg: 'bg-blue-50 border-blue-200 text-blue-700' },
  MIDTERM: { label: 'میان‌ترم', color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200 text-amber-700' },
  FINAL: { label: 'پایان‌ترم', color: 'text-red-700', bg: 'bg-red-50 border-red-200 text-red-700' },
  DIAGNOSTIC: { label: 'تشخیصی', color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200 text-purple-700' },
  PRACTICAL: { label: 'عملی', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200 text-emerald-700' },
};

const SHOW_RESULTS_MAP: Record<string, string> = {
  AFTER_SUBMIT: 'بعد از ارسال',
  AFTER_DEADLINE: 'بعد از مهلت',
  NEVER: 'هرگز',
};

const EMPTY_FORM: FormData = {
  title: '',
  description: '',
  skillProgramId: '',
  type: 'QUIZ',
  durationMinutes: '30',
  passingScore: '10',
  maxAttempts: '1',
  shuffleQuestions: true,
  showResults: 'AFTER_SUBMIT',
  isActive: true,
  openAt: '',
  closeAt: '',
};

const ITEMS_PER_PAGE = 12;

/* ─────────── Main Component ─────────── */

export default function ExamsAdminPage() {
  const router = useRouter();

  /* ── State ── */
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<PaginationInfo | null>(null);
  const [skillPrograms, setSkillPrograms] = useState<SkillProgram[]>([]);

  // Filters
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingExam, setEditingExam] = useState<Exam | null>(null);
  const [form, setForm] = useState<FormData>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  // Delete
  const [deleteId, setDeleteId] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchExams = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      params.set('page', currentPage.toString());
      params.set('limit', ITEMS_PER_PAGE.toString());
      if (search) params.set('search', search);
      if (typeFilter !== 'all') params.set('type', typeFilter);
      if (statusFilter !== 'all') params.set('isActive', statusFilter);

      const res = await fetch(`/api/admin/exams?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'خطا در دریافت لیست آزمون‌ها');
        return;
      }

      setExams(data['داده‌ها'] || []);
      setPagination(data['صفحه‌بندی'] || null);
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [currentPage, search, typeFilter, statusFilter]);

  const fetchSkillPrograms = useCallback(async () => {
    try {
      const res = await fetch('/api/crm/skill-programs?limit=100');
      const data = await res.json();
      if (res.ok) {
        setSkillPrograms(data['داده‌ها'] || []);
      }
    } catch {
      // silent fail
    }
  }, []);

  useEffect(() => {
    fetchExams();
  }, [fetchExams]);

  useEffect(() => {
    fetchSkillPrograms();
  }, [fetchSkillPrograms]);

  useEffect(() => {
    setCurrentPage(1);
  }, [search, typeFilter, statusFilter]);

  /* ── Computed stats ── */

  const totalExams = pagination?.کل ?? exams.length;
  const activeCount = exams.filter((e) => e.isActive).length;
  const totalQuestions = exams.reduce((sum, e) => sum + e._count.questions, 0);
  const totalAttempts = exams.reduce((sum, e) => sum + e._count.attempts, 0);

  /* ── Modal handlers ── */

  const openCreateModal = () => {
    setEditingExam(null);
    setForm(EMPTY_FORM);
    setModalOpen(true);
  };

  const openEditModal = (exam: Exam) => {
    setEditingExam(exam);
    setForm({
      title: exam.title,
      description: exam.description || '',
      skillProgramId: exam.skillProgram?.id || '',
      type: exam.type,
      durationMinutes: exam.durationMinutes.toString(),
      passingScore: exam.passingScore.toString(),
      maxAttempts: exam.maxAttempts.toString(),
      shuffleQuestions: exam.shuffleQuestions,
      showResults: exam.showResults,
      isActive: exam.isActive,
      openAt: exam.openAt ? new Date(exam.openAt).toISOString().slice(0, 16) : '',
      closeAt: exam.closeAt ? new Date(exam.closeAt).toISOString().slice(0, 16) : '',
    });
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    if (!form.title.trim()) {
      toast.error('عنوان آزمون الزامی است');
      return;
    }

    setSubmitting(true);

    try {
      const payload = {
        title: form.title.trim(),
        description: form.description.trim() || null,
        skillProgramId: form.skillProgramId || null,
        type: form.type,
        durationMinutes: form.durationMinutes,
        passingScore: form.passingScore,
        maxAttempts: form.maxAttempts,
        shuffleQuestions: form.shuffleQuestions,
        showResults: form.showResults,
        isActive: form.isActive,
        openAt: form.openAt || null,
        closeAt: form.closeAt || null,
      };

      let res: Response;

      if (editingExam) {
        res = await fetch(`/api/admin/exams/${editingExam.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch('/api/admin/exams', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'خطا در ذخیره‌سازی');
        return;
      }

      toast.success(editingExam ? 'آزمون با موفقیت ویرایش شد' : 'آزمون جدید با موفقیت ایجاد شد');
      setModalOpen(false);
      fetchExams();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setSubmitting(false);
    }
  };

  /* ── Delete handler ── */

  const handleDelete = async () => {
    if (!deleteId) return;

    try {
      const res = await fetch(`/api/admin/exams/${deleteId}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error || 'خطا در حذف آزمون');
        return;
      }
      toast.success('آزمون با موفقیت غیرفعال شد');
      fetchExams();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    }

    setDeleteId(null);
  };

  /* ── Page navigation ── */

  const totalPages = pagination?.تعداد_صفحات ?? 1;

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) setCurrentPage(page);
  };

  const getPageNumbers = (): (number | '...')[] => {
    if (totalPages <= 5) return Array.from({ length: totalPages }, (_, i) => i + 1);
    const pages: (number | '...')[] = [1];
    if (currentPage > 3) pages.push('...');
    const start = Math.max(2, currentPage - 1);
    const end = Math.min(totalPages - 1, currentPage + 1);
    for (let i = start; i <= end; i++) pages.push(i);
    if (currentPage < totalPages - 2) pages.push('...');
    pages.push(totalPages);
    return pages;
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <ClipboardCheck className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">مدیریت آزمون‌ها</h1>
            <p className="text-gray-500 mt-0.5 text-sm">
              ایجاد، ویرایش و مدیریت آزمون‌های آنلاین
            </p>
          </div>
        </div>
        <Button
          onClick={openCreateModal}
          className="bg-teal-600 hover:bg-teal-700 gap-2 text-white"
        >
          <Plus className="h-4 w-4" />
          آزمون جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کل آزمون‌ها</p>
                <p className="text-2xl font-bold mt-1 text-gray-900">
                  {loading ? <Skeleton className="h-8 w-12 inline-block" /> : toPersianNumber(totalExams)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <ClipboardCheck className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">فعال</p>
                <p className="text-2xl font-bold mt-1 text-emerald-700">
                  {loading ? <Skeleton className="h-8 w-12 inline-block" /> : toPersianNumber(activeCount)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کل سوالات</p>
                <p className="text-2xl font-bold mt-1 text-purple-700">
                  {loading ? <Skeleton className="h-8 w-12 inline-block" /> : toPersianNumber(totalQuestions)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200">
                <ListChecks className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کل شرکت‌کنندگان</p>
                <p className="text-2xl font-bold mt-1 text-amber-700">
                  {loading ? <Skeleton className="h-8 w-12 inline-block" /> : toPersianNumber(totalAttempts)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                <Users className="w-5 h-5 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter Bar */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="جستجو عنوان آزمون..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-full sm:w-44">
                <SelectValue placeholder="نوع آزمون" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه انواع</SelectItem>
                <SelectItem value="QUIZ">آزمون کوتاه</SelectItem>
                <SelectItem value="MIDTERM">میان‌ترم</SelectItem>
                <SelectItem value="FINAL">پایان‌ترم</SelectItem>
                <SelectItem value="DIAGNOSTIC">تشخیصی</SelectItem>
                <SelectItem value="PRACTICAL">عملی</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-36">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه</SelectItem>
                <SelectItem value="true">فعال</SelectItem>
                <SelectItem value="false">غیرفعال</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Cards Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-5 space-y-3">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <div className="flex gap-2">
                  <Skeleton className="h-6 w-20" />
                  <Skeleton className="h-6 w-16" />
                </div>
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : exams.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <ClipboardCheck className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">آزمونی یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با ایجاد آزمون جدید شروع کنید
            </p>
            <Button
              onClick={openCreateModal}
              className="mt-4 bg-teal-600 hover:bg-teal-700 gap-2 text-white"
            >
              <Plus className="h-4 w-4" />
              آزمون جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {exams.map((exam) => {
            const typeMeta = TYPE_MAP[exam.type] || TYPE_MAP.QUIZ;

            return (
              <Card
                key={exam.id}
                className="bg-white rounded-xl shadow-sm border hover:shadow-md transition-shadow duration-200 group"
              >
                <CardContent className="p-5">
                  {/* Header: Title + Type Badge */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <h3 className="font-bold text-gray-900 text-base leading-relaxed line-clamp-2">
                      {exam.title}
                    </h3>
                    <Badge
                      variant="outline"
                      className={`shrink-0 text-[10px] font-medium ${typeMeta.bg}`}
                    >
                      {typeMeta.label}
                    </Badge>
                  </div>

                  {/* Skill Program */}
                  {exam.skillProgram && (
                    <div className="flex items-center gap-1.5 text-sm text-gray-500 mb-2">
                      <Trophy className="w-3.5 h-3.5" />
                      <span className="truncate">{exam.skillProgram.name}</span>
                    </div>
                  )}

                  {/* Info Row */}
                  <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600 mb-3">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-gray-400" />
                      {toPersianNumber(exam.durationMinutes)} دقیقه
                    </div>
                    <div className="flex items-center gap-1">
                      <ListChecks className="w-3.5 h-3.5 text-gray-400" />
                      {toPersianNumber(exam._count.questions)} سوال
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-gray-400" />
                      {toPersianNumber(exam._count.attempts)} شرکت
                    </div>
                  </div>

                  {/* Settings badges */}
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    <Badge variant="secondary" className="text-[10px] bg-gray-50 text-gray-600">
                      حداقل نمره: {toPersianNumber(exam.passingScore)}
                    </Badge>
                    <Badge variant="secondary" className="text-[10px] bg-gray-50 text-gray-600">
                      {toPersianNumber(exam.maxAttempts)} تلاش
                    </Badge>
                    <Badge variant="secondary" className="text-[10px] bg-gray-50 text-gray-600">
                      {SHOW_RESULTS_MAP[exam.showResults] || exam.showResults}
                    </Badge>
                  </div>

                  {/* Status */}
                  <div className="flex items-center justify-between mb-4">
                    <Badge
                      variant="secondary"
                      className={
                        exam.isActive
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px]'
                          : 'bg-red-50 text-red-700 border border-red-200 text-[11px]'
                      }
                    >
                      {exam.isActive ? 'فعال' : 'غیرفعال'}
                    </Badge>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => router.push(`/admin/exams/${exam.id}`)}
                      className="gap-1.5 text-teal-600 hover:text-teal-700 hover:bg-teal-50 flex-1"
                    >
                      <Eye className="h-3.5 w-3.5" />
                      مدیریت سوالات
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditModal(exam)}
                      className="gap-1.5 text-gray-600 hover:text-teal-700 hover:bg-teal-50"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteId(exam.id)}
                      className="gap-1.5 text-gray-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-center gap-1 pt-2">
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={() => goToPage(currentPage - 1)}
            disabled={currentPage <= 1}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          {getPageNumbers().map((page, index) =>
            page === '...' ? (
              <span key={`dots-${index}`} className="px-2 text-gray-400 text-sm">...</span>
            ) : (
              <Button
                key={page}
                variant={page === currentPage ? 'default' : 'outline'}
                size="icon"
                className={`h-9 w-9 ${page === currentPage ? 'bg-teal-600 hover:bg-teal-700 text-white' : ''}`}
                onClick={() => goToPage(page)}
              >
                {toPersianNumber(page)}
              </Button>
            )
          )}
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={() => goToPage(currentPage + 1)}
            disabled={currentPage >= totalPages}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Add/Edit Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingExam ? 'ویرایش آزمون' : 'ایجاد آزمون جدید'}
            </DialogTitle>
            <DialogDescription>
              {editingExam
                ? 'اطلاعات آزمون را ویرایش کنید'
                : 'اطلاعات آزمون جدید را وارد کنید'}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
            {/* Title */}
            <div className="sm:col-span-2">
              <Label htmlFor="title" className="text-sm font-medium text-gray-700">
                عنوان آزمون <span className="text-red-500">*</span>
              </Label>
              <Input
                id="title"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="مثلاً: آزمون پایان‌ترم برنامه‌نویسی وب"
                className="mt-1.5"
              />
            </div>

            {/* Description */}
            <div className="sm:col-span-2">
              <Label htmlFor="description" className="text-sm font-medium text-gray-700">
                توضیحات
              </Label>
              <Textarea
                id="description"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="توضیحات آزمون (اختیاری)..."
                className="mt-1.5 min-h-[60px]"
              />
            </div>

            {/* Type */}
            <div>
              <Label className="text-sm font-medium text-gray-700">نوع آزمون</Label>
              <Select
                value={form.type}
                onValueChange={(val) => setForm({ ...form, type: val })}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="QUIZ">آزمون کوتاه</SelectItem>
                  <SelectItem value="MIDTERM">میان‌ترم</SelectItem>
                  <SelectItem value="FINAL">پایان‌ترم</SelectItem>
                  <SelectItem value="DIAGNOSTIC">تشخیصی</SelectItem>
                  <SelectItem value="PRACTICAL">عملی</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Skill Program */}
            <div>
              <Label className="text-sm font-medium text-gray-700">دوره مهارتی</Label>
              <Select
                value={form.skillProgramId || 'none'}
                onValueChange={(val) =>
                  setForm({ ...form, skillProgramId: val === 'none' ? '' : val })
                }
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="بدون دوره" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون دوره (عمومی)</SelectItem>
                  {skillPrograms.map((sp) => (
                    <SelectItem key={sp.id} value={sp.id}>
                      {sp.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Duration */}
            <div>
              <Label htmlFor="durationMinutes" className="text-sm font-medium text-gray-700">
                مدت آزمون (دقیقه)
              </Label>
              <Input
                id="durationMinutes"
                type="number"
                min={1}
                value={form.durationMinutes}
                onChange={(e) => setForm({ ...form, durationMinutes: e.target.value })}
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Passing Score */}
            <div>
              <Label htmlFor="passingScore" className="text-sm font-medium text-gray-700">
                حداقل نمره قبولی
              </Label>
              <Input
                id="passingScore"
                type="number"
                min={0}
                step={0.5}
                value={form.passingScore}
                onChange={(e) => setForm({ ...form, passingScore: e.target.value })}
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Max Attempts */}
            <div>
              <Label htmlFor="maxAttempts" className="text-sm font-medium text-gray-700">
                حداکثر دفعات شرکت
              </Label>
              <Input
                id="maxAttempts"
                type="number"
                min={1}
                value={form.maxAttempts}
                onChange={(e) => setForm({ ...form, maxAttempts: e.target.value })}
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Show Results */}
            <div>
              <Label className="text-sm font-medium text-gray-700">نمایش نتایج</Label>
              <Select
                value={form.showResults}
                onValueChange={(val) => setForm({ ...form, showResults: val })}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AFTER_SUBMIT">بعد از ارسال</SelectItem>
                  <SelectItem value="AFTER_DEADLINE">بعد از مهلت</SelectItem>
                  <SelectItem value="NEVER">هرگز</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Shuffle Questions */}
            <div className="flex items-center gap-3 sm:col-span-2">
              <input
                type="checkbox"
                id="shuffleQuestions"
                checked={form.shuffleQuestions}
                onChange={(e) => setForm({ ...form, shuffleQuestions: e.target.checked })}
                className="w-4 h-4 rounded border-gray-300 text-teal-600 focus:ring-teal-500"
              />
              <Label htmlFor="shuffleQuestions" className="text-sm text-gray-700">
                ترتیب تصادفی سوالات (برای هر کارآموز متفاوت)
              </Label>
            </div>

            {/* isActive */}
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="isActive"
                checked={form.isActive}
                onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                className="w-4 h-4 rounded border-gray-300 text-teal-600 focus:ring-teal-500"
              />
              <Label htmlFor="isActive" className="text-sm text-gray-700">
                فعال
              </Label>
            </div>

            {/* Open At */}
            <div>
              <Label htmlFor="openAt" className="text-sm font-medium text-gray-700">
                زمان شروع آزمون
              </Label>
              <Input
                id="openAt"
                type="datetime-local"
                value={form.openAt}
                onChange={(e) => setForm({ ...form, openAt: e.target.value })}
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Close At */}
            <div>
              <Label htmlFor="closeAt" className="text-sm font-medium text-gray-700">
                زمان پایان آزمون
              </Label>
              <Input
                id="closeAt"
                type="datetime-local"
                value={form.closeAt}
                onChange={(e) => setForm({ ...form, closeAt: e.target.value })}
                className="mt-1.5"
                dir="ltr"
              />
            </div>
          </div>

          <DialogFooter className="gap-2 mt-2">
            <Button
              variant="outline"
              onClick={() => setModalOpen(false)}
              disabled={submitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editingExam ? 'ذخیره تغییرات' : 'ایجاد آزمون'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>غیرفعال‌سازی آزمون</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از غیرفعال‌سازی این آزمون اطمینان دارید؟ کارآموزان دیگر قادر به شرکت در آن نخواهند بود.
              آزمون‌های ارسال شده حفظ می‌شوند.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              غیرفعال‌سازی
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
