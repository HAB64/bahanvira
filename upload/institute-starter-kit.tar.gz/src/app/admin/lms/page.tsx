'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  BookOpen,
  Video,
  FileText,
  HelpCircle,
  Monitor,
  Plus,
  Pencil,
  Trash2,
  GripVertical,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  Star,
  Clock,
  Users,
  Loader2,
  GraduationCap,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface SkillProgramSummary {
  id: string;
  code: string | null;
  name: string;
  description: string | null;
  totalHours: number;
  cluster: string | null;
  level: string | null;
  instructorName: string | null;
  isActive: boolean;
  lessonCount: number;
  publishedLessonCount: number;
  totalDurationMinutes: number;
  enrollmentCount: number;
  createdAt: string;
  updatedAt: string;
}

interface LessonStats {
  totalEnrollments: number;
  completedCount: number;
  inProgressCount: number;
  averageCompletionPercent: number;
}

interface Lesson {
  id: string;
  skillProgramId: string;
  title: string;
  description: string | null;
  type: string;
  content: string | null;
  videoUrl: string | null;
  videoDuration: number | null;
  documentUrl: string | null;
  order: number;
  isPublished: boolean;
  isFree: boolean;
  estimatedMinutes: number;
  createdAt: string;
  updatedAt: string;
  stats: LessonStats;
}

interface ProgramStats {
  totalEnrollments: number;
  completedEnrollments: number;
  averageCompletionPercent: number;
  totalLessons: number;
  publishedLessons: number;
  totalDurationMinutes: number;
}

interface ProgramDetail {
  id: string;
  name: string;
  code: string | null;
  description: string | null;
  totalHours: number;
  isActive: boolean;
}

interface LessonFormData {
  title: string;
  description: string;
  type: string;
  content: string;
  videoUrl: string;
  videoDuration: string;
  documentUrl: string;
  estimatedMinutes: string;
  isPublished: boolean;
  isFree: boolean;
  order: string;
}

/* ─────────── Constants ─────────── */

const LESSON_TYPE_MAP: Record<string, { label: string; color: string; bg: string; icon: typeof Video }> = {
  VIDEO: { label: 'ویدیو', color: 'text-blue-700', bg: 'bg-blue-50 border-blue-200 text-blue-700', icon: Video },
  TEXT: { label: 'متن', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200 text-emerald-700', icon: FileText },
  QUIZ: { label: 'آزمون', color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200 text-amber-700', icon: HelpCircle },
  DOCUMENT: { label: 'فایل', color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200 text-purple-700', icon: FileText },
  LIVE_SESSION: { label: 'جلسه زنده', color: 'text-rose-700', bg: 'bg-rose-50 border-rose-200 text-rose-700', icon: Monitor },
};

const EMPTY_FORM: LessonFormData = {
  title: '',
  description: '',
  type: 'VIDEO',
  content: '',
  videoUrl: '',
  videoDuration: '',
  documentUrl: '',
  estimatedMinutes: '0',
  isPublished: false,
  isFree: false,
  order: '',
};

/* ─────────── Main Component ─────────── */

export default function LmsAdminPage() {
  /* ── State ── */
  const [programs, setPrograms] = useState<SkillProgramSummary[]>([]);
  const [programsLoading, setProgramsLoading] = useState(true);
  const [selectedProgramId, setSelectedProgramId] = useState<string>('');

  const [programDetail, setProgramDetail] = useState<ProgramDetail | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [programStats, setProgramStats] = useState<ProgramStats | null>(null);
  const [lessonsLoading, setLessonsLoading] = useState(false);

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);
  const [form, setForm] = useState<LessonFormData>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  // Delete
  const [deleteId, setDeleteId] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchPrograms = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/lms');
      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'خطا در دریافت لیست دوره‌ها');
        return;
      }

      setPrograms(data.data || []);
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setProgramsLoading(false);
    }
  }, []);

  const fetchLessons = useCallback(async () => {
    if (!selectedProgramId) {
      setLessons([]);
      setProgramDetail(null);
      setProgramStats(null);
      return;
    }

    setLessonsLoading(true);
    try {
      const res = await fetch(`/api/admin/lms/program/${selectedProgramId}`);
      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'خطا در دریافت لیست دروس');
        return;
      }

      setProgramDetail(data.data.program || null);
      setLessons(data.data.lessons || []);
      setProgramStats(data.data.programStats || null);
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLessonsLoading(false);
    }
  }, [selectedProgramId]);

  useEffect(() => {
    fetchPrograms();
  }, [fetchPrograms]);

  useEffect(() => {
    fetchLessons();
  }, [fetchLessons]);

  /* ── Computed stats ── */

  const totalLessons = programStats?.totalLessons ?? 0;
  const publishedLessons = programStats?.publishedLessons ?? 0;
  const totalEnrollments = programStats?.totalEnrollments ?? 0;
  const avgCompletion = programStats?.averageCompletionPercent ?? 0;

  /* ── Modal handlers ── */

  const openCreateModal = () => {
    setEditingLesson(null);
    setForm({
      ...EMPTY_FORM,
      order: lessons.length > 0 ? String(Math.max(...lessons.map((l) => l.order)) + 1) : '0',
    });
    setModalOpen(true);
  };

  const openEditModal = (lesson: Lesson) => {
    setEditingLesson(lesson);
    setForm({
      title: lesson.title,
      description: lesson.description || '',
      type: lesson.type,
      content: lesson.content || '',
      videoUrl: lesson.videoUrl || '',
      videoDuration: lesson.videoDuration != null ? String(lesson.videoDuration) : '',
      documentUrl: lesson.documentUrl || '',
      estimatedMinutes: String(lesson.estimatedMinutes),
      isPublished: lesson.isPublished,
      isFree: lesson.isFree,
      order: String(lesson.order),
    });
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    if (!form.title.trim()) {
      toast.error('عنوان درس الزامی است');
      return;
    }

    if (!selectedProgramId) {
      toast.error('لطفاً ابتدا یک دوره انتخاب کنید');
      return;
    }

    setSubmitting(true);

    try {
      const payload = {
        skillProgramId: selectedProgramId,
        title: form.title.trim(),
        description: form.description.trim() || null,
        type: form.type,
        content: form.type === 'TEXT' ? (form.content.trim() || null) : null,
        videoUrl: form.type === 'VIDEO' ? (form.videoUrl.trim() || null) : null,
        videoDuration: form.type === 'VIDEO' && form.videoDuration ? Number(form.videoDuration) : null,
        documentUrl: form.type === 'DOCUMENT' ? (form.documentUrl.trim() || null) : null,
        estimatedMinutes: form.estimatedMinutes ? Number(form.estimatedMinutes) : 0,
        isPublished: form.isPublished,
        isFree: form.isFree,
        order: form.order ? Number(form.order) : undefined,
      };

      let res: Response;

      if (editingLesson) {
        res = await fetch(`/api/admin/lms/${editingLesson.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch('/api/admin/lms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error || 'خطا در ذخیره‌سازی');
        return;
      }

      toast.success(editingLesson ? 'درس با موفقیت ویرایش شد' : 'درس جدید با موفقیت ایجاد شد');
      setModalOpen(false);
      fetchLessons();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setSubmitting(false);
    }
  };

  /* ── Delete handler ── */

  const handleDelete = async () => {
    if (!deleteId) return;

    try {
      const res = await fetch(`/api/admin/lms/${deleteId}`, { method: 'DELETE' });
      if (!res.ok) {
        const data = await res.json();
        toast.error(data.error || 'خطا در حذف درس');
        return;
      }
      toast.success('درس با موفقیت حذف شد');
      fetchLessons();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    }

    setDeleteId(null);
  };

  /* ── Reorder handlers ── */

  const handleMoveUp = async (index: number) => {
    if (index <= 0) return;

    const updatedLessons = [...lessons];
    const temp = updatedLessons[index].order;
    updatedLessons[index].order = updatedLessons[index - 1].order;
    updatedLessons[index - 1].order = temp;

    // Reorder in UI immediately
    const sorted = [...updatedLessons].sort((a, b) => a.order - b.order);
    setLessons(sorted);

    try {
      await fetch('/api/admin/lms/reorder', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lessons: sorted.map((l, i) => ({ id: l.id, order: i })),
        }),
      });
    } catch {
      toast.error('خطا در تغییر ترتیب');
      fetchLessons();
    }
  };

  const handleMoveDown = async (index: number) => {
    if (index >= lessons.length - 1) return;

    const updatedLessons = [...lessons];
    const temp = updatedLessons[index].order;
    updatedLessons[index].order = updatedLessons[index + 1].order;
    updatedLessons[index + 1].order = temp;

    // Reorder in UI immediately
    const sorted = [...updatedLessons].sort((a, b) => a.order - b.order);
    setLessons(sorted);

    try {
      await fetch('/api/admin/lms/reorder', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lessons: sorted.map((l, i) => ({ id: l.id, order: i })),
        }),
      });
    } catch {
      toast.error('خطا در تغییر ترتیب');
      fetchLessons();
    }
  };

  /* ── Helper: format video duration ── */

  const formatDuration = (seconds: number): string => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${toPersianNumber(m)}:${toPersianNumber(s.toString().padStart(2, '0'))}`;
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
            <BookOpen className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">مدیریت محتوای آموزشی (LMS)</h1>
            <p className="text-gray-500 mt-0.5 text-sm">
              مدیریت دروس و محتوای دوره‌های آموزشی
            </p>
          </div>
        </div>
        <Button
          onClick={openCreateModal}
          disabled={!selectedProgramId}
          className="bg-emerald-600 hover:bg-emerald-700 gap-2 text-white"
        >
          <Plus className="h-4 w-4" />
          افزودن درس جدید
        </Button>
      </div>

      {/* Program Selection */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
            <Label className="text-sm font-medium text-gray-700 shrink-0">انتخاب دوره مهارتی:</Label>
            <div className="w-full sm:w-80">
              <Select
                value={selectedProgramId}
                onValueChange={setSelectedProgramId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="یک دوره انتخاب کنید..." />
                </SelectTrigger>
                <SelectContent>
                  {programsLoading ? (
                    <SelectItem value="_loading" disabled>در حال بارگذاری...</SelectItem>
                  ) : programs.length === 0 ? (
                    <SelectItem value="_empty" disabled>دوره‌ای یافت نشد</SelectItem>
                  ) : (
                    programs.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.name} ({toPersianNumber(p.lessonCount)} درس)
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
            {selectedProgramId && programDetail && (
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Badge variant="secondary" className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200">
                  {toPersianNumber(programDetail.totalHours)} ساعت
                </Badge>
                {programDetail.code && (
                  <Badge variant="secondary" className="text-[10px] bg-gray-50 text-gray-600">
                    کد: {programDetail.code}
                  </Badge>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards — shown when a program is selected */}
      {selectedProgramId && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">کل دروس</p>
                  <p className="text-2xl font-bold mt-1 text-gray-900">
                    {lessonsLoading ? <Skeleton className="h-8 w-12 inline-block" /> : toPersianNumber(totalLessons)}
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                  <BookOpen className="w-5 h-5 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">منتشر شده</p>
                  <p className="text-2xl font-bold mt-1 text-teal-700">
                    {lessonsLoading ? <Skeleton className="h-8 w-12 inline-block" /> : toPersianNumber(publishedLessons)}
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                  <Eye className="w-5 h-5 text-teal-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">ثبت‌نام‌ها</p>
                  <p className="text-2xl font-bold mt-1 text-amber-700">
                    {lessonsLoading ? <Skeleton className="h-8 w-12 inline-block" /> : toPersianNumber(totalEnrollments)}
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200">
                  <Users className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">میانگین پیشرفت</p>
                  <p className="text-2xl font-bold mt-1 text-purple-700">
                    {lessonsLoading ? (
                      <Skeleton className="h-8 w-12 inline-block" />
                    ) : (
                      `${toPersianNumber(avgCompletion)}٪`
                    )}
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200">
                  <GraduationCap className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Lessons List */}
      {!selectedProgramId ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">دوره‌ای انتخاب نشده</p>
            <p className="text-gray-400 text-sm mt-1">
              برای مشاهده دروس، ابتدا یک دوره مهارتی انتخاب کنید
            </p>
          </CardContent>
        </Card>
      ) : lessonsLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-5 space-y-3">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-6 w-6 rounded" />
                  <Skeleton className="h-5 w-3/4" />
                </div>
                <div className="flex gap-2">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-6 w-20" />
                </div>
                <Skeleton className="h-4 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : lessons.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">درسی یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با افزودن درس جدید شروع کنید
            </p>
            <Button
              onClick={openCreateModal}
              className="mt-4 bg-emerald-600 hover:bg-emerald-700 gap-2 text-white"
            >
              <Plus className="h-4 w-4" />
              افزودن درس جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {lessons.map((lesson, index) => {
            const typeMeta = LESSON_TYPE_MAP[lesson.type] || LESSON_TYPE_MAP.VIDEO;
            const TypeIcon = typeMeta.icon;

            return (
              <Card
                key={lesson.id}
                className="bg-white rounded-xl shadow-sm border hover:shadow-md transition-shadow duration-200 group"
              >
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    {/* Reorder controls */}
                    <div className="flex flex-col items-center gap-0.5 shrink-0 pt-0.5">
                      <GripVertical className="w-4 h-4 text-gray-300 mb-1" />
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        disabled={index === 0}
                        onClick={() => handleMoveUp(index)}
                      >
                        <ArrowUp className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        disabled={index === lessons.length - 1}
                        onClick={() => handleMoveDown(index)}
                      >
                        <ArrowDown className="h-3.5 w-3.5" />
                      </Button>
                    </div>

                    {/* Lesson info */}
                    <div className="flex-1 min-w-0">
                      {/* Title row */}
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-xs font-bold text-gray-400 bg-gray-100 rounded-full w-6 h-6 flex items-center justify-center shrink-0">
                            {toPersianNumber(index + 1)}
                          </span>
                          <h3 className="font-bold text-gray-900 text-base leading-relaxed truncate">
                            {lesson.title}
                          </h3>
                        </div>
                        <Badge
                          variant="outline"
                          className={`shrink-0 text-[10px] font-medium ${typeMeta.bg}`}
                        >
                          <TypeIcon className="w-3 h-3 ml-1" />
                          {typeMeta.label}
                        </Badge>
                      </div>

                      {/* Description */}
                      {lesson.description && (
                        <p className="text-sm text-gray-500 mb-2 line-clamp-1">
                          {lesson.description}
                        </p>
                      )}

                      {/* Info Row */}
                      <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600 mb-2">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-gray-400" />
                          {toPersianNumber(lesson.estimatedMinutes)} دقیقه
                        </div>
                        {lesson.type === 'VIDEO' && lesson.videoDuration != null && (
                          <div className="flex items-center gap-1">
                            <Video className="w-3.5 h-3.5 text-gray-400" />
                            {formatDuration(lesson.videoDuration)}
                          </div>
                        )}
                        <div className="flex items-center gap-1">
                          <Users className="w-3.5 h-3.5 text-gray-400" />
                          {toPersianNumber(lesson.stats.totalEnrollments)} شرکت‌کننده
                        </div>
                        <div className="flex items-center gap-1">
                          <GraduationCap className="w-3.5 h-3.5 text-gray-400" />
                          {toPersianNumber(lesson.stats.averageCompletionPercent)}٪ تکمیل
                        </div>
                      </div>

                      {/* Status badges */}
                      <div className="flex flex-wrap gap-1.5">
                        {lesson.isPublished ? (
                          <Badge variant="secondary" className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <Eye className="w-3 h-3 ml-0.5" />
                            منتشر شده
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-[10px] bg-gray-50 text-gray-500 border border-gray-200">
                            <EyeOff className="w-3 h-3 ml-0.5" />
                            پیش‌نویس
                          </Badge>
                        )}
                        {lesson.isFree && (
                          <Badge variant="secondary" className="text-[10px] bg-amber-50 text-amber-700 border border-amber-200">
                            <Star className="w-3 h-3 ml-0.5" />
                            پیش‌نمایش رایگان
                          </Badge>
                        )}
                        {lesson.stats.completedCount > 0 && (
                          <Badge variant="secondary" className="text-[10px] bg-teal-50 text-teal-700 border border-teal-200">
                            {toPersianNumber(lesson.stats.completedCount)} تکمیل شده
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEditModal(lesson)}
                        className="gap-1.5 text-gray-600 hover:text-emerald-700 hover:bg-emerald-50"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setDeleteId(lesson.id)}
                        className="gap-1.5 text-gray-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add/Edit Lesson Dialog */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingLesson ? 'ویرایش درس' : 'افزودن درس جدید'}
            </DialogTitle>
            <DialogDescription>
              {editingLesson
                ? 'اطلاعات درس را ویرایش کنید'
                : 'اطلاعات درس جدید را وارد کنید'}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
            {/* Title */}
            <div className="sm:col-span-2">
              <Label htmlFor="lesson-title" className="text-sm font-medium text-gray-700">
                عنوان درس <span className="text-red-500">*</span>
              </Label>
              <Input
                id="lesson-title"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="مثلاً: مقدمه‌ای بر برنامه‌نویسی"
                className="mt-1.5"
              />
            </div>

            {/* Description */}
            <div className="sm:col-span-2">
              <Label htmlFor="lesson-description" className="text-sm font-medium text-gray-700">
                توضیحات
              </Label>
              <Textarea
                id="lesson-description"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="توضیحات درس (اختیاری)..."
                className="mt-1.5 min-h-[60px]"
              />
            </div>

            {/* Type */}
            <div>
              <Label className="text-sm font-medium text-gray-700">نوع درس</Label>
              <Select
                value={form.type}
                onValueChange={(val) => setForm({ ...form, type: val })}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="VIDEO">ویدیو</SelectItem>
                  <SelectItem value="TEXT">متن</SelectItem>
                  <SelectItem value="QUIZ">آزمون</SelectItem>
                  <SelectItem value="DOCUMENT">فایل</SelectItem>
                  <SelectItem value="LIVE_SESSION">جلسه زنده</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Estimated Minutes */}
            <div>
              <Label htmlFor="lesson-estimatedMinutes" className="text-sm font-medium text-gray-700">
                مدت تخمینی (دقیقه)
              </Label>
              <Input
                id="lesson-estimatedMinutes"
                type="number"
                min={0}
                value={form.estimatedMinutes}
                onChange={(e) => setForm({ ...form, estimatedMinutes: e.target.value })}
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Content — shown when type=TEXT */}
            {form.type === 'TEXT' && (
              <div className="sm:col-span-2">
                <Label htmlFor="lesson-content" className="text-sm font-medium text-gray-700">
                  محتوای متنی
                </Label>
                <Textarea
                  id="lesson-content"
                  value={form.content}
                  onChange={(e) => setForm({ ...form, content: e.target.value })}
                  placeholder="محتوای درس را وارد کنید (پشتیبانی از Markdown)..."
                  className="mt-1.5 min-h-[120px]"
                />
              </div>
            )}

            {/* Video URL — shown when type=VIDEO */}
            {form.type === 'VIDEO' && (
              <div className="sm:col-span-2">
                <Label htmlFor="lesson-videoUrl" className="text-sm font-medium text-gray-700">
                  آدرس ویدیو
                </Label>
                <Input
                  id="lesson-videoUrl"
                  value={form.videoUrl}
                  onChange={(e) => setForm({ ...form, videoUrl: e.target.value })}
                  placeholder="https://..."
                  className="mt-1.5"
                  dir="ltr"
                />
              </div>
            )}

            {/* Video Duration — shown when type=VIDEO */}
            {form.type === 'VIDEO' && (
              <div>
                <Label htmlFor="lesson-videoDuration" className="text-sm font-medium text-gray-700">
                  مدت ویدیو (ثانیه)
                </Label>
                <Input
                  id="lesson-videoDuration"
                  type="number"
                  min={0}
                  value={form.videoDuration}
                  onChange={(e) => setForm({ ...form, videoDuration: e.target.value })}
                  className="mt-1.5"
                  dir="ltr"
                />
              </div>
            )}

            {/* Document URL — shown when type=DOCUMENT */}
            {form.type === 'DOCUMENT' && (
              <div className="sm:col-span-2">
                <Label htmlFor="lesson-documentUrl" className="text-sm font-medium text-gray-700">
                  آدرس فایل
                </Label>
                <Input
                  id="lesson-documentUrl"
                  value={form.documentUrl}
                  onChange={(e) => setForm({ ...form, documentUrl: e.target.value })}
                  placeholder="https://..."
                  className="mt-1.5"
                  dir="ltr"
                />
              </div>
            )}

            {/* Order */}
            <div>
              <Label htmlFor="lesson-order" className="text-sm font-medium text-gray-700">
                ترتیب نمایش
              </Label>
              <Input
                id="lesson-order"
                type="number"
                min={0}
                value={form.order}
                onChange={(e) => setForm({ ...form, order: e.target.value })}
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* isPublished */}
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="lesson-isPublished"
                checked={form.isPublished}
                onChange={(e) => setForm({ ...form, isPublished: e.target.checked })}
                className="w-4 h-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
              />
              <Label htmlFor="lesson-isPublished" className="text-sm text-gray-700">
                منتشر شده
              </Label>
            </div>

            {/* isFree */}
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="lesson-isFree"
                checked={form.isFree}
                onChange={(e) => setForm({ ...form, isFree: e.target.checked })}
                className="w-4 h-4 rounded border-gray-300 text-amber-600 focus:ring-amber-500"
              />
              <Label htmlFor="lesson-isFree" className="text-sm text-gray-700">
                پیش‌نمایش رایگان
              </Label>
            </div>
          </div>

          <DialogFooter className="gap-2 mt-2">
            <Button
              variant="outline"
              onClick={() => setModalOpen(false)}
              disabled={submitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editingLesson ? 'ذخیره تغییرات' : 'ایجاد درس'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف درس</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف این درس اطمینان دارید؟ تمام اطلاعات و پیشرفت کارآموزان مربوط به این درس حذف خواهد شد. این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
