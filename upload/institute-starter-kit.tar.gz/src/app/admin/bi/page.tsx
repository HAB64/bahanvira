'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Users,
  GraduationCap,
  RefreshCw,
  ArrowUpRight,
  ArrowDownRight,
  BookOpen,
  Clock,
  AlertTriangle,
  Target,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { toPersianNumber, formatPrice } from '@/lib/persian';

/* ═══════════════════════════════════════════════════════
   Types — matching the /api/admin/bi response
   ═══════════════════════════════════════════════════════ */

interface OverviewData {
  totalLeads: number;
  totalEnrollments: number;
  totalRevenue: number;
  totalKarAmuz: number;
  activePrograms: number;
  leadsGrowth: number;
  enrollmentGrowth: number;
  revenueGrowth: number;
}

interface MonthlyRevenue {
  month: string;
  amount: number;
  count: number;
}

interface ClusterRevenue {
  cluster: string;
  amount: number;
  count: number;
}

interface PaymentTypeRevenue {
  type: string;
  amount: number;
}

interface RevenueData {
  monthly: MonthlyRevenue[];
  byCluster: ClusterRevenue[];
  byPaymentType: PaymentTypeRevenue[];
  outstanding: number;
  collectionRate: number;
}

interface ProgramEnrollment {
  programName: string;
  count: number;
  activeCount: number;
  completedCount: number;
}

interface ClusterEnrollment {
  cluster: string;
  count: number;
}

interface MonthlyEnrollment {
  month: string;
  count: number;
}

interface EnrollmentData {
  byProgram: ProgramEnrollment[];
  byCluster: ClusterEnrollment[];
  byMonth: MonthlyEnrollment[];
  dropoutRate: number;
  completionRate: number;
}

interface LmsProgram {
  programName: string;
  totalLessons: number;
  avgProgress: number;
  enrolledCount: number;
}

interface PopularLesson {
  title: string;
  type: string;
  completionRate: number;
}

interface LmsData {
  totalLessons: number;
  publishedLessons: number;
  avgCompletionPercent: number;
  byProgram: LmsProgram[];
  popularLessons: PopularLesson[];
  avgTimeSpent: number;
}

interface LeadStage {
  stage: string;
  count: number;
}

interface LeadSource {
  source: string;
  count: number;
}

interface TopConsultant {
  name: string;
  leads: number;
  conversions: number;
}

interface CrmData {
  leadsByStage: LeadStage[];
  leadsBySource: LeadSource[];
  avgTimeToEnroll: number;
  conversionRate: number;
  topConsultants: TopConsultant[];
}

interface AttendanceProgram {
  programName: string;
  rate: number;
}

interface AttendanceTrend {
  month: string;
  rate: number;
}

interface AttendanceData {
  overallRate: number;
  byProgram: AttendanceProgram[];
  trend: AttendanceTrend[];
}

interface BIData {
  overview: OverviewData;
  revenue: RevenueData;
  enrollments: EnrollmentData;
  lms: LmsData;
  crm: CrmData;
  attendance: AttendanceData;
}

/* ═══════════════════════════════════════════════════════
   Constants
   ═══════════════════════════════════════════════════════ */

const FUNNEL_LABELS: Record<string, string> = {
  NEW: 'لید جدید',
  CONTACTED: 'تماس گرفته شده',
  INTERESTED: 'علاقه‌مند',
  ENROLLED: 'ثبت‌نام شده',
  QUALIFIED: 'واجد شرایط',
  NEGOTIATION: 'در مذاکره',
  LOST: 'از دست رفته',
};

const FUNNEL_COLORS: Record<string, { bg: string; text: string; bar: string }> = {
  NEW: { bg: 'bg-blue-50', text: 'text-blue-700', bar: 'bg-gradient-to-l from-blue-500 to-blue-400' },
  CONTACTED: { bg: 'bg-sky-50', text: 'text-sky-700', bar: 'bg-gradient-to-l from-sky-500 to-sky-400' },
  INTERESTED: { bg: 'bg-teal-50', text: 'text-teal-700', bar: 'bg-gradient-to-l from-teal-500 to-teal-400' },
  QUALIFIED: { bg: 'bg-cyan-50', text: 'text-cyan-700', bar: 'bg-gradient-to-l from-cyan-500 to-cyan-400' },
  NEGOTIATION: { bg: 'bg-amber-50', text: 'text-amber-700', bar: 'bg-gradient-to-l from-amber-500 to-amber-400' },
  ENROLLED: { bg: 'bg-emerald-50', text: 'text-emerald-700', bar: 'bg-gradient-to-l from-emerald-500 to-emerald-400' },
  LOST: { bg: 'bg-red-50', text: 'text-red-700', bar: 'bg-gradient-to-l from-red-500 to-red-400' },
};

const CLUSTER_COLORS: Record<string, string> = {
  'فناوری': '#0d9488',
  'مالی': '#6366f1',
  'مدیریت': '#f59e0b',
  'کارآفرینی': '#ef4444',
  'هنر': '#ec4899',
  'پوشاک': '#8b5cf6',
  'بازار سرمایه': '#14b8a6',
  'خدمات آموزشی': '#3b82f6',
  'خدمات حقوقی': '#64748b',
};

const PAYMENT_TYPE_LABELS: Record<string, string> = {
  TUITION: 'شهریه',
  REGISTRATION: 'ثبت‌نام',
  EXAM: 'آزمون',
  CERTIFICATE: 'گواهینامه',
  OTHER: 'سایر',
  INSTALLMENT: 'اقساط',
};

/* ═══════════════════════════════════════════════════════
   Helper: format rials for full display
   ═══════════════════════════════════════════════════════ */

function formatRials(amount: number): string {
  const formatted = Math.round(amount).toLocaleString('en-US');
  return toPersianNumber(formatted) + ' ریال';
}

/* ═══════════════════════════════════════════════════════
   Main Component
   ═══════════════════════════════════════════════════════ */

export default function BIDashboard() {
  const [data, setData] = useState<BIData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/admin/bi');
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || 'خطا در دریافت داده‌ها');
        return;
      }
      setData(json as BIData);
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  /* ──── Loading skeleton ──── */
  if (loading) {
    return (
      <div className="space-y-6" dir="rtl">
        {/* Header skeleton */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Skeleton className="h-12 w-12 rounded-xl" />
            <div className="space-y-2">
              <Skeleton className="h-7 w-52" />
              <Skeleton className="h-4 w-60" />
            </div>
          </div>
          <Skeleton className="h-9 w-28 rounded-lg" />
        </div>
        {/* KPI cards skeleton */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        {/* Charts skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
        {/* Tables skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
        {/* Bottom row skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </div>
    );
  }

  /* ──── Error state ──── */
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20" dir="rtl">
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center max-w-md">
          <AlertTriangle className="w-10 h-10 text-red-400 mx-auto mb-3" />
          <p className="text-red-600 font-medium mb-2">{error}</p>
          <button
            onClick={fetchData}
            className="mt-3 inline-flex items-center gap-2 text-sm text-teal-600 hover:text-teal-700 font-medium"
          >
            <RefreshCw className="w-4 h-4" />
            تلاش مجدد
          </button>
        </div>
      </div>
    );
  }

  if (!data) return null;

  /* ──── Computed values ──── */

  // Donut chart conic-gradient for enrollment by cluster
  const clusterTotal = data.enrollments.byCluster.reduce((s, seg) => s + seg.count, 0);
  let cumulativePct = 0;
  const conicSegments = data.enrollments.byCluster
    .filter((seg) => seg.count > 0)
    .map((seg) => {
      const pct = (seg.count / clusterTotal) * 100;
      const color = CLUSTER_COLORS[seg.cluster] || '#9ca3af';
      const startPct = cumulativePct;
      cumulativePct += pct;
      return `${color} ${startPct}% ${cumulativePct}%`;
    });
  const conicGradient = `conic-gradient(${conicSegments.join(', ')})`;

  // Funnel stages (only show standard 4)
  const funnelStages = ['NEW', 'CONTACTED', 'INTERESTED', 'ENROLLED'];
  const funnelData = funnelStages.map((stage) => {
    const found = data.crm.leadsByStage.find((s) => s.stage === stage);
    return {
      stage,
      count: found?.count || 0,
    };
  });
  const funnelMax = Math.max(...funnelData.map((s) => s.count), 1);
  const funnelTotal = funnelData.reduce((s, f) => s + f.count, 0);

  // Revenue bar chart max
  const revenueMax = Math.max(...data.revenue.monthly.map((m) => m.amount), 1);

  // Attendance trend for line chart
  const attendanceMin = data.attendance.trend.length > 0
    ? Math.min(...data.attendance.trend.map((m) => m.rate))
    : 0;
  const attendanceMax = data.attendance.trend.length > 0
    ? Math.max(...data.attendance.trend.map((m) => m.rate))
    : 100;

  // Revenue by program (from enrollment data + revenue by cluster)
  const revenueByProgram = data.enrollments.byProgram
    .slice()
    .sort((a, b) => b.count - a.count)
    .slice(0, 8)
    .map((p) => ({
      name: p.programName,
      enrollments: p.count,
      revenue: Math.round((p.count / Math.max(data.overview.totalEnrollments, 1)) * data.overview.totalRevenue),
      completionRate: p.count > 0 ? Math.round((p.completedCount / p.count) * 100) : 0,
    }));

  // Top courses from LMS data
  const topCourses = data.lms.byProgram
    .slice()
    .sort((a, b) => b.enrolledCount - a.enrolledCount)
    .slice(0, 8)
    .map((p) => ({
      name: p.programName,
      activeEnrollments: p.enrolledCount,
      avgProgress: p.avgProgress,
      attendanceRate: data.attendance.byProgram.find((a) => a.programName === p.programName)?.rate || 0,
    }));

  return (
    <div className="space-y-6" dir="rtl">
      {/* ═══════════ Header ═══════════ */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-bl from-teal-500 to-teal-600 shadow-lg shadow-teal-200">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">هوش تجاری و تحلیل</h1>
            <p className="text-gray-500 mt-0.5 text-sm">نمای جامع از عملکرد آموزشگاه</p>
          </div>
        </div>
        <button
          onClick={fetchData}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-teal-700 bg-teal-50 hover:bg-teal-100 border border-teal-200 rounded-lg transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          بروزرسانی
        </button>
      </div>

      {/* ═══════════ Overview Stats Row (5 cards) ═══════════ */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* 1. Total Leads */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-blue-500 to-blue-600 p-5 text-white shadow-lg shadow-blue-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">کل لیدها</p>
              <p className="text-3xl font-bold mt-2">{toPersianNumber(data.overview.totalLeads)}</p>
              <div className="flex items-center gap-1 mt-1">
                {data.overview.leadsGrowth >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5 text-blue-200" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5 text-red-300" />
                )}
                <span className={`text-xs ${data.overview.leadsGrowth >= 0 ? 'text-blue-200' : 'text-red-300'}`}>
                  {toPersianNumber(Math.abs(data.overview.leadsGrowth))}٪
                </span>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <Users className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 2. Enrollments */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-emerald-500 to-emerald-600 p-5 text-white shadow-lg shadow-emerald-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-emerald-100 text-sm font-medium">ثبت‌نام‌ها</p>
              <p className="text-3xl font-bold mt-2">{toPersianNumber(data.overview.totalEnrollments)}</p>
              <div className="flex items-center gap-1 mt-1">
                {data.overview.enrollmentGrowth >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5 text-emerald-200" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5 text-red-300" />
                )}
                <span className={`text-xs ${data.overview.enrollmentGrowth >= 0 ? 'text-emerald-200' : 'text-red-300'}`}>
                  {toPersianNumber(Math.abs(data.overview.enrollmentGrowth))}٪
                </span>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <GraduationCap className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 3. Total Revenue */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-amber-500 to-amber-600 p-5 text-white shadow-lg shadow-amber-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-amber-100 text-sm font-medium">درآمد کل</p>
              <p className="text-xl font-bold mt-2">{formatPrice(data.overview.totalRevenue)}</p>
              <div className="flex items-center gap-1 mt-1">
                {data.overview.revenueGrowth >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5 text-amber-200" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5 text-red-300" />
                )}
                <span className={`text-xs ${data.overview.revenueGrowth >= 0 ? 'text-amber-200' : 'text-red-300'}`}>
                  {toPersianNumber(Math.abs(data.overview.revenueGrowth))}٪
                </span>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <DollarSign className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 4. Active Students */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-violet-500 to-violet-600 p-5 text-white shadow-lg shadow-violet-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-violet-100 text-sm font-medium">کارآموزان فعال</p>
              <p className="text-3xl font-bold mt-2">{toPersianNumber(data.overview.totalKarAmuz)}</p>
              <p className="text-violet-200 text-xs mt-1">کارآموز ثبت‌شده</p>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <BookOpen className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 5. Active Programs */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-teal-500 to-teal-600 p-5 text-white shadow-lg shadow-teal-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-teal-100 text-sm font-medium">دوره‌های فعال</p>
              <p className="text-3xl font-bold mt-2">{toPersianNumber(data.overview.activePrograms)}</p>
              <p className="text-teal-200 text-xs mt-1">برنامه مهارتی فعال</p>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <Target className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* ═══════════ Charts Section (2x2 grid) ═══════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* ── Top-left: Revenue Chart (Bar) ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <DollarSign className="w-5 h-5 text-emerald-600" />
              درآمد ماهانه
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex items-end gap-2 h-56">
              {data.revenue.monthly.map((m, idx) => {
                const heightPct = (m.amount / revenueMax) * 100;
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 group relative">
                    {/* Tooltip */}
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                      {formatRials(m.amount)}
                    </div>
                    {/* Bar */}
                    <div
                      className="w-full rounded-t-md bg-gradient-to-t from-emerald-500 to-emerald-400 transition-all duration-500 min-h-[4px] relative group-hover:from-emerald-600 group-hover:to-emerald-500"
                      style={{ height: `${Math.max(heightPct, 2)}%` }}
                    />
                    {/* Month label */}
                    <span className="text-[10px] text-gray-500 font-medium leading-tight text-center">
                      {m.month}
                    </span>
                  </div>
                );
              })}
            </div>
            <Separator className="my-3" />
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>مجموع ۶ ماه اخیر</span>
              <span className="font-bold text-gray-800">
                {formatPrice(data.revenue.monthly.reduce((s, m) => s + m.amount, 0))}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* ── Top-right: Enrollment by Cluster (Donut) ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <GraduationCap className="w-5 h-5 text-violet-600" />
              ثبت‌نام بر اساس خوشه
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex items-center gap-6">
              {/* Donut chart */}
              <div className="relative flex-shrink-0">
                <div
                  className="w-40 h-40 rounded-full"
                  style={{ background: conicGradient || '#e5e7eb' }}
                />
                {/* Center hole */}
                <div className="absolute inset-4 rounded-full bg-white flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-lg font-bold text-gray-900">{toPersianNumber(clusterTotal)}</p>
                    <p className="text-[10px] text-gray-500">کل ثبت‌نام</p>
                  </div>
                </div>
              </div>
              {/* Legend */}
              <div className="flex-1 space-y-2 max-h-40 overflow-y-auto">
                {data.enrollments.byCluster.map((seg, idx) => {
                  const pct = clusterTotal > 0 ? Math.round((seg.count / clusterTotal) * 100) : 0;
                  const color = CLUSTER_COLORS[seg.cluster] || '#9ca3af';
                  return (
                    <div key={idx} className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <div
                          className="w-3 h-3 rounded-full flex-shrink-0"
                          style={{ backgroundColor: color }}
                        />
                        <span className="text-sm text-gray-700 truncate">{seg.cluster}</span>
                      </div>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <span className="text-sm font-bold text-gray-900">{toPersianNumber(seg.count)}</span>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {toPersianNumber(pct)}٪
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ── Bottom-left: CRM Funnel ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <Target className="w-5 h-5 text-teal-600" />
              قیف CRM
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              {funnelData.map((stage, idx) => {
                const meta = FUNNEL_COLORS[stage.stage] || FUNNEL_COLORS.NEW;
                const widthPct = Math.max((stage.count / funnelMax) * 100, 8);
                const pct = funnelTotal > 0 ? Math.round((stage.count / funnelTotal) * 100) : 0;
                return (
                  <div key={stage.stage}>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span
                          className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${meta.bg} ${meta.text}`}
                        >
                          {toPersianNumber(idx + 1)}
                        </span>
                        <span className="text-sm font-medium text-gray-800">
                          {FUNNEL_LABELS[stage.stage] || stage.stage}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-bold text-gray-900">{toPersianNumber(stage.count)}</span>
                        <span className="text-gray-400">|</span>
                        <span className={`${meta.text} font-medium`}>
                          {toPersianNumber(pct)}٪
                        </span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-8 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${meta.bar} transition-all duration-700 ease-out flex items-center justify-end px-3`}
                        style={{ width: `${widthPct}%` }}
                      >
                        {widthPct > 20 && (
                          <span className="text-white text-xs font-bold drop-shadow">
                            {toPersianNumber(stage.count)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
              {/* Overall conversion rate */}
              <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
                <span className="text-sm text-gray-500">نرخ تبدیل کلی</span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-sm font-bold">
                  <TrendingUp className="w-3.5 h-3.5" />
                  {toPersianNumber(data.crm.conversionRate)}٪
                </span>
              </div>
              {/* Average time to enroll */}
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">میانگین زمان ثبت‌نام</span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-700 text-sm font-bold">
                  <Clock className="w-3.5 h-3.5" />
                  {toPersianNumber(data.crm.avgTimeToEnroll)} روز
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ── Bottom-right: LMS Progress ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <BookOpen className="w-5 h-5 text-blue-600" />
              پیشرفت LMS
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {/* Summary */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="bg-blue-50 rounded-lg p-2 text-center">
                <p className="text-xs text-blue-600 font-medium">کل دروس</p>
                <p className="text-lg font-bold text-blue-800">{toPersianNumber(data.lms.totalLessons)}</p>
              </div>
              <div className="bg-emerald-50 rounded-lg p-2 text-center">
                <p className="text-xs text-emerald-600 font-medium">انتشار یافته</p>
                <p className="text-lg font-bold text-emerald-800">{toPersianNumber(data.lms.publishedLessons)}</p>
              </div>
              <div className="bg-amber-50 rounded-lg p-2 text-center">
                <p className="text-xs text-amber-600 font-medium">میانگین پیشرفت</p>
                <p className="text-lg font-bold text-amber-800">{toPersianNumber(data.lms.avgCompletionPercent)}٪</p>
              </div>
            </div>
            {/* Program progress bars */}
            <div className="space-y-3 max-h-48 overflow-y-auto">
              {data.lms.byProgram
                .slice()
                .sort((a, b) => b.avgProgress - a.avgProgress)
                .slice(0, 6)
                .map((p, idx) => (
                  <div key={idx}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-gray-700 truncate max-w-[60%]">{p.programName}</span>
                      <div className="flex items-center gap-2 text-xs text-gray-500 flex-shrink-0">
                        <span>{toPersianNumber(p.enrolledCount)} نفر</span>
                        <span className="font-bold text-gray-800">{toPersianNumber(p.avgProgress)}٪</span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2.5 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-l from-blue-500 to-blue-400 transition-all duration-700"
                        style={{ width: `${Math.max(p.avgProgress, 2)}%` }}
                      />
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ═══════════ Detailed Tables Section ═══════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* ── Revenue by Program ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <DollarSign className="w-5 h-5 text-emerald-600" />
              درآمد بر اساس دوره
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right text-xs">نام دوره</TableHead>
                  <TableHead className="text-right text-xs">تعداد ثبت‌نام</TableHead>
                  <TableHead className="text-right text-xs">درآمد</TableHead>
                  <TableHead className="text-right text-xs">نرخ تکمیل</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {revenueByProgram.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-gray-400 py-8">
                      داده‌ای موجود نیست
                    </TableCell>
                  </TableRow>
                ) : (
                  revenueByProgram.map((row, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="text-sm font-medium text-gray-800 max-w-[160px] truncate">
                        {row.name}
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {toPersianNumber(row.enrollments)}
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {formatPrice(row.revenue)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={row.completionRate >= 70 ? 'secondary' : 'outline'}
                          className={`text-xs ${
                            row.completionRate >= 70
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : row.completionRate >= 40
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-red-50 text-red-700 border-red-200'
                          }`}
                        >
                          {toPersianNumber(row.completionRate)}٪
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* ── Top Courses ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <GraduationCap className="w-5 h-5 text-violet-600" />
              برترین دوره‌ها
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right text-xs">نام دوره</TableHead>
                  <TableHead className="text-right text-xs">ثبت‌نام فعال</TableHead>
                  <TableHead className="text-right text-xs">پیشرفت میانگین</TableHead>
                  <TableHead className="text-right text-xs">نرخ حضور</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topCourses.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center text-gray-400 py-8">
                      داده‌ای موجود نیست
                    </TableCell>
                  </TableRow>
                ) : (
                  topCourses.map((row, idx) => (
                    <TableRow key={idx}>
                      <TableCell className="text-sm font-medium text-gray-800 max-w-[160px] truncate">
                        {row.name}
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {toPersianNumber(row.activeEnrollments)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="h-full rounded-full bg-gradient-to-l from-violet-500 to-violet-400"
                              style={{ width: `${Math.max(row.avgProgress, 2)}%` }}
                            />
                          </div>
                          <span className="text-xs font-bold text-gray-700">{toPersianNumber(row.avgProgress)}٪</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={row.attendanceRate >= 80 ? 'secondary' : 'outline'}
                          className={`text-xs ${
                            row.attendanceRate >= 80
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : row.attendanceRate >= 50
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-red-50 text-red-700 border-red-200'
                          }`}
                        >
                          {toPersianNumber(row.attendanceRate)}٪
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* ═══════════ Bottom Row ═══════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* ── Attendance Trend (CSS Line Chart) ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <Clock className="w-5 h-5 text-teal-600" />
              روند حضور
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {data.attendance.trend.length === 0 ? (
              <div className="flex items-center justify-center h-48 text-gray-400 text-sm">
                داده‌ای موجود نیست
              </div>
            ) : (
              <>
                {/* CSS-based line chart using SVG */}
                <div className="relative h-48">
                  {/* Grid lines */}
                  <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                    {[0, 25, 50, 75, 100].map((val) => (
                      <div key={val} className="flex items-center gap-2">
                        <span className="text-[10px] text-gray-400 w-8 text-left flex-shrink-0">
                          {toPersianNumber(val)}٪
                        </span>
                        <div className="flex-1 border-t border-dashed border-gray-100" />
                      </div>
                    ))}
                  </div>
                  {/* Chart area */}
                  <div className="absolute inset-0 mr-10">
                    <svg
                      viewBox={`0 0 ${data.attendance.trend.length * 100 - 20} 100`}
                      className="w-full h-full"
                      preserveAspectRatio="none"
                    >
                      {/* Area fill */}
                      <defs>
                        <linearGradient id="attendanceGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                          <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.3" />
                          <stop offset="100%" stopColor="#14b8a6" stopOpacity="0.02" />
                        </linearGradient>
                      </defs>
                      {(() => {
                        const range = Math.max(attendanceMax - attendanceMin, 10);
                        const points = data.attendance.trend.map((m, i) => {
                          const x = i * 80 + 40;
                          const y = 100 - ((m.rate - attendanceMin) / range) * 80 - 10;
                          return { x, y, ...m };
                        });
                        const linePath = points
                          .map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`)
                          .join(' ');
                        const areaPath = linePath + ` L ${points[points.length - 1].x} 100 L ${points[0].x} 100 Z`;
                        return (
                          <>
                            <path d={areaPath} fill="url(#attendanceGrad)" />
                            <path
                              d={linePath}
                              fill="none"
                              stroke="#14b8a6"
                              strokeWidth="3"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                            {points.map((p, i) => (
                              <g key={i}>
                                <circle cx={p.x} cy={p.y} r="5" fill="white" stroke="#14b8a6" strokeWidth="2.5" />
                                <text
                                  x={p.x}
                                  y={p.y - 12}
                                  textAnchor="middle"
                                  className="text-[10px] fill-gray-600 font-bold"
                                >
                                  {p.rate}٪
                                </text>
                              </g>
                            ))}
                          </>
                        );
                      })()}
                    </svg>
                  </div>
                </div>
                {/* Month labels */}
                <div className="flex justify-around mt-2 mr-10">
                  {data.attendance.trend.map((m, idx) => (
                    <span key={idx} className="text-[10px] text-gray-500 font-medium">
                      {m.month}
                    </span>
                  ))}
                </div>
                {/* Overall rate badge */}
                <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between">
                  <span className="text-sm text-gray-500">نرخ حضور کلی</span>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-sm font-bold">
                    <TrendingUp className="w-3.5 h-3.5" />
                    {toPersianNumber(data.attendance.overallRate)}٪
                  </span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* ── Outstanding Payments (Alert Card) ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
              مطالبات معوق
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {/* Total outstanding */}
            <div className="bg-gradient-to-bl from-amber-50 to-orange-50 border border-amber-200 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-amber-700 font-medium">مجموع مطالبات</span>
                <span className="text-xl font-bold text-amber-900">
                  {formatPrice(data.revenue.outstanding)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-amber-700 font-medium">نرخ وصول</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 bg-amber-200 rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-l from-emerald-500 to-emerald-400 transition-all duration-700"
                      style={{ width: `${Math.max(data.revenue.collectionRate, 2)}%` }}
                    />
                  </div>
                  <span className="text-sm font-bold text-gray-800">
                    {toPersianNumber(data.revenue.collectionRate)}٪
                  </span>
                </div>
              </div>
            </div>

            {/* Payment type breakdown */}
            <div>
              <p className="text-xs font-bold text-gray-500 mb-2">تفکیک نوع پرداخت</p>
              <div className="space-y-2 max-h-36 overflow-y-auto">
                {data.revenue.byPaymentType.length === 0 ? (
                  <p className="text-sm text-gray-400 text-center py-4">داده‌ای موجود نیست</p>
                ) : (
                  data.revenue.byPaymentType.map((pt, idx) => {
                    const totalPaid = data.revenue.byPaymentType.reduce((s, p) => s + p.amount, 0);
                    const pct = totalPaid > 0 ? Math.round((pt.amount / totalPaid) * 100) : 0;
                    const label = PAYMENT_TYPE_LABELS[pt.type] || pt.type;
                    const colors = [
                      'from-teal-500 to-teal-400',
                      'from-blue-500 to-blue-400',
                      'from-violet-500 to-violet-400',
                      'from-amber-500 to-amber-400',
                      'from-rose-500 to-rose-400',
                      'from-emerald-500 to-emerald-400',
                    ];
                    const colorClass = colors[idx % colors.length];
                    return (
                      <div key={idx}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-gray-700">{label}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-gray-900">{formatPrice(pt.amount)}</span>
                            <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                              {toPersianNumber(pct)}٪
                            </Badge>
                          </div>
                        </div>
                        <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                          <div
                            className={`h-full rounded-full bg-gradient-to-l ${colorClass}`}
                            style={{ width: `${Math.max(pct, 2)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
