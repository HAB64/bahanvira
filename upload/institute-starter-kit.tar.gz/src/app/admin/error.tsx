'use client';

export default function AdminError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div style={{
      minHeight: '50vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '2rem',
      direction: 'rtl',
    }}>
      <div style={{
        maxWidth: '460px',
        width: '100%',
        textAlign: 'center',
        backgroundColor: 'white',
        borderRadius: '16px',
        padding: '2rem',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        border: '1px solid #e2e8f0',
      }}>
        <div style={{
          width: '48px',
          height: '48px',
          borderRadius: '12px',
          backgroundColor: '#fef2f2',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 16px',
        }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10" />
            <line x1="12" y1="8" x2="12" y2="12" />
            <line x1="12" y1="16" x2="12.01" y2="16" />
          </svg>
        </div>

        <h2 style={{
          fontSize: '1.125rem',
          fontWeight: 700,
          marginBottom: '0.5rem',
          color: '#0f172a',
        }}>
          خطا در پنل مدیریت
        </h2>

        <p style={{
          fontSize: '0.8125rem',
          color: '#64748b',
          marginBottom: '1.25rem',
          lineHeight: 1.7,
        }}>
          در بارگذاری این بخش از پنل مدیریت مشکلی پیش آمده.
          اگر مشکل ادامه داشت، بررسی کنید که اتصال پایگاه داده برقرار باشد.
        </p>

        {error.digest && (
          <p style={{
            fontSize: '0.6875rem',
            color: '#94a3b8',
            marginBottom: '0.75rem',
            direction: 'ltr',
          }}>
            Error: {error.digest}
          </p>
        )}

        <div style={{
          display: 'flex',
          gap: '0.5rem',
          justifyContent: 'center',
        }}>
          <button
            onClick={reset}
            style={{
              backgroundColor: '#0d9488',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              padding: '0.5rem 1rem',
              fontSize: '0.8125rem',
              fontWeight: 600,
              cursor: 'pointer',
            }}
          >
            تلاش دوباره
          </button>

          <a
            href="/admin"
            style={{
              backgroundColor: '#f1f5f9',
              color: '#334155',
              border: 'none',
              borderRadius: '8px',
              padding: '0.5rem 1rem',
              fontSize: '0.8125rem',
              fontWeight: 600,
              cursor: 'pointer',
              textDecoration: 'none',
              display: 'inline-block',
            }}
          >
            بازگشت به داشبورد
          </a>
        </div>
      </div>
    </div>
  );
}
