'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  BookMarked,
  Plus,
  Search,
  Pencil,
  Trash2,
  Eye,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Lock,
  Clock,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface KnowledgeArticle {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  category: string;
  tags: string;
  isPublished: boolean;
  isInternal: boolean;
  author: string;
  viewCount: number;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

interface PaginationInfo {
  صفحه: number;
  حجم: number;
  کل: number;
  تعداد_صفحات: number;
}

interface FormData {
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  category: string;
  tags: string;
  isPublished: boolean;
  isInternal: boolean;
  sortOrder: string;
}

/* ─────────── Constants ─────────── */

const CATEGORY_MAP: Record<string, { label: string; color: string; bg: string }> = {
  GENERAL: {
    label: 'عمومی',
    color: 'text-gray-700',
    bg: 'bg-gray-50 border-gray-200',
  },
  ENROLLMENT: {
    label: 'ثبت‌نام',
    color: 'text-teal-700',
    bg: 'bg-teal-50 border-teal-200',
  },
  PAYMENT: {
    label: 'پرداخت',
    color: 'text-emerald-700',
    bg: 'bg-emerald-50 border-emerald-200',
  },
  CERTIFICATE: {
    label: 'گواهینامه',
    color: 'text-amber-700',
    bg: 'bg-amber-50 border-amber-200',
  },
  POLICIES: {
    label: 'قوانین و مقررات',
    color: 'text-purple-700',
    bg: 'bg-purple-50 border-purple-200',
  },
  FAQ: {
    label: 'سوالات متداول',
    color: 'text-blue-700',
    bg: 'bg-blue-50 border-blue-200',
  },
};

const CATEGORY_KEYS = Object.keys(CATEGORY_MAP);

const EMPTY_FORM: FormData = {
  title: '',
  slug: '',
  content: '',
  excerpt: '',
  category: 'GENERAL',
  tags: '',
  isPublished: false,
  isInternal: true,
  sortOrder: '0',
};

const ITEMS_PER_PAGE = 20;

/* ─────────── Helpers ─────────── */

function generateSlug(title: string): string {
  return title
    .replace(/[\s]+/g, '-')
    .replace(/[^\u0600-\u06FF\w-]/g, '')
    .toLowerCase()
    .substring(0, 80);
}

function formatDate(dateStr: string): string {
  try {
    return new Date(dateStr).toLocaleDateString('fa-IR');
  } catch {
    return dateStr;
  }
}

function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

/* ─────────── Main Component ─────────── */

export default function KnowledgeBasePage() {
  /* ── State ── */
  const [articles, setArticles] = useState<KnowledgeArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<PaginationInfo | null>(null);
  const [categories, setCategories] = useState<Record<string, number>>({});

  // Filters
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingArticle, setEditingArticle] = useState<KnowledgeArticle | null>(null);
  const [form, setForm] = useState<FormData>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  // Delete
  const [deleteId, setDeleteId] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchArticles = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      params.set('page', currentPage.toString());
      params.set('limit', ITEMS_PER_PAGE.toString());

      if (search) params.set('search', search);
      if (categoryFilter !== 'ALL') params.set('category', categoryFilter);

      const res = await fetch(`/api/crm/knowledge-base?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        toast.error(data['خطا'] || 'خطا در دریافت لیست مقالات');
        return;
      }

      setArticles(data['داده‌ها'] || []);
      setPagination(data['صفحه‌بندی'] || null);
      setCategories(data['دسته‌بندی‌ها'] || {});
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [currentPage, search, categoryFilter]);

  useEffect(() => {
    fetchArticles();
  }, [fetchArticles]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [search, categoryFilter]);

  /* ── Computed stats ── */

  const totalArticles = pagination?.کل ?? articles.length;

  /* ── Modal handlers ── */

  const openCreateModal = () => {
    setEditingArticle(null);
    setForm(EMPTY_FORM);
    setModalOpen(true);
  };

  const openEditModal = (article: KnowledgeArticle) => {
    setEditingArticle(article);
    setForm({
      title: article.title,
      slug: article.slug,
      content: '',
      excerpt: article.excerpt || '',
      category: article.category,
      tags: article.tags,
      isPublished: article.isPublished,
      isInternal: article.isInternal,
      sortOrder: article.sortOrder.toString(),
    });
    setModalOpen(true);
  };

  const handleTitleChange = (title: string) => {
    const newSlug = editingArticle ? form.slug : generateSlug(title);
    setForm({ ...form, title, slug: newSlug });
  };

  const handleSubmit = async () => {
    if (!form.title.trim()) {
      toast.error('عنوان مقاله الزامی است');
      return;
    }

    if (!form.content.trim() && !editingArticle) {
      toast.error('محتوای مقاله الزامی است');
      return;
    }

    setSubmitting(true);

    try {
      const payload = {
        title: form.title.trim(),
        slug: form.slug.trim() || generateSlug(form.title),
        content: form.content.trim(),
        excerpt: form.excerpt.trim() || '',
        category: form.category,
        tags: form.tags.trim(),
        isPublished: form.isPublished,
        isInternal: form.isInternal,
        sortOrder: parseInt(form.sortOrder) || 0,
        ...(editingArticle ? {} : { author: '' }),
      };

      let res: Response;

      if (editingArticle) {
        res = await fetch('/api/crm/knowledge-base', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            articleId: editingArticle.id,
            ...payload,
          }),
        });
      } else {
        res = await fetch('/api/crm/knowledge-base', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();

      if (!res.ok) {
        toast.error(data['خطا'] || 'خطا در ذخیره‌سازی');
        return;
      }

      toast.success(
        editingArticle
          ? 'مقاله با موفقیت ویرایش شد'
          : 'مقاله جدید با موفقیت ایجاد شد'
      );
      setModalOpen(false);
      fetchArticles();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setSubmitting(false);
    }
  };

  /* ── Delete handler ── */

  const handleDelete = async () => {
    if (!deleteId) return;

    try {
      const res = await fetch('/api/crm/knowledge-base', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ articleId: deleteId }),
      });

      if (!res.ok) {
        const data = await res.json();
        toast.error(data['خطا'] || 'خطا در حذف مقاله');
        return;
      }

      toast.success('مقاله با موفقیت حذف شد');
      fetchArticles();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    }

    setDeleteId(null);
  };

  /* ── Page navigation ── */

  const totalPages = pagination?.تعداد_صفحات ?? 1;

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const getPageNumbers = (): (number | '...')[] => {
    if (totalPages <= 5) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }

    const pages: (number | '...')[] = [1];

    if (currentPage > 3) {
      pages.push('...');
    }

    const start = Math.max(2, currentPage - 1);
    const end = Math.min(totalPages - 1, currentPage + 1);

    for (let i = start; i <= end; i++) {
      pages.push(i);
    }

    if (currentPage < totalPages - 2) {
      pages.push('...');
    }

    pages.push(totalPages);

    return pages;
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <BookMarked className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">پایگاه دانش</h1>
              <Badge
                variant="secondary"
                className="bg-teal-50 text-teal-700 border border-teal-200 text-xs"
              >
                {loading ? '...' : toPersianNumber(totalArticles)} مقاله
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">
              مدیریت مقالات و مستندات پایگاه دانش
            </p>
          </div>
        </div>
        <Button
          onClick={openCreateModal}
          className="bg-teal-600 hover:bg-teal-700 gap-2 text-white"
        >
          <Plus className="h-4 w-4" />
          افزودن مقاله
        </Button>
      </div>

      {/* Category Tabs / Pills */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setCategoryFilter('ALL')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-colors border ${
            categoryFilter === 'ALL'
              ? 'bg-teal-600 text-white border-teal-600'
              : 'bg-white text-gray-600 border-gray-200 hover:border-teal-300 hover:text-teal-700'
          }`}
        >
          همه
        </button>
        {CATEGORY_KEYS.map((key) => {
          const cat = CATEGORY_MAP[key];
          const count = categories[key] || 0;
          return (
            <button
              key={key}
              onClick={() => setCategoryFilter(key)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors border flex items-center gap-1.5 ${
                categoryFilter === key
                  ? 'bg-teal-600 text-white border-teal-600'
                  : `bg-white ${cat.color} border-gray-200 hover:border-teal-300`
              }`}
            >
              {cat.label}
              {count > 0 && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                    categoryFilter === key
                      ? 'bg-white/20 text-white'
                      : 'bg-gray-100 text-gray-500'
                  }`}
                >
                  {toPersianNumber(count)}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Search Bar */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="جستجو در عنوان، محتوا یا برچسب..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pr-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Articles Cards Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-5 space-y-3">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
                <div className="flex gap-2">
                  <Skeleton className="h-6 w-20" />
                  <Skeleton className="h-6 w-16" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : articles.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <BookMarked className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">مقاله‌ای یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با افزودن مقاله جدید شروع کنید
            </p>
            <Button
              onClick={openCreateModal}
              className="mt-4 bg-teal-600 hover:bg-teal-700 gap-2 text-white"
            >
              <Plus className="h-4 w-4" />
              افزودن مقاله
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {articles.map((article) => {
            const catMeta = CATEGORY_MAP[article.category];

            return (
              <Card
                key={article.id}
                className="bg-white rounded-xl shadow-sm border hover:shadow-md transition-shadow duration-200 group"
              >
                <CardContent className="p-5">
                  {/* Title + Status */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-bold text-gray-900 text-base leading-relaxed line-clamp-2">
                      {article.title}
                    </h3>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span
                        className={`w-2.5 h-2.5 rounded-full ${
                          article.isPublished
                            ? 'bg-emerald-500'
                            : 'bg-gray-300'
                        }`}
                        title={article.isPublished ? 'منتشر شده' : 'پیش‌نویس'}
                      />
                    </div>
                  </div>

                  {/* Excerpt */}
                  {article.excerpt && (
                    <p className="text-sm text-gray-500 mb-3 line-clamp-2">
                      {truncateText(article.excerpt, 120)}
                    </p>
                  )}

                  {/* Category + Internal Badge */}
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    {catMeta && (
                      <Badge
                        variant="outline"
                        className={`${catMeta.bg} text-[11px] font-medium`}
                      >
                        {catMeta.label}
                      </Badge>
                    )}
                    {article.isInternal && (
                      <Badge
                        variant="outline"
                        className="bg-orange-50 border-orange-200 text-orange-700 text-[11px] font-medium"
                      >
                        <Lock className="w-3 h-3 ml-1" />
                        داخلی
                      </Badge>
                    )}
                    <Badge
                      variant="secondary"
                      className={
                        article.isPublished
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px]'
                          : 'bg-gray-50 text-gray-500 border border-gray-200 text-[11px]'
                      }
                    >
                      {article.isPublished ? 'منتشر شده' : 'پیش‌نویس'}
                    </Badge>
                  </div>

                  {/* Meta info: Author, Views, Date */}
                  <div className="flex items-center gap-4 text-xs text-gray-400 mb-4">
                    {article.author && (
                      <span>{article.author}</span>
                    )}
                    <span className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" />
                      {toPersianNumber(article.viewCount)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {formatDate(article.updatedAt)}
                    </span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditModal(article)}
                      className="gap-1.5 text-gray-600 hover:text-teal-700 hover:bg-teal-50 flex-1"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      ویرایش
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteId(article.id)}
                      className="gap-1.5 text-gray-600 hover:text-red-700 hover:bg-red-50 flex-1"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      حذف
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-center gap-1 pt-2">
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={() => goToPage(currentPage - 1)}
            disabled={currentPage <= 1}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>

          {getPageNumbers().map((page, index) =>
            page === '...' ? (
              <span
                key={`dots-${index}`}
                className="px-2 text-gray-400 text-sm"
              >
                ...
              </span>
            ) : (
              <Button
                key={page}
                variant={page === currentPage ? 'default' : 'outline'}
                size="icon"
                className={`h-9 w-9 ${
                  page === currentPage
                    ? 'bg-teal-600 hover:bg-teal-700 text-white'
                    : ''
                }`}
                onClick={() => goToPage(page)}
              >
                {toPersianNumber(page)}
              </Button>
            )
          )}

          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={() => goToPage(currentPage + 1)}
            disabled={currentPage >= totalPages}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Add/Edit Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingArticle ? 'ویرایش مقاله' : 'افزودن مقاله جدید'}
            </DialogTitle>
            <DialogDescription>
              {editingArticle
                ? 'اطلاعات مقاله را ویرایش کنید'
                : 'اطلاعات مقاله جدید را وارد کنید'}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
            {/* Title */}
            <div className="sm:col-span-2">
              <Label htmlFor="title" className="text-sm font-medium text-gray-700">
                عنوان مقاله <span className="text-red-500">*</span>
              </Label>
              <Input
                id="title"
                value={form.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                placeholder="مثلاً: راهنمای ثبت‌نام دوره‌ها"
                className="mt-1.5"
              />
            </div>

            {/* Slug */}
            <div className="sm:col-span-2">
              <Label htmlFor="slug" className="text-sm font-medium text-gray-700">
                شناسه URL (slug)
              </Label>
              <Input
                id="slug"
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: e.target.value })}
                placeholder="به‌صورت خودکار از عنوان تولید می‌شود"
                className="mt-1.5 font-mono text-sm"
                dir="ltr"
              />
            </div>

            {/* Content */}
            <div className="sm:col-span-2">
              <Label htmlFor="content" className="text-sm font-medium text-gray-700">
                محتوای مقاله <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="content"
                value={form.content}
                onChange={(e) => setForm({ ...form, content: e.target.value })}
                placeholder="محتوای مقاله را وارد کنید... (پشتیبانی از Markdown)"
                className="mt-1.5 min-h-[200px]"
              />
              {editingArticle && (
                <p className="text-[11px] text-gray-400 mt-1">
                  محتوا تنها در صورت ورود مقدار جدید به‌روزرسانی می‌شود
                </p>
              )}
            </div>

            {/* Excerpt */}
            <div className="sm:col-span-2">
              <Label htmlFor="excerpt" className="text-sm font-medium text-gray-700">
                خلاصه
              </Label>
              <Textarea
                id="excerpt"
                value={form.excerpt}
                onChange={(e) => setForm({ ...form, excerpt: e.target.value })}
                placeholder="خلاصه کوتاه مقاله..."
                className="mt-1.5 min-h-[80px]"
              />
            </div>

            {/* Category */}
            <div>
              <Label className="text-sm font-medium text-gray-700">
                دسته‌بندی
              </Label>
              <Select
                value={form.category}
                onValueChange={(val) => setForm({ ...form, category: val })}
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="انتخاب دسته‌بندی" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORY_KEYS.map((key) => (
                    <SelectItem key={key} value={key}>
                      {CATEGORY_MAP[key].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Tags */}
            <div>
              <Label htmlFor="tags" className="text-sm font-medium text-gray-700">
                برچسب‌ها
              </Label>
              <Input
                id="tags"
                value={form.tags}
                onChange={(e) => setForm({ ...form, tags: e.target.value })}
                placeholder="با کاما جدا کنید: ثبت‌نام, دوره, شهریه"
                className="mt-1.5"
              />
            </div>

            {/* Sort Order */}
            <div>
              <Label htmlFor="sortOrder" className="text-sm font-medium text-gray-700">
                ترتیب نمایش
              </Label>
              <Input
                id="sortOrder"
                type="number"
                min={0}
                value={form.sortOrder}
                onChange={(e) => setForm({ ...form, sortOrder: e.target.value })}
                placeholder="0"
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Toggles */}
            <div className="space-y-4">
              {/* isPublished */}
              <div className="flex items-center justify-between gap-3 rounded-lg border border-gray-100 p-3">
                <div>
                  <Label className="text-sm font-medium text-gray-700">
                    انتشار
                  </Label>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    مقاله برای همه قابل مشاهده باشد
                  </p>
                </div>
                <Switch
                  checked={form.isPublished}
                  onCheckedChange={(checked) =>
                    setForm({ ...form, isPublished: checked })
                  }
                />
              </div>

              {/* isInternal */}
              <div className="flex items-center justify-between gap-3 rounded-lg border border-gray-100 p-3">
                <div>
                  <Label className="text-sm font-medium text-gray-700">
                    داخلی
                  </Label>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    فقط مدیران بتوانند مشاهده کنند
                  </p>
                </div>
                <Switch
                  checked={form.isInternal}
                  onCheckedChange={(checked) =>
                    setForm({ ...form, isInternal: checked })
                  }
                />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2 mt-2">
            <Button
              variant="outline"
              onClick={() => setModalOpen(false)}
              disabled={submitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editingArticle ? 'ذخیره تغییرات' : 'ایجاد مقاله'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف مقاله</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف این مقاله اطمینان دارید؟ این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
