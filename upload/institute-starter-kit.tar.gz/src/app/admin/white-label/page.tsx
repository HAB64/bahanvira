'use client';

import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Palette,
  Globe,
  Mail,
  Smartphone,
  Monitor,
  Eye,
  Save,
  Plus,
  Paintbrush,
  Loader2,
  AlertTriangle,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Tenant {
  id: string;
  name: string;
  slug: string;
  plan: string;
  status: string;
  domain?: string | null;
}

interface WhiteLabelConfig {
  id: string;
  tenantId: string;
  brandName: string;
  brandSlogan: string | null;
  logoUrl: string | null;
  faviconUrl: string | null;
  primaryColor: string;
  secondaryColor: string | null;
  accentColor: string | null;
  fontFamily: string | null;
  borderRadius: string;
  customDomain: string | null;
  customEmailFrom: string | null;
  customSmsFrom: string | null;
  loginPageTitle: string | null;
  loginPageSubtitle: string | null;
  loginBackground: string | null;
  footerText: string | null;
  termsUrl: string | null;
  privacyUrl: string | null;
  isActive: boolean;
  createdAt: string;
  tenant: Tenant;
}

interface FormState {
  tenantId: string;
  brandName: string;
  brandSlogan: string;
  logoUrl: string;
  faviconUrl: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
  borderRadius: string;
  customDomain: string;
  customEmailFrom: string;
  customSmsFrom: string;
  loginPageTitle: string;
  loginPageSubtitle: string;
  loginBackground: string;
  footerText: string;
  termsUrl: string;
  privacyUrl: string;
  isActive: boolean;
}

const emptyForm: FormState = {
  tenantId: '',
  brandName: '',
  brandSlogan: '',
  logoUrl: '',
  faviconUrl: '',
  primaryColor: '#0d9488',
  secondaryColor: '#14b8a6',
  accentColor: '#f59e0b',
  fontFamily: '',
  borderRadius: '0.5rem',
  customDomain: '',
  customEmailFrom: '',
  customSmsFrom: '',
  loginPageTitle: '',
  loginPageSubtitle: '',
  loginBackground: '',
  footerText: '',
  termsUrl: '',
  privacyUrl: '',
  isActive: true,
};

/* ─────────── Component ─────────── */

export default function WhiteLabelPage() {
  const [configs, setConfigs] = useState<WhiteLabelConfig[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [stats, setStats] = useState({ total: 0, active: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Dialog states
  const [formOpen, setFormOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editingTenantId, setEditingTenantId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [previewConfig, setPreviewConfig] = useState<WhiteLabelConfig | null>(null);

  // Fetch configs
  const fetchConfigs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('/api/admin/white-label');
      if (!res.ok) throw new Error('خطا در دریافت داده‌ها');
      const data = await res.json();
      setConfigs(data.configs || []);
      setStats(data.stats || { total: 0, active: 0 });
    } catch {
      setError('خطا در دریافت تنظیمات White-Label');
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch tenants for dropdown
  const fetchTenants = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/tenants');
      if (res.ok) {
        const data = await res.json();
        setTenants(data.tenants || []);
      }
    } catch {
      // silent fail — tenants are optional for the form
    }
  }, []);

  useEffect(() => {
    fetchConfigs();
    fetchTenants();
  }, [fetchConfigs, fetchTenants]);

  // ─── Form helpers ───

  const updateForm = (field: keyof FormState, value: string | boolean) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const openCreateDialog = () => {
    setEditMode(false);
    setEditingTenantId(null);
    setForm(emptyForm);
    setFormOpen(true);
  };

  const openEditDialog = (config: WhiteLabelConfig) => {
    setEditMode(true);
    setEditingTenantId(config.tenantId);
    setForm({
      tenantId: config.tenantId,
      brandName: config.brandName,
      brandSlogan: config.brandSlogan || '',
      logoUrl: config.logoUrl || '',
      faviconUrl: config.faviconUrl || '',
      primaryColor: config.primaryColor,
      secondaryColor: config.secondaryColor || '',
      accentColor: config.accentColor || '',
      fontFamily: config.fontFamily || '',
      borderRadius: config.borderRadius,
      customDomain: config.customDomain || '',
      customEmailFrom: config.customEmailFrom || '',
      customSmsFrom: config.customSmsFrom || '',
      loginPageTitle: config.loginPageTitle || '',
      loginPageSubtitle: config.loginPageSubtitle || '',
      loginBackground: config.loginBackground || '',
      footerText: config.footerText || '',
      termsUrl: config.termsUrl || '',
      privacyUrl: config.privacyUrl || '',
      isActive: config.isActive,
    });
    setFormOpen(true);
  };

  const openPreview = (config: WhiteLabelConfig) => {
    setPreviewConfig(config);
    setPreviewOpen(true);
  };

  // ─── Save handler ───

  const handleSave = async () => {
    if (!form.brandName.trim()) {
      toast.error('نام برند الزامی است');
      return;
    }
    if (!editMode && !form.tenantId) {
      toast.error('انتخاب Tenant الزامی است');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        tenantId: form.tenantId,
        brandName: form.brandName,
        brandSlogan: form.brandSlogan || null,
        logoUrl: form.logoUrl || null,
        faviconUrl: form.faviconUrl || null,
        primaryColor: form.primaryColor,
        secondaryColor: form.secondaryColor || null,
        accentColor: form.accentColor || null,
        fontFamily: form.fontFamily || null,
        borderRadius: form.borderRadius || null,
        customDomain: form.customDomain || null,
        customEmailFrom: form.customEmailFrom || null,
        customSmsFrom: form.customSmsFrom || null,
        loginPageTitle: form.loginPageTitle || null,
        loginPageSubtitle: form.loginPageSubtitle || null,
        loginBackground: form.loginBackground || null,
        footerText: form.footerText || null,
        termsUrl: form.termsUrl || null,
        privacyUrl: form.privacyUrl || null,
        isActive: form.isActive,
      };

      let res: Response;
      if (editMode && editingTenantId) {
        res = await fetch(`/api/admin/white-label/${editingTenantId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch('/api/admin/white-label', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'خطا در ذخیره تنظیمات');
      }

      toast.success(editMode ? 'تنظیمات با موفقیت به‌روزرسانی شد' : 'تنظیمات جدید با موفقیت ایجاد شد');
      setFormOpen(false);
      fetchConfigs();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'خطا در ذخیره تنظیمات';
      toast.error(message);
    } finally {
      setSaving(false);
    }
  };

  // ─── Tenants without config (for create mode) ───

  const tenantsWithoutConfig = tenants.filter(
    (t) => !configs.some((c) => c.tenantId === t.id)
  );

  /* ─────────── Render ─────────── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center shrink-0">
            <Palette className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">White-Label</h1>
            <p className="text-gray-500 mt-0.5 text-sm">
              تنظیمات برندسازی — شخصی‌سازی ظاهر و احساس پلتفرم
            </p>
          </div>
        </div>
        <Button
          onClick={openCreateDialog}
          className="bg-teal-600 hover:bg-teal-700 gap-2 shrink-0"
        >
          <Plus className="h-4 w-4" />
          تنظیمات جدید
        </Button>
      </div>

      {/* ── Stats Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">کل تنظیمات</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  {loading ? <Skeleton className="h-9 w-12" /> : toPersianNumber(stats.total)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center">
                <Paintbrush className="h-6 w-6 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">فعال</p>
                <p className="text-3xl font-bold text-green-600 mt-1">
                  {loading ? <Skeleton className="h-9 w-12" /> : toPersianNumber(stats.active)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center">
                <Monitor className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Error State ── */}
      {error && (
        <Card className="border-0 shadow-sm border-r-4 border-r-red-400">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 text-red-700">
              <AlertTriangle className="h-5 w-5 shrink-0" />
              <p className="text-sm">{error}</p>
              <Button variant="outline" size="sm" onClick={fetchConfigs} className="mr-auto">
                تلاش مجدد
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Config List ── */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-6 space-y-4">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <div className="flex gap-2">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                </div>
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : configs.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Palette className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">هنوز تنظیمات White-Label ایجاد نشده</p>
            <p className="text-gray-400 text-sm mt-1">
              با کلیک روی دکمه &ldquo;تنظیمات جدید&rdquo; شروع کنید
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {configs.map((config) => (
            <Card key={config.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
              <CardContent className="p-6 space-y-4">
                {/* Tenant name + status */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-sm text-gray-500 truncate">{config.tenant.name}</span>
                    <Badge
                      variant="outline"
                      className={
                        config.tenant.status === 'ACTIVE'
                          ? 'border-green-200 text-green-700 bg-green-50'
                          : config.tenant.status === 'TRIAL'
                          ? 'border-amber-200 text-amber-700 bg-amber-50'
                          : 'border-gray-200 text-gray-600 bg-gray-50'
                      }
                    >
                      {config.tenant.status === 'ACTIVE'
                        ? 'فعال'
                        : config.tenant.status === 'TRIAL'
                        ? 'آزمایشی'
                        : config.tenant.status === 'SUSPENDED'
                        ? 'معلق'
                        : 'منقضی'}
                    </Badge>
                  </div>
                  <Badge
                    className={
                      config.isActive
                        ? 'bg-green-100 text-green-700 hover:bg-green-100'
                        : 'bg-gray-100 text-gray-500 hover:bg-gray-100'
                    }
                  >
                    {config.isActive ? 'فعال' : 'غیرفعال'}
                  </Badge>
                </div>

                {/* Brand name */}
                <h3 className="text-xl font-bold text-gray-900 truncate">{config.brandName}</h3>

                {/* Color preview */}
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-8 h-8 rounded-full border-2 border-white shadow-sm"
                      style={{ backgroundColor: config.primaryColor }}
                      title={`رنگ اصلی: ${config.primaryColor}`}
                    />
                    <div
                      className="w-8 h-8 rounded-full border-2 border-white shadow-sm"
                      style={{ backgroundColor: config.secondaryColor || '#e5e7eb' }}
                      title={`رنگ ثانویه: ${config.secondaryColor || '—'}`}
                    />
                    <div
                      className="w-8 h-8 rounded-full border-2 border-white shadow-sm"
                      style={{ backgroundColor: config.accentColor || '#e5e7eb' }}
                      title={`رنگ تأکیدی: ${config.accentColor || '—'}`}
                    />
                  </div>
                  <span className="text-xs text-gray-400 font-mono" dir="ltr">
                    {config.primaryColor}
                  </span>
                </div>

                {/* Custom domain */}
                {config.customDomain && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Globe className="h-4 w-4 text-gray-400 shrink-0" />
                    <span className="truncate" dir="ltr">{config.customDomain}</span>
                  </div>
                )}

                {/* Slogan */}
                {config.brandSlogan && (
                  <p className="text-sm text-gray-500 truncate">&ldquo;{config.brandSlogan}&rdquo;</p>
                )}

                {/* Actions */}
                <div className="flex items-center gap-2 pt-2 border-t border-gray-100">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openPreview(config)}
                    className="gap-1.5 text-xs"
                  >
                    <Eye className="h-3.5 w-3.5" />
                    پیش‌نمایش
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditDialog(config)}
                    className="gap-1.5 text-xs"
                  >
                    <Paintbrush className="h-3.5 w-3.5" />
                    ویرایش
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* ─────────── Create / Edit Dialog ─────────── */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-teal-600" />
              {editMode ? 'ویرایش تنظیمات White-Label' : 'ایجاد تنظیمات جدید'}
            </DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="brand" className="w-full">
            <TabsList className="w-full grid grid-cols-5 h-auto p-1">
              <TabsTrigger value="brand" className="text-xs py-2">تب برند</TabsTrigger>
              <TabsTrigger value="colors" className="text-xs py-2">رنگ و فونت</TabsTrigger>
              <TabsTrigger value="domain" className="text-xs py-2">دامنه و ارتباط</TabsTrigger>
              <TabsTrigger value="login" className="text-xs py-2">صفحه ورود</TabsTrigger>
              <TabsTrigger value="footer" className="text-xs py-2">فوتر و حقوقی</TabsTrigger>
            </TabsList>

            {/* ── Brand Tab ── */}
            <TabsContent value="brand" className="space-y-4 mt-4">
              {/* Tenant select (only create mode) */}
              {!editMode && (
                <div className="space-y-2">
                  <Label>Tenant</Label>
                  <Select
                    value={form.tenantId}
                    onValueChange={(val) => updateForm('tenantId', val)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="انتخاب Tenant..." />
                    </SelectTrigger>
                    <SelectContent>
                      {tenantsWithoutConfig.length === 0 ? (
                        <div className="px-3 py-2 text-sm text-gray-500">
                          Tenant موجود نیست
                        </div>
                      ) : (
                        tenantsWithoutConfig.map((t) => (
                          <SelectItem key={t.id} value={t.id}>
                            {t.name} ({t.slug})
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="space-y-2">
                <Label>
                  نام برند <span className="text-red-500">*</span>
                </Label>
                <Input
                  value={form.brandName}
                  onChange={(e) => updateForm('brandName', e.target.value)}
                  placeholder="مثلاً: آکادمی نوین"
                />
              </div>

              <div className="space-y-2">
                <Label>شعار برند</Label>
                <Input
                  value={form.brandSlogan}
                  onChange={(e) => updateForm('brandSlogan', e.target.value)}
                  placeholder="شعار یا جمله کوتاه برند"
                />
              </div>

              <div className="space-y-2">
                <Label>لوگو (URL)</Label>
                <Input
                  value={form.logoUrl}
                  onChange={(e) => updateForm('logoUrl', e.target.value)}
                  placeholder="https://example.com/logo.png"
                  dir="ltr"
                />
              </div>

              <div className="space-y-2">
                <Label>فاوآیکون (URL)</Label>
                <Input
                  value={form.faviconUrl}
                  onChange={(e) => updateForm('faviconUrl', e.target.value)}
                  placeholder="https://example.com/favicon.ico"
                  dir="ltr"
                />
              </div>
            </TabsContent>

            {/* ── Colors & Font Tab ── */}
            <TabsContent value="colors" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>رنگ اصلی</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={form.primaryColor}
                      onChange={(e) => updateForm('primaryColor', e.target.value)}
                      className="w-10 h-10 rounded-lg border border-gray-200 cursor-pointer p-0.5"
                    />
                    <Input
                      value={form.primaryColor}
                      onChange={(e) => updateForm('primaryColor', e.target.value)}
                      className="font-mono text-sm"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>رنگ ثانویه</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={form.secondaryColor || '#14b8a6'}
                      onChange={(e) => updateForm('secondaryColor', e.target.value)}
                      className="w-10 h-10 rounded-lg border border-gray-200 cursor-pointer p-0.5"
                    />
                    <Input
                      value={form.secondaryColor}
                      onChange={(e) => updateForm('secondaryColor', e.target.value)}
                      placeholder="#14b8a6"
                      className="font-mono text-sm"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>رنگ تأکیدی</Label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={form.accentColor || '#f59e0b'}
                      onChange={(e) => updateForm('accentColor', e.target.value)}
                      className="w-10 h-10 rounded-lg border border-gray-200 cursor-pointer p-0.5"
                    />
                    <Input
                      value={form.accentColor}
                      onChange={(e) => updateForm('accentColor', e.target.value)}
                      placeholder="#f59e0b"
                      className="font-mono text-sm"
                      dir="ltr"
                    />
                  </div>
                </div>
              </div>

              {/* Live color preview strip */}
              <div className="space-y-2">
                <Label>پیش‌نمایش رنگ‌ها</Label>
                <div className="flex rounded-lg overflow-hidden h-10 shadow-sm">
                  <div
                    className="flex-1 flex items-center justify-center text-white text-xs font-medium"
                    style={{ backgroundColor: form.primaryColor }}
                  >
                    اصلی
                  </div>
                  <div
                    className="flex-1 flex items-center justify-center text-white text-xs font-medium"
                    style={{ backgroundColor: form.secondaryColor || '#14b8a6' }}
                  >
                    ثانویه
                  </div>
                  <div
                    className="flex-1 flex items-center justify-center text-white text-xs font-medium"
                    style={{ backgroundColor: form.accentColor || '#f59e0b' }}
                  >
                    تأکیدی
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>فونت</Label>
                  <Input
                    value={form.fontFamily}
                    onChange={(e) => updateForm('fontFamily', e.target.value)}
                    placeholder="Vazirmatn, sans-serif"
                    dir="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <Label>شعاع حاشیه</Label>
                  <Input
                    value={form.borderRadius}
                    onChange={(e) => updateForm('borderRadius', e.target.value)}
                    placeholder="0.5rem"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* Border radius preview */}
              <div className="space-y-2">
                <Label>پیش‌نمایش شعاع حاشیه</Label>
                <div
                  className="w-24 h-12 border-2 border-gray-300 flex items-center justify-center text-xs text-gray-500"
                  style={{ borderRadius: form.borderRadius || '0.5rem' }}
                >
                  پیش‌نمایش
                </div>
              </div>
            </TabsContent>

            {/* ── Domain & Communication Tab ── */}
            <TabsContent value="domain" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-gray-400" />
                  دامنه اختصاصی
                </Label>
                <Input
                  value={form.customDomain}
                  onChange={(e) => updateForm('customDomain', e.target.value)}
                  placeholder="portal.example.com"
                  dir="ltr"
                />
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-gray-400" />
                  ایمیل فرستنده
                </Label>
                <Input
                  value={form.customEmailFrom}
                  onChange={(e) => updateForm('customEmailFrom', e.target.value)}
                  placeholder="noreply@example.com"
                  dir="ltr"
                />
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-gray-400" />
                  شماره پیامک
                </Label>
                <Input
                  value={form.customSmsFrom}
                  onChange={(e) => updateForm('customSmsFrom', e.target.value)}
                  placeholder="۳۰۰۰۱۲۳۴"
                />
              </div>
            </TabsContent>

            {/* ── Login Page Tab ── */}
            <TabsContent value="login" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>عنوان صفحه ورود</Label>
                <Input
                  value={form.loginPageTitle}
                  onChange={(e) => updateForm('loginPageTitle', e.target.value)}
                  placeholder="ورود به پنل"
                />
              </div>

              <div className="space-y-2">
                <Label>زیرعنوان</Label>
                <Input
                  value={form.loginPageSubtitle}
                  onChange={(e) => updateForm('loginPageSubtitle', e.target.value)}
                  placeholder="به حساب کاربری خود وارد شوید"
                />
              </div>

              <div className="space-y-2">
                <Label>تصویر پس‌زمینه (URL)</Label>
                <Input
                  value={form.loginBackground}
                  onChange={(e) => updateForm('loginBackground', e.target.value)}
                  placeholder="https://example.com/bg.jpg"
                  dir="ltr"
                />
              </div>

              {/* Login preview */}
              {(form.loginPageTitle || form.loginPageSubtitle) && (
                <div className="space-y-2">
                  <Label>پیش‌نمایش صفحه ورود</Label>
                  <div
                    className="rounded-lg p-6 text-center space-y-2 border"
                    style={{
                      backgroundColor: form.primaryColor + '15',
                      borderColor: form.primaryColor + '30',
                      borderRadius: form.borderRadius || '0.5rem',
                    }}
                  >
                    {form.loginBackground && (
                      <div className="text-xs text-gray-400 mb-2">🖼 تصویر پس‌زمینه تنظیم شده</div>
                    )}
                    <h4
                      className="text-lg font-bold"
                      style={{ color: form.primaryColor }}
                    >
                      {form.loginPageTitle || 'ورود به پنل'}
                    </h4>
                    <p className="text-sm text-gray-500">
                      {form.loginPageSubtitle || 'به حساب کاربری خود وارد شوید'}
                    </p>
                  </div>
                </div>
              )}
            </TabsContent>

            {/* ── Footer & Legal Tab ── */}
            <TabsContent value="footer" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>متن فوتر</Label>
                <Textarea
                  value={form.footerText}
                  onChange={(e) => updateForm('footerText', e.target.value)}
                  placeholder="© ۱۴۰۴ آکادمی نوین — تمامی حقوق محفوظ است"
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>لینک شرایط استفاده</Label>
                <Input
                  value={form.termsUrl}
                  onChange={(e) => updateForm('termsUrl', e.target.value)}
                  placeholder="https://example.com/terms"
                  dir="ltr"
                />
              </div>

              <div className="space-y-2">
                <Label>لینک حریم خصوصی</Label>
                <Input
                  value={form.privacyUrl}
                  onChange={(e) => updateForm('privacyUrl', e.target.value)}
                  placeholder="https://example.com/privacy"
                  dir="ltr"
                />
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <Label className="text-sm font-medium">فعال / غیرفعال</Label>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {form.isActive ? 'تنظیمات فعال است' : 'تنظیمات غیرفعال است'}
                  </p>
                </div>
                <Switch
                  checked={form.isActive}
                  onCheckedChange={(val) => updateForm('isActive', val)}
                />
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter className="gap-2 mt-6">
            <Button
              variant="outline"
              onClick={() => setFormOpen(false)}
              disabled={saving}
            >
              انصراف
            </Button>
            <Button
              onClick={handleSave}
              disabled={saving}
              className="bg-teal-600 hover:bg-teal-700 gap-2"
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              {saving ? 'در حال ذخیره...' : 'ذخیره'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─────────── Preview Dialog ─────────── */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-3xl" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-teal-600" />
              پیش‌نمایش White-Label
              {previewConfig && (
                <span className="text-sm font-normal text-gray-500">
                  — {previewConfig.brandName}
                </span>
              )}
            </DialogTitle>
          </DialogHeader>

          {previewConfig && (
            <div className="mt-4">
              {/* Mini browser frame */}
              <div className="rounded-xl border border-gray-200 shadow-lg overflow-hidden bg-white">
                {/* Browser chrome */}
                <div className="bg-gray-100 border-b border-gray-200 px-4 py-2.5 flex items-center gap-3">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-400" />
                    <div className="w-3 h-3 rounded-full bg-yellow-400" />
                    <div className="w-3 h-3 rounded-full bg-green-400" />
                  </div>
                  <div className="flex-1 bg-white rounded-md px-3 py-1 text-xs text-gray-400 font-mono" dir="ltr">
                    {previewConfig.customDomain || 'https://portal.example.com'}/login
                  </div>
                </div>

                {/* Page content */}
                <div
                  className="min-h-[380px] flex flex-col"
                  style={{
                    backgroundColor: previewConfig.loginBackground ? '#f9fafb' : previewConfig.primaryColor + '08',
                  }}
                >
                  {/* Header */}
                  <div
                    className="px-6 py-4 flex items-center justify-between"
                    style={{
                      backgroundColor: previewConfig.primaryColor,
                      borderRadius: '0 0 ' + (previewConfig.borderRadius || '0.5rem') + ' ' + (previewConfig.borderRadius || '0.5rem'),
                    }}
                  >
                    <div className="flex items-center gap-3">
                      {previewConfig.logoUrl ? (
                        <div
                          className="w-8 h-8 bg-white/20 rounded flex items-center justify-center overflow-hidden"
                        >
                          <img
                            src={previewConfig.logoUrl}
                            alt="لوگو"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = 'none';
                            }}
                          />
                        </div>
                      ) : (
                        <div className="w-8 h-8 bg-white/20 rounded flex items-center justify-center">
                          <Palette className="h-4 w-4 text-white" />
                        </div>
                      )}
                      <span className="text-white font-bold text-lg">
                        {previewConfig.brandName}
                      </span>
                    </div>
                    <div className="flex gap-3">
                      <div className="text-white/70 text-xs">دوره‌ها</div>
                      <div className="text-white/70 text-xs">تماس</div>
                    </div>
                  </div>

                  {/* Login Section */}
                  <div className="flex-1 flex items-center justify-center p-6">
                    <div
                      className="w-full max-w-sm bg-white p-6 space-y-4"
                      style={{
                        borderRadius: previewConfig.borderRadius || '0.5rem',
                        boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
                      }}
                    >
                      <div className="text-center space-y-2">
                        <h3
                          className="text-xl font-bold"
                          style={{ color: previewConfig.primaryColor }}
                        >
                          {previewConfig.loginPageTitle || `ورود به ${previewConfig.brandName}`}
                        </h3>
                        <p className="text-sm text-gray-500">
                          {previewConfig.loginPageSubtitle || 'به حساب کاربری خود وارد شوید'}
                        </p>
                      </div>

                      {/* Mock login form */}
                      <div className="space-y-3">
                        <div
                          className="h-10 border border-gray-200 rounded-md flex items-center px-3"
                          style={{ borderRadius: previewConfig.borderRadius || '0.5rem' }}
                        >
                          <span className="text-xs text-gray-300">ایمیل</span>
                        </div>
                        <div
                          className="h-10 border border-gray-200 rounded-md flex items-center px-3"
                          style={{ borderRadius: previewConfig.borderRadius || '0.5rem' }}
                        >
                          <span className="text-xs text-gray-300">رمز عبور</span>
                        </div>
                        <div
                          className="h-10 text-white text-sm font-medium flex items-center justify-center"
                          style={{
                            backgroundColor: previewConfig.primaryColor,
                            borderRadius: previewConfig.borderRadius || '0.5rem',
                          }}
                        >
                          ورود
                        </div>
                      </div>

                      {previewConfig.brandSlogan && (
                        <p className="text-center text-xs text-gray-400 italic">
                          &ldquo;{previewConfig.brandSlogan}&rdquo;
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Footer */}
                  <div
                    className="px-6 py-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-400"
                    style={{ backgroundColor: previewConfig.primaryColor + '08' }}
                  >
                    <span>{previewConfig.footerText || `© ۱۴۰۴ ${previewConfig.brandName}`}</span>
                    <div className="flex gap-3">
                      {previewConfig.termsUrl && <span>شرایط استفاده</span>}
                      {previewConfig.privacyUrl && <span>حریم خصوصی</span>}
                    </div>
                  </div>
                </div>
              </div>

              {/* Info below preview */}
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">رنگ اصلی</p>
                  <div className="flex items-center justify-center gap-2">
                    <div
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: previewConfig.primaryColor }}
                    />
                    <span className="text-xs font-mono" dir="ltr">{previewConfig.primaryColor}</span>
                  </div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">رنگ ثانویه</p>
                  <div className="flex items-center justify-center gap-2">
                    <div
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: previewConfig.secondaryColor || '#e5e7eb' }}
                    />
                    <span className="text-xs font-mono" dir="ltr">{previewConfig.secondaryColor || '—'}</span>
                  </div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">شعاع حاشیه</p>
                  <span className="text-xs font-mono" dir="ltr">{previewConfig.borderRadius}</span>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">فونت</p>
                  <span className="text-xs">{previewConfig.fontFamily || 'پیش‌فرض'}</span>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2 mt-4">
            {previewConfig && (
              <Button
                variant="outline"
                onClick={() => {
                  setPreviewOpen(false);
                  openEditDialog(previewConfig);
                }}
                className="gap-2"
              >
                <Paintbrush className="h-4 w-4" />
                ویرایش تنظیمات
              </Button>
            )}
            <Button
              variant="outline"
              onClick={() => setPreviewOpen(false)}
            >
              بستن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
