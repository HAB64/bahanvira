'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  LayoutDashboard,
  BookOpen,
  FileText,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronDown,
  Users,
  GraduationCap,
  ClipboardList,
  ListTodo,
  BarChart3,
  Ticket,
  BookMarked,
  FileSpreadsheet,
  Receipt,
  CalendarCheck,
  Target,
  Headphones,
  Mail,
  MapPin,
  Shield,
  Megaphone,
  Zap,
  GitBranch,
  Brain,
  Radar,
  Sparkles,
  Key,
  Globe,
  UserPlus,
  ClipboardCheck,
  Award,
  Cpu,
  Layers,
  UserCog,
  ShieldCheck,
  Building2,
  Store,
  Package,
  Palette,
  Briefcase,
  Bot,
  Database,
  LineChart,
  FlaskConical,
  Sitemap,
  MonitorSpeaker,
  Handshake,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const navSections: NavSection[] = [
  {
    title: 'گروه ۱: داشبورد و مدیریت',
    items: [
      { href: '/admin', label: 'داشبورد', icon: LayoutDashboard },
      { href: '/admin/users', label: 'کاربران سیستم', icon: Users },
      { href: '/admin/roles', label: 'نقش‌ها و دسترسی‌ها', icon: ShieldCheck },
      { href: '/admin/settings', label: 'تنظیمات', icon: Settings },
    ],
  },
  {
    title: 'گروه ۲: آموزش و محتوا',
    items: [
      { href: '/admin/courses', label: 'دوره‌ها (سایت)', icon: BookOpen },
      { href: '/admin/blog', label: 'بلاگ', icon: FileText },
      { href: '/admin/lms', label: 'LMS', icon: MonitorSpeaker },
      { href: '/admin/skill-programs', label: 'دوره‌های مهارتی', icon: ClipboardList },
      { href: '/admin/exams', label: 'آزمون‌ها', icon: ClipboardCheck },
      { href: '/admin/adaptive-exams', label: 'آزمون‌های تطبیقی', icon: FlaskConical },
      { href: '/admin/question-bank', label: 'بانک سوال', icon: Database },
      { href: '/admin/question-bank/generate', label: 'آزمون‌ساز', icon: Sparkles },
      { href: '/admin/quality', label: 'کیفیت آموزشی', icon: Award },
      { href: '/admin/karamuz', label: 'کارآموزان', icon: GraduationCap },
    ],
  },
  {
    title: 'گروه ۳: CRM و فروش',
    items: [
      { href: '/admin/crm', label: 'CRM', icon: Users },
      { href: '/admin/analytics', label: 'تحلیل CRM', icon: BarChart3 },
      { href: '/admin/tasks', label: 'وظایف', icon: ListTodo },
      { href: '/admin/tickets', label: 'تیکت‌ها', icon: Ticket },
      { href: '/admin/quotes', label: 'پیشنهادها', icon: FileSpreadsheet },
      { href: '/admin/invoices', label: 'فاکتورها', icon: Receipt },
      { href: '/admin/sales-targets', label: 'اهداف فروش', icon: Target },
      { href: '/admin/appointments', label: 'قرارها', icon: CalendarCheck },
      { href: '/admin/service-contracts', label: 'قراردادهای خدمات', icon: Shield },
    ],
  },
  {
    title: 'گروه ۴: بازاریابی',
    items: [
      { href: '/admin/campaigns', label: 'کمپین‌ها', icon: Megaphone },
      { href: '/admin/referrers', label: 'معرف‌ها و بازاریاب‌ها', icon: UserPlus },
      { href: '/admin/discount-codes', label: 'کدهای تخفیف', icon: Handshake },
      { href: '/admin/automation', label: 'اتوماسیون', icon: Zap },
      { href: '/admin/auto-lead-rules', label: 'تشخیص خودکار سرن', icon: Radar },
      { href: '/admin/churn-predictions', label: 'پیش‌بینی ریزش', icon: Brain },
    ],
  },
  {
    title: 'گروه ۵: کاریابی',
    items: [
      { href: '/admin/employment', label: 'کاریابی', icon: Briefcase },
      { href: '/admin/employment/job-listings', label: 'آگهی‌های شغلی', icon: Briefcase },
      { href: '/admin/employment/employers', label: 'کارفرمایان', icon: Building2 },
      { href: '/admin/employment/job-seekers', label: 'جویایان کار', icon: Users },
      { href: '/admin/employment/applications', label: 'درخواست‌ها', icon: ClipboardList },
    ],
  },
  {
    title: 'گروه ۶: هوش مصنوعی',
    items: [
      { href: '/admin/conversations', label: 'مکالمات AI', icon: Headphones },
      { href: '/admin/ai-agents', label: 'عامل‌های AI', icon: Bot },
      { href: '/admin/ai-reports', label: 'گزارش‌های AI', icon: Sparkles },
      { href: '/admin/knowledge-base', label: 'پایگاه دانش', icon: BookMarked },
    ],
  },
  {
    title: 'گروه ۷: تجاری و پلتفرم',
    items: [
      { href: '/admin/franchise', label: 'فرانچایز', icon: Store },
      { href: '/admin/white-label', label: 'White-Label', icon: Palette },
      { href: '/admin/marketplace', label: 'API Marketplace', icon: Package },
      { href: '/admin/tenants', label: 'مدیریت Tenantها', icon: Building2 },
      { href: '/admin/geo', label: 'نقشه مشتریان', icon: MapPin },
      { href: '/admin/bi', label: 'هوش تجاری (BI)', icon: LineChart },
      { href: '/admin/predictions', label: 'پیش‌بینی‌ها', icon: Brain },
    ],
  },
  {
    title: 'گروه ۸: پیشرفته',
    items: [
      { href: '/admin/architecture', label: 'معماری Enterprise', icon: Layers },
      { href: '/admin/cybernetic', label: 'سیستم سایبرنتیک', icon: Cpu },
      { href: '/admin/business-processes', label: 'فرآیندها', icon: GitBranch },
      { href: '/admin/api-keys', label: 'کلیدهای API', icon: Key },
      { href: '/admin/email-templates', label: 'قالب‌های ایمیل', icon: Mail },
      { href: '/admin/customer-portal', label: 'پورتال مشتری', icon: Globe },
    ],
  },
];

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [collapsedSections, setCollapsedSections] = useState<Set<number>>(new Set());

  const checkAuth = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/auth/check');
      const data = await res.json();
      if (data.authenticated) {
        setIsAuthenticated(true);
      } else {
        router.push('/admin/login');
      }
    } catch {
      router.push('/admin/login');
    } finally {
      setIsLoading(false);
    }
  }, [router]);

  useEffect(() => {
    if (pathname !== '/admin/login' && pathname !== '/admin/setup') {
      checkAuth();
    }
  }, [pathname, checkAuth]);

  const handleLogout = async () => {
    await fetch('/api/admin/auth/logout', { method: 'POST' });
    router.push('/admin/login');
  };

  const toggleSection = (index: number) => {
    setCollapsedSections(prev => {
      const next = new Set(prev);
      if (next.has(index)) {
        next.delete(index);
      } else {
        next.add(index);
      }
      return next;
    });
  };

  if (pathname === '/admin/login' || pathname === '/admin/setup') {
    return <>{children}</>;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center gap-4">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-teal-600 border-t-transparent" />
          <p className="text-sm text-gray-500">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex" dir="rtl">
      {/* SEO: Prevent search engine indexing of admin pages */}
      <head>
        <meta name="robots" content="noindex, nofollow" />
      </head>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 right-0 z-50 h-full w-64 bg-white border-l border-gray-200 transform transition-transform duration-200 lg:translate-x-0 lg:static lg:z-auto ${
          sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo area */}
          <div className="p-4 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center">
                  <span className="text-white font-bold text-lg">ب</span>
                </div>
                <div>
                  <h2 className="font-bold text-gray-900 text-sm">پنل مدیریت</h2>
                  <p className="text-xs text-gray-500">آموزشگاه بهان رایانه</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 p-3">
            <nav className="space-y-1">
              {navSections.map((section, sectionIndex) => {
                const isCollapsed = collapsedSections.has(sectionIndex);
                return (
                  <div key={sectionIndex}>
                    {/* Section header — collapsible toggle */}
                    <button
                      onClick={() => toggleSection(sectionIndex)}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-bold text-amber-400 hover:text-amber-500 transition-colors rounded-lg hover:bg-amber-50/50"
                    >
                      <ChevronDown
                        className={`h-3.5 w-3.5 transition-transform duration-200 ${
                          isCollapsed ? '-rotate-90' : ''
                        }`}
                      />
                      {section.title}
                    </button>
                    {/* Section items */}
                    {!isCollapsed && (
                      <div className="space-y-0.5 mb-2">
                        {section.items.map((item) => {
                          const isActive = pathname === item.href ||
                            (item.href !== '/admin' && pathname.startsWith(item.href));
                          return (
                            <Link
                              key={item.href}
                              href={item.href}
                              onClick={() => setSidebarOpen(false)}
                              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                                isActive
                                  ? 'bg-teal-50 text-teal-700'
                                  : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                              }`}
                            >
                              <item.icon className="h-4 w-4" />
                              {item.label}
                            </Link>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </nav>
          </ScrollArea>

          {/* Footer */}
          <div className="p-3 border-t border-gray-100">
            <Button
              variant="ghost"
              onClick={handleLogout}
              className="w-full justify-start gap-3 text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <LogOut className="h-5 w-5" />
              خروج
            </Button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-white border-b border-gray-200 px-4 py-3 lg:px-6">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div className="flex items-center gap-3 mr-auto">
              <Separator orientation="vertical" className="h-6 hidden lg:block" />
              <span className="text-sm text-gray-500 hidden lg:block">
                پنل مدیریت آموزشگاه بهان رایانه
              </span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
