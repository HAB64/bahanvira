'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Store,
  Plus,
  Search,
  Loader2,
  AlertTriangle,
  Eye,
  Edit3,
  FileText,
  DollarSign,
  CheckCircle2,
  Clock,
  XCircle,
  Ban,
  CreditCard,
  CalendarDays,
  TrendingUp,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface TenantInfo {
  id: string;
  name: string;
  slug: string;
  primaryColor?: string;
}

interface FranchiseContract {
  id: string;
  tenantId: string;
  parentTenantId: string;
  contractNumber: string;
  startDate: string;
  endDate: string;
  status: string;
  royaltyPercent: number;
  fixedRoyalty: number | null;
  minRevenue: number | null;
  terms: unknown;
  notes: string | null;
  tenant: TenantInfo;
  parentTenant: { id: string; name: string; slug: string };
  _count?: { payments: number };
  createdAt: string;
  updatedAt: string;
}

interface FranchisePayment {
  id: string;
  contractId: string;
  periodStart: string;
  periodEnd: string;
  revenue: number;
  royaltyAmount: number;
  status: string;
  paidAt: string | null;
  receiptNumber: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
}

interface FranchiseStats {
  total: number;
  active: number;
  pending: number;
  totalRoyalty: number;
  pendingRoyalty: number;
}

interface TenantOption {
  id: string;
  name: string;
  primaryColor?: string;
}

/* ─────────── Constants ─────────── */

const STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  ACTIVE: { label: 'فعال', color: 'text-green-700', bgColor: 'bg-green-100' },
  PENDING: { label: 'در انتظار', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  EXPIRED: { label: 'منقضی', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  TERMINATED: { label: 'فسخ شده', color: 'text-red-700', bgColor: 'bg-red-100' },
};

const PAYMENT_STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  PAID: { label: 'پرداخت شده', color: 'text-green-700', bgColor: 'bg-green-100' },
  OVERDUE: { label: 'سررسید گذشته', color: 'text-red-700', bgColor: 'bg-red-100' },
  WAIVED: { label: 'معاف شده', color: 'text-yellow-700', bgColor: 'bg-yellow-100' },
};

const STATUS_OPTIONS = [
  { value: 'all', label: 'همه وضعیت‌ها' },
  { value: 'ACTIVE', label: 'فعال' },
  { value: 'PENDING', label: 'در انتظار' },
  { value: 'EXPIRED', label: 'منقضی' },
  { value: 'TERMINATED', label: 'فسخ شده' },
];

const CONTRACT_STATUS_EDIT_OPTIONS = [
  { value: 'ACTIVE', label: 'فعال' },
  { value: 'PENDING', label: 'در انتظار' },
  { value: 'EXPIRED', label: 'منقضی' },
  { value: 'TERMINATED', label: 'فسخ شده' },
];

/* ─────────── Helpers ─────────── */

function formatRial(amount: number) {
  return toPersianNumber(amount.toLocaleString('fa-IR')) + ' ریال';
}

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function getStatusBadge(status: string) {
  const meta = STATUS_META[status] || { label: status, color: 'text-gray-700', bgColor: 'bg-gray-100' };
  return (
    <Badge className={`${meta.bgColor} ${meta.color} hover:${meta.bgColor} border-0 text-xs font-medium`}>
      {meta.label}
    </Badge>
  );
}

function getPaymentStatusBadge(status: string) {
  const meta = PAYMENT_STATUS_META[status] || { label: status, color: 'text-gray-700', bgColor: 'bg-gray-100' };
  return (
    <Badge className={`${meta.bgColor} ${meta.color} hover:${meta.bgColor} border-0 text-xs font-medium`}>
      {meta.label}
    </Badge>
  );
}

/* ─────────── Stat Card Component ─────────── */

function StatCard({
  title,
  value,
  icon: Icon,
  color,
  bgColor,
}: {
  title: string;
  value: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
}) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4 lg:p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm text-gray-500">{title}</p>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
          </div>
          <div className={`h-12 w-12 rounded-xl ${bgColor} flex items-center justify-center`}>
            <Icon className={`h-6 w-6 ${color}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ─────────── Main Component ─────────── */

export default function FranchisePage() {
  /* ── State ── */
  const [contracts, setContracts] = useState<FranchiseContract[]>([]);
  const [stats, setStats] = useState<FranchiseStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Tenants for dropdowns
  const [tenants, setTenants] = useState<TenantOption[]>([]);

  // Create dialog
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Create form fields
  const [formTenantId, setFormTenantId] = useState('');
  const [formParentTenantId, setFormParentTenantId] = useState('');
  const [formContractNumber, setFormContractNumber] = useState('');
  const [formStartDate, setFormStartDate] = useState('');
  const [formEndDate, setFormEndDate] = useState('');
  const [formRoyaltyPercent, setFormRoyaltyPercent] = useState('');
  const [formFixedRoyalty, setFormFixedRoyalty] = useState('');
  const [formMinRevenue, setFormMinRevenue] = useState('');
  const [formNotes, setFormNotes] = useState('');

  // Payment details dialog
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [selectedContract, setSelectedContract] = useState<FranchiseContract | null>(null);
  const [payments, setPayments] = useState<FranchisePayment[]>([]);
  const [paymentsLoading, setPaymentsLoading] = useState(false);

  // Edit status dialog
  const [editStatusDialogOpen, setEditStatusDialogOpen] = useState(false);
  const [editContractId, setEditContractId] = useState('');
  const [editStatus, setEditStatus] = useState('');
  const [editSubmitting, setEditSubmitting] = useState(false);

  // Record payment dialog
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [paymentSubmitting, setPaymentSubmitting] = useState(false);
  const [formPayPeriodStart, setFormPayPeriodStart] = useState('');
  const [formPayPeriodEnd, setFormPayPeriodEnd] = useState('');
  const [formPayRevenue, setFormPayRevenue] = useState('');
  const [formPayRoyaltyAmount, setFormPayRoyaltyAmount] = useState('');
  const [formPayReceiptNumber, setFormPayReceiptNumber] = useState('');

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  /* ── Data Fetching ── */

  const fetchContracts = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = new URLSearchParams();
      if (filterStatus && filterStatus !== 'all') params.set('status', filterStatus);

      const res = await fetch(`/api/admin/franchise?${params.toString()}`);
      if (!res.ok) throw new Error('خطا در دریافت قراردادها');
      const data = await res.json();
      setContracts(data.contracts || []);
      setStats(data.stats || null);
    } catch (err) {
      console.error('Fetch contracts error:', err);
      setError('خطا در دریافت اطلاعات قراردادها');
    } finally {
      setLoading(false);
    }
  }, [filterStatus]);

  const fetchTenants = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/tenants');
      if (!res.ok) return;
      const data = await res.json();
      const opts: TenantOption[] = (data.tenants || []).map((t: { id: string; name: string; primaryColor?: string }) => ({
        id: t.id,
        name: t.name,
        primaryColor: t.primaryColor,
      }));
      setTenants(opts);
    } catch {
      // silently fail
    }
  }, []);

  const fetchPayments = useCallback(async (contractId: string) => {
    setPaymentsLoading(true);
    try {
      const res = await fetch(`/api/admin/franchise/${contractId}/payments`);
      if (!res.ok) throw new Error('خطا در دریافت پرداخت‌ها');
      const data = await res.json();
      setPayments(data.payments || []);
    } catch {
      setPayments([]);
    } finally {
      setPaymentsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContracts();
  }, [fetchContracts]);

  useEffect(() => {
    fetchTenants();
  }, [fetchTenants]);

  /* ── Filtered Contracts ── */

  const filteredContracts = contracts.filter((c) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      c.contractNumber.toLowerCase().includes(q) ||
      c.tenant.name.toLowerCase().includes(q) ||
      c.parentTenant.name.toLowerCase().includes(q)
    );
  });

  /* ── Handlers ── */

  const resetCreateForm = useCallback(() => {
    setFormTenantId('');
    setFormParentTenantId('');
    setFormContractNumber('');
    setFormStartDate('');
    setFormEndDate('');
    setFormRoyaltyPercent('');
    setFormFixedRoyalty('');
    setFormMinRevenue('');
    setFormNotes('');
  }, []);

  const handleCreateContract = async () => {
    if (!formTenantId || !formParentTenantId || !formContractNumber || !formStartDate || !formEndDate) {
      showToast('لطفاً فیلدهای الزامی را پر کنید', 'error');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/admin/franchise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: formTenantId,
          parentTenantId: formParentTenantId,
          contractNumber: formContractNumber,
          startDate: formStartDate,
          endDate: formEndDate,
          royaltyPercent: formRoyaltyPercent ? parseFloat(formRoyaltyPercent) : 0,
          fixedRoyalty: formFixedRoyalty ? parseFloat(formFixedRoyalty) : null,
          minRevenue: formMinRevenue ? parseFloat(formMinRevenue) : null,
          notes: formNotes || null,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'خطا در ایجاد قرارداد');
      }

      showToast('قرارداد با موفقیت ایجاد شد');
      setCreateDialogOpen(false);
      resetCreateForm();
      fetchContracts();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'خطا در ایجاد قرارداد', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleViewDetails = (contract: FranchiseContract) => {
    setSelectedContract(contract);
    setDetailsDialogOpen(true);
    fetchPayments(contract.id);
  };

  const handleEditStatus = (contract: FranchiseContract) => {
    setEditContractId(contract.id);
    setEditStatus(contract.status);
    setEditStatusDialogOpen(true);
  };

  const handleUpdateStatus = async () => {
    setEditSubmitting(true);
    try {
      const res = await fetch(`/api/admin/franchise/${editContractId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: editStatus }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'خطا در به‌روزرسانی وضعیت');

      showToast('وضعیت قرارداد با موفقیت به‌روزرسانی شد');
      setEditStatusDialogOpen(false);
      fetchContracts();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'خطا در به‌روزرسانی وضعیت', 'error');
    } finally {
      setEditSubmitting(false);
    }
  };

  const handleOpenPaymentDialog = () => {
    setFormPayPeriodStart('');
    setFormPayPeriodEnd('');
    setFormPayRevenue('');
    setFormPayRoyaltyAmount('');
    setFormPayReceiptNumber('');
    setPaymentDialogOpen(true);
  };

  // Auto-calculate royalty when revenue changes
  const handleRevenueChange = (value: string) => {
    setFormPayRevenue(value);
    if (selectedContract && value && !formPayRoyaltyAmount) {
      const revenue = parseFloat(value);
      if (!isNaN(revenue) && selectedContract.royaltyPercent) {
        let calculated = (revenue * selectedContract.royaltyPercent) / 100;
        if (selectedContract.fixedRoyalty) {
          calculated += selectedContract.fixedRoyalty;
        }
        setFormPayRoyaltyAmount(calculated.toFixed(0));
      }
    }
  };

  const handleRecordPayment = async () => {
    if (!formPayPeriodStart || !formPayPeriodEnd) {
      showToast('تاریخ شروع و پایان دوره الزامی است', 'error');
      return;
    }

    setPaymentSubmitting(true);
    try {
      const res = await fetch(`/api/admin/franchise/${selectedContract?.id}/payments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          periodStart: formPayPeriodStart,
          periodEnd: formPayPeriodEnd,
          revenue: formPayRevenue ? parseFloat(formPayRevenue) : 0,
          royaltyAmount: formPayRoyaltyAmount ? parseFloat(formPayRoyaltyAmount) : undefined,
          receiptNumber: formPayReceiptNumber || null,
          status: 'PAID',
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'خطا در ثبت پرداخت');

      showToast('پرداخت با موفقیت ثبت شد');
      setPaymentDialogOpen(false);
      if (selectedContract) {
        fetchPayments(selectedContract.id);
      }
      fetchContracts();
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : 'خطا در ثبت پرداخت', 'error');
    } finally {
      setPaymentSubmitting(false);
    }
  };

  /* ─────────── Render ─────────── */

  return (
    <div dir="rtl" className="space-y-6">
      {/* Toast notification */}
      {toast && (
        <div
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 rounded-lg shadow-lg text-white text-sm font-medium transition-all ${
            toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'
          }`}
        >
          {toast.message}
        </div>
      )}

      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-xl bg-teal-100 flex items-center justify-center">
            <Store className="h-6 w-6 text-teal-700" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-900">مدیریت فرانچایز</h1>
            <p className="text-sm text-gray-500">سیستم فرانچایز — قراردادها، حق‌الامتیاز و گزارش‌ها</p>
          </div>
        </div>
        <Button onClick={() => setCreateDialogOpen(true)} className="gap-2 bg-teal-600 hover:bg-teal-700">
          <Plus className="h-4 w-4" />
          قرارداد جدید
        </Button>
      </div>

      {/* ── Stats Cards ── */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="کل قراردادها"
            value={toPersianNumber(stats.total.toString())}
            icon={FileText}
            color="text-teal-700"
            bgColor="bg-teal-100"
          />
          <StatCard
            title="فعال"
            value={toPersianNumber(stats.active.toString())}
            icon={CheckCircle2}
            color="text-green-700"
            bgColor="bg-green-100"
          />
          <StatCard
            title="در انتظار"
            value={toPersianNumber(stats.pending.toString())}
            icon={Clock}
            color="text-blue-700"
            bgColor="bg-blue-100"
          />
          <StatCard
            title="کل حق‌الامتیاز"
            value={formatRial(stats.totalRoyalty)}
            icon={DollarSign}
            color="text-amber-700"
            bgColor="bg-amber-100"
          />
        </div>
      )}

      {/* ── Filters ── */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="جستجو در شماره قرارداد، نام فرانچایزگیرنده..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* ── Error State ── */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4 flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            <p className="text-sm text-red-700">{error}</p>
            <Button variant="outline" size="sm" onClick={fetchContracts} className="mr-auto">
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      )}

      {/* ── Contracts Table ── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold">قراردادهای فرانچایز</CardTitle>
          <CardDescription>
            {toPersianNumber(filteredContracts.length.toString())} قرارداد
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-6 w-16" />
                </div>
              ))}
            </div>
          ) : filteredContracts.length === 0 ? (
            <div className="p-12 text-center">
              <Store className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">قرارداد فرانچایزی یافت نشد</p>
              <Button
                variant="outline"
                className="mt-3 gap-2"
                onClick={() => {
                  setFilterStatus('all');
                  setSearch('');
                }}
              >
                پاک کردن فیلترها
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 hover:bg-gray-50">
                    <TableHead className="text-xs font-semibold">شماره قرارداد</TableHead>
                    <TableHead className="text-xs font-semibold">فرانچایزگیرنده</TableHead>
                    <TableHead className="text-xs font-semibold">فرانچایزدهنده</TableHead>
                    <TableHead className="text-xs font-semibold">درصد حق‌الامتیاز</TableHead>
                    <TableHead className="text-xs font-semibold">حق‌الامتیاز ثابت</TableHead>
                    <TableHead className="text-xs font-semibold">وضعیت</TableHead>
                    <TableHead className="text-xs font-semibold">تاریخ شروع/پایان</TableHead>
                    <TableHead className="text-xs font-semibold">تعداد پرداخت</TableHead>
                    <TableHead className="text-xs font-semibold">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredContracts.map((contract) => (
                    <TableRow key={contract.id} className="hover:bg-gray-50/50">
                      <TableCell className="font-bold text-sm">
                        {contract.contractNumber}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span
                            className="h-2.5 w-2.5 rounded-full inline-block"
                            style={{ backgroundColor: contract.tenant.primaryColor || '#0d9488' }}
                          />
                          <span className="text-sm">{contract.tenant.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {contract.parentTenant.name}
                      </TableCell>
                      <TableCell className="text-sm">
                        {toPersianNumber(contract.royaltyPercent.toString())}٪
                      </TableCell>
                      <TableCell className="text-sm">
                        {contract.fixedRoyalty ? formatRial(contract.fixedRoyalty) : '—'}
                      </TableCell>
                      <TableCell>{getStatusBadge(contract.status)}</TableCell>
                      <TableCell className="text-xs text-gray-500">
                        <div>{formatPersianDate(contract.startDate)}</div>
                        <div>{formatPersianDate(contract.endDate)}</div>
                      </TableCell>
                      <TableCell className="text-sm text-center">
                        {toPersianNumber((contract._count?.payments || 0).toString())}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-teal-600"
                            onClick={() => handleViewDetails(contract)}
                            title="مشاهده جزئیات"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-blue-600"
                            onClick={() => handleEditStatus(contract)}
                            title="تغییر وضعیت"
                          >
                            <Edit3 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Create Contract Dialog ── */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Store className="h-5 w-5 text-teal-600" />
              ایجاد قرارداد فرانچایز جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* فرانچایزگیرنده */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  فرانچایزگیرنده <span className="text-red-500">*</span>
                </Label>
                <Select value={formTenantId} onValueChange={setFormTenantId}>
                  <SelectTrigger>
                    <SelectValue placeholder="انتخاب فرانچایزگیرنده..." />
                  </SelectTrigger>
                  <SelectContent className="max-h-48">
                    {tenants.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        <div className="flex items-center gap-2">
                          <span
                            className="h-2 w-2 rounded-full"
                            style={{ backgroundColor: t.primaryColor || '#0d9488' }}
                          />
                          {t.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* فرانچایزدهنده */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  فرانچایزدهنده <span className="text-red-500">*</span>
                </Label>
                <Select value={formParentTenantId} onValueChange={setFormParentTenantId}>
                  <SelectTrigger>
                    <SelectValue placeholder="انتخاب فرانچایزدهنده..." />
                  </SelectTrigger>
                  <SelectContent className="max-h-48">
                    {tenants.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* شماره قرارداد */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  شماره قرارداد <span className="text-red-500">*</span>
                </Label>
                <Input
                  value={formContractNumber}
                  onChange={(e) => setFormContractNumber(e.target.value)}
                  placeholder="مثلاً: FR-1403-001"
                />
              </div>

              {/* درصد حق‌الامتیاز */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">درصد حق‌الامتیاز</Label>
                <div className="relative">
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formRoyaltyPercent}
                    onChange={(e) => setFormRoyaltyPercent(e.target.value)}
                    placeholder="مثلاً: ۵"
                    className="pl-10"
                  />
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">٪</span>
                </div>
              </div>

              {/* تاریخ شروع */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  تاریخ شروع <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="date"
                  value={formStartDate}
                  onChange={(e) => setFormStartDate(e.target.value)}
                />
              </div>

              {/* تاریخ پایان */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  تاریخ پایان <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="date"
                  value={formEndDate}
                  onChange={(e) => setFormEndDate(e.target.value)}
                />
              </div>

              {/* حق‌الامتیاز ثابت ماهانه */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">حق‌الامتیاز ثابت ماهانه (ریال)</Label>
                <Input
                  type="number"
                  min="0"
                  value={formFixedRoyalty}
                  onChange={(e) => setFormFixedRoyalty(e.target.value)}
                  placeholder="اختیاری"
                />
              </div>

              {/* حداقل درآمد تعهدی */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">حداقل درآمد تعهدی (ریال)</Label>
                <Input
                  type="number"
                  min="0"
                  value={formMinRevenue}
                  onChange={(e) => setFormMinRevenue(e.target.value)}
                  placeholder="اختیاری"
                />
              </div>
            </div>

            {/* یادداشت */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">یادداشت</Label>
              <Textarea
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                placeholder="توضیحات اضافی درباره قرارداد..."
                rows={3}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setCreateDialogOpen(false);
                resetCreateForm();
              }}
              disabled={submitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleCreateContract}
              disabled={submitting}
              className="gap-2 bg-teal-600 hover:bg-teal-700"
            >
              {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
              ایجاد قرارداد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Edit Status Dialog ── */}
      <Dialog open={editStatusDialogOpen} onOpenChange={setEditStatusDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit3 className="h-5 w-5 text-blue-600" />
              تغییر وضعیت قرارداد
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-sm font-medium">وضعیت جدید</Label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CONTRACT_STATUS_EDIT_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      <div className="flex items-center gap-2">
                        <span
                          className={`h-2 w-2 rounded-full ${
                            opt.value === 'ACTIVE'
                              ? 'bg-green-500'
                              : opt.value === 'PENDING'
                              ? 'bg-blue-500'
                              : opt.value === 'EXPIRED'
                              ? 'bg-gray-400'
                              : 'bg-red-500'
                          }`}
                        />
                        {opt.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setEditStatusDialogOpen(false)}
              disabled={editSubmitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleUpdateStatus}
              disabled={editSubmitting}
              className="gap-2 bg-blue-600 hover:bg-blue-700"
            >
              {editSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
              به‌روزرسانی
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Payment Details Dialog ── */}
      <Dialog open={detailsDialogOpen} onOpenChange={setDetailsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-teal-600" />
              جزئیات قرارداد و پرداخت‌ها
            </DialogTitle>
          </DialogHeader>

          {selectedContract && (
            <div className="space-y-4">
              {/* Contract Info */}
              <Card className="border-teal-200 bg-teal-50/30">
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div>
                      <p className="text-xs text-gray-500 mb-1">شماره قرارداد</p>
                      <p className="font-bold text-sm">{selectedContract.contractNumber}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">فرانچایزگیرنده</p>
                      <div className="flex items-center gap-1.5">
                        <span
                          className="h-2 w-2 rounded-full"
                          style={{ backgroundColor: selectedContract.tenant.primaryColor || '#0d9488' }}
                        />
                        <p className="text-sm font-medium">{selectedContract.tenant.name}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">فرانچایزدهنده</p>
                      <p className="text-sm">{selectedContract.parentTenant.name}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">وضعیت</p>
                      {getStatusBadge(selectedContract.status)}
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">درصد حق‌الامتیاز</p>
                      <p className="text-sm font-medium">{toPersianNumber(selectedContract.royaltyPercent.toString())}٪</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">حق‌الامتیاز ثابت</p>
                      <p className="text-sm">
                        {selectedContract.fixedRoyalty ? formatRial(selectedContract.fixedRoyalty) : '—'}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">تاریخ شروع</p>
                      <p className="text-sm flex items-center gap-1">
                        <CalendarDays className="h-3.5 w-3.5 text-gray-400" />
                        {formatPersianDate(selectedContract.startDate)}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">تاریخ پایان</p>
                      <p className="text-sm flex items-center gap-1">
                        <CalendarDays className="h-3.5 w-3.5 text-gray-400" />
                        {formatPersianDate(selectedContract.endDate)}
                      </p>
                    </div>
                  </div>
                  {selectedContract.minRevenue && (
                    <div className="mt-3 pt-3 border-t border-teal-200/60">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-teal-600" />
                        <span className="text-xs text-gray-500">حداقل درآمد تعهدی:</span>
                        <span className="text-sm font-medium">{formatRial(selectedContract.minRevenue)}</span>
                      </div>
                    </div>
                  )}
                  {selectedContract.notes && (
                    <div className="mt-3 pt-3 border-t border-teal-200/60">
                      <p className="text-xs text-gray-500 mb-1">یادداشت:</p>
                      <p className="text-sm text-gray-700">{selectedContract.notes}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Separator />

              {/* Payments Header */}
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-gray-900">پرداخت‌های حق‌الامتیاز</h3>
                  <p className="text-xs text-gray-500">
                    {toPersianNumber(payments.length.toString())} پرداخت ثبت شده
                  </p>
                </div>
                <Button
                  onClick={handleOpenPaymentDialog}
                  size="sm"
                  className="gap-1.5 bg-teal-600 hover:bg-teal-700"
                >
                  <Plus className="h-3.5 w-3.5" />
                  ثبت پرداخت جدید
                </Button>
              </div>

              {/* Payments Table */}
              {paymentsLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-4 p-3">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-16" />
                    </div>
                  ))}
                </div>
              ) : payments.length === 0 ? (
                <div className="text-center py-8">
                  <CreditCard className="h-10 w-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">هنوز پرداختی ثبت نشده است</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-gray-200">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50 hover:bg-gray-50">
                        <TableHead className="text-xs font-semibold">دوره</TableHead>
                        <TableHead className="text-xs font-semibold">درآمد</TableHead>
                        <TableHead className="text-xs font-semibold">مبلغ حق‌الامتیاز</TableHead>
                        <TableHead className="text-xs font-semibold">وضعیت</TableHead>
                        <TableHead className="text-xs font-semibold">تاریخ پرداخت</TableHead>
                        <TableHead className="text-xs font-semibold">شماره رسید</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {payments.map((payment) => (
                        <TableRow key={payment.id} className="hover:bg-gray-50/50">
                          <TableCell className="text-xs">
                            <div>{formatPersianDate(payment.periodStart)}</div>
                            <div className="text-gray-400">تا {formatPersianDate(payment.periodEnd)}</div>
                          </TableCell>
                          <TableCell className="text-sm">
                            {payment.revenue ? formatRial(payment.revenue) : '—'}
                          </TableCell>
                          <TableCell className="text-sm font-medium">
                            {formatRial(payment.royaltyAmount)}
                          </TableCell>
                          <TableCell>{getPaymentStatusBadge(payment.status)}</TableCell>
                          <TableCell className="text-xs text-gray-500">
                            {payment.paidAt ? formatPersianDate(payment.paidAt) : '—'}
                          </TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {payment.receiptNumber || '—'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailsDialogOpen(false)}>
              بستن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Record Payment Dialog ── */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-teal-600" />
              ثبت پرداخت حق‌الامتیاز
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* تاریخ شروع دوره */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  شروع دوره <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="date"
                  value={formPayPeriodStart}
                  onChange={(e) => setFormPayPeriodStart(e.target.value)}
                />
              </div>

              {/* تاریخ پایان دوره */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">
                  پایان دوره <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="date"
                  value={formPayPeriodEnd}
                  onChange={(e) => setFormPayPeriodEnd(e.target.value)}
                />
              </div>

              {/* درآمد دوره */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">درآمد دوره (ریال)</Label>
                <Input
                  type="number"
                  min="0"
                  value={formPayRevenue}
                  onChange={(e) => handleRevenueChange(e.target.value)}
                  placeholder="درآمد این دوره"
                />
              </div>

              {/* مبلغ حق‌الامتیاز */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">مبلغ حق‌الامتیاز (ریال)</Label>
                <Input
                  type="number"
                  min="0"
                  value={formPayRoyaltyAmount}
                  onChange={(e) => setFormPayRoyaltyAmount(e.target.value)}
                  placeholder="خودکار محاسبه می‌شود"
                />
              </div>
            </div>

            {/* شماره رسید */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">شماره رسید</Label>
              <Input
                value={formPayReceiptNumber}
                onChange={(e) => setFormPayReceiptNumber(e.target.value)}
                placeholder="شماره رسید پرداخت"
              />
            </div>

            {selectedContract && (
              <div className="p-3 bg-gray-50 rounded-lg text-xs text-gray-600 space-y-1">
                <p>
                  <span className="text-gray-500">قرارداد:</span>{' '}
                  {selectedContract.contractNumber} —{' '}
                  <span className="text-gray-500">درصد:</span>{' '}
                  {toPersianNumber(selectedContract.royaltyPercent.toString())}٪
                  {selectedContract.fixedRoyalty && (
                    <>
                      {' + '}
                      <span className="text-gray-500">ثابت:</span>{' '}
                      {formatRial(selectedContract.fixedRoyalty)}
                    </>
                  )}
                </p>
                <p className="text-gray-400">
                  اگر مبلغ حق‌الامتیاز را خالی بگذارید، بر اساس درصد و درآمد محاسبه می‌شود.
                </p>
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setPaymentDialogOpen(false)}
              disabled={paymentSubmitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleRecordPayment}
              disabled={paymentSubmitting}
              className="gap-2 bg-teal-600 hover:bg-teal-700"
            >
              {paymentSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
              ثبت پرداخت
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
