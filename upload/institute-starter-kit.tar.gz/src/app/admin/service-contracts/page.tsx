'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Shield,
  Plus,
  Search,
  Loader2,
  AlertTriangle,
  X,
  Eye,
  CheckCircle2,
  Ban,
  Clock,
  FileText,
  AlertOctagon,
  Wrench,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface ServiceActivity {
  id: string;
  title: string;
  description: string | null;
  type: string;
  priority: string;
  status: string;
  scheduledAt: string | null;
  completedAt: string | null;
  slaDeadline: string | null;
  slaBreached: boolean;
  assignedTo: string;
  hoursSpent: number;
  notes: string | null;
  createdAt: string;
}

interface Warranty {
  id: string;
  title: string;
  description: string | null;
  durationMonths: number;
  startDate: string;
  endDate: string;
  coverageDetails: string;
  maxClaims: number;
  claimsUsed: number;
  status: string;
  createdAt: string;
}

interface ServiceContract {
  id: string;
  contractNumber: string;
  leadId: string | null;
  karAmuzId: string | null;
  title: string;
  description: string | null;
  type: string;
  responseTimeHrs: number;
  resolutionTimeHrs: number;
  uptimeGuarantee: number | null;
  startDate: string;
  endDate: string | null;
  status: string;
  contractValue: number;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  lead?: { id: string; name: string; phone: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string; phone: string } | null;
  _count?: { serviceActivities: number; warranties: number };
  // Detail fields (fetched separately)
  serviceActivities?: ServiceActivity[];
  warranties?: Warranty[];
}

interface LeadOption {
  id: string;
  name: string;
}

interface KarAmuzOption {
  id: string;
  firstName: string;
  lastName: string;
}

/* ─────────── Constants ─────────── */

const STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  ACTIVE: { label: 'فعال', color: 'text-green-700', bgColor: 'bg-green-100' },
  EXPIRED: { label: 'منقضی', color: 'text-yellow-700', bgColor: 'bg-yellow-100' },
  TERMINATED: { label: 'فسخ شده', color: 'text-red-700', bgColor: 'bg-red-100' },
  DRAFT: { label: 'پیش‌نویس', color: 'text-gray-700', bgColor: 'bg-gray-100' },
};

const TYPE_META: Record<string, { label: string; color: string; bgColor: string }> = {
  SLA: { label: 'SLA', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  WARRANTY: { label: 'گارانتی', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  MAINTENANCE: { label: 'نگهداری', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  SUPPORT: { label: 'پشتیبانی', color: 'text-purple-700', bgColor: 'bg-purple-100' },
};

const STATUS_OPTIONS = [
  { value: 'all', label: 'همه وضعیت‌ها' },
  { value: 'ACTIVE', label: 'فعال' },
  { value: 'EXPIRED', label: 'منقضی' },
  { value: 'TERMINATED', label: 'فسخ شده' },
  { value: 'DRAFT', label: 'پیش‌نویس' },
];

const TYPE_OPTIONS = [
  { value: 'SLA', label: 'SLA' },
  { value: 'WARRANTY', label: 'گارانتی' },
  { value: 'MAINTENANCE', label: 'نگهداری' },
  { value: 'SUPPORT', label: 'پشتیبانی' },
];

const ACTIVITY_STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  IN_PROGRESS: { label: 'در حال انجام', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  COMPLETED: { label: 'تکمیل شده', color: 'text-green-700', bgColor: 'bg-green-100' },
  CANCELLED: { label: 'لغو شده', color: 'text-red-700', bgColor: 'bg-red-100' },
};

/* ─────────── Helpers ─────────── */

function formatToman(amount: number) {
  const toman = Math.round(amount / 10);
  return toPersianNumber(toman.toLocaleString('en-US')) + ' تومان';
}

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function getRelatedName(contract: ServiceContract): string {
  if (contract.lead) return contract.lead.name;
  if (contract.karAmuz) return `${contract.karAmuz.firstName} ${contract.karAmuz.lastName}`;
  return '-';
}

/* ─────────── Main Component ─────────── */

export default function ServiceContractsPage() {
  /* ── State ── */
  const [contracts, setContracts] = useState<ServiceContract[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Add dialog
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formLeadId, setFormLeadId] = useState('');
  const [formKarAmuzId, setFormKarAmuzId] = useState('');
  const [formTitle, setFormTitle] = useState('');
  const [formType, setFormType] = useState('SLA');
  const [formResponseTimeHrs, setFormResponseTimeHrs] = useState(24);
  const [formResolutionTimeHrs, setFormResolutionTimeHrs] = useState(72);
  const [formStartDate, setFormStartDate] = useState('');
  const [formEndDate, setFormEndDate] = useState('');
  const [formContractValue, setFormContractValue] = useState(0);
  const [formNotes, setFormNotes] = useState('');

  // Lead/KarAmuz search
  const [leadOptions, setLeadOptions] = useState<LeadOption[]>([]);
  const [karAmuzOptions, setKarAmuzOptions] = useState<KarAmuzOption[]>([]);
  const [leadSearch, setLeadSearch] = useState('');
  const [karAmuzSearch, setKarAmuzSearch] = useState('');
  const [leadsLoading, setLeadsLoading] = useState(false);
  const [karAmuzLoading, setKarAmuzLoading] = useState(false);

  // Detail dialog
  const [detailContract, setDetailContract] = useState<ServiceContract | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [statusSubmitting, setStatusSubmitting] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);

  /* ── Data fetching ── */

  const fetchContracts = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (search) params.set('search', search);
      if (filterStatus && filterStatus !== 'all') params.set('status', filterStatus);

      const res = await fetch(`/api/crm/service-contracts?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت قراردادها');
        return;
      }

      setContracts(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterStatus]);

  useEffect(() => {
    fetchContracts();
  }, [fetchContracts]);

  const fetchLeads = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setLeadOptions([]); return; }
    setLeadsLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/leads?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setLeadOptions((data['داده‌ها'] || []).map((l: { id: string; name: string }) => ({ id: l.id, name: l.name })));
      }
    } catch { /* silent */ } finally { setLeadsLoading(false); }
  }, []);

  const fetchKarAmuz = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setKarAmuzOptions([]); return; }
    setKarAmuzLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/karamuz?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setKarAmuzOptions((data['داده‌ها'] || []).map((k: { id: string; firstName: string; lastName: string }) => ({ id: k.id, firstName: k.firstName, lastName: k.lastName })));
      }
    } catch { /* silent */ } finally { setKarAmuzLoading(false); }
  }, []);

  /* ── Computed ── */

  const stats = useMemo(() => ({
    total: contracts.length,
    ACTIVE: contracts.filter(c => c.status === 'ACTIVE').length,
    EXPIRED: contracts.filter(c => c.status === 'EXPIRED').length,
    DRAFT: contracts.filter(c => c.status === 'DRAFT').length,
    slaBreached: contracts.reduce((sum, c) => sum + (c.serviceActivities?.filter(a => a.slaBreached).length ?? 0), 0),
  }), [contracts]);

  /* ── Modal handlers ── */

  const openAddDialog = () => {
    setFormLeadId('');
    setFormKarAmuzId('');
    setFormTitle('');
    setFormType('SLA');
    setFormResponseTimeHrs(24);
    setFormResolutionTimeHrs(72);
    setFormStartDate('');
    setFormEndDate('');
    setFormContractValue(0);
    setFormNotes('');
    setLeadSearch('');
    setKarAmuzSearch('');
    setLeadOptions([]);
    setKarAmuzOptions([]);
    setAddDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formTitle.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/service-contracts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leadId: formLeadId || null,
          karAmuzId: formKarAmuzId || null,
          title: formTitle,
          type: formType,
          responseTimeHrs: formResponseTimeHrs,
          resolutionTimeHrs: formResolutionTimeHrs,
          startDate: formStartDate,
          endDate: formEndDate || null,
          contractValue: formContractValue,
          notes: formNotes || null,
        }),
      });

      if (res.ok) {
        setAddDialogOpen(false);
        fetchContracts();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const openDetail = async (contract: ServiceContract) => {
    setDetailContract(contract);
    setDetailDialogOpen(true);
    setDetailLoading(true);

    try {
      const res = await fetch(`/api/crm/service-contracts/${contract.id}`);
      const data = await res.json();
      if (res.ok) {
        setDetailContract(data['داده'] as ServiceContract);
      }
    } catch { /* silent */ } finally { setDetailLoading(false); }
  };

  const handleStatusChange = async (contractId: string, newStatus: string) => {
    setStatusSubmitting(true);
    try {
      const res = await fetch('/api/crm/service-contracts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contractId, status: newStatus }),
      });

      if (res.ok) {
        const data = await res.json();
        setDetailContract(data['داده'] as ServiceContract);
        fetchContracts();
      }
    } catch { /* silent */ } finally { setStatusSubmitting(false); }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Shield className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">قراردادهای خدمات</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(stats.total)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت قراردادهای SLA و خدمات</p>
          </div>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          قرارداد جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">فعال</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.ACTIVE)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">منقضی</p>
                <p className="text-2xl font-bold mt-1 text-yellow-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.EXPIRED)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-200">
                <Clock className="w-5 h-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">نقض SLA</p>
                <p className="text-2xl font-bold mt-1 text-red-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.slaBreached)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200">
                <AlertOctagon className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">در انتظار</p>
                <p className="text-2xl font-bold mt-1 text-gray-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.DRAFT)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-200">
                <FileText className="w-5 h-5 text-gray-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="جستجوی شماره، عنوان یا یادداشت..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10 bg-white"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-44 bg-white">
            <SelectValue placeholder="وضعیت" />
          </SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchContracts}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : contracts.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Shield className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">قراردادی یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با ایجاد قرارداد جدید شروع کنید
            </p>
            <Button
              onClick={openAddDialog}
              className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <Plus className="w-4 h-4" />
              قرارداد جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">شماره قرارداد</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عنوان</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">شخص مرتبط</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">نوع</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">زمان پاسخ</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">وضعیت</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">شروع</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">پایان</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {contracts.map((contract) => {
                  const statusMeta = STATUS_META[contract.status] || STATUS_META.DRAFT;
                  const typeMeta = TYPE_META[contract.type] || TYPE_META.SLA;
                  return (
                    <TableRow key={contract.id} className="hover:bg-gray-50/50">
                      <TableCell className="font-mono text-sm">
                        {contract.contractNumber}
                      </TableCell>
                      <TableCell className="text-sm font-medium">
                        {contract.title}
                      </TableCell>
                      <TableCell className="text-sm">
                        {getRelatedName(contract)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="secondary"
                          className={`${typeMeta.bgColor} ${typeMeta.color} text-xs border-0`}
                        >
                          {typeMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {toPersianNumber(contract.responseTimeHrs)} ساعت
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="secondary"
                          className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}
                        >
                          {statusMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatPersianDate(contract.startDate)}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {contract.endDate ? formatPersianDate(contract.endDate) : '-'}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                          onClick={() => openDetail(contract)}
                          title="مشاهده جزئیات"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Add Contract Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Shield className="w-5 h-5 text-teal-600" />
              قرارداد خدمات جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Lead search */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">لید مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder="جستجوی لید..."
                  value={leadSearch}
                  onChange={(e) => {
                    setLeadSearch(e.target.value);
                    fetchLeads(e.target.value);
                  }}
                />
                {leadsLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {leadOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {leadOptions.map((lead) => (
                    <button
                      key={lead.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-teal-50 transition-colors ${
                        formLeadId === lead.id ? 'bg-teal-50 text-teal-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormLeadId(lead.id);
                        setLeadSearch(lead.name);
                        setLeadOptions([]);
                      }}
                    >
                      {lead.name}
                    </button>
                  ))}
                </div>
              )}
              {formLeadId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                    {leadSearch}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => { setFormLeadId(''); setLeadSearch(''); }}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* KarAmuz search */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">کارآموز مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder="جستجوی کارآموز..."
                  value={karAmuzSearch}
                  onChange={(e) => {
                    setKarAmuzSearch(e.target.value);
                    fetchKarAmuz(e.target.value);
                  }}
                />
                {karAmuzLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {karAmuzOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {karAmuzOptions.map((ka) => (
                    <button
                      key={ka.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-purple-50 transition-colors ${
                        formKarAmuzId === ka.id ? 'bg-purple-50 text-purple-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormKarAmuzId(ka.id);
                        setKarAmuzSearch(`${ka.firstName} ${ka.lastName}`);
                        setKarAmuzOptions([]);
                      }}
                    >
                      {ka.firstName} {ka.lastName}
                    </button>
                  ))}
                </div>
              )}
              {formKarAmuzId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-purple-50 text-purple-700 text-xs">
                    {karAmuzSearch}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => { setFormKarAmuzId(''); setKarAmuzSearch(''); }}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* Title */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">عنوان قرارداد *</Label>
              <Input
                placeholder="عنوان قرارداد..."
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
              />
            </div>

            {/* Type + Contract Value */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نوع قرارداد</Label>
                <Select value={formType} onValueChange={setFormType}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPE_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">ارزش قرارداد (ریال)</Label>
                <Input
                  type="number"
                  min={0}
                  placeholder="ارزش قرارداد..."
                  value={formContractValue || ''}
                  onChange={(e) => setFormContractValue(parseInt(e.target.value) || 0)}
                />
              </div>
            </div>

            {/* SLA Times */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">زمان پاسخ‌دهی (ساعت)</Label>
                <Input
                  type="number"
                  min={1}
                  value={formResponseTimeHrs || ''}
                  onChange={(e) => setFormResponseTimeHrs(parseInt(e.target.value) || 24)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">زمان رفع مشکل (ساعت)</Label>
                <Input
                  type="number"
                  min={1}
                  value={formResolutionTimeHrs || ''}
                  onChange={(e) => setFormResolutionTimeHrs(parseInt(e.target.value) || 72)}
                />
              </div>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">تاریخ شروع *</Label>
                <Input
                  type="date"
                  value={formStartDate}
                  onChange={(e) => setFormStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">تاریخ پایان</Label>
                <Input
                  type="date"
                  value={formEndDate}
                  onChange={(e) => setFormEndDate(e.target.value)}
                />
              </div>
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">یادداشت</Label>
              <Textarea
                placeholder="یادداشت..."
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !formTitle.trim()}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ثبت قرارداد
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
          {detailContract && (() => {
            const statusMeta = STATUS_META[detailContract.status] || STATUS_META.DRAFT;
            const typeMeta = TYPE_META[detailContract.type] || TYPE_META.SLA;
            const activities = detailContract.serviceActivities || [];
            const warranties = detailContract.warranties || [];
            const breachedActivities = activities.filter(a => a.slaBreached);

            return (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2 text-right">
                    <Shield className="w-5 h-5 text-teal-600" />
                    جزئیات قرارداد {detailContract.contractNumber}
                  </DialogTitle>
                </DialogHeader>

                <div className="space-y-4 py-2">
                  {/* Status + info */}
                  <div className="flex flex-wrap items-center gap-3">
                    <Badge className={`${statusMeta.bgColor} ${statusMeta.color} text-sm border-0`}>
                      {statusMeta.label}
                    </Badge>
                    <Badge className={`${typeMeta.bgColor} ${typeMeta.color} text-sm border-0`}>
                      {typeMeta.label}
                    </Badge>
                    <span className="text-sm text-gray-600">
                      {detailContract.lead ? `لید: ${detailContract.lead.name}` :
                       detailContract.karAmuz ? `کارآموز: ${detailContract.karAmuz.firstName} ${detailContract.karAmuz.lastName}` : ''}
                    </span>
                  </div>

                  {/* Contract Info */}
                  <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                    <h3 className="text-sm font-bold text-gray-700 mb-2">اطلاعات قرارداد</h3>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <span className="text-gray-500">عنوان:</span>
                        <span className="font-medium mr-1">{detailContract.title}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">ارزش قرارداد:</span>
                        <span className="font-medium mr-1">{detailContract.contractValue > 0 ? formatToman(detailContract.contractValue) : '-'}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">زمان پاسخ‌دهی:</span>
                        <span className="font-medium mr-1">{toPersianNumber(detailContract.responseTimeHrs)} ساعت</span>
                      </div>
                      <div>
                        <span className="text-gray-500">زمان رفع مشکل:</span>
                        <span className="font-medium mr-1">{toPersianNumber(detailContract.resolutionTimeHrs)} ساعت</span>
                      </div>
                      <div>
                        <span className="text-gray-500">شروع:</span>
                        <span className="font-medium mr-1">{formatPersianDate(detailContract.startDate)}</span>
                      </div>
                      <div>
                        <span className="text-gray-500">پایان:</span>
                        <span className="font-medium mr-1">{detailContract.endDate ? formatPersianDate(detailContract.endDate) : '-'}</span>
                      </div>
                      {detailContract.uptimeGuarantee && (
                        <div>
                          <span className="text-gray-500">تضمین آپتایم:</span>
                          <span className="font-medium mr-1">{toPersianNumber(detailContract.uptimeGuarantee)}٪</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* SLA Breach Alert */}
                  {breachedActivities.length > 0 && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                      <div className="flex items-center gap-2 text-red-700 font-medium mb-1">
                        <AlertOctagon className="w-4 h-4" />
                        {toPersianNumber(breachedActivities.length)} فعالیت نقض SLA
                      </div>
                      <p className="text-xs text-red-600">
                        فعالیت‌های زیر مهلت SLA را نقض کرده‌اند و نیاز به پیگیری فوری دارند.
                      </p>
                    </div>
                  )}

                  {/* Activities List */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-bold text-gray-700">
                        فعالیت‌ها ({toPersianNumber(activities.length)})
                      </h3>
                    </div>
                    {detailLoading ? (
                      <div className="space-y-2">
                        {[...Array(3)].map((_, i) => (
                          <Skeleton key={i} className="h-12 rounded-lg" />
                        ))}
                      </div>
                    ) : activities.length === 0 ? (
                      <div className="text-sm text-gray-400 text-center py-4 bg-gray-50 rounded-lg">
                        فعالیتی ثبت نشده
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {activities.map((activity) => {
                          const actStatus = ACTIVITY_STATUS_META[activity.status] || ACTIVITY_STATUS_META.PENDING;
                          return (
                            <div
                              key={activity.id}
                              className={`border rounded-lg p-3 text-sm ${
                                activity.slaBreached ? 'border-red-200 bg-red-50/50' : 'border-gray-100 bg-white'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <Wrench className="w-4 h-4 text-gray-400" />
                                  <span className="font-medium">{activity.title}</span>
                                  {activity.slaBreached && (
                                    <Badge className="bg-red-100 text-red-700 text-xs border-0">نقض SLA</Badge>
                                  )}
                                </div>
                                <Badge className={`${actStatus.bgColor} ${actStatus.color} text-xs border-0`}>
                                  {actStatus.label}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                                <span>نوع: {activity.type}</span>
                                <span>اولویت: {activity.priority}</span>
                                {activity.slaDeadline && (
                                  <span>مهلت: {formatPersianDate(activity.slaDeadline)}</span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Warranties List */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-bold text-gray-700">
                        گارانتی‌ها ({toPersianNumber(warranties.length)})
                      </h3>
                    </div>
                    {detailLoading ? (
                      <div className="space-y-2">
                        {[...Array(2)].map((_, i) => (
                          <Skeleton key={i} className="h-12 rounded-lg" />
                        ))}
                      </div>
                    ) : warranties.length === 0 ? (
                      <div className="text-sm text-gray-400 text-center py-4 bg-gray-50 rounded-lg">
                        گارانتی ثبت نشده
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {warranties.map((warranty) => {
                          const wStatus = warranty.status === 'ACTIVE' ? { label: 'فعال', color: 'text-green-700', bgColor: 'bg-green-100' } :
                            warranty.status === 'EXPIRED' ? { label: 'منقضی', color: 'text-yellow-700', bgColor: 'bg-yellow-100' } :
                            warranty.status === 'VOIDED' ? { label: 'باطل', color: 'text-red-700', bgColor: 'bg-red-100' } :
                            { label: 'ادعا شده', color: 'text-blue-700', bgColor: 'bg-blue-100' };
                          return (
                            <div key={warranty.id} className="border border-gray-100 rounded-lg p-3 text-sm bg-white">
                              <div className="flex items-center justify-between">
                                <span className="font-medium">{warranty.title}</span>
                                <Badge className={`${wStatus.bgColor} ${wStatus.color} text-xs border-0`}>
                                  {wStatus.label}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                                <span>مدت: {toPersianNumber(warranty.durationMonths)} ماه</span>
                                {warranty.maxClaims > 0 && (
                                  <span>ادعا: {toPersianNumber(warranty.claimsUsed)}/{toPersianNumber(warranty.maxClaims)}</span>
                                )}
                                <span>پایان: {formatPersianDate(warranty.endDate)}</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Notes */}
                  {detailContract.notes && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 mb-1">يادداشت:</p>
                      <p className="text-sm text-gray-700 bg-gray-50 rounded-lg p-2">{detailContract.notes}</p>
                    </div>
                  )}

                  {/* Status change buttons */}
                  <div className="border-t pt-3 space-y-2">
                    <p className="text-xs font-bold text-gray-500">تغییر وضعیت:</p>
                    <div className="flex flex-wrap gap-2">
                      {detailContract.status === 'DRAFT' && (
                        <Button
                          size="sm"
                          onClick={() => handleStatusChange(detailContract.id, 'ACTIVE')}
                          disabled={statusSubmitting}
                          className="bg-green-600 hover:bg-green-700 text-white gap-1"
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          فعال‌سازی
                        </Button>
                      )}
                      {detailContract.status === 'ACTIVE' && (
                        <Button
                          size="sm"
                          onClick={() => handleStatusChange(detailContract.id, 'TERMINATED')}
                          disabled={statusSubmitting}
                          className="bg-red-600 hover:bg-red-700 text-white gap-1"
                        >
                          <Ban className="w-3 h-3" />
                          فسخ قرارداد
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
