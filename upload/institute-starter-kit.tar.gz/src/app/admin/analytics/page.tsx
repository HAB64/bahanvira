'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Heart,
  Clock,
  Star,
  Users,
  RefreshCw,
  ArrowDown,
  ArrowLeft,
  UserCheck,
  UserX,
  PhoneIncoming,
  Zap,
  Target,
  Award,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { toPersianNumber } from '@/lib/persian';

/* ═══════════════════════════════════════════════════════
   Types — matching the actual /api/crm/analytics response
   ═══════════════════════════════════════════════════════ */

interface FunnelStage {
  مرحله: string;
  تعداد: number;
  درصد: number;
}

interface CLVBySegment {
  بخش: string;
  میانگین_CLV: number;
  تعداد: number;
}

interface TopCustomer {
  id: string;
  name: string;
  phone: string;
  lifetimeValue: number;
  segment: string;
}

interface ConsultantResponse {
  مشاور: string;
  میانگین_پاسخ_دقیقه: number;
  تعداد_تماس: number;
}

interface MonthlyTrend {
  ماه: string;
  تعداد_لید: number;
  تعداد_ثبت‌نام: number;
  درآمد: number;
  نرخ_تبدیل: number;
}

interface SegmentDist {
  بخش: string;
  تعداد: number;
}

interface AnalyticsData {
  قیف_تبدیل: {
    مراحل: FunnelStage[];
    نرخ_تبدیل_کل: number;
  };
  ارزش_مشتری: {
    میانگین_CLV: number;
    CLV_بر_بخش: CLVBySegment[];
    برترین_مشتریان: TopCustomer[];
  };
  حفظ_مشتری: {
    فعال: number;
    ترک_کرده: number;
    نرخ_حفظ: number;
    میانگین_زمان_ترک_روز: number;
  };
  زمان_پاسخ: {
    میانگین_پاسخ_دقیقه: number;
    بر_مشاور: ConsultantResponse[];
  };
  رضایت: {
    میانگین_امتیاز: number;
    تعداد_نظرات: number;
    توزیع: Record<string, number>;
  };
  توزیع_بخش: SegmentDist[];
  روند_ماهانه: MonthlyTrend[];
}

/* ═══════════════════════════════════════════════════════
   Helpers
   ═══════════════════════════════════════════════════════ */

function formatRials(amount: number): string {
  const formatted = Math.round(amount).toLocaleString('en-US');
  return toPersianNumber(formatted) + ' ریال';
}

function formatTomanShort(amount: number): string {
  const toman = Math.round(amount / 10);
  if (toman >= 1_000_000) {
    const m = toman / 1_000_000;
    return toPersianNumber(m % 1 === 0 ? m.toFixed(0) : m.toFixed(1)) + ' میلیون تومان';
  }
  if (toman >= 1_000) {
    const k = toman / 1_000;
    return toPersianNumber(k % 1 === 0 ? k.toFixed(0) : k.toFixed(1)) + ' هزار تومان';
  }
  return toPersianNumber(toman.toLocaleString('en-US')) + ' تومان';
}

const FUNNEL_LABELS: Record<string, string> = {
  NEW: 'لید جدید',
  CONTACTED: 'تماس گرفته شده',
  INTERESTED: 'علاقه‌مند',
  ENROLLED: 'ثبت‌نام شده',
};

const FUNNEL_COLORS: Record<string, { bg: string; text: string; bar: string }> = {
  NEW: { bg: 'bg-blue-50', text: 'text-blue-700', bar: 'bg-gradient-to-l from-blue-500 to-blue-400' },
  CONTACTED: { bg: 'bg-teal-50', text: 'text-teal-700', bar: 'bg-gradient-to-l from-teal-500 to-teal-400' },
  INTERESTED: { bg: 'bg-emerald-50', text: 'text-emerald-700', bar: 'bg-gradient-to-l from-emerald-500 to-emerald-400' },
  ENROLLED: { bg: 'bg-green-50', text: 'text-green-700', bar: 'bg-gradient-to-l from-green-600 to-green-400' },
};

const SEGMENT_LABELS: Record<string, string> = {
  VIP: 'VIP',
  REGULAR: 'عادی',
  AT_RISK: 'در خطر',
  CHURNED: 'رها شده',
  NEW: 'جدید',
  LOYAL: 'وفادار',
  بدون_بخش: 'بدون بخش',
};

const SEGMENT_COLORS: Record<string, string> = {
  VIP: '#0d9488',
  REGULAR: '#6366f1',
  AT_RISK: '#f59e0b',
  CHURNED: '#ef4444',
  NEW: '#3b82f6',
  LOYAL: '#10b981',
  بدون_بخش: '#9ca3af',
};

/* ═══════════════════════════════════════════════════════
   Main Component
   ═══════════════════════════════════════════════════════ */

export default function AnalyticsDashboard() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/crm/analytics');
      const json = await res.json();
      if (!res.ok) {
        setError(json['خطا'] || 'خطا در دریافت داده‌ها');
        return;
      }
      setData(json['داده'] as AnalyticsData);
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Derived values
  const totalLeads = data
    ? data.قیف_تبدیل.مراحل.reduce((sum, s) => sum + s.تعداد, 0)
    : 0;

  /* ──── Loading skeleton ──── */
  if (loading) {
    return (
      <div className="space-y-6" dir="rtl">
        {/* Header skeleton */}
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-4 w-64" />
          </div>
          <Skeleton className="h-9 w-28" />
        </div>
        {/* KPI cards skeleton */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        {/* Funnel + CLV skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Skeleton className="h-72 rounded-xl" />
          <Skeleton className="h-72 rounded-xl" />
        </div>
        {/* Bottom sections skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-64 rounded-xl" />
        </div>
      </div>
    );
  }

  /* ──── Error state ──── */
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20" dir="rtl">
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center max-w-md">
          <p className="text-red-600 font-medium mb-2">{error}</p>
          <button
            onClick={fetchData}
            className="mt-3 inline-flex items-center gap-2 text-sm text-teal-600 hover:text-teal-700 font-medium"
          >
            <RefreshCw className="w-4 h-4" />
            تلاش مجدد
          </button>
        </div>
      </div>
    );
  }

  if (!data) return null;

  /* ──── Computed values for donut chart ──── */
  const segmentTotal = data.توزیع_بخش.reduce((s, seg) => s + seg.تعداد, 0);
  const conicSegments = data.توزیع_بخش
    .filter((seg) => seg.تعداد > 0)
    .map((seg) => {
      const pct = (seg.تعداد / segmentTotal) * 100;
      const color = SEGMENT_COLORS[seg.بخش] || '#9ca3af';
      return `${color} 0% ${pct}%`;
    });

  const conicGradient = `conic-gradient(${conicSegments.join(', ')})`;

  // Satisfaction total for distribution
  const satTotal = Object.values(data.رضایت.توزیع).reduce((s, v) => s + v, 0);

  return (
    <div className="space-y-6" dir="rtl">
      {/* ═══════════ Header ═══════════ */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-bl from-teal-500 to-teal-600 shadow-lg shadow-teal-200">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">داشبورد تحلیلی</h1>
            <p className="text-gray-500 mt-0.5 text-sm">شاخص‌های کلیدی عملکرد CRM</p>
          </div>
        </div>
        <button
          onClick={fetchData}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-teal-700 bg-teal-50 hover:bg-teal-100 border border-teal-200 rounded-lg transition-colors"
        >
          <RefreshCw className="w-4 h-4" />
          بروزرسانی
        </button>
      </div>

      {/* ═══════════ KPI Cards ═══════════ */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* 1. Conversion Rate */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-teal-500 to-teal-600 p-5 text-white shadow-lg shadow-teal-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-teal-100 text-sm font-medium">نرخ تبدیل کلی</p>
              <p className="text-3xl font-bold mt-2">
                {toPersianNumber(data.قیف_تبدیل.نرخ_تبدیل_کل)}
                <span className="text-lg mr-1">٪</span>
              </p>
              <p className="text-teal-200 text-xs mt-1">از لید تا ثبت‌نام</p>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 2. Average CLV */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-emerald-500 to-emerald-600 p-5 text-white shadow-lg shadow-emerald-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-emerald-100 text-sm font-medium">میانگین CLV</p>
              <p className="text-2xl font-bold mt-2">
                {formatTomanShort(data.ارزش_مشتری.میانگین_CLV)}
              </p>
              <p className="text-emerald-200 text-xs mt-1">ارزش طول عمر مشتری</p>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <DollarSign className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 3. Retention Rate */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-rose-500 to-rose-600 p-5 text-white shadow-lg shadow-rose-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-rose-100 text-sm font-medium">نرخ حفظ مشتری</p>
              <p className="text-3xl font-bold mt-2">
                {toPersianNumber(data.حفظ_مشتری.نرخ_حفظ)}
                <span className="text-lg mr-1">٪</span>
              </p>
              <p className="text-rose-200 text-xs mt-1">
                {toPersianNumber(data.حفظ_مشتری.فعال)} فعال از {toPersianNumber(data.حفظ_مشتری.فعال + data.حفظ_مشتری.ترک_کرده)} نفر
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <Heart className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 4. Average Response Time */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-blue-500 to-blue-600 p-5 text-white shadow-lg shadow-blue-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">میانگین زمان پاسخ</p>
              <p className="text-3xl font-bold mt-2">
                {data.زمان_پاسخ.میانگین_پاسخ_دقیقه >= 60
                  ? toPersianNumber(Math.floor(data.زمان_پاسخ.میانگین_پاسخ_دقیقه / 60))
                  : toPersianNumber(data.زمان_پاسخ.میانگین_پاسخ_دقیقه)}
                <span className="text-lg mr-1">
                  {data.زمان_پاسخ.میانگین_پاسخ_دقیقه >= 60 ? 'ساعت' : 'دقیقه'}
                </span>
              </p>
              <p className="text-blue-200 text-xs mt-1">تا اولین تماس</p>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <Clock className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 5. Satisfaction Score */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-amber-500 to-amber-600 p-5 text-white shadow-lg shadow-amber-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-amber-100 text-sm font-medium">امتیاز رضایت</p>
              <p className="text-3xl font-bold mt-2">
                {toPersianNumber(data.رضایت.میانگین_امتیاز)}
                <span className="text-lg mr-1">از ۵</span>
              </p>
              <p className="text-amber-200 text-xs mt-1">
                {toPersianNumber(data.رضایت.تعداد_نظرات)} نظر ثبت شده
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <Star className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* 6. Total Leads */}
        <div className="relative overflow-hidden rounded-xl bg-gradient-to-bl from-violet-500 to-violet-600 p-5 text-white shadow-lg shadow-violet-200/50">
          <div className="absolute -left-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
          <div className="relative flex items-start justify-between">
            <div>
              <p className="text-violet-100 text-sm font-medium">کل لیدها</p>
              <p className="text-3xl font-bold mt-2">{toPersianNumber(totalLeads)}</p>
              <p className="text-violet-200 text-xs mt-1">در قیف تبدیل</p>
            </div>
            <div className="p-2.5 rounded-xl bg-white/20 backdrop-blur-sm">
              <Users className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* ═══════════ Row 2: Funnel + CLV ═══════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* ── Conversion Funnel ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <Target className="w-5 h-5 text-teal-600" />
              قیف تبدیل
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              {data.قیف_تبدیل.مراحل.map((stage, idx) => {
                const meta = FUNNEL_COLORS[stage.مرحله] || FUNNEL_COLORS.NEW;
                const widthPct = Math.max(
                  (stage.تعداد / Math.max(...data.قیف_تبدیل.مراحل.map((s) => s.تعداد), 1)) * 100,
                  8
                );
                return (
                  <div key={stage.مرحله}>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span
                          className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold ${meta.bg} ${meta.text}`}
                        >
                          {toPersianNumber(idx + 1)}
                        </span>
                        <span className="text-sm font-medium text-gray-800">
                          {FUNNEL_LABELS[stage.مرحله] || stage.مرحله}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-bold text-gray-900">{toPersianNumber(stage.تعداد)}</span>
                        <span className="text-gray-400">|</span>
                        <span className={`${meta.text} font-medium`}>
                          {toPersianNumber(stage.درصد)}٪
                        </span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-8 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${meta.bar} transition-all duration-700 ease-out flex items-center justify-end px-3`}
                        style={{ width: `${widthPct}%` }}
                      >
                        {widthPct > 20 && (
                          <span className="text-white text-xs font-bold drop-shadow">
                            {toPersianNumber(stage.تعداد)}
                          </span>
                        )}
                      </div>
                    </div>
                    {/* Connector arrow */}
                    {idx < data.قیف_تبدیل.مراحل.length - 1 && (
                      <div className="flex justify-center my-1">
                        <ArrowDown className="w-4 h-4 text-gray-300" />
                      </div>
                    )}
                  </div>
                );
              })}
              {/* Overall rate badge */}
              <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between">
                <span className="text-sm text-gray-500">نرخ تبدیل کلی</span>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-sm font-bold">
                  <TrendingUp className="w-3.5 h-3.5" />
                  {toPersianNumber(data.قیف_تبدیل.نرخ_تبدیل_کل)}٪
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ── CLV Section ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <DollarSign className="w-5 h-5 text-emerald-600" />
              ارزش طول عمر مشتری (CLV)
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {/* Average CLV */}
            <div className="bg-emerald-50 rounded-lg p-3 mb-4 flex items-center justify-between">
              <span className="text-sm text-emerald-700 font-medium">میانگین CLV</span>
              <span className="text-lg font-bold text-emerald-800">
                {formatRials(data.ارزش_مشتری.میانگین_CLV)}
              </span>
            </div>

            {/* CLV by Segment */}
            {data.ارزش_مشتری.CLV_بر_بخش.length > 0 && (
              <div className="mb-4">
                <p className="text-xs font-bold text-gray-500 mb-2">CLV بر اساس بخش</p>
                <div className="space-y-2.5">
                  {data.ارزش_مشتری.CLV_بر_بخش.map((seg) => {
                    const maxCLV = Math.max(
                      ...data.ارزش_مشتری.CLV_بر_بخش.map((s) => s.میانگین_CLV),
                      1
                    );
                    const widthPct = (seg.میانگین_CLV / maxCLV) * 100;
                    const color =
                      seg.بخش === 'VIP'
                        ? 'bg-teal-500'
                        : seg.بخش === 'REGULAR'
                        ? 'bg-indigo-400'
                        : 'bg-amber-400';
                    return (
                      <div key={seg.بخش}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-medium text-gray-700">
                            {SEGMENT_LABELS[seg.بخش] || seg.بخش}
                            <span className="text-gray-400 mr-1">
                              ({toPersianNumber(seg.تعداد)} نفر)
                            </span>
                          </span>
                          <span className="text-xs font-bold text-gray-900">
                            {formatRials(seg.میانگین_CLV)}
                          </span>
                        </div>
                        <div className="w-full bg-gray-100 rounded-full h-3">
                          <div
                            className={`h-full rounded-full ${color} transition-all duration-700`}
                            style={{ width: `${widthPct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Top Customers */}
            {data.ارزش_مشتری.برترین_مشتریان.length > 0 && (
              <div>
                <p className="text-xs font-bold text-gray-500 mb-2">برترین مشتریان</p>
                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {data.ارزش_مشتری.برترین_مشتریان.slice(0, 5).map((customer, idx) => (
                    <div
                      key={customer.id}
                      className="flex items-center justify-between bg-gray-50 rounded-lg px-3 py-2"
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                            idx === 0
                              ? 'bg-amber-100 text-amber-700'
                              : idx === 1
                              ? 'bg-gray-200 text-gray-700'
                              : idx === 2
                              ? 'bg-orange-100 text-orange-700'
                              : 'bg-gray-100 text-gray-500'
                          }`}
                        >
                          {toPersianNumber(idx + 1)}
                        </span>
                        <span className="text-sm font-medium text-gray-800">
                          {customer.name || 'بدون نام'}
                        </span>
                      </div>
                      <span className="text-xs font-bold text-emerald-700">
                        {formatRials(customer.lifetimeValue)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ═══════════ Row 3: Retention + Response + Satisfaction ═══════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* ── Retention ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <Heart className="w-5 h-5 text-rose-500" />
              حفظ مشتری
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {/* Circular progress */}
            <div className="flex justify-center mb-4">
              <div className="relative w-36 h-36">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                  <circle
                    cx="60"
                    cy="60"
                    r="52"
                    fill="none"
                    stroke="#f3f4f6"
                    strokeWidth="10"
                  />
                  <circle
                    cx="60"
                    cy="60"
                    r="52"
                    fill="none"
                    stroke="#0d9488"
                    strokeWidth="10"
                    strokeLinecap="round"
                    strokeDasharray={`${(data.حفظ_مشتری.نرخ_حفظ / 100) * 326.73} 326.73`}
                    className="transition-all duration-1000 ease-out"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-2xl font-bold text-gray-900">
                    {toPersianNumber(data.حفظ_مشتری.نرخ_حفظ)}٪
                  </span>
                  <span className="text-xs text-gray-500">نرخ حفظ</span>
                </div>
              </div>
            </div>

            {/* Active vs Dropped */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-emerald-50 rounded-lg p-3 text-center">
                <UserCheck className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
                <p className="text-xl font-bold text-emerald-700">
                  {toPersianNumber(data.حفظ_مشتری.فعال)}
                </p>
                <p className="text-xs text-emerald-600">فعال</p>
              </div>
              <div className="bg-red-50 rounded-lg p-3 text-center">
                <UserX className="w-5 h-5 text-red-500 mx-auto mb-1" />
                <p className="text-xl font-bold text-red-700">
                  {toPersianNumber(data.حفظ_مشتری.ترک_کرده)}
                </p>
                <p className="text-xs text-red-600">ترک کرده</p>
              </div>
            </div>

            {/* Avg dropout time */}
            {data.حفظ_مشتری.میانگین_زمان_ترک_روز > 0 && (
              <div className="bg-gray-50 rounded-lg p-3 flex items-center gap-3">
                <Clock className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">میانگین زمان تا ترک</p>
                  <p className="text-sm font-bold text-gray-800">
                    {toPersianNumber(data.حفظ_مشتری.میانگین_زمان_ترک_روز)} روز
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ── Response Time ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <PhoneIncoming className="w-5 h-5 text-blue-500" />
              زمان پاسخ‌دهی
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {/* Average */}
            <div className="bg-blue-50 rounded-lg p-3 mb-4 flex items-center justify-between">
              <span className="text-sm text-blue-700 font-medium">میانگین پاسخ‌دهی</span>
              <span className="text-lg font-bold text-blue-800">
                {toPersianNumber(data.زمان_پاسخ.میانگین_پاسخ_دقیقه)} دقیقه
              </span>
            </div>

            {/* By Consultant */}
            {data.زمان_پاسخ.بر_مشاور.length > 0 ? (
              <div className="space-y-3">
                <p className="text-xs font-bold text-gray-500">بر اساس مشاور</p>
                {data.زمان_پاسخ.بر_مشاور.map((consultant) => {
                  const maxMin = Math.max(
                    ...data.زمان_پاسخ.بر_مشاور.map((c) => c.میانگین_پاسخ_دقیقه),
                    1
                  );
                  const widthPct = (consultant.میانگین_پاسخ_دقیقه / maxMin) * 100;
                  const isSlow = consultant.میانگین_پاسخ_دقیقه > 180;
                  const isMedium =
                    consultant.میانگین_پاسخ_دقیقه > 60 &&
                    consultant.میانگین_پاسخ_دقیقه <= 180;
                  const barColor = isSlow
                    ? 'bg-red-400'
                    : isMedium
                    ? 'bg-amber-400'
                    : 'bg-blue-400';
                  return (
                    <div key={consultant.مشاور}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-gray-700">
                          {consultant.مشاور === 'بدون_مشاور'
                            ? 'بدون مشاور'
                            : consultant.مشاور}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-gray-400">
                            {toPersianNumber(consultant.تعداد_تماس)} تماس
                          </span>
                          <span className="text-xs font-bold text-gray-900">
                            {toPersianNumber(consultant.میانگین_پاسخ_دقیقه)} دقیقه
                          </span>
                        </div>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-3">
                        <div
                          className={`h-full rounded-full ${barColor} transition-all duration-700`}
                          style={{ width: `${widthPct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-center text-gray-400 text-sm py-6">
                داده‌ای موجود نیست
              </p>
            )}
          </CardContent>
        </Card>

        {/* ── Satisfaction ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <Star className="w-5 h-5 text-amber-500" />
              رضایت مشتری
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {/* Star Rating Display */}
            <div className="flex flex-col items-center mb-5">
              <div className="flex items-center gap-1 mb-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-7 h-7 ${
                      star <= Math.round(data.رضایت.میانگین_امتیاز)
                        ? 'text-amber-400 fill-amber-400'
                        : star <= data.رضایت.میانگین_امتیاز + 0.5
                        ? 'text-amber-300 fill-amber-200'
                        : 'text-gray-200'
                    }`}
                  />
                ))}
              </div>
              <p className="text-3xl font-bold text-gray-900">
                {toPersianNumber(data.رضایت.میانگین_امتیاز)}
                <span className="text-base text-gray-400 mr-1">/ ۵</span>
              </p>
              <p className="text-xs text-gray-500 mt-0.5">
                بر اساس {toPersianNumber(data.رضایت.تعداد_نظرات)} نظر
              </p>
            </div>

            {/* Distribution */}
            <div className="space-y-2">
              {[5, 4, 3, 2, 1].map((score) => {
                const count = data.رضایت.توزیع[score] || 0;
                const pct = satTotal > 0 ? (count / satTotal) * 100 : 0;
                return (
                  <div key={score} className="flex items-center gap-2">
                    <span className="text-xs font-medium text-gray-600 w-4 text-center">
                      {toPersianNumber(score)}
                    </span>
                    <Star className="w-3 h-3 text-amber-400 fill-amber-400 flex-shrink-0" />
                    <div className="flex-1 bg-gray-100 rounded-full h-2.5">
                      <div
                        className="h-full rounded-full bg-amber-400 transition-all duration-700"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="text-xs text-gray-500 w-8 text-left font-medium">
                      {toPersianNumber(count)}
                    </span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ═══════════ Row 4: Monthly Trends + Segment Distribution ═══════════ */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* ── Monthly Trends ── */}
        <Card className="bg-white rounded-xl shadow-sm border lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <BarChart3 className="w-5 h-5 text-teal-600" />
              روند ماهانه
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {data.روند_ماهانه.length > 0 ? (
              <div>
                {/* Bar chart */}
                <div className="flex items-end gap-2 h-48 mb-4">
                  {data.روند_ماهانه.map((month) => {
                    const maxLead = Math.max(
                      ...data.روند_ماهانه.map((m) => m.تعداد_لید),
                      1
                    );
                    const leadH = (month.تعداد_لید / maxLead) * 100;
                    const enrollH =
                      month.تعداد_لید > 0
                        ? (month.تعداد_ثبت‌نام / month.تعداد_لید) * leadH
                        : 0;
                    return (
                      <div
                        key={month.ماه}
                        className="flex-1 flex flex-col items-center gap-1"
                      >
                        {/* Value label */}
                        <span className="text-[10px] font-bold text-teal-700">
                          {toPersianNumber(month.تعداد_لید)}
                        </span>
                        {/* Bar stack */}
                        <div className="w-full relative" style={{ height: '160px' }}>
                          <div className="absolute bottom-0 w-full flex flex-col justify-end h-full">
                            {/* Enrolled portion */}
                            <div
                              className="w-full bg-teal-500 rounded-t-sm transition-all duration-700 min-h-[2px]"
                              style={{ height: `${enrollH}%` }}
                            />
                            {/* Lead portion (total - enrolled) */}
                            <div
                              className="w-full bg-teal-200 rounded-t-sm transition-all duration-700 min-h-[2px]"
                              style={{
                                height: `${leadH - enrollH}%`,
                              }}
                            />
                          </div>
                        </div>
                        {/* Month label */}
                        <span className="text-[10px] text-gray-500 font-medium mt-1 truncate w-full text-center">
                          {month.ماه}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Legend */}
                <div className="flex items-center justify-center gap-4 mb-4">
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-sm bg-teal-200" />
                    <span className="text-xs text-gray-600">لید</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-3 h-3 rounded-sm bg-teal-500" />
                    <span className="text-xs text-gray-600">ثبت‌نام</span>
                  </div>
                </div>

                {/* Revenue & conversion table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-right">
                    <thead>
                      <tr className="border-b border-gray-100 text-gray-400 text-xs">
                        <th className="pb-2 pr-2">ماه</th>
                        <th className="pb-2 text-center">لید</th>
                        <th className="pb-2 text-center">ثبت‌نام</th>
                        <th className="pb-2 text-center">نرخ تبدیل</th>
                        <th className="pb-2 text-left pl-2">درآمد</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.روند_ماهانه.map((m) => (
                        <tr
                          key={m.ماه}
                          className="border-b border-gray-50 hover:bg-gray-50 transition-colors"
                        >
                          <td className="py-2 pr-2 font-medium text-gray-800">
                            {m.ماه}
                          </td>
                          <td className="py-2 text-center text-gray-700">
                            {toPersianNumber(m.تعداد_لید)}
                          </td>
                          <td className="py-2 text-center text-teal-700 font-medium">
                            {toPersianNumber(m.تعداد_ثبت‌نام)}
                          </td>
                          <td className="py-2 text-center">
                            <span
                              className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${
                                m.نرخ_تبدیل >= 30
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : m.نرخ_تبدیل >= 15
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-red-100 text-red-700'
                              }`}
                            >
                              {toPersianNumber(m.نرخ_تبدیل)}٪
                            </span>
                          </td>
                          <td className="py-2 text-left pl-2 text-emerald-700 font-medium text-xs">
                            {m.درآمد > 0 ? formatTomanShort(m.درآمد) : '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <p className="text-center text-gray-400 text-sm py-10">
                داده‌ای موجود نیست
              </p>
            )}
          </CardContent>
        </Card>

        {/* ── Segment Distribution ── */}
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <Award className="w-5 h-5 text-violet-500" />
              توزیع بخش‌ها
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {segmentTotal > 0 ? (
              <div>
                {/* Pie Chart using conic-gradient */}
                <div className="flex justify-center mb-5">
                  <div className="relative">
                    <div
                      className="w-40 h-40 rounded-full shadow-inner"
                      style={{ background: conicGradient }}
                    />
                    {/* Inner circle for donut effect */}
                    <div className="absolute inset-4 rounded-full bg-white flex items-center justify-center">
                      <div className="text-center">
                        <p className="text-xl font-bold text-gray-900">
                          {toPersianNumber(segmentTotal)}
                        </p>
                        <p className="text-[10px] text-gray-500">کل</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Legend */}
                <div className="space-y-2">
                  {data.توزیع_بخش
                    .filter((seg) => seg.تعداد > 0)
                    .map((seg) => {
                      const pct = segmentTotal > 0
                        ? Math.round((seg.تعداد / segmentTotal) * 100)
                        : 0;
                      const color = SEGMENT_COLORS[seg.بخش] || '#9ca3af';
                      return (
                        <div
                          key={seg.بخش}
                          className="flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className="w-3 h-3 rounded-full flex-shrink-0"
                              style={{ backgroundColor: color }}
                            />
                            <span className="text-sm text-gray-700 font-medium">
                              {SEGMENT_LABELS[seg.بخش] || seg.بخش}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-400">
                              {toPersianNumber(pct)}٪
                            </span>
                            <span className="text-sm font-bold text-gray-900">
                              {toPersianNumber(seg.تعداد)}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            ) : (
              <p className="text-center text-gray-400 text-sm py-10">
                داده‌ای موجود نیست
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ═══════════ Row 5: Funnel Conversion Drop Analysis ═══════════ */}
      {data.قیف_تبدیل.مراحل.length >= 2 && (
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base font-bold text-gray-900">
              <Zap className="w-5 h-5 text-amber-500" />
              تحلیل افت قیف تبدیل
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {data.قیف_تبدیل.مراحل.map((stage, idx) => {
                if (idx === 0) return null;
                const prev = data.قیف_تبدیل.مراحل[idx - 1];
                const dropRate =
                  prev.تعداد > 0
                    ? Math.round(
                        ((prev.تعداد - stage.تعداد) / prev.تعداد) * 100
                      )
                    : 0;
                const meta = FUNNEL_COLORS[stage.مرحله] || FUNNEL_COLORS.NEW;
                return (
                  <div
                    key={stage.مرحله}
                    className="bg-gray-50 rounded-lg p-3 flex items-center gap-3"
                  >
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-10 h-10 rounded-full ${meta.bg} flex items-center justify-center`}
                      >
                        <ArrowLeft className={`w-5 h-5 ${meta.text}`} />
                      </div>
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-gray-500">
                        {FUNNEL_LABELS[prev.مرحله] || prev.مرحله} →{' '}
                        {FUNNEL_LABELS[stage.مرحله] || stage.مرحله}
                      </p>
                      <p className="text-lg font-bold text-gray-900 mt-0.5">
                        {toPersianNumber(dropRate)}٪
                        <span className="text-xs text-red-500 mr-1">افت</span>
                      </p>
                      <p className="text-[10px] text-gray-400">
                        {toPersianNumber(prev.تعداد)} →{' '}
                        {toPersianNumber(stage.تعداد)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
