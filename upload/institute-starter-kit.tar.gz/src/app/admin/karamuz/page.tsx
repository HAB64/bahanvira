'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import {
  GraduationCap,
  Plus,
  Search,
  Users,
  UserCheck,
  Award,
  UserX,
  Eye,
  Loader2,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Filter,
  Download,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toPersianNumber } from '@/lib/persian';
import { exportToCSV } from '@/lib/csv-export';

/* ─────────── Types ─────────── */

interface SkillProgramSimple {
  id: string;
  name: string;
  code: string | null;
  totalHours: number;
}

interface Enrollment {
  id: string;
  karAmuzId: string;
  skillProgramId: string;
  status: string;
  enrollmentDate: string;
  skillProgram: SkillProgramSimple;
}

interface KarAmuz {
  id: string;
  nationalId: string;
  studentCode: string | null;
  firstName: string;
  lastName: string;
  phone: string;
  email: string | null;
  dateOfBirth: string | null;
  education: string | null;
  fatherName: string | null;
  address: string | null;
  city: string | null;
  status: string;
  startDate: string;
  notes: string | null;
  enrollments: Enrollment[];
  _count: {
    attendances: number;
    evaluations: number;
    certificates: number;
  };
  createdAt: string;
}

interface PaginationInfo {
  صفحه: number;
  حجم: number;
  کل: number;
  تعداد_صفحات: number;
}

interface SkillProgramOption {
  id: string;
  name: string;
  code: string | null;
}

/* ─────────── Constants ─────────── */

const STATUS_META: Record<string, { label: string; color: string; bg: string }> = {
  ACTIVE: { label: 'فعال', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
  GRADUATED: { label: 'فارغ‌التحصیل', color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200' },
  DROPPED: { label: 'ترک‌کرده', color: 'text-red-700', bg: 'bg-red-50 border-red-200' },
  SUSPENDED: { label: 'تعلیق‌شده', color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200' },
};

const EDUCATION_OPTIONS = [
  { value: 'زیردیپلم', label: 'زیردیپلم' },
  { value: 'دیپلم', label: 'دیپلم' },
  { value: 'کاردانی', label: 'کاردانی' },
  { value: 'کارشناسی', label: 'کارشناسی' },
  { value: 'کارشناسی ارشد', label: 'کارشناسی ارشد' },
  { value: 'دکتری', label: 'دکتری' },
];

const ITEMS_PER_PAGE = 20;

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string) {
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(new Date(dateStr));
  } catch {
    return '—';
  }
}

function getActiveEnrollment(enrollments: Enrollment[]): Enrollment | null {
  if (!enrollments || enrollments.length === 0) return null;
  const active = enrollments.find((e) => e.status === 'ENROLLED');
  return active || enrollments[0];
}

/* ─────────── Main Component ─────────── */

export default function KarAmuzPage() {
  /* ── State ── */
  const [karamuzList, setKaramuzList] = useState<KarAmuz[]>([]);
  const [pagination, setPagination] = useState<PaginationInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [skillProgramFilter, setSkillProgramFilter] = useState<string>('all');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);

  // Skill programs for filter & form
  const [skillPrograms, setSkillPrograms] = useState<SkillProgramOption[]>([]);

  // Add modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // Form fields
  const [formNationalId, setFormNationalId] = useState('');
  const [formFirstName, setFormFirstName] = useState('');
  const [formLastName, setFormLastName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formFatherName, setFormFatherName] = useState('');
  const [formEducation, setFormEducation] = useState('');
  const [formCity, setFormCity] = useState('Mahmoudabad');
  const [formAddress, setFormAddress] = useState('');
  const [formDateOfBirth, setFormDateOfBirth] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formSkillProgramId, setFormSkillProgramId] = useState('');

  /* ── Data Fetching ── */

  const fetchKarAmuz = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('page', currentPage.toString());
      params.set('limit', ITEMS_PER_PAGE.toString());
      if (search) params.set('search', search);
      if (statusFilter && statusFilter !== 'all') params.set('status', statusFilter);
      if (skillProgramFilter && skillProgramFilter !== 'all') params.set('skillProgramId', skillProgramFilter);

      const res = await fetch(`/api/crm/karamuz?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت لیست کارآموزان');
        return;
      }

      setKaramuzList(data['داده‌ها'] || []);
      setPagination(data['صفحه‌بندی'] || null);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [currentPage, search, statusFilter, skillProgramFilter]);

  const fetchSkillPrograms = useCallback(async () => {
    try {
      const res = await fetch('/api/crm/skill-programs?isActive=true&limit=100');
      const data = await res.json();
      if (res.ok) {
        setSkillPrograms((data['داده‌ها'] || []) as SkillProgramOption[]);
      }
    } catch {
      // Non-critical
    }
  }, []);

  useEffect(() => {
    fetchKarAmuz();
  }, [fetchKarAmuz]);

  useEffect(() => {
    fetchSkillPrograms();
  }, [fetchSkillPrograms]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [search, statusFilter, skillProgramFilter]);

  /* ── Form Handling ── */

  const resetForm = useCallback(() => {
    setFormNationalId('');
    setFormFirstName('');
    setFormLastName('');
    setFormPhone('');
    setFormEmail('');
    setFormFatherName('');
    setFormEducation('');
    setFormCity('Mahmoudabad');
    setFormAddress('');
    setFormDateOfBirth('');
    setFormNotes('');
    setFormSkillProgramId('');
    setFormError('');
  }, []);

  const handleAddKarAmuz = useCallback(async () => {
    // Validate required fields
    if (!formNationalId.trim() || !formFirstName.trim() || !formLastName.trim() || !formPhone.trim()) {
      setFormError('لطفاً فیلدهای الزامی را تکمیل کنید');
      return;
    }

    // Validate phone format
    if (!/^09[0-9]{9}$/.test(formPhone.trim())) {
      setFormError('شماره موبایل نامعتبر است (فرمت: 09123456789)');
      return;
    }

    // Validate national ID format
    if (!/^\d{10}$/.test(formNationalId.trim())) {
      setFormError('کد ملی باید ۱۰ رقم باشد');
      return;
    }

    setSubmitting(true);
    setFormError('');

    try {
      // Create KarAmuz
      const payload: Record<string, unknown> = {
        nationalId: formNationalId.trim(),
        firstName: formFirstName.trim(),
        lastName: formLastName.trim(),
        phone: formPhone.trim(),
      };

      if (formEmail.trim()) payload.email = formEmail.trim();
      if (formFatherName.trim()) payload.fatherName = formFatherName.trim();
      if (formEducation) payload.education = formEducation;
      if (formCity.trim()) payload.city = formCity.trim();
      if (formAddress.trim()) payload.address = formAddress.trim();
      if (formDateOfBirth) payload.dateOfBirth = formDateOfBirth;
      if (formNotes.trim()) payload.notes = formNotes.trim();

      const res = await fetch('/api/crm/karamuz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        setFormError(data['خطا'] || 'خطا در ثبت کارآموز');
        return;
      }

      const newKarAmuzId = data['داده']?.id;

      // If skill program selected, also create enrollment
      if (formSkillProgramId && newKarAmuzId) {
        try {
          await fetch('/api/crm/enrollments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              karAmuzId: newKarAmuzId,
              skillProgramId: formSkillProgramId,
            }),
          });
        } catch {
          // Enrollment failure is non-critical for the main creation
        }
      }

      // Close modal and refresh
      setAddModalOpen(false);
      resetForm();
      fetchKarAmuz();
    } catch {
      setFormError('خطا در ارتباط با سرور');
    } finally {
      setSubmitting(false);
    }
  }, [
    formNationalId, formFirstName, formLastName, formPhone,
    formEmail, formFatherName, formEducation, formCity,
    formAddress, formDateOfBirth, formNotes, formSkillProgramId,
    resetForm, fetchKarAmuz,
  ]);

  /* ── Computed values ── */

  const totalCount = pagination?.کل ?? 0;
  const totalPages = pagination?.تعداد_صفحات ?? 1;

  // Count by status from current list (for stats cards, we need total counts)
  // We'll derive from the pagination total and use a separate fetch for accurate stats
  const [statsCounts, setStatsCounts] = useState({ total: 0, active: 0, graduated: 0, dropped: 0 });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [totalRes, activeRes, graduatedRes, droppedRes] = await Promise.all([
          fetch('/api/crm/karamuz?limit=1'),
          fetch('/api/crm/karamuz?status=ACTIVE&limit=1'),
          fetch('/api/crm/karamuz?status=GRADUATED&limit=1'),
          fetch('/api/crm/karamuz?status=DROPPED&limit=1'),
        ]);
        const [totalData, activeData, graduatedData, droppedData] = await Promise.all([
          totalRes.json(), activeRes.json(), graduatedRes.json(), droppedRes.json(),
        ]);
        setStatsCounts({
          total: totalData['صفحه‌بندی']?.کل ?? 0,
          active: activeData['صفحه‌بندی']?.کل ?? 0,
          graduated: graduatedData['صفحه‌بندی']?.کل ?? 0,
          dropped: droppedData['صفحه‌بندی']?.کل ?? 0,
        });
      } catch {
        // Non-critical
      }
    };
    fetchStats();
  }, [karamuzList]); // Re-fetch stats when list changes

  /* ── Pagination helpers ── */

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      if (currentPage > 3) pages.push('...');
      for (let i = Math.max(2, currentPage - 1); i <= Math.min(totalPages - 1, currentPage + 1); i++) {
        pages.push(i);
      }
      if (currentPage < totalPages - 2) pages.push('...');
      pages.push(totalPages);
    }
    return pages;
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <GraduationCap className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">مدیریت کارآموزان</h1>
            <p className="text-gray-500 mt-0.5 text-sm">
              لیست کارآموزان آموزشگاه بهان رایانه
            </p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              exportToCSV(
                karamuzList.map((ka) => ({
                  firstName: ka.firstName,
                  lastName: ka.lastName,
                  nationalId: ka.nationalId,
                  studentCode: ka.studentCode || '',
                  phone: ka.phone,
                  email: ka.email || '',
                  city: ka.city || '',
                  status: STATUS_META[ka.status]?.label || ka.status,
                })),
                'trainees-export.csv',
                [
                  { key: 'firstName', header: 'نام' },
                  { key: 'lastName', header: 'نام خانوادگی' },
                  { key: 'nationalId', header: 'کد ملی' },
                  { key: 'studentCode', header: 'کد کارآموزی' },
                  { key: 'phone', header: 'موبایل' },
                  { key: 'email', header: 'ایمیل' },
                  { key: 'city', header: 'شهر' },
                  { key: 'status', header: 'وضعیت' },
                ]
              );
            }}
            className="gap-2"
            disabled={karamuzList.length === 0}
          >
            <Download className="w-4 h-4" />
            خروجی CSV
          </Button>
          <Button
            onClick={() => {
              resetForm();
              setAddModalOpen(true);
            }}
            className="bg-teal-600 hover:bg-teal-700 text-white gap-2 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            افزودن کارآموز
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="bg-white rounded-xl shadow-sm border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کل کارآموزان</p>
                <p className="text-2xl font-bold mt-1 text-gray-900">
                  {loading ? <Skeleton className="h-7 w-12 inline-block" /> : toPersianNumber(statsCounts.total)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-xl shadow-sm border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">فعال</p>
                <p className="text-2xl font-bold mt-1 text-emerald-700">
                  {loading ? <Skeleton className="h-7 w-12 inline-block" /> : toPersianNumber(statsCounts.active)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <UserCheck className="w-5 h-5 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-xl shadow-sm border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">فارغ‌التحصیل</p>
                <p className="text-2xl font-bold mt-1 text-purple-700">
                  {loading ? <Skeleton className="h-7 w-12 inline-block" /> : toPersianNumber(statsCounts.graduated)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200">
                <Award className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white rounded-xl shadow-sm border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">ترک‌کرده</p>
                <p className="text-2xl font-bold mt-1 text-red-700">
                  {loading ? <Skeleton className="h-7 w-12 inline-block" /> : toPersianNumber(statsCounts.dropped)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200">
                <UserX className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter Bar */}
      <Card className="bg-white rounded-xl shadow-sm border">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Filter className="w-4 h-4 text-gray-400" />
            <span className="text-sm font-medium text-gray-600">فیلتر و جستجو</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Search Input */}
            <div className="relative sm:col-span-2 lg:col-span-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="جستجو (نام، کد ملی، موبایل، کد کارآموزی)"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-9 text-sm"
              />
            </div>

            {/* Status Filter */}
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full text-sm">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                <SelectItem value="ACTIVE">فعال</SelectItem>
                <SelectItem value="GRADUATED">فارغ‌التحصیل</SelectItem>
                <SelectItem value="DROPPED">ترک‌کرده</SelectItem>
                <SelectItem value="SUSPENDED">تعلیق‌شده</SelectItem>
              </SelectContent>
            </Select>

            {/* Skill Program Filter */}
            <Select value={skillProgramFilter} onValueChange={setSkillProgramFilter}>
              <SelectTrigger className="w-full text-sm">
                <SelectValue placeholder="رشته/دوره" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه دوره‌ها</SelectItem>
                {skillPrograms.map((sp) => (
                  <SelectItem key={sp.id} value={sp.id}>
                    {sp.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Results count */}
            <div className="flex items-center text-sm text-gray-500 lg:justify-end">
              <span>
                {toPersianNumber(totalCount)} کارآموز
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Table */}
      <Card className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50/80 hover:bg-gray-50/80">
                <TableHead className="text-right text-xs font-semibold text-gray-600">ردیف</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-600">کد کارآموزی</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-600">نام و نام خانوادگی</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-600">کد ملی</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-600">موبایل</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-600">رشته/دوره</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-600">وضعیت</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-600">تاریخ ثبت‌نام</TableHead>
                <TableHead className="text-right text-xs font-semibold text-gray-600">عملیات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                // Loading skeletons
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 9 }).map((_, j) => (
                      <TableCell key={j}>
                        <Skeleton className="h-5 w-full max-w-[80px]" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : karamuzList.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12">
                    <div className="flex flex-col items-center gap-3">
                      <GraduationCap className="w-10 h-10 text-gray-300" />
                      <p className="text-gray-500 text-sm">کارآموزی یافت نشد</p>
                      <p className="text-gray-400 text-xs">با تغییر فیلترها یا افزودن کارآموز جدید، لیست را تشکیل دهید</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                karamuzList.map((ka, index) => {
                  const statusMeta = STATUS_META[ka.status] || { label: ka.status, color: 'text-gray-700', bg: 'bg-gray-50 border-gray-200' };
                  const activeEnrollment = getActiveEnrollment(ka.enrollments);
                  const rowNumber = (currentPage - 1) * ITEMS_PER_PAGE + index + 1;

                  return (
                    <TableRow
                      key={ka.id}
                      className={`hover:bg-teal-50/40 transition-colors ${index % 2 === 1 ? 'bg-gray-50/30' : ''}`}
                    >
                      <TableCell className="text-sm text-gray-500">
                        {toPersianNumber(rowNumber)}
                      </TableCell>
                      <TableCell className="text-sm">
                        <span className="font-mono text-gray-700" dir="ltr">
                          {ka.studentCode || '—'}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm font-medium text-gray-900">
                        {ka.firstName} {ka.lastName}
                      </TableCell>
                      <TableCell className="text-sm font-mono text-gray-700" dir="ltr">
                        {ka.nationalId}
                      </TableCell>
                      <TableCell className="text-sm text-gray-700" dir="ltr">
                        {ka.phone}
                      </TableCell>
                      <TableCell className="text-sm text-gray-700">
                        {activeEnrollment ? (
                          <span className="inline-flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-teal-500 shrink-0" />
                            {activeEnrollment.skillProgram.name}
                          </span>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={`text-[11px] px-2 py-0.5 h-5 border ${statusMeta.bg} ${statusMeta.color}`}
                        >
                          {statusMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {formatPersianDate(ka.startDate)}
                      </TableCell>
                      <TableCell>
                        <Link href={`/admin/karamuz/${ka.id}`}>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="gap-1.5 text-teal-600 hover:text-teal-700 hover:bg-teal-50 h-8"
                          >
                            <Eye className="w-4 h-4" />
                            مشاهده
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-sm text-gray-500">
            نمایش {toPersianNumber((currentPage - 1) * ITEMS_PER_PAGE + 1)} تا{' '}
            {toPersianNumber(Math.min(currentPage * ITEMS_PER_PAGE, totalCount))} از{' '}
            {toPersianNumber(totalCount)} کارآموز
          </p>
          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              disabled={currentPage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
            {getPageNumbers().map((page, idx) =>
              typeof page === 'string' ? (
                <span key={`dots-${idx}`} className="px-1 text-gray-400 text-sm">
                  ...
                </span>
              ) : (
                <Button
                  key={page}
                  variant={page === currentPage ? 'default' : 'outline'}
                  size="icon"
                  className={`h-8 w-8 text-xs ${
                    page === currentPage
                      ? 'bg-teal-600 hover:bg-teal-700 text-white'
                      : ''
                  }`}
                  onClick={() => setCurrentPage(page)}
                >
                  {toPersianNumber(page)}
                </Button>
              )
            )}
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              disabled={currentPage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Add KarAmuz Modal */}
      <Dialog open={addModalOpen} onOpenChange={setAddModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <GraduationCap className="w-5 h-5 text-teal-600" />
              افزودن کارآموز جدید
            </DialogTitle>
            <DialogDescription className="text-right">
              اطلاعات کارآموز جدید را وارد کنید. فیلدهای دارای * الزامی هستند.
            </DialogDescription>
          </DialogHeader>

          {formError && (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
            {/* National ID */}
            <div className="space-y-1.5">
              <Label htmlFor="nationalId" className="text-sm font-medium">
                کد ملی <span className="text-red-500">*</span>
              </Label>
              <Input
                id="nationalId"
                placeholder="کد ملی ۱۰ رقمی"
                value={formNationalId}
                onChange={(e) => setFormNationalId(e.target.value)}
                maxLength={10}
                dir="ltr"
                className="text-left"
              />
            </div>

            {/* First Name */}
            <div className="space-y-1.5">
              <Label htmlFor="firstName" className="text-sm font-medium">
                نام <span className="text-red-500">*</span>
              </Label>
              <Input
                id="firstName"
                placeholder="نام"
                value={formFirstName}
                onChange={(e) => setFormFirstName(e.target.value)}
              />
            </div>

            {/* Last Name */}
            <div className="space-y-1.5">
              <Label htmlFor="lastName" className="text-sm font-medium">
                نام خانوادگی <span className="text-red-500">*</span>
              </Label>
              <Input
                id="lastName"
                placeholder="نام خانوادگی"
                value={formLastName}
                onChange={(e) => setFormLastName(e.target.value)}
              />
            </div>

            {/* Phone */}
            <div className="space-y-1.5">
              <Label htmlFor="phone" className="text-sm font-medium">
                موبایل <span className="text-red-500">*</span>
              </Label>
              <Input
                id="phone"
                placeholder="09123456789"
                value={formPhone}
                onChange={(e) => setFormPhone(e.target.value)}
                maxLength={11}
                dir="ltr"
                className="text-left"
              />
            </div>

            {/* Email */}
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-sm font-medium">
                ایمیل
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="email@example.com"
                value={formEmail}
                onChange={(e) => setFormEmail(e.target.value)}
                dir="ltr"
                className="text-left"
              />
            </div>

            {/* Father Name */}
            <div className="space-y-1.5">
              <Label htmlFor="fatherName" className="text-sm font-medium">
                نام پدر
              </Label>
              <Input
                id="fatherName"
                placeholder="نام پدر"
                value={formFatherName}
                onChange={(e) => setFormFatherName(e.target.value)}
              />
            </div>

            {/* Education */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">تحصیلات</Label>
              <Select value={formEducation} onValueChange={setFormEducation}>
                <SelectTrigger className="w-full text-sm">
                  <SelectValue placeholder="انتخاب تحصیلات" />
                </SelectTrigger>
                <SelectContent>
                  {EDUCATION_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Skill Program */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">انتخاب دوره</Label>
              <Select value={formSkillProgramId} onValueChange={setFormSkillProgramId}>
                <SelectTrigger className="w-full text-sm">
                  <SelectValue placeholder="انتخاب دوره آموزشی" />
                </SelectTrigger>
                <SelectContent>
                  {skillPrograms.map((sp) => (
                    <SelectItem key={sp.id} value={sp.id}>
                      {sp.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* City */}
            <div className="space-y-1.5">
              <Label htmlFor="city" className="text-sm font-medium">
                شهر
              </Label>
              <Input
                id="city"
                placeholder="شهر"
                value={formCity}
                onChange={(e) => setFormCity(e.target.value)}
              />
            </div>

            {/* Date of Birth */}
            <div className="space-y-1.5">
              <Label htmlFor="dateOfBirth" className="text-sm font-medium">
                تاریخ تولد
              </Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={formDateOfBirth}
                onChange={(e) => setFormDateOfBirth(e.target.value)}
                dir="ltr"
                className="text-left"
              />
            </div>

            {/* Address - full width */}
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="address" className="text-sm font-medium">
                آدرس
              </Label>
              <Input
                id="address"
                placeholder="آدرس محل سکونت"
                value={formAddress}
                onChange={(e) => setFormAddress(e.target.value)}
              />
            </div>

            {/* Notes - full width */}
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="notes" className="text-sm font-medium">
                یادداشت
              </Label>
              <Textarea
                id="notes"
                placeholder="یادداشت‌های تکمیلی..."
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setAddModalOpen(false)}
              disabled={submitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleAddKarAmuz}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  در حال ثبت...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  ثبت کارآموز
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
