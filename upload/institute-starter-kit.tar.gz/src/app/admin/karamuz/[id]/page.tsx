'use client';

import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowRight,
  Pencil,
  Save,
  X,
  Plus,
  BookOpen,
  ClipboardCheck,
  GraduationCap,
  Award,
  CreditCard,
  Loader2,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Clock,
  ChevronDown,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Hash,
  UserCheck,
  Building,
  Link as LinkIcon,
  UserX,
  AlertTriangle,
  FileCheck,
  FileDown,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface SkillProgram {
  id: string;
  name: string;
  code: string | null;
  totalHours: number;
  theoryHours: number;
  practicalHours: number;
  minAttendancePct: number;
  instructorName: string | null;
}

interface Enrollment {
  id: string;
  karAmuzId: string;
  skillProgramId: string;
  status: string;
  enrollmentDate: string;
  completionDate: string | null;
  finalGrade: number | null;
  isPassed: boolean | null;
  skillProgram: SkillProgram;
  createdAt: string;
  updatedAt: string;
}

interface Session {
  id: string;
  skillProgramId: string;
  date: string;
  startTime: string;
  endTime: string;
  title: string | null;
  type: string;
  instructorName: string | null;
  skillProgram?: { id: string; name: string; code: string | null };
}

interface AttendanceRecord {
  id: string;
  karAmuzId: string;
  sessionId: string;
  hours: number;
  status: string;
  notes: string | null;
  session: {
    id: string;
    date: string;
    title: string | null;
    type: string;
    startTime: string;
    endTime: string;
  };
  createdAt: string;
  updatedAt: string;
}

interface Evaluation {
  id: string;
  karAmuzId: string;
  skillProgramId: string;
  type: string;
  title: string;
  score: number | null;
  maxScore: number;
  date: string;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Certificate {
  id: string;
  karAmuzId: string;
  skillProgramId: string;
  certificateNo: string | null;
  issueDate: string | null;
  status: string;
  qrCode: string | null;
  pdfUrl: string | null;
  skillProgram: {
    id: string;
    name: string;
    code: string | null;
  };
  createdAt: string;
  updatedAt: string;
}

interface Payment {
  id: string;
  leadId: string | null;
  karAmuzId: string | null;
  amount: number;
  type: string;
  status: string;
  dueDate: string | null;
  paidAt: string | null;
  note: string;
  createdAt: string;
  updatedAt: string;
}

interface Lead {
  id: string;
  name: string;
  phone: string;
  source: string;
  stage: string;
}

interface KarAmuz {
  id: string;
  nationalId: string;
  studentCode: string | null;
  firstName: string;
  lastName: string;
  phone: string;
  email: string | null;
  photo: string | null;
  dateOfBirth: string | null;
  education: string | null;
  fatherName: string | null;
  address: string | null;
  city: string | null;
  leadId: string | null;
  lead: Lead | null;
  status: string;
  startDate: string;
  expectedEndDate: string | null;
  actualEndDate: string | null;
  notes: string | null;
  enrollments: Enrollment[];
  attendances: AttendanceRecord[];
  evaluations: Evaluation[];
  certificates: Certificate[];
  payments: Payment[];
  createdAt: string;
  updatedAt: string;
}

/* ─────────── Constants ─────────── */

const STATUS_META: Record<string, { label: string; color: string; bg: string; icon: typeof CheckCircle2 }> = {
  ACTIVE: { label: 'فعال', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200', icon: CheckCircle2 },
  GRADUATED: { label: 'فارغ‌التحصیل', color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200', icon: GraduationCap },
  DROPPED: { label: 'انصراف', color: 'text-red-700', bg: 'bg-red-50 border-red-200', icon: XCircle },
  SUSPENDED: { label: 'تعلیق', color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200', icon: AlertTriangle },
};

const ENROLLMENT_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  ENROLLED: { label: 'در حال آموزش', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
  COMPLETED: { label: 'تکمیل شده', color: 'text-teal-700', bg: 'bg-teal-50 border-teal-200' },
  DROPPED: { label: 'انصراف', color: 'text-red-700', bg: 'bg-red-50 border-red-200' },
  FAILED: { label: 'مردود', color: 'text-orange-700', bg: 'bg-orange-50 border-orange-200' },
};

const ATTENDANCE_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  PRESENT: { label: 'حاضر', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
  ABSENT: { label: 'غایب', color: 'text-red-700', bg: 'bg-red-50 border-red-200' },
  LATE: { label: 'تأخیر', color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200' },
  EXCUSED: { label: 'موجه', color: 'text-sky-700', bg: 'bg-sky-50 border-sky-200' },
};

const EVAL_TYPE_MAP: Record<string, string> = {
  MIDTERM: 'میان‌ترم',
  FINAL: 'پایان‌ترم',
  PROJECT: 'پروژه',
  SKILL_CHECK: 'ارزیابی شایستگی',
};

const CERT_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-gray-600', bg: 'bg-gray-50 border-gray-200' },
  EXAM_REGISTERED: { label: 'ثبت‌نام آزمون', color: 'text-sky-700', bg: 'bg-sky-50 border-sky-200' },
  EXAM_PASSED: { label: 'قبول در آزمون', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
  EXAM_FAILED: { label: 'رد در آزمون', color: 'text-red-700', bg: 'bg-red-50 border-red-200' },
  ISSUED: { label: 'صادر شده', color: 'text-teal-700', bg: 'bg-teal-50 border-teal-200' },
};

const PAYMENT_TYPE_MAP: Record<string, string> = {
  CASH: 'نقدی',
  CHECK: 'چک',
  INSTALLMENT: 'قسط',
};

const PAYMENT_STATUS_MAP: Record<string, { label: string; color: string; bg: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200' },
  PAID: { label: 'پرداخت شده', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
  OVERDUE: { label: 'سررسید گذشته', color: 'text-red-700', bg: 'bg-red-50 border-red-200' },
  CANCELLED: { label: 'لغو شده', color: 'text-gray-500', bg: 'bg-gray-50 border-gray-200' },
};

const SESSION_TYPE_MAP: Record<string, string> = {
  THEORY: 'تئوری',
  PRACTICAL: 'عملی',
};

const EDUCATION_MAP: Record<string, string> = {
  'دیپلم': 'دیپلم',
  'کاردانی': 'کاردانی',
  'کارشناسی': 'کارشناسی',
  'کارشناسی ارشد': 'کارشناسی ارشد',
  'دکتری': 'دکتری',
  'سیکل': 'سیکل',
  'زیردیپلم': 'زیردیپلم',
};

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function formatPersianDateShort(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(dateStr));
}

function formatRials(amount: number): string {
  return toPersianNumber(amount.toLocaleString('en-US')) + ' ریال';
}

function formatToman(amount: number): string {
  const toman = Math.round(amount / 10);
  return toPersianNumber(toman.toLocaleString('en-US')) + ' تومان';
}

/* ─────────── Main Component ─────────── */

export default function KarAmuzDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  /* ── Core state ── */
  const [karAmuz, setKarAmuz] = useState<KarAmuz | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  /* ── Edit mode ── */
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  /* ── Skill programs for enrollment dropdown ── */
  const [skillPrograms, setSkillPrograms] = useState<{ id: string; name: string; code: string | null }[]>([]);

  /* ── Sessions for attendance ── */
  const [sessions, setSessions] = useState<Session[]>([]);

  /* ── Dialogs ── */
  const [enrollDialogOpen, setEnrollDialogOpen] = useState(false);
  const [selectedProgramId, setSelectedProgramId] = useState('');
  const [enrolling, setEnrolling] = useState(false);

  const [attendanceDialogOpen, setAttendanceDialogOpen] = useState(false);
  const [attSessionId, setAttSessionId] = useState('');
  const [attStatus, setAttStatus] = useState('PRESENT');
  const [attHours, setAttHours] = useState('');
  const [attNotes, setAttNotes] = useState('');
  const [attProgramId, setAttProgramId] = useState('');
  const [submittingAtt, setSubmittingAtt] = useState(false);

  const [evalDialogOpen, setEvalDialogOpen] = useState(false);
  const [evalForm, setEvalForm] = useState({
    skillProgramId: '',
    type: 'MIDTERM',
    title: '',
    score: '',
    maxScore: '20',
    date: new Date().toISOString().split('T')[0],
    notes: '',
  });
  const [submittingEval, setSubmittingEval] = useState(false);

  const [certDialogOpen, setCertDialogOpen] = useState(false);
  const [certProgramId, setCertProgramId] = useState('');
  const [submittingCert, setSubmittingCert] = useState(false);

  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [payForm, setPayForm] = useState({
    amount: '',
    type: 'CASH',
    dueDate: '',
    note: '',
  });
  const [submittingPay, setSubmittingPay] = useState(false);

  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [changingStatus, setChangingStatus] = useState(false);

  /* ── Toast ── */
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  /* ── Data fetching ── */

  const fetchKarAmuz = useCallback(async () => {
    try {
      const res = await fetch(`/api/crm/karamuz/${id}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت اطلاعات کارآموز');
        return;
      }
      const ka = data['داده'] as KarAmuz;
      setKarAmuz(ka);
      // Initialize edit form
      setEditForm({
        firstName: ka.firstName || '',
        lastName: ka.lastName || '',
        phone: ka.phone || '',
        email: ka.email || '',
        fatherName: ka.fatherName || '',
        education: ka.education || '',
        city: ka.city || '',
        address: ka.address || '',
        dateOfBirth: ka.dateOfBirth ? ka.dateOfBirth.split('T')[0] : '',
        notes: ka.notes || '',
        expectedEndDate: ka.expectedEndDate ? ka.expectedEndDate.split('T')[0] : '',
      });
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    }
  }, [id]);

  const fetchSkillPrograms = useCallback(async () => {
    try {
      const res = await fetch('/api/crm/skill-programs?isActive=true&limit=100');
      const data = await res.json();
      if (res.ok) {
        setSkillPrograms(
          (data['داده‌ها'] || []).map((sp: { id: string; name: string; code: string | null }) => ({
            id: sp.id,
            name: sp.name,
            code: sp.code,
          }))
        );
      }
    } catch {
      // Non-critical
    }
  }, []);

  const fetchSessions = useCallback(async (skillProgramId: string) => {
    if (!skillProgramId) {
      setSessions([]);
      return;
    }
    try {
      const res = await fetch(`/api/crm/sessions?skillProgramId=${skillProgramId}`);
      const data = await res.json();
      if (res.ok) {
        setSessions(data['داده‌ها'] || []);
      }
    } catch {
      // Non-critical
    }
  }, []);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await fetchKarAmuz();
      setLoading(false);
    };
    load();
  }, [fetchKarAmuz]);

  useEffect(() => {
    fetchSkillPrograms();
  }, [fetchSkillPrograms]);

  /* ── Attendance stats ── */
  const attendanceStats = karAmuz
    ? (() => {
        const total = karAmuz.attendances.length;
        const present = karAmuz.attendances.filter((a) => a.status === 'PRESENT').length;
        const absent = karAmuz.attendances.filter((a) => a.status === 'ABSENT').length;
        const late = karAmuz.attendances.filter((a) => a.status === 'LATE').length;
        const pct = total > 0 ? Math.round(((present + late) / total) * 100) : 0;
        return { total, present, absent, late, pct };
      })()
    : { total: 0, present: 0, absent: 0, late: 0, pct: 0 };

  /* ── Handlers ── */

  const handleSaveEdit = async () => {
    if (!karAmuz) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/crm/karamuz/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName: editForm.firstName || undefined,
          lastName: editForm.lastName || undefined,
          phone: editForm.phone || undefined,
          email: editForm.email || undefined,
          fatherName: editForm.fatherName || undefined,
          education: editForm.education || undefined,
          city: editForm.city || undefined,
          address: editForm.address || undefined,
          dateOfBirth: editForm.dateOfBirth || undefined,
          notes: editForm.notes || undefined,
          expectedEndDate: editForm.expectedEndDate || undefined,
        }),
      });
      if (res.ok) {
        setIsEditing(false);
        await fetchKarAmuz();
        showToast('اطلاعات کارآموز با موفقیت ذخیره شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در ذخیره اطلاعات', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleStatusChange = async () => {
    if (!karAmuz || !newStatus) return;
    setChangingStatus(true);
    try {
      const res = await fetch(`/api/crm/karamuz/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        setStatusDialogOpen(false);
        await fetchKarAmuz();
        showToast('وضعیت کارآموز با موفقیت تغییر کرد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در تغییر وضعیت', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally {
      setChangingStatus(false);
    }
  };

  const handleEnroll = async () => {
    if (!selectedProgramId) return;
    setEnrolling(true);
    try {
      const res = await fetch('/api/crm/enrollments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ karAmuzId: id, skillProgramId: selectedProgramId }),
      });
      if (res.ok) {
        setEnrollDialogOpen(false);
        setSelectedProgramId('');
        await fetchKarAmuz();
        showToast('ثبت‌نام در دوره با موفقیت انجام شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در ثبت‌نام', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally {
      setEnrolling(false);
    }
  };

  const handleAddAttendance = async () => {
    if (!attSessionId || !attStatus) return;
    setSubmittingAtt(true);
    try {
      const res = await fetch('/api/crm/attendances', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          karAmuzId: id,
          sessionId: attSessionId,
          status: attStatus,
          hours: attHours ? parseFloat(attHours) : undefined,
          notes: attNotes || undefined,
        }),
      });
      if (res.ok) {
        setAttendanceDialogOpen(false);
        setAttSessionId('');
        setAttStatus('PRESENT');
        setAttHours('');
        setAttNotes('');
        await fetchKarAmuz();
        showToast('حضور و غیاب با موفقیت ثبت شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در ثبت حضور و غیاب', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally {
      setSubmittingAtt(false);
    }
  };

  const handleAddEvaluation = async () => {
    if (!evalForm.skillProgramId || !evalForm.title || !evalForm.date) return;
    setSubmittingEval(true);
    try {
      const res = await fetch('/api/crm/evaluations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          karAmuzId: id,
          skillProgramId: evalForm.skillProgramId,
          type: evalForm.type,
          title: evalForm.title,
          score: evalForm.score ? parseFloat(evalForm.score) : undefined,
          maxScore: parseFloat(evalForm.maxScore) || 20,
          date: evalForm.date,
          notes: evalForm.notes || undefined,
        }),
      });
      if (res.ok) {
        setEvalDialogOpen(false);
        setEvalForm({
          skillProgramId: '',
          type: 'MIDTERM',
          title: '',
          score: '',
          maxScore: '20',
          date: new Date().toISOString().split('T')[0],
          notes: '',
        });
        await fetchKarAmuz();
        showToast('ارزیابی با موفقیت ثبت شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در ثبت ارزیابی', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally {
      setSubmittingEval(false);
    }
  };

  const handleAddCertificate = async () => {
    if (!certProgramId) return;
    setSubmittingCert(true);
    try {
      const res = await fetch('/api/crm/certificates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ karAmuzId: id, skillProgramId: certProgramId }),
      });
      if (res.ok) {
        setCertDialogOpen(false);
        setCertProgramId('');
        await fetchKarAmuz();
        showToast('گواهینامه با موفقیت ایجاد شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در صدور گواهینامه', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally {
      setSubmittingCert(false);
    }
  };

  const handleCertStatusChange = async (certId: string, status: string) => {
    try {
      const res = await fetch(`/api/crm/certificates/${certId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        await fetchKarAmuz();
        showToast('وضعیت گواهینامه به‌روزرسانی شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در به‌روزرسانی', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    }
  };

  const handleAddPayment = async () => {
    if (!payForm.amount) return;
    setSubmittingPay(true);
    try {
      const payload: Record<string, unknown> = {
        amount: parseInt(payForm.amount) * 10, // Convert toman to rial
        type: payForm.type,
        dueDate: payForm.dueDate || undefined,
        note: payForm.note || undefined,
        karAmuzId: id,
      };

      // If the karAmuz has a lead, also link to the lead
      if (karAmuz?.leadId) {
        payload.leadId = karAmuz.leadId;
      }

      const res = await fetch('/api/crm/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        setPaymentDialogOpen(false);
        setPayForm({ amount: '', type: 'CASH', dueDate: '', note: '' });
        await fetchKarAmuz();
        showToast('پرداخت با موفقیت ثبت شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در ثبت پرداخت', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally {
      setSubmittingPay(false);
    }
  };

  const handlePayStatusChange = async (paymentId: string, status: string) => {
    try {
      const res = await fetch('/api/crm/payments', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentId, status }),
      });
      if (res.ok) {
        await fetchKarAmuz();
        showToast('وضعیت پرداخت به‌روزرسانی شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || 'خطا در به‌روزرسانی', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    }
  };

  /* ──── Loading ──── */

  if (loading) {
    return (
      <div className="space-y-6" dir="rtl">
        <div className="flex items-center gap-4">
          <Skeleton className="h-10 w-10 rounded-lg" />
          <div className="space-y-2">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
        <Skeleton className="h-56 w-full rounded-xl" />
        <Skeleton className="h-80 w-full rounded-xl" />
      </div>
    );
  }

  if (error || !karAmuz) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-4" dir="rtl">
        <AlertCircle className="w-12 h-12 text-red-400" />
        <p className="text-gray-600 text-center">{error || 'کارآموز مورد نظر یافت نشد'}</p>
        <Link href="/admin/karamuz">
          <Button variant="outline" className="gap-2">
            <ArrowRight className="w-4 h-4" />
            بازگشت به لیست کارآموزان
          </Button>
        </Link>
      </div>
    );
  }

  const statusMeta = STATUS_META[karAmuz.status] || STATUS_META.ACTIVE;

  // Available skill programs (not already enrolled)
  const enrolledProgramIds = new Set(karAmuz.enrollments.map((e) => e.skillProgramId));
  const availablePrograms = skillPrograms.filter((sp) => !enrolledProgramIds.has(sp.id));

  // Programs with enrollments (for eval/cert dropdowns)
  const enrolledPrograms = karAmuz.enrollments.map((e) => e.skillProgram);

  // Payment summary
  const totalPayAmount = karAmuz.payments
    .filter((p) => p.status !== 'CANCELLED')
    .reduce((sum, p) => sum + p.amount, 0);
  const paidAmount = karAmuz.payments
    .filter((p) => p.status === 'PAID')
    .reduce((sum, p) => sum + p.amount, 0);

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Toast */}
      {toast && (
        <div
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-[100] flex items-center gap-2 px-4 py-3 rounded-lg shadow-lg transition-all duration-300 ${
            toast.type === 'success'
              ? 'bg-emerald-600 text-white'
              : 'bg-red-600 text-white'
          }`}
        >
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5" />
          ) : (
            <AlertCircle className="w-5 h-5" />
          )}
          <span className="text-sm font-medium">{toast.message}</span>
        </div>
      )}

      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link href="/admin/karamuz">
            <Button variant="ghost" size="icon" className="shrink-0">
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold text-gray-900">
                {karAmuz.firstName} {karAmuz.lastName}
              </h1>
              <Badge variant="outline" className={`${statusMeta.bg} ${statusMeta.color} text-xs`}>
                {statusMeta.label}
              </Badge>
            </div>
            <p className="text-sm text-gray-500 mt-0.5">
              کد کارآموزی: {toPersianNumber(karAmuz.studentCode || '—')}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isEditing ? (
            <>
              <Button
                onClick={handleSaveEdit}
                disabled={saving}
                className="gap-2 bg-teal-600 hover:bg-teal-700"
                size="sm"
              >
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                ذخیره
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(false)}
                className="gap-2"
              >
                <X className="w-4 h-4" />
                انصراف
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
                className="gap-2"
              >
                <Pencil className="w-4 h-4" />
                ویرایش
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setNewStatus(karAmuz.status);
                  setStatusDialogOpen(true);
                }}
                className="gap-2"
              >
                <UserCheck className="w-4 h-4" />
                تغییر وضعیت
              </Button>
            </>
          )}
        </div>
      </div>

      {/* ── Profile Card ── */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-bold text-gray-500 flex items-center gap-2">
            <User className="w-4 h-4" />
            اطلاعات شخصی
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
            {/* National ID */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <Hash className="w-3.5 h-3.5" />
                کد ملی
              </Label>
              <p className="text-sm font-medium text-gray-900" dir="ltr">
                {toPersianNumber(karAmuz.nationalId)}
              </p>
            </div>

            {/* Phone */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5" />
                شماره تماس
              </Label>
              {isEditing ? (
                <Input
                  value={editForm.phone}
                  onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                  className="h-8 text-sm"
                  dir="ltr"
                />
              ) : (
                <p className="text-sm font-medium text-gray-900" dir="ltr">
                  {karAmuz.phone}
                </p>
              )}
            </div>

            {/* Email */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5" />
                ایمیل
              </Label>
              {isEditing ? (
                <Input
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className="h-8 text-sm"
                  dir="ltr"
                  placeholder="example@mail.com"
                />
              ) : (
                <p className="text-sm font-medium text-gray-900" dir="ltr">
                  {karAmuz.email || '—'}
                </p>
              )}
            </div>

            {/* Father Name */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" />
                نام پدر
              </Label>
              {isEditing ? (
                <Input
                  value={editForm.fatherName}
                  onChange={(e) => setEditForm({ ...editForm, fatherName: e.target.value })}
                  className="h-8 text-sm"
                />
              ) : (
                <p className="text-sm font-medium text-gray-900">{karAmuz.fatherName || '—'}</p>
              )}
            </div>

            {/* Education */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                تحصیلات
              </Label>
              {isEditing ? (
                <Select
                  value={editForm.education}
                  onValueChange={(val) => setEditForm({ ...editForm, education: val })}
                >
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="انتخاب تحصیلات" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(EDUCATION_MAP).map(([key, label]) => (
                      <SelectItem key={key} value={key}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <p className="text-sm font-medium text-gray-900">{karAmuz.education || '—'}</p>
              )}
            </div>

            {/* City */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" />
                شهر
              </Label>
              {isEditing ? (
                <Input
                  value={editForm.city}
                  onChange={(e) => setEditForm({ ...editForm, city: e.target.value })}
                  className="h-8 text-sm"
                />
              ) : (
                <p className="text-sm font-medium text-gray-900">{karAmuz.city || '—'}</p>
              )}
            </div>

            {/* Date of Birth */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                تاریخ تولد
              </Label>
              {isEditing ? (
                <Input
                  type="date"
                  value={editForm.dateOfBirth}
                  onChange={(e) => setEditForm({ ...editForm, dateOfBirth: e.target.value })}
                  className="h-8 text-sm"
                  dir="ltr"
                />
              ) : (
                <p className="text-sm font-medium text-gray-900">
                  {karAmuz.dateOfBirth ? formatPersianDate(karAmuz.dateOfBirth) : '—'}
                </p>
              )}
            </div>

            {/* Address */}
            <div className="space-y-1 sm:col-span-2">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" />
                آدرس
              </Label>
              {isEditing ? (
                <Input
                  value={editForm.address}
                  onChange={(e) => setEditForm({ ...editForm, address: e.target.value })}
                  className="h-8 text-sm"
                />
              ) : (
                <p className="text-sm font-medium text-gray-900">{karAmuz.address || '—'}</p>
              )}
            </div>

            <Separator className="sm:col-span-2 lg:col-span-3" />

            {/* Lead source */}
            {karAmuz.lead && (
              <div className="space-y-1">
                <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5" />
                  منبع لید
                </Label>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-gray-900">{karAmuz.lead.name}</p>
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                    {karAmuz.lead.source}
                  </Badge>
                </div>
              </div>
            )}

            {/* Registration date */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                تاریخ ثبت‌نام
              </Label>
              <p className="text-sm font-medium text-gray-900">
                {formatPersianDate(karAmuz.startDate)}
              </p>
            </div>

            {/* Expected end date */}
            <div className="space-y-1">
              <Label className="text-xs text-gray-500 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                تاریخ پایان مورد انتظار
              </Label>
              {isEditing ? (
                <Input
                  type="date"
                  value={editForm.expectedEndDate}
                  onChange={(e) => setEditForm({ ...editForm, expectedEndDate: e.target.value })}
                  className="h-8 text-sm"
                  dir="ltr"
                />
              ) : (
                <p className="text-sm font-medium text-gray-900">
                  {karAmuz.expectedEndDate ? formatPersianDate(karAmuz.expectedEndDate) : '—'}
                </p>
              )}
            </div>

            {/* Notes */}
            {(karAmuz.notes || isEditing) && (
              <div className="space-y-1 sm:col-span-2 lg:col-span-3">
                <Label className="text-xs text-gray-500">یادداشت</Label>
                {isEditing ? (
                  <Textarea
                    value={editForm.notes}
                    onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                    className="text-sm min-h-[60px]"
                  />
                ) : (
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{karAmuz.notes}</p>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ── Tabs ── */}
      <Tabs defaultValue="enrollments" dir="rtl">
        <TabsList className="w-full flex-wrap h-auto gap-1 p-1 bg-gray-100 rounded-lg">
          <TabsTrigger value="enrollments" className="gap-1.5 text-xs sm:text-sm">
            <BookOpen className="w-4 h-4" />
            دوره‌ها
            {karAmuz.enrollments.length > 0 && (
              <span className="text-[10px] bg-teal-100 text-teal-700 px-1.5 py-0.5 rounded-full font-bold">
                {toPersianNumber(karAmuz.enrollments.length)}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="attendance" className="gap-1.5 text-xs sm:text-sm">
            <ClipboardCheck className="w-4 h-4" />
            حضور و غیاب
          </TabsTrigger>
          <TabsTrigger value="evaluations" className="gap-1.5 text-xs sm:text-sm">
            <FileCheck className="w-4 h-4" />
            ارزیابی‌ها
          </TabsTrigger>
          <TabsTrigger value="certificates" className="gap-1.5 text-xs sm:text-sm">
            <Award className="w-4 h-4" />
            گواهینامه‌ها
          </TabsTrigger>
          <TabsTrigger value="payments" className="gap-1.5 text-xs sm:text-sm">
            <CreditCard className="w-4 h-4" />
            پرداخت‌ها
          </TabsTrigger>
        </TabsList>

        {/* ── Tab 1: Enrollments ── */}
        <TabsContent value="enrollments">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3 flex-row items-center justify-between">
              <CardTitle className="text-sm font-bold text-gray-500">
                دوره‌های ثبت‌نام شده
              </CardTitle>
              <Button
                size="sm"
                className="gap-1.5 bg-teal-600 hover:bg-teal-700"
                onClick={() => setEnrollDialogOpen(true)}
              >
                <Plus className="w-4 h-4" />
                ثبت‌نام در دوره جدید
              </Button>
            </CardHeader>
            <CardContent>
              {karAmuz.enrollments.length === 0 ? (
                <div className="text-center py-10">
                  <BookOpen className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                  <p className="text-sm text-gray-500">هنوز در دوره‌ای ثبت‌نام نشده است</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {karAmuz.enrollments.map((enrollment) => {
                    const eStatus = ENROLLMENT_STATUS[enrollment.status] || ENROLLMENT_STATUS.ENROLLED;
                    return (
                      <div
                        key={enrollment.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100 gap-3"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-medium text-gray-900 text-sm">
                              {enrollment.skillProgram.name}
                            </p>
                            <Badge variant="outline" className={`${eStatus.bg} ${eStatus.color} text-[10px] px-1.5 py-0`}>
                              {eStatus.label}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 mt-1.5 text-xs text-gray-500 flex-wrap">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {formatPersianDateShort(enrollment.enrollmentDate)}
                            </span>
                            {enrollment.completionDate && (
                              <span className="flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" />
                                تکمیل: {formatPersianDateShort(enrollment.completionDate)}
                              </span>
                            )}
                            {enrollment.finalGrade !== null && (
                              <span className="flex items-center gap-1">
                                نمره: {toPersianNumber(enrollment.finalGrade)}
                              </span>
                            )}
                            <span>
                              {toPersianNumber(enrollment.skillProgram.totalHours)} ساعت
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab 2: Attendance ── */}
        <TabsContent value="attendance">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <CardTitle className="text-sm font-bold text-gray-500">
                  حضور و غیاب
                </CardTitle>
                <Button
                  size="sm"
                  className="gap-1.5 bg-teal-600 hover:bg-teal-700"
                  onClick={() => {
                    setAttProgramId('');
                    setAttSessionId('');
                    setSessions([]);
                    setAttendanceDialogOpen(true);
                  }}
                >
                  <Plus className="w-4 h-4" />
                  ثبت حضور و غیاب
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {/* Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-5">
                <div className="bg-gray-50 rounded-lg p-3 text-center">
                  <p className="text-[10px] text-gray-500">کل جلسات</p>
                  <p className="text-lg font-bold text-gray-900">{toPersianNumber(attendanceStats.total)}</p>
                </div>
                <div className="bg-emerald-50 rounded-lg p-3 text-center">
                  <p className="text-[10px] text-emerald-600">حاضر</p>
                  <p className="text-lg font-bold text-emerald-700">{toPersianNumber(attendanceStats.present)}</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3 text-center">
                  <p className="text-[10px] text-red-600">غایب</p>
                  <p className="text-lg font-bold text-red-700">{toPersianNumber(attendanceStats.absent)}</p>
                </div>
                <div className="bg-amber-50 rounded-lg p-3 text-center">
                  <p className="text-[10px] text-amber-600">تأخیر</p>
                  <p className="text-lg font-bold text-amber-700">{toPersianNumber(attendanceStats.late)}</p>
                </div>
                <div className="bg-teal-50 rounded-lg p-3 text-center col-span-2 sm:col-span-1">
                  <p className="text-[10px] text-teal-600">درصد حضور</p>
                  <p className="text-lg font-bold text-teal-700">{toPersianNumber(attendanceStats.pct)}٪</p>
                  <Progress value={attendanceStats.pct} className="mt-1.5 h-1.5" />
                </div>
              </div>

              {/* Table */}
              {karAmuz.attendances.length === 0 ? (
                <div className="text-center py-10">
                  <ClipboardCheck className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                  <p className="text-sm text-gray-500">هنوز سابقه حضور و غیاب ثبت نشده است</p>
                </div>
              ) : (
                <div className="overflow-x-auto max-h-96 overflow-y-auto rounded-lg border border-gray-100">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-50">
                        <TableHead className="text-xs">تاریخ جلسه</TableHead>
                        <TableHead className="text-xs">عنوان</TableHead>
                        <TableHead className="text-xs">نوع</TableHead>
                        <TableHead className="text-xs">ساعات</TableHead>
                        <TableHead className="text-xs">وضعیت</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {karAmuz.attendances.map((att) => {
                        const aStatus = ATTENDANCE_STATUS[att.status] || ATTENDANCE_STATUS.PRESENT;
                        return (
                          <TableRow key={att.id}>
                            <TableCell className="text-xs">
                              {formatPersianDateShort(att.session.date)}
                            </TableCell>
                            <TableCell className="text-xs">
                              {att.session.title || '—'}
                            </TableCell>
                            <TableCell className="text-xs">
                              {SESSION_TYPE_MAP[att.session.type] || att.session.type}
                            </TableCell>
                            <TableCell className="text-xs">
                              {toPersianNumber(att.hours)}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="outline"
                                className={`${aStatus.bg} ${aStatus.color} text-[10px] px-1.5 py-0`}
                              >
                                {aStatus.label}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab 3: Evaluations ── */}
        <TabsContent value="evaluations">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3 flex-row items-center justify-between">
              <CardTitle className="text-sm font-bold text-gray-500">
                ارزیابی‌ها
              </CardTitle>
              <Button
                size="sm"
                className="gap-1.5 bg-teal-600 hover:bg-teal-700"
                onClick={() => setEvalDialogOpen(true)}
              >
                <Plus className="w-4 h-4" />
                افزودن ارزیابی
              </Button>
            </CardHeader>
            <CardContent>
              {karAmuz.evaluations.length === 0 ? (
                <div className="text-center py-10">
                  <FileCheck className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                  <p className="text-sm text-gray-500">هنوز ارزیابی ثبت نشده است</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {karAmuz.evaluations.map((ev) => (
                    <div
                      key={ev.id}
                      className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100 gap-3"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-medium text-gray-900 text-sm">{ev.title}</p>
                          <Badge variant="outline" className="bg-teal-50 border-teal-200 text-teal-700 text-[10px] px-1.5 py-0">
                            {EVAL_TYPE_MAP[ev.type] || ev.type}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-1.5 text-xs text-gray-500 flex-wrap">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {formatPersianDateShort(ev.date)}
                          </span>
                          {ev.score !== null && (
                            <span className="font-medium text-gray-700">
                              نمره: {toPersianNumber(ev.score)} از {toPersianNumber(ev.maxScore)}
                            </span>
                          )}
                        </div>
                        {ev.notes && (
                          <p className="text-xs text-gray-500 mt-1">{ev.notes}</p>
                        )}
                      </div>
                      {ev.score !== null && (
                        <div className="flex items-center gap-2 shrink-0">
                          <div className="text-center">
                            <p className="text-2xl font-bold text-gray-900">
                              {toPersianNumber(ev.score)}
                            </p>
                            <p className="text-[10px] text-gray-400">
                              از {toPersianNumber(ev.maxScore)}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab 4: Certificates ── */}
        <TabsContent value="certificates">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3 flex-row items-center justify-between">
              <CardTitle className="text-sm font-bold text-gray-500">
                گواهینامه‌ها
              </CardTitle>
              <Button
                size="sm"
                className="gap-1.5 bg-teal-600 hover:bg-teal-700"
                onClick={() => setCertDialogOpen(true)}
              >
                <Plus className="w-4 h-4" />
                صدور گواهینامه
              </Button>
            </CardHeader>
            <CardContent>
              {karAmuz.certificates.length === 0 ? (
                <div className="text-center py-10">
                  <Award className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                  <p className="text-sm text-gray-500">هنوز گواهینامه‌ای صادر نشده است</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {karAmuz.certificates.map((cert) => {
                    const cStatus = CERT_STATUS[cert.status] || CERT_STATUS.PENDING;
                    return (
                      <div
                        key={cert.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100 gap-3"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-medium text-gray-900 text-sm">
                              {cert.skillProgram.name}
                            </p>
                            <Badge
                              variant="outline"
                              className={`${cStatus.bg} ${cStatus.color} text-[10px] px-1.5 py-0`}
                            >
                              {cStatus.label}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 mt-1.5 text-xs text-gray-500 flex-wrap">
                            {cert.certificateNo && (
                              <span>شماره: {toPersianNumber(cert.certificateNo)}</span>
                            )}
                            {cert.issueDate && (
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {formatPersianDateShort(cert.issueDate)}
                              </span>
                            )}
                          </div>
                        </div>
                        {/* Status action buttons */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {cert.status === 'PENDING' && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs h-7 gap-1"
                              onClick={() => handleCertStatusChange(cert.id, 'EXAM_REGISTERED')}
                            >
                              <Building className="w-3 h-3" />
                              ثبت‌نام آزمون
                            </Button>
                          )}
                          {cert.status === 'EXAM_REGISTERED' && (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-xs h-7 gap-1 text-emerald-700 border-emerald-200 hover:bg-emerald-50"
                                onClick={() => handleCertStatusChange(cert.id, 'EXAM_PASSED')}
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                قبول
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-xs h-7 gap-1 text-red-700 border-red-200 hover:bg-red-50"
                                onClick={() => handleCertStatusChange(cert.id, 'EXAM_FAILED')}
                              >
                                <XCircle className="w-3 h-3" />
                                مردود
                              </Button>
                            </>
                          )}
                          {cert.status === 'EXAM_PASSED' && (
                            <Button
                              size="sm"
                              className="text-xs h-7 gap-1 bg-teal-600 hover:bg-teal-700"
                              onClick={() => handleCertStatusChange(cert.id, 'ISSUED')}
                            >
                              <Award className="w-3 h-3" />
                              صدور گواهینامه
                            </Button>
                          )}
                          {cert.status === 'EXAM_FAILED' && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs h-7 gap-1"
                              onClick={() => handleCertStatusChange(cert.id, 'EXAM_REGISTERED')}
                            >
                              <Clock className="w-3 h-3" />
                              ثبت‌نام مجدد
                            </Button>
                          )}
                          {cert.status === 'ISSUED' && (
                            <div className="flex items-center gap-1.5">
                              <Badge className="bg-teal-600 text-white text-xs gap-1">
                                <CheckCircle2 className="w-3 h-3" />
                                صادر شده
                              </Badge>
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-xs h-7 gap-1 text-teal-700 border-teal-200 hover:bg-teal-50"
                                onClick={() => window.open(`/api/crm/certificates/${cert.id}/pdf`, '_blank')}
                              >
                                <FileDown className="w-3 h-3" />
                                دانلود گواهینامه
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab 5: Payments ── */}
        <TabsContent value="payments">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <CardTitle className="text-sm font-bold text-gray-500">
                  پرداخت‌ها
                </CardTitle>
                <Button
                  size="sm"
                  className="gap-1.5 bg-teal-600 hover:bg-teal-700"
                  onClick={() => setPaymentDialogOpen(true)}
                >
                  <Plus className="w-4 h-4" />
                  ثبت پرداخت
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {/* Summary */}
              {karAmuz.payments.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-5">
                  <div className="bg-gray-50 rounded-lg p-3 text-center">
                    <p className="text-[10px] text-gray-500">مبلغ کل</p>
                    <p className="text-sm font-bold text-gray-900">{formatToman(totalPayAmount)}</p>
                  </div>
                  <div className="bg-emerald-50 rounded-lg p-3 text-center">
                    <p className="text-[10px] text-emerald-600">پرداخت شده</p>
                    <p className="text-sm font-bold text-emerald-700">{formatToman(paidAmount)}</p>
                  </div>
                  <div className="bg-amber-50 rounded-lg p-3 text-center col-span-2 sm:col-span-1">
                    <p className="text-[10px] text-amber-600">مانده</p>
                    <p className="text-sm font-bold text-amber-700">{formatToman(totalPayAmount - paidAmount)}</p>
                  </div>
                </div>
              )}

              {karAmuz.payments.length === 0 ? (
                <div className="text-center py-10">
                  <CreditCard className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                  <p className="text-sm text-gray-500">هنوز پرداختی ثبت نشده است</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {karAmuz.payments.map((pay) => {
                    const pStatus = PAYMENT_STATUS_MAP[pay.status] || PAYMENT_STATUS_MAP.PENDING;
                    return (
                      <div
                        key={pay.id}
                        className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100 gap-3"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-bold text-gray-900 text-sm">
                              {formatRials(pay.amount)}
                            </p>
                            <Badge
                              variant="outline"
                              className={`${pStatus.bg} ${pStatus.color} text-[10px] px-1.5 py-0`}
                            >
                              {pStatus.label}
                            </Badge>
                            <Badge variant="outline" className="bg-gray-50 text-gray-600 text-[10px] px-1.5 py-0">
                              {PAYMENT_TYPE_MAP[pay.type] || pay.type}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 mt-1.5 text-xs text-gray-500 flex-wrap">
                            {pay.dueDate && (
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                سررسید: {formatPersianDateShort(pay.dueDate)}
                              </span>
                            )}
                            {pay.paidAt && (
                              <span className="flex items-center gap-1 text-emerald-600">
                                <CheckCircle2 className="w-3 h-3" />
                                پرداخت: {formatPersianDateShort(pay.paidAt)}
                              </span>
                            )}
                          </div>
                          {pay.note && (
                            <p className="text-xs text-gray-400 mt-1">{pay.note}</p>
                          )}
                        </div>
                        {/* Actions */}
                        <div className="flex items-center gap-1.5">
                          {pay.status === 'PENDING' && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs h-7 gap-1 text-emerald-700 border-emerald-200 hover:bg-emerald-50"
                              onClick={() => handlePayStatusChange(pay.id, 'PAID')}
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              تأیید پرداخت
                            </Button>
                          )}
                          {(pay.status === 'PENDING' || pay.status === 'OVERDUE') && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-xs h-7 gap-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                              onClick={() => handlePayStatusChange(pay.id, 'CANCELLED')}
                            >
                              <XCircle className="w-3 h-3" />
                              لغو
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ─────────── Dialogs ─────────── */}

      {/* Status Change Dialog */}
      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>تغییر وضعیت کارآموز</DialogTitle>
            <DialogDescription>
              وضعیت فعلی: {statusMeta.label}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Label className="text-sm">وضعیت جدید</Label>
            <Select value={newStatus} onValueChange={setNewStatus}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(STATUS_META).map(([key, meta]) => (
                  <SelectItem key={key} value={key}>
                    <div className="flex items-center gap-2">
                      <meta.icon className={`w-4 h-4 ${meta.color}`} />
                      {meta.label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setStatusDialogOpen(false)}
              size="sm"
            >
              انصراف
            </Button>
            <Button
              onClick={handleStatusChange}
              disabled={changingStatus || newStatus === karAmuz.status}
              className="bg-teal-600 hover:bg-teal-700"
              size="sm"
            >
              {changingStatus && <Loader2 className="w-4 h-4 animate-spin ml-1" />}
              تأیید
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Enrollment Dialog */}
      <Dialog open={enrollDialogOpen} onOpenChange={setEnrollDialogOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>ثبت‌نام در دوره جدید</DialogTitle>
            <DialogDescription>
              دوره مورد نظر را برای ثبت‌نام انتخاب کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            {availablePrograms.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-4">
                دوره دیگری برای ثبت‌نام موجود نیست
              </p>
            ) : (
              <Select value={selectedProgramId} onValueChange={setSelectedProgramId}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب دوره مهارتی" />
                </SelectTrigger>
                <SelectContent>
                  {availablePrograms.map((sp) => (
                    <SelectItem key={sp.id} value={sp.id}>
                      {sp.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setEnrollDialogOpen(false)}
              size="sm"
            >
              انصراف
            </Button>
            <Button
              onClick={handleEnroll}
              disabled={enrolling || !selectedProgramId}
              className="bg-teal-600 hover:bg-teal-700"
              size="sm"
            >
              {enrolling && <Loader2 className="w-4 h-4 animate-spin ml-1" />}
              ثبت‌نام
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Attendance Dialog */}
      <Dialog open={attendanceDialogOpen} onOpenChange={setAttendanceDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>ثبت حضور و غیاب</DialogTitle>
            <DialogDescription>
              جلسه و وضعیت حضور را مشخص کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {/* Step 1: Select Skill Program */}
            <div className="space-y-1.5">
              <Label className="text-sm">برنامه مهارتی</Label>
              <Select
                value={attProgramId}
                onValueChange={(val) => {
                  setAttProgramId(val);
                  setAttSessionId('');
                  fetchSessions(val);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب برنامه مهارتی" />
                </SelectTrigger>
                <SelectContent>
                  {enrolledPrograms
                    .filter((p) => karAmuz.enrollments.find((e) => e.skillProgramId === p.id && e.status === 'ENROLLED'))
                    .map((sp) => (
                      <SelectItem key={sp.id} value={sp.id}>
                        {sp.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            {/* Step 2: Select Session */}
            <div className="space-y-1.5">
              <Label className="text-sm">جلسه</Label>
              <Select value={attSessionId} onValueChange={setAttSessionId} disabled={!attProgramId || sessions.length === 0}>
                <SelectTrigger>
                  <SelectValue placeholder={sessions.length === 0 ? 'جلسه‌ای یافت نشد' : 'انتخاب جلسه'} />
                </SelectTrigger>
                <SelectContent>
                  {sessions.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {formatPersianDateShort(s.date)} — {s.title || (SESSION_TYPE_MAP[s.type] || s.type)} ({s.startTime} - {s.endTime})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Step 3: Status */}
            <div className="space-y-1.5">
              <Label className="text-sm">وضعیت حضور</Label>
              <Select value={attStatus} onValueChange={setAttStatus}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(ATTENDANCE_STATUS).map(([key, meta]) => (
                    <SelectItem key={key} value={key}>
                      {meta.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Hours */}
            <div className="space-y-1.5">
              <Label className="text-sm">ساعات حضور</Label>
              <Input
                type="number"
                value={attHours}
                onChange={(e) => setAttHours(e.target.value)}
                placeholder="مثلاً 2"
                className="h-9"
                dir="ltr"
              />
            </div>

            {/* Notes */}
            <div className="space-y-1.5">
              <Label className="text-sm">توضیحات (اختیاری)</Label>
              <Input
                value={attNotes}
                onChange={(e) => setAttNotes(e.target.value)}
                placeholder="توضیحات"
                className="h-9"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setAttendanceDialogOpen(false)}
              size="sm"
            >
              انصراف
            </Button>
            <Button
              onClick={handleAddAttendance}
              disabled={submittingAtt || !attSessionId}
              className="bg-teal-600 hover:bg-teal-700"
              size="sm"
            >
              {submittingAtt && <Loader2 className="w-4 h-4 animate-spin ml-1" />}
              ثبت
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Evaluation Dialog */}
      <Dialog open={evalDialogOpen} onOpenChange={setEvalDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>افزودن ارزیابی</DialogTitle>
            <DialogDescription>
              اطلاعات ارزیابی جدید را وارد کنید
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm">برنامه مهارتی</Label>
              <Select
                value={evalForm.skillProgramId}
                onValueChange={(val) => setEvalForm({ ...evalForm, skillProgramId: val })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب برنامه مهارتی" />
                </SelectTrigger>
                <SelectContent>
                  {enrolledPrograms.map((sp) => (
                    <SelectItem key={sp.id} value={sp.id}>
                      {sp.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm">نوع ارزیابی</Label>
              <Select
                value={evalForm.type}
                onValueChange={(val) => setEvalForm({ ...evalForm, type: val })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(EVAL_TYPE_MAP).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm">عنوان</Label>
              <Input
                value={evalForm.title}
                onChange={(e) => setEvalForm({ ...evalForm, title: e.target.value })}
                placeholder="مثلاً: آزمون میان‌ترم"
                className="h-9"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm">نمره</Label>
                <Input
                  type="number"
                  value={evalForm.score}
                  onChange={(e) => setEvalForm({ ...evalForm, score: e.target.value })}
                  placeholder="—"
                  className="h-9"
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm">نمره کل</Label>
                <Input
                  type="number"
                  value={evalForm.maxScore}
                  onChange={(e) => setEvalForm({ ...evalForm, maxScore: e.target.value })}
                  className="h-9"
                  dir="ltr"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm">تاریخ</Label>
              <Input
                type="date"
                value={evalForm.date}
                onChange={(e) => setEvalForm({ ...evalForm, date: e.target.value })}
                className="h-9"
                dir="ltr"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm">توضیحات (اختیاری)</Label>
              <Textarea
                value={evalForm.notes}
                onChange={(e) => setEvalForm({ ...evalForm, notes: e.target.value })}
                className="min-h-[60px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setEvalDialogOpen(false)}
              size="sm"
            >
              انصراف
            </Button>
            <Button
              onClick={handleAddEvaluation}
              disabled={submittingEval || !evalForm.skillProgramId || !evalForm.title}
              className="bg-teal-600 hover:bg-teal-700"
              size="sm"
            >
              {submittingEval && <Loader2 className="w-4 h-4 animate-spin ml-1" />}
              ثبت ارزیابی
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Certificate Dialog */}
      <Dialog open={certDialogOpen} onOpenChange={setCertDialogOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>صدور گواهینامه</DialogTitle>
            <DialogDescription>
              برنامه مهارتی مورد نظر را انتخاب کنید. شماره گواهینامه به صورت خودکار تولید می‌شود.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Label className="text-sm">برنامه مهارتی</Label>
            <Select value={certProgramId} onValueChange={setCertProgramId}>
              <SelectTrigger>
                <SelectValue placeholder="انتخاب برنامه مهارتی" />
              </SelectTrigger>
              <SelectContent>
                {enrolledPrograms.map((sp) => (
                  <SelectItem key={sp.id} value={sp.id}>
                    {sp.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setCertDialogOpen(false)}
              size="sm"
            >
              انصراف
            </Button>
            <Button
              onClick={handleAddCertificate}
              disabled={submittingCert || !certProgramId}
              className="bg-teal-600 hover:bg-teal-700"
              size="sm"
            >
              {submittingCert && <Loader2 className="w-4 h-4 animate-spin ml-1" />}
              صدور گواهینامه
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>ثبت پرداخت</DialogTitle>
            <DialogDescription>
              اطلاعات پرداخت جدید را وارد کنید (مبلغ به تومان)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm">مبلغ (تومان)</Label>
              <Input
                type="number"
                value={payForm.amount}
                onChange={(e) => setPayForm({ ...payForm, amount: e.target.value })}
                placeholder="مثلاً 5000000"
                className="h-9"
                dir="ltr"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm">نوع پرداخت</Label>
              <Select
                value={payForm.type}
                onValueChange={(val) => setPayForm({ ...payForm, type: val })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(PAYMENT_TYPE_MAP).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm">سررسید (اختیاری)</Label>
              <Input
                type="date"
                value={payForm.dueDate}
                onChange={(e) => setPayForm({ ...payForm, dueDate: e.target.value })}
                className="h-9"
                dir="ltr"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm">توضیحات (اختیاری)</Label>
              <Input
                value={payForm.note}
                onChange={(e) => setPayForm({ ...payForm, note: e.target.value })}
                className="h-9"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setPaymentDialogOpen(false)}
              size="sm"
            >
              انصراف
            </Button>
            <Button
              onClick={handleAddPayment}
              disabled={submittingPay || !payForm.amount}
              className="bg-teal-600 hover:bg-teal-700"
              size="sm"
            >
              {submittingPay && <Loader2 className="w-4 h-4 animate-spin ml-1" />}
              ثبت پرداخت
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
