'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import {
  Store,
  Plus,
  Loader2,
  AlertTriangle,
  Eye,
  CheckCircle2,
  XCircle,
  Pencil,
  Star,
  Download,
  Users,
  Package,
  Clock,
  Search,
  RefreshCw,
  ExternalLink,
  FileText,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface MarketplaceApp {
  id: string;
  tenantId: string;
  name: string;
  slug: string;
  description: string;
  shortDesc: string | null;
  category: string;
  iconUrl: string | null;
  version: string;
  pricingModel: string;
  price: number;
  monthlyPrice: number | null;
  status: string;
  reviewNotes: string | null;
  downloads: number;
  rating: number;
  reviewCount: number;
  developerName: string | null;
  developerEmail: string | null;
  supportUrl: string | null;
  documentationUrl: string | null;
  createdAt: string;
  updatedAt: string;
  tenant: { id: string; name: string; slug: string };
  _count: { subscriptions: number; reviews: number };
}

interface AppSubscription {
  id: string;
  appId: string;
  subscriberTenantId: string;
  status: string;
  plan: string;
  startDate: string;
  endDate: string | null;
  createdAt: string;
  app: { name: string };
}

interface AppReviewItem {
  id: string;
  appId: string;
  reviewerTenantId: string;
  rating: number;
  title: string | null;
  comment: string | null;
  createdAt: string;
}

interface AppDetail {
  id: string;
  tenantId: string;
  name: string;
  slug: string;
  description: string;
  shortDesc: string | null;
  category: string;
  iconUrl: string | null;
  version: string;
  apiEndpoints: unknown;
  requiredScopes: unknown;
  pricingModel: string;
  price: number;
  monthlyPrice: number | null;
  status: string;
  reviewNotes: string | null;
  downloads: number;
  rating: number;
  reviewCount: number;
  developerName: string | null;
  developerEmail: string | null;
  supportUrl: string | null;
  documentationUrl: string | null;
  createdAt: string;
  updatedAt: string;
  tenant: { id: string; name: string; slug: string };
  subscriptions: AppSubscription[];
  reviews: AppReviewItem[];
}

interface Stats {
  total: number;
  approved: number;
  pending: number;
  totalDownloads: number;
  totalSubscriptions: number;
  categories: { category: string; _count: number }[];
}

interface TenantItem {
  id: string;
  name: string;
  slug: string;
}

/* ─────────── Constants ─────────── */

const CATEGORY_MAP: Record<string, { label: string; color: string; bg: string }> = {
  INTEGRATION: { label: 'یکپارچه‌سازی', color: 'text-violet-700', bg: 'bg-violet-50 border-violet-200' },
  PLUGIN: { label: 'افزونه', color: 'text-cyan-700', bg: 'bg-cyan-50 border-cyan-200' },
  ANALYTICS: { label: 'تحلیل', color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200' },
  PAYMENT: { label: 'پرداخت', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
  COMMUNICATION: { label: 'ارتباطات', color: 'text-rose-700', bg: 'bg-rose-50 border-rose-200' },
  OTHER: { label: 'سایر', color: 'text-gray-700', bg: 'bg-gray-50 border-gray-200' },
};

const PRICING_MAP: Record<string, { label: string; color: string; bg: string }> = {
  FREE: { label: 'رایگان', color: 'text-green-700', bg: 'bg-green-50 border-green-200' },
  ONE_TIME: { label: 'یک‌باره', color: 'text-blue-700', bg: 'bg-blue-50 border-blue-200' },
  SUBSCRIPTION: { label: 'اشتراکی', color: 'text-purple-700', bg: 'bg-purple-50 border-purple-200' },
  USAGE_BASED: { label: 'مبتنی بر مصرف', color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200' },
};

const STATUS_MAP: Record<string, { label: string; color: string; bg: string }> = {
  APPROVED: { label: 'تأییدشده', color: 'text-green-700', bg: 'bg-green-50 border-green-200' },
  PENDING_REVIEW: { label: 'در انتظار بررسی', color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200' },
  DRAFT: { label: 'پیش‌نویس', color: 'text-gray-600', bg: 'bg-gray-50 border-gray-200' },
  REJECTED: { label: 'ردشده', color: 'text-red-700', bg: 'bg-red-50 border-red-200' },
  SUSPENDED: { label: 'معلق', color: 'text-orange-700', bg: 'bg-orange-50 border-orange-200' },
};

const CATEGORY_COLORS: Record<string, string> = {
  INTEGRATION: 'bg-violet-500',
  PLUGIN: 'bg-cyan-500',
  ANALYTICS: 'bg-amber-500',
  PAYMENT: 'bg-emerald-500',
  COMMUNICATION: 'bg-rose-500',
  OTHER: 'bg-gray-500',
};

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string | null) {
  if (!dateStr) return '—';
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^\w\u0600-\u06FF-]/g, '')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

function renderStars(rating: number) {
  const stars = [];
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  for (let i = 0; i < 5; i++) {
    if (i < full) {
      stars.push(<Star key={i} className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />);
    } else if (i === full && half) {
      stars.push(<Star key={i} className="w-3.5 h-3.5 fill-yellow-400/50 text-yellow-400" />);
    } else {
      stars.push(<Star key={i} className="w-3.5 h-3.5 text-gray-300" />);
    }
  }
  return stars;
}

/* ─────────── Main Component ─────────── */

export default function MarketplacePage() {
  const [apps, setApps] = useState<MarketplaceApp[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Tenants for the create dialog
  const [tenants, setTenants] = useState<TenantItem[]>([]);

  // Create dialog
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formTenantId, setFormTenantId] = useState('');
  const [formName, setFormName] = useState('');
  const [formSlug, setFormSlug] = useState('');
  const [formShortDesc, setFormShortDesc] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formPricingModel, setFormPricingModel] = useState('FREE');
  const [formPrice, setFormPrice] = useState('');
  const [formMonthlyPrice, setFormMonthlyPrice] = useState('');
  const [formDeveloperName, setFormDeveloperName] = useState('');
  const [formDeveloperEmail, setFormDeveloperEmail] = useState('');
  const [formSupportUrl, setFormSupportUrl] = useState('');
  const [formDocumentationUrl, setFormDocumentationUrl] = useState('');

  // Detail dialog
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [selectedApp, setSelectedApp] = useState<AppDetail | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [reviewSubmitting, setReviewSubmitting] = useState(false);

  // Edit dialog
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editSubmitting, setEditSubmitting] = useState(false);
  const [editApp, setEditApp] = useState<MarketplaceApp | null>(null);
  const [editName, setEditName] = useState('');
  const [editShortDesc, setEditShortDesc] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editPricingModel, setEditPricingModel] = useState('');
  const [editPrice, setEditPrice] = useState('');
  const [editMonthlyPrice, setEditMonthlyPrice] = useState('');
  const [editSupportUrl, setEditSupportUrl] = useState('');
  const [editDocumentationUrl, setEditDocumentationUrl] = useState('');

  /* ── Data Fetching ── */

  const fetchApps = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (activeTab !== 'all') params.set('category', activeTab);
      const res = await fetch(`/api/admin/marketplace?${params.toString()}`);
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'خطا در دریافت اپلیکیشن‌ها');
        return;
      }
      setApps(data.apps || []);
      setStats(data.stats || null);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [activeTab]);

  const fetchTenants = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/tenants');
      const data = await res.json();
      if (res.ok) {
        setTenants((data.tenants || []).map((t: { id: string; name: string; slug: string }) => ({
          id: t.id,
          name: t.name,
          slug: t.slug,
        })));
      }
    } catch {
      // Silent
    }
  }, []);

  useEffect(() => {
    fetchApps();
  }, [fetchApps]);

  useEffect(() => {
    fetchTenants();
  }, [fetchTenants]);

  /* ── Filtered apps ── */

  const filteredApps = useMemo(() => {
    let result = apps;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (a) =>
          a.name.toLowerCase().includes(q) ||
          a.slug.toLowerCase().includes(q) ||
          (a.shortDesc && a.shortDesc.toLowerCase().includes(q)) ||
          (a.developerName && a.developerName.toLowerCase().includes(q))
      );
    }
    return result;
  }, [apps, searchQuery]);

  /* ── Handlers ── */

  const handleCreateApp = async () => {
    if (!formTenantId || !formName.trim() || !formSlug.trim() || !formDescription.trim() || !formCategory) {
      toast.error('لطفاً فیلدهای الزامی را تکمیل کنید');
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch('/api/admin/marketplace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: formTenantId,
          name: formName,
          slug: formSlug,
          description: formDescription,
          shortDesc: formShortDesc || null,
          category: formCategory,
          pricingModel: formPricingModel,
          price: formPricingModel !== 'FREE' ? Number(formPrice) || 0 : 0,
          monthlyPrice: formPricingModel === 'SUBSCRIPTION' ? Number(formMonthlyPrice) || null : null,
          developerName: formDeveloperName || null,
          developerEmail: formDeveloperEmail || null,
          supportUrl: formSupportUrl || null,
          documentationUrl: formDocumentationUrl || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || 'خطا در ایجاد اپلیکیشن');
        return;
      }
      toast.success('اپلیکیشن با موفقیت ایجاد شد');
      setCreateDialogOpen(false);
      resetCreateForm();
      fetchApps();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setSubmitting(false);
    }
  };

  const resetCreateForm = () => {
    setFormTenantId('');
    setFormName('');
    setFormSlug('');
    setFormShortDesc('');
    setFormDescription('');
    setFormCategory('');
    setFormPricingModel('FREE');
    setFormPrice('');
    setFormMonthlyPrice('');
    setFormDeveloperName('');
    setFormDeveloperEmail('');
    setFormSupportUrl('');
    setFormDocumentationUrl('');
  };

  const handleViewDetail = async (appId: string) => {
    setDetailLoading(true);
    setDetailDialogOpen(true);
    setReviewNotes('');
    try {
      const res = await fetch(`/api/admin/marketplace/${appId}`);
      const data = await res.json();
      if (res.ok) {
        setSelectedApp(data.app);
      } else {
        toast.error(data.error || 'خطا در دریافت اطلاعات');
        setDetailDialogOpen(false);
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
      setDetailDialogOpen(false);
    } finally {
      setDetailLoading(false);
    }
  };

  const handleReview = async (appId: string, action: 'APPROVED' | 'REJECTED') => {
    setReviewSubmitting(true);
    try {
      const res = await fetch(`/api/admin/marketplace/${appId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status: action,
          reviewNotes: reviewNotes || null,
        }),
      });
      if (res.ok) {
        toast.success(action === 'APPROVED' ? 'اپلیکیشن تأیید شد' : 'اپلیکیشن رد شد');
        setDetailDialogOpen(false);
        fetchApps();
      } else {
        const data = await res.json();
        toast.error(data.error || 'خطا در به‌روزرسانی وضعیت');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setReviewSubmitting(false);
    }
  };

  const handleOpenEdit = (app: MarketplaceApp) => {
    setEditApp(app);
    setEditName(app.name);
    setEditShortDesc(app.shortDesc || '');
    setEditDescription(app.description);
    setEditCategory(app.category);
    setEditPricingModel(app.pricingModel);
    setEditPrice(app.pricingModel !== 'FREE' ? String(app.price) : '');
    setEditMonthlyPrice(app.monthlyPrice ? String(app.monthlyPrice) : '');
    setEditSupportUrl(app.supportUrl || '');
    setEditDocumentationUrl(app.documentationUrl || '');
    setEditDialogOpen(true);
  };

  const handleEditSubmit = async () => {
    if (!editApp) return;
    setEditSubmitting(true);
    try {
      const res = await fetch(`/api/admin/marketplace/${editApp.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName,
          description: editDescription,
          shortDesc: editShortDesc || null,
          pricingModel: editPricingModel,
          price: editPricingModel !== 'FREE' ? Number(editPrice) || 0 : 0,
          monthlyPrice: editPricingModel === 'SUBSCRIPTION' ? Number(editMonthlyPrice) || null : null,
          supportUrl: editSupportUrl || null,
          documentationUrl: editDocumentationUrl || null,
        }),
      });
      if (res.ok) {
        toast.success('اپلیکیشن به‌روزرسانی شد');
        setEditDialogOpen(false);
        fetchApps();
      } else {
        const data = await res.json();
        toast.error(data.error || 'خطا در به‌روزرسانی');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setEditSubmitting(false);
    }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Store className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">API Marketplace</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {stats ? toPersianNumber(stats.total) : '—'}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مارکت اپلیکیشن — مدیریت افزونه‌ها و اتصالات</p>
          </div>
        </div>
        <Button
          onClick={() => {
            resetCreateForm();
            setCreateDialogOpen(true);
          }}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          اپلیکیشن جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-medium">کل اپلیکیشن‌ها</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {loading ? <Skeleton className="h-7 w-12 inline-block" /> : toPersianNumber(stats?.total || 0)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-gray-100">
                <Package className="w-5 h-5 text-gray-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-medium">تأییدشده</p>
                <p className="text-2xl font-bold text-green-700 mt-1">
                  {loading ? <Skeleton className="h-7 w-12 inline-block" /> : toPersianNumber(stats?.approved || 0)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-medium">در انتظار بررسی</p>
                <p className="text-2xl font-bold text-blue-700 mt-1">
                  {loading ? <Skeleton className="h-7 w-12 inline-block" /> : toPersianNumber(stats?.pending || 0)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500 font-medium">کل اشتراک‌ها</p>
                <p className="text-2xl font-bold text-purple-700 mt-1">
                  {loading ? <Skeleton className="h-7 w-12 inline-block" /> : toPersianNumber(stats?.totalSubscriptions || 0)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-50">
                <Users className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search & Tabs */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="جستجوی اپلیکیشن..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-9"
            />
          </div>
          <Button variant="outline" size="icon" onClick={fetchApps} title="بازخوانی">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-gray-100/80 p-1 h-auto flex-wrap">
            <TabsTrigger value="all" className="text-xs">همه</TabsTrigger>
            <TabsTrigger value="INTEGRATION" className="text-xs">یکپارچه‌سازی</TabsTrigger>
            <TabsTrigger value="PLUGIN" className="text-xs">افزونه</TabsTrigger>
            <TabsTrigger value="ANALYTICS" className="text-xs">تحلیل</TabsTrigger>
            <TabsTrigger value="PAYMENT" className="text-xs">پرداخت</TabsTrigger>
            <TabsTrigger value="COMMUNICATION" className="text-xs">ارتباطات</TabsTrigger>
            <TabsTrigger value="OTHER" className="text-xs">سایر</TabsTrigger>
          </TabsList>

          {/* We use a single TabsContent that renders the filtered grid */}
          <TabsContent value={activeTab} className="mt-4">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="border-0 shadow-sm">
                    <CardContent className="p-5">
                      <div className="flex items-start gap-3">
                        <Skeleton className="w-12 h-12 rounded-full shrink-0" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-5 w-3/4" />
                          <Skeleton className="h-4 w-full" />
                          <Skeleton className="h-4 w-1/2" />
                        </div>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <Skeleton className="h-6 w-16" />
                        <Skeleton className="h-6 w-16" />
                      </div>
                      <div className="flex gap-2 mt-4">
                        <Skeleton className="h-8 w-20" />
                        <Skeleton className="h-8 w-20" />
                        <Skeleton className="h-8 w-20" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : error ? (
              <Card className="border-red-200 bg-red-50">
                <CardContent className="p-6 text-center">
                  <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
                  <p className="text-red-700 font-medium">{error}</p>
                  <Button variant="outline" size="sm" className="mt-3" onClick={fetchApps}>
                    تلاش مجدد
                  </Button>
                </CardContent>
              </Card>
            ) : filteredApps.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-12 text-center">
                  <Store className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500 font-medium">اپلیکیشنی یافت نشد</p>
                  <p className="text-gray-400 text-sm mt-1">
                    {searchQuery ? 'عبارت جستجو تغییر کند یا' : 'اولین اپلیکیشن را ایجاد کنید'}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredApps.map((app) => {
                  const catInfo = CATEGORY_MAP[app.category] || CATEGORY_MAP.OTHER;
                  const priceInfo = PRICING_MAP[app.pricingModel] || PRICING_MAP.FREE;
                  const statusInfo = STATUS_MAP[app.status] || STATUS_MAP.DRAFT;
                  const iconBg = CATEGORY_COLORS[app.category] || 'bg-gray-500';

                  return (
                    <Card
                      key={app.id}
                      className="border-0 shadow-sm hover:shadow-md transition-shadow group"
                    >
                      <CardContent className="p-5">
                        {/* App header */}
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-12 h-12 rounded-full ${iconBg} flex items-center justify-center shrink-0`}
                          >
                            <span className="text-white font-bold text-lg">
                              {app.name.charAt(0)}
                            </span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-bold text-gray-900 truncate">{app.name}</h3>
                            <p className="text-xs text-gray-400 font-mono mt-0.5">{app.slug}</p>
                          </div>
                          <Badge
                            variant="secondary"
                            className={`${statusInfo.bg} ${statusInfo.color} text-xs border-0 shrink-0`}
                          >
                            {statusInfo.label}
                          </Badge>
                        </div>

                        {/* Description */}
                        <p className="text-sm text-gray-600 mt-3 line-clamp-2 leading-6">
                          {app.shortDesc || app.description}
                        </p>

                        {/* Badges row */}
                        <div className="flex flex-wrap gap-1.5 mt-3">
                          <Badge
                            variant="secondary"
                            className={`${catInfo.bg} ${catInfo.color} text-xs border-0`}
                          >
                            {catInfo.label}
                          </Badge>
                          <Badge
                            variant="secondary"
                            className={`${priceInfo.bg} ${priceInfo.color} text-xs border-0`}
                          >
                            {priceInfo.label}
                          </Badge>
                        </div>

                        {/* Stats row */}
                        <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
                          <div className="flex items-center gap-1">
                            <Download className="w-3.5 h-3.5" />
                            <span>{toPersianNumber(app.downloads)}</span>
                          </div>
                          <div className="flex items-center gap-0.5">
                            {renderStars(app.rating)}
                            <span className="mr-1 text-gray-400">
                              ({toPersianNumber(app.reviewCount)})
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="w-3.5 h-3.5" />
                            <span>{toPersianNumber(app._count.subscriptions)}</span>
                          </div>
                        </div>

                        {/* Tenant info */}
                        <div className="flex items-center gap-1.5 mt-2.5 text-xs text-gray-400">
                          <span>صاحب:</span>
                          <span className="text-gray-600 font-medium">{app.tenant.name}</span>
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-gray-100">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 text-xs gap-1 text-gray-600 hover:text-gray-900"
                            onClick={() => handleViewDetail(app.id)}
                          >
                            <Eye className="w-3.5 h-3.5" />
                            مشاهده
                          </Button>
                          {(app.status === 'PENDING_REVIEW' || app.status === 'DRAFT') && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 text-xs gap-1 text-green-600 hover:text-green-700 hover:bg-green-50"
                                onClick={async () => {
                                  try {
                                    const res = await fetch(`/api/admin/marketplace/${app.id}`, {
                                      method: 'PUT',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ status: 'APPROVED' }),
                                    });
                                    if (res.ok) {
                                      toast.success('اپلیکیشن تأیید شد');
                                      fetchApps();
                                    } else {
                                      toast.error('خطا در تأیید اپلیکیشن');
                                    }
                                  } catch {
                                    toast.error('خطا در ارتباط با سرور');
                                  }
                                }}
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                تأیید
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 text-xs gap-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                                onClick={async () => {
                                  try {
                                    const res = await fetch(`/api/admin/marketplace/${app.id}`, {
                                      method: 'PUT',
                                      headers: { 'Content-Type': 'application/json' },
                                      body: JSON.stringify({ status: 'REJECTED' }),
                                    });
                                    if (res.ok) {
                                      toast.success('اپلیکیشن رد شد');
                                      fetchApps();
                                    } else {
                                      toast.error('خطا در رد اپلیکیشن');
                                    }
                                  } catch {
                                    toast.error('خطا در ارتباط با سرور');
                                  }
                                }}
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                رد
                              </Button>
                            </>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 text-xs gap-1 text-gray-500 hover:text-gray-700 hover:bg-gray-100 mr-auto"
                            onClick={() => handleOpenEdit(app)}
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            ویرایش
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* ─── Create App Dialog ─── */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Store className="w-5 h-5 text-teal-600" />
              اپلیکیشن جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Tenant */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">
                Tenant صاحب <span className="text-red-500">*</span>
              </Label>
              <Select value={formTenantId} onValueChange={setFormTenantId}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب Tenant..." />
                </SelectTrigger>
                <SelectContent>
                  {tenants.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name} ({t.slug})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Name & Slug */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">
                  نام اپلیکیشن <span className="text-red-500">*</span>
                </Label>
                <Input
                  placeholder="نام اپلیکیشن..."
                  value={formName}
                  onChange={(e) => {
                    setFormName(e.target.value);
                    setFormSlug(slugify(e.target.value));
                  }}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">
                  شناسه <span className="text-red-500">*</span>
                </Label>
                <Input
                  placeholder="slug..."
                  value={formSlug}
                  onChange={(e) => setFormSlug(e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </div>

            {/* Category */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">
                دسته‌بندی <span className="text-red-500">*</span>
              </Label>
              <Select value={formCategory} onValueChange={setFormCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب دسته‌بندی..." />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORY_MAP).map(([key, val]) => (
                    <SelectItem key={key} value={key}>
                      {val.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Short description */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">توضیح کوتاه</Label>
              <Input
                placeholder="توضیح کوتاه (حداکثر ۱۲۰ کاراکتر)..."
                value={formShortDesc}
                onChange={(e) => {
                  if (e.target.value.length <= 120) setFormShortDesc(e.target.value);
                }}
                maxLength={120}
              />
              <p className="text-xs text-gray-400 text-left" dir="ltr">
                {formShortDesc.length}/120
              </p>
            </div>

            {/* Full description */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">
                توضیحات کامل <span className="text-red-500">*</span>
              </Label>
              <Textarea
                placeholder="توضیحات کامل اپلیکیشن..."
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                rows={4}
              />
            </div>

            {/* Pricing model */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">مدل قیمت‌گذاری</Label>
              <Select value={formPricingModel} onValueChange={setFormPricingModel}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(PRICING_MAP).map(([key, val]) => (
                    <SelectItem key={key} value={key}>
                      {val.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Price fields */}
            {formPricingModel !== 'FREE' && (
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">قیمت (ریال)</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    dir="ltr"
                    className="text-left"
                  />
                </div>
                {formPricingModel === 'SUBSCRIPTION' && (
                  <div className="space-y-1.5">
                    <Label className="text-sm font-medium">اشتراک ماهانه (ریال)</Label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={formMonthlyPrice}
                      onChange={(e) => setFormMonthlyPrice(e.target.value)}
                      dir="ltr"
                      className="text-left"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Developer info */}
            <Separator />
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نام توسعه‌دهنده</Label>
                <Input
                  placeholder="نام توسعه‌دهنده..."
                  value={formDeveloperName}
                  onChange={(e) => setFormDeveloperName(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">ایمیل توسعه‌دهنده</Label>
                <Input
                  type="email"
                  placeholder="email@example.com"
                  value={formDeveloperEmail}
                  onChange={(e) => setFormDeveloperEmail(e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">لینک پشتیبانی</Label>
                <Input
                  placeholder="https://..."
                  value={formSupportUrl}
                  onChange={(e) => setFormSupportUrl(e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">لینک مستندات</Label>
                <Input
                  placeholder="https://..."
                  value={formDocumentationUrl}
                  onChange={(e) => setFormDocumentationUrl(e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleCreateApp}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
              ایجاد اپلیکیشن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── App Detail Dialog ─── */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Store className="w-5 h-5 text-teal-600" />
              جزئیات اپلیکیشن
            </DialogTitle>
          </DialogHeader>

          {detailLoading ? (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3">
                <Skeleton className="w-14 h-14 rounded-full" />
                <div className="space-y-2">
                  <Skeleton className="h-6 w-48" />
                  <Skeleton className="h-4 w-32" />
                </div>
              </div>
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-4 w-full" />
              ))}
            </div>
          ) : selectedApp ? (
            <div className="space-y-5 py-2">
              {/* App header */}
              <div className="flex items-start gap-4">
                <div
                  className={`w-14 h-14 rounded-full ${
                    CATEGORY_COLORS[selectedApp.category] || 'bg-gray-500'
                  } flex items-center justify-center shrink-0`}
                >
                  <span className="text-white font-bold text-xl">
                    {selectedApp.name.charAt(0)}
                  </span>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-900">{selectedApp.name}</h3>
                  <p className="text-sm text-gray-400 font-mono">{selectedApp.slug}</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    <Badge
                      variant="secondary"
                      className={`${(CATEGORY_MAP[selectedApp.category] || CATEGORY_MAP.OTHER).bg} ${(CATEGORY_MAP[selectedApp.category] || CATEGORY_MAP.OTHER).color} text-xs border-0`}
                    >
                      {(CATEGORY_MAP[selectedApp.category] || CATEGORY_MAP.OTHER).label}
                    </Badge>
                    <Badge
                      variant="secondary"
                      className={`${(PRICING_MAP[selectedApp.pricingModel] || PRICING_MAP.FREE).bg} ${(PRICING_MAP[selectedApp.pricingModel] || PRICING_MAP.FREE).color} text-xs border-0`}
                    >
                      {(PRICING_MAP[selectedApp.pricingModel] || PRICING_MAP.FREE).label}
                    </Badge>
                    <Badge
                      variant="secondary"
                      className={`${(STATUS_MAP[selectedApp.status] || STATUS_MAP.DRAFT).bg} ${(STATUS_MAP[selectedApp.status] || STATUS_MAP.DRAFT).color} text-xs border-0`}
                    >
                      {(STATUS_MAP[selectedApp.status] || STATUS_MAP.DRAFT).label}
                    </Badge>
                  </div>
                </div>
              </div>

              <Separator />

              {/* App info grid */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-gray-500">نسخه:</span>{' '}
                  <span className="font-medium">{selectedApp.version}</span>
                </div>
                <div>
                  <span className="text-gray-500">Tenant صاحب:</span>{' '}
                  <span className="font-medium">{selectedApp.tenant.name}</span>
                </div>
                <div>
                  <span className="text-gray-500">دانلود:</span>{' '}
                  <span className="font-medium">{toPersianNumber(selectedApp.downloads)}</span>
                </div>
                <div>
                  <span className="text-gray-500">امتیاز:</span>{' '}
                  <span className="font-medium flex items-center gap-1">
                    {toPersianNumber(selectedApp.rating)}
                    <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                  </span>
                </div>
                {selectedApp.pricingModel !== 'FREE' && (
                  <div>
                    <span className="text-gray-500">قیمت:</span>{' '}
                    <span className="font-medium">{toPersianNumber(selectedApp.price)} ریال</span>
                  </div>
                )}
                {selectedApp.monthlyPrice && (
                  <div>
                    <span className="text-gray-500">اشتراک ماهانه:</span>{' '}
                    <span className="font-medium">{toPersianNumber(selectedApp.monthlyPrice)} ریال</span>
                  </div>
                )}
                {selectedApp.developerName && (
                  <div>
                    <span className="text-gray-500">توسعه‌دهنده:</span>{' '}
                    <span className="font-medium">{selectedApp.developerName}</span>
                  </div>
                )}
                {selectedApp.developerEmail && (
                  <div>
                    <span className="text-gray-500">ایمیل:</span>{' '}
                    <span className="font-medium" dir="ltr">{selectedApp.developerEmail}</span>
                  </div>
                )}
                <div>
                  <span className="text-gray-500">تاریخ ایجاد:</span>{' '}
                  <span className="font-medium">{formatPersianDate(selectedApp.createdAt)}</span>
                </div>
                <div>
                  <span className="text-gray-500">آخرین به‌روزرسانی:</span>{' '}
                  <span className="font-medium">{formatPersianDate(selectedApp.updatedAt)}</span>
                </div>
              </div>

              {/* Links */}
              {(selectedApp.supportUrl || selectedApp.documentationUrl) && (
                <div className="flex gap-2">
                  {selectedApp.supportUrl && (
                    <a
                      href={selectedApp.supportUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-teal-600 hover:text-teal-700"
                    >
                      <ExternalLink className="w-3 h-3" />
                      پشتیبانی
                    </a>
                  )}
                  {selectedApp.documentationUrl && (
                    <a
                      href={selectedApp.documentationUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-teal-600 hover:text-teal-700"
                    >
                      <FileText className="w-3 h-3" />
                      مستندات
                    </a>
                  )}
                </div>
              )}

              {/* Description */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-1">توضیحات</h4>
                <p className="text-sm text-gray-600 whitespace-pre-wrap leading-7">
                  {selectedApp.description}
                </p>
              </div>

              {selectedApp.reviewNotes && (
                <div>
                  <h4 className="text-sm font-semibold text-gray-700 mb-1">یادداشت بررسی</h4>
                  <p className="text-sm text-gray-600 whitespace-pre-wrap leading-7">
                    {selectedApp.reviewNotes}
                  </p>
                </div>
              )}

              <Separator />

              {/* Subscriptions */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  اشتراک‌ها
                  <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-600 border-0">
                    {toPersianNumber(selectedApp.subscriptions.length)}
                  </Badge>
                </h4>
                {selectedApp.subscriptions.length === 0 ? (
                  <p className="text-xs text-gray-400">اشتراکی ثبت نشده</p>
                ) : (
                  <div className="max-h-48 overflow-y-auto space-y-2 custom-scrollbar">
                    {selectedApp.subscriptions.map((sub) => (
                      <div
                        key={sub.id}
                        className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg text-xs"
                      >
                        <div>
                          <span className="text-gray-400">Tenant:</span>{' '}
                          <span className="font-medium text-gray-700">
                            {sub.subscriberTenantId.slice(0, 12)}...
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge
                            variant="secondary"
                            className={`text-xs border-0 ${
                              sub.status === 'ACTIVE'
                                ? 'bg-green-50 text-green-700'
                                : sub.status === 'TRIAL'
                                ? 'bg-blue-50 text-blue-700'
                                : 'bg-gray-50 text-gray-600'
                            }`}
                          >
                            {sub.status === 'ACTIVE'
                              ? 'فعال'
                              : sub.status === 'TRIAL'
                              ? 'آزمایشی'
                              : sub.status === 'CANCELLED'
                              ? 'لغوشده'
                              : 'منقضی'}
                          </Badge>
                          <Badge
                            variant="secondary"
                            className="text-xs border-0 bg-gray-100 text-gray-600"
                          >
                            {sub.plan}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Reviews */}
              <div>
                <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <Star className="w-4 h-4" />
                  نظرات
                  <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-600 border-0">
                    {toPersianNumber(selectedApp.reviews.length)}
                  </Badge>
                </h4>
                {selectedApp.reviews.length === 0 ? (
                  <p className="text-xs text-gray-400">نظری ثبت نشده</p>
                ) : (
                  <div className="max-h-48 overflow-y-auto space-y-2 custom-scrollbar">
                    {selectedApp.reviews.map((review) => (
                      <div key={review.id} className="p-2.5 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-0.5">
                            {renderStars(review.rating)}
                          </div>
                          <span className="text-xs text-gray-400">
                            {formatPersianDate(review.createdAt)}
                          </span>
                        </div>
                        {review.title && (
                          <p className="text-xs font-semibold text-gray-700">{review.title}</p>
                        )}
                        {review.comment && (
                          <p className="text-xs text-gray-600 mt-0.5">{review.comment}</p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Approve/Reject section */}
              {(selectedApp.status === 'PENDING_REVIEW' || selectedApp.status === 'DRAFT') && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-gray-700">بررسی اپلیکیشن</h4>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">یادداشت بررسی</Label>
                      <Textarea
                        placeholder="یادداشت بررسی (اختیاری)..."
                        value={reviewNotes}
                        onChange={(e) => setReviewNotes(e.target.value)}
                        rows={3}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleReview(selectedApp.id, 'APPROVED')}
                        disabled={reviewSubmitting}
                        className="bg-green-600 hover:bg-green-700 text-white gap-2"
                      >
                        {reviewSubmitting ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4" />
                        )}
                        تأیید اپلیکیشن
                      </Button>
                      <Button
                        onClick={() => handleReview(selectedApp.id, 'REJECTED')}
                        disabled={reviewSubmitting}
                        variant="destructive"
                        className="gap-2"
                      >
                        {reviewSubmitting ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <XCircle className="w-4 h-4" />
                        )}
                        رد اپلیکیشن
                      </Button>
                    </div>
                  </div>
                </>
              )}

              {/* Suspended apps can be re-approved */}
              {selectedApp.status === 'SUSPENDED' && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-gray-700">تغییر وضعیت</h4>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">یادداشت</Label>
                      <Textarea
                        placeholder="یادداشت..."
                        value={reviewNotes}
                        onChange={(e) => setReviewNotes(e.target.value)}
                        rows={3}
                      />
                    </div>
                    <Button
                      onClick={() => handleReview(selectedApp.id, 'APPROVED')}
                      disabled={reviewSubmitting}
                      className="bg-green-600 hover:bg-green-700 text-white gap-2"
                    >
                      {reviewSubmitting ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4" />
                      )}
                      فعال‌سازی مجدد
                    </Button>
                  </div>
                </>
              )}

              {/* Approved apps can be suspended */}
              {selectedApp.status === 'APPROVED' && (
                <>
                  <Separator />
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-gray-700">تغییر وضعیت</h4>
                    <div className="space-y-1.5">
                      <Label className="text-sm font-medium">دلیل تعلیق</Label>
                      <Textarea
                        placeholder="دلیل تعلیق..."
                        value={reviewNotes}
                        onChange={(e) => setReviewNotes(e.target.value)}
                        rows={3}
                      />
                    </div>
                    <Button
                      onClick={() => handleReview(selectedApp.id, 'SUSPENDED')}
                      disabled={reviewSubmitting}
                      variant="destructive"
                      className="gap-2"
                    >
                      {reviewSubmitting ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <XCircle className="w-4 h-4" />
                      )}
                      تعلیق اپلیکیشن
                    </Button>
                  </div>
                </>
              )}
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* ─── Edit App Dialog ─── */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Pencil className="w-5 h-5 text-teal-600" />
              ویرایش اپلیکیشن
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نام اپلیکیشن</Label>
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">توضیح کوتاه</Label>
              <Input
                value={editShortDesc}
                onChange={(e) => {
                  if (e.target.value.length <= 120) setEditShortDesc(e.target.value);
                }}
                maxLength={120}
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">توضیحات کامل</Label>
              <Textarea
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                rows={4}
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">مدل قیمت‌گذاری</Label>
              <Select value={editPricingModel} onValueChange={setEditPricingModel}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(PRICING_MAP).map(([key, val]) => (
                    <SelectItem key={key} value={key}>
                      {val.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {editPricingModel !== 'FREE' && (
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">قیمت (ریال)</Label>
                  <Input
                    type="number"
                    value={editPrice}
                    onChange={(e) => setEditPrice(e.target.value)}
                    dir="ltr"
                    className="text-left"
                  />
                </div>
                {editPricingModel === 'SUBSCRIPTION' && (
                  <div className="space-y-1.5">
                    <Label className="text-sm font-medium">اشتراک ماهانه (ریال)</Label>
                    <Input
                      type="number"
                      value={editMonthlyPrice}
                      onChange={(e) => setEditMonthlyPrice(e.target.value)}
                      dir="ltr"
                      className="text-left"
                    />
                  </div>
                )}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">لینک پشتیبانی</Label>
                <Input
                  value={editSupportUrl}
                  onChange={(e) => setEditSupportUrl(e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">لینک مستندات</Label>
                <Input
                  value={editDocumentationUrl}
                  onChange={(e) => setEditDocumentationUrl(e.target.value)}
                  dir="ltr"
                  className="text-left"
                />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleEditSubmit}
              disabled={editSubmitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {editSubmitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Pencil className="w-4 h-4" />
              )}
              ذخیره تغییرات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
