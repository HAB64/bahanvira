'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  X,
  Search,
  UserPlus,
  Phone,
  MessageCircle,
  ChevronLeft,
  ChevronRight,
  PhoneCall,
  Clock,
  Star,
  Users,
  TrendingUp,
  Plus,
  Tag,
  XCircle,
  Loader2,
  AlertCircle,
  Filter,
  Calendar,
  Activity,
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  DollarSign,
  Wallet,
  Archive,
  Bell,
  BarChart3,
  Download,
  CheckSquare,
  Square,
} from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { toPersianNumber } from '@/lib/persian';
import { exportToCSV } from '@/lib/csv-export';
import ConversionFunnel from '@/components/admin/ConversionFunnel';
import BulkActionBar from '@/components/admin/BulkActionBar';
import MonthlyTrends from '@/components/admin/MonthlyTrends';
import KanbanBoard from '@/components/admin/KanbanBoard';

/* ─────────── Types ─────────── */

interface LeadTag {
  id: string;
  name: string;
  color: string;
}

interface TagOnLead {
  tagId: string;
  tag: LeadTag;
}

interface ActivityLog {
  id: string;
  type: string;
  content: string;
  followUpAt: string | null;
  createdAt: string;
}

interface Payment {
  id: string;
  leadId: string;
  amount: number;
  type: string;
  status: string;
  dueDate: string | null;
  paidAt: string | null;
  note: string;
  createdAt: string;
  updatedAt: string;
}

interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  course: string;
  cluster: string;
  source: string;
  stage: string;
  score: number;
  assignedTo: string;
  message: string;
  goal: string;
  level: string;
  interest: string;
  company: string;
  serviceType: string;
  lastContactedAt: string | null;
  createdAt: string;
  tags?: TagOnLead[];
  activityLogs?: ActivityLog[];
  payments?: Payment[];
  _count?: { activityLogs: number; payments: number };
}

interface StatsData {
  لیدها_بر_مرحله: Record<string, number>;
  لیدها_بر_خوشه: Record<string, number>;
  لیدهای_اخیر: number;
  پیگیری_امروز: number;
  کل_لیدها: number;
  میانگین_امتیاز: number;
  درآمد_کل: number;
  درآمد_در_انتظار: number;
  لیدهای_ماهانه: { month: string; count: number }[];
  درآمد_ماهانه: { month: string; revenue: number }[];
  نرخ_تبدیل_ماهانه: { month: string; rate: number }[];
}

interface PaymentAlert {
  id: string;
  amount: number;
  type: string;
  status: string;
  dueDate: string | null;
  note: string;
  leadId: string;
  leadName: string;
  leadPhone: string;
}

/* ─────────── Constants ─────────── */

const STAGES = ['NEW', 'CONTACTED', 'INTERESTED', 'ENROLLED', 'REJECTED', 'ARCHIVED'] as const;

const STAGE_META: Record<
  string,
  { label: string; color: string; bg: string; icon: typeof UserPlus }
> = {
  NEW: {
    label: 'لیدهای جدید',
    color: 'text-sky-700',
    bg: 'bg-sky-50 border-sky-200',
    icon: UserPlus,
  },
  CONTACTED: {
    label: 'در انتظار تماس',
    color: 'text-amber-700',
    bg: 'bg-amber-50 border-amber-200',
    icon: Phone,
  },
  INTERESTED: {
    label: 'علاقه‌مند',
    color: 'text-purple-700',
    bg: 'bg-purple-50 border-purple-200',
    icon: Star,
  },
  ENROLLED: {
    label: 'ثبت‌نام شده',
    color: 'text-emerald-700',
    bg: 'bg-emerald-50 border-emerald-200',
    icon: TrendingUp,
  },
  REJECTED: {
    label: 'رد شده',
    color: 'text-red-700',
    bg: 'bg-red-50 border-red-200',
    icon: XCircle,
  },
  ARCHIVED: {
    label: 'بایگانی',
    color: 'text-gray-500',
    bg: 'bg-gray-50 border-gray-200',
    icon: Clock,
  },
};

const CLUSTER_MAP: Record<string, string> = {
  'tech-ai': 'کامپیوتر و هوش مصنوعی',
  financial: 'بازار سرمایه',
  management: 'توسعه کسب‌وکار',
  entrepreneurship: 'کارآفرینی',
};

const ACTIVITY_TYPES: Record<string, { label: string; icon: typeof Phone }> = {
  CALL: { label: 'تماس', icon: Phone },
  WHATSAPP: { label: 'واتس‌اپ', icon: MessageCircle },
  SMS: { label: 'پیامک', icon: MessageCircle },
  NOTE: { label: 'یادداشت', icon: Activity },
  STAGE_CHANGE: { label: 'تغییر مرحله', icon: TrendingUp },
  REMINDER: { label: 'یادآوری', icon: Clock },
};

const PAYMENT_TYPE_MAP: Record<string, string> = {
  CASH: 'نقدی',
  CHECK: 'چک',
  INSTALLMENT: 'قسط',
};

const PAYMENT_STATUS_MAP: Record<string, { label: string; color: string; bg: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200' },
  PAID: { label: 'پرداخت شده', color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' },
  OVERDUE: { label: 'سررسید گذشته', color: 'text-red-700', bg: 'bg-red-50 border-red-200' },
  CANCELLED: { label: 'لغو شده', color: 'text-gray-500', bg: 'bg-gray-50 border-gray-200' },
};

/* ─────────── Helpers ─────────── */

function scoreColor(score: number) {
  if (score >= 70) return 'bg-emerald-100 text-emerald-700 border-emerald-200';
  if (score >= 40) return 'bg-amber-100 text-amber-700 border-amber-200';
  return 'bg-red-100 text-red-700 border-red-200';
}

function maskPhone(phone: string) {
  if (phone.length !== 11) return phone;
  return phone.slice(0, 4) + '***' + phone.slice(7);
}

function timeAgo(dateStr: string) {
  const now = new Date();
  const date = new Date(dateStr);
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (minutes < 1) return 'همین الان';
  if (minutes < 60)
    return `${toPersianNumber(minutes)} دقیقه پیش`;
  if (hours < 24)
    return `${toPersianNumber(hours)} ساعت پیش`;
  if (days < 30)
    return `${toPersianNumber(days)} روز پیش`;
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(date);
}

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

function formatToman(amount: number) {
  const toman = Math.round(amount / 10);
  return toPersianNumber(toman.toLocaleString('en-US')) + ' تومان';
}

function isOverdue(payment: Payment) {
  if (payment.status !== 'PENDING' || !payment.dueDate) return false;
  return new Date(payment.dueDate) < new Date();
}

/* ─────────── Main Component ─────────── */

export default function CRMDashboard() {
  /* ── State ── */
  const [leads, setLeads] = useState<Lead[]>([]);
  const [stats, setStats] = useState<StatsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterStage, setFilterStage] = useState<string>('all');
  const [filterCluster, setFilterCluster] = useState<string>('all');
  const [filterScoreMin, setFilterScoreMin] = useState('');
  const [filterScoreMax, setFilterScoreMax] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  // Detail panel
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);
  const [detailTab, setDetailTab] = useState<'info' | 'payments'>('info');

  // Activity form
  const [newActivityType, setNewActivityType] = useState('NOTE');
  const [newActivityContent, setNewActivityContent] = useState('');
  const [newActivityFollowUp, setNewActivityFollowUp] = useState('');
  const [submittingActivity, setSubmittingActivity] = useState(false);

  // Tag form
  const [newTagName, setNewTagName] = useState('');
  const [submittingTag, setSubmittingTag] = useState(false);

  // Payment form
  const [newPayAmount, setNewPayAmount] = useState('');
  const [newPayType, setNewPayType] = useState('CASH');
  const [newPayDueDate, setNewPayDueDate] = useState('');
  const [newPayNote, setNewPayNote] = useState('');
  const [submittingPayment, setSubmittingPayment] = useState(false);
  const [updatingPaymentId, setUpdatingPaymentId] = useState<string | null>(null);

  // Payment alerts
  const [overdueAlerts, setOverdueAlerts] = useState<PaymentAlert[]>([]);
  const [nearDueAlerts, setNearDueAlerts] = useState<PaymentAlert[]>([]);
  const [alertsLoading, setAlertsLoading] = useState(true);

  // Follow-up alerts
  const [followUpAlerts, setFollowUpAlerts] = useState<{ lead: { id: string; name: string; phone: string; stage: string; score: number }; followUps: { id: string; content: string; followUpAt: string | null }[] }[]>([]);
  const [followUpsLoading, setFollowUpsLoading] = useState(true);

  // View mode
  const [viewMode, setViewMode] = useState<'list' | 'kanban'>('list');

  // Performance tab
  const [showPerformance, setShowPerformance] = useState(false);
  const [performanceData, setPerformanceData] = useState<{
    مشاوران: { consultantId: string; totalLeads: number; enrolled: number; conversionRate: number; avgScore: number; callCount: number; whatsappCount: number }[];
    قیف_کلی: { total: number; new: number; contacted: number; interested: number; enrolled: number; rejected: number; archived: number; overallConversionRate: number };
    منابع: { منبع: string; تعداد: number }[];
  } | null>(null);

  // Bulk selection
  const [selectedLeadIds, setSelectedLeadIds] = useState<Set<string>>(new Set());
  const [bulkTags, setBulkTags] = useState<{ id: string; name: string; color: string }[]>([]);

  /* ── Data fetching ── */

  const fetchLeads = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (search) params.set('search', search);
      if (filterStage && filterStage !== 'all')
        params.set('stage', filterStage);
      if (filterCluster && filterCluster !== 'all')
        params.set('cluster', filterCluster);

      const res = await fetch(`/api/crm/leads?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت لیست لیدها');
        return;
      }

      let filteredLeads: Lead[] = data['داده‌ها'] || [];

      // Client-side score filtering
      if (filterScoreMin) {
        filteredLeads = filteredLeads.filter(
          (l: Lead) => l.score >= parseInt(filterScoreMin)
        );
      }
      if (filterScoreMax) {
        filteredLeads = filteredLeads.filter(
          (l: Lead) => l.score <= parseInt(filterScoreMax)
        );
      }

      setLeads(filteredLeads);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    }
  }, [search, filterStage, filterCluster, filterScoreMin, filterScoreMax]);

  const fetchStats = useCallback(async () => {
    try {
      const res = await fetch('/api/crm/stats');
      const data = await res.json();
      if (res.ok) {
        setStats(data['داده'] as StatsData);
      }
    } catch {
      // Stats are non-critical
    }
  }, []);

  const fetchPaymentAlerts = useCallback(async () => {
    try {
      setAlertsLoading(true);
      const res = await fetch('/api/crm/payments/alerts');
      const data = await res.json();
      if (res.ok) {
        const alertData = data['داده'] as {
          سررسید_شده: PaymentAlert[];
          نزدیک_سررسید: PaymentAlert[];
        };
        setOverdueAlerts(alertData.سررسید_شده || []);
        setNearDueAlerts(alertData.نزدیک_سررسید || []);
      }
    } catch {
      // Alerts are non-critical
    } finally {
      setAlertsLoading(false);
    }
  }, []);

  const fetchFollowUps = useCallback(async () => {
    try {
      setFollowUpsLoading(true);
      const res = await fetch('/api/crm/follow-ups?type=overdue');
      const data = await res.json();
      if (res.ok) {
        setFollowUpAlerts(data['داده‌ها'] || []);
      }
    } catch {
      // Non-critical
    } finally {
      setFollowUpsLoading(false);
    }
  }, []);

  const fetchPerformance = useCallback(async () => {
    try {
      const res = await fetch('/api/crm/performance');
      const data = await res.json();
      if (res.ok) {
        setPerformanceData(data['داده']);
      }
    } catch {
      // Non-critical
    }
  }, []);

  const fetchBulkTags = useCallback(async () => {
    try {
      const res = await fetch('/api/crm/tags');
      const data = await res.json();
      if (res.ok) {
        setBulkTags(data['داده‌ها'] || []);
      }
    } catch {
      // Non-critical
    }
  }, []);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      await Promise.all([fetchLeads(), fetchStats(), fetchPaymentAlerts(), fetchFollowUps(), fetchBulkTags()]);
      setLoading(false);
    };
    load();
  }, []);

  // Refetch leads when filters change (debounce search)
  useEffect(() => {
    const timer = setTimeout(() => {
      fetchLeads();
    }, 300);
    return () => clearTimeout(timer);
  }, [fetchLeads]);

  /* ── Lead detail ── */

  const openLeadDetail = useCallback(async (lead: Lead) => {
    setPanelOpen(true);
    setDetailLoading(true);
    setSelectedLead(lead);
    setDetailTab('info');

    try {
      const res = await fetch(`/api/crm/leads/${lead.id}`);
      const data = await res.json();
      if (res.ok) {
        setSelectedLead(data['داده'] as Lead);
      }
    } catch {
      // Use the basic lead data
    } finally {
      setDetailLoading(false);
    }
  }, []);

  const closePanel = useCallback(() => {
    setPanelOpen(false);
    setSelectedLead(null);
    setDetailTab('info');
  }, []);

  /* ── Stage change ── */

  const moveLeadStage = useCallback(
    async (lead: Lead, direction: 'left' | 'right') => {
      const currentIdx = STAGES.indexOf(lead.stage as typeof STAGES[number]);
      const newIdx =
        direction === 'left' ? currentIdx - 1 : currentIdx + 1;
      if (newIdx < 0 || newIdx >= STAGES.length) return;

      const newStage = STAGES[newIdx];

      try {
        const res = await fetch(`/api/crm/leads/${lead.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stage: newStage }),
        });

        if (res.ok) {
          // Update local leads
          setLeads((prev) =>
            prev.map((l) => (l.id === lead.id ? { ...l, stage: newStage } : l))
          );

          // Update selected lead if it's the same
          setSelectedLead((prev) =>
            prev?.id === lead.id ? { ...prev, stage: newStage } : prev
          );

          // Refresh stats
          fetchStats();
        }
      } catch {
        // Silently fail
      }
    },
    [fetchStats]
  );

  /* ── Activity submission ── */

  const handleAddActivity = useCallback(async () => {
    if (!selectedLead || !newActivityContent.trim()) return;

    setSubmittingActivity(true);
    try {
      const res = await fetch(
        `/api/crm/leads/${selectedLead.id}/activities`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: newActivityType,
            content: newActivityContent.trim(),
            followUpAt: newActivityFollowUp || undefined,
          }),
        }
      );

      if (res.ok) {
        setNewActivityContent('');
        setNewActivityFollowUp('');
        // Refresh lead detail
        const detailRes = await fetch(`/api/crm/leads/${selectedLead.id}`);
        const detailData = await detailRes.json();
        if (detailRes.ok) {
          setSelectedLead(detailData['داده'] as Lead);
        }
      }
    } catch {
      // Silently fail
    } finally {
      setSubmittingActivity(false);
    }
  }, [selectedLead, newActivityType, newActivityContent, newActivityFollowUp]);

  /* ── Quick actions ── */

  const handleQuickAction = useCallback(
    async (type: 'CALL' | 'WHATSAPP') => {
      if (!selectedLead) return;

      const content =
        type === 'CALL'
          ? 'تماس تلفنی گرفته شد'
          : 'پیام واتس‌اپ ارسال شد';

      setSubmittingActivity(true);
      try {
        const res = await fetch(
          `/api/crm/leads/${selectedLead.id}/activities`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type, content }),
          }
        );

        if (res.ok) {
          // Refresh lead detail
          const detailRes = await fetch(`/api/crm/leads/${selectedLead.id}`);
          const detailData = await detailRes.json();
          if (detailRes.ok) {
            setSelectedLead(detailData['داده'] as Lead);
          }
        }
      } catch {
        // Silently fail
      } finally {
        setSubmittingActivity(false);
      }
    },
    [selectedLead]
  );

  /* ── Tag management ── */

  const handleAddTag = useCallback(async () => {
    if (!selectedLead || !newTagName.trim()) return;

    setSubmittingTag(true);
    try {
      const res = await fetch(
        `/api/crm/leads/${selectedLead.id}/tags`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: newTagName.trim() }),
        }
      );

      if (res.ok) {
        setNewTagName('');
        // Refresh lead detail
        const detailRes = await fetch(`/api/crm/leads/${selectedLead.id}`);
        const detailData = await detailRes.json();
        if (detailRes.ok) {
          setSelectedLead(detailData['داده'] as Lead);
        }
      }
    } catch {
      // Silently fail
    } finally {
      setSubmittingTag(false);
    }
  }, [selectedLead, newTagName]);

  const handleRemoveTag = useCallback(
    async (tagId: string) => {
      if (!selectedLead) return;

      try {
        const res = await fetch(
          `/api/crm/leads/${selectedLead.id}/tags?tagId=${tagId}`,
          {
            method: 'DELETE',
          }
        );

        if (res.ok) {
          // Refresh lead detail
          const detailRes = await fetch(`/api/crm/leads/${selectedLead.id}`);
          const detailData = await detailRes.json();
          if (detailRes.ok) {
            setSelectedLead(detailData['داده'] as Lead);
          }
        }
      } catch {
        // Silently fail
      }
    },
    [selectedLead]
  );

  /* ── Payment management ── */

  const handleAddPayment = useCallback(async () => {
    if (!selectedLead || !newPayAmount) return;

    setSubmittingPayment(true);
    try {
      const res = await fetch(
        `/api/crm/leads/${selectedLead.id}/payments`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            amount: parseInt(newPayAmount) * 10, // convert toman to rial
            type: newPayType,
            dueDate: newPayDueDate || undefined,
            note: newPayNote || undefined,
          }),
        }
      );

      if (res.ok) {
        setNewPayAmount('');
        setNewPayType('CASH');
        setNewPayDueDate('');
        setNewPayNote('');
        // Refresh lead detail
        const detailRes = await fetch(`/api/crm/leads/${selectedLead.id}`);
        const detailData = await detailRes.json();
        if (detailRes.ok) {
          setSelectedLead(detailData['داده'] as Lead);
        }
        // Refresh alerts
        fetchPaymentAlerts();
      }
    } catch {
      // Silently fail
    } finally {
      setSubmittingPayment(false);
    }
  }, [selectedLead, newPayAmount, newPayType, newPayDueDate, newPayNote, fetchPaymentAlerts]);

  const handleMarkAsPaid = useCallback(
    async (paymentId: string) => {
      if (!selectedLead) return;

      setUpdatingPaymentId(paymentId);
      try {
        const res = await fetch(
          `/api/crm/leads/${selectedLead.id}/payments`,
          {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              paymentId,
              status: 'PAID',
            }),
          }
        );

        if (res.ok) {
          // Refresh lead detail
          const detailRes = await fetch(`/api/crm/leads/${selectedLead.id}`);
          const detailData = await detailRes.json();
          if (detailRes.ok) {
            setSelectedLead(detailData['داده'] as Lead);
          }
          // Refresh stats and alerts
          fetchStats();
          fetchPaymentAlerts();
        }
      } catch {
        // Silently fail
      } finally {
        setUpdatingPaymentId(null);
      }
    },
    [selectedLead, fetchStats, fetchPaymentAlerts]
  );

  const handleCancelPayment = useCallback(
    async (paymentId: string) => {
      if (!selectedLead) return;

      setUpdatingPaymentId(paymentId);
      try {
        const res = await fetch(
          `/api/crm/leads/${selectedLead.id}/payments`,
          {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              paymentId,
              status: 'CANCELLED',
            }),
          }
        );

        if (res.ok) {
          // Refresh lead detail
          const detailRes = await fetch(`/api/crm/leads/${selectedLead.id}`);
          const detailData = await detailRes.json();
          if (detailRes.ok) {
            setSelectedLead(detailData['داده'] as Lead);
          }
          // Refresh stats and alerts
          fetchStats();
          fetchPaymentAlerts();
        }
      } catch {
        // Silently fail
      } finally {
        setUpdatingPaymentId(null);
      }
    },
    [selectedLead, fetchStats, fetchPaymentAlerts]
  );

  /* ── Kanban stage change handler ── */

  const handleKanbanStageChange = useCallback(
    async (leadId: string, newStage: string): Promise<boolean> => {
      // Save original lead for revert
      const originalLead = leads.find((l) => l.id === leadId);
      if (!originalLead) return false;

      // Optimistically update local state
      setLeads((prev) =>
        prev.map((l) => (l.id === leadId ? { ...l, stage: newStage } : l))
      );

      try {
        const res = await fetch(`/api/crm/leads/${leadId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stage: newStage }),
        });

        if (res.ok) {
          // Update selected lead if it's the same
          setSelectedLead((prev) =>
            prev?.id === leadId ? { ...prev, stage: newStage } : prev
          );
          // Refresh stats
          fetchStats();
          return true;
        } else {
          // Revert on failure
          setLeads((prev) =>
            prev.map((l) =>
              l.id === leadId ? { ...l, stage: originalLead.stage } : l
            )
          );
          return false;
        }
      } catch {
        // Revert on failure
        setLeads((prev) =>
          prev.map((l) =>
            l.id === leadId ? { ...l, stage: originalLead.stage } : l
          )
        );
        return false;
      }
    },
    [leads, fetchStats]
  );

  /* ── Group leads by stage ── */

  const leadsByStage = STAGES.reduce(
    (acc, stage) => {
      acc[stage] = leads.filter((l) => l.stage === stage);
      return acc;
    },
    {} as Record<string, Lead[]>
  );

  /* ── Payment computations for selected lead ── */

  const leadPayments = selectedLead?.payments || [];
  const totalPaymentAmount = leadPayments
    .filter((p) => p.status !== 'CANCELLED')
    .reduce((sum, p) => sum + p.amount, 0);
  const totalPaidAmount = leadPayments
    .filter((p) => p.status === 'PAID')
    .reduce((sum, p) => sum + p.amount, 0);
  const hasOverduePayments = leadPayments.some(isOverdue);

  // Bulk selection handlers
  const toggleLeadSelection = useCallback((leadId: string) => {
    setSelectedLeadIds((prev) => {
      const next = new Set(prev);
      if (next.has(leadId)) {
        next.delete(leadId);
      } else {
        next.add(leadId);
      }
      return next;
    });
  }, []);

  const toggleSelectAll = useCallback(() => {
    if (selectedLeadIds.size === leads.length) {
      setSelectedLeadIds(new Set());
    } else {
      setSelectedLeadIds(new Set(leads.map((l) => l.id)));
    }
  }, [selectedLeadIds.size, leads]);

  const clearSelection = useCallback(() => {
    setSelectedLeadIds(new Set());
  }, []);

  const handleBulkActionComplete = useCallback(() => {
    clearSelection();
    fetchLeads();
    fetchStats();
  }, [clearSelection, fetchLeads, fetchStats]);

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">داشبورد CRM</h1>
          <p className="text-gray-500 mt-1 text-sm">
            مدیریت لیدها و فرآیند فروش
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {/* View Mode Toggle */}
          <div className="flex border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 text-xs font-medium transition-colors flex items-center gap-1.5 ${
                viewMode === 'list'
                  ? 'bg-teal-600 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              لیست
            </button>
            <button
              onClick={() => setViewMode('kanban')}
              className={`px-3 py-1.5 text-xs font-medium transition-colors flex items-center gap-1.5 border-r border-gray-200 ${
                viewMode === 'kanban'
                  ? 'bg-teal-600 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              کانبان
            </button>
          </div>
          {/* Select All button */}
          {leads.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={toggleSelectAll}
              className="gap-2"
            >
              {selectedLeadIds.size === leads.length ? (
                <CheckSquare className="w-4 h-4 text-teal-600" />
              ) : (
                <Square className="w-4 h-4" />
              )}
              {selectedLeadIds.size === leads.length ? 'لغو انتخاب' : 'انتخاب همه'}
              {selectedLeadIds.size > 0 && (
                <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-[10px] px-1.5 py-0 h-5">
                  {toPersianNumber(selectedLeadIds.size)}
                </Badge>
              )}
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={async () => {
              setShowPerformance(!showPerformance);
              if (!performanceData) await fetchPerformance();
            }}
            className="gap-2"
          >
            <BarChart3 className="w-4 h-4" />
            عملکرد مشاوران
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="gap-2"
          >
            <Filter className="w-4 h-4" />
            فیلترها
            {(filterStage !== 'all' ||
              filterCluster !== 'all' ||
              filterScoreMin ||
              filterScoreMax ||
              search) && (
              <span className="w-2 h-2 rounded-full bg-teal-500" />
            )}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              exportToCSV(
                leads.map((l) => ({
                  name: l.name,
                  phone: l.phone,
                  email: l.email,
                  stage: STAGE_META[l.stage]?.label || l.stage,
                  source: l.source,
                  score: l.score,
                  assignedTo: l.assignedTo,
                  createdAt: new Intl.DateTimeFormat('fa-IR').format(new Date(l.createdAt)),
                })),
                'leads-export.csv',
                [
                  { key: 'name', header: 'نام' },
                  { key: 'phone', header: 'تلفن' },
                  { key: 'email', header: 'ایمیل' },
                  { key: 'stage', header: 'مرحله' },
                  { key: 'source', header: 'منبع' },
                  { key: 'score', header: 'امتیاز' },
                  { key: 'assignedTo', header: 'مسئول' },
                  { key: 'createdAt', header: 'تاریخ ایجاد' },
                ]
              );
            }}
            className="gap-2"
            disabled={leads.length === 0}
          >
            <Download className="w-4 h-4" />
            خروجی CSV
          </Button>
        </div>
      </div>

      {/* ── Payment Alerts ── */}
      {!alertsLoading && (overdueAlerts.length > 0 || nearDueAlerts.length > 0) && (
        <div className="space-y-3">
          {/* Overdue alerts */}
          {overdueAlerts.length > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                  <span className="text-sm font-bold text-red-700">
                    {toPersianNumber(overdueAlerts.length)} قسط سررسید شده
                  </span>
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {overdueAlerts.map((alert) => (
                    <button
                      key={alert.id}
                      onClick={() => {
                        const lead = leads.find((l) => l.id === alert.leadId);
                        if (lead) openLeadDetail({ ...lead, id: alert.leadId, name: alert.leadName, phone: alert.leadPhone } as Lead);
                      }}
                      className="w-full flex items-center justify-between bg-white rounded-lg p-2.5 border border-red-100 hover:border-red-300 transition-colors text-right"
                    >
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-red-400" />
                        <div>
                          <p className="text-xs font-medium text-gray-900">{alert.leadName}</p>
                          <p className="text-[10px] text-gray-500" dir="ltr">{alert.leadPhone}</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <p className="text-xs font-bold text-red-700">{formatToman(alert.amount)}</p>
                        {alert.dueDate && (
                          <p className="text-[10px] text-red-500">
                            سررسید: {new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' }).format(new Date(alert.dueDate))}
                          </p>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Near-due alerts */}
          {nearDueAlerts.length > 0 && (
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="w-5 h-5 text-yellow-600" />
                  <span className="text-sm font-bold text-yellow-700">
                    {toPersianNumber(nearDueAlerts.length)} قسط تا ۳ روز آینده سررسید
                  </span>
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {nearDueAlerts.map((alert) => (
                    <button
                      key={alert.id}
                      onClick={() => {
                        const lead = leads.find((l) => l.id === alert.leadId);
                        if (lead) openLeadDetail({ ...lead, id: alert.leadId, name: alert.leadName, phone: alert.leadPhone } as Lead);
                      }}
                      className="w-full flex items-center justify-between bg-white rounded-lg p-2.5 border border-yellow-100 hover:border-yellow-300 transition-colors text-right"
                    >
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-yellow-400" />
                        <div>
                          <p className="text-xs font-medium text-gray-900">{alert.leadName}</p>
                          <p className="text-[10px] text-gray-500" dir="ltr">{alert.leadPhone}</p>
                        </div>
                      </div>
                      <div className="text-left">
                        <p className="text-xs font-bold text-yellow-700">{formatToman(alert.amount)}</p>
                        {alert.dueDate && (
                          <p className="text-[10px] text-yellow-600">
                            سررسید: {new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' }).format(new Date(alert.dueDate))}
                          </p>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Stats Bar */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-2">
          {STAGES.map((stage) => {
            const meta = STAGE_META[stage];
            const Icon = meta.icon;
            const count = stats?.لیدها_بر_مرحله?.[stage] ?? 0;
            return (
              <Card key={stage} className="border-0 shadow-sm">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] text-gray-500">{meta.label}</p>
                      <p className="text-xl font-bold mt-0.5 text-gray-900">
                        {toPersianNumber(count)}
                      </p>
                    </div>
                    <div
                      className={`p-2.5 rounded-xl ${meta.bg.split(' ')[0]}`}
                    >
                      <Icon className={`w-5 h-5 ${meta.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Revenue Stats */}
      {!loading && stats && (
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">درآمد کل</p>
                  <p className="text-lg font-bold mt-1 text-emerald-700">
                    {formatToman(stats.درآمد_کل || 0)}
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                  <DollarSign className="w-5 h-5 text-emerald-700" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">درآمد در انتظار</p>
                  <p className="text-lg font-bold mt-1 text-yellow-700">
                    {formatToman(stats.درآمد_در_انتظار || 0)}
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-200">
                  <Wallet className="w-5 h-5 text-yellow-700" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm col-span-2 lg:col-span-1">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500">کل لیدها</p>
                  <p className="text-lg font-bold mt-1 text-gray-900">
                    {toPersianNumber(stats.کل_لیدها || 0)}
                  </p>
                </div>
                <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-200">
                  <Users className="w-5 h-5 text-gray-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* ── Follow-up Alerts ── */}
      {!followUpsLoading && followUpAlerts.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-3">
              <Bell className="w-5 h-5 text-orange-600" />
              <span className="text-sm font-bold text-orange-700">
                {toPersianNumber(followUpAlerts.length)} لید نیاز به پیگیری فوری دارند
              </span>
            </div>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {followUpAlerts.map((item) => (
                <button
                  key={item.lead.id}
                  onClick={() => {
                    const lead = leads.find((l) => l.id === item.lead.id);
                    if (lead) openLeadDetail(lead);
                  }}
                  className="w-full flex items-center justify-between bg-white rounded-lg p-2.5 border border-orange-100 hover:border-orange-300 transition-colors text-right"
                >
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-orange-400" />
                    <div>
                      <p className="text-xs font-medium text-gray-900">{item.lead.name}</p>
                      <p className="text-[10px] text-gray-500" dir="ltr">{item.lead.phone}</p>
                    </div>
                  </div>
                  <div className="text-left">
                    {item.followUps[0]?.followUpAt && (
                      <p className="text-[10px] text-orange-600 font-medium">
                        سررسید: {new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(item.followUps[0].followUpAt))}
                      </p>
                    )}
                    <Badge variant="outline" className={`text-[9px] px-1 py-0 h-4 ${scoreColor(item.lead.score)}`}>
                      {toPersianNumber(item.lead.score)}
                    </Badge>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Performance Dashboard ── */}
      {showPerformance && performanceData && (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <BarChart3 className="w-5 h-5 text-teal-600" />
              <h3 className="text-base font-bold text-gray-900">عملکرد مشاوران</h3>
            </div>
            {/* Overall Funnel */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
              <div className="bg-gray-50 rounded-lg p-3 text-center">
                <p className="text-xs text-gray-500">کل لیدها</p>
                <p className="text-lg font-bold text-gray-900">{toPersianNumber(performanceData.قیف_کلی.total)}</p>
              </div>
              <div className="bg-emerald-50 rounded-lg p-3 text-center">
                <p className="text-xs text-emerald-600">ثبت‌نام شده</p>
                <p className="text-lg font-bold text-emerald-700">{toPersianNumber(performanceData.قیف_کلی.enrolled)}</p>
              </div>
              <div className="bg-red-50 rounded-lg p-3 text-center">
                <p className="text-xs text-red-600">رد شده</p>
                <p className="text-lg font-bold text-red-700">{toPersianNumber(performanceData.قیف_کلی.rejected)}</p>
              </div>
              <div className="bg-teal-50 rounded-lg p-3 text-center">
                <p className="text-xs text-teal-600">نرخ تبدیل کلی</p>
                <p className="text-lg font-bold text-teal-700">{toPersianNumber(performanceData.قیف_کلی.overallConversionRate)}٪</p>
              </div>
            </div>
            {/* Source Breakdown */}
            {performanceData.منابع.length > 0 && (
              <div className="mb-4">
                <p className="text-xs font-bold text-gray-600 mb-2">لیدها بر اساس منبع:</p>
                <div className="flex flex-wrap gap-2">
                  {performanceData.منابع.map((src) => (
                    <span key={src.منبع} className="text-xs bg-gray-100 px-2.5 py-1 rounded-lg">
                      {src.منبع === 'hero-form' ? 'فرم هیرو' :
                       src.منبع === 'career-quiz' ? 'آزمون مسیر' :
                       src.منبع === 'consulting-form' ? 'مشاوره' :
                       src.منبع === 'webhook' ? 'وب‌هوک' : src.منبع}: {toPersianNumber(src.تعداد)}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {/* Consultant Table */}
            {performanceData.مشاوران.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-right">
                  <thead>
                    <tr className="border-b border-gray-100 text-gray-500 text-xs">
                      <th className="pb-2 pr-2">مشاور</th>
                      <th className="pb-2 text-center">لیدها</th>
                      <th className="pb-2 text-center">ثبت‌نام</th>
                      <th className="pb-2 text-center">نرخ تبدیل</th>
                      <th className="pb-2 text-center">میانگین امتیاز</th>
                      <th className="pb-2 text-center">تماس</th>
                      <th className="pb-2 text-center">واتس‌اپ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {performanceData.مشاوران.map((c) => (
                      <tr key={c.consultantId} className="border-b border-gray-50 hover:bg-gray-50">
                        <td className="py-2 pr-2 font-medium">{c.consultantId === 'unassigned' ? 'بدون مشاور' : c.consultantId}</td>
                        <td className="py-2 text-center">{toPersianNumber(c.totalLeads)}</td>
                        <td className="py-2 text-center text-emerald-700 font-medium">{toPersianNumber(c.enrolled)}</td>
                        <td className="py-2 text-center">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${c.conversionRate >= 30 ? 'bg-emerald-100 text-emerald-700' : c.conversionRate >= 15 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'}`}>
                            {toPersianNumber(c.conversionRate)}٪
                          </span>
                        </td>
                        <td className="py-2 text-center">{toPersianNumber(c.avgScore)}</td>
                        <td className="py-2 text-center">{toPersianNumber(c.callCount)}</td>
                        <td className="py-2 text-center">{toPersianNumber(c.whatsappCount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-center text-gray-400 text-sm py-4">هنوز مشاوری تعریف نشده است</p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Conversion Funnel & Monthly Trends */}
      {!loading && stats && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <ConversionFunnel stageCounts={stats.لیدها_بر_مرحله} />
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <MonthlyTrends
                monthlyLeads={stats.لیدهای_ماهانه || []}
                monthlyRevenue={stats.درآمد_ماهانه || []}
              />
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      {showFilters && (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {/* Search */}
              <div className="relative sm:col-span-2 lg:col-span-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="جستجوی نام / شماره"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pr-9 h-9 text-sm"
                />
              </div>

              {/* Stage filter */}
              <Select
                value={filterStage}
                onValueChange={setFilterStage}
              >
                <SelectTrigger className="h-9 text-sm w-full">
                  <SelectValue placeholder="مرحله" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه مراحل</SelectItem>
                  {STAGES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {STAGE_META[s].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Cluster filter */}
              <Select
                value={filterCluster}
                onValueChange={setFilterCluster}
              >
                <SelectTrigger className="h-9 text-sm w-full">
                  <SelectValue placeholder="خوشه" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه خوشه‌ها</SelectItem>
                  {Object.entries(CLUSTER_MAP).map(([val, label]) => (
                    <SelectItem key={val} value={val}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Score range */}
              <div className="flex gap-2 items-center">
                <Input
                  placeholder="امتیاز از"
                  type="number"
                  min={0}
                  max={100}
                  value={filterScoreMin}
                  onChange={(e) => setFilterScoreMin(e.target.value)}
                  className="h-9 text-sm"
                />
                <span className="text-gray-400 text-xs">تا</span>
                <Input
                  placeholder="امتیاز تا"
                  type="number"
                  min={0}
                  max={100}
                  value={filterScoreMax}
                  onChange={(e) => setFilterScoreMax(e.target.value)}
                  className="h-9 text-sm"
                />
              </div>

              {/* Clear filters */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setSearch('');
                  setFilterStage('all');
                  setFilterCluster('all');
                  setFilterScoreMin('');
                  setFilterScoreMax('');
                }}
                className="text-gray-500 h-9"
              >
                پاک‌سازی فیلترها
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 text-red-600 bg-red-50 rounded-lg px-4 py-3 text-sm">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Pipeline / Kanban View */}
      {viewMode === 'kanban' ? (
        /* ── Kanban Board View ── */
        loading ? (
          <div className="flex gap-3 overflow-x-auto pb-4">
            {[...Array(7)].map((_, i) => (
              <div key={i} className="min-w-[280px] w-[280px] space-y-3">
                <Skeleton className="h-10 rounded-xl" />
                {[...Array(3)].map((_, j) => (
                  <Skeleton key={j} className="h-28 rounded-xl" />
                ))}
              </div>
            ))}
          </div>
        ) : (
          <KanbanBoard
            leads={leads}
            onLeadClick={openLeadDetail}
            onStageChange={handleKanbanStageChange}
            selectedLeadIds={selectedLeadIds}
            onToggleLeadSelection={toggleLeadSelection}
          />
        )
      ) : (
        /* ── List / Pipeline View ── */
        loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="h-8 w-32 rounded-lg" />
                {[...Array(3)].map((_, j) => (
                  <Skeleton key={j} className="h-28 rounded-xl" />
                ))}
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
            {STAGES.map((stage) => {
              const meta = STAGE_META[stage];
              const Icon = meta.icon;
              const stageLeads = leadsByStage[stage] || [];

              return (
                <div key={stage} className="space-y-3">
                  {/* Column header */}
                  <div
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg border ${meta.bg}`}
                  >
                    <Checkbox
                      checked={stageLeads.length > 0 && stageLeads.every((l) => selectedLeadIds.has(l.id))}
                      onCheckedChange={() => {
                        const stageLeadIds = stageLeads.map((l) => l.id);
                        const allSelected = stageLeadIds.every((id) => selectedLeadIds.has(id));
                        setSelectedLeadIds((prev) => {
                          const next = new Set(prev);
                          stageLeadIds.forEach((id) => {
                            if (allSelected) next.delete(id);
                            else next.add(id);
                          });
                          return next;
                        });
                      }}
                      className="border-gray-300"
                    />
                    <Icon className={`w-4 h-4 ${meta.color}`} />
                    <span className={`text-sm font-bold ${meta.color}`}>
                      {meta.label}
                    </span>
                    <span
                      className={`mr-auto text-xs font-medium px-1.5 py-0.5 rounded-full ${meta.bg} ${meta.color}`}
                    >
                      {toPersianNumber(stageLeads.length)}
                    </span>
                  </div>

                  {/* Lead cards */}
                  <div className="space-y-2 max-h-[calc(100vh-380px)] overflow-y-auto">
                    {stageLeads.length === 0 ? (
                      <div className="text-center py-8 text-gray-400 text-xs border border-dashed border-gray-200 rounded-xl">
                        لیدی در این مرحله نیست
                      </div>
                    ) : (
                      stageLeads.map((lead) => (
                        <Card
                          key={lead.id}
                          className={`border shadow-none hover:shadow-md transition-all cursor-pointer group ${
                            selectedLeadIds.has(lead.id)
                              ? 'border-teal-300 bg-teal-50/50'
                              : 'border-gray-100 hover:border-teal-200'
                          }`}
                          onClick={() => openLeadDetail(lead)}
                        >
                          <CardContent className="p-3 space-y-2">
                            {/* Checkbox + Name + Score */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 min-w-0">
                                <Checkbox
                                  checked={selectedLeadIds.has(lead.id)}
                                  onCheckedChange={() => toggleLeadSelection(lead.id)}
                                  onClick={(e) => e.stopPropagation()}
                                  className="border-gray-300 flex-shrink-0"
                                />
                                <span className="text-sm font-bold text-gray-900 truncate">
                                  {lead.name}
                                </span>
                              </div>
                              <Badge
                                variant="outline"
                                className={`text-[10px] px-1.5 py-0 h-5 ${scoreColor(lead.score)}`}
                              >
                                {toPersianNumber(lead.score)}
                              </Badge>
                            </div>

                            {/* Phone */}
                            <p className="text-xs text-gray-500 font-mono" dir="ltr">
                              {maskPhone(lead.phone)}
                            </p>

                            {/* Course / Cluster */}
                            {lead.course && (
                              <p className="text-xs text-gray-600 truncate">
                                {lead.course}
                              </p>
                            )}
                            {!lead.course && lead.cluster && (
                              <p className="text-xs text-gray-600 truncate">
                                {CLUSTER_MAP[lead.cluster] || lead.cluster}
                              </p>
                            )}

                            {/* Time + Stage buttons */}
                            <div className="flex items-center justify-between pt-1">
                              <span className="text-[10px] text-gray-400">
                                {timeAgo(lead.createdAt)}
                              </span>
                              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                {stage !== 'NEW' && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      moveLeadStage(lead, 'left');
                                    }}
                                    className="p-1 hover:bg-gray-100 rounded transition-colors"
                                    title="انتقال به مرحله قبل"
                                  >
                                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" />
                                  </button>
                                )}
                                {stage !== 'ARCHIVED' && (
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      moveLeadStage(lead, 'right');
                                    }}
                                    className="p-1 hover:bg-gray-100 rounded transition-colors"
                                    title="انتقال به مرحله بعد"
                                  >
                                    <ChevronLeft className="w-3.5 h-3.5 text-gray-400" />
                                  </button>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )
      )}

      {/* ─── Detail Panel (Sheet-like sidebar) ─── */}
      {panelOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/30 z-40 lg:bg-black/20"
            onClick={closePanel}
          />

          {/* Panel */}
          <div className="fixed top-0 left-0 z-50 h-full w-full sm:w-[440px] bg-white shadow-2xl overflow-y-auto">
            {/* Panel header */}
            <div className="sticky top-0 bg-white border-b border-gray-100 px-5 py-4 flex items-center justify-between z-10">
              <h2 className="text-lg font-bold text-gray-900">
                جزئیات لید
              </h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={closePanel}
                className="h-8 w-8"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            {detailLoading ? (
              <div className="p-5 space-y-4">
                <Skeleton className="h-6 w-40" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-32 w-full" />
              </div>
            ) : selectedLead ? (
              <div className="p-5 space-y-5">
                {/* Lead info header */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-gray-900">
                      {selectedLead.name}
                    </h3>
                    <Badge
                      variant="outline"
                      className={`text-xs ${scoreColor(selectedLead.score)}`}
                    >
                      امتیاز: {toPersianNumber(selectedLead.score)}
                    </Badge>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <Phone className="w-4 h-4 text-gray-400" />
                      <span dir="ltr">{selectedLead.phone}</span>
                    </div>
                    {selectedLead.email && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <MessageCircle className="w-4 h-4 text-gray-400" />
                        <span>{selectedLead.email}</span>
                      </div>
                    )}
                    {selectedLead.course && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Star className="w-4 h-4 text-gray-400" />
                        <span>{selectedLead.course}</span>
                      </div>
                    )}
                    {selectedLead.cluster && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Users className="w-4 h-4 text-gray-400" />
                        <span>
                          {CLUSTER_MAP[selectedLead.cluster] ||
                            selectedLead.cluster}
                        </span>
                      </div>
                    )}
                    {selectedLead.message && (
                      <div className="bg-gray-50 rounded-lg p-3 text-xs text-gray-700 leading-relaxed">
                        {selectedLead.message}
                      </div>
                    )}
                  </div>

                  {/* Meta */}
                  <div className="flex flex-wrap gap-2 text-[10px] text-gray-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {timeAgo(selectedLead.createdAt)}
                    </span>
                    <span>•</span>
                    <span>
                      منبع:{' '}
                      {selectedLead.source === 'hero-form'
                        ? 'فرم اصلی'
                        : selectedLead.source === 'career-quiz'
                          ? 'تست شغلی'
                          : selectedLead.source}
                    </span>
                    <span>•</span>
                    <span>
                      مرحله: {STAGE_META[selectedLead.stage]?.label}
                    </span>
                  </div>
                </div>

                {/* Quick actions */}
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-gray-500">
                    اقدامات سریع
                  </p>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1.5 text-teal-700 border-teal-200 hover:bg-teal-50 flex-1"
                      onClick={() => handleQuickAction('CALL')}
                      disabled={submittingActivity}
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      تماس
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-1.5 text-green-700 border-green-200 hover:bg-green-50 flex-1"
                      onClick={() => handleQuickAction('WHATSAPP')}
                      disabled={submittingActivity}
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      واتس‌اپ
                    </Button>
                  </div>
                </div>

                {/* Stage navigation */}
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-gray-500">
                    تغییر مرحله
                  </p>
                  <div className="flex gap-2">
                    {STAGES.map((s, idx) => {
                      const currentIdx = STAGES.indexOf(
                        selectedLead.stage as typeof STAGES[number]
                      );
                      const isActive = s === selectedLead.stage;
                      const meta = STAGE_META[s];

                      return (
                        <button
                          key={s}
                          onClick={() => {
                            if (idx < currentIdx)
                              moveLeadStage(selectedLead, 'left');
                            else if (idx > currentIdx)
                              moveLeadStage(selectedLead, 'right');
                          }}
                          disabled={isActive}
                          className={`flex-1 py-2 rounded-lg text-[10px] font-medium transition-all border ${
                            isActive
                              ? `${meta.bg} ${meta.color} border-current`
                              : 'border-gray-100 text-gray-400 hover:bg-gray-50'
                          }`}
                        >
                          {meta.label}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Detail Tabs */}
                <div className="border-b border-gray-100">
                  <div className="flex gap-4">
                    <button
                      onClick={() => setDetailTab('info')}
                      className={`pb-2 text-sm font-medium border-b-2 transition-colors ${
                        detailTab === 'info'
                          ? 'border-teal-500 text-teal-700'
                          : 'border-transparent text-gray-400 hover:text-gray-600'
                      }`}
                    >
                      اطلاعات و فعالیت‌ها
                    </button>
                    <button
                      onClick={() => setDetailTab('payments')}
                      className={`pb-2 text-sm font-medium border-b-2 transition-colors flex items-center gap-1.5 ${
                        detailTab === 'payments'
                          ? 'border-teal-500 text-teal-700'
                          : 'border-transparent text-gray-400 hover:text-gray-600'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      پرداخت‌ها
                      {leadPayments.length > 0 && (
                        <span className="text-[10px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded-full">
                          {toPersianNumber(leadPayments.length)}
                        </span>
                      )}
                    </button>
                  </div>
                </div>

                {/* ─── Info Tab ─── */}
                {detailTab === 'info' && (
                  <>
                    {/* Tags */}
                    <div className="space-y-2">
                      <p className="text-xs font-semibold text-gray-500">
                        <Tag className="w-3.5 h-3.5 inline ml-1" />
                        برچسب‌ها
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedLead.tags?.map((t) => (
                          <Badge
                            key={t.tagId}
                            variant="outline"
                            className="text-xs gap-1 pr-2"
                            style={{
                              borderColor: t.tag.color,
                              color: t.tag.color,
                            }}
                          >
                            {t.tag.name}
                            <button
                              onClick={() => handleRemoveTag(t.tagId)}
                              className="hover:bg-black/10 rounded-full p-0.5"
                            >
                              <XCircle className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                        {(!selectedLead.tags || selectedLead.tags.length === 0) && (
                          <span className="text-xs text-gray-400">
                            برچسبی ندارد
                          </span>
                        )}
                      </div>
                      {/* Add tag */}
                      <div className="flex gap-2 mt-2">
                        <Input
                          placeholder="برچسب جدید"
                          value={newTagName}
                          onChange={(e) => setNewTagName(e.target.value)}
                          className="h-8 text-xs"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleAddTag();
                          }}
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={handleAddTag}
                          disabled={submittingTag || !newTagName.trim()}
                          className="h-8 px-3"
                        >
                          {submittingTag ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Plus className="w-3.5 h-3.5" />
                          )}
                        </Button>
                      </div>
                    </div>

                    {/* Activity Log */}
                    <div className="space-y-3">
                      <p className="text-xs font-semibold text-gray-500">
                        <Activity className="w-3.5 h-3.5 inline ml-1" />
                        تاریخچه فعالیت‌ها
                      </p>

                      {/* Activity list */}
                      <div className="space-y-2 max-h-64 overflow-y-auto">
                        {selectedLead.activityLogs &&
                        selectedLead.activityLogs.length > 0 ? (
                          selectedLead.activityLogs.map((act) => {
                            const actMeta = ACTIVITY_TYPES[act.type];
                            return (
                              <div
                                key={act.id}
                                className="bg-gray-50 rounded-lg p-3 space-y-1"
                              >
                                <div className="flex items-center gap-2">
                                  {actMeta && (
                                    <actMeta.icon className="w-3.5 h-3.5 text-gray-400" />
                                  )}
                                  <span className="text-[10px] font-medium text-gray-500">
                                    {actMeta?.label || act.type}
                                  </span>
                                  <span className="text-[10px] text-gray-400 mr-auto">
                                    {timeAgo(act.createdAt)}
                                  </span>
                                </div>
                                <p className="text-xs text-gray-700 leading-relaxed">
                                  {act.content}
                                </p>
                                {act.followUpAt && (
                                  <div className="flex items-center gap-1 text-[10px] text-amber-600">
                                    <Calendar className="w-3 h-3" />
                                    پیگیری:{' '}
                                    {formatPersianDate(act.followUpAt)}
                                  </div>
                                )}
                              </div>
                            );
                          })
                        ) : (
                          <p className="text-xs text-gray-400 text-center py-4">
                            فعالیتی ثبت نشده
                          </p>
                        )}
                      </div>

                      {/* Add activity */}
                      <div className="space-y-2 border-t border-gray-100 pt-3">
                        <div className="flex gap-2">
                          <Select
                            value={newActivityType}
                            onValueChange={setNewActivityType}
                          >
                            <SelectTrigger className="h-8 text-xs w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="NOTE">یادداشت</SelectItem>
                              <SelectItem value="CALL">تماس</SelectItem>
                              <SelectItem value="WHATSAPP">واتس‌اپ</SelectItem>
                              <SelectItem value="SMS">پیامک</SelectItem>
                              <SelectItem value="REMINDER">یادآوری</SelectItem>
                            </SelectContent>
                          </Select>
                          <Input
                            type="date"
                            value={newActivityFollowUp}
                            onChange={(e) =>
                              setNewActivityFollowUp(e.target.value)
                            }
                            className="h-8 text-xs w-36"
                            placeholder="تاریخ پیگیری"
                          />
                        </div>
                        <div className="flex gap-2">
                          <Textarea
                            placeholder="محتوای فعالیت..."
                            value={newActivityContent}
                            onChange={(e) => setNewActivityContent(e.target.value)}
                            className="text-xs min-h-[60px] resize-none"
                            rows={2}
                          />
                        </div>
                        <Button
                          size="sm"
                          onClick={handleAddActivity}
                          disabled={
                            submittingActivity || !newActivityContent.trim()
                          }
                          className="w-full h-8 text-xs gap-1.5"
                        >
                          {submittingActivity ? (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          ) : (
                            <Plus className="w-3.5 h-3.5" />
                          )}
                          ثبت فعالیت
                        </Button>
                      </div>
                    </div>
                  </>
                )}

                {/* ─── Payments Tab ─── */}
                {detailTab === 'payments' && (
                  <div className="space-y-4">
                    {/* Overdue Alert */}
                    {hasOverduePayments && (
                      <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg p-3">
                        <AlertTriangle className="w-4 h-4 text-red-600 flex-shrink-0" />
                        <span className="text-xs font-medium text-red-700">
                          {toPersianNumber(leadPayments.filter(isOverdue).length)} پرداخت سررسید گذشته دارد!
                        </span>
                      </div>
                    )}

                    {/* Payment Summary */}
                    <div className="grid grid-cols-3 gap-2">
                      <div className="bg-gray-50 rounded-lg p-3 text-center">
                        <p className="text-[10px] text-gray-500">مبلغ کل</p>
                        <p className="text-xs font-bold text-gray-900 mt-1">
                          {formatToman(totalPaymentAmount)}
                        </p>
                      </div>
                      <div className="bg-emerald-50 rounded-lg p-3 text-center">
                        <p className="text-[10px] text-emerald-600">پرداخت شده</p>
                        <p className="text-xs font-bold text-emerald-700 mt-1">
                          {formatToman(totalPaidAmount)}
                        </p>
                      </div>
                      <div className="bg-yellow-50 rounded-lg p-3 text-center">
                        <p className="text-[10px] text-yellow-600">مانده</p>
                        <p className="text-xs font-bold text-yellow-700 mt-1">
                          {formatToman(totalPaymentAmount - totalPaidAmount)}
                        </p>
                      </div>
                    </div>

                    {/* Payment List */}
                    <div className="space-y-2">
                      <p className="text-xs font-semibold text-gray-500">
                        لیست پرداخت‌ها
                      </p>
                      <div className="space-y-2 max-h-72 overflow-y-auto">
                        {leadPayments.length > 0 ? (
                          leadPayments.map((payment) => {
                            const statusMeta = PAYMENT_STATUS_MAP[payment.status] || PAYMENT_STATUS_MAP.PENDING;
                            const overdue = isOverdue(payment);

                            return (
                              <div
                                key={payment.id}
                                className={`bg-gray-50 rounded-lg p-3 space-y-2 border ${
                                  overdue ? 'border-red-200 bg-red-50/30' : 'border-transparent'
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <CreditCard className="w-3.5 h-3.5 text-gray-400" />
                                    <span className="text-xs font-bold text-gray-900">
                                      {formatToman(payment.amount)}
                                    </span>
                                    <Badge
                                      variant="outline"
                                      className="text-[10px] px-1.5 py-0 h-5"
                                    >
                                      {PAYMENT_TYPE_MAP[payment.type] || payment.type}
                                    </Badge>
                                  </div>
                                  <Badge
                                    variant="outline"
                                    className={`text-[10px] px-1.5 py-0 h-5 ${statusMeta.color} ${statusMeta.bg}`}
                                  >
                                    {statusMeta.label}
                                  </Badge>
                                </div>

                                {/* Due date & Paid date */}
                                <div className="flex items-center gap-3 text-[10px] text-gray-500">
                                  {payment.dueDate && (
                                    <span className="flex items-center gap-1">
                                      <Calendar className="w-3 h-3" />
                                      سررسید: {new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' }).format(new Date(payment.dueDate))}
                                    </span>
                                  )}
                                  {payment.paidAt && (
                                    <span className="flex items-center gap-1 text-emerald-600">
                                      <CheckCircle2 className="w-3 h-3" />
                                      پرداخت: {new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' }).format(new Date(payment.paidAt))}
                                    </span>
                                  )}
                                </div>

                                {/* Note */}
                                {payment.note && (
                                  <p className="text-[10px] text-gray-500 leading-relaxed">
                                    {payment.note}
                                  </p>
                                )}

                                {/* Action buttons */}
                                {payment.status === 'PENDING' && (
                                  <div className="flex gap-2 pt-1">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="h-6 text-[10px] gap-1 text-emerald-700 border-emerald-200 hover:bg-emerald-50 flex-1"
                                      onClick={() => handleMarkAsPaid(payment.id)}
                                      disabled={updatingPaymentId === payment.id}
                                    >
                                      {updatingPaymentId === payment.id ? (
                                        <Loader2 className="w-3 h-3 animate-spin" />
                                      ) : (
                                        <CheckCircle2 className="w-3 h-3" />
                                      )}
                                      پرداخت شد
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="h-6 text-[10px] gap-1 text-gray-500 border-gray-200 hover:bg-gray-50"
                                      onClick={() => handleCancelPayment(payment.id)}
                                      disabled={updatingPaymentId === payment.id}
                                    >
                                      لغو
                                    </Button>
                                  </div>
                                )}
                                {overdue && (
                                  <div className="flex items-center gap-1 text-[10px] text-red-600 pt-1">
                                    <AlertTriangle className="w-3 h-3" />
                                    سررسید گذشته - لطفاً پیگیری کنید
                                  </div>
                                )}
                              </div>
                            );
                          })
                        ) : (
                          <p className="text-xs text-gray-400 text-center py-4">
                            پرداختی ثبت نشده
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Add Payment Form */}
                    <div className="space-y-2 border-t border-gray-100 pt-3">
                      <p className="text-xs font-semibold text-gray-500">
                        <Plus className="w-3.5 h-3.5 inline ml-1" />
                        ثبت پرداخت جدید
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <Input
                          type="number"
                          placeholder="مبلغ (تومان)"
                          value={newPayAmount}
                          onChange={(e) => setNewPayAmount(e.target.value)}
                          className="h-8 text-xs"
                        />
                        <Select
                          value={newPayType}
                          onValueChange={setNewPayType}
                        >
                          <SelectTrigger className="h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="CASH">نقدی</SelectItem>
                            <SelectItem value="CHECK">چک</SelectItem>
                            <SelectItem value="INSTALLMENT">قسط</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Input
                        type="date"
                        placeholder="تاریخ سررسید"
                        value={newPayDueDate}
                        onChange={(e) => setNewPayDueDate(e.target.value)}
                        className="h-8 text-xs"
                      />
                      <Textarea
                        placeholder="توضیحات (اختیاری)"
                        value={newPayNote}
                        onChange={(e) => setNewPayNote(e.target.value)}
                        className="text-xs min-h-[40px] resize-none"
                        rows={2}
                      />
                      <Button
                        size="sm"
                        onClick={handleAddPayment}
                        disabled={submittingPayment || !newPayAmount}
                        className="w-full h-8 text-xs gap-1.5"
                      >
                        {submittingPayment ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Plus className="w-3.5 h-3.5" />
                        )}
                        ثبت پرداخت
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        </>
      )}
      {/* Bulk Action Bar */}
      <BulkActionBar
        selectedIds={Array.from(selectedLeadIds)}
        totalCount={leads.length}
        onClearSelection={clearSelection}
        onActionComplete={handleBulkActionComplete}
        availableTags={bulkTags}
      />

      {/* Spacer for bulk action bar */}
      {selectedLeadIds.size > 0 && <div className="h-20" />}
    </div>
  );
}
