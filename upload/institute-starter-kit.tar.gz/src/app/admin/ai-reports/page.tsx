'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sparkles,
  Plus,
  Loader2,
  AlertTriangle,
  Eye,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface AIReport {
  id: string;
  title: string;
  type: string;
  period: string;
  data: Record<string, unknown>;
  summary: string | null;
  generatedAt: string;
  createdAt: string;
}

/* ─────────── Constants ─────────── */

const TYPE_META: Record<string, { label: string; color: string; bgColor: string }> = {
  INSIGHT: { label: 'بینش', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  FORECAST: { label: 'پیش‌بینی', color: 'text-purple-700', bgColor: 'bg-purple-100' },
  ANOMALY: { label: 'ناهنجاری', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  PERFORMANCE: { label: 'عملکرد', color: 'text-green-700', bgColor: 'bg-green-100' },
  TREND: { label: 'روند', color: 'text-blue-700', bgColor: 'bg-blue-100' },
};

const PERIOD_LABELS: Record<string, string> = {
  DAILY: 'روزانه',
  WEEKLY: 'هفتگی',
  MONTHLY: 'ماهانه',
  QUARTERLY: 'فصلی',
  YEARLY: 'سالانه',
};

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function AIReportsPage() {
  const [reports, setReports] = useState<AIReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filterType, setFilterType] = useState<string>('all');

  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [formTitle, setFormTitle] = useState('');
  const [formType, setFormType] = useState('INSIGHT');
  const [formPeriod, setFormPeriod] = useState('MONTHLY');

  const [detailReport, setDetailReport] = useState<AIReport | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);

  /* ── Data fetching ── */

  const fetchReports = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '50');
      if (filterType && filterType !== 'all') params.set('type', filterType);

      const res = await fetch(`/api/crm/ai-reports?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت گزارش‌ها');
        return;
      }

      setReports(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [filterType]);

  useEffect(() => {
    fetchReports();
  }, [fetchReports]);

  /* ── Handlers ── */

  const handleSubmit = async () => {
    if (!formTitle.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/ai-reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formTitle,
          type: formType,
          period: formPeriod,
        }),
      });

      if (res.ok) {
        setAddDialogOpen(false);
        fetchReports();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const openDetail = (report: AIReport) => {
    setDetailReport(report);
    setDetailDialogOpen(true);
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Sparkles className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">گزارش‌های هوشمند</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(reports.length)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">گزارش‌های تحلیلی تولیدشده توسط هوش مصنوعی</p>
          </div>
        </div>
        <Button
          onClick={() => {
            setFormTitle('');
            setFormType('INSIGHT');
            setFormPeriod('MONTHLY');
            setAddDialogOpen(true);
          }}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          تولید گزارش
        </Button>
      </div>

      {/* Filter */}
      <div className="flex gap-3">
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-full sm:w-44 bg-white">
            <SelectValue placeholder="نوع گزارش" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه انواع</SelectItem>
            <SelectItem value="INSIGHT">بینش</SelectItem>
            <SelectItem value="FORECAST">پیش‌بینی</SelectItem>
            <SelectItem value="ANOMALY">ناهنجاری</SelectItem>
            <SelectItem value="PERFORMANCE">عملکرد</SelectItem>
            <SelectItem value="TREND">روند</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Cards Layout */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-40 rounded-xl" />)}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchReports}>تلاش مجدد</Button>
          </CardContent>
        </Card>
      ) : reports.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Sparkles className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">گزارشی یافت نشد</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {reports.map((report) => {
            const typeMeta = TYPE_META[report.type] || TYPE_META.INSIGHT;
            return (
              <Card key={report.id} className="border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => openDetail(report)}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className={`${typeMeta.bgColor} ${typeMeta.color} text-xs border-0`}>
                        {typeMeta.label}
                      </Badge>
                      <Badge variant="secondary" className="bg-gray-100 text-gray-600 text-xs border-0">
                        {PERIOD_LABELS[report.period] || report.period}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-gray-400 hover:text-teal-700"
                      onClick={(e) => { e.stopPropagation(); openDetail(report); }}
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                  <h3 className="font-bold text-gray-900 text-sm mb-2 line-clamp-1">{report.title}</h3>
                  {report.summary && (
                    <p className="text-xs text-gray-500 line-clamp-2 leading-5 mb-3">{report.summary}</p>
                  )}
                  <p className="text-xs text-gray-400">
                    {formatPersianDate(report.generatedAt)}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Sparkles className="w-5 h-5 text-teal-600" />
              تولید گزارش جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">عنوان گزارش</Label>
              <Input
                placeholder="عنوان..."
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نوع گزارش</Label>
                <Select value={formType} onValueChange={setFormType}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INSIGHT">بینش</SelectItem>
                    <SelectItem value="FORECAST">پیش‌بینی</SelectItem>
                    <SelectItem value="ANOMALY">ناهنجاری</SelectItem>
                    <SelectItem value="PERFORMANCE">عملکرد</SelectItem>
                    <SelectItem value="TREND">روند</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">دوره زمانی</Label>
                <Select value={formPeriod} onValueChange={setFormPeriod}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DAILY">روزانه</SelectItem>
                    <SelectItem value="WEEKLY">هفتگی</SelectItem>
                    <SelectItem value="MONTHLY">ماهانه</SelectItem>
                    <SelectItem value="QUARTERLY">فصلی</SelectItem>
                    <SelectItem value="YEARLY">سالانه</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>انصراف</Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !formTitle.trim()}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              تولید گزارش
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          {detailReport && (() => {
            const typeMeta = TYPE_META[detailReport.type] || TYPE_META.INSIGHT;
            return (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2 text-right">
                    <Sparkles className="w-5 h-5 text-teal-600" />
                    {detailReport.title}
                  </DialogTitle>
                </DialogHeader>

                <div className="space-y-4 py-2">
                  <div className="flex items-center gap-3">
                    <Badge className={`${typeMeta.bgColor} ${typeMeta.color} text-sm border-0`}>
                      {typeMeta.label}
                    </Badge>
                    <Badge variant="secondary" className="bg-gray-100 text-gray-600 text-sm border-0">
                      {PERIOD_LABELS[detailReport.period] || detailReport.period}
                    </Badge>
                    <span className="text-xs text-gray-400">
                      {formatPersianDate(detailReport.generatedAt)}
                    </span>
                  </div>

                  {/* AI Summary */}
                  {detailReport.summary && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 mb-1">خلاصه AI:</p>
                      <p className="text-sm text-gray-700 bg-teal-50 rounded-lg p-3 leading-7">
                        {detailReport.summary}
                      </p>
                    </div>
                  )}

                  {/* Report Data */}
                  <div>
                    <p className="text-xs font-bold text-gray-500 mb-1">داده‌های گزارش:</p>
                    <div className="bg-gray-50 rounded-lg p-3 overflow-x-auto">
                      <pre className="text-xs text-gray-700 font-mono whitespace-pre-wrap leading-6" dir="ltr">
                        {JSON.stringify(detailReport.data, null, 2)}
                      </pre>
                    </div>
                  </div>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
