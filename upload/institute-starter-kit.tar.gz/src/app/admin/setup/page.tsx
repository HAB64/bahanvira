'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Database, CheckCircle, AlertCircle, Copy, Check, ArrowLeft } from 'lucide-react';

export default function AdminSetupPage() {
  const [initializing, setInitializing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<{ adminUser: string; adminPassword: string; tables: number } | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const handleInitialize = async () => {
    setInitializing(true);
    setError('');
    try {
      const res = await fetch('/api/admin/setup/initialize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess(true);
        setResult({ adminUser: data.adminUser, adminPassword: data.adminPassword, tables: data.tables });
      } else {
        setError(data.error || 'خطا در راه‌اندازی دیتابیس');
      }
    } catch {
      setError('خطا در اتصال به سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setInitializing(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-50 to-gray-100 p-4" dir="rtl">
      <div className="max-w-2xl w-full space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-teal-600 flex items-center justify-center shadow-lg shadow-teal-200 mb-4">
            <Database className="text-white h-8 w-8" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">وضعیت دیتابیس</h1>
          <p className="text-gray-500 mt-2">دیتابیس PostgreSQL (Neon) فعال و آماده است</p>
        </div>

        {success && result ? (
          <div className="space-y-4">
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-700">
                دیتابیس با موفقیت راه‌اندازی شد! {result.tables} جدول و داده‌های اولیه ایجاد شدند.
              </AlertDescription>
            </Alert>

            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg text-teal-700">اطلاعات ورود به پنل مدیریت</CardTitle>
                <CardDescription>
                  این اطلاعات را ذخیره کنید — برای ورود به پنل مدیریت نیاز دارید
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <span className="text-sm text-gray-500">نام کاربری:</span>
                    <span className="mr-2 font-mono font-bold text-gray-900">{result.adminUser}</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => copyToClipboard(result.adminUser, 'user')}>
                    {copied === 'user' ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <span className="text-sm text-gray-500">رمز عبور:</span>
                    <span className="mr-2 font-mono font-bold text-gray-900">{result.adminPassword}</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => copyToClipboard(result.adminPassword, 'pass')}>
                    {copied === 'pass' ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-sm bg-teal-50">
              <CardContent className="p-4">
                <p className="text-teal-800 text-sm">
                  دیتابیس PostgreSQL (Neon) به صورت ابری فعال است. تمام داده‌ها به صورت امن در سرورهای Neon نگهداری می‌شوند.
                </p>
              </CardContent>
            </Card>

            <Button
              onClick={() => window.location.href = '/admin/login'}
              className="w-full bg-teal-600 hover:bg-teal-700"
            >
              ورود به پنل مدیریت
            </Button>
          </div>
        ) : (
          <>
            <Card className="border-0 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  دیتابیس PostgreSQL (Neon) فعال است
                </CardTitle>
                <CardDescription>
                  دیتابیس ابری Neon PostgreSQL متصل و آماده استفاده است
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-800">اتصال به Neon PostgreSQL</p>
                      <p className="text-xs text-gray-500">دیتابیس ابری با ۶۶ جدول و داده‌های اولیه</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-teal-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-800">داده‌های اولیه</p>
                      <p className="text-xs text-gray-500">شامل: ۳ ادمین، تگ‌ها، دوره‌ها، قوانین اتوماسیون، قالب‌های ایمیل</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-teal-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-gray-800">حساب‌های مدیر</p>
                      <p className="text-xs text-gray-500">admin / drbahan / reception</p>
                    </div>
                  </div>
                </div>

                {error && (
                  <Alert variant="destructive" className="bg-red-50 border-red-200">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button
                  onClick={handleInitialize}
                  disabled={initializing}
                  className="w-full bg-teal-600 hover:bg-teal-700"
                >
                  {initializing ? (
                    <span className="flex items-center gap-2">
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      در حال راه‌اندازی دیتابیس...
                    </span>
                  ) : (
                    'بازنشانی دیتابیس'
                  )}
                </Button>
              </CardContent>
            </Card>
          </>
        )}

        <Button
          variant="ghost"
          onClick={() => window.location.href = '/admin/login'}
          className="w-full text-gray-500 hover:text-teal-600"
        >
          <ArrowLeft className="h-4 w-4 ml-2" />
          بازگشت به صفحه ورود
        </Button>
      </div>
    </div>
  );
}
