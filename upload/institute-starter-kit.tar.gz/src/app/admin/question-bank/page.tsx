'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Database, Plus, Search, Pencil, Trash2, Upload, Download,
  Filter, RefreshCw, CheckCircle, XCircle, ChevronLeft, ChevronRight,
  HelpCircle, Sparkles, Tags, BarChart3, FileText, AlertTriangle,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─── Types ─── */
interface QuestionBankItem {
  id: string;
  text: string;
  type: string;
  options: { id: number; text: string; isCorrect: boolean }[] | null;
  correctAnswer: string;
  explanation: string | null;
  difficulty: string;
  points: number;
  tags: string[];
  isActive: boolean;
  usageCount: number;
  successRate: number | null;
  category: { id: string; name: string; color: string } | null;
  createdAt: string;
}

interface Category {
  id: string;
  name: string;
  color: string;
  _count: { questions: number; subCategories: number };
}

interface Stats {
  totalQuestions: number;
  avgSuccessRate: number | null;
  difficultyBreakdown: { difficulty: string; count: number }[];
  typeBreakdown: { type: string; count: number }[];
}

const typeLabels: Record<string, string> = {
  MULTIPLE_CHOICE: 'چهارگزینه‌ای',
  TRUE_FALSE: 'صحیح/غلط',
  SHORT_ANSWER: 'تشریحی',
  MULTI_SELECT: 'چندانتخابی',
  FILL_IN_BLANK: 'جای خالی',
  MATCHING: 'جورچین',
  ORDERING: 'رتبه‌بندی',
};

const difficultyLabels: Record<string, string> = {
  EASY: 'آسان',
  MEDIUM: 'متوسط',
  HARD: 'سخت',
  EXPERT: 'تخصصی',
};

const difficultyColors: Record<string, string> = {
  EASY: 'bg-green-100 text-green-800',
  MEDIUM: 'bg-yellow-100 text-yellow-800',
  HARD: 'bg-orange-100 text-orange-800',
  EXPERT: 'bg-red-100 text-red-800',
};

export default function QuestionBankPage() {
  const router = useRouter();
  const [questions, setQuestions] = useState<QuestionBankItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterDifficulty, setFilterDifficulty] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterActive, setFilterActive] = useState('');

  // Dialogs
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<QuestionBankItem | null>(null);
  const [deleteIds, setDeleteIds] = useState<string[]>([]);

  // Form state
  const [formData, setFormData] = useState({
    text: '',
    type: 'MULTIPLE_CHOICE',
    options: [
      { id: 1, text: '', isCorrect: true },
      { id: 2, text: '', isCorrect: false },
      { id: 3, text: '', isCorrect: false },
      { id: 4, text: '', isCorrect: false },
    ],
    correctAnswer: '',
    explanation: '',
    categoryId: '',
    tags: '',
    difficulty: 'MEDIUM',
    points: 1,
  });

  // Import state
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{
    total: number; imported: number; skipped: number; errors: string[];
  } | null>(null);

  // ─── Fetch Functions ───
  const fetchQuestions = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: String(page),
        limit: '20',
      });
      if (searchQuery) params.set('search', searchQuery);
      if (filterType) params.set('type', filterType);
      if (filterDifficulty) params.set('difficulty', filterDifficulty);
      if (filterCategory) params.set('categoryId', filterCategory);
      if (filterActive) params.set('isActive', filterActive);

      const res = await fetch(`/api/admin/question-bank?${params}`);
      const data = await res.json();

      if (res.ok) {
        setQuestions(data.data || []);
        setStats(data.stats || null);
        setTotal(data.pagination?.total || 0);
        setTotalPages(data.pagination?.totalPages || 1);
      }
    } catch (err) {
      toast.error('خطا در دریافت سوالات');
    } finally {
      setLoading(false);
    }
  }, [page, searchQuery, filterType, filterDifficulty, filterCategory, filterActive]);

  const fetchCategories = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/question-bank/categories');
      if (res.ok) {
        const data = await res.json();
        setCategories(data);
      }
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  useEffect(() => {
    fetchCategories();
  }, [fetchCategories]);

  // ─── Handlers ───
  const openAddDialog = () => {
    setEditingQuestion(null);
    setFormData({
      text: '',
      type: 'MULTIPLE_CHOICE',
      options: [
        { id: 1, text: '', isCorrect: true },
        { id: 2, text: '', isCorrect: false },
        { id: 3, text: '', isCorrect: false },
        { id: 4, text: '', isCorrect: false },
      ],
      correctAnswer: '',
      explanation: '',
      categoryId: '',
      tags: '',
      difficulty: 'MEDIUM',
      points: 1,
    });
    setShowAddDialog(true);
  };

  const openEditDialog = (q: QuestionBankItem) => {
    setEditingQuestion(q);
    setFormData({
      text: q.text,
      type: q.type,
      options: q.options || [
        { id: 1, text: '', isCorrect: true },
        { id: 2, text: '', isCorrect: false },
        { id: 3, text: '', isCorrect: false },
        { id: 4, text: '', isCorrect: false },
      ],
      correctAnswer: q.correctAnswer,
      explanation: q.explanation || '',
      categoryId: q.category?.id || '',
      tags: q.tags.join('، '),
      difficulty: q.difficulty,
      points: q.points,
    });
    setShowAddDialog(true);
  };

  const handleSaveQuestion = async () => {
    if (!formData.text.trim()) {
      toast.error('متن سوال الزامی است');
      return;
    }

    try {
      const optionsForApi =
        formData.type === 'TRUE_FALSE'
          ? formData.options
          : formData.type === 'SHORT_ANSWER'
            ? null
            : formData.options.filter((o) => o.text.trim());

      const payload = {
        text: formData.text.trim(),
        type: formData.type,
        options: optionsForApi,
        correctAnswer:
          formData.type === 'TRUE_FALSE'
            ? formData.options.find((o) => o.isCorrect)?.text || 'صحیح'
            : formData.type === 'SHORT_ANSWER'
              ? formData.correctAnswer
              : formData.options.find((o) => o.isCorrect)?.text || formData.correctAnswer,
        explanation: formData.explanation.trim() || null,
        categoryId: formData.categoryId || null,
        tags: formData.tags
          .split(/[،,]/)
          .map((t) => t.trim())
          .filter(Boolean),
        difficulty: formData.difficulty,
        points: formData.points,
      };

      const res = await fetch('/api/admin/question-bank', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        toast.success(editingQuestion ? 'سوال بروزرسانی شد' : 'سوال جدید اضافه شد');
        setShowAddDialog(false);
        fetchQuestions();
      } else {
        const err = await res.json();
        toast.error(err.error || 'خطا در ذخیره سوال');
      }
    } catch {
      toast.error('خطا در ذخیره سوال');
    }
  };

  const handleDelete = async () => {
    try {
      const idsParam = deleteIds.join(',');
      const res = await fetch(`/api/admin/question-bank?ids=${idsParam}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        toast.success(`${deleteIds.length} سوال حذف شد`);
        setShowDeleteDialog(false);
        fetchQuestions();
      }
    } catch {
      toast.error('خطا در حذف');
    }
  };

  const handleImport = async () => {
    if (!importFile) {
      toast.error('فایل را انتخاب کنید');
      return;
    }

    setImporting(true);
    setImportResult(null);

    try {
      const fd = new FormData();
      fd.append('file', importFile);

      const isJSON = importFile.name.endsWith('.json');
      fd.append('format', isJSON ? 'json' : 'csv');

      const res = await fetch('/api/admin/question-bank/import', {
        method: 'POST',
        body: fd,
      });
      const data = await res.json();

      if (res.ok) {
        setImportResult(data);
        toast.success(`${data.imported} سوال ایمپورت شد`);
        fetchQuestions();
        fetchCategories();
      } else {
        toast.error(data.error || 'خطا در ایمپورت');
      }
    } catch {
      toast.error('خطا در ایمپورت فایل');
    } finally {
      setImporting(false);
    }
  };

  const setCorrectOption = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      options: prev.options.map((o, i) => ({
        ...o,
        isCorrect: i === index,
      })),
    }));
  };

  const handleToggleActive = async (q: QuestionBankItem) => {
    try {
      await fetch('/api/admin/question-bank', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ids: [q.id],
          updates: { isActive: !q.isActive },
        }),
      });
      toast.success(q.isActive ? 'سوال غیرفعال شد' : 'سوال فعال شد');
      fetchQuestions();
    } catch {
      toast.error('خطا در تغییر وضعیت');
    }
  };

  // ─── Export CSV template ───
  const downloadTemplate = () => {
    const csvContent = `سوال,نوع,گزینه ۱,گزینه ۲,گزینه ۳,گزینه ۴,پاسخ,توضیح,سختی,نمره,دسته‌بندی,برچسب
"ویندوز ۱۰ کدام نسخه سیستم‌عامل است؟","چهارگزینه‌ای","سیستم‌عامل موبایل","سیستم‌عامل دسکتاپ","مرورگر وب","ویرایشگر متن","2","ویندوز ۱۰ یک سیستم‌عامل دسکتاپ است","متوسط","1","کامپیوتر","ویندوز,OS"
"آیا RAM یک حافظه غیرفرار است؟","صحیح غلط","صحیح","غلط","","","غلط","RAM حافظه فرار است","آسان","1","کامپیوتر","سخت‌افزار,حافظه"
"تفاوت بین TCP و UDP را شرح دهید","تشریحی","","","","","TCP اتصال‌گراست و UDP بدون اتصال","TCP پروتکل قابل اعتماد و UDP پروتکل سریع است","سخت","2","شبکه","پروتکل,شبکه"`;

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'question-bank-template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  // ─── Render ───
  return (
    <div className="space-y-6 p-4 md:p-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Database className="h-6 w-6 text-indigo-600" />
            بانک سوال
          </h1>
          <p className="text-muted-foreground mt-1">
            مدیریت، ایمپورت و سازماندهی سوالات آزمون
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={downloadTemplate}>
            <Download className="h-4 w-4 ml-1" />
            دانلود قالب CSV
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={() => {
              setImportFile(null);
              setImportResult(null);
              setShowImportDialog(true);
            }}
          >
            <Upload className="h-4 w-4 ml-1" />
            ایمپورت سوال
          </Button>
          <Button variant="default" size="sm" onClick={openAddDialog}>
            <Plus className="h-4 w-4 ml-1" />
            سوال جدید
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-2xl font-bold">{toPersianNumber(stats.totalQuestions)}</p>
                  <p className="text-xs text-muted-foreground">کل سوالات</p>
                </div>
              </div>
            </CardContent>
          </Card>
          {stats.difficultyBreakdown.map((d) => (
            <Card key={d.difficulty}>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2 py-1 rounded-full ${difficultyColors[d.difficulty] || ''}`}>
                    {difficultyLabels[d.difficulty] || d.difficulty}
                  </span>
                  <span className="text-xl font-bold">{toPersianNumber(d.count)}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">فیلترها</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="جستجو در سوالات..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="نوع سوال" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه</SelectItem>
                {Object.entries(typeLabels).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterDifficulty} onValueChange={setFilterDifficulty}>
              <SelectTrigger>
                <SelectValue placeholder="سطح سختی" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه</SelectItem>
                {Object.entries(difficultyLabels).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger>
                <SelectValue placeholder="دسته‌بندی" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه</SelectItem>
                {categories.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterActive} onValueChange={setFilterActive}>
              <SelectTrigger>
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه</SelectItem>
                <SelectItem value="true">فعال</SelectItem>
                <SelectItem value="false">غیرفعال</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Questions List */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">
              سوالات ({toPersianNumber(total)})
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={fetchQuestions}>
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : questions.length === 0 ? (
            <div className="text-center py-12">
              <Database className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-lg font-medium text-muted-foreground">بانک سوال خالی است</p>
              <p className="text-sm text-muted-foreground mt-1">
                سوال جدید اضافه کنید یا فایل CSV/JSON ایمپورت کنید
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {questions.map((q) => (
                <div
                  key={q.id}
                  className={`border rounded-lg p-4 transition-colors ${!q.isActive ? 'opacity-60 bg-muted/50' : 'hover:bg-muted/30'}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${difficultyColors[q.difficulty] || ''}`}>
                          {difficultyLabels[q.difficulty] || q.difficulty}
                        </span>
                        <Badge variant="secondary" className="text-xs">
                          {typeLabels[q.type] || q.type}
                        </Badge>
                        {q.category && (
                          <Badge variant="outline" className="text-xs" style={{ borderColor: q.category.color, color: q.category.color }}>
                            {q.category.name}
                          </Badge>
                        )}
                        <span className="text-xs text-muted-foreground">
                          {toPersianNumber(q.points)} نمره | {toPersianNumber(q.usageCount)} استفاده
                        </span>
                        {!q.isActive && (
                          <Badge variant="destructive" className="text-xs">غیرفعال</Badge>
                        )}
                      </div>
                      <p className="text-sm leading-relaxed">{q.text}</p>
                      {q.options && q.options.length > 0 && q.type !== 'TRUE_FALSE' && (
                        <div className="mt-2 grid grid-cols-1 md:grid-cols-2 gap-1">
                          {q.options.map((opt, i) => (
                            <div key={opt.id} className={`text-xs px-2 py-1 rounded ${opt.isCorrect ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-muted/50'}`}>
                              {toPersianNumber(i + 1)}) {opt.text} {opt.isCorrect && '✓'}
                            </div>
                          ))}
                        </div>
                      )}
                      {q.tags.length > 0 && (
                        <div className="flex items-center gap-1 mt-2 flex-wrap">
                          <Tags className="h-3 w-3 text-muted-foreground" />
                          {q.tags.map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleToggleActive(q)}>
                        {q.isActive ? <CheckCircle className="h-4 w-4 text-green-600" /> : <XCircle className="h-4 w-4 text-red-600" />}
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditDialog(q)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-red-600"
                        onClick={() => {
                          setDeleteIds([q.id]);
                          setShowDeleteDialog(true);
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-6">
              <Button
                variant="outline"
                size="sm"
                disabled={page <= 1}
                onClick={() => setPage(page - 1)}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              <span className="text-sm text-muted-foreground">
                صفحه {toPersianNumber(page)} از {toPersianNumber(totalPages)}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages}
                onClick={() => setPage(page + 1)}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ─── Add/Edit Dialog ─── */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>
              {editingQuestion ? 'ویرایش سوال' : 'سوال جدید'}
            </DialogTitle>
            <DialogDescription>
              اطلاعات سوال را وارد کنید
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Question Type & Difficulty */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>نوع سوال</Label>
                <Select
                  value={formData.type}
                  onValueChange={(v) => {
                    setFormData((prev) => ({
                      ...prev,
                      type: v,
                      options:
                        v === 'TRUE_FALSE'
                          ? [
                              { id: 1, text: 'صحیح', isCorrect: true },
                              { id: 2, text: 'غلط', isCorrect: false },
                            ]
                          : v === 'SHORT_ANSWER'
                            ? []
                            : prev.options,
                    }));
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(typeLabels).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>سطح سختی</Label>
                <Select
                  value={formData.difficulty}
                  onValueChange={(v) =>
                    setFormData((prev) => ({ ...prev, difficulty: v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(difficultyLabels).map(([k, v]) => (
                      <SelectItem key={k} value={k}>{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Question Text */}
            <div>
              <Label>متن سوال *</Label>
              <Textarea
                value={formData.text}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, text: e.target.value }))
                }
                rows={3}
                placeholder="متن سوال را وارد کنید..."
              />
            </div>

            {/* Options (for multiple choice / true-false) */}
            {formData.type !== 'SHORT_ANSWER' && (
              <div>
                <Label>گزینه‌ها</Label>
                <div className="space-y-2 mt-2">
                  {formData.options.map((opt, idx) => (
                    <div key={opt.id} className="flex items-center gap-2">
                      <Button
                        type="button"
                        variant={opt.isCorrect ? 'default' : 'outline'}
                        size="sm"
                        className="shrink-0"
                        onClick={() => setCorrectOption(idx)}
                      >
                        {opt.isCorrect ? (
                          <CheckCircle className="h-3 w-3" />
                        ) : (
                          <span className="text-xs">{toPersianNumber(idx + 1)}</span>
                        )}
                      </Button>
                      <Input
                        value={opt.text}
                        onChange={(e) =>
                          setFormData((prev) => ({
                            ...prev,
                            options: prev.options.map((o, i) =>
                              i === idx ? { ...o, text: e.target.value } : o
                            ),
                          }))
                        }
                        placeholder={`گزینه ${toPersianNumber(idx + 1)}`}
                        disabled={formData.type === 'TRUE_FALSE'}
                      />
                    </div>
                  ))}
                </div>
                {formData.type === 'MULTIPLE_CHOICE' && formData.options.length < 6 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2"
                    onClick={() =>
                      setFormData((prev) => ({
                        ...prev,
                        options: [
                          ...prev.options,
                          {
                            id: prev.options.length + 1,
                            text: '',
                            isCorrect: false,
                          },
                        ],
                      }))
                    }
                  >
                    <Plus className="h-3 w-3 ml-1" />
                    افزودن گزینه
                  </Button>
                )}
              </div>
            )}

            {/* Correct answer for short answer */}
            {formData.type === 'SHORT_ANSWER' && (
              <div>
                <Label>پاسخ صحیح *</Label>
                <Input
                  value={formData.correctAnswer}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      correctAnswer: e.target.value,
                    }))
                  }
                  placeholder="پاسخ صحیح را وارد کنید..."
                />
              </div>
            )}

            {/* Explanation */}
            <div>
              <Label>توضیح پاسخ</Label>
              <Textarea
                value={formData.explanation}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    explanation: e.target.value,
                  }))
                }
                rows={2}
                placeholder="توضیح پاسخ (اختیاری)..."
              />
            </div>

            {/* Category, Tags, Points */}
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>دسته‌بندی</Label>
                <Select
                  value={formData.categoryId}
                  onValueChange={(v) =>
                    setFormData((prev) => ({ ...prev, categoryId: v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="انتخاب" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">بدون دسته‌بندی</SelectItem>
                    {categories.map((c) => (
                      <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>برچسب‌ها</Label>
                <Input
                  value={formData.tags}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, tags: e.target.value }))
                  }
                  placeholder="برچسب۱، برچسب۲"
                />
              </div>
              <div>
                <Label>نمره</Label>
                <Input
                  type="number"
                  value={formData.points}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      points: parseFloat(e.target.value) || 1,
                    }))
                  }
                  min={0.5}
                  step={0.5}
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              انصراف
            </Button>
            <Button onClick={handleSaveQuestion}>
              {editingQuestion ? 'بروزرسانی' : 'ذخیره'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Import Dialog ─── */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>
              <Upload className="h-5 w-5 inline-block ml-2" />
              ایمپورت سوالات از فایل
            </DialogTitle>
            <DialogDescription>
              فایل CSV یا JSON حاوی سوالات را آپلود کنید (فرمت JSON بانک سوالات نیز پشتیبانی می‌شود)
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <input
                type="file"
                accept=".csv,.json"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                className="hidden"
                id="import-file"
              />
              <label htmlFor="import-file" className="cursor-pointer">
                {importFile ? (
                  <div>
                    <FileText className="h-10 w-10 mx-auto text-green-600 mb-2" />
                    <p className="font-medium">{importFile.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(importFile.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                ) : (
                  <div>
                    <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
                    <p className="font-medium">فایل را انتخاب کنید</p>
                    <p className="text-sm text-muted-foreground">
                      CSV، JSON ساده یا JSON بانک سوالات
                    </p>
                  </div>
                )}
              </label>
            </div>

            {/* Import result */}
            {importResult && (
              <Card>
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>کل سوالات:</span>
                      <span className="font-bold">{toPersianNumber(importResult.total)}</span>
                    </div>
                    <div className="flex justify-between text-green-600">
                      <span>ایمپورت موفق:</span>
                      <span className="font-bold">{toPersianNumber(importResult.imported)}</span>
                    </div>
                    <div className="flex justify-between text-yellow-600">
                      <span>رد شده:</span>
                      <span className="font-bold">{toPersianNumber(importResult.skipped)}</span>
                    </div>
                    {importResult.errors.length > 0 && (
                      <div className="mt-2">
                        <p className="text-xs text-red-600 mb-1">خطاها:</p>
                        {importResult.errors.map((err, i) => (
                          <p key={i} className="text-xs text-red-500">{err}</p>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Format info */}
            <div className="bg-muted rounded-lg p-4">
              <p className="text-sm font-medium mb-2">فرمت فایل CSV:</p>
              <code className="text-xs block bg-background rounded p-2 overflow-x-auto whitespace-nowrap" dir="ltr">
                سوال,نوع,گزینه ۱,گزینه ۲,گزینه ۳,گزینه ۴,پاسخ,توضیح,سختی,نمره,دسته‌بندی,برچسب
              </code>
              <p className="text-xs text-muted-foreground mt-2">
                پاسخ می‌تواند شماره گزینه (۱-۴) یا متن گزینه صحیح باشد
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowImportDialog(false)}>
              بستن
            </Button>
            <Button
              onClick={handleImport}
              disabled={!importFile || importing}
            >
              {importing ? (
                <>
                  <RefreshCw className="h-4 w-4 ml-1 animate-spin" />
                  در حال ایمپورت...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 ml-1" />
                  ایمپورت
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Delete Dialog ─── */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف سوال</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف {toPersianNumber(deleteIds.length)} سوال اطمینان دارید؟ این عمل قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
