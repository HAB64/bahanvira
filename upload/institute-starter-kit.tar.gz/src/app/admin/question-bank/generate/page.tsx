'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Sparkles, RefreshCw, Eye, History, CheckCircle, FileText, Zap, BarChart3,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

interface Category {
  id: string;
  name: string;
  color: string;
  _count: { questions: number; subCategories: number };
}

interface GenerationRecord {
  id: string;
  title: string;
  totalQuestions: number;
  easyCount: number;
  mediumCount: number;
  hardCount: number;
  expertCount: number;
  durationMinutes: number;
  passingScore: number;
  createdAt: string;
  exam: { id: string; title: string; type: string; isActive: boolean } | null;
}

const typeLabels: Record<string, string> = {
  QUIZ: 'کوییز',
  MIDTERM: 'میان‌ترم',
  FINAL: 'پایان‌ترم',
  DIAGNOSTIC: 'تشخیصی',
  PRACTICAL: 'عملی',
};

export default function ExamGeneratorPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [history, setHistory] = useState<GenerationRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [generatedExam, setGeneratedExam] = useState<{
    id: string; title: string; totalQuestions: number; totalPoints: number;
    difficultyBreakdown: { easy: number; medium: number; hard: number; expert: number };
  } | null>(null);

  const [form, setForm] = useState({
    title: '',
    description: '',
    categoryId: '',
    tags: '',
    type: 'QUIZ',
    durationMinutes: 30,
    passingScore: 60,
    maxAttempts: 1,
    shuffleQuestions: true,
    showResults: 'AFTER_SUBMIT',
    totalQuestions: 20,
    easyCount: 5,
    mediumCount: 10,
    hardCount: 4,
    expertCount: 1,
  });

  const fetchCategories = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/question-bank/categories');
      if (res.ok) setCategories(await res.json());
    } catch { /* ignore */ }
  }, []);

  const fetchHistory = useCallback(async () => {
    setHistoryLoading(true);
    try {
      const res = await fetch('/api/admin/question-bank/generate?page=1&limit=10');
      if (res.ok) {
        const data = await res.json();
        setHistory(data.data || []);
      }
    } catch { /* ignore */ }
    finally { setHistoryLoading(false); }
  }, []);

  useEffect(() => {
    fetchCategories();
    fetchHistory();
  }, [fetchCategories, fetchHistory]);

  const handleGenerate = async () => {
    if (!form.title.trim()) {
      toast.error('عنوان آزمون الزامی است');
      return;
    }

    const total = form.easyCount + form.mediumCount + form.hardCount + form.expertCount;
    if (total === 0) {
      toast.error('حداقل یک سوال از یک سطح انتخاب کنید');
      return;
    }

    setLoading(true);
    try {
      const payload = {
        ...form,
        tags: form.tags.split(/[،,]/).map((t) => t.trim()).filter(Boolean),
      };

      const res = await fetch('/api/admin/question-bank/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (res.ok) {
        setGeneratedExam(data.exam);
        toast.success(data.message);
        fetchHistory();
      } else {
        toast.error(data.error || 'خطا در تولید آزمون');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 p-4 md:p-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-purple-600" />
            آزمون‌ساز هوشمند
          </h1>
          <p className="text-muted-foreground mt-1">
            تولید آزمون تصادفی از بانک سوال
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => setShowHistory(!showHistory)}>
          <History className="h-4 w-4 ml-1" />
          تاریخچه تولید
        </Button>
      </div>

      {/* History Panel */}
      {showHistory && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <History className="h-5 w-5" />
              تاریخچه تولید آزمون
            </CardTitle>
          </CardHeader>
          <CardContent>
            {historyLoading ? (
              <div className="animate-pulse space-y-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-12 bg-muted rounded" />
                ))}
              </div>
            ) : history.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">
                هنوز آزمونی تولید نشده است
              </p>
            ) : (
              <div className="space-y-2">
                {history.map((h) => (
                  <div key={h.id} className="flex items-center justify-between border rounded-lg p-3">
                    <div>
                      <p className="font-medium text-sm">{h.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-xs">
                          {typeLabels[h.type] || h.type}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {toPersianNumber(h.totalQuestions)} سوال
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {toPersianNumber(h.durationMinutes)} دقیقه
                        </span>
                      </div>
                      <div className="flex gap-2 mt-1">
                        <span className="text-xs bg-green-100 text-green-800 px-1.5 rounded">
                          آسان: {toPersianNumber(h.easyCount)}
                        </span>
                        <span className="text-xs bg-yellow-100 text-yellow-800 px-1.5 rounded">
                          متوسط: {toPersianNumber(h.mediumCount)}
                        </span>
                        <span className="text-xs bg-orange-100 text-orange-800 px-1.5 rounded">
                          سخت: {toPersianNumber(h.hardCount)}
                        </span>
                        <span className="text-xs bg-red-100 text-red-800 px-1.5 rounded">
                          تخصصی: {toPersianNumber(h.expertCount)}
                        </span>
                      </div>
                    </div>
                    {h.exam && (
                      <div className="flex items-center gap-2">
                        <Badge variant={h.exam.isActive ? 'default' : 'secondary'} className="text-xs">
                          {h.exam.isActive ? 'فعال' : 'غیرفعال'}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => window.open(`/admin/exams/${h.exam!.id}`, '_blank')}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Config Panel */}
        <div className="lg:col-span-2 space-y-4">
          {/* Exam Info */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="h-5 w-5" />
                اطلاعات آزمون
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>عنوان آزمون *</Label>
                <Input
                  value={form.title}
                  onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
                  placeholder="مثلاً: آزمون پایانی ICDL"
                />
              </div>
              <div>
                <Label>توضیحات</Label>
                <Textarea
                  value={form.description}
                  onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                  placeholder="توضیحات آزمون (اختیاری)"
                  rows={2}
                />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <Label>نوع آزمون</Label>
                  <Select value={form.type} onValueChange={(v) => setForm((p) => ({ ...p, type: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(typeLabels).map(([k, v]) => (
                        <SelectItem key={k} value={k}>{v}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>مدت (دقیقه)</Label>
                  <Input
                    type="number"
                    value={form.durationMinutes}
                    onChange={(e) => setForm((p) => ({ ...p, durationMinutes: parseInt(e.target.value) || 30 }))}
                  />
                </div>
                <div>
                  <Label>نمره عبور</Label>
                  <Input
                    type="number"
                    value={form.passingScore}
                    onChange={(e) => setForm((p) => ({ ...p, passingScore: parseFloat(e.target.value) || 60 }))}
                  />
                </div>
                <div>
                  <Label>حداکثر تلاش</Label>
                  <Input
                    type="number"
                    value={form.maxAttempts}
                    onChange={(e) => setForm((p) => ({ ...p, maxAttempts: parseInt(e.target.value) || 1 }))}
                  />
                </div>
                <div>
                  <Label>نمایش نتایج</Label>
                  <Select value={form.showResults} onValueChange={(v) => setForm((p) => ({ ...p, showResults: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AFTER_SUBMIT">بعد از ارسال</SelectItem>
                      <SelectItem value="AFTER_DEADLINE">بعد از مهلت</SelectItem>
                      <SelectItem value="NEVER">هرگز</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={form.shuffleQuestions}
                      onChange={(e) => setForm((p) => ({ ...p, shuffleQuestions: e.target.checked }))}
                      className="rounded border-gray-300"
                    />
                    <span className="text-sm">ترتیب تصادفی</span>
                  </label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Question Selection */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Zap className="h-5 w-5 text-yellow-500" />
                انتخاب سوالات از بانک
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>فیلتر دسته‌بندی</Label>
                  <Select
                    value={form.categoryId}
                    onValueChange={(v) => setForm((p) => ({ ...p, categoryId: v === 'all' ? '' : v }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="همه دسته‌بندی‌ها" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">همه دسته‌بندی‌ها</SelectItem>
                      {categories.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.name} ({toPersianNumber(c._count.questions)})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>برچسب‌ها</Label>
                  <Input
                    value={form.tags}
                    onChange={(e) => setForm((p) => ({ ...p, tags: e.target.value }))}
                    placeholder="برچسب۱، برچسب۲"
                  />
                </div>
              </div>

              <div className="bg-muted rounded-lg p-4">
                <p className="text-sm font-medium mb-3 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  تعداد سوالات بر اساس سطح سختی
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { key: 'easyCount' as const, label: 'آسان', color: 'green' },
                    { key: 'mediumCount' as const, label: 'متوسط', color: 'yellow' },
                    { key: 'hardCount' as const, label: 'سخت', color: 'orange' },
                    { key: 'expertCount' as const, label: 'تخصصی', color: 'red' },
                  ].map(({ key, label, color }) => (
                    <div key={key} className="space-y-1">
                      <Label className={`text-${color}-700 text-xs`}>{label}</Label>
                      <Input
                        type="number"
                        value={form[key]}
                        onChange={(e) => setForm((p) => ({ ...p, [key]: parseInt(e.target.value) || 0 }))}
                        min={0}
                        className={`border-${color}-200`}
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-center">
                <Button
                  className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white px-8"
                  onClick={handleGenerate}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <RefreshCw className="h-4 w-4 ml-2 animate-spin" />
                      در حال تولید...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 ml-2" />
                      تولید آزمون
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Summary */}
        <div>
          <Card className="sticky top-4">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">خلاصه آزمون</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">نوع:</span>
                <span>{typeLabels[form.type]}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">مدت:</span>
                <span>{toPersianNumber(form.durationMinutes)} دقیقه</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">نمره عبور:</span>
                <span>{toPersianNumber(form.passingScore)}%</span>
              </div>
              <hr />
              <div className="space-y-1">
                <p className="text-sm font-medium">توزیع سطح سختی:</p>
                {[
                  { key: 'easyCount' as const, label: 'آسان', color: 'text-green-600' },
                  { key: 'mediumCount' as const, label: 'متوسط', color: 'text-yellow-600' },
                  { key: 'hardCount' as const, label: 'سخت', color: 'text-orange-600' },
                  { key: 'expertCount' as const, label: 'تخصصی', color: 'text-red-600' },
                ].map(({ key, label, color }) => (
                  <div key={key} className="flex justify-between text-sm">
                    <span className={color}>{label}</span>
                    <span>{toPersianNumber(form[key])}</span>
                  </div>
                ))}
                <hr />
                <div className="flex justify-between font-bold">
                  <span>مجموع:</span>
                  <span>
                    {toPersianNumber(form.easyCount + form.mediumCount + form.hardCount + form.expertCount)} سوال
                  </span>
                </div>
              </div>

              {generatedExam && (
                <div className="mt-4 bg-green-50 border border-green-200 rounded-lg p-3">
                  <div className="flex items-center gap-2 text-green-800 mb-2">
                    <CheckCircle className="h-5 w-5" />
                    <span className="font-medium">آزمون تولید شد!</span>
                  </div>
                  <p className="text-sm text-green-700">
                    {toPersianNumber(generatedExam.totalQuestions)} سوال | {toPersianNumber(generatedExam.totalPoints)} نمره کل
                  </p>
                  <Button
                    size="sm"
                    className="w-full mt-2 bg-green-600 hover:bg-green-700"
                    onClick={() => window.open(`/admin/exams/${generatedExam.id}`, '_blank')}
                  >
                    <Eye className="h-4 w-4 ml-1" />
                    مشاهده آزمون
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
