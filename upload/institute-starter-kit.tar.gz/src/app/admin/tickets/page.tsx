'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Ticket as TicketIcon,
  Clock,
  Loader2,
  Plus,
  Search,
  AlertTriangle,
  User,
  X,
  MessageSquare,
  ChevronRight,
  ChevronLeft,
  Eye,
  ArrowLeft,
  CheckCircle2,
  Hourglass,
  CircleDot,
  ShieldCheck,
  Ban,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Ticket {
  id: string;
  subject: string;
  description: string;
  category: string;
  priority: string;
  status: string;
  leadId: string | null;
  karAmuzId: string | null;
  assignedTo: string;
  source: string;
  sourceId: string | null;
  resolution: string | null;
  resolvedAt: string | null;
  closedAt: string | null;
  firstResponseAt: string | null;
  satisfactionRating: number | null;
  createdAt: string;
  updatedAt: string;
  lead?: { id: string; name: string; phone: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string; phone: string } | null;
  _count?: { responses: number };
}

interface TicketResponse {
  id: string;
  ticketId: string;
  content: string;
  authorType: string;
  authorName: string;
  isInternal: boolean;
  createdAt: string;
}

interface LeadOption {
  id: string;
  name: string;
}

interface KarAmuzOption {
  id: string;
  firstName: string;
  lastName: string;
}

interface PaginationInfo {
  صفحه: number;
  حجم: number;
  کل: number;
  تعداد_صفحات: number;
}

/* ─────────── Constants ─────────── */

const PRIORITY_META: Record<string, { label: string; color: string; bgColor: string }> = {
  URGENT: { label: 'فوری', color: 'text-red-700', bgColor: 'bg-red-100' },
  HIGH: { label: 'بالا', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  MEDIUM: { label: 'متوسط', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  LOW: { label: 'پایین', color: 'text-gray-600', bgColor: 'bg-gray-100' },
};

const STATUS_META: Record<string, { label: string; color: string; bgColor: string; icon: React.ElementType }> = {
  OPEN: { label: 'باز', color: 'text-blue-700', bgColor: 'bg-blue-100', icon: CircleDot },
  IN_PROGRESS: { label: 'در انجام', color: 'text-teal-700', bgColor: 'bg-teal-100', icon: Clock },
  WAITING_CUSTOMER: { label: 'منتظر مشتری', color: 'text-yellow-700', bgColor: 'bg-yellow-100', icon: Hourglass },
  RESOLVED: { label: 'حل‌شده', color: 'text-green-700', bgColor: 'bg-green-100', icon: CheckCircle2 },
  CLOSED: { label: 'بسته‌شده', color: 'text-gray-500', bgColor: 'bg-gray-100', icon: Ban },
};

const CATEGORY_META: Record<string, { label: string; color: string; bgColor: string }> = {
  GENERAL: { label: 'عمومی', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  ENROLLMENT: { label: 'ثبت‌نام', color: 'text-teal-700', bgColor: 'bg-teal-50' },
  PAYMENT: { label: 'پرداخت', color: 'text-emerald-700', bgColor: 'bg-emerald-50' },
  CERTIFICATE: { label: 'گواهینامه', color: 'text-purple-700', bgColor: 'bg-purple-50' },
  TECHNICAL: { label: 'فنی', color: 'text-orange-700', bgColor: 'bg-orange-50' },
  COMPLAINT: { label: 'شکایت', color: 'text-red-700', bgColor: 'bg-red-50' },
};

const PRIORITY_OPTIONS = [
  { value: 'URGENT', label: 'فوری' },
  { value: 'HIGH', label: 'بالا' },
  { value: 'MEDIUM', label: 'متوسط' },
  { value: 'LOW', label: 'پایین' },
];

const CATEGORY_OPTIONS = [
  { value: 'GENERAL', label: 'عمومی' },
  { value: 'ENROLLMENT', label: 'ثبت‌نام' },
  { value: 'PAYMENT', label: 'پرداخت' },
  { value: 'CERTIFICATE', label: 'گواهینامه' },
  { value: 'TECHNICAL', label: 'فنی' },
  { value: 'COMPLAINT', label: 'شکایت' },
];

const STATUS_OPTIONS = [
  { value: 'OPEN', label: 'باز' },
  { value: 'IN_PROGRESS', label: 'در انجام' },
  { value: 'WAITING_CUSTOMER', label: 'منتظر مشتری' },
  { value: 'RESOLVED', label: 'حل‌شده' },
  { value: 'CLOSED', label: 'بسته‌شده' },
];

const STATUS_FLOW: Record<string, string[]> = {
  OPEN: ['IN_PROGRESS'],
  IN_PROGRESS: ['WAITING_CUSTOMER', 'RESOLVED'],
  WAITING_CUSTOMER: ['IN_PROGRESS', 'RESOLVED'],
  RESOLVED: ['CLOSED', 'IN_PROGRESS'],
  CLOSED: ['IN_PROGRESS'],
};

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string): string {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

function formatPersianDateShort(dateStr: string): string {
  return new Intl.DateTimeFormat('fa-IR', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function TicketManagementPage() {
  /* ── State ── */
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState<Record<string, number>>({});
  const [pagination, setPagination] = useState<PaginationInfo>({
    صفحه: 1,
    حجم: 20,
    کل: 0,
    تعداد_صفحات: 1,
  });

  // Filters
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);

  // Add ticket dialog
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formSubject, setFormSubject] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formCategory, setFormCategory] = useState('GENERAL');
  const [formPriority, setFormPriority] = useState('MEDIUM');
  const [formLeadId, setFormLeadId] = useState('');
  const [formKarAmuzId, setFormKarAmuzId] = useState('');
  const [formAssignedTo, setFormAssignedTo] = useState('');

  // Lead/KarAmuz search
  const [leadOptions, setLeadOptions] = useState<LeadOption[]>([]);
  const [karAmuzOptions, setKarAmuzOptions] = useState<KarAmuzOption[]>([]);
  const [leadSearch, setLeadSearch] = useState('');
  const [karAmuzSearch, setKarAmuzSearch] = useState('');
  const [leadsLoading, setLeadsLoading] = useState(false);
  const [karAmuzLoading, setKarAmuzLoading] = useState(false);

  // Detail dialog
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [responses, setResponses] = useState<TicketResponse[]>([]);
  const [responsesLoading, setResponsesLoading] = useState(false);
  const [responseContent, setResponseContent] = useState('');
  const [responseIsInternal, setResponseIsInternal] = useState(false);
  const [submittingResponse, setSubmittingResponse] = useState(false);
  const [statusUpdating, setStatusUpdating] = useState(false);

  /* ── Data fetching ── */

  const fetchTickets = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (filterStatus && filterStatus !== 'all') params.set('status', filterStatus);
      if (filterPriority && filterPriority !== 'all') params.set('priority', filterPriority);
      if (filterCategory && filterCategory !== 'all') params.set('category', filterCategory);
      params.set('page', currentPage.toString());
      params.set('limit', '20');

      const res = await fetch(`/api/crm/tickets?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت تیکت‌ها');
        return;
      }

      setTickets(data['داده‌ها'] || []);
      setStats(data['آمار'] || {});
      setPagination(data['صفحه‌بندی'] || { صفحه: 1, حجم: 20, کل: 0, تعداد_صفحات: 1 });
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterStatus, filterPriority, filterCategory, currentPage]);

  useEffect(() => {
    fetchTickets();
  }, [fetchTickets]);

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [search, filterStatus, filterPriority, filterCategory]);

  const fetchLeads = useCallback(async (q: string) => {
    if (!q || q.length < 2) {
      setLeadOptions([]);
      return;
    }
    setLeadsLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/leads?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setLeadOptions(
          (data['داده‌ها'] || []).map((l: { id: string; name: string }) => ({
            id: l.id,
            name: l.name,
          }))
        );
      }
    } catch {
      // silent
    } finally {
      setLeadsLoading(false);
    }
  }, []);

  const fetchKarAmuz = useCallback(async (q: string) => {
    if (!q || q.length < 2) {
      setKarAmuzOptions([]);
      return;
    }
    setKarAmuzLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/karamuz?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setKarAmuzOptions(
          (data['داده‌ها'] || []).map((k: { id: string; firstName: string; lastName: string }) => ({
            id: k.id,
            firstName: k.firstName,
            lastName: k.lastName,
          }))
        );
      }
    } catch {
      // silent
    } finally {
      setKarAmuzLoading(false);
    }
  }, []);

  const fetchResponses = useCallback(async (ticketId: string) => {
    setResponsesLoading(true);
    try {
      const res = await fetch(`/api/crm/tickets/responses?ticketId=${ticketId}`);
      const data = await res.json();
      if (res.ok) {
        setResponses(data['داده‌ها'] || []);
      }
    } catch {
      // silent
    } finally {
      setResponsesLoading(false);
    }
  }, []);

  /* ── Computed ── */

  const statCounts = useMemo(() => {
    const open = stats['OPEN'] || 0;
    const inProgress = stats['IN_PROGRESS'] || 0;
    const waitingCustomer = stats['WAITING_CUSTOMER'] || 0;
    const resolvedClosed = (stats['RESOLVED'] || 0) + (stats['CLOSED'] || 0);
    return { open, inProgress, waitingCustomer, resolvedClosed };
  }, [stats]);

  /* ── Modal handlers ── */

  const openAddDialog = () => {
    setFormSubject('');
    setFormDescription('');
    setFormCategory('GENERAL');
    setFormPriority('MEDIUM');
    setFormLeadId('');
    setFormKarAmuzId('');
    setFormAssignedTo('');
    setLeadSearch('');
    setKarAmuzSearch('');
    setLeadOptions([]);
    setKarAmuzOptions([]);
    setAddDialogOpen(true);
  };

  const closeAddDialog = () => {
    setAddDialogOpen(false);
  };

  const handleSubmitTicket = async () => {
    if (!formSubject.trim() || !formDescription.trim()) return;

    setSubmitting(true);
    try {
      const payload = {
        subject: formSubject.trim(),
        description: formDescription.trim(),
        category: formCategory,
        priority: formPriority,
        leadId: formLeadId || null,
        karAmuzId: formKarAmuzId || null,
        assignedTo: formAssignedTo.trim() || null,
      };

      const res = await fetch('/api/crm/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        closeAddDialog();
        fetchTickets();
      }
    } catch {
      // silent
    } finally {
      setSubmitting(false);
    }
  };

  const openDetailDialog = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setResponseContent('');
    setResponseIsInternal(false);
    setDetailDialogOpen(true);
    fetchResponses(ticket.id);
  };

  const closeDetailDialog = () => {
    setDetailDialogOpen(false);
    setSelectedTicket(null);
    setResponses([]);
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!selectedTicket) return;
    setStatusUpdating(true);
    try {
      const res = await fetch('/api/crm/tickets', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticketId: selectedTicket.id, status: newStatus }),
      });

      if (res.ok) {
        const data = await res.json();
        setSelectedTicket(data['داده']);
        fetchTickets();
      }
    } catch {
      // silent
    } finally {
      setStatusUpdating(false);
    }
  };

  const handleSubmitResponse = async () => {
    if (!responseContent.trim() || !selectedTicket) return;

    setSubmittingResponse(true);
    try {
      const res = await fetch('/api/crm/tickets/responses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ticketId: selectedTicket.id,
          content: responseContent.trim(),
          authorType: 'ADMIN',
          authorName: 'admin',
          isInternal: responseIsInternal,
        }),
      });

      if (res.ok) {
        setResponseContent('');
        setResponseIsInternal(false);
        fetchResponses(selectedTicket.id);
        fetchTickets();
      }
    } catch {
      // silent
    } finally {
      setSubmittingResponse(false);
    }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <TicketIcon className="w-6 h-6 text-teal-600" />
          </div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-gray-900">مدیریت تیکت‌ها</h1>
            <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-sm px-2.5">
              {loading ? '...' : toPersianNumber(pagination.کل)}
            </Badge>
          </div>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          تیکت جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Open */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">باز</p>
                <p className="text-2xl font-bold mt-1 text-blue-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(statCounts.open)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <CircleDot className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* In Progress */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">در انجام</p>
                <p className="text-2xl font-bold mt-1 text-teal-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(statCounts.inProgress)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                <Clock className="w-5 h-5 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Waiting Customer */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">منتظر مشتری</p>
                <p className="text-2xl font-bold mt-1 text-yellow-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(statCounts.waitingCustomer)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-200">
                <Hourglass className="w-5 h-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Resolved + Closed */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">حل‌شده / بسته‌شده</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(statCounts.resolvedClosed)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <ShieldCheck className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters Row */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="جستجوی موضوع یا توضیحات..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10 bg-white"
          />
        </div>

        {/* Status Filter */}
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-44 bg-white">
            <SelectValue placeholder="وضعیت" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Priority Filter */}
        <Select value={filterPriority} onValueChange={setFilterPriority}>
          <SelectTrigger className="w-full sm:w-40 bg-white">
            <SelectValue placeholder="اولویت" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه اولویت‌ها</SelectItem>
            {PRIORITY_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Category Filter */}
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full sm:w-40 bg-white">
            <SelectValue placeholder="دسته‌بندی" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه دسته‌ها</SelectItem>
            {CATEGORY_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Tickets Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchTickets}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : tickets.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <TicketIcon className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">تیکتی یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با تغییر فیلترها یا ایجاد تیکت جدید شروع کنید
            </p>
            <Button
              onClick={openAddDialog}
              className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <Plus className="w-4 h-4" />
              تیکت جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden md:block bg-white rounded-xl shadow-sm border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-right font-semibold text-gray-700">موضوع</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700">شخص مرتبط</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700">دسته‌بندی</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700">اولویت</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700">وضعیت</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700">مسئول</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700">تاریخ</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700">پاسخ</TableHead>
                  <TableHead className="text-right font-semibold text-gray-700 w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tickets.map((ticket) => {
                  const priorityMeta = PRIORITY_META[ticket.priority] || PRIORITY_META.MEDIUM;
                  const statusMeta = STATUS_META[ticket.status] || STATUS_META.OPEN;
                  const categoryMeta = CATEGORY_META[ticket.category] || CATEGORY_META.GENERAL;
                  const relatedPerson = ticket.lead?.name || (ticket.karAmuz ? `${ticket.karAmuz.firstName} ${ticket.karAmuz.lastName}` : '');
                  const responseCount = ticket._count?.responses || 0;

                  return (
                    <TableRow
                      key={ticket.id}
                      className="cursor-pointer hover:bg-gray-50/80 transition-colors"
                      onClick={() => openDetailDialog(ticket)}
                    >
                      <TableCell className="font-medium text-gray-900 max-w-[200px] truncate">
                        {ticket.subject}
                      </TableCell>
                      <TableCell className="text-gray-600">
                        {relatedPerson ? (
                          <div className="flex items-center gap-1.5">
                            <User className="w-3.5 h-3.5 text-gray-400" />
                            <span className="truncate max-w-[120px]">{relatedPerson}</span>
                          </div>
                        ) : (
                          <span className="text-gray-300">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`${categoryMeta.bgColor} ${categoryMeta.color} text-xs border-0`}>
                          {categoryMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`${priorityMeta.bgColor} ${priorityMeta.color} text-xs border-0`}>
                          {priorityMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
                          {statusMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-600 text-sm">
                        {ticket.assignedTo || <span className="text-gray-300">-</span>}
                      </TableCell>
                      <TableCell className="text-gray-500 text-xs whitespace-nowrap">
                        {formatPersianDateShort(ticket.createdAt)}
                      </TableCell>
                      <TableCell className="text-center">
                        {responseCount > 0 ? (
                          <div className="flex items-center justify-center gap-1">
                            <MessageSquare className="w-3.5 h-3.5 text-teal-500" />
                            <span className="text-xs font-medium text-teal-700">
                              {toPersianNumber(responseCount)}
                            </span>
                          </div>
                        ) : (
                          <span className="text-gray-300 text-xs">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-400 hover:text-teal-600 hover:bg-teal-50"
                          onClick={(e) => {
                            e.stopPropagation();
                            openDetailDialog(ticket);
                          }}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden space-y-3">
            {tickets.map((ticket) => {
              const priorityMeta = PRIORITY_META[ticket.priority] || PRIORITY_META.MEDIUM;
              const statusMeta = STATUS_META[ticket.status] || STATUS_META.OPEN;
              const categoryMeta = CATEGORY_META[ticket.category] || CATEGORY_META.GENERAL;
              const relatedPerson = ticket.lead?.name || (ticket.karAmuz ? `${ticket.karAmuz.firstName} ${ticket.karAmuz.lastName}` : '');
              const responseCount = ticket._count?.responses || 0;

              return (
                <div
                  key={ticket.id}
                  className="bg-white rounded-xl shadow-sm border p-4 cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => openDetailDialog(ticket)}
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-bold text-gray-900 text-sm line-clamp-1">{ticket.subject}</h3>
                    <Badge variant="secondary" className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0 shrink-0`}>
                      {statusMeta.label}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    <Badge variant="secondary" className={`${categoryMeta.bgColor} ${categoryMeta.color} text-[10px] border-0`}>
                      {categoryMeta.label}
                    </Badge>
                    <Badge variant="secondary" className={`${priorityMeta.bgColor} ${priorityMeta.color} text-[10px] border-0`}>
                      {priorityMeta.label}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center gap-3">
                      {relatedPerson && (
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          <span className="truncate max-w-[100px]">{relatedPerson}</span>
                        </div>
                      )}
                      {ticket.assignedTo && (
                        <span>{ticket.assignedTo}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {responseCount > 0 && (
                        <div className="flex items-center gap-0.5">
                          <MessageSquare className="w-3 h-3 text-teal-500" />
                          <span className="text-teal-700">{toPersianNumber(responseCount)}</span>
                        </div>
                      )}
                      <span>{formatPersianDateShort(ticket.createdAt)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Pagination */}
          {pagination.تعداد_صفحات > 1 && (
            <div className="flex items-center justify-center gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="gap-1"
              >
                <ChevronRight className="w-4 h-4" />
                قبلی
              </Button>
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(pagination.تعداد_صفحات, 5) }, (_, i) => {
                  let pageNum: number;
                  if (pagination.تعداد_صفحات <= 5) {
                    pageNum = i + 1;
                  } else if (currentPage <= 3) {
                    pageNum = i + 1;
                  } else if (currentPage >= pagination.تعداد_صفحات - 2) {
                    pageNum = pagination.تعداد_صفحات - 4 + i;
                  } else {
                    pageNum = currentPage - 2 + i;
                  }
                  return (
                    <Button
                      key={pageNum}
                      variant={currentPage === pageNum ? 'default' : 'outline'}
                      size="sm"
                      className={`w-9 h-9 p-0 ${
                        currentPage === pageNum ? 'bg-teal-600 hover:bg-teal-700 text-white' : ''
                      }`}
                      onClick={() => setCurrentPage(pageNum)}
                    >
                      {toPersianNumber(pageNum)}
                    </Button>
                  );
                })}
              </div>
              <Button
                variant="outline"
                size="sm"
                disabled={currentPage >= pagination.تعداد_صفحات}
                onClick={() => setCurrentPage((p) => Math.min(pagination.تعداد_صفحات, p + 1))}
                className="gap-1"
              >
                بعدی
                <ChevronLeft className="w-4 h-4" />
              </Button>
            </div>
          )}
        </>
      )}

      {/* Add Ticket Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <TicketIcon className="w-5 h-5 text-teal-600" />
              تیکت جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Subject */}
            <div className="space-y-1.5">
              <Label htmlFor="ticket-subject" className="text-sm font-medium">
                موضوع <span className="text-red-500">*</span>
              </Label>
              <Input
                id="ticket-subject"
                placeholder="موضوع تیکت..."
                value={formSubject}
                onChange={(e) => setFormSubject(e.target.value)}
              />
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <Label htmlFor="ticket-desc" className="text-sm font-medium">
                توضیحات <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="ticket-desc"
                placeholder="توضیحات تیکت..."
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                rows={4}
              />
            </div>

            {/* Category + Priority */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">دسته‌بندی</Label>
                <Select value={formCategory} onValueChange={setFormCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORY_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label className="text-sm font-medium">اولویت</Label>
                <Select value={formPriority} onValueChange={setFormPriority}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PRIORITY_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Assigned To */}
            <div className="space-y-1.5">
              <Label htmlFor="ticket-assignee" className="text-sm font-medium">
                مسئول
              </Label>
              <Input
                id="ticket-assignee"
                placeholder="نام مسئول..."
                value={formAssignedTo}
                onChange={(e) => setFormAssignedTo(e.target.value)}
              />
            </div>

            {/* Lead search & select */}
            <div className="space-y-1.5">
              <Label htmlFor="ticket-lead" className="text-sm font-medium">
                لید مرتبط
              </Label>
              <div className="relative">
                <Input
                  id="ticket-lead"
                  placeholder="جستجوی لید..."
                  value={leadSearch}
                  onChange={(e) => {
                    setLeadSearch(e.target.value);
                    fetchLeads(e.target.value);
                  }}
                />
                {leadsLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {leadOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {leadOptions.map((lead) => (
                    <button
                      key={lead.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-teal-50 transition-colors ${
                        formLeadId === lead.id ? 'bg-teal-50 text-teal-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormLeadId(lead.id);
                        setLeadSearch(lead.name);
                        setLeadOptions([]);
                      }}
                    >
                      {lead.name}
                    </button>
                  ))}
                </div>
              )}
              {formLeadId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                    {leadSearch}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5"
                    onClick={() => {
                      setFormLeadId('');
                      setLeadSearch('');
                    }}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* KarAmuz search & select */}
            <div className="space-y-1.5">
              <Label htmlFor="ticket-karamuz" className="text-sm font-medium">
                کارآموز مرتبط
              </Label>
              <div className="relative">
                <Input
                  id="ticket-karamuz"
                  placeholder="جستجوی کارآموز..."
                  value={karAmuzSearch}
                  onChange={(e) => {
                    setKarAmuzSearch(e.target.value);
                    fetchKarAmuz(e.target.value);
                  }}
                />
                {karAmuzLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {karAmuzOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {karAmuzOptions.map((ka) => (
                    <button
                      key={ka.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-purple-50 transition-colors ${
                        formKarAmuzId === ka.id ? 'bg-purple-50 text-purple-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormKarAmuzId(ka.id);
                        setKarAmuzSearch(`${ka.firstName} ${ka.lastName}`);
                        setKarAmuzOptions([]);
                      }}
                    >
                      {ka.firstName} {ka.lastName}
                    </button>
                  ))}
                </div>
              )}
              {formKarAmuzId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-purple-50 text-purple-700 text-xs">
                    {karAmuzSearch}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5"
                    onClick={() => {
                      setFormKarAmuzId('');
                      setKarAmuzSearch('');
                    }}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={closeAddDialog}
              disabled={submitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleSubmitTicket}
              disabled={submitting || !formSubject.trim() || !formDescription.trim()}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
              ایجاد تیکت
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Ticket Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <TicketIcon className="w-5 h-5 text-teal-600" />
              جزئیات تیکت
            </DialogTitle>
          </DialogHeader>

          {selectedTicket && (
            <div className="space-y-5">
              {/* Ticket Info */}
              <div className="bg-gray-50 rounded-xl p-4 space-y-3">
                {/* Subject */}
                <div>
                  <h3 className="text-lg font-bold text-gray-900">{selectedTicket.subject}</h3>
                </div>

                {/* Badges row */}
                <div className="flex flex-wrap gap-2">
                  {(() => {
                    const categoryMeta = CATEGORY_META[selectedTicket.category] || CATEGORY_META.GENERAL;
                    const priorityMeta = PRIORITY_META[selectedTicket.priority] || PRIORITY_META.MEDIUM;
                    const statusMeta = STATUS_META[selectedTicket.status] || STATUS_META.OPEN;
                    return (
                      <>
                        <Badge variant="secondary" className={`${categoryMeta.bgColor} ${categoryMeta.color} text-xs border-0`}>
                          {categoryMeta.label}
                        </Badge>
                        <Badge variant="secondary" className={`${priorityMeta.bgColor} ${priorityMeta.color} text-xs border-0`}>
                          {priorityMeta.label}
                        </Badge>
                        <Badge variant="secondary" className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
                          {statusMeta.label}
                        </Badge>
                      </>
                    );
                  })()}
                </div>

                {/* Description */}
                <div>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">
                    {selectedTicket.description}
                  </p>
                </div>

                {/* Meta info grid */}
                <div className="grid grid-cols-2 gap-3 text-sm">
                  {selectedTicket.assignedTo && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <User className="w-4 h-4 text-gray-400" />
                      <span>مسئول: {selectedTicket.assignedTo}</span>
                    </div>
                  )}
                  {selectedTicket.lead && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <User className="w-4 h-4 text-teal-500" />
                      <span>لید: {selectedTicket.lead.name}</span>
                    </div>
                  )}
                  {selectedTicket.karAmuz && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <User className="w-4 h-4 text-purple-500" />
                      <span>کارآموز: {selectedTicket.karAmuz.firstName} {selectedTicket.karAmuz.lastName}</span>
                    </div>
                  )}
                  <div className="text-gray-500 text-xs">
                    ایجاد: {formatPersianDate(selectedTicket.createdAt)}
                  </div>
                  <div className="text-gray-500 text-xs">
                    به‌روزرسانی: {formatPersianDate(selectedTicket.updatedAt)}
                  </div>
                  {selectedTicket.firstResponseAt && (
                    <div className="text-gray-500 text-xs">
                      اولین پاسخ: {formatPersianDate(selectedTicket.firstResponseAt)}
                    </div>
                  )}
                  {selectedTicket.resolvedAt && (
                    <div className="text-gray-500 text-xs">
                      حل‌شده: {formatPersianDate(selectedTicket.resolvedAt)}
                    </div>
                  )}
                  {selectedTicket.closedAt && (
                    <div className="text-gray-500 text-xs">
                      بسته‌شده: {formatPersianDate(selectedTicket.closedAt)}
                    </div>
                  )}
                </div>

                {/* Resolution */}
                {selectedTicket.resolution && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                    <p className="text-xs font-medium text-green-700 mb-1">نتیجه نهایی:</p>
                    <p className="text-sm text-green-800">{selectedTicket.resolution}</p>
                  </div>
                )}
              </div>

              {/* Status Change Buttons */}
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">تغییر وضعیت:</p>
                <div className="flex flex-wrap gap-2">
                  {STATUS_FLOW[selectedTicket.status]?.map((nextStatus) => {
                    const meta = STATUS_META[nextStatus];
                    if (!meta) return null;
                    const Icon = meta.icon;
                    return (
                      <Button
                        key={nextStatus}
                        variant="outline"
                        size="sm"
                        className={`${meta.bgColor} ${meta.color} border-current/20 hover:opacity-80 gap-1.5`}
                        onClick={() => handleStatusChange(nextStatus)}
                        disabled={statusUpdating}
                      >
                        {statusUpdating ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Icon className="w-3.5 h-3.5" />
                        )}
                        {meta.label}
                      </Button>
                    );
                  })}
                </div>
              </div>

              {/* Response Thread */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-teal-600" />
                  <p className="text-sm font-medium text-gray-700">
                    تاریخچه پاسخ‌ها ({toPersianNumber(responses.length)})
                  </p>
                </div>

                {responsesLoading ? (
                  <div className="space-y-2">
                    {[...Array(3)].map((_, i) => (
                      <Skeleton key={i} className="h-16 rounded-lg" />
                    ))}
                  </div>
                ) : responses.length === 0 ? (
                  <div className="text-center py-6 text-gray-400 text-sm">
                    هنوز پاسخی ثبت نشده است
                  </div>
                ) : (
                  <div className="max-h-80 overflow-y-auto space-y-2 pr-1" style={{ scrollbarWidth: 'thin' }}>
                    {responses.map((resp) => {
                      const isInternal = resp.isInternal;
                      const isAdmin = resp.authorType === 'ADMIN';
                      const isSystem = resp.authorType === 'SYSTEM';

                      let authorBadgeClass = 'bg-gray-100 text-gray-600';
                      if (isAdmin) authorBadgeClass = 'bg-green-100 text-green-700';
                      else if (!isSystem) authorBadgeClass = 'bg-blue-100 text-blue-700';

                      const authorLabel = isAdmin ? 'مدیر' : isSystem ? 'سیستم' : 'مشتری';

                      return (
                        <div
                          key={resp.id}
                          className={`rounded-lg p-3 text-sm ${
                            isInternal
                              ? 'bg-yellow-50 border border-yellow-200'
                              : isAdmin
                              ? 'bg-green-50/50 border border-green-100'
                              : isSystem
                              ? 'bg-gray-50 border border-gray-200'
                              : 'bg-blue-50/50 border border-blue-100'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className={`${authorBadgeClass} text-[10px] border-0 px-1.5 py-0.5`}>
                                {authorLabel}
                              </Badge>
                              <span className="text-xs text-gray-600 font-medium">{resp.authorName}</span>
                              {isInternal && (
                                <Badge variant="secondary" className="bg-yellow-100 text-yellow-700 text-[10px] border-0 px-1.5 py-0.5">
                                  یادداشت داخلی
                                </Badge>
                              )}
                            </div>
                            <span className="text-[10px] text-gray-400">
                              {formatPersianDate(resp.createdAt)}
                            </span>
                          </div>
                          <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">{resp.content}</p>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Add Response Form */}
              <div className="space-y-3 border-t pt-4">
                <p className="text-sm font-medium text-gray-700">افزودن پاسخ:</p>
                <Textarea
                  placeholder="متن پاسخ..."
                  value={responseContent}
                  onChange={(e) => setResponseContent(e.target.value)}
                  rows={3}
                />
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="isInternal"
                      checked={responseIsInternal}
                      onCheckedChange={(checked) => setResponseIsInternal(checked === true)}
                    />
                    <Label htmlFor="isInternal" className="text-sm text-gray-600 cursor-pointer">
                      یادداشت داخلی (مشتری نمی‌بیند)
                    </Label>
                  </div>
                  <Button
                    onClick={handleSubmitResponse}
                    disabled={submittingResponse || !responseContent.trim()}
                    className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
                    size="sm"
                  >
                    {submittingResponse ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <ArrowLeft className="w-4 h-4" />
                    )}
                    ارسال پاسخ
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
