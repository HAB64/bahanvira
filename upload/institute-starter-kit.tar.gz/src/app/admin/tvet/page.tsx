'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Building,
  Loader2,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRightLeft,
  Award,
  CalendarCheck,
  FileCheck,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface SyncItem {
  id: string;
  entityType: string;
  entityId: string;
  tvetCode: string | null;
  syncStatus: string;
  errorMessage: string | null;
  lastSyncAt: string | null;
  createdAt: string;
}

interface TVETReport {
  totalPrograms: number;
  syncedPrograms: number;
  pendingPrograms: number;
  failedPrograms: number;
  totalCertificates: number;
  syncedCertificates: number;
  pendingCertificates: number;
  failedCertificates: number;
  totalAttendance: number;
  syncedAttendance: number;
  pendingAttendance: number;
  failedAttendance: number;
  overallCompliance: number;
  lastSyncAt: string | null;
  failedSyncs: Array<{
    id: string;
    entityType: string;
    entityId: string;
    errorMessage: string;
    lastSyncAt: string | null;
  }>;
}

/* ─────────── Constants ─────────── */

const STATUS_META: Record<string, { label: string; color: string; bgColor: string; icon: React.ElementType }> = {
  SYNCED: { label: 'همگام‌شده', color: 'text-green-700', bgColor: 'bg-green-100', icon: CheckCircle2 },
  PENDING: { label: 'در انتظار', color: 'text-yellow-700', bgColor: 'bg-yellow-100', icon: Clock },
  FAILED: { label: 'خطا', color: 'text-red-700', bgColor: 'bg-red-100', icon: XCircle },
  CONFLICT: { label: 'تضاد', color: 'text-orange-700', bgColor: 'bg-orange-100', icon: AlertTriangle },
};

const ENTITY_TYPE_LABELS: Record<string, string> = {
  SKILL_PROGRAM: 'برنامه مهارتی',
  CERTIFICATE: 'مدرک',
  ATTENDANCE: 'حضورغیابی',
};

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string | null) {
  if (!dateStr) return '—';
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function TVETPage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [syncs, setSyncs] = useState<SyncItem[]>([]);
  const [report, setReport] = useState<TVETReport | null>(null);

  const [syncingPrograms, setSyncingPrograms] = useState(false);
  const [syncingCertificates, setSyncingCertificates] = useState(false);
  const [syncingAttendance, setSyncingAttendance] = useState(false);
  const [retryingId, setRetryingId] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError('');

      const [statusRes, reportRes] = await Promise.allSettled([
        fetch('/api/admin/tvet/status?report=true'),
        fetch('/api/admin/tvet/status?report=true'),
      ]);

      if (statusRes.status === 'fulfilled' && statusRes.value.ok) {
        const statusJson = await statusRes.value.json();
        setSyncs(statusJson.syncs || []);
        if (statusJson.report) {
          setReport(statusJson.report);
        }
      }
    } catch {
      setError('خطا در دریافت اطلاعات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  /* ── Sync actions ── */

  const syncPrograms = async () => {
    setSyncingPrograms(true);
    try {
      // Get all skill programs and sync each
      const programsRes = await fetch('/api/admin/tvet/status?entityType=SKILL_PROGRAM');
      if (programsRes.ok) {
        const data = await programsRes.json();
        const pendingSyncs = (data.syncs || []).filter((s: SyncItem) => s.syncStatus !== 'SYNCED');
        for (const s of pendingSyncs.slice(0, 10)) {
          await fetch('/api/admin/tvet/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ entityType: 'SKILL_PROGRAM', entityId: s.entityId }),
          });
        }
      }
      await fetchData();
    } catch { /* silent */ } finally {
      setSyncingPrograms(false);
    }
  };

  const syncCertificates = async () => {
    setSyncingCertificates(true);
    try {
      const certsRes = await fetch('/api/admin/tvet/status?entityType=CERTIFICATE');
      if (certsRes.ok) {
        const data = await certsRes.json();
        const pendingSyncs = (data.syncs || []).filter((s: SyncItem) => s.syncStatus !== 'SYNCED');
        for (const s of pendingSyncs.slice(0, 10)) {
          await fetch('/api/admin/tvet/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ entityType: 'CERTIFICATE', entityId: s.entityId }),
          });
        }
      }
      await fetchData();
    } catch { /* silent */ } finally {
      setSyncingCertificates(false);
    }
  };

  const syncAttendance = async () => {
    setSyncingAttendance(true);
    try {
      const attRes = await fetch('/api/admin/tvet/status?entityType=ATTENDANCE');
      if (attRes.ok) {
        const data = await attRes.json();
        const pendingSyncs = (data.syncs || []).filter((s: SyncItem) => s.syncStatus !== 'SYNCED');
        for (const s of pendingSyncs.slice(0, 10)) {
          await fetch('/api/admin/tvet/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ entityType: 'ATTENDANCE', entityId: s.entityId }),
          });
        }
      }
      await fetchData();
    } catch { /* silent */ } finally {
      setSyncingAttendance(false);
    }
  };

  const retrySync = async (syncId: string) => {
    setRetryingId(syncId);
    try {
      const res = await fetch(`/api/admin/tvet/retry/${syncId}`, { method: 'POST' });
      if (res.ok) {
        await fetchData();
      }
    } catch { /* silent */ } finally {
      setRetryingId(null);
    }
  };

  /* ── Computed ── */

  const compliancePct = report?.overallCompliance ?? 0;

  const programSynced = report?.syncedPrograms ?? 0;
  const programTotal = report?.totalPrograms ?? 0;
  const certSynced = report?.syncedCertificates ?? 0;
  const certTotal = report?.totalCertificates ?? 0;
  const attSynced = report?.syncedAttendance ?? 0;
  const attTotal = report?.totalAttendance ?? 0;

  const failedSyncs = useMemo(() => syncs.filter(s => s.syncStatus === 'FAILED'), [syncs]);

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
            <Building className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">اتصال سامانه فنی‌وحرفه‌ای</h1>
            <p className="text-gray-500 mt-0.5 text-sm">همگام‌سازی و صدور مدرک</p>
          </div>
        </div>
        <Button variant="outline" onClick={fetchData} className="gap-2">
          <RefreshCw className="w-4 h-4" /> بروزرسانی
        </Button>
      </div>

      {/* Compliance Score Card */}
      <Card className="border-0 shadow-sm bg-gradient-to-l from-emerald-50 to-white">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Big number */}
            <div className="text-center">
              <p className="text-6xl font-bold text-emerald-700">{toPersianNumber(compliancePct)}</p>
              <p className="text-sm text-gray-500 mt-1">درصد همگام‌سازی کل</p>
            </div>

            {/* Breakdown */}
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-4 w-full">
              {/* Programs */}
              <div className="bg-white rounded-xl p-4 border border-gray-200">
                <div className="flex items-center gap-2 mb-2">
                  <FileCheck className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs text-gray-500">برنامه‌ها</span>
                </div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-lg font-bold text-gray-800">{toPersianNumber(programSynced)} / {toPersianNumber(programTotal)}</span>
                </div>
                <Progress value={programTotal > 0 ? (programSynced / programTotal) * 100 : 0} className="h-2" />
              </div>

              {/* Certificates */}
              <div className="bg-white rounded-xl p-4 border border-gray-200">
                <div className="flex items-center gap-2 mb-2">
                  <Award className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs text-gray-500">مدارک</span>
                </div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-lg font-bold text-gray-800">{toPersianNumber(certSynced)} / {toPersianNumber(certTotal)}</span>
                </div>
                <Progress value={certTotal > 0 ? (certSynced / certTotal) * 100 : 0} className="h-2" />
              </div>

              {/* Attendance */}
              <div className="bg-white rounded-xl p-4 border border-gray-200">
                <div className="flex items-center gap-2 mb-2">
                  <CalendarCheck className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs text-gray-500">حضورغیابی</span>
                </div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-lg font-bold text-gray-800">{toPersianNumber(attSynced)} / {toPersianNumber(attTotal)}</span>
                </div>
                <Progress value={attTotal > 0 ? (attSynced / attTotal) * 100 : 0} className="h-2" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Error */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchData}>تلاش مجدد</Button>
          </CardContent>
        </Card>
      )}

      {/* Sync Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-emerald-100">
                <FileCheck className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-bold text-gray-700">همگام‌سازی برنامه‌ها</p>
                <p className="text-xs text-gray-500">ارسال اطلاعات دوره‌ها</p>
              </div>
            </div>
            <Button
              onClick={syncPrograms}
              disabled={syncingPrograms}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
            >
              {syncingPrograms ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRightLeft className="w-4 h-4" />}
              همگام‌سازی برنامه‌ها
            </Button>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-amber-100">
                <Award className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-sm font-bold text-gray-700">صدور مدرک</p>
                <p className="text-xs text-gray-500">ارسال مدارک به فنی‌وحرفه‌ای</p>
              </div>
            </div>
            <Button
              onClick={syncCertificates}
              disabled={syncingCertificates}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white gap-2"
            >
              {syncingCertificates ? <Loader2 className="w-4 h-4 animate-spin" /> : <Award className="w-4 h-4" />}
              صدور مدرک
            </Button>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-blue-100">
                <CalendarCheck className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-bold text-gray-700">ارسال حضور</p>
                <p className="text-xs text-gray-500">همگام‌سازی حضورغیابی</p>
              </div>
            </div>
            <Button
              onClick={syncAttendance}
              disabled={syncingAttendance}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2"
            >
              {syncingAttendance ? <Loader2 className="w-4 h-4 animate-spin" /> : <CalendarCheck className="w-4 h-4" />}
              ارسال حضور
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Sync Status Table */}
      <Card className="border-0 shadow-sm overflow-hidden">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-bold text-gray-700">وضعیت همگام‌سازی</CardTitle>
            <Badge variant="secondary" className="text-xs border-0 bg-gray-100">
              {toPersianNumber(syncs.length)} رکورد
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 rounded-lg" />)}
            </div>
          ) : syncs.length === 0 ? (
            <div className="text-center py-8 text-gray-400 text-sm">
              هنوز عملیات همگام‌سازی انجام نشده
            </div>
          ) : (
            <div className="overflow-x-auto max-h-96 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50/80">
                    <TableHead className="text-xs font-bold text-gray-600">نوع</TableHead>
                    <TableHead className="text-xs font-bold text-gray-600">کد فنی‌وحرفه‌ای</TableHead>
                    <TableHead className="text-xs font-bold text-gray-600">وضعیت</TableHead>
                    <TableHead className="text-xs font-bold text-gray-600">آخرین همگام‌سازی</TableHead>
                    <TableHead className="text-xs font-bold text-gray-600">اقدام</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {syncs.map((sync) => {
                    const statusMeta = STATUS_META[sync.syncStatus] || STATUS_META.PENDING;
                    const StatusIcon = statusMeta.icon;
                    return (
                      <TableRow key={sync.id} className="hover:bg-gray-50/50">
                        <TableCell className="text-sm">
                          <Badge variant="secondary" className="text-xs border-0 bg-gray-100">
                            {ENTITY_TYPE_LABELS[sync.entityType] || sync.entityType}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm font-mono text-gray-600">
                          {sync.tvetCode ? toPersianNumber(sync.tvetCode) : '—'}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            <StatusIcon className={`w-4 h-4 ${statusMeta.color}`} />
                            <Badge variant="secondary" className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
                              {statusMeta.label}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-gray-500">
                          {formatPersianDate(sync.lastSyncAt)}
                        </TableCell>
                        <TableCell>
                          {sync.syncStatus === 'FAILED' && (
                            <div className="space-y-1">
                              {sync.errorMessage && (
                                <p className="text-xs text-red-500 max-w-48 truncate">{sync.errorMessage}</p>
                              )}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 text-xs gap-1 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
                                onClick={() => retrySync(sync.id)}
                                disabled={retryingId === sync.id}
                              >
                                {retryingId === sync.id ? (
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                ) : (
                                  <RefreshCw className="w-3 h-3" />
                                )}
                                تلاش مجدد
                              </Button>
                            </div>
                          )}
                          {sync.syncStatus === 'SYNCED' && (
                            <span className="text-xs text-green-500">تکمیل‌شده</span>
                          )}
                          {sync.syncStatus === 'PENDING' && (
                            <span className="text-xs text-yellow-500">در انتظار</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* TVET Report */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-emerald-600" />
            <CardTitle className="text-sm font-bold text-gray-700">گزارش فنی‌وحرفه‌ای</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
            </div>
          ) : report ? (
            <div className="space-y-4">
              {/* Summary stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-green-50 rounded-xl p-3 border border-green-200">
                  <p className="text-xs text-green-600">همگام‌شده</p>
                  <p className="text-xl font-bold text-green-700">
                    {toPersianNumber((report.syncedPrograms + report.syncedCertificates + report.syncedAttendance))}
                  </p>
                </div>
                <div className="bg-yellow-50 rounded-xl p-3 border border-yellow-200">
                  <p className="text-xs text-yellow-600">در انتظار</p>
                  <p className="text-xl font-bold text-yellow-700">
                    {toPersianNumber((report.pendingPrograms + report.pendingCertificates + report.pendingAttendance))}
                  </p>
                </div>
                <div className="bg-red-50 rounded-xl p-3 border border-red-200">
                  <p className="text-xs text-red-600">خطا</p>
                  <p className="text-xl font-bold text-red-700">
                    {toPersianNumber((report.failedPrograms + report.failedCertificates + report.failedAttendance))}
                  </p>
                </div>
                <div className="bg-gray-50 rounded-xl p-3 border border-gray-200">
                  <p className="text-xs text-gray-500">آخرین همگام‌سازی</p>
                  <p className="text-sm font-bold text-gray-700 mt-1">
                    {formatPersianDate(report.lastSyncAt)}
                  </p>
                </div>
              </div>

              {/* Compliance checklist */}
              <div className="border rounded-xl p-4 space-y-3">
                <p className="text-sm font-bold text-gray-700">چک‌لیست انطباق</p>
                {[
                  { label: 'همه برنامه‌ها همگام‌شده', done: report.totalPrograms > 0 && report.syncedPrograms === report.totalPrograms },
                  { label: 'همه مدارک صادرشده', done: report.totalCertificates > 0 && report.syncedCertificates === report.totalCertificates },
                  { label: 'همه حضورغیابی ارسال‌شده', done: report.totalAttendance > 0 && report.syncedAttendance === report.totalAttendance },
                  { label: 'بدون رکورد خطا', done: (report.failedPrograms + report.failedCertificates + report.failedAttendance) === 0 },
                  { label: 'درصد انطباق بالای ۸۰٪', done: report.overallCompliance >= 80 },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    {item.done ? (
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-gray-300" />
                    )}
                    <span className={`text-sm ${item.done ? 'text-gray-700' : 'text-gray-400'}`}>{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-400 text-sm">
              گزارشی موجود نیست
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
