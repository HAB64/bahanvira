'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Save, Settings, Phone, MapPin, MessageCircle, Instagram, Send, Mail, Globe, Clock } from 'lucide-react';
import { toast } from 'sonner';

const settingsConfig = [
  { key: 'phone', label: 'شماره تلفن', icon: Phone, placeholder: 'شماره تلفن' },
  { key: 'address', label: 'آدرس', icon: MapPin, placeholder: 'آدرس آموزشگاه' },
  { key: 'whatsapp', label: 'شماره واتساپ', icon: MessageCircle, placeholder: 'شماره واتساپ' },
  { key: 'instagram', label: 'اینستاگرام', icon: Instagram, placeholder: 'آدرس اینستاگرام', dir: 'ltr' },
  { key: 'telegram', label: 'تلگرام', icon: Send, placeholder: 'آدرس تلگرام', dir: 'ltr' },
  { key: 'email', label: 'ایمیل', icon: Mail, placeholder: 'آدرس ایمیل', dir: 'ltr' },
  { key: 'website', label: 'وبسایت', icon: Globe, placeholder: 'آدرس وبسایت', dir: 'ltr' },
  { key: 'workHours', label: 'ساعات کاری', icon: Clock, placeholder: 'ساعات کاری' },
];

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/admin/settings');
      if (res.ok) {
        const data = await res.json();
        setSettings(data);
      }
    } catch {
      toast.error('خطا در دریافت تنظیمات');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });

      if (res.ok) {
        toast.success('تنظیمات با موفقیت ذخیره شد');
      } else {
        toast.error('خطا در ذخیره تنظیمات');
      }
    } catch {
      toast.error('خطا در ذخیره تنظیمات');
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (key: string, value: string) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">تنظیمات سایت</h1>
          <p className="text-gray-500 mt-1">مدیریت اطلاعات و تنظیمات عمومی سایت</p>
        </div>
        <Button
          onClick={handleSave}
          disabled={saving}
          className="bg-teal-600 hover:bg-teal-700 gap-2"
        >
          <Save className="h-4 w-4" />
          {saving ? 'در حال ذخیره...' : 'ذخیره تنظیمات'}
        </Button>
      </div>

      {loading ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-6 space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-10 bg-gray-100 rounded animate-pulse" />
            ))}
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Contact Info */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Phone className="h-5 w-5 text-teal-600" />
                اطلاعات تماس
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {settingsConfig
                .filter((s) => ['phone', 'address', 'whatsapp', 'email'].includes(s.key))
                .map((config) => (
                  <div key={config.key} className="grid grid-cols-1 md:grid-cols-3 gap-2 items-center">
                    <Label className="flex items-center gap-2 text-sm">
                      <config.icon className="h-4 w-4 text-gray-400" />
                      {config.label}
                    </Label>
                    <div className="md:col-span-2">
                      <Input
                        value={settings[config.key] || ''}
                        onChange={(e) => updateSetting(config.key, e.target.value)}
                        placeholder={config.placeholder}
                        dir={config.dir as 'ltr' | 'rtl'}
                      />
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>

          {/* Social Media */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Instagram className="h-5 w-5 text-teal-600" />
                شبکه‌های اجتماعی
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {settingsConfig
                .filter((s) => ['instagram', 'telegram'].includes(s.key))
                .map((config) => (
                  <div key={config.key} className="grid grid-cols-1 md:grid-cols-3 gap-2 items-center">
                    <Label className="flex items-center gap-2 text-sm">
                      <config.icon className="h-4 w-4 text-gray-400" />
                      {config.label}
                    </Label>
                    <div className="md:col-span-2">
                      <Input
                        value={settings[config.key] || ''}
                        onChange={(e) => updateSetting(config.key, e.target.value)}
                        placeholder={config.placeholder}
                        dir={config.dir as 'ltr' | 'rtl'}
                      />
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>

          {/* General */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Settings className="h-5 w-5 text-teal-600" />
                عمومی
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {settingsConfig
                .filter((s) => ['website', 'workHours'].includes(s.key))
                .map((config) => (
                  <div key={config.key} className="grid grid-cols-1 md:grid-cols-3 gap-2 items-center">
                    <Label className="flex items-center gap-2 text-sm">
                      <config.icon className="h-4 w-4 text-gray-400" />
                      {config.label}
                    </Label>
                    <div className="md:col-span-2">
                      <Input
                        value={settings[config.key] || ''}
                        onChange={(e) => updateSetting(config.key, e.target.value)}
                        placeholder={config.placeholder}
                        dir={config.dir as 'ltr' | 'rtl'}
                      />
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>

          {/* Save button at bottom */}
          <div className="flex justify-end gap-3 pb-6">
            <Button onClick={handleSave} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-2">
              <Save className="h-4 w-4" />
              {saving ? 'در حال ذخیره...' : 'ذخیره تنظیمات'}
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
