'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  ListTodo,
  Clock,
  Loader2,
  CheckCircle,
  Plus,
  Search,
  Trash2,
  Pencil,
  Check,
  AlertTriangle,
  CalendarDays,
  User,
  X,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Task {
  id: string;
  title: string;
  description: string | null;
  type: string;
  priority: string;
  status: string;
  dueDate: string | null;
  completedAt: string | null;
  assignedTo: string;
  leadId: string | null;
  karAmuzId: string | null;
  createdAt: string;
  updatedAt: string;
  lead?: { id: string; name: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string } | null;
}

interface LeadOption {
  id: string;
  name: string;
}

interface KarAmuzOption {
  id: string;
  firstName: string;
  lastName: string;
}

/* ─────────── Constants ─────────── */

const PRIORITY_META: Record<string, { label: string; color: string; bgColor: string; borderColor: string }> = {
  URGENT: { label: 'فوری', color: 'text-red-700', bgColor: 'bg-red-100', borderColor: 'border-r-red-500' },
  HIGH: { label: 'بالا', color: 'text-orange-700', bgColor: 'bg-orange-100', borderColor: 'border-r-orange-400' },
  MEDIUM: { label: 'متوسط', color: 'text-blue-700', bgColor: 'bg-blue-100', borderColor: 'border-r-blue-400' },
  LOW: { label: 'پایین', color: 'text-gray-600', bgColor: 'bg-gray-100', borderColor: 'border-r-gray-300' },
};

const TYPE_META: Record<string, { label: string; color: string; bgColor: string }> = {
  FOLLOW_UP: { label: 'پیگیری', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  CALL: { label: 'تماس', color: 'text-green-700', bgColor: 'bg-green-100' },
  MEETING: { label: 'جلسه', color: 'text-purple-700', bgColor: 'bg-purple-100' },
  DOCUMENT: { label: 'سند', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  PAYMENT_REMINDER: { label: 'یادآور پرداخت', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  OTHER: { label: 'سایر', color: 'text-gray-600', bgColor: 'bg-gray-100' },
};

const STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  IN_PROGRESS: { label: 'در انجام', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  COMPLETED: { label: 'تکمیل‌شده', color: 'text-green-700', bgColor: 'bg-green-100' },
  CANCELLED: { label: 'لغو شده', color: 'text-gray-500', bgColor: 'bg-gray-100' },
};

const PRIORITY_OPTIONS = [
  { value: 'URGENT', label: 'فوری' },
  { value: 'HIGH', label: 'بالا' },
  { value: 'MEDIUM', label: 'متوسط' },
  { value: 'LOW', label: 'پایین' },
];

const TYPE_OPTIONS = [
  { value: 'FOLLOW_UP', label: 'پیگیری' },
  { value: 'CALL', label: 'تماس' },
  { value: 'MEETING', label: 'جلسه' },
  { value: 'DOCUMENT', label: 'سند' },
  { value: 'PAYMENT_REMINDER', label: 'یادآور پرداخت' },
  { value: 'OTHER', label: 'سایر' },
];

/* ─────────── Helpers ─────────── */

function isToday(dateStr: string): boolean {
  const date = new Date(dateStr);
  const today = new Date();
  return (
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate()
  );
}

function isOverdue(dateStr: string, status: string): boolean {
  if (status === 'COMPLETED' || status === 'CANCELLED') return false;
  const due = new Date(dateStr);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);
  return due < now;
}

function formatPersianDate(dateStr: string): string {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

function formatPersianDateShort(dateStr: string): string {
  return new Intl.DateTimeFormat('fa-IR', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

function getInitials(name: string): string {
  if (!name) return '؟';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].charAt(0);
  return parts[0].charAt(0) + parts[parts.length - 1].charAt(0);
}

/* ─────────── Main Component ─────────── */

export default function TaskManagementPage() {
  /* ── State ── */
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterAssignedTo, setFilterAssignedTo] = useState<string>('');

  // Tab
  const [activeTab, setActiveTab] = useState('all');

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formType, setFormType] = useState('FOLLOW_UP');
  const [formPriority, setFormPriority] = useState('MEDIUM');
  const [formDueDate, setFormDueDate] = useState('');
  const [formAssignedTo, setFormAssignedTo] = useState('');
  const [formLeadId, setFormLeadId] = useState('');
  const [formKarAmuzId, setFormKarAmuzId] = useState('');

  // Lead/KarAmuz search
  const [leadOptions, setLeadOptions] = useState<LeadOption[]>([]);
  const [karAmuzOptions, setKarAmuzOptions] = useState<KarAmuzOption[]>([]);
  const [leadSearch, setLeadSearch] = useState('');
  const [karAmuzSearch, setKarAmuzSearch] = useState('');
  const [leadsLoading, setLeadsLoading] = useState(false);
  const [karAmuzLoading, setKarAmuzLoading] = useState(false);

  // Complete animation
  const [completingId, setCompletingId] = useState<string | null>(null);

  // Delete confirmation
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchTasks = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (filterPriority && filterPriority !== 'all') params.set('priority', filterPriority);
      if (filterType && filterType !== 'all') params.set('type', filterType);
      if (filterAssignedTo) params.set('assignedTo', filterAssignedTo);

      const res = await fetch(`/api/crm/tasks?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت وظایف');
        return;
      }

      setTasks(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterPriority, filterType, filterAssignedTo]);

  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const fetchLeads = useCallback(async (q: string) => {
    if (!q || q.length < 2) {
      setLeadOptions([]);
      return;
    }
    setLeadsLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/leads?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setLeadOptions(
          (data['داده‌ها'] || []).map((l: { id: string; name: string }) => ({
            id: l.id,
            name: l.name,
          }))
        );
      }
    } catch {
      // silent
    } finally {
      setLeadsLoading(false);
    }
  }, []);

  const fetchKarAmuz = useCallback(async (q: string) => {
    if (!q || q.length < 2) {
      setKarAmuzOptions([]);
      return;
    }
    setKarAmuzLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/karamuz?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setKarAmuzOptions(
          (data['داده‌ها'] || []).map((k: { id: string; firstName: string; lastName: string }) => ({
            id: k.id,
            firstName: k.firstName,
            lastName: k.lastName,
          }))
        );
      }
    } catch {
      // silent
    } finally {
      setKarAmuzLoading(false);
    }
  }, []);

  /* ── Computed ── */

  const stats = useMemo(() => {
    const total = tasks.length;
    const pending = tasks.filter((t) => t.status === 'PENDING').length;
    const inProgress = tasks.filter((t) => t.status === 'IN_PROGRESS').length;
    const completed = tasks.filter((t) => t.status === 'COMPLETED').length;
    return { total, pending, inProgress, completed };
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    let filtered = [...tasks];

    switch (activeTab) {
      case 'today':
        filtered = filtered.filter((t) => t.dueDate && isToday(t.dueDate));
        break;
      case 'overdue':
        filtered = filtered.filter((t) => t.dueDate && isOverdue(t.dueDate, t.status));
        break;
      case 'nodue':
        filtered = filtered.filter((t) => !t.dueDate);
        break;
    }

    // Sort: URGENT first, then by due date (earliest first), then by creation date
    const priorityOrder: Record<string, number> = { URGENT: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
    filtered.sort((a, b) => {
      // Non-completed first
      const aCompleted = a.status === 'COMPLETED' || a.status === 'CANCELLED' ? 1 : 0;
      const bCompleted = b.status === 'COMPLETED' || b.status === 'CANCELLED' ? 1 : 0;
      if (aCompleted !== bCompleted) return aCompleted - bCompleted;

      // Priority
      const pDiff = (priorityOrder[a.priority] ?? 3) - (priorityOrder[b.priority] ?? 3);
      if (pDiff !== 0) return pDiff;

      // Due date (earliest first, no due date goes last)
      if (a.dueDate && b.dueDate) {
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      }
      if (a.dueDate) return -1;
      if (b.dueDate) return 1;

      // Creation date (newest first)
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    return filtered;
  }, [tasks, activeTab]);

  // Unique assignedTo values for filter
  const assignedToOptions = useMemo(() => {
    const set = new Set<string>();
    tasks.forEach((t) => {
      if (t.assignedTo) set.add(t.assignedTo);
    });
    return Array.from(set).sort();
  }, [tasks]);

  /* ── Modal handlers ── */

  const openCreateModal = () => {
    setEditingTask(null);
    setFormTitle('');
    setFormDescription('');
    setFormType('FOLLOW_UP');
    setFormPriority('MEDIUM');
    setFormDueDate('');
    setFormAssignedTo('');
    setFormLeadId('');
    setFormKarAmuzId('');
    setLeadSearch('');
    setKarAmuzSearch('');
    setLeadOptions([]);
    setKarAmuzOptions([]);
    setModalOpen(true);
  };

  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setFormTitle(task.title);
    setFormDescription(task.description || '');
    setFormType(task.type);
    setFormPriority(task.priority);
    setFormDueDate(task.dueDate ? new Date(task.dueDate).toISOString().slice(0, 16) : '');
    setFormAssignedTo(task.assignedTo);
    setFormLeadId(task.leadId || '');
    setFormKarAmuzId(task.karAmuzId || '');
    setLeadSearch(task.lead?.name || '');
    setKarAmuzSearch(task.karAmuz ? `${task.karAmuz.firstName} ${task.karAmuz.lastName}` : '');
    setLeadOptions(task.lead ? [{ id: task.lead.id, name: task.lead.name }] : []);
    setKarAmuzOptions(
      task.karAmuz
        ? [{ id: task.karAmuz.id, firstName: task.karAmuz.firstName, lastName: task.karAmuz.lastName }]
        : []
    );
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setEditingTask(null);
  };

  const handleSubmit = async () => {
    if (!formTitle.trim()) return;

    setSubmitting(true);
    try {
      const payload: Record<string, unknown> = {
        title: formTitle.trim(),
        description: formDescription.trim() || null,
        type: formType,
        priority: formPriority,
        dueDate: formDueDate || null,
        assignedTo: formAssignedTo.trim() || null,
        leadId: formLeadId || null,
        karAmuzId: formKarAmuzId || null,
      };

      let res: Response;
      if (editingTask) {
        res = await fetch(`/api/crm/tasks/${editingTask.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch('/api/crm/tasks', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      if (res.ok) {
        closeModal();
        fetchTasks();
      }
    } catch {
      // silent
    } finally {
      setSubmitting(false);
    }
  };

  const handleComplete = async (taskId: string) => {
    setCompletingId(taskId);
    try {
      const res = await fetch(`/api/crm/tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'COMPLETED' }),
      });

      if (res.ok) {
        // Brief visual feedback
        setTimeout(() => {
          setCompletingId(null);
          fetchTasks();
        }, 600);
      } else {
        setCompletingId(null);
      }
    } catch {
      setCompletingId(null);
    }
  };

  const handleDelete = async (taskId: string) => {
    try {
      const res = await fetch(`/api/crm/tasks/${taskId}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        setDeleteConfirmId(null);
        fetchTasks();
      }
    } catch {
      // silent
    }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <ListTodo className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">مدیریت وظایف</h1>
            <p className="text-gray-500 mt-0.5 text-sm">پیگیری و مدیریت وظایف تیم</p>
          </div>
        </div>
        <Button
          onClick={openCreateModal}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          وظیفه جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کل وظایف</p>
                <p className="text-2xl font-bold mt-1 text-gray-900">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.total)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <ListTodo className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pending */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">در انتظار</p>
                <p className="text-2xl font-bold mt-1 text-orange-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.pending)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200">
                <Clock className="w-5 h-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* In Progress */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">در انجام</p>
                <p className="text-2xl font-bold mt-1 text-teal-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.inProgress)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                <Loader2 className="w-5 h-5 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Completed */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">تکمیل‌شده</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.completed)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <CheckCircle className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white border shadow-sm h-auto p-1 rounded-xl">
          <TabsTrigger value="all" className="rounded-lg text-sm px-4 py-2">
            همه
          </TabsTrigger>
          <TabsTrigger value="today" className="rounded-lg text-sm px-4 py-2">
            امروز
          </TabsTrigger>
          <TabsTrigger value="overdue" className="rounded-lg text-sm px-4 py-2">
            سررسیدشده
          </TabsTrigger>
          <TabsTrigger value="nodue" className="rounded-lg text-sm px-4 py-2">
            بدون موعد
          </TabsTrigger>
        </TabsList>

        {/* Filter Bar */}
        <div className="mt-4 flex flex-col sm:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="جستجوی عنوان یا توضیحات..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pr-10 bg-white"
            />
          </div>

          {/* Priority Filter */}
          <Select value={filterPriority} onValueChange={setFilterPriority}>
            <SelectTrigger className="w-full sm:w-40 bg-white">
              <SelectValue placeholder="اولویت" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه اولویت‌ها</SelectItem>
              {PRIORITY_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Type Filter */}
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-full sm:w-40 bg-white">
              <SelectValue placeholder="نوع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه انواع</SelectItem>
              {TYPE_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Assigned To Filter */}
          <Select value={filterAssignedTo} onValueChange={setFilterAssignedTo}>
            <SelectTrigger className="w-full sm:w-44 bg-white">
              <SelectValue placeholder="مسئول" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه مسئولین</SelectItem>
              {assignedToOptions.map((name) => (
                <SelectItem key={name} value={name}>
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Task List */}
        <TabsContent value={activeTab} className="mt-4">
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-28 rounded-xl" />
              ))}
            </div>
          ) : error ? (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-6 text-center">
                <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
                <p className="text-red-700 font-medium">{error}</p>
                <Button variant="outline" size="sm" className="mt-3" onClick={fetchTasks}>
                  تلاش مجدد
                </Button>
              </CardContent>
            </Card>
          ) : filteredTasks.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <ListTodo className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">وظیفه‌ای یافت نشد</p>
                <p className="text-gray-400 text-sm mt-1">
                  با تغییر فیلترها یا ایجاد وظیفه جدید شروع کنید
                </p>
                <Button
                  onClick={openCreateModal}
                  className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2"
                >
                  <Plus className="w-4 h-4" />
                  وظیفه جدید
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {filteredTasks.map((task) => {
                const priorityMeta = PRIORITY_META[task.priority] || PRIORITY_META.MEDIUM;
                const typeMeta = TYPE_META[task.type] || TYPE_META.OTHER;
                const statusMeta = STATUS_META[task.status] || STATUS_META.PENDING;
                const overdue = task.dueDate ? isOverdue(task.dueDate, task.status) : false;
                const isCompleted = task.status === 'COMPLETED';
                const isCancelled = task.status === 'CANCELLED';
                const isCompleting = completingId === task.id;

                return (
                  <div
                    key={task.id}
                    className={`
                      bg-white rounded-xl shadow-sm border border-r-4 ${priorityMeta.borderColor}
                      p-4 transition-all duration-200 hover:shadow-md
                      ${overdue ? 'bg-red-50/50' : ''}
                      ${isCompleting ? 'scale-[0.98] opacity-70' : ''}
                      ${isCompleted ? 'opacity-60' : ''}
                      ${isCancelled ? 'opacity-40' : ''}
                    `}
                  >
                    <div className="flex items-start gap-4">
                      {/* Right side: Main content */}
                      <div className="flex-1 min-w-0">
                        {/* Top row: Title + badges */}
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <h3
                            className={`font-bold text-gray-900 text-base ${
                              isCompleted ? 'line-through text-gray-500' : ''
                            }`}
                          >
                            {task.title}
                          </h3>

                          {/* Type badge */}
                          <Badge
                            variant="secondary"
                            className={`${typeMeta.bgColor} ${typeMeta.color} text-xs border-0`}
                          >
                            {typeMeta.label}
                          </Badge>

                          {/* Priority badge */}
                          <Badge
                            variant="secondary"
                            className={`${priorityMeta.bgColor} ${priorityMeta.color} text-xs border-0 ${
                              task.priority === 'URGENT' ? 'animate-pulse' : ''
                            }`}
                          >
                            {priorityMeta.label}
                          </Badge>

                          {/* Status badge */}
                          <Badge
                            variant="secondary"
                            className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}
                          >
                            {statusMeta.label}
                          </Badge>
                        </div>

                        {/* Description */}
                        {task.description && (
                          <p className="text-gray-500 text-sm leading-relaxed line-clamp-2 mb-2">
                            {task.description}
                          </p>
                        )}

                        {/* Meta row */}
                        <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500">
                          {/* Due date */}
                          {task.dueDate && (
                            <div className="flex items-center gap-1.5">
                              <CalendarDays className="w-3.5 h-3.5" />
                              <span>{formatPersianDateShort(task.dueDate)}</span>
                              {overdue && (
                                <span className="text-red-600 font-bold flex items-center gap-0.5">
                                  <AlertTriangle className="w-3 h-3" />
                                  سررسید شده!
                                </span>
                              )}
                            </div>
                          )}

                          {/* Assigned to */}
                          {task.assignedTo && (
                            <div className="flex items-center gap-1.5">
                              <div className="w-5 h-5 rounded-full bg-teal-100 flex items-center justify-center">
                                <span className="text-[10px] font-bold text-teal-700">
                                  {getInitials(task.assignedTo)}
                                </span>
                              </div>
                              <span>{task.assignedTo}</span>
                            </div>
                          )}

                          {/* Related lead */}
                          {task.lead && (
                            <div className="flex items-center gap-1.5">
                              <User className="w-3.5 h-3.5 text-teal-500" />
                              <a
                                href={`/admin/crm?leadId=${task.lead.id}`}
                                className="text-teal-600 hover:text-teal-800 hover:underline font-medium"
                              >
                                {task.lead.name}
                              </a>
                            </div>
                          )}

                          {/* Related karAmuz */}
                          {task.karAmuz && (
                            <div className="flex items-center gap-1.5">
                              <User className="w-3.5 h-3.5 text-purple-500" />
                              <a
                                href={`/admin/karamuz/${task.karAmuz.id}`}
                                className="text-purple-600 hover:text-purple-800 hover:underline font-medium"
                              >
                                {task.karAmuz.firstName} {task.karAmuz.lastName}
                              </a>
                            </div>
                          )}

                          {/* Created at */}
                          <span className="text-gray-400">
                            {formatPersianDate(task.createdAt)}
                          </span>
                        </div>
                      </div>

                      {/* Left side: Action buttons */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Complete button */}
                        {!isCompleted && !isCancelled && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-green-600 hover:text-green-800 hover:bg-green-50"
                            onClick={() => handleComplete(task.id)}
                            disabled={!!completingId}
                            title="تکمیل"
                          >
                            {isCompleting ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Check className="w-4 h-4" />
                            )}
                          </Button>
                        )}

                        {/* Edit button */}
                        {!isCancelled && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                            onClick={() => openEditModal(task)}
                            title="ویرایش"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                        )}

                        {/* Delete button */}
                        {deleteConfirmId === task.id ? (
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 text-red-600 hover:bg-red-50 text-xs"
                              onClick={() => handleDelete(task.id)}
                            >
                              حذف
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-gray-400 hover:bg-gray-100"
                              onClick={() => setDeleteConfirmId(null)}
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        ) : (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-400 hover:text-red-600 hover:bg-red-50"
                            onClick={() => setDeleteConfirmId(task.id)}
                            title="حذف"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Add/Edit Task Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <ListTodo className="w-5 h-5 text-teal-600" />
              {editingTask ? 'ویرایش وظیفه' : 'وظیفه جدید'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Title */}
            <div className="space-y-1.5">
              <Label htmlFor="task-title" className="text-sm font-medium">
                عنوان <span className="text-red-500">*</span>
              </Label>
              <Input
                id="task-title"
                placeholder="عنوان وظیفه..."
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
              />
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <Label htmlFor="task-desc" className="text-sm font-medium">
                توضیحات
              </Label>
              <Textarea
                id="task-desc"
                placeholder="توضیحات وظیفه..."
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                rows={3}
              />
            </div>

            {/* Type + Priority */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نوع</Label>
                <Select value={formType} onValueChange={setFormType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPE_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label className="text-sm font-medium">اولویت</Label>
                <Select value={formPriority} onValueChange={setFormPriority}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PRIORITY_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Due Date */}
            <div className="space-y-1.5">
              <Label htmlFor="task-due" className="text-sm font-medium">
                موعد
              </Label>
              <Input
                id="task-due"
                type="datetime-local"
                value={formDueDate}
                onChange={(e) => setFormDueDate(e.target.value)}
              />
            </div>

            {/* Assigned To */}
            <div className="space-y-1.5">
              <Label htmlFor="task-assignee" className="text-sm font-medium">
                مسئول
              </Label>
              <Input
                id="task-assignee"
                placeholder="نام مسئول..."
                value={formAssignedTo}
                onChange={(e) => setFormAssignedTo(e.target.value)}
              />
            </div>

            {/* Lead search & select */}
            <div className="space-y-1.5">
              <Label htmlFor="task-lead" className="text-sm font-medium">
                لید مرتبط
              </Label>
              <div className="relative">
                <Input
                  id="task-lead"
                  placeholder="جستجوی لید..."
                  value={leadSearch}
                  onChange={(e) => {
                    setLeadSearch(e.target.value);
                    fetchLeads(e.target.value);
                  }}
                />
                {leadsLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {leadOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {leadOptions.map((lead) => (
                    <button
                      key={lead.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-teal-50 transition-colors ${
                        formLeadId === lead.id ? 'bg-teal-50 text-teal-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormLeadId(lead.id);
                        setLeadSearch(lead.name);
                        setLeadOptions([]);
                      }}
                    >
                      {lead.name}
                    </button>
                  ))}
                </div>
              )}
              {formLeadId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                    {leadSearch}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5"
                    onClick={() => {
                      setFormLeadId('');
                      setLeadSearch('');
                    }}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* KarAmuz search & select */}
            <div className="space-y-1.5">
              <Label htmlFor="task-karamuz" className="text-sm font-medium">
                کارآموز مرتبط
              </Label>
              <div className="relative">
                <Input
                  id="task-karamuz"
                  placeholder="جستجوی کارآموز..."
                  value={karAmuzSearch}
                  onChange={(e) => {
                    setKarAmuzSearch(e.target.value);
                    fetchKarAmuz(e.target.value);
                  }}
                />
                {karAmuzLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {karAmuzOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {karAmuzOptions.map((ka) => (
                    <button
                      key={ka.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-purple-50 transition-colors ${
                        formKarAmuzId === ka.id ? 'bg-purple-50 text-purple-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormKarAmuzId(ka.id);
                        setKarAmuzSearch(`${ka.firstName} ${ka.lastName}`);
                        setKarAmuzOptions([]);
                      }}
                    >
                      {ka.firstName} {ka.lastName}
                    </button>
                  ))}
                </div>
              )}
              {formKarAmuzId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-purple-50 text-purple-700 text-xs">
                    {karAmuzSearch}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5"
                    onClick={() => {
                      setFormKarAmuzId('');
                      setKarAmuzSearch('');
                    }}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={closeModal}
              className="gap-1"
            >
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!formTitle.trim() || submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editingTask ? 'ذخیره تغییرات' : 'ایجاد وظیفه'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
