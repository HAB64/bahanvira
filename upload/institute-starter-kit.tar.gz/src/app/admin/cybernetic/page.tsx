'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Activity, Brain, Gauge, Rocket, Shield, TrendingUp,
  AlertTriangle, CheckCircle2, XCircle, ChevronDown, ChevronUp,
  RefreshCw, Zap, Target, Users, BarChart3, Cpu, Eye,
  Layers, ArrowUpRight, ArrowDownRight, Minus, Lightbulb,
  Clock, Globe, Database, Code2, Boxes, Workflow,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from '@/components/ui/accordion';

// ─── Types ──────────────────────────────────────────────────────

interface WebVitalMetric {
  name: string; value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  label_fa: string; description: string; target: string;
}

interface CognitiveLoadAnalysis {
  intrinsicLoad: number; extraneousLoad: number; germaneLoad: number;
  overallScore: number;
  rating: 'optimal' | 'acceptable' | 'heavy' | 'critical';
  recommendations: string[];
}

interface ArchitectureHealth {
  codeModularity: number; apiEfficiency: number;
  dbQueryOptimization: number; componentReusability: number;
  overallHealth: number;
  rating: 'excellent' | 'good' | 'fair' | 'poor';
}

interface AgilityScore {
  pageWeight: number; renderPerformance: number;
  cognitiveEfficiency: number; conversionOptimization: number;
  overallAgility: number;
  rating: 'agile' | 'moderate' | 'heavy' | 'bloated';
}

interface SystemStats {
  totalLeads: number; totalKarAmuz: number; totalEnrollments: number;
  totalCampaigns: number; totalAutomationRules: number; totalMessageLogs: number;
  activeDrips: number; conversionRate: number; avgLeadScore: number;
}

interface SystemAnalysis {
  webVitals: WebVitalMetric[];
  cognitiveLoad: CognitiveLoadAnalysis;
  architectureHealth: ArchitectureHealth;
  agilityScore: AgilityScore;
  systemStats: SystemStats;
  roadmapProgress: { phase1: number; phase2: number; phase3: number; phase4: number };
}

// ─── Helper Functions ───────────────────────────────────────────

function getRatingColor(rating: string): string {
  switch (rating) {
    case 'good': case 'optimal': case 'excellent': case 'agile': return 'text-emerald-600';
    case 'needs-improvement': case 'acceptable': case 'good': case 'moderate': return 'text-amber-600';
    case 'poor': case 'heavy': case 'fair': return 'text-orange-600';
    case 'critical': case 'bloated': return 'text-red-600';
    default: return 'text-gray-600';
  }
}

function getRatingBg(rating: string): string {
  switch (rating) {
    case 'good': case 'optimal': case 'excellent': case 'agile': return 'bg-emerald-50 border-emerald-200';
    case 'needs-improvement': case 'acceptable': case 'good': case 'moderate': return 'bg-amber-50 border-amber-200';
    case 'poor': case 'heavy': case 'fair': return 'bg-orange-50 border-orange-200';
    case 'critical': case 'bloated': return 'bg-red-50 border-red-200';
    default: return 'bg-gray-50 border-gray-200';
  }
}

function getRatingBadge(rating: string): string {
  switch (rating) {
    case 'good': case 'optimal': case 'excellent': case 'agile': return 'عالی';
    case 'needs-improvement': case 'acceptable': case 'good': case 'moderate': return 'قابل قبول';
    case 'poor': case 'heavy': case 'fair': return 'نیاز به بهبود';
    case 'critical': case 'bloated': return 'بحرانی';
    default: return 'نامشخص';
  }
}

function getScoreIcon(score: number) {
  if (score >= 75) return <CheckCircle2 className="h-5 w-5 text-emerald-500" />;
  if (score >= 50) return <Minus className="h-5 w-5 text-amber-500" />;
  return <AlertTriangle className="h-5 w-5 text-orange-500" />;
}

function getProgressBarColor(score: number): string {
  if (score >= 75) return 'bg-emerald-500';
  if (score >= 50) return 'bg-amber-500';
  if (score >= 30) return 'bg-orange-500';
  return 'bg-red-500';
}

// ─── Sub-Components ─────────────────────────────────────────────

function WebVitalsCard({ vitals }: { vitals: WebVitalMetric[] }) {
  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-blue-50">
            <Gauge className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <CardTitle className="text-lg">Core Web Vitals</CardTitle>
            <CardDescription>شاخص‌های عملکرد حرفه‌ای Google</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {vitals.map((v) => (
            <div key={v.name} className={`p-3 rounded-lg border ${getRatingBg(v.rating)}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-mono font-bold text-gray-700">{v.name}</span>
                <span className={`text-xs font-bold ${getRatingColor(v.rating)}`}>
                  {getRatingBadge(v.rating)}
                </span>
              </div>
              <div className={`text-2xl font-bold ${getRatingColor(v.rating)}`}>
                {v.value}
                <span className="text-xs font-normal text-gray-500 mr-1">
                  {v.name === 'LCP' || v.name === 'FCP' || v.name === 'TTFB' ? 'ثانیه' :
                   v.name === 'CLS' ? '' : 'ms'}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">{v.label_fa}</p>
              <p className="text-xs text-gray-400">هدف: {v.target}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function CognitiveLoadCard({ data }: { data: CognitiveLoadAnalysis }) {
  const bars = [
    { label: 'بار ذاتی (Intrinsic)', value: data.intrinsicLoad, color: 'bg-blue-500', desc: 'سختی ذاتی موضوعات' },
    { label: 'بار اضافی (Extraneous)', value: data.extraneousLoad, color: 'bg-red-500', desc: 'عوامل حواس‌پرتی و تکرار' },
    { label: 'بار مفید (Germane)', value: data.germaneLoad, color: 'bg-emerald-500', desc: 'محتوای ارزشمند یادگیری' },
  ];

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-purple-50">
            <Brain className="h-5 w-5 text-purple-600" />
          </div>
          <div>
            <CardTitle className="text-lg">بار شناختی (Cognitive Load)</CardTitle>
            <CardDescription>تحلیل سه‌گانه بار ادراکی کاربر</CardDescription>
          </div>
          <Badge variant="outline" className={`mr-auto ${getRatingColor(data.rating)}`}>
            امتیاز: {data.overallScore}/۱۰۰ — {getRatingBadge(data.rating)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {bars.map((bar) => (
            <div key={bar.label}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-gray-700">{bar.label}</span>
                <span className="text-sm font-bold text-gray-900">{bar.value}%</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-1000 ${bar.color}`}
                  style={{ width: `${bar.value}%` }}
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">{bar.desc}</p>
            </div>
          ))}

          <Separator className="my-3" />

          <div>
            <h4 className="text-sm font-bold text-gray-700 mb-2 flex items-center gap-1">
              <Lightbulb className="h-4 w-4 text-amber-500" />
              پیشنهادات بهبود
            </h4>
            <ul className="space-y-1.5">
              {data.recommendations.map((rec, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-gray-600">
                  <span className="text-amber-500 mt-0.5">●</span>
                  {rec}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ArchitectureHealthCard({ data }: { data: ArchitectureHealth }) {
  const metrics = [
    { label: 'ماژولاریتی کد', value: data.codeModularity, icon: Code2, desc: 'ساختار ماژولار و قابل نگهداری' },
    { label: 'بهره‌وری API', value: data.apiEfficiency, icon: Workflow, desc: 'سرعت و کشینگ endpoint ها' },
    { label: 'بهینه‌سازی DB', value: data.dbQueryOptimization, icon: Database, desc: 'ایندکس‌ها و N+1 query ها' },
    { label: 'قابلیت استفاده مجدد', value: data.componentReusability, icon: Boxes, desc: 'استفاده مجدد از کامپوننت‌ها' },
  ];

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-teal-50">
            <Shield className="h-5 w-5 text-teal-600" />
          </div>
          <div>
            <CardTitle className="text-lg">سلامت معماری سیستم</CardTitle>
            <CardDescription>تحلیل ساختاری و فنی زیرساخت</CardDescription>
          </div>
          <Badge variant="outline" className={`mr-auto ${getRatingColor(data.rating)}`}>
            {data.overallHealth}/۱۰۰ — {getRatingBadge(data.rating)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3">
          {metrics.map((m) => (
            <div key={m.label} className="p-3 rounded-lg bg-gray-50 border border-gray-100">
              <div className="flex items-center gap-2 mb-2">
                <m.icon className="h-4 w-4 text-gray-500" />
                <span className="text-xs font-medium text-gray-600">{m.label}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold text-gray-900">{m.value}</span>
                <span className="text-xs text-gray-400">/۱۰۰</span>
                {getScoreIcon(m.value)}
              </div>
              <Progress value={m.value} className="h-1.5 mt-2" />
              <p className="text-xs text-gray-400 mt-1">{m.desc}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function AgilityScoreCard({ data }: { data: AgilityScore }) {
  const agilityMetrics = [
    { label: 'وزن صفحه', value: data.pageWeight, icon: Globe, desc: 'سرعت بارگذاری و حجم منابع' },
    { label: 'عملکرد رندر', value: data.renderPerformance, icon: Cpu, desc: 'FCP و زمان مسدودسازی' },
    { label: 'بهره‌وری شناختی', value: data.cognitiveEfficiency, icon: Brain, desc: 'بار ادراکی و تمرکز کاربر' },
    { label: 'بهینه‌سازی تبدیل', value: data.conversionOptimization, icon: Target, desc: 'CTA و فرم‌ها و مسیر کاربر' },
  ];

  const size = 140;
  const strokeWidth = 12;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (data.overallAgility / 100) * circumference;

  const gaugeColor = data.overallAgility >= 75 ? '#10b981' :
    data.overallAgility >= 55 ? '#f59e0b' :
    data.overallAgility >= 35 ? '#f97316' : '#ef4444';

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-emerald-50">
            <Zap className="h-5 w-5 text-emerald-600" />
          </div>
          <div>
            <CardTitle className="text-lg">امتیاز چابکی سیستم</CardTitle>
            <CardDescription>شاخص ترکیبی سنگینی vs چابکی</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col lg:flex-row items-center gap-6">
          {/* Gauge */}
          <div className="relative flex-shrink-0">
            <svg width={size} height={size} className="-rotate-90">
              <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke="#e5e7eb" strokeWidth={strokeWidth} />
              <circle
                cx={size/2} cy={size/2} r={radius} fill="none"
                stroke={gaugeColor} strokeWidth={strokeWidth}
                strokeDasharray={circumference} strokeDashoffset={offset}
                strokeLinecap="round" className="transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold" style={{ color: gaugeColor }}>
                {data.overallAgility}
              </span>
              <span className="text-xs text-gray-400">از ۱۰۰</span>
            </div>
          </div>

          {/* Metrics */}
          <div className="flex-1 grid grid-cols-2 gap-2 w-full">
            {agilityMetrics.map((m) => (
              <div key={m.label} className="p-2.5 rounded-lg bg-gray-50 border border-gray-100">
                <div className="flex items-center gap-1.5 mb-1">
                  <m.icon className="h-3.5 w-3.5 text-gray-400" />
                  <span className="text-xs font-medium text-gray-600">{m.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-bold text-gray-800">{m.value}</span>
                  <Progress value={m.value} className="h-1.5 flex-1" />
                </div>
                <p className="text-xs text-gray-400 mt-0.5">{m.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Rating Badge */}
        <div className={`mt-4 p-3 rounded-lg border text-center ${getRatingBg(data.rating)}`}>
          <span className={`text-lg font-bold ${getRatingColor(data.rating)}`}>
            {data.rating === 'agile' ? 'سیستم چابک' :
             data.rating === 'moderate' ? 'سیستم متوسط' :
             data.rating === 'heavy' ? 'سیستم سنگین' : 'سیستم متورم'}
          </span>
          <p className="text-xs text-gray-500 mt-1">
            {data.rating === 'agile' ? 'سیستم شما بهینه و سریع عمل می‌کند. تمرکز روی حفظ وضعیت فعلی.' :
             data.rating === 'moderate' ? 'سیستم عملکرد قابل قبولی دارد اما پتانسیل بهبود وجود دارد.' :
             data.rating === 'heavy' ? 'سیستم سنگین شده و نیاز به مهندسی مجدد دارد.' :
             'سیستم به‌شدت سنگین است و نیاز به بازطراحی اساسی دارد.'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

function RoadmapCard({ progress }: { progress: { phase1: number; phase2: number; phase3: number; phase4: number } }) {
  // تسک‌ها بر اساس درصد واقعی محاسبه می‌شوند (نه آستانه‌های هاردکد)
  // هر تسک وقتی انجام شده که سهم آن در درصد فاز محاسبه شده باشد
  const phases = [
    {
      key: 'phase1', label: 'فاز ۱: مهندسی مجدد صفحه اصلی', progress: progress.phase1,
      icon: Eye, color: 'bg-blue-500',
      tasks: [
        { text: 'بازطراحی Hero با یک پیام واضح', done: progress.phase1 >= 25 },
        { text: 'دو CTA مشخص (یافتن مسیر + مشاهده دوره‌ها)', done: progress.phase1 >= 45 },
        { text: 'فرم مشاوره کوتاه (نام + شماره)', done: progress.phase1 >= 70 },
        { text: 'خلاصه‌سازی Social Proof (ادغام سکشن‌ها)', done: progress.phase1 >= 85 },
        { text: 'نمایش فقط خوشه‌های اصلی (۴ کارت)', done: progress.phase1 >= 95 },
      ],
    },
    {
      key: 'phase2', label: 'فاز ۲: سیستم هدایت تعاملی', progress: progress.phase2,
      icon: Layers, color: 'bg-purple-500',
      tasks: [
        { text: 'کوییز شرطی ۳-۵ مرحله‌ای', done: progress.phase2 >= 25 },
        { text: 'پیشنهاد خوشه بر اساس کوییز', done: progress.phase2 >= 45 },
        { text: 'Landing Page اختصاصی هر خوشه', done: progress.phase2 >= 65 },
        { text: 'مسیر پیشنهادی تعاملی', done: progress.phase2 >= 80 },
        { text: 'اتصال به lead capture', done: progress.phase2 >= 90 },
      ],
    },
    {
      key: 'phase3', label: 'فاز ۳: مشاوره هوشمند AI', progress: progress.phase3,
      icon: Brain, color: 'bg-amber-500',
      tasks: [
        { text: 'مینی‌ایجنت مشاوره (local-first)', done: progress.phase3 >= 25 },
        { text: 'اتصال به پایگاه داده دوره‌ها', done: progress.phase3 >= 45 },
        { text: 'پاسخ سؤالات متداول (۱۵+ الگو)', done: progress.phase3 >= 60 },
        { text: 'اتصال به CRM (استخراج خودکار لید)', done: progress.phase3 >= 80 },
        { text: 'تحلیل داده رفتاری (تزریق به چت‌بات)', done: progress.phase3 >= 95 },
      ],
    },
    {
      key: 'phase4', label: 'فاز ۴: سیستم سایبرنتیک آموزشی', progress: progress.phase4,
      icon: Rocket, color: 'bg-emerald-500',
      tasks: [
        { text: 'یادگیری از رفتار کاربران', done: progress.phase4 >= 20 },
        { text: 'بهینه‌سازی مسیرها بر اساس داده', done: progress.phase4 >= 30 },
        { text: 'شخصی‌سازی خودکار پیشنهادها', done: progress.phase4 >= 45 },
        { text: 'تنظیم محتوا بر اساس داده واقعی', done: progress.phase4 >= 65 },
        { text: 'سیستم خودتنظیم‌گر کامل (Effector ها)', done: progress.phase4 >= 80 },
      ],
    },
  ];

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-indigo-50">
            <Rocket className="h-5 w-5 text-indigo-600" />
          </div>
          <div>
            <CardTitle className="text-lg">نقشه راه ارتقا: سایت → سیستم سایبرنتیک</CardTitle>
            <CardDescription>پیشرفت هر فاز از تبدیل سیستم</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="multiple" defaultValue={['phase1', 'phase2', 'phase3', 'phase4']} className="space-y-2">
          {phases.map((phase) => (
            <AccordionItem key={phase.key} value={phase.key} className="border rounded-lg px-4">
              <AccordionTrigger className="hover:no-underline py-3">
                <div className="flex items-center gap-3 flex-1">
                  <div className={`p-1.5 rounded ${phase.color} text-white`}>
                    <phase.icon className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium text-gray-700 text-right">{phase.label}</span>
                  <div className="mr-auto flex items-center gap-2">
                    <Progress value={phase.progress} className="w-24 h-2" />
                    <span className="text-sm font-bold text-gray-600">{phase.progress}%</span>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2 pt-2 pb-1">
                  {phase.tasks.map((task, i) => (
                    <div key={i} className="flex items-center gap-2">
                      {task.done ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                      ) : (
                        <div className="h-4 w-4 rounded-full border-2 border-gray-300 flex-shrink-0" />
                      )}
                      <span className={`text-sm ${task.done ? 'text-gray-500 line-through' : 'text-gray-700'}`}>
                        {task.text}
                      </span>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}

function SystemStatsCard({ stats }: { stats: SystemStats }) {
  const items = [
    { label: 'کل لیدها', value: stats.totalLeads, icon: Users, color: 'text-blue-600 bg-blue-50' },
    { label: 'کارآموزان', value: stats.totalKarAmuz, icon: GraduationCap, color: 'text-purple-600 bg-purple-50' },
    { label: 'ثبت‌نام‌ها', value: stats.totalEnrollments, icon: BookOpen, color: 'text-teal-600 bg-teal-50' },
    { label: 'نرخ تبدیل', value: `${stats.conversionRate}%`, icon: TrendingUp, color: 'text-emerald-600 bg-emerald-50' },
    { label: 'اتوماسیون‌ها', value: stats.totalAutomationRules, icon: Zap, color: 'text-amber-600 bg-amber-50' },
    { label: 'پیام‌ها', value: stats.totalMessageLogs, icon: Activity, color: 'text-rose-600 bg-rose-50' },
    { label: 'Drip فعال', value: stats.activeDrips, icon: Clock, color: 'text-indigo-600 bg-indigo-50' },
    { label: 'امتیاز لید', value: stats.avgLeadScore, icon: BarChart3, color: 'text-cyan-600 bg-cyan-50' },
  ];

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-rose-50">
            <BarChart3 className="h-5 w-5 text-rose-600" />
          </div>
          <div>
            <CardTitle className="text-lg">آمار سیستم</CardTitle>
            <CardDescription>خلاصه وضعیت فعلی CRM و اتوماسیون</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {items.map((item) => (
            <div key={item.label} className="p-3 rounded-lg bg-gray-50 border border-gray-100 text-center">
              <div className={`inline-flex p-2 rounded-lg ${item.color} mb-2`}>
                <item.icon className="h-4 w-4" />
              </div>
              <div className="text-xl font-bold text-gray-900">{item.value}</div>
              <div className="text-xs text-gray-500">{item.label}</div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ─── Main Page ──────────────────────────────────────────────────

import { GraduationCap, BookOpen } from 'lucide-react';

export default function CyberneticDashboard() {
  const [data, setData] = useState<SystemAnalysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchAnalysis = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/admin/system-analysis');
      if (res.status === 401) {
        setError('دسترسی غیرمجاز. لطفاً وارد شوید.');
        return;
      }
      if (!res.ok) {
        setError('خطا در دریافت تحلیل سیستم');
        return;
      }
      const json = await res.json();
      setData(json);
      setLastUpdated(new Date());
    } catch (err) {
      setError('خطا در اتصال به سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAnalysis(); }, [fetchAnalysis]);

  if (loading && !data) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-teal-600 border-t-transparent" />
        <p className="text-gray-500">در حال تحلیل سیستم...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <AlertTriangle className="h-10 w-10 text-red-500" />
        <p className="text-red-600">{error}</p>
        <Button onClick={fetchAnalysis} variant="outline">تلاش مجدد</Button>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Cpu className="h-7 w-7 text-teal-600" />
            داشبورد سایبرنتیک
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            تحلیل جامع سنگینی و چابکی سیستم بهان رایانه
          </p>
        </div>
        <div className="flex items-center gap-3">
          {lastUpdated && (
            <span className="text-xs text-gray-400">
              آخرین بروزرسانی: {lastUpdated.toLocaleTimeString('fa-IR')}
            </span>
          )}
          <Button onClick={fetchAnalysis} variant="outline" size="sm" disabled={loading}>
            <RefreshCw className={`h-4 w-4 ml-1 ${loading ? 'animate-spin' : ''}`} />
            بروزرسانی
          </Button>
        </div>
      </div>

      {/* Top Stats */}
      <SystemStatsCard stats={data.systemStats} />

      {/* Agility Score — Hero */}
      <AgilityScoreCard data={data.agilityScore} />

      {/* Two-column grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <WebVitalsCard vitals={data.webVitals} />
        <CognitiveLoadCard data={data.cognitiveLoad} />
      </div>

      {/* Architecture Health */}
      <ArchitectureHealthCard data={data.architectureHealth} />

      {/* Roadmap */}
      <RoadmapCard progress={data.roadmapProgress} />

      {/* Footer Analysis Summary */}
      <Card className="border-0 shadow-lg bg-gradient-to-l from-teal-50 to-emerald-50">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Lightbulb className="h-6 w-6 text-teal-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-gray-900 mb-2">تحلیل نهایی مدیریتی</h3>
              <p className="text-sm text-gray-700 leading-7">
                بهان رایانه از نظر فلسفه آموزشی و زیرساخت فنی، چند پله جلوتر از بازار است.
                زیرساخت Next.js مدرن، Prisma ORM قدرتمند، و معماری ماژولار CRM نشان‌دهنده
                سرمایه‌گذاری هوشمندانه روی تکنولوژی است. اما صفحه اصلی فعلی، این برتری را
                به‌صورت چابک و متمرکز منتقل نمی‌کند. بار شناختی اضافی (Extraneous Load)
                بالاتر از حد بهینه است و باعث خستگی کاربر قبل از تصمیم‌گیری می‌شود.
              </p>
              <p className="text-sm text-gray-700 leading-7 mt-2">
                با اجرای نقشه راه ۴ فازه، سیستم از یک «سایت آموزشی خوب» به یک
                <strong className="text-teal-700"> سیستم سایبرنتیک هدایت شغلی </strong>
                تبدیل می‌شود که از رفتار کاربران یاد می‌گیرد، مسیرها را بهینه می‌کند،
                و پیشنهادها را شخصی‌سازی می‌کند.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
