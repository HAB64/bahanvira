'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ScrollArea,
} from '@/components/ui/scroll-area';
import {
  UserPlus,
  Search,
  Loader2,
  AlertTriangle,
  Eye,
  Copy,
  QrCode,
  Ban,
  CheckCircle2,
  DollarSign,
  Users,
  TrendingUp,
  CreditCard,
  Settings,
  Plus,
  Trash2,
  Edit,
  ChevronDown,
  Wallet,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';
import { siteConfig } from '@/config/site';

/* ─────────── Types ─────────── */

interface Referrer {
  id: string;
  code: string;
  firstName: string;
  lastName: string;
  phone: string;
  email: string | null;
  avatarUrl: string | null;
  isActive: boolean;
  status: string;
  baseCommissionPct: number;
  commissionTiers: { minEnrollments: number; maxEnrollments?: number; pct: number; name?: string }[] | null;
  totalReferrals: number;
  totalEnrollments: number;
  totalRevenue: number;
  totalCommission: number;
  totalPaidCommission: number;
  bankName: string | null;
  bankAccountNo: string | null;
  bankCardNo: string | null;
  bankShaba: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  _count?: { referrals: number; commissions: number; payouts: number };
  // Detail fields
  referrals?: Referral[];
  commissions?: Commission[];
  payouts?: Payout[];
}

interface Referral {
  id: string;
  refName: string;
  refPhone: string;
  refEmail: string | null;
  source: string;
  status: string;
  enrolledCourse: string | null;
  commissionPct: number | null;
  commissionAmount: number | null;
  commissionStatus: string;
  createdAt: string;
}

interface Commission {
  id: string;
  referrerId: string;
  referralId: string | null;
  amount: number;
  commissionPct: number;
  commissionAmount: number;
  tierLevel: number;
  tierName: string;
  status: string;
  approvedAt: string | null;
  paidAt: string | null;
  description: string | null;
  createdAt: string;
  referrer?: { id: string; firstName: string; lastName: string; code: string };
  referral?: { id: string; refName: string; refPhone: string };
}

interface Payout {
  id: string;
  referrerId: string;
  amount: number;
  method: string;
  bankName: string | null;
  bankAccountNo: string | null;
  bankShaba: string | null;
  trackingNo: string | null;
  periodStart: string;
  periodEnd: string;
  status: string;
  completedAt: string | null;
  notes: string | null;
  createdAt: string;
  referrer?: { id: string; firstName: string; lastName: string; code: string; bankName: string; bankAccountNo: string; bankShaba: string };
}

interface CommissionTier {
  minEnrollments: number;
  maxEnrollments?: number;
  pct: number;
  name: string;
}

/* ─────────── Constants ─────────── */

const STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  ACTIVE: { label: 'فعال', color: 'text-green-700', bgColor: 'bg-green-100' },
  SUSPENDED: { label: 'معلق', color: 'text-red-700', bgColor: 'bg-red-100' },
  INACTIVE: { label: 'غیرفعال', color: 'text-gray-700', bgColor: 'bg-gray-100' },
};

const COMMISSION_STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-yellow-700', bgColor: 'bg-yellow-100' },
  APPROVED: { label: 'تأیید شده', color: 'text-green-700', bgColor: 'bg-green-100' },
  PAID: { label: 'پرداخت شده', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  CANCELLED: { label: 'لغو شده', color: 'text-red-700', bgColor: 'bg-red-100' },
};

const PAYOUT_STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  COMPLETED: { label: 'تکمیل شده', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  CANCELLED: { label: 'لغو شده', color: 'text-red-700', bgColor: 'bg-red-100' },
};

const TIER_BADGES: Record<string, { label: string; color: string; bgColor: string }> = {
  '1': { label: 'سطح ۱ - پایه', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  '2': { label: 'سطح ۲ - برنزی', color: 'text-amber-700', bgColor: 'bg-amber-100' },
  '3': { label: 'سطح ۳ - نقره‌ای', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  '4': { label: 'سطح ۴ - طلایی', color: 'text-yellow-700', bgColor: 'bg-yellow-100' },
};

const DEFAULT_TIERS: CommissionTier[] = [
  { minEnrollments: 1, maxEnrollments: 5, pct: 10, name: 'پایه' },
  { minEnrollments: 6, maxEnrollments: 15, pct: 12, name: 'برنزی' },
  { minEnrollments: 16, maxEnrollments: 30, pct: 15, name: 'نقره‌ای' },
  { minEnrollments: 31, pct: 20, name: 'طلایی' },
];

/* ─────────── Helpers ─────────── */

function formatToman(amount: number) {
  const toman = Math.round(amount / 10);
  return toPersianNumber(toman.toLocaleString('en-US')) + ' تومان';
}

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function getReferralLink(code: string) {
  return `${siteConfig.url.base}/ref?code=${code}`;
}

function getTierBadge(level: number) {
  return TIER_BADGES[String(level)] || TIER_BADGES['1'];
}

/* ─────────── Main Component ─────────── */

export default function ReferrersPage() {
  /* ── State ── */
  const [referrers, setReferrers] = useState<Referrer[]>([]);
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState({ activeCount: 0, totalCount: 0, monthCommissionPaid: 0, monthReferrals: 0 });

  // Filters
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [commissionFilterStatus, setCommissionFilterStatus] = useState<string>('all');

  // Active tab
  const [activeTab, setActiveTab] = useState('referrers');

  // Add dialog
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Add form
  const [formFirstName, setFormFirstName] = useState('');
  const [formLastName, setFormLastName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formBankName, setFormBankName] = useState('');
  const [formBankAccountNo, setFormBankAccountNo] = useState('');
  const [formBankCardNo, setFormBankCardNo] = useState('');
  const [formBankShaba, setFormBankShaba] = useState('');
  const [formNotes, setFormNotes] = useState('');

  // Edit dialog
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editReferrer, setEditReferrer] = useState<Referrer | null>(null);
  const [editSubmitting, setEditSubmitting] = useState(false);

  // Detail dialog
  const [detailReferrer, setDetailReferrer] = useState<Referrer | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);

  // Payout dialog
  const [payoutDialogOpen, setPayoutDialogOpen] = useState(false);
  const [payoutSubmitting, setPayoutSubmitting] = useState(false);
  const [payoutReferrerId, setPayoutReferrerId] = useState('');
  const [payoutPeriodStart, setPayoutPeriodStart] = useState('');
  const [payoutPeriodEnd, setPayoutPeriodEnd] = useState('');

  // Settings - commission tiers
  const [settingsTiers, setSettingsTiers] = useState<CommissionTier[]>(DEFAULT_TIERS);
  const [settingsSaving, setSettingsSaving] = useState(false);

  // Toast
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [qrReferrer, setQrReferrer] = useState<Referrer | null>(null);
  const [qrDialogOpen, setQrDialogOpen] = useState(false);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  /* ── Data fetching ── */

  const fetchReferrers = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (search) params.set('search', search);
      if (filterStatus && filterStatus !== 'all') params.set('status', filterStatus);

      const res = await fetch(`/api/crm/referrers?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || data.error || 'خطا در دریافت معرف‌ها');
        return;
      }

      const referrerList = data['داده‌ها'] || data.data || [];
      setReferrers(referrerList);
      // Compute stats from referrer list since API may not return stats
      const activeList = referrerList.filter((r: Referrer) => r.status === 'ACTIVE');
      setStats({
        activeCount: activeList.length,
        totalCount: referrerList.length,
        monthCommissionPaid: referrerList.reduce((sum: number, r: Referrer) => sum + (r.totalPaidCommission || 0), 0),
        monthReferrals: referrerList.reduce((sum: number, r: Referrer) => sum + (r.totalReferrals || r._count?.referrals || 0), 0),
      });
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterStatus]);

  const fetchCommissions = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (commissionFilterStatus && commissionFilterStatus !== 'all') params.set('status', commissionFilterStatus);

      const res = await fetch(`/api/crm/referrers/commissions?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setCommissions(data['داده‌ها'] || data.data || []);
      }
    } catch { /* silent */ }
  }, [commissionFilterStatus]);

  const fetchPayouts = useCallback(async () => {
    try {
      const res = await fetch('/api/crm/referrers/payouts?limit=100');
      const data = await res.json();
      if (res.ok) {
        setPayouts(data['داده‌ها'] || data.data || []);
      }
    } catch { /* silent */ }
  }, []);

  useEffect(() => {
    fetchReferrers();
  }, [fetchReferrers]);

  useEffect(() => {
    if (activeTab === 'commissions') fetchCommissions();
    if (activeTab === 'payouts') fetchPayouts();
  }, [activeTab, fetchCommissions, fetchPayouts]);

  /* ── Computed ── */

  const activeReferrers = useMemo(() => stats.activeCount || referrers.filter(r => r.status === 'ACTIVE').length, [stats, referrers]);

  /* ── Modal handlers ── */

  const openAddDialog = () => {
    setFormFirstName('');
    setFormLastName('');
    setFormPhone('');
    setFormEmail('');
    setFormBankName('');
    setFormBankAccountNo('');
    setFormBankCardNo('');
    setFormBankShaba('');
    setFormNotes('');
    setAddDialogOpen(true);
  };

  const handleAddSubmit = async () => {
    if (!formFirstName.trim() || !formLastName.trim() || !formPhone.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/referrers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName: formFirstName,
          lastName: formLastName,
          phone: formPhone,
          email: formEmail,
          bankName: formBankName,
          bankAccountNo: formBankAccountNo,
          bankCardNo: formBankCardNo,
          bankShaba: formBankShaba,
          notes: formNotes,
        }),
      });
      if (res.ok) {
        setAddDialogOpen(false);
        fetchReferrers();
        showToast('معرف با موفقیت اضافه شد');
      } else {
        const data = await res.json();
        showToast(data['خطا'] || data.error || 'خطا در ثبت معرف', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally { setSubmitting(false); }
  };

  const openEditDialog = (referrer: Referrer) => {
    setEditReferrer(referrer);
    setFormFirstName(referrer.firstName);
    setFormLastName(referrer.lastName);
    setFormPhone(referrer.phone);
    setFormEmail(referrer.email || '');
    setFormBankName(referrer.bankName || '');
    setFormBankAccountNo(referrer.bankAccountNo || '');
    setFormBankCardNo(referrer.bankCardNo || '');
    setFormBankShaba(referrer.bankShaba || '');
    setFormNotes(referrer.notes || '');
    setEditDialogOpen(true);
  };

  const handleEditSubmit = async () => {
    if (!editReferrer) return;
    setEditSubmitting(true);
    try {
      const res = await fetch(`/api/crm/referrers/${editReferrer.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName: formFirstName,
          lastName: formLastName,
          phone: formPhone,
          email: formEmail,
          bankName: formBankName,
          bankAccountNo: formBankAccountNo,
          bankCardNo: formBankCardNo,
          bankShaba: formBankShaba,
          notes: formNotes,
        }),
      });
      if (res.ok) {
        setEditDialogOpen(false);
        fetchReferrers();
        showToast('معرف با موفقیت ویرایش شد');
      } else {
        showToast('خطا در ویرایش معرف', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally { setEditSubmitting(false); }
  };

  const openDetail = async (referrer: Referrer) => {
    setDetailReferrer(referrer);
    setDetailDialogOpen(true);
    setDetailLoading(true);

    try {
      const res = await fetch(`/api/crm/referrers/${referrer.id}`);
      const data = await res.json();
      if (res.ok) {
        setDetailReferrer((data['داده'] || data.data) as Referrer);
      }
    } catch { /* silent */ } finally { setDetailLoading(false); }
  };

  const handleStatusChange = async (referrerId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/crm/referrers/${referrerId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, isActive: newStatus === 'ACTIVE' }),
      });
      if (res.ok) {
        fetchReferrers();
        showToast('وضعیت معرف تغییر کرد');
      }
    } catch {
      showToast('خطا در تغییر وضعیت', 'error');
    }
  };

  const handleCopyLink = (code: string) => {
    navigator.clipboard.writeText(getReferralLink(code));
    showToast('لینک معرف کپی شد');
  };

  const handleCommissionAction = async (commissionId: string, action: string) => {
    try {
      const res = await fetch('/api/crm/referrers/commissions', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ commissionId, status: action }),
      });
      if (res.ok) {
        fetchCommissions();
        showToast('وضعیت پورسانت تغییر کرد');
      }
    } catch {
      showToast('خطا در تغییر وضعیت', 'error');
    }
  };

  const handleCreatePayout = async () => {
    if (!payoutReferrerId || !payoutPeriodStart || !payoutPeriodEnd) return;
    setPayoutSubmitting(true);
    try {
      const res = await fetch('/api/crm/referrers/payouts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          referrerId: payoutReferrerId,
          periodStart: payoutPeriodStart,
          periodEnd: payoutPeriodEnd,
        }),
      });
      if (res.ok) {
        setPayoutDialogOpen(false);
        fetchPayouts();
        showToast('پرداخت با موفقیت ثبت شد');
      } else {
        const data = await res.json();
        showToast(data.error || 'خطا در ثبت پرداخت', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally { setPayoutSubmitting(false); }
  };

  const handleSaveSettings = async () => {
    setSettingsSaving(true);
    try {
      // Save default tiers as a site setting
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: 'default_commission_tiers',
          value: JSON.stringify(settingsTiers),
        }),
      });
      if (res.ok) {
        showToast('تنظیمات ذخیره شد');
      } else {
        showToast('خطا در ذخیره تنظیمات', 'error');
      }
    } catch {
      showToast('خطا در ارتباط با سرور', 'error');
    } finally { setSettingsSaving(false); }
  };

  const addTier = () => {
    const lastTier = settingsTiers[settingsTiers.length - 1];
    setSettingsTiers(prev => [
      ...prev,
      {
        minEnrollments: lastTier?.maxEnrollments ? lastTier.maxEnrollments + 1 : 1,
        maxEnrollments: undefined,
        pct: lastTier ? lastTier.pct + 3 : 10,
        name: '',
      },
    ]);
  };

  const removeTier = (index: number) => {
    if (settingsTiers.length <= 1) return;
    setSettingsTiers(prev => prev.filter((_, i) => i !== index));
  };

  const updateTier = (index: number, field: keyof CommissionTier, value: string | number) => {
    setSettingsTiers(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 z-[100] px-4 py-2 rounded-lg shadow-lg text-sm font-medium transition-all ${
          toast.type === 'success' ? 'bg-teal-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {toast.message}
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <UserPlus className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">مدیریت معرف‌ها و بازاریاب‌ها</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(stats.totalCount)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت معرف‌ها، پورسانت‌ها و پرداخت‌ها</p>
          </div>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <UserPlus className="w-4 h-4" />
          افزودن معرف
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">تعداد معرف‌های فعال</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(activeReferrers)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <Users className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کل ثبت‌نام‌های معرفی</p>
                <p className="text-2xl font-bold mt-1 text-blue-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.monthReferrals)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <TrendingUp className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">پورسانت پرداختی ماه</p>
                <p className="text-2xl font-bold mt-1 text-orange-700">
                  {loading ? <Skeleton className="h-8 w-20" /> : formatToman(stats.monthCommissionPaid)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200">
                <Wallet className="w-5 h-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">درآمد تولیدشده از معرف‌ها</p>
                <p className="text-2xl font-bold mt-1 text-teal-700">
                  {loading ? <Skeleton className="h-8 w-20" /> : formatToman(referrers.reduce((sum, r) => sum + (r.totalRevenue || 0), 0))}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                <DollarSign className="w-5 h-5 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-white border shadow-sm">
          <TabsTrigger value="referrers" className="gap-1.5">
            <Users className="w-4 h-4" />
            معرف‌ها
          </TabsTrigger>
          <TabsTrigger value="commissions" className="gap-1.5">
            <DollarSign className="w-4 h-4" />
            پورسانت‌ها
          </TabsTrigger>
          <TabsTrigger value="payouts" className="gap-1.5">
            <Wallet className="w-4 h-4" />
            پرداخت‌ها
          </TabsTrigger>
          <TabsTrigger value="settings" className="gap-1.5">
            <Settings className="w-4 h-4" />
            تنظیمات پلکانی
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Referrers List */}
        <TabsContent value="referrers" className="mt-4 space-y-4">
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="جستجوی نام، کد یا تلفن..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10 bg-white"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full sm:w-40 bg-white">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                <SelectItem value="ACTIVE">فعال</SelectItem>
                <SelectItem value="SUSPENDED">معلق</SelectItem>
                <SelectItem value="INACTIVE">غیرفعال</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Referrers Table */}
          {loading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 rounded-lg" />
              ))}
            </div>
          ) : error ? (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-6 text-center">
                <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
                <p className="text-red-700 font-medium">{error}</p>
                <Button variant="outline" size="sm" className="mt-3" onClick={fetchReferrers}>
                  تلاش مجدد
                </Button>
              </CardContent>
            </Card>
          ) : referrers.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <UserPlus className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">معرفی یافت نشد</p>
                <p className="text-gray-400 text-sm mt-1">با افزودن معرف جدید شروع کنید</p>
                <Button onClick={openAddDialog} className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2">
                  <UserPlus className="w-4 h-4" />
                  افزودن معرف
                </Button>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-0 shadow-sm overflow-hidden">
              <ScrollArea className="max-h-[600px]">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50 hover:bg-gray-50">
                      <TableHead className="text-right font-bold">کد معرف</TableHead>
                      <TableHead className="text-right font-bold">نام و نام خانوادگی</TableHead>
                      <TableHead className="text-right font-bold">تلفن</TableHead>
                      <TableHead className="text-right font-bold hidden md:table-cell">معرف‌ها</TableHead>
                      <TableHead className="text-right font-bold hidden md:table-cell">ثبت‌نام‌ها</TableHead>
                      <TableHead className="text-right font-bold hidden lg:table-cell">درآمد</TableHead>
                      <TableHead className="text-right font-bold hidden lg:table-cell">پورسانت</TableHead>
                      <TableHead className="text-right font-bold hidden md:table-cell">سطح</TableHead>
                      <TableHead className="text-right font-bold">وضعیت</TableHead>
                      <TableHead className="text-right font-bold">عملیات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {referrers.map((referrer) => {
                      const statusMeta = STATUS_META[referrer.status] || STATUS_META.INACTIVE;
                      return (
                        <TableRow key={referrer.id} className="hover:bg-gray-50/50">
                          <TableCell>
                            <code className="px-2 py-1 bg-teal-50 text-teal-700 rounded text-xs font-mono font-bold">
                              {referrer.code}
                            </code>
                          </TableCell>
                          <TableCell className="font-medium">
                            {referrer.firstName} {referrer.lastName}
                          </TableCell>
                          <TableCell className="text-gray-500 text-sm dir-ltr" dir="ltr">
                            {referrer.phone}
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            <Badge variant="secondary" className="text-xs">
                              {toPersianNumber(referrer.totalReferrals || referrer._count?.referrals || 0)}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            <Badge variant="secondary" className="text-xs">
                              {toPersianNumber(referrer.totalEnrollments)}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden lg:table-cell text-sm">
                            {referrer.totalRevenue > 0 ? formatToman(referrer.totalRevenue) : '—'}
                          </TableCell>
                          <TableCell className="hidden lg:table-cell text-sm">
                            {referrer.totalCommission > 0 ? formatToman(referrer.totalCommission) : '—'}
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            <Badge className={`${getTierBadge(Math.min(4, Math.max(1, Math.ceil(referrer.totalEnrollments / 10) + 1))).bgColor} ${getTierBadge(Math.min(4, Math.max(1, Math.ceil(referrer.totalEnrollments / 10) + 1))).color} text-xs border-0`}>
                              {getTierBadge(Math.min(4, Math.max(1, Math.ceil(referrer.totalEnrollments / 10) + 1))).label}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
                              {statusMeta.label}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                                onClick={() => openDetail(referrer)}
                                title="مشاهده جزئیات"
                              >
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 text-gray-500 hover:text-orange-700 hover:bg-orange-50"
                                onClick={() => openEditDialog(referrer)}
                                title="ویرایش"
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 text-gray-500 hover:text-purple-700 hover:bg-purple-50"
                                onClick={() => { setQrReferrer(referrer); setQrDialogOpen(true); }}
                                title="QR Code"
                              >
                                <QrCode className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 text-gray-500 hover:text-blue-700 hover:bg-blue-50"
                                onClick={() => handleCopyLink(referrer.code)}
                                title="کپی لینک"
                              >
                                <Copy className="w-4 h-4" />
                              </Button>
                              {referrer.status === 'ACTIVE' && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0 text-gray-500 hover:text-yellow-700 hover:bg-yellow-50"
                                  onClick={() => handleStatusChange(referrer.id, 'SUSPENDED')}
                                  title="معلق کردن"
                                >
                                  <Ban className="w-4 h-4" />
                                </Button>
                              )}
                              {referrer.status === 'SUSPENDED' && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-8 w-8 p-0 text-gray-500 hover:text-green-700 hover:bg-green-50"
                                  onClick={() => handleStatusChange(referrer.id, 'ACTIVE')}
                                  title="فعال کردن"
                                >
                                  <CheckCircle2 className="w-4 h-4" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </ScrollArea>
            </Card>
          )}
        </TabsContent>

        {/* Tab 2: Commissions */}
        <TabsContent value="commissions" className="mt-4 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-gray-900">پورسانت‌ها</h2>
            <Select value={commissionFilterStatus} onValueChange={setCommissionFilterStatus}>
              <SelectTrigger className="w-40 bg-white">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه وضعیت‌ها</SelectItem>
                <SelectItem value="PENDING">در انتظار</SelectItem>
                <SelectItem value="APPROVED">تأیید شده</SelectItem>
                <SelectItem value="PAID">پرداخت شده</SelectItem>
                <SelectItem value="CANCELLED">لغو شده</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Card className="border-0 shadow-sm overflow-hidden">
            <ScrollArea className="max-h-[500px]">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 hover:bg-gray-50">
                    <TableHead className="text-right font-bold">معرف</TableHead>
                    <TableHead className="text-right font-bold">شخص معرفی‌شده</TableHead>
                    <TableHead className="text-right font-bold hidden md:table-cell">مبلغ شهریه</TableHead>
                    <TableHead className="text-right font-bold">درصد</TableHead>
                    <TableHead className="text-right font-bold">مبلغ پورسانت</TableHead>
                    <TableHead className="text-right font-bold hidden md:table-cell">سطح</TableHead>
                    <TableHead className="text-right font-bold">وضعیت</TableHead>
                    <TableHead className="text-right font-bold hidden lg:table-cell">تاریخ</TableHead>
                    <TableHead className="text-right font-bold">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {commissions.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-8 text-gray-400">
                        پورسانتی یافت نشد
                      </TableCell>
                    </TableRow>
                  ) : commissions.map((commission) => {
                    const statusMeta = COMMISSION_STATUS_META[commission.status] || COMMISSION_STATUS_META.PENDING;
                    const tierBadge = getTierBadge(commission.tierLevel);
                    return (
                      <TableRow key={commission.id} className="hover:bg-gray-50/50">
                        <TableCell className="font-medium text-sm">
                          {commission.referrer ? `${commission.referrer.firstName} ${commission.referrer.lastName}` : '—'}
                        </TableCell>
                        <TableCell className="text-sm">
                          {commission.referral?.refName || '—'}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm">
                          {formatToman(commission.amount)}
                        </TableCell>
                        <TableCell className="text-sm font-bold">
                          {toPersianNumber(commission.commissionPct)}٪
                        </TableCell>
                        <TableCell className="text-sm font-bold text-teal-700">
                          {formatToman(commission.commissionAmount)}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <Badge className={`${tierBadge.bgColor} ${tierBadge.color} text-xs border-0`}>
                            {tierBadge.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
                            {statusMeta.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-xs text-gray-500">
                          {formatPersianDate(commission.createdAt)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {commission.status === 'PENDING' && (
                              <>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 text-xs text-green-700 hover:bg-green-50"
                                  onClick={() => handleCommissionAction(commission.id, 'APPROVED')}
                                >
                                  تأیید
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 text-xs text-red-700 hover:bg-red-50"
                                  onClick={() => handleCommissionAction(commission.id, 'CANCELLED')}
                                >
                                  لغو
                                </Button>
                              </>
                            )}
                            {commission.status === 'APPROVED' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 text-xs text-teal-700 hover:bg-teal-50"
                                onClick={() => handleCommissionAction(commission.id, 'PAID')}
                              >
                                پرداخت
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </ScrollArea>
          </Card>
        </TabsContent>

        {/* Tab 3: Payouts */}
        <TabsContent value="payouts" className="mt-4 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-gray-900">پرداخت‌ها</h2>
            <Button
              onClick={() => {
                setPayoutReferrerId('');
                setPayoutPeriodStart('');
                setPayoutPeriodEnd('');
                setPayoutDialogOpen(true);
              }}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <CreditCard className="w-4 h-4" />
              ثبت پرداخت
            </Button>
          </div>

          <Card className="border-0 shadow-sm overflow-hidden">
            <ScrollArea className="max-h-[500px]">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gray-50 hover:bg-gray-50">
                    <TableHead className="text-right font-bold">معرف</TableHead>
                    <TableHead className="text-right font-bold">مبلغ</TableHead>
                    <TableHead className="text-right font-bold hidden md:table-cell">روش</TableHead>
                    <TableHead className="text-right font-bold hidden md:table-cell">دوره</TableHead>
                    <TableHead className="text-right font-bold">وضعیت</TableHead>
                    <TableHead className="text-right font-bold hidden lg:table-cell">شماره پیگیری</TableHead>
                    <TableHead className="text-right font-bold hidden lg:table-cell">تاریخ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payouts.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-8 text-gray-400">
                        پرداختی یافت نشد
                      </TableCell>
                    </TableRow>
                  ) : payouts.map((payout) => {
                    const statusMeta = PAYOUT_STATUS_META[payout.status] || PAYOUT_STATUS_META.PENDING;
                    const methodLabel: Record<string, string> = {
                      BANK_TRANSFER: 'انتقال بانکی',
                      CASH: 'نقدی',
                      CHECK: 'چک',
                    };
                    return (
                      <TableRow key={payout.id} className="hover:bg-gray-50/50">
                        <TableCell className="font-medium text-sm">
                          {payout.referrer ? `${payout.referrer.firstName} ${payout.referrer.lastName}` : '—'}
                        </TableCell>
                        <TableCell className="text-sm font-bold text-teal-700">
                          {formatToman(payout.amount)}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm">
                          {methodLabel[payout.method] || payout.method}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-xs text-gray-500">
                          {formatPersianDate(payout.periodStart)} — {formatPersianDate(payout.periodEnd)}
                        </TableCell>
                        <TableCell>
                          <Badge className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
                            {statusMeta.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm font-mono">
                          {payout.trackingNo || '—'}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-xs text-gray-500">
                          {formatPersianDate(payout.createdAt)}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </ScrollArea>
          </Card>
        </TabsContent>

        {/* Tab 4: Settings */}
        <TabsContent value="settings" className="mt-4 space-y-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-bold text-gray-900">سطوح پورسانت پیش‌فرض</h2>
                  <p className="text-sm text-gray-500 mt-1">این سطوح برای معرف‌های جدید اعمال می‌شود</p>
                </div>
                <Button variant="outline" size="sm" onClick={addTier} className="gap-1">
                  <Plus className="w-3 h-3" />
                  افزودن سطح
                </Button>
              </div>

              <div className="space-y-3">
                {settingsTiers.map((tier, idx) => {
                  const tierBadge = TIER_BADGES[String(idx + 1)] || TIER_BADGES['1'];
                  return (
                    <div key={idx} className="border rounded-lg p-4 bg-gray-50/50 flex items-center gap-4">
                      <Badge className={`${tierBadge.bgColor} ${tierBadge.color} text-xs border-0 shrink-0`}>
                        سطح {toPersianNumber(idx + 1)}
                      </Badge>
                      <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div>
                          <Label className="text-xs text-gray-500">نام سطح</Label>
                          <Input
                            value={tier.name}
                            onChange={(e) => updateTier(idx, 'name', e.target.value)}
                            placeholder="نام سطح..."
                            className="h-8 text-sm"
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-gray-500">حداقل ثبت‌نام</Label>
                          <Input
                            type="number"
                            min={1}
                            value={tier.minEnrollments}
                            onChange={(e) => updateTier(idx, 'minEnrollments', parseInt(e.target.value) || 1)}
                            className="h-8 text-sm"
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-gray-500">حداکثر ثبت‌نام</Label>
                          <Input
                            type="number"
                            min={0}
                            value={tier.maxEnrollments || ''}
                            onChange={(e) => updateTier(idx, 'maxEnrollments', parseInt(e.target.value) || undefined)}
                            placeholder="نامحدود"
                            className="h-8 text-sm"
                          />
                        </div>
                        <div>
                          <Label className="text-xs text-gray-500">درصد پورسانت</Label>
                          <Input
                            type="number"
                            min={0}
                            max={100}
                            value={tier.pct}
                            onChange={(e) => updateTier(idx, 'pct', parseFloat(e.target.value) || 0)}
                            className="h-8 text-sm"
                          />
                        </div>
                      </div>
                      {settingsTiers.length > 1 && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-red-500 hover:bg-red-50 shrink-0"
                          onClick={() => removeTier(idx)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="mt-6 flex items-center justify-between border-t pt-4">
                <div className="flex items-center gap-3">
                  {settingsTiers.map((tier, idx) => (
                    <div key={idx} className="flex items-center gap-1">
                      <Badge className={`${(TIER_BADGES[String(idx + 1)] || TIER_BADGES['1']).bgColor} ${(TIER_BADGES[String(idx + 1)] || TIER_BADGES['1']).color} text-xs border-0`}>
                        {toPersianNumber(tier.pct)}٪
                      </Badge>
                      <span className="text-xs text-gray-400">{tier.name}</span>
                    </div>
                  ))}
                </div>
                <Button
                  onClick={handleSaveSettings}
                  disabled={settingsSaving}
                  className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
                >
                  {settingsSaving && <Loader2 className="w-4 h-4 animate-spin" />}
                  ذخیره تنظیمات
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Referrer Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <UserPlus className="w-5 h-5 text-teal-600" />
              افزودن معرف جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نام *</Label>
                <Input
                  placeholder="نام..."
                  value={formFirstName}
                  onChange={(e) => setFormFirstName(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نام خانوادگی *</Label>
                <Input
                  placeholder="نام خانوادگی..."
                  value={formLastName}
                  onChange={(e) => setFormLastName(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">شماره تلفن *</Label>
              <Input
                placeholder="شماره تلفن..."
                value={formPhone}
                onChange={(e) => setFormPhone(e.target.value)}
                dir="ltr"
              />
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">ایمیل</Label>
              <Input
                placeholder="ایمیل..."
                value={formEmail}
                onChange={(e) => setFormEmail(e.target.value)}
                dir="ltr"
              />
            </div>

            <div className="border-t pt-4">
              <p className="text-sm font-bold text-gray-700 mb-3">اطلاعات بانکی</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">نام بانک</Label>
                  <Input
                    placeholder="نام بانک..."
                    value={formBankName}
                    onChange={(e) => setFormBankName(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">شماره حساب</Label>
                  <Input
                    placeholder="شماره حساب..."
                    value={formBankAccountNo}
                    onChange={(e) => setFormBankAccountNo(e.target.value)}
                    dir="ltr"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-3">
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">شماره کارت</Label>
                  <Input
                    placeholder="شماره کارت..."
                    value={formBankCardNo}
                    onChange={(e) => setFormBankCardNo(e.target.value)}
                    dir="ltr"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">شماره شبا</Label>
                  <Input
                    placeholder="IR..."
                    value={formBankShaba}
                    onChange={(e) => setFormBankShaba(e.target.value)}
                    dir="ltr"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">یادداشت</Label>
              <Textarea
                placeholder="یادداشت اختیاری..."
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>انصراف</Button>
            <Button
              onClick={handleAddSubmit}
              disabled={submitting || !formFirstName.trim() || !formLastName.trim() || !formPhone.trim()}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              ثبت معرف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Referrer Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Edit className="w-5 h-5 text-teal-600" />
              ویرایش معرف
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نام *</Label>
                <Input value={formFirstName} onChange={(e) => setFormFirstName(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نام خانوادگی *</Label>
                <Input value={formLastName} onChange={(e) => setFormLastName(e.target.value)} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">شماره تلفن *</Label>
              <Input value={formPhone} onChange={(e) => setFormPhone(e.target.value)} dir="ltr" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">ایمیل</Label>
              <Input value={formEmail} onChange={(e) => setFormEmail(e.target.value)} dir="ltr" />
            </div>
            <div className="border-t pt-4">
              <p className="text-sm font-bold text-gray-700 mb-3">اطلاعات بانکی</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">نام بانک</Label>
                  <Input value={formBankName} onChange={(e) => setFormBankName(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">شماره حساب</Label>
                  <Input value={formBankAccountNo} onChange={(e) => setFormBankAccountNo(e.target.value)} dir="ltr" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-3">
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">شماره کارت</Label>
                  <Input value={formBankCardNo} onChange={(e) => setFormBankCardNo(e.target.value)} dir="ltr" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">شماره شبا</Label>
                  <Input value={formBankShaba} onChange={(e) => setFormBankShaba(e.target.value)} dir="ltr" />
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">یادداشت</Label>
              <Textarea
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>انصراف</Button>
            <Button
              onClick={handleEditSubmit}
              disabled={editSubmitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {editSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
              ذخیره تغییرات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Eye className="w-5 h-5 text-teal-600" />
              جزئیات معرف
            </DialogTitle>
          </DialogHeader>

          {detailLoading ? (
            <div className="space-y-4 py-4">
              <Skeleton className="h-8 w-48" />
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-48 w-full" />
            </div>
          ) : detailReferrer ? (
            <div className="space-y-6 py-2">
              {/* Profile Info */}
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-full bg-teal-100 flex items-center justify-center shrink-0">
                  <span className="text-2xl font-bold text-teal-700">
                    {detailReferrer.firstName.charAt(0)}
                  </span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-gray-900">
                      {detailReferrer.firstName} {detailReferrer.lastName}
                    </h3>
                    <Badge className={`${STATUS_META[detailReferrer.status]?.bgColor} ${STATUS_META[detailReferrer.status]?.color} text-xs border-0`}>
                      {STATUS_META[detailReferrer.status]?.label}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 mt-1 text-sm text-gray-500">
                    <span>کد معرف: <code className="bg-teal-50 text-teal-700 px-1.5 py-0.5 rounded font-mono">{detailReferrer.code}</code></span>
                    <span dir="ltr">{detailReferrer.phone}</span>
                    {detailReferrer.email && <span dir="ltr">{detailReferrer.email}</span>}
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1 text-xs"
                      onClick={() => handleCopyLink(detailReferrer.code)}
                    >
                      <Copy className="w-3 h-3" />
                      کپی لینک
                    </Button>
                  </div>
                  <div className="mt-2 p-2 bg-gray-50 rounded-lg text-xs">
                    <span className="text-gray-500">لینک معرف: </span>
                    <code className="text-teal-700 break-all" dir="ltr">{getReferralLink(detailReferrer.code)}</code>
                  </div>

                  {/* QR Code */}
                  <div className="mt-3 flex items-center gap-4">
                    <div className="border rounded-lg p-2 bg-white">
                      <img
                        src={`/api/crm/referrers/${detailReferrer.id}/qr`}
                        alt="QR Code"
                        className="w-32 h-32"
                        loading="lazy"
                      />
                    </div>
                    <div className="text-xs text-gray-500 space-y-1">
                      <p>این QR Code را اسکن کنید</p>
                      <p>تا مستقیماً به صفحه معرف</p>
                      <p>دسترسی پیدا کنید.</p>
                      <a
                        href={`/api/crm/referrers/${detailReferrer.id}/qr`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-teal-600 hover:text-teal-700 font-medium"
                      >
                        <QrCode className="w-3 h-3" />
                        دانلود QR
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">کل معرف‌ها</p>
                  <p className="text-xl font-bold text-gray-700">{toPersianNumber(detailReferrer.totalReferrals)}</p>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-xs text-gray-500">ثبت‌نام‌ها</p>
                  <p className="text-xl font-bold text-green-700">{toPersianNumber(detailReferrer.totalEnrollments)}</p>
                </div>
                <div className="text-center p-3 bg-teal-50 rounded-lg">
                  <p className="text-xs text-gray-500">درآمد</p>
                  <p className="text-lg font-bold text-teal-700">{detailReferrer.totalRevenue > 0 ? formatToman(detailReferrer.totalRevenue) : '—'}</p>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <p className="text-xs text-gray-500">پورسانت</p>
                  <p className="text-lg font-bold text-purple-700">{detailReferrer.totalCommission > 0 ? formatToman(detailReferrer.totalCommission) : '—'}</p>
                </div>
              </div>

              {/* Commission Tier */}
              <div className="border rounded-lg p-4">
                <h4 className="text-sm font-bold text-gray-700 mb-2">سطوح پورسانت</h4>
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge className="bg-gray-100 text-gray-700 text-xs border-0">
                    پایه: {toPersianNumber(detailReferrer.baseCommissionPct)}٪
                  </Badge>
                  {detailReferrer.commissionTiers?.map((tier, idx) => {
                    const tierBadge = TIER_BADGES[String(idx + 1)] || TIER_BADGES['1'];
                    return (
                      <Badge key={idx} className={`${tierBadge.bgColor} ${tierBadge.color} text-xs border-0`}>
                        {tier.name || tierBadge.label}: {toPersianNumber(tier.pct)}٪
                      </Badge>
                    );
                  })}
                </div>
              </div>

              {/* Bank Info */}
              {detailReferrer.bankName && (
                <div className="border rounded-lg p-4">
                  <h4 className="text-sm font-bold text-gray-700 mb-2">اطلاعات بانکی</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {detailReferrer.bankName && (
                      <div><span className="text-gray-500">بانک:</span> {detailReferrer.bankName}</div>
                    )}
                    {detailReferrer.bankAccountNo && (
                      <div dir="ltr" className="text-right"><span className="text-gray-500" dir="rtl">شماره حساب:</span> {detailReferrer.bankAccountNo}</div>
                    )}
                    {detailReferrer.bankCardNo && (
                      <div dir="ltr" className="text-right"><span className="text-gray-500" dir="rtl">شماره کارت:</span> {detailReferrer.bankCardNo}</div>
                    )}
                    {detailReferrer.bankShaba && (
                      <div dir="ltr" className="text-right"><span className="text-gray-500" dir="rtl">شبا:</span> {detailReferrer.bankShaba}</div>
                    )}
                  </div>
                </div>
              )}

              {/* Recent Referrals */}
              <div className="border rounded-lg p-4">
                <h4 className="text-sm font-bold text-gray-700 mb-3">آخرین معرف‌ها</h4>
                {detailReferrer.referrals && detailReferrer.referrals.length > 0 ? (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {detailReferrer.referrals.slice(0, 10).map((ref) => (
                      <div key={ref.id} className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded">
                        <div>
                          <span className="font-medium">{ref.refName}</span>
                          <span className="text-gray-400 mr-2" dir="ltr">{ref.refPhone}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={`${COMMISSION_STATUS_META[ref.commissionStatus]?.bgColor} ${COMMISSION_STATUS_META[ref.commissionStatus]?.color} text-xs border-0`}>
                            {COMMISSION_STATUS_META[ref.commissionStatus]?.label}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-400 text-center py-4">معرفی‌ای ثبت نشده</p>
                )}
              </div>

              {/* Commission History */}
              <div className="border rounded-lg p-4">
                <h4 className="text-sm font-bold text-gray-700 mb-3">سابقه پورسانت</h4>
                {detailReferrer.commissions && detailReferrer.commissions.length > 0 ? (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {detailReferrer.commissions.slice(0, 10).map((comm) => {
                      const tierBadge = getTierBadge(comm.tierLevel);
                      return (
                        <div key={comm.id} className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded">
                          <div className="flex items-center gap-2">
                            <Badge className={`${tierBadge.bgColor} ${tierBadge.color} text-xs border-0`}>
                              {tierBadge.label}
                            </Badge>
                            <span>{formatToman(comm.commissionAmount)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={`${COMMISSION_STATUS_META[comm.status]?.bgColor} ${COMMISSION_STATUS_META[comm.status]?.color} text-xs border-0`}>
                              {COMMISSION_STATUS_META[comm.status]?.label}
                            </Badge>
                            <span className="text-xs text-gray-400">{formatPersianDate(comm.createdAt)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-sm text-gray-400 text-center py-4">سابقه پورسانتی وجود ندارد</p>
                )}
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* Create Payout Dialog */}
      <Dialog open={payoutDialogOpen} onOpenChange={setPayoutDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <CreditCard className="w-5 h-5 text-teal-600" />
              ثبت پرداخت جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">معرف *</Label>
              <Select value={payoutReferrerId} onValueChange={setPayoutReferrerId}>
                <SelectTrigger className="bg-white">
                  <SelectValue placeholder="انتخاب معرف..." />
                </SelectTrigger>
                <SelectContent>
                  {referrers.filter(r => r.status === 'ACTIVE').map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.firstName} {r.lastName} ({r.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">شروع دوره *</Label>
                <Input
                  type="date"
                  value={payoutPeriodStart}
                  onChange={(e) => setPayoutPeriodStart(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">پایان دوره *</Label>
                <Input
                  type="date"
                  value={payoutPeriodEnd}
                  onChange={(e) => setPayoutPeriodEnd(e.target.value)}
                />
              </div>
            </div>

            <div className="p-3 bg-teal-50 rounded-lg text-sm text-teal-700">
              <p>مبلغ پرداخت به صورت خودکار بر اساس پورسانت‌های تأییدشده در بازه زمانی محاسبه می‌شود.</p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setPayoutDialogOpen(false)}>انصراف</Button>
            <Button
              onClick={handleCreatePayout}
              disabled={payoutSubmitting || !payoutReferrerId || !payoutPeriodStart || !payoutPeriodEnd}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {payoutSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
              ثبت پرداخت
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* QR Code Modal */}
      <Dialog open={qrDialogOpen} onOpenChange={setQrDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="w-5 h-5 text-teal-600" />
              QR Code معرف
            </DialogTitle>
          </DialogHeader>
          {qrReferrer && (
            <div className="flex flex-col items-center gap-4 py-2">
              <div className="text-center">
                <p className="font-bold text-gray-900">
                  {qrReferrer.firstName} {qrReferrer.lastName}
                </p>
                <code className="text-xs font-mono bg-teal-50 text-teal-700 px-2 py-1 rounded mt-1 inline-block">
                  {qrReferrer.code}
                </code>
              </div>
              <div className="border-2 border-dashed border-gray-200 rounded-xl p-3 bg-white">
                <img
                  src={`/api/crm/referrers/${qrReferrer.id}/qr`}
                  alt="QR Code"
                  className="w-64 h-64"
                />
              </div>
              <div className="text-center text-xs text-gray-500 bg-gray-50 p-2 rounded-lg w-full break-all" dir="ltr">
                {getReferralLink(qrReferrer.code)}
              </div>
              <div className="flex gap-2 w-full">
                <Button
                  variant="outline"
                  className="flex-1 gap-2"
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = `/api/crm/referrers/${qrReferrer.id}/qr`;
                    link.download = `qr-${qrReferrer.code}.png`;
                    link.click();
                  }}
                >
                  <QrCode className="w-4 h-4" />
                  دانلود PNG
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 gap-2"
                  onClick={() => {
                    navigator.clipboard.writeText(getReferralLink(qrReferrer.code));
                    showToast('لینک کپی شد');
                  }}
                >
                  <Copy className="w-4 h-4" />
                  کپی لینک
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
