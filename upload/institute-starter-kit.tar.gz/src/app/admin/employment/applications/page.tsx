'use client';

import { useEffect, useState, useCallback } from 'react';
import { FileText, Search, Eye, CheckCircle, XCircle, Calendar, Clock, ListFilter } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

interface Application {
  id: string;
  jobListingId: string; jobSeekerId: string;
  coverLetter: string | null; proposedSalary: number | null;
  status: string; adminNotes: string | null; employerNotes: string | null;
  reviewedAt: string | null; shortlistedAt: string | null;
  interviewAt: string | null; hiredAt: string | null; rejectedAt: string | null;
  createdAt: string;
  jobListing: { id: string; title: string; jobType: string; city: string; employer: { id: string; companyName: string } };
  jobSeeker: { id: string; firstName: string; lastName: string; phone: string; skills: string; education: string };
}

const statusMap: Record<string, { label: string; color: string }> = {
  PENDING: { label: 'در انتظار', color: 'bg-yellow-100 text-yellow-800' },
  REVIEWED: { label: 'بررسی شده', color: 'bg-blue-100 text-blue-800' },
  SHORTLISTED: { label: 'لیست کوتاه', color: 'bg-purple-100 text-purple-800' },
  INTERVIEW_SCHEDULED: { label: 'مصاحبه', color: 'bg-indigo-100 text-indigo-800' },
  ACCEPTED: { label: 'پذیرفته شده', color: 'bg-green-100 text-green-800' },
  REJECTED: { label: 'رد شده', color: 'bg-red-100 text-red-800' },
  WITHDRAWN: { label: 'برگشت داده', color: 'bg-gray-100 text-gray-800' },
};

export default function ApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [viewApp, setViewApp] = useState<Application | null>(null);
  const [adminNotes, setAdminNotes] = useState('');

  const fetchApplications = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: '20' });
      if (statusFilter) params.set('status', statusFilter);
      const res = await fetch(`/api/crm/employment/applications?${params}`);
      const data = await res.json();
      setApplications(data?.داده‌ها || []);
      setTotal(data?.صفحه‌بندی?.کل || 0);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, statusFilter]);

  useEffect(() => { fetchApplications(); }, [fetchApplications]);

  const updateStatus = async (id: string, status: string) => {
    await fetch(`/api/crm/employment/applications/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, adminNotes: adminNotes || undefined }),
    });
    setViewApp(null);
    setAdminNotes('');
    fetchApplications();
  };

  const openView = (app: Application) => {
    setViewApp(app);
    setAdminNotes(app.adminNotes || '');
  };

  const timeline = (app: Application) => {
    const items = [
      { label: 'ثبت درخواست', date: app.createdAt, done: true },
      { label: 'بررسی', date: app.reviewedAt, done: !!app.reviewedAt },
      { label: 'لیست کوتاه', date: app.shortlistedAt, done: !!app.shortlistedAt },
      { label: 'مصاحبه', date: app.interviewAt, done: !!app.interviewAt },
      { label: 'استخدام', date: app.hiredAt, done: !!app.hiredAt },
    ];
    return items;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">درخواست‌های استخدام</h1>
          <p className="text-sm text-gray-500 mt-1">مدیریت و پیگیری درخواست‌های کارجویان</p>
        </div>
      </div>

      <Card>
        <CardContent className="p-4 flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <ListFilter className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
            <Select value={statusFilter || 'ALL'} onValueChange={v => { setStatusFilter(v === 'ALL' ? '' : v); setPage(1); }}>
              <SelectTrigger className="pr-9"><SelectValue placeholder="فیلتر وضعیت" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">همه وضعیت‌ها</SelectItem>
                <SelectItem value="PENDING">در انتظار</SelectItem>
                <SelectItem value="REVIEWED">بررسی شده</SelectItem>
                <SelectItem value="SHORTLISTED">لیست کوتاه</SelectItem>
                <SelectItem value="INTERVIEW_SCHEDULED">مصاحبه</SelectItem>
                <SelectItem value="ACCEPTED">پذیرفته شده</SelectItem>
                <SelectItem value="REJECTED">رد شده</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <span className="text-sm text-gray-500">{total} درخواست</span>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-right p-3 font-medium text-gray-600">کارجو</th>
                  <th className="text-right p-3 font-medium text-gray-600">شغل</th>
                  <th className="text-right p-3 font-medium text-gray-600">کارفرما</th>
                  <th className="text-right p-3 font-medium text-gray-600">حقوق پیشنهادی</th>
                  <th className="text-right p-3 font-medium text-gray-600">وضعیت</th>
                  <th className="text-right p-3 font-medium text-gray-600">تاریخ</th>
                  <th className="text-right p-3 font-medium text-gray-600">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={7} className="text-center p-8 text-gray-400">در حال بارگذاری...</td></tr>
                ) : applications.length === 0 ? (
                  <tr><td colSpan={7} className="text-center p-8 text-gray-400">درخواستی یافت نشد</td></tr>
                ) : applications.map(app => {
                  const st = statusMap[app.status] || { label: app.status, color: 'bg-gray-100' };
                  return (
                    <tr key={app.id} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div className="font-medium">{app.jobSeeker.firstName} {app.jobSeeker.lastName}</div>
                        <div className="text-xs text-gray-400" dir="ltr">{app.jobSeeker.phone}</div>
                      </td>
                      <td className="p-3">{app.jobListing.title}</td>
                      <td className="p-3">{app.jobListing.employer?.companyName}</td>
                      <td className="p-3">{app.proposedSalary ? `${(app.proposedSalary / 1000000).toFixed(1)} م` : '-'}</td>
                      <td className="p-3"><Badge className={st.color} variant="secondary">{st.label}</Badge></td>
                      <td className="p-3 text-xs">{new Date(app.createdAt).toLocaleDateString('fa-IR')}</td>
                      <td className="p-3">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" onClick={() => openView(app)}><Eye className="h-4 w-4" /></Button>
                          {app.status === 'PENDING' && (
                            <Button variant="ghost" size="icon" onClick={() => updateStatus(app.id, 'REVIEWED')} title="بررسی">
                              <CheckCircle className="h-4 w-4 text-blue-500" />
                            </Button>
                          )}
                          {(app.status === 'REVIEWED' || app.status === 'PENDING') && (
                            <Button variant="ghost" size="icon" onClick={() => updateStatus(app.id, 'SHORTLISTED')} title="لیست کوتاه">
                              <ListFilter className="h-4 w-4 text-purple-500" />
                            </Button>
                          )}
                          {app.status === 'SHORTLISTED' && (
                            <Button variant="ghost" size="icon" onClick={() => updateStatus(app.id, 'INTERVIEW_SCHEDULED')} title="مصاحبه">
                              <Calendar className="h-4 w-4 text-indigo-500" />
                            </Button>
                          )}
                          {app.status === 'INTERVIEW_SCHEDULED' && (
                            <>
                              <Button variant="ghost" size="icon" onClick={() => updateStatus(app.id, 'ACCEPTED')} title="پذیرش">
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => updateStatus(app.id, 'REJECTED')} title="رد">
                                <XCircle className="h-4 w-4 text-red-500" />
                              </Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {total > 20 && (
            <div className="flex items-center justify-between p-3 border-t">
              <span className="text-xs text-gray-500">نمایش {((page - 1) * 20) + 1} تا {Math.min(page * 20, total)} از {total}</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>قبلی</Button>
                <Button variant="outline" size="sm" disabled={page * 20 >= total} onClick={() => setPage(p => p + 1)}>بعدی</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Dialog */}
      <Dialog open={!!viewApp} onOpenChange={() => setViewApp(null)}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>جزئیات درخواست</DialogTitle>
          </DialogHeader>
          {viewApp && (
            <div className="space-y-4">
              {/* Info */}
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div><span className="text-gray-500">کارجو:</span> <span className="font-medium">{viewApp.jobSeeker.firstName} {viewApp.jobSeeker.lastName}</span></div>
                <div><span className="text-gray-500">تماس:</span> <span dir="ltr">{viewApp.jobSeeker.phone}</span></div>
                <div><span className="text-gray-500">شغل:</span> <span>{viewApp.jobListing.title}</span></div>
                <div><span className="text-gray-500">کارفرما:</span> <span>{viewApp.jobListing.employer?.companyName}</span></div>
                <div><span className="text-gray-500">تحصیلات:</span> <span>{viewApp.jobSeeker.education || '-'}</span></div>
                <div><span className="text-gray-500">حقوق پیشنهادی:</span> <span>{viewApp.proposedSalary ? viewApp.proposedSalary.toLocaleString() + ' ریال' : '-'}</span></div>
              </div>

              {/* Skills */}
              {viewApp.jobSeeker.skills && (
                <div className="text-sm">
                  <span className="text-gray-500">مهارت‌ها:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {viewApp.jobSeeker.skills.split(',').map((s, i) => (
                      <Badge key={i} variant="secondary" className="text-xs">{s.trim()}</Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Cover Letter */}
              {viewApp.coverLetter && (
                <div className="text-sm">
                  <span className="text-gray-500">نامه همراه:</span>
                  <p className="mt-1 p-2 bg-gray-50 rounded-lg text-xs">{viewApp.coverLetter}</p>
                </div>
              )}

              {/* Timeline */}
              <div className="text-sm">
                <span className="text-gray-500 block mb-2">خط زمانی:</span>
                <div className="space-y-2">
                  {timeline(viewApp).map((item, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className={`w-2.5 h-2.5 rounded-full ${item.done ? 'bg-teal-500' : 'bg-gray-200'}`} />
                      <span className={item.done ? 'font-medium' : 'text-gray-400'}>{item.label}</span>
                      {item.date && <span className="text-xs text-gray-400 mr-auto">{new Date(item.date).toLocaleDateString('fa-IR')}</span>}
                    </div>
                  ))}
                </div>
              </div>

              {/* Admin Notes */}
              <div>
                <Label>یادداشت ادمین</Label>
                <Textarea value={adminNotes} onChange={e => setAdminNotes(e.target.value)} rows={2} />
              </div>

              {/* Actions */}
              <div className="flex flex-wrap gap-2">
                {viewApp.status === 'PENDING' && (
                  <Button size="sm" onClick={() => updateStatus(viewApp.id, 'REVIEWED')} className="gap-1">
                    <Clock className="h-3.5 w-3.5" /> بررسی شد
                  </Button>
                )}
                {(viewApp.status === 'PENDING' || viewApp.status === 'REVIEWED') && (
                  <Button size="sm" variant="outline" onClick={() => updateStatus(viewApp.id, 'SHORTLISTED')} className="gap-1">
                    لیست کوتاه
                  </Button>
                )}
                {viewApp.status === 'SHORTLISTED' && (
                  <Button size="sm" variant="outline" onClick={() => updateStatus(viewApp.id, 'INTERVIEW_SCHEDULED')} className="gap-1">
                    <Calendar className="h-3.5 w-3.5" /> برنامه‌ریزی مصاحبه
                  </Button>
                )}
                {viewApp.status === 'INTERVIEW_SCHEDULED' && (
                  <>
                    <Button size="sm" className="gap-1 bg-green-600 hover:bg-green-700" onClick={() => updateStatus(viewApp.id, 'ACCEPTED')}>
                      <CheckCircle className="h-3.5 w-3.5" /> پذیرش
                    </Button>
                    <Button size="sm" variant="destructive" className="gap-1" onClick={() => updateStatus(viewApp.id, 'REJECTED')}>
                      <XCircle className="h-3.5 w-3.5" /> رد
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
