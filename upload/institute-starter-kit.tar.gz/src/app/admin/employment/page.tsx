'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Users, Briefcase, Building2, FileText, TrendingUp,
  GraduationCap, ArrowLeft, Clock, CheckCircle2, XCircle,
  Calendar,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface Stats {
  کارجویان: { کل: number; فعال: number; شاغل: number };
  فرصت_شغلی: { کل: number; فعال: number };
  کارفرمایان: { کل: number; تأیید_شده: number };
  درخواست‌ها: { کل: number; در_انتظار: number; پذیرفته_شده: number; رد_شده: number; مصاحبه: number };
  نرخ_تطبیق: number;
  فارغ‌التحصیلان_بدون_کارجو: number;
  فعالیت_اخیر: Array<{
    id: string;
    status: string;
    createdAt: string;
    jobListing: { title: string; employer: { companyName: string } };
    jobSeeker: { firstName: string; lastName: string };
  }>;
}

const statusMap: Record<string, { label: string; color: string }> = {
  PENDING: { label: 'در انتظار', color: 'bg-yellow-100 text-yellow-800' },
  REVIEWED: { label: 'بررسی شده', color: 'bg-blue-100 text-blue-800' },
  SHORTLISTED: { label: 'لیست کوتاه', color: 'bg-purple-100 text-purple-800' },
  INTERVIEW_SCHEDULED: { label: 'مصاحبه', color: 'bg-indigo-100 text-indigo-800' },
  ACCEPTED: { label: 'پذیرفته شده', color: 'bg-green-100 text-green-800' },
  REJECTED: { label: 'رد شده', color: 'bg-red-100 text-red-800' },
  WITHDRAWN: { label: 'برگشت داده', color: 'bg-gray-100 text-gray-800' },
};

export default function EmploymentDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/crm/employment/stats')
      .then(r => r.json())
      .then(data => setStats(data?.داده || null))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-teal-600 border-t-transparent" />
      </div>
    );
  }

  if (!stats) {
    return <div className="text-center py-20 text-gray-500">خطا در دریافت آمار</div>;
  }

  const statCards = [
    { title: 'کارجویان', value: stats.کارجویان.کل, sub: `${stats.کارجویان.فعال} فعال | ${stats.کارجویان.شاغل} شاغل`, icon: Users, color: 'text-teal-600', bg: 'bg-teal-50' },
    { title: 'فرصت‌های شغلی', value: stats.فرصت_شغلی.کل, sub: `${stats.فرصت_شغلی.فعال} فعال`, icon: Briefcase, color: 'text-blue-600', bg: 'bg-blue-50' },
    { title: 'کارفرمایان', value: stats.کارفرمایان.کل, sub: `${stats.کارفرمایان.تأیید_شده} تأیید شده`, icon: Building2, color: 'text-purple-600', bg: 'bg-purple-50' },
    { title: 'درخواست‌ها', value: stats.درخواست‌ها.کل, sub: `${stats.درخواست‌ها.در_انتظار} در انتظار`, icon: FileText, color: 'text-orange-600', bg: 'bg-orange-50' },
    { title: 'نرخ تطبیق', value: `${stats.نرخ_تطبیق}%`, sub: 'درصد پذیرش', icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50' },
    { title: 'فارغ‌التحصیلان آماده', value: stats.فارغ‌التحصیلان_بدون_کارجو, sub: 'بدون پروفایل کارجو', icon: GraduationCap, color: 'text-rose-600', bg: 'bg-rose-50' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">داشبورد اشتغال و کاریابی</h1>
          <p className="text-sm text-gray-500 mt-1">مدیریت سیستم اتصال فارغ‌التحصیلان به بازار کار</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map(card => (
          <Card key={card.title}>
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-xl ${card.bg}`}>
                  <card.icon className={`h-6 w-6 ${card.color}`} />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-gray-500">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{card.value}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{card.sub}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">دسترسی سریع</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-3">
          <Link href="/admin/employment/employers">
            <Button variant="outline" size="sm" className="gap-2">
              <Building2 className="h-4 w-4" /> کارفرمایان
            </Button>
          </Link>
          <Link href="/admin/employment/job-listings">
            <Button variant="outline" size="sm" className="gap-2">
              <Briefcase className="h-4 w-4" /> فرصت‌های شغلی
            </Button>
          </Link>
          <Link href="/admin/employment/job-seekers">
            <Button variant="outline" size="sm" className="gap-2">
              <Users className="h-4 w-4" /> کارجویان
            </Button>
          </Link>
          <Link href="/admin/employment/applications">
            <Button variant="outline" size="sm" className="gap-2">
              <FileText className="h-4 w-4" /> درخواست‌ها
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="h-4 w-4" /> فعالیت اخیر
          </CardTitle>
        </CardHeader>
        <CardContent>
          {stats.فعالیت_اخیر.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-8">هنوز درخواستی ثبت نشده است</p>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {stats.فعالیت_اخیر.map(app => {
                const st = statusMap[app.status] || { label: app.status, color: 'bg-gray-100 text-gray-800' };
                return (
                  <div key={app.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {app.jobSeeker.firstName} {app.jobSeeker.lastName}
                        <span className="text-gray-400 font-normal"> → </span>
                        {app.jobListing.title}
                      </p>
                      <p className="text-xs text-gray-400">
                        {app.jobListing.employer.companyName} • {new Date(app.createdAt).toLocaleDateString('fa-IR')}
                      </p>
                    </div>
                    <Badge className={st.color} variant="secondary">{st.label}</Badge>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Application Pipeline */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">خط لوله درخواست‌ها</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="text-center p-3 bg-yellow-50 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-yellow-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-yellow-700">{stats.درخواست‌ها.در_انتظار}</p>
              <p className="text-xs text-yellow-600">در انتظار</p>
            </div>
            <div className="text-center p-3 bg-indigo-50 rounded-lg">
              <Calendar className="h-5 w-5 text-indigo-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-indigo-700">{stats.درخواست‌ها.مصاحبه}</p>
              <p className="text-xs text-indigo-600">مصاحبه</p>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <CheckCircle2 className="h-5 w-5 text-green-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-green-700">{stats.درخواست‌ها.پذیرفته_شده}</p>
              <p className="text-xs text-green-600">پذیرفته شده</p>
            </div>
            <div className="text-center p-3 bg-red-50 rounded-lg">
              <XCircle className="h-5 w-5 text-red-600 mx-auto mb-1" />
              <p className="text-lg font-bold text-red-700">{stats.درخواست‌ها.رد_شده}</p>
              <p className="text-xs text-red-600">رد شده</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
