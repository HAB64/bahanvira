'use client';

import { useEffect, useState, useCallback } from 'react';
import { Building2, Plus, Search, Shield, ShieldCheck, ShieldX, Eye, Edit2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface Employer {
  id: string; companyName: string; contactPerson: string; phone: string;
  email: string; address: string | null; city: string; industry: string;
  website: string | null; description: string | null; status: string;
  isVerified: boolean; source: string; totalJobsPosted: number; totalHired: number;
  createdAt: string; _count: { jobListings: number };
}

const emptyForm = {
  companyName: '', contactPerson: '', phone: '', email: '', address: '',
  city: 'Mahmoudabad', industry: '', website: '', description: '',
};

export default function EmployersPage() {
  const [employers, setEmployers] = useState<Employer[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [viewEmployer, setViewEmployer] = useState<Employer | null>(null);

  const fetchEmployers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: '20' });
      if (search) params.set('search', search);
      if (statusFilter) params.set('status', statusFilter);
      const res = await fetch(`/api/crm/employment/employers?${params}`);
      const data = await res.json();
      setEmployers(data?.داده‌ها || []);
      setTotal(data?.صفحه‌بندی?.کل || 0);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, search, statusFilter]);

  useEffect(() => { fetchEmployers(); }, [fetchEmployers]);

  const handleSave = async () => {
    const url = editId ? `/api/crm/employment/employers/${editId}` : '/api/crm/employment/employers';
    const method = editId ? 'PATCH' : 'POST';
    await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    setDialogOpen(false);
    setEditId(null);
    setForm(emptyForm);
    fetchEmployers();
  };

  const handleVerify = async (id: string, isVerified: boolean) => {
    await fetch(`/api/crm/employment/employers/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isVerified }),
    });
    fetchEmployers();
  };

  const handleStatus = async (id: string, status: string) => {
    await fetch(`/api/crm/employment/employers/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    fetchEmployers();
  };

  const openEdit = (emp: Employer) => {
    setEditId(emp.id);
    setForm({
      companyName: emp.companyName, contactPerson: emp.contactPerson,
      phone: emp.phone, email: emp.email, address: emp.address || '',
      city: emp.city, industry: emp.industry, website: emp.website || '',
      description: emp.description || '',
    });
    setDialogOpen(true);
  };

  const statusBadge = (s: string) => {
    const m: Record<string, string> = {
      ACTIVE: 'bg-green-100 text-green-800',
      INACTIVE: 'bg-gray-100 text-gray-800',
      BLOCKED: 'bg-red-100 text-red-800',
    };
    const labels: Record<string, string> = { ACTIVE: 'فعال', INACTIVE: 'غیرفعال', BLOCKED: 'مسدود' };
    return <Badge className={m[s] || 'bg-gray-100'} variant="secondary">{labels[s] || s}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">کارفرمایان</h1>
          <p className="text-sm text-gray-500 mt-1">مدیریت شرکت‌ها و سازمان‌های کارفرما</p>
        </div>
        <Button onClick={() => { setForm(emptyForm); setEditId(null); setDialogOpen(true); }} className="gap-2">
          <Plus className="h-4 w-4" /> افزودن کارفرما
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4 flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input placeholder="جستجوی نام شرکت، شخص مسئول..." value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }} className="pr-9" />
          </div>
          <Select value={statusFilter || 'ALL'} onValueChange={v => { setStatusFilter(v === 'ALL' ? '' : v); setPage(1); }}>
            <SelectTrigger className="w-36"><SelectValue placeholder="وضعیت" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">همه</SelectItem>
              <SelectItem value="ACTIVE">فعال</SelectItem>
              <SelectItem value="INACTIVE">غیرفعال</SelectItem>
              <SelectItem value="BLOCKED">مسدود</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-right p-3 font-medium text-gray-600">نام شرکت</th>
                  <th className="text-right p-3 font-medium text-gray-600">شخص مسئول</th>
                  <th className="text-right p-3 font-medium text-gray-600">تماس</th>
                  <th className="text-right p-3 font-medium text-gray-600">شهر</th>
                  <th className="text-right p-3 font-medium text-gray-600">وضعیت</th>
                  <th className="text-right p-3 font-medium text-gray-600">تأیید</th>
                  <th className="text-right p-3 font-medium text-gray-600">مشاغل</th>
                  <th className="text-right p-3 font-medium text-gray-600">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={8} className="text-center p-8 text-gray-400">در حال بارگذاری...</td></tr>
                ) : employers.length === 0 ? (
                  <tr><td colSpan={8} className="text-center p-8 text-gray-400">کارفرمایی یافت نشد</td></tr>
                ) : employers.map(emp => (
                  <tr key={emp.id} className="border-b hover:bg-gray-50">
                    <td className="p-3 font-medium">{emp.companyName}</td>
                    <td className="p-3">{emp.contactPerson}</td>
                    <td className="p-3 text-xs">{emp.phone}</td>
                    <td className="p-3">{emp.city}</td>
                    <td className="p-3">{statusBadge(emp.status)}</td>
                    <td className="p-3">
                      {emp.isVerified ? (
                        <ShieldCheck className="h-5 w-5 text-green-600" />
                      ) : (
                        <Shield className="h-5 w-5 text-gray-300" />
                      )}
                    </td>
                    <td className="p-3">{emp._count?.jobListings || emp.totalJobsPosted}</td>
                    <td className="p-3">
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => setViewEmployer(emp)}><Eye className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => openEdit(emp)}><Edit2 className="h-4 w-4" /></Button>
                        {!emp.isVerified && (
                          <Button variant="ghost" size="icon" onClick={() => handleVerify(emp.id, true)} title="تأیید">
                            <ShieldCheck className="h-4 w-4 text-green-600" />
                          </Button>
                        )}
                        {emp.status === 'ACTIVE' && (
                          <Button variant="ghost" size="icon" onClick={() => handleStatus(emp.id, 'BLOCKED')} title="مسدود">
                            <ShieldX className="h-4 w-4 text-red-500" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {total > 20 && (
            <div className="flex items-center justify-between p-3 border-t">
              <span className="text-xs text-gray-500">نمایش {((page - 1) * 20) + 1} تا {Math.min(page * 20, total)} از {total}</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>قبلی</Button>
                <Button variant="outline" size="sm" disabled={page * 20 >= total} onClick={() => setPage(p => p + 1)}>بعدی</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editId ? 'ویرایش کارفرما' : 'افزودن کارفرما'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 max-h-[60vh] overflow-y-auto p-1">
            <div className="col-span-2"><Label>نام شرکت *</Label><Input value={form.companyName} onChange={e => setForm({ ...form, companyName: e.target.value })} /></div>
            <div><Label>شخص مسئول *</Label><Input value={form.contactPerson} onChange={e => setForm({ ...form, contactPerson: e.target.value })} /></div>
            <div><Label>شماره تماس *</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label>ایمیل</Label><Input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
            <div><Label>شهر</Label><Input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
            <div><Label>صنعت</Label><Input value={form.industry} onChange={e => setForm({ ...form, industry: e.target.value })} /></div>
            <div><Label>وب‌سایت</Label><Input value={form.website} onChange={e => setForm({ ...form, website: e.target.value })} /></div>
            <div className="col-span-2"><Label>آدرس</Label><Input value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div>
            <div className="col-span-2"><Label>توضیحات</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>انصراف</Button>
            <Button onClick={handleSave}>{editId ? 'بروزرسانی' : 'ثبت'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={!!viewEmployer} onOpenChange={() => setViewEmployer(null)}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>جزئیات کارفرما</DialogTitle>
          </DialogHeader>
          {viewEmployer && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">نام شرکت:</span><span className="font-medium">{viewEmployer.companyName}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">شخص مسئول:</span><span>{viewEmployer.contactPerson}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">تماس:</span><span dir="ltr">{viewEmployer.phone}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">ایمیل:</span><span dir="ltr">{viewEmployer.email}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">شهر:</span><span>{viewEmployer.city}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">صنعت:</span><span>{viewEmployer.industry || '-'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">تأیید شده:</span><span>{viewEmployer.isVerified ? 'بله' : 'خیر'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">مجموع مشاغل:</span><span>{viewEmployer.totalJobsPosted}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">مجموع استخدام:</span><span>{viewEmployer.totalHired}</span></div>
              {viewEmployer.address && <div><span className="text-gray-500">آدرس:</span><p className="mt-1">{viewEmployer.address}</p></div>}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
