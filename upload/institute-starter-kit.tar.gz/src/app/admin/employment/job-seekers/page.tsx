'use client';

import { useEffect, useState, useCallback } from 'react';
import { Users, Plus, Search, Eye, Edit2, GraduationCap, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface JobSeeker {
  id: string; karAmuzId: string | null; firstName: string; lastName: string;
  phone: string; email: string; city: string; skills: string;
  education: string; desiredJob: string; desiredJobType: string;
  experienceYears: number; status: string; isAvailable: boolean;
  source: string; applicationCount: number; createdAt: string;
  karAmuz: { id: string; firstName: string; lastName: string; studentCode: string; status: string } | null;
  _count: { applications: number };
}

const statusMap: Record<string, { l: string; c: string }> = {
  ACTIVE: { l: 'فعال', c: 'bg-green-100 text-green-800' },
  EMPLOYED: { l: 'شاغل', c: 'bg-blue-100 text-blue-800' },
  INACTIVE: { l: 'غیرفعال', c: 'bg-gray-100 text-gray-800' },
  BLOCKED: { l: 'مسدود', c: 'bg-red-100 text-red-800' },
};

const educationLabels: Record<string, string> = {
  دیپلم: 'دیپلم', کاردانی: 'کاردانی', کارشناسی: 'کارشناسی', 'کارشناسی ارشد': 'کارشناسی ارشد', دکتری: 'دکتری',
};

const emptyForm = {
  firstName: '', lastName: '', phone: '', email: '', gender: '',
  city: 'Mahmoudabad', education: '', fieldOfStudy: '', skills: '',
  certifications: '', experienceYears: '0', currentJob: '', desiredJob: '',
  desiredSalary: '', desiredJobType: 'FULL_TIME', availableFrom: '',
};

export default function JobSeekersPage() {
  const [seekers, setSeekers] = useState<JobSeeker[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sourceFilter, setSourceFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [viewSeeker, setViewSeeker] = useState<JobSeeker | null>(null);

  const fetchSeekers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: '20' });
      if (search) params.set('search', search);
      if (statusFilter) params.set('status', statusFilter);
      if (sourceFilter) params.set('source', sourceFilter);
      const res = await fetch(`/api/crm/employment/job-seekers?${params}`);
      const data = await res.json();
      setSeekers(data?.داده‌ها || []);
      setTotal(data?.صفحه‌بندی?.کل || 0);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, search, statusFilter, sourceFilter]);

  useEffect(() => { fetchSeekers(); }, [fetchSeekers]);

  const handleSave = async () => {
    const body = {
      ...form,
      experienceYears: parseInt(form.experienceYears) || 0,
      desiredSalary: form.desiredSalary ? parseInt(form.desiredSalary) : null,
      availableFrom: form.availableFrom || null,
    };
    const url = editId ? `/api/crm/employment/job-seekers/${editId}` : '/api/crm/employment/job-seekers';
    const method = editId ? 'PATCH' : 'POST';
    await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    setDialogOpen(false); setEditId(null); setForm(emptyForm); fetchSeekers();
  };

  const markEmployed = async (id: string) => {
    await fetch(`/api/crm/employment/job-seekers/${id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'EMPLOYED', isAvailable: false }),
    });
    fetchSeekers();
  };

  const openEdit = (s: JobSeeker) => {
    setEditId(s.id);
    setForm({
      firstName: s.firstName, lastName: s.lastName, phone: s.phone,
      email: s.email, gender: '', city: s.city, education: s.education,
      fieldOfStudy: '', skills: s.skills, certifications: '',
      experienceYears: String(s.experienceYears), currentJob: '',
      desiredJob: s.desiredJob, desiredSalary: '',
      desiredJobType: s.desiredJobType, availableFrom: '',
    });
    setDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">کارجویان</h1>
          <p className="text-sm text-gray-500 mt-1">مدیریت کارجویان و فارغ‌التحصیلان آماده کار</p>
        </div>
        <Button onClick={() => { setForm(emptyForm); setEditId(null); setDialogOpen(true); }} className="gap-2">
          <Plus className="h-4 w-4" /> افزودن کارجو
        </Button>
      </div>

      <Card>
        <CardContent className="p-4 flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input placeholder="جستجوی نام، مهارت، شغل مورد نظر..." value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }} className="pr-9" />
          </div>
          <Select value={statusFilter || 'ALL'} onValueChange={v => { setStatusFilter(v === 'ALL' ? '' : v); setPage(1); }}>
            <SelectTrigger className="w-32"><SelectValue placeholder="وضعیت" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">همه</SelectItem>
              <SelectItem value="ACTIVE">فعال</SelectItem>
              <SelectItem value="EMPLOYED">شاغل</SelectItem>
              <SelectItem value="INACTIVE">غیرفعال</SelectItem>
            </SelectContent>
          </Select>
          <Select value={sourceFilter || 'ALL'} onValueChange={v => { setSourceFilter(v === 'ALL' ? '' : v); setPage(1); }}>
            <SelectTrigger className="w-36"><SelectValue placeholder="منبع" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">همه</SelectItem>
              <SelectItem value="WEB_FORM">فرم وب</SelectItem>
              <SelectItem value="ADMIN">ادمین</SelectItem>
              <SelectItem value="KARAMUZ_GRADUATE">فارغ‌التحصیل</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-right p-3 font-medium text-gray-600">نام</th>
                  <th className="text-right p-3 font-medium text-gray-600">تماس</th>
                  <th className="text-right p-3 font-medium text-gray-600">تحصیلات</th>
                  <th className="text-right p-3 font-medium text-gray-600">مهارت‌ها</th>
                  <th className="text-right p-3 font-medium text-gray-600">شغل مورد نظر</th>
                  <th className="text-right p-3 font-medium text-gray-600">وضعیت</th>
                  <th className="text-right p-3 font-medium text-gray-600">منبع</th>
                  <th className="text-right p-3 font-medium text-gray-600">درخواست</th>
                  <th className="text-right p-3 font-medium text-gray-600">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={9} className="text-center p-8 text-gray-400">در حال بارگذاری...</td></tr>
                ) : seekers.length === 0 ? (
                  <tr><td colSpan={9} className="text-center p-8 text-gray-400">کارجویی یافت نشد</td></tr>
                ) : seekers.map(s => {
                  const st = statusMap[s.status] || { l: s.status, c: 'bg-gray-100' };
                  const srcLabel: Record<string, string> = { WEB_FORM: 'وب', ADMIN: 'ادمین', KARAMUZ_GRADUATE: 'فارغ‌التحصیل' };
                  return (
                    <tr key={s.id} className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium">
                        {s.firstName} {s.lastName}
                        {s.karAmuz && (
                          <GraduationCap className="h-3.5 w-3.5 text-teal-600 inline mr-1" />
                        )}
                      </td>
                      <td className="p-3 text-xs" dir="ltr">{s.phone}</td>
                      <td className="p-3">{s.education || '-'}</td>
                      <td className="p-3 max-w-[150px] truncate">{s.skills || '-'}</td>
                      <td className="p-3">{s.desiredJob || '-'}</td>
                      <td className="p-3"><Badge className={st.c} variant="secondary">{st.l}</Badge></td>
                      <td className="p-3">{srcLabel[s.source] || s.source}</td>
                      <td className="p-3">{s._count?.applications || s.applicationCount}</td>
                      <td className="p-3">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" onClick={() => setViewSeeker(s)}><Eye className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => openEdit(s)}><Edit2 className="h-4 w-4" /></Button>
                          {s.status === 'ACTIVE' && (
                            <Button variant="ghost" size="icon" onClick={() => markEmployed(s.id)} title="شاغل شد">
                              <CheckCircle className="h-4 w-4 text-green-600" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {total > 20 && (
            <div className="flex items-center justify-between p-3 border-t">
              <span className="text-xs text-gray-500">نمایش {((page - 1) * 20) + 1} تا {Math.min(page * 20, total)} از {total}</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>قبلی</Button>
                <Button variant="outline" size="sm" disabled={page * 20 >= total} onClick={() => setPage(p => p + 1)}>بعدی</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editId ? 'ویرایش کارجو' : 'افزودن کارجو'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 max-h-[60vh] overflow-y-auto p-1">
            <div><Label>نام *</Label><Input value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} /></div>
            <div><Label>نام خانوادگی *</Label><Input value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} /></div>
            <div><Label>شماره تماس *</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
            <div><Label>ایمیل</Label><Input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
            <div><Label>شهر</Label><Input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
            <div><Label>تحصیلات</Label>
              <Select value={form.education} onValueChange={v => setForm({ ...form, education: v })}>
                <SelectTrigger><SelectValue placeholder="انتخاب" /></SelectTrigger>
                <SelectContent>
                  {Object.entries(educationLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label>رشته تحصیلی</Label><Input value={form.fieldOfStudy} onChange={e => setForm({ ...form, fieldOfStudy: e.target.value })} /></div>
            <div><Label>مهارت‌ها</Label><Input value={form.skills} onChange={e => setForm({ ...form, skills: e.target.value })} placeholder="با کاما جدا کنید" /></div>
            <div><Label>سابقه کار (سال)</Label><Input type="number" value={form.experienceYears} onChange={e => setForm({ ...form, experienceYears: e.target.value })} /></div>
            <div><Label>شغل مورد نظر</Label><Input value={form.desiredJob} onChange={e => setForm({ ...form, desiredJob: e.target.value })} /></div>
            <div><Label>نوع شغل</Label>
              <Select value={form.desiredJobType} onValueChange={v => setForm({ ...form, desiredJobType: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="FULL_TIME">تمام‌وقت</SelectItem>
                  <SelectItem value="PART_TIME">پاره‌وقت</SelectItem>
                  <SelectItem value="CONTRACT">قراردادی</SelectItem>
                  <SelectItem value="REMOTE">دورکاری</SelectItem>
                  <SelectItem value="ANY">هر نوع</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>حقوق مورد انتظار (ریال)</Label><Input type="number" value={form.desiredSalary} onChange={e => setForm({ ...form, desiredSalary: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>انصراف</Button>
            <Button onClick={handleSave}>{editId ? 'بروزرسانی' : 'ثبت'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Dialog */}
      <Dialog open={!!viewSeeker} onOpenChange={() => setViewSeeker(null)}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>جزئیات کارجو</DialogTitle>
          </DialogHeader>
          {viewSeeker && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-gray-500">نام:</span><span className="font-medium">{viewSeeker.firstName} {viewSeeker.lastName}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">تماس:</span><span dir="ltr">{viewSeeker.phone}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">ایمیل:</span><span dir="ltr">{viewSeeker.email}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">شهر:</span><span>{viewSeeker.city}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">تحصیلات:</span><span>{viewSeeker.education || '-'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">سابقه کار:</span><span>{viewSeeker.experienceYears} سال</span></div>
              <div><span className="text-gray-500">مهارت‌ها:</span><p className="mt-1">{viewSeeker.skills || '-'}</p></div>
              <div className="flex justify-between"><span className="text-gray-500">شغل مورد نظر:</span><span>{viewSeeker.desiredJob || '-'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">وضعیت:</span><span>{viewSeeker.isAvailable ? 'آماده به کار' : 'غیرفعال'}</span></div>
              <div className="flex justify-between"><span className="text-gray-500">منبع:</span><span>{viewSeeker.source}</span></div>
              {viewSeeker.karAmuz && (
                <div className="flex justify-between"><span className="text-gray-500">کد کارآموزی:</span><span>{viewSeeker.karAmuz.studentCode}</span></div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
