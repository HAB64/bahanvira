'use client';

import { useEffect, useState, useCallback } from 'react';
import { Briefcase, Plus, Search, Eye, Edit2, XCircle, RotateCcw } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface JobListing {
  id: string; employerId: string; title: string; description: string;
  category: string; jobType: string; experienceLevel: string;
  salaryMin: number | null; salaryMax: number | null;
  requiredSkills: string; city: string; isRemote: boolean;
  status: string; urgency: string; deadline: string | null;
  applicationCount: number; createdAt: string;
  employer: { id: string; companyName: string; city: string; isVerified: boolean };
  _count: { applications: number };
}

interface Employer { id: string; companyName: string }

const jobTypeLabels: Record<string, string> = {
  FULL_TIME: 'تمام‌وقت', PART_TIME: 'پاره‌وقت', CONTRACT: 'قراردادی',
  INTERNSHIP: 'کارآموزی', REMOTE: 'دورکاری',
};
const categoryLabels: Record<string, string> = {
  'tech-ai': 'فناوری و AI', financial: 'بازارهای مالی', management: 'مدیریت', other: 'سایر', '': 'نامشخص',
};
const expLabels: Record<string, string> = {
  JUNIOR: 'تازه‌کار', MID: 'متوسط', SENIOR: 'ارشد', ENTRY_LEVEL: 'مبتدی',
};
const statusLabels: Record<string, { l: string; c: string }> = {
  ACTIVE: { l: 'فعال', c: 'bg-green-100 text-green-800' },
  PAUSED: { l: 'مکث', c: 'bg-yellow-100 text-yellow-800' },
  CLOSED: { l: 'بسته', c: 'bg-red-100 text-red-800' },
  DRAFT: { l: 'پیش‌نویس', c: 'bg-gray-100 text-gray-800' },
};

const emptyForm = {
  employerId: '', title: '', description: '', category: '', jobType: 'FULL_TIME',
  experienceLevel: 'JUNIOR', salaryMin: '', salaryMax: '', requiredSkills: '',
  requiredEducation: '', benefits: '', city: 'Mahmoudabad', isRemote: false,
  urgency: 'NORMAL', deadline: '',
};

export default function JobListingsPage() {
  const [jobs, setJobs] = useState<JobListing[]>([]);
  const [employers, setEmployers] = useState<Employer[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [jobTypeFilter, setJobTypeFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: '20' });
      if (search) params.set('search', search);
      if (categoryFilter) params.set('category', categoryFilter);
      if (statusFilter) params.set('status', statusFilter);
      if (jobTypeFilter) params.set('jobType', jobTypeFilter);
      const res = await fetch(`/api/crm/employment/job-listings?${params}`);
      const data = await res.json();
      setJobs(data?.داده‌ها || []);
      setTotal(data?.صفحه‌بندی?.کل || 0);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, [page, search, categoryFilter, statusFilter, jobTypeFilter]);

  const fetchEmployers = async () => {
    try {
      const res = await fetch('/api/crm/employment/employers?limit=100');
      const data = await res.json();
      setEmployers(data?.داده‌ها || []);
    } catch (e) { console.error(e); }
  };

  useEffect(() => { fetchJobs(); }, [fetchJobs]);
  useEffect(() => { fetchEmployers(); }, []);

  const handleSave = async () => {
    const body = {
      ...form,
      salaryMin: form.salaryMin ? parseInt(form.salaryMin) : null,
      salaryMax: form.salaryMax ? parseInt(form.salaryMax) : null,
      deadline: form.deadline || null,
    };
    const url = editId ? `/api/crm/employment/job-listings/${editId}` : '/api/crm/employment/job-listings';
    const method = editId ? 'PATCH' : 'POST';
    await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    setDialogOpen(false); setEditId(null); setForm(emptyForm); fetchJobs();
  };

  const handleStatusChange = async (id: string, status: string) => {
    await fetch(`/api/crm/employment/job-listings/${id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    fetchJobs();
  };

  const openEdit = (job: JobListing) => {
    setEditId(job.id);
    setForm({
      employerId: job.employerId, title: job.title, description: job.description,
      category: job.category, jobType: job.jobType, experienceLevel: job.experienceLevel,
      salaryMin: job.salaryMin?.toString() || '', salaryMax: job.salaryMax?.toString() || '',
      requiredSkills: job.requiredSkills, requiredEducation: '', benefits: '',
      city: job.city, isRemote: job.isRemote, urgency: job.urgency,
      deadline: job.deadline ? job.deadline.split('T')[0] : '',
    });
    setDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">فرصت‌های شغلی</h1>
          <p className="text-sm text-gray-500 mt-1">مدیریت آگهی‌ها و موقعیت‌های شغلی</p>
        </div>
        <Button onClick={() => { setForm(emptyForm); setEditId(null); setDialogOpen(true); }} className="gap-2">
          <Plus className="h-4 w-4" /> افزودن فرصت شغلی
        </Button>
      </div>

      <Card>
        <CardContent className="p-4 flex flex-wrap gap-3 items-center">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input placeholder="جستجوی عنوان، مهارت..." value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }} className="pr-9" />
          </div>
          <Select value={categoryFilter || 'ALL'} onValueChange={v => { setCategoryFilter(v === 'ALL' ? '' : v); setPage(1); }}>
            <SelectTrigger className="w-36"><SelectValue placeholder="دسته‌بندی" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">همه</SelectItem>
              <SelectItem value="tech-ai">فناوری و AI</SelectItem>
              <SelectItem value="financial">بازارهای مالی</SelectItem>
              <SelectItem value="management">مدیریت</SelectItem>
              <SelectItem value="other">سایر</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter || 'ALL'} onValueChange={v => { setStatusFilter(v === 'ALL' ? '' : v); setPage(1); }}>
            <SelectTrigger className="w-32"><SelectValue placeholder="وضعیت" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">همه</SelectItem>
              <SelectItem value="ACTIVE">فعال</SelectItem>
              <SelectItem value="PAUSED">مکث</SelectItem>
              <SelectItem value="CLOSED">بسته</SelectItem>
              <SelectItem value="DRAFT">پیش‌نویس</SelectItem>
            </SelectContent>
          </Select>
          <Select value={jobTypeFilter || 'ALL'} onValueChange={v => { setJobTypeFilter(v === 'ALL' ? '' : v); setPage(1); }}>
            <SelectTrigger className="w-32"><SelectValue placeholder="نوع" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">همه</SelectItem>
              <SelectItem value="FULL_TIME">تمام‌وقت</SelectItem>
              <SelectItem value="PART_TIME">پاره‌وقت</SelectItem>
              <SelectItem value="CONTRACT">قراردادی</SelectItem>
              <SelectItem value="REMOTE">دورکاری</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="text-right p-3 font-medium text-gray-600">عنوان</th>
                  <th className="text-right p-3 font-medium text-gray-600">کارفرما</th>
                  <th className="text-right p-3 font-medium text-gray-600">نوع</th>
                  <th className="text-right p-3 font-medium text-gray-600">دسته</th>
                  <th className="text-right p-3 font-medium text-gray-600">شهر</th>
                  <th className="text-right p-3 font-medium text-gray-600">وضعیت</th>
                  <th className="text-right p-3 font-medium text-gray-600">درخواست</th>
                  <th className="text-right p-3 font-medium text-gray-600">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={8} className="text-center p-8 text-gray-400">در حال بارگذاری...</td></tr>
                ) : jobs.length === 0 ? (
                  <tr><td colSpan={8} className="text-center p-8 text-gray-400">فرصت شغلی یافت نشد</td></tr>
                ) : jobs.map(job => {
                  const st = statusLabels[job.status] || { l: job.status, c: 'bg-gray-100' };
                  return (
                    <tr key={job.id} className="border-b hover:bg-gray-50">
                      <td className="p-3 font-medium max-w-[200px] truncate">
                        <div>{job.title}</div>
                        {job.isRemote && <Badge className="bg-blue-50 text-blue-700 text-xs mt-1" variant="secondary">دورکاری</Badge>}
                      </td>
                      <td className="p-3">{job.employer?.companyName || '-'}</td>
                      <td className="p-3">{jobTypeLabels[job.jobType] || job.jobType}</td>
                      <td className="p-3">{categoryLabels[job.category] || job.category}</td>
                      <td className="p-3">{job.city}</td>
                      <td className="p-3"><Badge className={st.c} variant="secondary">{st.l}</Badge></td>
                      <td className="p-3">{job._count?.applications || job.applicationCount}</td>
                      <td className="p-3">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" onClick={() => openEdit(job)}><Edit2 className="h-4 w-4" /></Button>
                          {job.status === 'ACTIVE' && (
                            <Button variant="ghost" size="icon" onClick={() => handleStatusChange(job.id, 'CLOSED')} title="بستن">
                              <XCircle className="h-4 w-4 text-red-500" />
                            </Button>
                          )}
                          {job.status === 'CLOSED' && (
                            <Button variant="ghost" size="icon" onClick={() => handleStatusChange(job.id, 'ACTIVE')} title="بازگشایی">
                              <RotateCcw className="h-4 w-4 text-green-500" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {total > 20 && (
            <div className="flex items-center justify-between p-3 border-t">
              <span className="text-xs text-gray-500">نمایش {((page - 1) * 20) + 1} تا {Math.min(page * 20, total)} از {total}</span>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>قبلی</Button>
                <Button variant="outline" size="sm" disabled={page * 20 >= total} onClick={() => setPage(p => p + 1)}>بعدی</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editId ? 'ویرایش فرصت شغلی' : 'افزودن فرصت شغلی'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 max-h-[60vh] overflow-y-auto p-1">
            <div className="col-span-2"><Label>کارفرما *</Label>
              <Select value={form.employerId} onValueChange={v => setForm({ ...form, employerId: v })}>
                <SelectTrigger><SelectValue placeholder="انتخاب کارفرما" /></SelectTrigger>
                <SelectContent>{employers.map(e => <SelectItem key={e.id} value={e.id}>{e.companyName}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="col-span-2"><Label>عنوان شغل *</Label><Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} /></div>
            <div className="col-span-2"><Label>توضیحات *</Label><Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={3} /></div>
            <div><Label>دسته‌بندی</Label>
              <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="tech-ai">فناوری و AI</SelectItem>
                  <SelectItem value="financial">بازارهای مالی</SelectItem>
                  <SelectItem value="management">مدیریت</SelectItem>
                  <SelectItem value="other">سایر</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>نوع شغل</Label>
              <Select value={form.jobType} onValueChange={v => setForm({ ...form, jobType: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(jobTypeLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label>سطح تجربه</Label>
              <Select value={form.experienceLevel} onValueChange={v => setForm({ ...form, experienceLevel: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(expLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label>شهر</Label><Input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
            <div><Label>حداقل حقوق (ریال)</Label><Input type="number" value={form.salaryMin} onChange={e => setForm({ ...form, salaryMin: e.target.value })} /></div>
            <div><Label>حداکثر حقوق (ریال)</Label><Input type="number" value={form.salaryMax} onChange={e => setForm({ ...form, salaryMax: e.target.value })} /></div>
            <div><Label>مهارت‌های مورد نیاز</Label><Input value={form.requiredSkills} onChange={e => setForm({ ...form, requiredSkills: e.target.value })} placeholder="با کاما جدا کنید" /></div>
            <div><Label>مزایا</Label><Input value={form.benefits} onChange={e => setForm({ ...form, benefits: e.target.value })} placeholder="با کاما جدا کنید" /></div>
            <div><Label>مهلت ارسال رزومه</Label><Input type="date" value={form.deadline} onChange={e => setForm({ ...form, deadline: e.target.value })} /></div>
            <div className="flex items-center gap-2 pt-6"><input type="checkbox" checked={form.isRemote} onChange={e => setForm({ ...form, isRemote: e.target.checked })} /><Label>امکان دورکاری</Label></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>انصراف</Button>
            <Button onClick={handleSave}>{editId ? 'بروزرسانی' : 'ثبت'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
