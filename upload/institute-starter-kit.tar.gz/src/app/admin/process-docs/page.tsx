'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  GitBranch, Plus, Loader2, Trash2, Pencil, Eye, X,
  Package, ArrowRight, Users, Settings, BarChart3, Shield,
  RefreshCw, AlertTriangle, CheckCircle2, ChevronDown, ChevronUp,
  FileText, ArrowLeftRight, TrendingUp, BookOpen,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ═══════════════════════════════════════════════════════
   Types
   ═══════════════════════════════════════════════════════ */

interface ProcessStep {
  title: string;
  description: string;
}

interface ProcessDoc {
  id: string;
  name: string;
  description: string;
  category: string;
  isoClause: string;
  version: number;
  isActive: boolean;
  owner: string;
  department: string;
  supplier: string;
  inputs: string;
  processSteps: string;
  outputs: string;
  customers: string;
  feedbackMethods: string;
  kpis: string;
  risks: string;
  lastReviewedAt: string | null;
  reviewedBy: string;
  createdAt: string;
  updatedAt: string;
}

interface FormData {
  name: string;
  description: string;
  category: string;
  isoClause: string;
  owner: string;
  department: string;
  supplier: string;
  inputs: string;
  processSteps: ProcessStep[];
  outputs: string;
  customers: string;
  feedbackMethods: string;
  kpis: string[];
  risks: string[];
}

const CATEGORIES: Record<string, { label: string; color: string }> = {
  enrollment: { label: 'ثبت‌نام و ارزیابی', color: 'bg-blue-100 text-blue-700' },
  training: { label: 'آموزش و تدریس', color: 'bg-emerald-100 text-emerald-700' },
  assessment: { label: 'آزمون و سنجش', color: 'bg-purple-100 text-purple-700' },
  certification: { label: 'گواهینامه و صدور', color: 'bg-amber-100 text-amber-700' },
  support: { label: 'پشتیبانی و مشاوره', color: 'bg-pink-100 text-pink-700' },
  general: { label: 'عمومی', color: 'bg-gray-100 text-gray-700' },
};

const emptyForm: FormData = {
  name: '', description: '', category: 'general', isoClause: '4.4',
  owner: '', department: '', supplier: '', inputs: '',
  processSteps: [], outputs: '', customers: '',
  feedbackMethods: '', kpis: [], risks: [],
};

/* ═══════════════════════════════════════════════════════
   SIPOC Flowchart Component
   ═══════════════════════════════════════════════════════ */

function SIPOCFlowchart({ doc, compact = false }: { doc: ProcessDoc; compact?: boolean }) {
  const steps: ProcessStep[] = (() => { try { return JSON.parse(doc.processSteps); } catch { return []; } })();
  const risks: string[] = (() => { try { return JSON.parse(doc.risks); } catch { return []; } })();
  const kpis: string[] = (() => { try { return JSON.parse(doc.kpis); } catch { return []; } })();

  const sipocItems = [
    { label: 'تأمین‌کننده', sublabel: 'Supplier', value: doc.supplier, icon: Package, color: 'from-sky-500 to-blue-600', bg: 'bg-sky-50 border-sky-200' },
    { label: 'ورودی‌ها', sublabel: 'Inputs', value: doc.inputs, icon: ArrowRight, color: 'from-violet-500 to-purple-600', bg: 'bg-violet-50 border-violet-200' },
    { label: 'فرآیند', sublabel: 'Process', value: steps.length > 0 ? steps.map(s => s.title).join(' ← ') : doc.description, icon: Settings, color: 'from-rose-500 to-red-600', bg: 'bg-rose-50 border-rose-200', isProcess: true, steps },
    { label: 'خروجی‌ها', sublabel: 'Outputs', value: doc.outputs, icon: CheckCircle2, color: 'from-emerald-500 to-green-600', bg: 'bg-emerald-50 border-emerald-200' },
    { label: 'مشتریان', sublabel: 'Customers', value: doc.customers, icon: Users, color: 'from-amber-500 to-orange-600', bg: 'bg-amber-50 border-amber-200' },
  ];

  if (compact) {
    return (
      <div className="flex items-center gap-1 overflow-x-auto pb-2" dir="ltr">
        {sipocItems.map((item, idx) => (
          <div key={idx} className="flex items-center gap-1 flex-shrink-0">
            <div className={`px-3 py-1.5 rounded-lg border ${item.bg} max-w-[140px]`}>
              <p className="text-[10px] font-bold text-gray-500">{item.label}</p>
              <p className="text-[11px] text-gray-700 truncate">{item.value || '—'}</p>
            </div>
            {idx < sipocItems.length - 1 && (
              <ArrowRight className="h-3 w-3 text-gray-400 flex-shrink-0" />
            )}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Main SIPOC Flow */}
      <div className="flex items-stretch gap-2 overflow-x-auto pb-3" dir="ltr">
        {sipocItems.map((item, idx) => (
          <div key={idx} className="flex items-center gap-2 flex-shrink-0">
            <div className={`rounded-xl border-2 p-4 w-52 ${item.bg} relative`}>
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center`}>
                  <item.icon className="h-4 w-4 text-white" />
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-800">{item.label}</p>
                  <p className="text-[10px] text-gray-400">{item.sublabel}</p>
                </div>
              </div>
              {item.isProcess && steps.length > 0 ? (
                <div className="space-y-1.5 mt-2">
                  {steps.map((step, si) => (
                    <div key={si} className="flex items-start gap-1.5">
                      <div className="w-5 h-5 rounded-full bg-gradient-to-br from-rose-500 to-red-500 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                        {si + 1}
                      </div>
                      <div>
                        <p className="text-xs font-medium text-gray-800">{step.title}</p>
                        {step.description && <p className="text-[10px] text-gray-500">{step.description}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-gray-600 leading-relaxed mt-2 whitespace-pre-wrap">{item.value || 'تعریف نشده'}</p>
              )}
            </div>
            {idx < sipocItems.length - 1 && (
              <ArrowRight className="h-5 w-5 text-gray-400 flex-shrink-0 self-center" />
            )}
          </div>
        ))}
      </div>

      {/* Feedback Loop Arrow */}
      <div className="relative bg-gradient-to-l from-emerald-50 to-sky-50 border border-emerald-200 rounded-xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <RefreshCw className="h-4 w-4 text-emerald-600" />
          <p className="text-sm font-bold text-gray-700">حلقه بازخورد و بهبود مستمر</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { icon: BarChart3, label: 'تحلیل آماری', value: kpis.length > 0 ? kpis.join('، ') : 'تعریف نشده' },
            { icon: FileText, label: 'مستندسازی', value: doc.feedbackMethods || 'تعریف نشده' },
            { icon: TrendingUp, label: 'بهبود مستمر', value: `نسخه ${toPersianNumber(doc.version)}` },
            { icon: BookOpen, label: 'بازبینی', value: doc.lastReviewedAt ? new Date(doc.lastReviewedAt).toLocaleDateString('fa-IR') : 'بازبینی نشده' },
          ].map((item, idx) => (
            <div key={idx} className="flex items-start gap-2">
              <item.icon className="h-4 w-4 text-emerald-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-[10px] font-bold text-gray-500">{item.label}</p>
                <p className="text-xs text-gray-700">{item.value}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Risks Section */}
      {risks.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="h-4 w-4 text-red-500" />
            <p className="text-sm font-bold text-red-700">مضرات عدم مدیریت این فرآیند</p>
          </div>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-1">
            {risks.map((risk, idx) => (
              <li key={idx} className="flex items-start gap-1.5 text-xs text-red-600">
                <X className="h-3 w-3 mt-0.5 flex-shrink-0" />
                {risk}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   Form Dialog Component
   ═══════════════════════════════════════════════════════ */

function ProcessFormDialog({
  open, onClose, onSave, initial, isEdit,
}: {
  open: boolean; onClose: () => void; onSave: (data: FormData) => void;
  initial: FormData; isEdit: boolean;
}) {
  const [form, setForm] = useState<FormData>(initial);
  const [saving, setSaving] = useState(false);
  const [stepInput, setStepInput] = useState({ title: '', description: '' });
  const [kpiInput, setKpiInput] = useState('');
  const [riskInput, setRiskInput] = useState('');

  useEffect(() => { setForm(initial); }, [initial, open]);

  const set = (key: keyof FormData, val: string | boolean | ProcessStep[] | string[]) =>
    setForm(prev => ({ ...prev, [key]: val }));

  const addStep = () => {
    if (!stepInput.title.trim()) return;
    set('processSteps', [...form.processSteps, { ...stepInput }]);
    setStepInput({ title: '', description: '' });
  };

  const removeStep = (idx: number) => {
    set('processSteps', form.processSteps.filter((_, i) => i !== idx));
  };

  const addKpi = () => {
    if (!kpiInput.trim()) return;
    set('kpis', [...form.kpis, kpiInput.trim()]);
    setKpiInput('');
  };

  const removeKpi = (idx: number) => {
    set('kpis', form.kpis.filter((_, i) => i !== idx));
  };

  const addRisk = () => {
    if (!riskInput.trim()) return;
    set('risks', [...form.risks, riskInput.trim()]);
    setRiskInput('');
  };

  const removeRisk = (idx: number) => {
    set('risks', form.risks.filter((_, i) => i !== idx));
  };

  const handleSave = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    await onSave(form);
    setSaving(false);
  };

  const siopcFields = [
    { key: 'supplier' as const, label: 'تأمین‌کننده (S)', placeholder: 'منابع و ورودی‌های مورد نیاز...', hint: 'چه کسانی/سیستم‌هایی داده و منابع را تأمین می‌کنند؟' },
    { key: 'inputs' as const, label: 'ورودی‌ها (I)', placeholder: 'داده‌ها و اطلاعات مورد نیاز...', hint: 'دقیقاً چه چیزهایی وارد فرآیند می‌شود؟' },
    { key: 'outputs' as const, label: 'خروجی‌ها (O)', placeholder: 'نتایج و محصولات تولیدشده...', hint: 'دقیقاً چه چیزهایی خروجی فرآیند است؟' },
    { key: 'customers' as const, label: 'مشتریان/ذی‌نفعان (C)', placeholder: 'مستخدمین نهایی یا ذی‌نفعان...', hint: 'چه کسانی از خروجی‌ها بهره‌مند می‌شوند؟' },
  ];

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitBranch className="h-5 w-5 text-teal-600" />
            {isEdit ? 'ویرایش فرآیند' : 'فرآیند جدید — ISO 9001:2015'}
          </DialogTitle>
          <DialogDescription>
            مستندسازی فرآیند بر اساس مدل SIPOC (بند 4.4 استاندارد ISO 9001:2015)
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 mt-2">
          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Label>نام فرآیند *</Label>
              <Input value={form.name} onChange={e => set('name', e.target.value)} placeholder="مثلاً: فرآیند ثبت‌نام و ارزیابی اولیه" />
            </div>
            <div>
              <Label>دسته‌بندی</Label>
              <Select value={form.category} onValueChange={v => set('category', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORIES).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>بند ISO</Label>
              <Input value={form.isoClause} onChange={e => set('isoClause', e.target.value)} placeholder="4.4" />
            </div>
            <div>
              <Label>مسئول / مالک فرآیند</Label>
              <Input value={form.owner} onChange={e => set('owner', e.target.value)} placeholder="نام مسئول" />
            </div>
            <div>
              <Label>واحد سازمانی</Label>
              <Input value={form.department} onChange={e => set('department', e.target.value)} placeholder="مثلاً: آموزش، CRM" />
            </div>
            <div className="col-span-2">
              <Label>توضیحات</Label>
              <Textarea value={form.description} onChange={e => set('description', e.target.value)} placeholder="توضیح کلی فرآیند..." rows={2} />
            </div>
          </div>

          {/* SIPOC Section */}
          <div className="border border-gray-200 rounded-xl p-4 space-y-3">
            <div className="flex items-center gap-2 mb-1">
              <ArrowLeftRight className="h-4 w-4 text-teal-600" />
              <p className="text-sm font-bold text-gray-700">مدل SIPOC</p>
              <Badge variant="outline" className="text-[10px]">ISO 9001 Clause 4.4</Badge>
            </div>

            {siopcFields.map(f => (
              <div key={f.key}>
                <Label className="text-xs font-bold">{f.label}</Label>
                <p className="text-[10px] text-gray-400 mb-1">{f.hint}</p>
                <Textarea
                  value={form[f.key]}
                  onChange={e => set(f.key, e.target.value)}
                  placeholder={f.placeholder}
                  rows={2}
                />
              </div>
            ))}

            {/* Process Steps */}
            <div>
              <Label className="text-xs font-bold">مراحل فرآیند (P)</Label>
              <p className="text-[10px] text-gray-400 mb-2">فعالیت‌هایی که ورودی‌ها را به خروجی‌ها تبدیل می‌کنند</p>
              <div className="flex gap-2 mb-2">
                <Input
                  value={stepInput.title}
                  onChange={e => setStepInput(p => ({ ...p, title: e.target.value }))}
                  placeholder="عنوان مرحله"
                  className="flex-1"
                  onKeyDown={e => e.key === 'Enter' && addStep()}
                />
                <Input
                  value={stepInput.description}
                  onChange={e => setStepInput(p => ({ ...p, description: e.target.value }))}
                  placeholder="توضیح (اختیاری)"
                  className="flex-1"
                  onKeyDown={e => e.key === 'Enter' && addStep()}
                />
                <Button variant="outline" size="sm" onClick={addStep}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {form.processSteps.length > 0 && (
                <div className="space-y-1.5">
                  {form.processSteps.map((step, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-gray-50 rounded-lg p-2">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-rose-500 to-red-500 text-white text-xs font-bold flex items-center justify-center flex-shrink-0">
                        {idx + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-800">{step.title}</p>
                        {step.description && <p className="text-[10px] text-gray-500">{step.description}</p>}
                      </div>
                      <button onClick={() => removeStep(idx)} className="text-gray-400 hover:text-red-500">
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Feedback & Improvement */}
          <div className="border border-emerald-200 rounded-xl p-4 space-y-3 bg-emerald-50/50">
            <div className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4 text-emerald-600" />
              <p className="text-sm font-bold text-gray-700">حلقه بازخورد و بهبود مستمر</p>
            </div>

            <div>
              <Label className="text-xs font-bold">روش‌های بازخورد</Label>
              <Textarea value={form.feedbackMethods} onChange={e => set('feedbackMethods', e.target.value)} placeholder="نظرسنجی، تحلیل آماری، ارزیابی دوره‌ای..." rows={2} />
            </div>

            {/* KPIs */}
            <div>
              <Label className="text-xs font-bold">شاخص‌های کلیدی عملکرد (KPI)</Label>
              <div className="flex gap-2 mt-1">
                <Input
                  value={kpiInput}
                  onChange={e => setKpiInput(e.target.value)}
                  placeholder="مثلاً: نرخ رضایت مشتری > 80%"
                  className="flex-1"
                  onKeyDown={e => e.key === 'Enter' && addKpi()}
                />
                <Button variant="outline" size="sm" onClick={addKpi}><Plus className="h-4 w-4" /></Button>
              </div>
              {form.kpis.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {form.kpis.map((kpi, idx) => (
                    <Badge key={idx} variant="secondary" className="gap-1 pr-1">
                      {kpi}
                      <button onClick={() => removeKpi(idx)} className="hover:text-red-500"><X className="h-3 w-3" /></button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Risks */}
          <div className="border border-red-200 rounded-xl p-4 space-y-3 bg-red-50/50">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-red-500" />
              <p className="text-sm font-bold text-red-700">مضرات عدم مدیریت این فرآیند</p>
            </div>
            <div className="flex gap-2">
              <Input
                value={riskInput}
                onChange={e => setRiskInput(e.target.value)}
                placeholder="مثلاً: عدم شفافیت در فرآیندها"
                className="flex-1"
                onKeyDown={e => e.key === 'Enter' && addRisk()}
              />
              <Button variant="outline" size="sm" onClick={addRisk}><Plus className="h-4 w-4" /></Button>
            </div>
            {form.risks.length > 0 && (
              <ul className="space-y-1">
                {form.risks.map((risk, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm text-red-600 bg-white rounded-lg p-2">
                    <X className="h-3 w-3 flex-shrink-0" />
                    {risk}
                    <button onClick={() => removeRisk(idx)} className="mr-auto text-gray-400 hover:text-red-500">
                      <X className="h-4 w-4" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button
            onClick={handleSave}
            disabled={!form.name.trim() || saving}
            className="bg-teal-600 hover:bg-teal-700"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin ml-2" />}
            {isEdit ? 'بروزرسانی' : 'ایجاد فرآیند'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ═══════════════════════════════════════════════════════
   Main Page Component
   ═══════════════════════════════════════════════════════ */

export default function ProcessDocsPage() {
  const [docs, setDocs] = useState<ProcessDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editDoc, setEditDoc] = useState<ProcessDoc | null>(null);
  const [viewDoc, setViewDoc] = useState<ProcessDoc | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchDocs = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const url = categoryFilter !== 'all' ? `/api/admin/process-docs?category=${categoryFilter}` : '/api/admin/process-docs';
      const res = await fetch(url);
      if (!res.ok) throw new Error();
      setDocs(await res.json());
    } catch {
      setError('خطا در دریافت فرآیندها');
    } finally {
      setLoading(false);
    }
  }, [categoryFilter]);

  useEffect(() => { fetchDocs(); }, [fetchDocs]);

  const handleCreate = async (data: FormData) => {
    try {
      const res = await fetch('/api/admin/process-docs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error();
      setDialogOpen(false);
      fetchDocs();
    } catch { setError('خطا در ایجاد فرآیند'); }
  };

  const handleUpdate = async (data: FormData) => {
    if (!editDoc) return;
    try {
      const res = await fetch(`/api/admin/process-docs/${editDoc.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, _bumpVersion: true }),
      });
      if (!res.ok) throw new Error();
      setEditDoc(null);
      setDialogOpen(false);
      fetchDocs();
    } catch { setError('خطا در بروزرسانی'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('آیا از حذف این فرآیند مطمئنید؟')) return;
    try {
      await fetch(`/api/admin/process-docs/${id}`, { method: 'DELETE' });
      fetchDocs();
    } catch { setError('خطا در حذف'); }
  };

  const toggleActive = async (doc: ProcessDoc) => {
    try {
      await fetch(`/api/admin/process-docs/${doc.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !doc.isActive }),
      });
      fetchDocs();
    } catch { /* ignore */ }
  };

  const openEdit = (doc: ProcessDoc) => {
    setEditDoc(doc);
    setDialogOpen(true);
  };

  const docToForm = (doc: ProcessDoc): FormData => ({
    name: doc.name,
    description: doc.description,
    category: doc.category,
    isoClause: doc.isoClause,
    owner: doc.owner,
    department: doc.department,
    supplier: doc.supplier,
    inputs: doc.inputs,
    processSteps: (() => { try { return JSON.parse(doc.processSteps); } catch { return []; } })(),
    outputs: doc.outputs,
    customers: doc.customers,
    feedbackMethods: doc.feedbackMethods,
    kpis: (() => { try { return JSON.parse(doc.kpis); } catch { return []; } })(),
    risks: (() => { try { return JSON.parse(doc.risks); } catch { return []; } })(),
  });

  const activeCount = docs.filter(d => d.isActive).length;
  const categoryCounts = Object.fromEntries(
    Object.keys(CATEGORIES).map(c => [c, docs.filter(d => d.category === c).length])
  );

  return (
    <div className="space-y-5" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-teal-600 to-emerald-700 rounded-2xl p-5 text-white flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2">
            <GitBranch className="h-6 w-6" /> مستندسازی فرآیندها — ISO 9001:2015
          </h1>
          <p className="text-teal-100 text-sm mt-1">
            مدل SIPOC (بند 4.4) — شناسایی، مستندسازی، پایش و بهبود فرآیندهای سازمان
          </p>
        </div>
        <Button
          onClick={() => { setEditDoc(null); setDialogOpen(true); }}
          className="bg-white text-teal-700 hover:bg-teal-50 font-medium"
        >
          <Plus className="h-4 w-4 ml-1" /> فرآیند جدید
        </Button>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'کل فرآیندها', value: docs.length, icon: GitBranch, color: 'bg-teal-100 text-teal-600' },
          { label: 'فعال', value: activeCount, icon: CheckCircle2, color: 'bg-green-100 text-green-600' },
          { label: 'غیرفعال', value: docs.length - activeCount, icon: X, color: 'bg-gray-100 text-gray-600' },
          { label: 'نسخه‌ها', value: docs.reduce((s, d) => s + d.version, 0), icon: Shield, color: 'bg-blue-100 text-blue-600' },
        ].map((stat, idx) => (
          <div key={idx} className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-1">
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${stat.color}`}>
                <stat.icon className="h-3.5 w-3.5" />
              </div>
              <span className="text-xs text-gray-500">{stat.label}</span>
            </div>
            <p className="text-xl font-bold text-gray-800">{toPersianNumber(stat.value)}</p>
          </div>
        ))}
      </div>

      {/* Category Filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs font-bold text-gray-500">دسته‌بندی:</span>
        {[
          { key: 'all', label: 'همه' },
          ...Object.entries(CATEGORIES).map(([k, v]) => ({ key: k, label: v.label })),
        ].map(c => (
          <button
            key={c.key}
            onClick={() => setCategoryFilter(c.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              categoryFilter === c.key
                ? 'bg-teal-600 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {c.label}
            {c.key !== 'all' && categoryCounts[c.key] > 0 && (
              <span className="mr-1 opacity-70">({toPersianNumber(categoryCounts[c.key])})</span>
            )}
          </button>
        ))}
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-600 text-sm flex items-center gap-2">
          <AlertTriangle className="h-4 w-4" /> {error}
          <button onClick={fetchDocs} className="mr-auto text-xs underline">تلاش مجدد</button>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <Skeleton key={i} className="h-32 w-full rounded-xl" />
          ))}
        </div>
      )}

      {/* Process List */}
      {!loading && docs.length === 0 && (
        <div className="text-center py-16">
          <GitBranch className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">هنوز فرآیندی مستندسازی نشده</p>
          <Button variant="outline" className="mt-3" onClick={() => { setEditDoc(null); setDialogOpen(true); }}>
            <Plus className="h-4 w-4 ml-1" /> ایجاد اولین فرآیند
          </Button>
        </div>
      )}

      {!loading && docs.map(doc => {
        const cat = CATEGORIES[doc.category] || CATEGORIES.general;
        const isExpanded = expandedId === doc.id;

        return (
          <Card key={doc.id} className={`border-2 transition-all ${isExpanded ? 'border-teal-300 shadow-lg' : 'border-gray-100'} ${!doc.isActive ? 'opacity-60' : ''}`}>
            <CardContent className="p-4">
              {/* Row 1: Title & Actions */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center flex-shrink-0`}>
                    <GitBranch className="h-5 w-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm font-bold text-gray-800">{doc.name}</h3>
                      <Badge className={`text-[10px] ${cat.color}`}>{cat.label}</Badge>
                      <Badge variant="outline" className="text-[10px]">v{toPersianNumber(doc.version)}</Badge>
                      <Badge variant="outline" className="text-[10px]">ISO {doc.isoClause}</Badge>
                      {!doc.isActive && <Badge variant="secondary" className="text-[10px]">غیرفعال</Badge>}
                    </div>
                    {doc.description && <p className="text-xs text-gray-500 mt-0.5 truncate">{doc.description}</p>}
                    {doc.department && (
                      <p className="text-[10px] text-gray-400 mt-0.5">
                        {doc.owner && <span>مسئول: {doc.owner} | </span>}
                        واحد: {doc.department}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => setExpandedId(isExpanded ? null : doc.id)} className="p-2 hover:bg-gray-100 rounded-lg" title={isExpanded ? 'بستن' : 'نمایش SIPOC'}>
                    {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </button>
                  <button onClick={() => setViewDoc(doc)} className="p-2 hover:bg-sky-50 rounded-lg text-sky-600" title="مشاهده کامل">
                    <Eye className="h-4 w-4" />
                  </button>
                  <button onClick={() => openEdit(doc)} className="p-2 hover:bg-amber-50 rounded-lg text-amber-600" title="ویرایش">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button onClick={() => toggleActive(doc)} className="p-2 hover:bg-gray-100 rounded-lg" title={doc.isActive ? 'غیرفعال کردن' : 'فعال کردن'}>
                    <CheckCircle2 className={`h-4 w-4 ${doc.isActive ? 'text-green-500' : 'text-gray-300'}`} />
                  </button>
                  <button onClick={() => handleDelete(doc.id)} className="p-2 hover:bg-red-50 rounded-lg text-red-400" title="حذف">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Compact SIPOC Preview */}
              <div className="mt-3">
                <SIPOCFlowchart doc={doc} compact />
              </div>

              {/* Expanded: Full SIPOC */}
              {isExpanded && (
                <div className="mt-4 border-t border-gray-100 pt-4">
                  <SIPOCFlowchart doc={doc} />
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}

      {/* Form Dialog */}
      <ProcessFormDialog
        open={dialogOpen}
        onClose={() => { setDialogOpen(false); setEditDoc(null); }}
        onSave={editDoc ? handleUpdate : handleCreate}
        initial={editDoc ? docToForm(editDoc) : emptyForm}
        isEdit={!!editDoc}
      />

      {/* View Dialog */}
      <Dialog open={!!viewDoc} onOpenChange={(v) => !v && setViewDoc(null)}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto" dir="rtl">
          {viewDoc && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <GitBranch className="h-5 w-5 text-teal-600" />
                  {viewDoc.name}
                  <Badge variant="outline" className="text-xs">v{toPersianNumber(viewDoc.version)}</Badge>
                  <Badge variant="outline" className="text-xs">ISO {viewDoc.isoClause}</Badge>
                </DialogTitle>
                {viewDoc.description && <DialogDescription>{viewDoc.description}</DialogDescription>}
              </DialogHeader>
              <SIPOCFlowchart doc={viewDoc} />
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}