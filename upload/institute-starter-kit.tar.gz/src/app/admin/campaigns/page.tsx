'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Megaphone,
  Plus,
  Search,
  Loader2,
  AlertTriangle,
  X,
  Trash2,
  Eye,
  Play,
  Pause,
  CheckCircle2,
  Clock,
  DollarSign,
  BarChart3,
  Mail,
  MessageSquare,
  Instagram,
  Globe,
  Send,
  Users,
  TrendingUp,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface CampaignStage {
  day: number;
  subject: string;
  body: string;
  channel: string;
}

interface CampaignRecipient {
  id: string;
  leadId: string | null;
  karAmuzId: string | null;
  status: string;
  sentAt: string | null;
  openedAt: string | null;
  clickedAt: string | null;
  convertedAt: string | null;
  currentStage: number;
  nextStageAt: string | null;
  lead?: { id: string; name: string; phone: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string; phone: string } | null;
}

interface Campaign {
  id: string;
  name: string;
  description: string | null;
  type: string;
  channel: string;
  status: string;
  startDate: string | null;
  endDate: string | null;
  budget: number;
  spentAmount: number;
  targetSegment: string;
  targetCluster: string;
  utmCampaign: string;
  stages: CampaignStage[] | null;
  sentCount: number;
  deliveredCount: number;
  openCount: number;
  clickCount: number;
  conversionCount: number;
  bounceCount: number;
  adPlatform: string | null;
  adCostPerClick: number | null;
  adImpressions: number | null;
  adClicks: number | null;
  assignedTo: string;
  createdAt: string;
  updatedAt: string;
  _count?: { recipients: number };
  // Detail fields
  recipients?: CampaignRecipient[];
}

/* ─────────── Constants ─────────── */

const STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  DRAFT: { label: 'پیش‌نویس', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  SCHEDULED: { label: 'زمان‌بندی شده', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  RUNNING: { label: 'در اجرا', color: 'text-green-700', bgColor: 'bg-green-100' },
  PAUSED: { label: 'متوقف', color: 'text-yellow-700', bgColor: 'bg-yellow-100' },
  COMPLETED: { label: 'تکمیل شده', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  CANCELLED: { label: 'لغو شده', color: 'text-red-700', bgColor: 'bg-red-100' },
};

const CHANNEL_META: Record<string, { label: string; icon: React.ElementType; color: string; bgColor: string }> = {
  SMS: { label: 'پیامک', icon: MessageSquare, color: 'text-blue-700', bgColor: 'bg-blue-100' },
  EMAIL: { label: 'ایمیل', icon: Mail, color: 'text-purple-700', bgColor: 'bg-purple-100' },
  WHATSAPP: { label: 'واتساپ', icon: MessageSquare, color: 'text-green-700', bgColor: 'bg-green-100' },
  INSTAGRAM: { label: 'اینستاگرام', icon: Instagram, color: 'text-pink-700', bgColor: 'bg-pink-100' },
  GOOGLE_ADS: { label: 'گوگل ادز', icon: Globe, color: 'text-orange-700', bgColor: 'bg-orange-100' },
  TELEGRAM: { label: 'تلگرام', icon: Send, color: 'text-sky-700', bgColor: 'bg-sky-100' },
};

const TYPE_META: Record<string, { label: string; color: string; bgColor: string }> = {
  MULTI_STAGE: { label: 'چند مرحله‌ای', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  EMAIL: { label: 'ایمیل', color: 'text-purple-700', bgColor: 'bg-purple-100' },
  SMS: { label: 'پیامک', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  SOCIAL: { label: 'شبکه اجتماعی', color: 'text-pink-700', bgColor: 'bg-pink-100' },
  AD: { label: 'تبلیغات', color: 'text-orange-700', bgColor: 'bg-orange-100' },
};

const SEGMENT_OPTIONS = [
  { value: 'ALL', label: 'همه' },
  { value: 'NEW', label: 'جدید' },
  { value: 'VIP', label: 'VIP' },
  { value: 'AT_RISK', label: 'در خطر' },
  { value: 'LOYAL', label: 'وفادار' },
  { value: 'REGULAR', label: 'عادی' },
  { value: 'CHURNED', label: 'رها شده' },
];

const CLUSTER_OPTIONS = [
  { value: 'all', label: 'همه خوشه‌ها' },
  { value: 'tech-ai', label: 'فناوری و هوش مصنوعی' },
  { value: 'financial', label: 'مالی و حسابداری' },
  { value: 'management', label: 'مدیریت و بازاریابی' },
  { value: 'entrepreneurship', label: 'کارآفرینی' },
];

const CHANNEL_OPTIONS = [
  { value: 'SMS', label: 'پیامک' },
  { value: 'EMAIL', label: 'ایمیل' },
  { value: 'WHATSAPP', label: 'واتساپ' },
  { value: 'INSTAGRAM', label: 'اینستاگرام' },
  { value: 'GOOGLE_ADS', label: 'گوگل ادز' },
  { value: 'TELEGRAM', label: 'تلگرام' },
];

const TYPE_OPTIONS = [
  { value: 'MULTI_STAGE', label: 'چند مرحله‌ای' },
  { value: 'EMAIL', label: 'ایمیل' },
  { value: 'SMS', label: 'پیامک' },
  { value: 'SOCIAL', label: 'شبکه اجتماعی' },
  { value: 'AD', label: 'تبلیغات' },
];

const RECIPIENT_STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  PENDING: { label: 'در انتظار', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  SENT: { label: 'ارسال شده', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  DELIVERED: { label: 'تحویل شده', color: 'text-sky-700', bgColor: 'bg-sky-100' },
  OPENED: { label: 'باز شده', color: 'text-green-700', bgColor: 'bg-green-100' },
  CLICKED: { label: 'کلیک شده', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  CONVERTED: { label: 'تبدیل', color: 'text-emerald-700', bgColor: 'bg-emerald-100' },
  BOUNCED: { label: 'برگشتی', color: 'text-red-700', bgColor: 'bg-red-100' },
  FAILED: { label: 'ناموفق', color: 'text-red-700', bgColor: 'bg-red-100' },
};

/* ─────────── Helpers ─────────── */

function formatToman(amount: number) {
  const toman = Math.round(amount / 10);
  return toPersianNumber(toman.toLocaleString('en-US')) + ' تومان';
}

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function CampaignsPage() {
  /* ── State ── */
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterChannel, setFilterChannel] = useState<string>('all');

  // Add dialog
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formName, setFormName] = useState('');
  const [formType, setFormType] = useState('MULTI_STAGE');
  const [formChannel, setFormChannel] = useState('SMS');
  const [formTargetSegment, setFormTargetSegment] = useState('ALL');
  const [formTargetCluster, setFormTargetCluster] = useState('all');
  const [formBudget, setFormBudget] = useState(0);
  const [formStartDate, setFormStartDate] = useState('');
  const [formEndDate, setFormEndDate] = useState('');
  const [formStages, setFormStages] = useState<CampaignStage[]>([
    { day: 0, subject: '', body: '', channel: 'SMS' },
  ]);
  const [formAssignedTo, setFormAssignedTo] = useState('');

  // Edit dialog
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editCampaignId, setEditCampaignId] = useState('');
  const [editSubmitting, setEditSubmitting] = useState(false);

  // Delete confirmation
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteCampaignId, setDeleteCampaignId] = useState('');
  const [deleteSubmitting, setDeleteSubmitting] = useState(false);

  // Detail dialog
  const [detailCampaign, setDetailCampaign] = useState<Campaign | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [statusSubmitting, setStatusSubmitting] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);

  /* ── Data fetching ── */

  const fetchCampaigns = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (search) params.set('search', search);
      if (filterStatus && filterStatus !== 'all') params.set('status', filterStatus);
      if (filterChannel && filterChannel !== 'all') params.set('channel', filterChannel);

      const res = await fetch(`/api/crm/campaigns?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت کمپین‌ها');
        return;
      }

      setCampaigns(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterStatus, filterChannel]);

  useEffect(() => {
    fetchCampaigns();
  }, [fetchCampaigns]);

  /* ── Computed ── */

  const stats = useMemo(() => {
    const totalConversion = campaigns.reduce((sum, c) => sum + c.conversionCount, 0);
    const totalSent = campaigns.reduce((sum, c) => sum + c.sentCount, 0);
    return {
      total: campaigns.length,
      DRAFT: campaigns.filter(c => c.status === 'DRAFT').length,
      RUNNING: campaigns.filter(c => c.status === 'RUNNING').length,
      COMPLETED: campaigns.filter(c => c.status === 'COMPLETED').length,
      conversionRate: totalSent > 0 ? Math.round((totalConversion / totalSent) * 100) : 0,
    };
  }, [campaigns]);

  /* ── Stage editor handlers ── */

  const updateStage = (index: number, field: keyof CampaignStage, value: string | number) => {
    setFormStages(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const addStage = () => {
    const lastDay = formStages.length > 0 ? formStages[formStages.length - 1].day + 3 : 0;
    setFormStages(prev => [...prev, { day: lastDay, subject: '', body: '', channel: formChannel }]);
  };

  const removeStage = (index: number) => {
    if (formStages.length <= 1) return;
    setFormStages(prev => prev.filter((_, i) => i !== index));
  };

  /* ── Modal handlers ── */

  const openAddDialog = () => {
    setFormName('');
    setFormType('MULTI_STAGE');
    setFormChannel('SMS');
    setFormTargetSegment('ALL');
    setFormTargetCluster('all');
    setFormBudget(0);
    setFormStartDate('');
    setFormEndDate('');
    setFormStages([{ day: 0, subject: '', body: '', channel: 'SMS' }]);
    setFormAssignedTo('');
    setAddDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formName.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          type: formType,
          channel: formChannel,
          targetSegment: formTargetSegment,
          targetCluster: formTargetCluster,
          budget: formBudget,
          startDate: formStartDate || null,
          endDate: formEndDate || null,
          stages: formStages.some(s => s.subject.trim()) ? formStages : null,
          assignedTo: formAssignedTo || '',
        }),
      });

      if (res.ok) {
        setAddDialogOpen(false);
        fetchCampaigns();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const openDetail = async (campaign: Campaign) => {
    setDetailCampaign(campaign);
    setDetailDialogOpen(true);
    setDetailLoading(true);

    try {
      const res = await fetch(`/api/crm/campaigns/${campaign.id}`);
      const data = await res.json();
      if (res.ok) {
        setDetailCampaign(data['داده'] as Campaign);
      }
    } catch { /* silent */ } finally { setDetailLoading(false); }
  };

  const handleStatusChange = async (campaignId: string, newStatus: string) => {
    setStatusSubmitting(true);
    try {
      const res = await fetch('/api/crm/campaigns', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ campaignId, status: newStatus }),
      });

      if (res.ok) {
        const data = await res.json();
        const updatedCampaign = data['داده'] as Campaign;
        setDetailCampaign(updatedCampaign);
        fetchCampaigns();
      }
    } catch { /* silent */ } finally { setStatusSubmitting(false); }
  };

  const openEditDialog = (campaign: Campaign) => {
    setEditCampaignId(campaign.id);
    setFormName(campaign.name);
    setFormType(campaign.type);
    setFormChannel(campaign.channel);
    setFormTargetSegment(campaign.targetSegment || 'ALL');
    setFormTargetCluster(campaign.targetCluster || 'all');
    setFormBudget(campaign.budget);
    setFormStartDate(campaign.startDate ? campaign.startDate.split('T')[0] : '');
    setFormEndDate(campaign.endDate ? campaign.endDate.split('T')[0] : '');
    setFormStages(campaign.stages && campaign.stages.length > 0 ? campaign.stages : [{ day: 0, subject: '', body: '', channel: campaign.channel }]);
    setFormAssignedTo(campaign.assignedTo || '');
    setEditDialogOpen(true);
  };

  const handleEditSubmit = async () => {
    if (!formName.trim() || !editCampaignId) return;
    setEditSubmitting(true);
    try {
      const res = await fetch(`/api/crm/campaigns/${editCampaignId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          type: formType,
          channel: formChannel,
          targetSegment: formTargetSegment,
          targetCluster: formTargetCluster,
          budget: formBudget,
          startDate: formStartDate || null,
          endDate: formEndDate || null,
          stages: formStages.some(s => s.subject.trim() || s.body.trim()) ? formStages : null,
          assignedTo: formAssignedTo || '',
        }),
      });
      if (res.ok) {
        setEditDialogOpen(false);
        fetchCampaigns();
      }
    } catch { /* silent */ } finally { setEditSubmitting(false); }
  };

  const openDeleteDialog = (campaignId: string) => {
    setDeleteCampaignId(campaignId);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!deleteCampaignId) return;
    setDeleteSubmitting(true);
    try {
      const res = await fetch(`/api/crm/campaigns/${deleteCampaignId}`, { method: 'DELETE' });
      if (res.ok) {
        setDeleteDialogOpen(false);
        fetchCampaigns();
      }
    } catch { /* silent */ } finally { setDeleteSubmitting(false); }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Megaphone className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">کمپین‌های بازاریابی</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(stats.total)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت کمپین‌ها و بازاریابی</p>
          </div>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          کمپین جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">پیش‌نویس</p>
                <p className="text-2xl font-bold mt-1 text-gray-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.DRAFT)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-200">
                <Megaphone className="w-5 h-5 text-gray-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">در اجرا</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.RUNNING)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <Play className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">تکمیل شده</p>
                <p className="text-2xl font-bold mt-1 text-teal-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.COMPLETED)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                <CheckCircle2 className="w-5 h-5 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">نرخ تبدیل</p>
                <p className="text-2xl font-bold mt-1 text-purple-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : `${toPersianNumber(stats.conversionRate)}٪`}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200">
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="جستجوی نام کمپین یا UTM..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10 bg-white"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-40 bg-white">
            <SelectValue placeholder="وضعیت" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            {Object.entries(STATUS_META).map(([key, meta]) => (
              <SelectItem key={key} value={key}>
                {meta.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterChannel} onValueChange={setFilterChannel}>
          <SelectTrigger className="w-full sm:w-36 bg-white">
            <SelectValue placeholder="کانال" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه کانال‌ها</SelectItem>
            {CHANNEL_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Campaign Cards */}
      {loading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-56 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchCampaigns}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : campaigns.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Megaphone className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">کمپینی یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با ایجاد کمپین جدید شروع کنید
            </p>
            <Button
              onClick={openAddDialog}
              className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <Plus className="w-4 h-4" />
              کمپین جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {campaigns.map((campaign) => {
            const statusMeta = STATUS_META[campaign.status] || STATUS_META.DRAFT;
            const typeMeta = TYPE_META[campaign.type] || TYPE_META.MULTI_STAGE;
            const channelMeta = CHANNEL_META[campaign.channel] || CHANNEL_META.SMS;
            const ChannelIcon = channelMeta.icon;
            const budgetProgress = campaign.budget > 0 ? Math.min(100, Math.round((campaign.spentAmount / campaign.budget) * 100)) : 0;
            const sentTarget = campaign._count?.recipients || 0;
            const sentProgress = sentTarget > 0 ? Math.min(100, Math.round((campaign.sentCount / sentTarget) * 100)) : 0;

            return (
              <Card key={campaign.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-5">
                  {/* Header row: name + badges */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-gray-900 text-sm truncate">{campaign.name}</h3>
                      <p className="text-xs text-gray-400 mt-0.5 truncate">
                        {campaign.utmCampaign && `UTM: ${campaign.utmCampaign}`}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <Badge className={`${typeMeta.bgColor} ${typeMeta.color} text-xs border-0`}>
                        {typeMeta.label}
                      </Badge>
                      <Badge className={`${channelMeta.bgColor} ${channelMeta.color} text-xs border-0 flex items-center gap-1`}>
                        <ChannelIcon className="w-3 h-3" />
                        {channelMeta.label}
                      </Badge>
                    </div>
                  </div>

                  {/* Status */}
                  <div className="mb-3">
                    <Badge className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
                      {statusMeta.label}
                    </Badge>
                  </div>

                  {/* Budget row */}
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-gray-500">بودجه / خرج شده</span>
                    <span className="font-medium">
                      {campaign.budget > 0 ? (
                        <>
                          {formatToman(campaign.spentAmount)} / {formatToman(campaign.budget)}
                          <span className={`mr-1 ${budgetProgress > 80 ? 'text-red-600' : 'text-gray-500'}`}>
                            ({toPersianNumber(budgetProgress)}٪)
                          </span>
                        </>
                      ) : (
                        '—'
                      )}
                    </span>
                  </div>
                  {campaign.budget > 0 && (
                    <div className="w-full bg-gray-100 rounded-full h-1.5 mb-3">
                      <div
                        className={`h-1.5 rounded-full transition-all ${
                          budgetProgress > 80 ? 'bg-red-500' : budgetProgress > 50 ? 'bg-yellow-500' : 'bg-teal-500'
                        }`}
                        style={{ width: `${budgetProgress}%` }}
                      />
                    </div>
                  )}

                  {/* Stats row */}
                  <div className="grid grid-cols-5 gap-1 text-center mb-3 bg-gray-50 rounded-lg p-2">
                    <div>
                      <p className="text-xs text-gray-400">ارسال</p>
                      <p className="text-sm font-bold text-gray-700">{toPersianNumber(campaign.sentCount)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">تحویل</p>
                      <p className="text-sm font-bold text-blue-700">{toPersianNumber(campaign.deliveredCount)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">باز</p>
                      <p className="text-sm font-bold text-green-700">{toPersianNumber(campaign.openCount)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">کلیک</p>
                      <p className="text-sm font-bold text-teal-700">{toPersianNumber(campaign.clickCount)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">تبدیل</p>
                      <p className="text-sm font-bold text-purple-700">{toPersianNumber(campaign.conversionCount)}</p>
                    </div>
                  </div>

                  {/* Sent progress bar */}
                  {sentTarget > 0 && (
                    <div className="mb-3">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-gray-500">ارسال / هدف</span>
                        <span className="text-gray-600">{toPersianNumber(campaign.sentCount)} / {toPersianNumber(sentTarget)}</span>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-1.5">
                        <div
                          className="h-1.5 rounded-full bg-teal-500 transition-all"
                          style={{ width: `${sentProgress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Target info */}
                  <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
                    {campaign.targetSegment && campaign.targetSegment !== 'ALL' && (
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {SEGMENT_OPTIONS.find(s => s.value === campaign.targetSegment)?.label || campaign.targetSegment}
                      </span>
                    )}
                    {campaign.targetCluster && campaign.targetCluster !== 'all' && (
                      <span className="flex items-center gap-1">
                        <BarChart3 className="w-3 h-3" />
                        {CLUSTER_OPTIONS.find(c => c.value === campaign.targetCluster)?.label || campaign.targetCluster}
                      </span>
                    )}
                    {campaign.startDate && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatPersianDate(campaign.startDate)}
                        {campaign.endDate ? ` — ${formatPersianDate(campaign.endDate)}` : ''}
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between border-t border-gray-100 pt-3">
                    <div className="flex items-center gap-1">
                      {campaign.status === 'DRAFT' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 text-green-700 hover:text-green-800 hover:bg-green-50 gap-1 text-xs"
                          onClick={() => handleStatusChange(campaign.id, 'RUNNING')}
                          disabled={statusSubmitting}
                        >
                          <Play className="w-3 h-3" />
                          شروع
                        </Button>
                      )}
                      {campaign.status === 'RUNNING' && (
                        <>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 text-yellow-700 hover:text-yellow-800 hover:bg-yellow-50 gap-1 text-xs"
                            onClick={() => handleStatusChange(campaign.id, 'PAUSED')}
                            disabled={statusSubmitting}
                          >
                            <Pause className="w-3 h-3" />
                            توقف
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 text-teal-700 hover:text-teal-800 hover:bg-teal-50 gap-1 text-xs"
                            onClick={() => handleStatusChange(campaign.id, 'COMPLETED')}
                            disabled={statusSubmitting}
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            تکمیل
                          </Button>
                        </>
                      )}
                      {campaign.status === 'PAUSED' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 text-green-700 hover:text-green-800 hover:bg-green-50 gap-1 text-xs"
                          onClick={() => handleStatusChange(campaign.id, 'RUNNING')}
                          disabled={statusSubmitting}
                        >
                          <Play className="w-3 h-3" />
                          ادامه
                        </Button>
                      )}
                      {(campaign.status === 'DRAFT' || campaign.status === 'PAUSED' || campaign.status === 'CANCELLED') && (
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 text-blue-700 hover:text-blue-800 hover:bg-blue-50 gap-1 text-xs"
                          onClick={() => openEditDialog(campaign)}
                        >
                          <Eye className="w-3 h-3" />
                          ویرایش
                        </Button>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50 gap-1 text-xs"
                        onClick={() => openDetail(campaign)}
                      >
                        <Eye className="w-3 h-3" />
                        جزئیات
                      </Button>
                      {(campaign.status === 'DRAFT' || campaign.status === 'CANCELLED') && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 text-red-500 hover:text-red-700 hover:bg-red-50 gap-1 text-xs"
                          onClick={() => openDeleteDialog(campaign.id)}
                        >
                          <Trash2 className="w-3 h-3" />
                          حذف
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add Campaign Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Megaphone className="w-5 h-5 text-teal-600" />
              کمپین بازاریابی جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Name */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نام کمپین *</Label>
              <Input
                placeholder="نام کمپین..."
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
              />
            </div>

            {/* Type + Channel */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نوع</Label>
                <Select value={formType} onValueChange={setFormType}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPE_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">کانال</Label>
                <Select value={formChannel} onValueChange={setFormChannel}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CHANNEL_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Target Segment + Cluster */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">بخش هدف</Label>
                <Select value={formTargetSegment} onValueChange={setFormTargetSegment}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SEGMENT_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">خوشه هدف</Label>
                <Select value={formTargetCluster} onValueChange={setFormTargetCluster}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CLUSTER_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Budget + Assigned */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">بودجه (ریال)</Label>
                <Input
                  type="number"
                  min={0}
                  placeholder="بودجه..."
                  value={formBudget || ''}
                  onChange={(e) => setFormBudget(parseInt(e.target.value) || 0)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">مسئول</Label>
                <Input
                  placeholder="نام مسئول..."
                  value={formAssignedTo}
                  onChange={(e) => setFormAssignedTo(e.target.value)}
                />
              </div>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">تاریخ شروع</Label>
                <Input
                  type="date"
                  value={formStartDate}
                  onChange={(e) => setFormStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">تاریخ پایان</Label>
                <Input
                  type="date"
                  value={formEndDate}
                  onChange={(e) => setFormEndDate(e.target.value)}
                />
              </div>
            </div>

            {/* Stages Editor */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-bold">مراحل کمپین</Label>
                <Button variant="outline" size="sm" onClick={addStage} className="gap-1 text-xs">
                  <Plus className="w-3 h-3" />
                  افزودن مرحله
                </Button>
              </div>

              {formStages.map((stage, idx) => (
                <div key={idx} className="border rounded-lg p-3 space-y-2 bg-gray-50/50">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-500">مرحله {toPersianNumber(idx + 1)}</span>
                    {formStages.length > 1 && (
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500 hover:bg-red-50" onClick={() => removeStage(idx)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-xs text-gray-500">روز</Label>
                      <Input
                        type="number"
                        min={0}
                        value={stage.day}
                        onChange={(e) => updateStage(idx, 'day', parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">کانال</Label>
                      <Select value={stage.channel} onValueChange={(v) => updateStage(idx, 'channel', v)}>
                        <SelectTrigger className="bg-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {CHANNEL_OPTIONS.map((opt) => (
                            <SelectItem key={opt.value} value={opt.value}>
                              {opt.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">موضوع</Label>
                      <Input
                        placeholder="موضوع پیام"
                        value={stage.subject}
                        onChange={(e) => updateStage(idx, 'subject', e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-gray-500">متن پیام</Label>
                    <Textarea
                      placeholder="متن پیام..."
                      value={stage.body}
                      onChange={(e) => updateStage(idx, 'body', e.target.value)}
                      rows={2}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !formName.trim()}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ثبت کمپین
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
          {detailCampaign && (() => {
            const statusMeta = STATUS_META[detailCampaign.status] || STATUS_META.DRAFT;
            const typeMeta = TYPE_META[detailCampaign.type] || TYPE_META.MULTI_STAGE;
            const channelMeta = CHANNEL_META[detailCampaign.channel] || CHANNEL_META.SMS;
            const ChannelIcon = channelMeta.icon;
            const stages = detailCampaign.stages || [];
            const recipients = detailCampaign.recipients || [];
            const convRate = detailCampaign.sentCount > 0
              ? Math.round((detailCampaign.conversionCount / detailCampaign.sentCount) * 100)
              : 0;

            return (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2 text-right">
                    <Megaphone className="w-5 h-5 text-teal-600" />
                    {detailCampaign.name}
                  </DialogTitle>
                </DialogHeader>

                <div className="space-y-4 py-2">
                  {/* Badges */}
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge className={`${statusMeta.bgColor} ${statusMeta.color} text-sm border-0`}>
                      {statusMeta.label}
                    </Badge>
                    <Badge className={`${typeMeta.bgColor} ${typeMeta.color} text-sm border-0`}>
                      {typeMeta.label}
                    </Badge>
                    <Badge className={`${channelMeta.bgColor} ${channelMeta.color} text-sm border-0 flex items-center gap-1`}>
                      <ChannelIcon className="w-3.5 h-3.5" />
                      {channelMeta.label}
                    </Badge>
                    {detailCampaign.utmCampaign && (
                      <Badge variant="outline" className="text-xs">UTM: {detailCampaign.utmCampaign}</Badge>
                    )}
                  </div>

                  {/* Campaign Stats */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="text-sm font-bold text-gray-700 mb-3">آمار کمپین</h3>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-gray-900">{toPersianNumber(detailCampaign.sentCount)}</p>
                        <p className="text-xs text-gray-500">ارسال</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-blue-700">{toPersianNumber(detailCampaign.deliveredCount)}</p>
                        <p className="text-xs text-gray-500">تحویل</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-green-700">{toPersianNumber(detailCampaign.openCount)}</p>
                        <p className="text-xs text-gray-500">باز شده</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-teal-700">{toPersianNumber(detailCampaign.clickCount)}</p>
                        <p className="text-xs text-gray-500">کلیک</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-purple-700">{toPersianNumber(detailCampaign.conversionCount)}</p>
                        <p className="text-xs text-gray-500">تبدیل</p>
                      </div>
                      <div className="text-center">
                        <p className="text-2xl font-bold text-red-700">{toPersianNumber(detailCampaign.bounceCount)}</p>
                        <p className="text-xs text-gray-500">برگشتی</p>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-200 flex items-center justify-between">
                      <span className="text-sm text-gray-600">نرخ تبدیل:</span>
                      <span className="text-lg font-bold text-purple-700">{toPersianNumber(convRate)}٪</span>
                    </div>
                  </div>

                  {/* Budget & Dates */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="text-xs text-gray-500 mb-1">بودجه</p>
                      <p className="text-sm font-bold">{detailCampaign.budget > 0 ? formatToman(detailCampaign.budget) : '—'}</p>
                      {detailCampaign.spentAmount > 0 && (
                        <p className="text-xs text-gray-500 mt-0.5">خرج شده: {formatToman(detailCampaign.spentAmount)}</p>
                      )}
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="text-xs text-gray-500 mb-1">بازه زمانی</p>
                      <p className="text-sm font-bold">
                        {detailCampaign.startDate ? formatPersianDate(detailCampaign.startDate) : '—'}
                        {detailCampaign.endDate ? ` — ${formatPersianDate(detailCampaign.endDate)}` : ''}
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        هدف: {SEGMENT_OPTIONS.find(s => s.value === detailCampaign.targetSegment)?.label || 'همه'}
                        {detailCampaign.targetCluster && detailCampaign.targetCluster !== 'all' && (
                          <span> / {CLUSTER_OPTIONS.find(c => c.value === detailCampaign.targetCluster)?.label}</span>
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Ad Metrics */}
                  {(detailCampaign.adPlatform || detailCampaign.adImpressions) && (
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                      <h3 className="text-sm font-bold text-orange-700 mb-2 flex items-center gap-1.5">
                        <DollarSign className="w-4 h-4" />
                        متریک‌های تبلیغات
                      </h3>
                      <div className="grid grid-cols-3 gap-3 text-sm">
                        {detailCampaign.adPlatform && (
                          <div>
                            <span className="text-xs text-gray-500">پلتفرم:</span>
                            <span className="font-medium mr-1">{detailCampaign.adPlatform}</span>
                          </div>
                        )}
                        {detailCampaign.adImpressions != null && (
                          <div>
                            <span className="text-xs text-gray-500">نمایش:</span>
                            <span className="font-medium mr-1">{toPersianNumber(detailCampaign.adImpressions)}</span>
                          </div>
                        )}
                        {detailCampaign.adClicks != null && (
                          <div>
                            <span className="text-xs text-gray-500">کلیک:</span>
                            <span className="font-medium mr-1">{toPersianNumber(detailCampaign.adClicks)}</span>
                          </div>
                        )}
                        {detailCampaign.adCostPerClick != null && (
                          <div>
                            <span className="text-xs text-gray-500">هزینه هر کلیک:</span>
                            <span className="font-medium mr-1">{toPersianNumber(detailCampaign.adCostPerClick)}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Stages */}
                  {stages.length > 0 && (
                    <div>
                      <h3 className="text-sm font-bold text-gray-700 mb-2">
                        مراحل ({toPersianNumber(stages.length)})
                      </h3>
                      <div className="space-y-2">
                        {stages.map((stage, idx) => (
                          <div key={idx} className="border rounded-lg p-3 bg-gray-50/50 text-sm">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-bold text-xs bg-teal-100 text-teal-700 rounded px-1.5 py-0.5">
                                روز {toPersianNumber(stage.day)}
                              </span>
                              <span className="text-gray-500">—</span>
                              <span className="font-medium">{stage.subject || 'بدون عنوان'}</span>
                              <Badge variant="outline" className="text-xs mr-auto">
                                {CHANNEL_OPTIONS.find(c => c.value === stage.channel)?.label || stage.channel}
                              </Badge>
                            </div>
                            {stage.body && (
                              <p className="text-xs text-gray-600 mt-1 whitespace-pre-wrap">{stage.body}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recipients */}
                  <div>
                    <h3 className="text-sm font-bold text-gray-700 mb-2">
                      گیرندگان ({toPersianNumber(recipients.length)})
                    </h3>
                    {detailLoading ? (
                      <div className="space-y-2">
                        {[...Array(3)].map((_, i) => (
                          <Skeleton key={i} className="h-8 rounded-lg" />
                        ))}
                      </div>
                    ) : recipients.length === 0 ? (
                      <div className="text-sm text-gray-400 text-center py-4 bg-gray-50 rounded-lg">
                        گیرنده‌ای ثبت نشده
                      </div>
                    ) : (
                      <div className="max-h-64 overflow-y-auto space-y-1">
                        {recipients.map((recipient) => {
                          const rStatus = RECIPIENT_STATUS_META[recipient.status] || RECIPIENT_STATUS_META.PENDING;
                          const name = recipient.lead?.name ||
                            (recipient.karAmuz ? `${recipient.karAmuz.firstName} ${recipient.karAmuz.lastName}` : '—');
                          return (
                            <div key={recipient.id} className="flex items-center justify-between px-3 py-2 border border-gray-100 rounded-lg bg-white text-sm">
                              <span className="font-medium">{name}</span>
                              <div className="flex items-center gap-2">
                                {recipient.currentStage > 0 && (
                                  <span className="text-xs text-gray-400">
                                    مرحله {toPersianNumber(recipient.currentStage)}
                                  </span>
                                )}
                                <Badge className={`${rStatus.bgColor} ${rStatus.color} text-xs border-0`}>
                                  {rStatus.label}
                                </Badge>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Description */}
                  {detailCampaign.description && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 mb-1">توضیحات:</p>
                      <p className="text-sm text-gray-700 bg-gray-50 rounded-lg p-2">{detailCampaign.description}</p>
                    </div>
                  )}

                  {/* Status change buttons */}
                  <div className="border-t pt-3 space-y-2">
                    <p className="text-xs font-bold text-gray-500">تغییر وضعیت:</p>
                    <div className="flex flex-wrap gap-2">
                      {detailCampaign.status === 'DRAFT' && (
                        <Button
                          size="sm"
                          onClick={() => handleStatusChange(detailCampaign.id, 'RUNNING')}
                          disabled={statusSubmitting}
                          className="bg-green-600 hover:bg-green-700 text-white gap-1"
                        >
                          <Play className="w-3 h-3" />
                          شروع کمپین
                        </Button>
                      )}
                      {detailCampaign.status === 'RUNNING' && (
                        <>
                          <Button
                            size="sm"
                            onClick={() => handleStatusChange(detailCampaign.id, 'PAUSED')}
                            disabled={statusSubmitting}
                            className="bg-yellow-600 hover:bg-yellow-700 text-white gap-1"
                          >
                            <Pause className="w-3 h-3" />
                            توقف
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => handleStatusChange(detailCampaign.id, 'COMPLETED')}
                            disabled={statusSubmitting}
                            className="bg-teal-600 hover:bg-teal-700 text-white gap-1"
                          >
                            <CheckCircle2 className="w-3 h-3" />
                            تکمیل
                          </Button>
                        </>
                      )}
                      {detailCampaign.status === 'PAUSED' && (
                        <Button
                          size="sm"
                          onClick={() => handleStatusChange(detailCampaign.id, 'RUNNING')}
                          disabled={statusSubmitting}
                          className="bg-green-600 hover:bg-green-700 text-white gap-1"
                        >
                          <Play className="w-3 h-3" />
                          ادامه
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Edit Campaign Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Megaphone className="w-5 h-5 text-blue-600" />
              ویرایش کمپین
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نام کمپین *</Label>
              <Input placeholder="نام کمپین..." value={formName} onChange={(e) => setFormName(e.target.value)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">نوع</Label>
                <Select value={formType} onValueChange={setFormType}>
                  <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {TYPE_OPTIONS.map((opt) => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">کانال</Label>
                <Select value={formChannel} onValueChange={setFormChannel}>
                  <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CHANNEL_OPTIONS.map((opt) => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">بخش هدف</Label>
                <Select value={formTargetSegment} onValueChange={setFormTargetSegment}>
                  <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SEGMENT_OPTIONS.map((opt) => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">خوشه هدف</Label>
                <Select value={formTargetCluster} onValueChange={setFormTargetCluster}>
                  <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CLUSTER_OPTIONS.map((opt) => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">بودجه (ریال)</Label>
                <Input type="number" min={0} value={formBudget || ''} onChange={(e) => setFormBudget(parseInt(e.target.value) || 0)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">مسئول</Label>
                <Input placeholder="نام مسئول..." value={formAssignedTo} onChange={(e) => setFormAssignedTo(e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">تاریخ شروع</Label>
                <Input type="date" value={formStartDate} onChange={(e) => setFormStartDate(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">تاریخ پایان</Label>
                <Input type="date" value={formEndDate} onChange={(e) => setFormEndDate(e.target.value)} />
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-bold">مراحل کمپین</Label>
                <Button variant="outline" size="sm" onClick={addStage} className="gap-1 text-xs">
                  <Plus className="w-3 h-3" /> افزودن مرحله
                </Button>
              </div>
              {formStages.map((stage, idx) => (
                <div key={idx} className="border rounded-lg p-3 space-y-2 bg-gray-50/50">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-500">مرحله {toPersianNumber(idx + 1)}</span>
                    {formStages.length > 1 && (
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500 hover:bg-red-50" onClick={() => removeStage(idx)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-xs text-gray-500">روز</Label>
                      <Input type="number" min={0} value={stage.day} onChange={(e) => updateStage(idx, 'day', parseInt(e.target.value) || 0)} />
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">کانال</Label>
                      <Select value={stage.channel} onValueChange={(v) => updateStage(idx, 'channel', v)}>
                        <SelectTrigger className="bg-white"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {CHANNEL_OPTIONS.map((opt) => (<SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">موضوع</Label>
                      <Input placeholder="موضوع پیام" value={stage.subject} onChange={(e) => updateStage(idx, 'subject', e.target.value)} />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs text-gray-500">متن پیام</Label>
                    <Textarea placeholder="متن پیام..." value={stage.body} onChange={(e) => updateStage(idx, 'body', e.target.value)} rows={2} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>انصراف</Button>
            <Button onClick={handleEditSubmit} disabled={editSubmitting || !formName.trim()} className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
              {editSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ذخیره تغییرات
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              حذف کمپین
            </DialogTitle>
          </DialogHeader>
          <p className="text-gray-600 py-3">
            آیا از حذف این کمپین اطمینان دارید؟ این عمل غیرقابل بازگشت است و تمام گیرنده‌ها و آمار کمپین حذف خواهد شد.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>انصراف</Button>
            <Button onClick={handleDelete} disabled={deleteSubmitting} className="bg-red-600 hover:bg-red-700 text-white gap-2">
              {deleteSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
