'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Zap,
  Plus,
  Loader2,
  AlertTriangle,
  Trash2,
  Pencil,
  Play,
  Pause,
  Clock,
  Flame,
  CheckCircle2,
  XCircle,
  Activity,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface AutomationAction {
  type: string;
  payload: Record<string, unknown>;
}

interface AutomationRule {
  id: string;
  name: string;
  trigger: string;
  conditions: Record<string, unknown> | null;
  actions: AutomationAction[];
  isActive: boolean;
  priority: number;
  lastRunAt: string | null;
  createdAt: string;
  updatedAt: string;
}

/* ─────────── Constants ─────────── */

const TRIGGER_META: Record<string, { label: string; color: string; bgColor: string }> = {
  LEAD_CREATED: { label: 'ایجاد لید', color: 'text-green-700', bgColor: 'bg-green-100' },
  STAGE_CHANGED: { label: 'تغییر مرحله', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  PAYMENT_RECEIVED: { label: 'دریافت پرداخت', color: 'text-emerald-700', bgColor: 'bg-emerald-100' },
  PAYMENT_OVERDUE: { label: 'سررسید پرداخت', color: 'text-red-700', bgColor: 'bg-red-100' },
  FOLLOW_UP_DUE: { label: 'زمان پیگیری', color: 'text-amber-700', bgColor: 'bg-amber-100' },
  TICKET_CREATED: { label: 'ایجاد تیکت', color: 'text-purple-700', bgColor: 'bg-purple-100' },
  TICKET_SLA_BREACH: { label: 'نقض SLA تیکت', color: 'text-rose-700', bgColor: 'bg-rose-100' },
  QUOTE_ACCEPTED: { label: 'پذیرش پیشنهاد', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  QUOTE_SENT: { label: 'ارسال پیشنهاد', color: 'text-cyan-700', bgColor: 'bg-cyan-100' },
  APPOINTMENT_REMINDER: { label: 'یادآوری قرار', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  ENROLLMENT_CREATED: { label: 'ثبت‌نام جدید', color: 'text-indigo-700', bgColor: 'bg-indigo-100' },
  CERTIFICATE_ISSUED: { label: 'صدور گواهینامه', color: 'text-lime-700', bgColor: 'bg-lime-100' },
};

const ACTION_META: Record<string, { label: string; color: string; bgColor: string }> = {
  CREATE_TASK: { label: 'ایجاد وظیفه', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  ADD_TAG: { label: 'افزودن برچسب', color: 'text-amber-700', bgColor: 'bg-amber-100' },
  STAGE_CHANGE: { label: 'تغییر مرحله', color: 'text-green-700', bgColor: 'bg-green-100' },
  ADD_NOTE: { label: 'افزودن یادداشت', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  SEND_SMS: { label: 'ارسال پیامک', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  SEND_WHATSAPP: { label: 'ارسال واتساپ', color: 'text-emerald-700', bgColor: 'bg-emerald-100' },
  NOTIFY: { label: 'اعلان', color: 'text-purple-700', bgColor: 'bg-purple-100' },
  CREATE_INVOICE: { label: 'ایجاد فاکتور', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  UPDATE_SEGMENT: { label: 'به‌روزرسانی سگمنت', color: 'text-cyan-700', bgColor: 'bg-cyan-100' },
  ESCALATE_TICKET: { label: 'ارتقای تیکت', color: 'text-red-700', bgColor: 'bg-red-100' },
  SEND_EMAIL: { label: 'ارسال ایمیل', color: 'text-pink-700', bgColor: 'bg-pink-100' },
};

const TRIGGER_OPTIONS = Object.entries(TRIGGER_META).map(([value, meta]) => ({
  value,
  label: meta.label,
}));

const ACTION_TYPE_OPTIONS = Object.entries(ACTION_META).map(([value, meta]) => ({
  value,
  label: meta.label,
}));

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function AutomationPage() {
  /* ── State ── */
  const [rules, setRules] = useState<AutomationRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Expanded cards
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());

  // Dialog
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<AutomationRule | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Delete confirmation
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingRule, setDeletingRule] = useState<AutomationRule | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Form fields
  const [formName, setFormName] = useState('');
  const [formTrigger, setFormTrigger] = useState('');
  const [formPriority, setFormPriority] = useState(0);
  const [formIsActive, setFormIsActive] = useState(true);
  const [formConditions, setFormConditions] = useState('{}');
  const [formConditionsError, setFormConditionsError] = useState('');
  const [formActions, setFormActions] = useState<{ type: string; payload: string }[]>([
    { type: 'CREATE_TASK', payload: '{}' },
  ]);

  /* ── Data fetching ── */

  const fetchRules = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/crm/automation-rules');
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت قوانین اتوماسیون');
        return;
      }

      setRules(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRules();
  }, [fetchRules]);

  /* ── Computed ── */

  const stats = useMemo(() => ({
    total: rules.length,
    active: rules.filter(r => r.isActive).length,
    inactive: rules.filter(r => !r.isActive).length,
    recentlyRun: rules.filter(r => {
      if (!r.lastRunAt) return false;
      const runDate = new Date(r.lastRunAt);
      const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      return runDate > dayAgo;
    }).length,
    highPriority: rules.filter(r => r.priority >= 10).length,
  }), [rules]);

  /* ── Card toggle ── */

  const toggleCard = (id: string) => {
    setExpandedCards(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  /* ── Dialog handlers ── */

  const openAddDialog = () => {
    setEditingRule(null);
    setFormName('');
    setFormTrigger('');
    setFormPriority(0);
    setFormIsActive(true);
    setFormConditions('{}');
    setFormConditionsError('');
    setFormActions([{ type: 'CREATE_TASK', payload: '{}' }]);
    setDialogOpen(true);
  };

  const openEditDialog = (rule: AutomationRule) => {
    setEditingRule(rule);
    setFormName(rule.name);
    setFormTrigger(rule.trigger);
    setFormPriority(rule.priority);
    setFormIsActive(rule.isActive);
    setFormConditions(rule.conditions ? JSON.stringify(rule.conditions, null, 2) : '{}');
    setFormConditionsError('');
    setFormActions(
      (rule.actions || []).map(a => ({
        type: a.type,
        payload: JSON.stringify(a.payload, null, 2),
      }))
    );
    setDialogOpen(true);
  };

  const validateConditions = (value: string): boolean => {
    try {
      JSON.parse(value);
      setFormConditionsError('');
      return true;
    } catch {
      setFormConditionsError('JSON نامعتبر است');
      return false;
    }
  };

  const addAction = () => {
    setFormActions(prev => [...prev, { type: 'CREATE_TASK', payload: '{}' }]);
  };

  const removeAction = (index: number) => {
    if (formActions.length <= 1) return;
    setFormActions(prev => prev.filter((_, i) => i !== index));
  };

  const updateAction = (index: number, field: 'type' | 'payload', value: string) => {
    setFormActions(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const handleSubmit = async () => {
    // Validate conditions JSON
    let parsedConditions: Record<string, unknown> = {};
    try {
      parsedConditions = JSON.parse(formConditions);
    } catch {
      setFormConditionsError('JSON شرایط نامعتبر است');
      return;
    }

    // Validate actions
    const parsedActions: AutomationAction[] = [];
    for (let i = 0; i < formActions.length; i++) {
      try {
        const payload = JSON.parse(formActions[i].payload);
        parsedActions.push({ type: formActions[i].type, payload });
      } catch {
        return; // Invalid JSON in action payload
      }
    }

    if (!formName.trim() || !formTrigger || parsedActions.length === 0) return;

    setSubmitting(true);
    try {
      if (editingRule) {
        // Update
        const res = await fetch(`/api/crm/automation-rules/${editingRule.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formName.trim(),
            trigger: formTrigger,
            priority: formPriority,
            isActive: formIsActive,
            conditions: parsedConditions,
            actions: parsedActions,
          }),
        });
        if (res.ok) {
          setDialogOpen(false);
          fetchRules();
        }
      } else {
        // Create
        const res = await fetch('/api/crm/automation-rules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: formName.trim(),
            trigger: formTrigger,
            priority: formPriority,
            isActive: formIsActive,
            conditions: parsedConditions,
            actions: parsedActions,
          }),
        });
        if (res.ok) {
          setDialogOpen(false);
          fetchRules();
        }
      }
    } catch { /* silent */ } finally {
      setSubmitting(false);
    }
  };

  const handleToggleActive = async (rule: AutomationRule) => {
    try {
      const res = await fetch(`/api/crm/automation-rules/${rule.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !rule.isActive }),
      });
      if (res.ok) {
        fetchRules();
      }
    } catch { /* silent */ }
  };

  const handleDelete = async () => {
    if (!deletingRule) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/crm/automation-rules/${deletingRule.id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setDeleteDialogOpen(false);
        setDeletingRule(null);
        fetchRules();
      }
    } catch { /* silent */ } finally {
      setDeleting(false);
    }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Zap className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">قوانین اتوماسیون</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(stats.total)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت قوانین خودکار CRM</p>
          </div>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          قانون جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">فعال</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.active)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">غیرفعال</p>
                <p className="text-2xl font-bold mt-1 text-gray-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.inactive)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-200">
                <XCircle className="w-5 h-5 text-gray-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">اجرا شده اخیر</p>
                <p className="text-2xl font-bold mt-1 text-teal-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.recentlyRun)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
                <Activity className="w-5 h-5 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">اولویت بالا</p>
                <p className="text-2xl font-bold mt-1 text-red-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.highPriority)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200">
                <Flame className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Rules List */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchRules}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : rules.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Zap className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">قانون اتوماسیونی یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با ایجاد قانون جدید شروع کنید
            </p>
            <Button
              onClick={openAddDialog}
              className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <Plus className="w-4 h-4" />
              قانون جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {rules.map((rule) => {
            const triggerMeta = TRIGGER_META[rule.trigger] || { label: rule.trigger, color: 'text-gray-700', bgColor: 'bg-gray-100' };
            const isExpanded = expandedCards.has(rule.id);

            return (
              <Card key={rule.id} className="border-0 shadow-sm overflow-hidden">
                <CardContent className="p-0">
                  {/* Rule Header */}
                  <div className="p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                      {/* Right side: name + trigger */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-bold text-gray-900 text-base">{rule.name}</h3>
                          <Badge
                            variant="secondary"
                            className={`${triggerMeta.bgColor} ${triggerMeta.color} text-xs border-0`}
                          >
                            {triggerMeta.label}
                          </Badge>
                          <Badge variant="outline" className="text-xs text-gray-500">
                            اولویت: {toPersianNumber(rule.priority)}
                          </Badge>
                          {!rule.isActive && (
                            <Badge variant="secondary" className="bg-gray-100 text-gray-500 text-xs border-0">
                              غیرفعال
                            </Badge>
                          )}
                        </div>
                        {/* Actions summary line */}
                        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                          <span className="text-xs text-gray-500">عملیات:</span>
                          {(rule.actions || []).map((action, idx) => {
                            const actionMeta = ACTION_META[action.type] || { label: action.type, color: 'text-gray-700', bgColor: 'bg-gray-100' };
                            return (
                              <Badge
                                key={idx}
                                variant="secondary"
                                className={`${actionMeta.bgColor} ${actionMeta.color} text-[10px] border-0 px-1.5 py-0`}
                              >
                                {actionMeta.label}
                              </Badge>
                            );
                          })}
                        </div>
                      </div>

                      {/* Left side: controls */}
                      <div className="flex items-center gap-2 shrink-0">
                        {/* Active toggle */}
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={rule.isActive}
                            onCheckedChange={() => handleToggleActive(rule)}
                          />
                          <span className="text-xs text-gray-500">
                            {rule.isActive ? 'فعال' : 'غیرفعال'}
                          </span>
                        </div>

                        {/* Expand button */}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                          onClick={() => toggleCard(rule.id)}
                          title={isExpanded ? 'بستن جزئیات' : 'مشاهده جزئیات'}
                        >
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </Button>

                        {/* Edit */}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                          onClick={() => openEditDialog(rule)}
                          title="ویرایش"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>

                        {/* Delete */}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-red-700 hover:bg-red-50"
                          onClick={() => {
                            setDeletingRule(rule);
                            setDeleteDialogOpen(true);
                          }}
                          title="حذف"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Expanded content */}
                  {isExpanded && (
                    <div className="border-t border-gray-100 bg-gray-50/50 p-4 space-y-3">
                      {/* Conditions */}
                      <div>
                        <p className="text-xs font-bold text-gray-500 mb-1.5">شروط:</p>
                        {rule.conditions && Object.keys(rule.conditions).length > 0 ? (
                          <div className="flex flex-wrap gap-1.5">
                            {Object.entries(rule.conditions).map(([key, value]) => (
                              <Badge key={key} variant="outline" className="text-xs font-mono">
                                {key}: {String(value)}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <p className="text-xs text-gray-400">بدون شرط (اجرا برای همه)</p>
                        )}
                      </div>

                      {/* Actions detail */}
                      <div>
                        <p className="text-xs font-bold text-gray-500 mb-1.5">جزئیات عملیات:</p>
                        <div className="space-y-2">
                          {(rule.actions || []).map((action, idx) => {
                            const actionMeta = ACTION_META[action.type] || { label: action.type, color: 'text-gray-700', bgColor: 'bg-gray-100' };
                            return (
                              <div key={idx} className="bg-white rounded-lg border border-gray-200 p-2.5">
                                <div className="flex items-center gap-2 mb-1">
                                  <Badge
                                    variant="secondary"
                                    className={`${actionMeta.bgColor} ${actionMeta.color} text-xs border-0`}
                                  >
                                    {actionMeta.label}
                                  </Badge>
                                  <span className="text-xs text-gray-400 font-mono">{action.type}</span>
                                </div>
                                {action.payload && Object.keys(action.payload).length > 0 && (
                                  <div className="flex flex-wrap gap-1 mt-1">
                                    {Object.entries(action.payload).map(([key, value]) => (
                                      <span key={key} className="text-[10px] text-gray-500 bg-gray-50 rounded px-1.5 py-0.5 font-mono">
                                        {key}: {String(value)}
                                      </span>
                                    ))}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Last run */}
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Clock className="w-3.5 h-3.5" />
                        <span>
                          آخرین اجرا:{' '}
                          {rule.lastRunAt ? formatPersianDate(rule.lastRunAt) : 'هنوز اجرا نشده'}
                        </span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Zap className="w-5 h-5 text-teal-600" />
              {editingRule ? 'ویرایش قانون اتوماسیون' : 'قانون اتوماسیون جدید'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Name */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نام قانون</Label>
              <Input
                placeholder="مثلاً: پیگیری خودکار لید جدید"
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
              />
            </div>

            {/* Trigger + Priority row */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">رویداد راه‌انداز</Label>
                <Select value={formTrigger} onValueChange={setFormTrigger}>
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="انتخاب رویداد..." />
                  </SelectTrigger>
                  <SelectContent>
                    {TRIGGER_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">اولویت</Label>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  value={formPriority || ''}
                  onChange={(e) => setFormPriority(parseInt(e.target.value) || 0)}
                  placeholder="عدد بالاتر = اجرای زودتر"
                />
              </div>
            </div>

            {/* Active toggle */}
            <div className="flex items-center gap-3">
              <Switch
                checked={formIsActive}
                onCheckedChange={setFormIsActive}
              />
              <Label className="text-sm font-medium">
                {formIsActive ? 'فعال' : 'غیرفعال'}
              </Label>
            </div>

            {/* Conditions JSON */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">شروط (JSON)</Label>
              <Textarea
                placeholder='مثلاً: { "stage": "CONTACTED", "cluster": "tech-ai" }'
                value={formConditions}
                onChange={(e) => {
                  setFormConditions(e.target.value);
                  validateConditions(e.target.value);
                }}
                rows={3}
                className="font-mono text-xs"
                dir="ltr"
              />
              {formConditionsError && (
                <p className="text-xs text-red-600">{formConditionsError}</p>
              )}
              <p className="text-xs text-gray-400">{'خالی بگذارید یا { } برای بدون شرط'}</p>
            </div>

            {/* Actions builder */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-bold">عملیات‌ها</Label>
                <Button variant="outline" size="sm" onClick={addAction} className="gap-1 text-xs">
                  <Plus className="w-3 h-3" />
                  افزودن عملیات
                </Button>
              </div>

              {formActions.map((action, idx) => (
                <div key={idx} className="border rounded-lg p-3 space-y-2 bg-gray-50/50">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-500">عملیات {toPersianNumber(idx + 1)}</span>
                    {formActions.length > 1 && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-red-500 hover:bg-red-50"
                        onClick={() => removeAction(idx)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                  <div className="space-y-2">
                    <div>
                      <Label className="text-xs text-gray-500">نوع عملیات</Label>
                      <Select
                        value={action.type}
                        onValueChange={(value) => updateAction(idx, 'type', value)}
                      >
                        <SelectTrigger className="bg-white mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {ACTION_TYPE_OPTIONS.map((opt) => (
                            <SelectItem key={opt.value} value={opt.value}>
                              {opt.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">محموله (JSON)</Label>
                      <Textarea
                        placeholder='مثلاً: { "title": "پیگیری", "priority": "HIGH" }'
                        value={action.payload}
                        onChange={(e) => updateAction(idx, 'payload', e.target.value)}
                        rows={2}
                        className="font-mono text-xs mt-1"
                        dir="ltr"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !formName.trim() || !formTrigger}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              {editingRule ? 'به‌روزرسانی قانون' : 'ثبت قانون'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right text-red-700">
              <AlertTriangle className="w-5 h-5" />
              حذف قانون اتوماسیون
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-gray-600">
            آیا از حذف قانون &laquo;{deletingRule?.name}&raquo; اطمینان دارید؟ این عمل غیرقابل بازگشت است.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleting}
              className="gap-2"
            >
              {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
