'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Mail,
  Plus,
  Search,
  Loader2,
  AlertTriangle,
  Eye,
  Pencil,
  Star,
  ToggleLeft,
  ToggleRight,
  FileText,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  body: string;
  category: string;
  variables: string;
  isDefault: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

/* ─────────── Constants ─────────── */

const CATEGORY_META: Record<string, { label: string; color: string; bgColor: string }> = {
  GENERAL: { label: 'عمومی', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  MARKETING: { label: 'بازاریابی', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  TRANSACTIONAL: { label: 'تراکنشی', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  FOLLOW_UP: { label: 'پیگیری', color: 'text-teal-700', bgColor: 'bg-teal-100' },
};

const CATEGORY_OPTIONS = [
  { value: 'all', label: 'همه دسته‌بندی‌ها' },
  { value: 'GENERAL', label: 'عمومی' },
  { value: 'MARKETING', label: 'بازاریابی' },
  { value: 'TRANSACTIONAL', label: 'تراکنشی' },
  { value: 'FOLLOW_UP', label: 'پیگیری' },
];

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function EmailTemplatesPage() {
  /* ── State ── */
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  // Add/Edit dialog
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editId, setEditId] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formName, setFormName] = useState('');
  const [formSubject, setFormSubject] = useState('');
  const [formBody, setFormBody] = useState('');
  const [formCategory, setFormCategory] = useState('GENERAL');
  const [formVariables, setFormVariables] = useState('');
  const [formIsDefault, setFormIsDefault] = useState(false);
  const [formIsActive, setFormIsActive] = useState(true);

  // Preview dialog
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewTemplate, setPreviewTemplate] = useState<EmailTemplate | null>(null);

  /* ── Data fetching ── */

  const fetchTemplates = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (search) params.set('search', search);
      if (filterCategory && filterCategory !== 'all') params.set('category', filterCategory);

      const res = await fetch(`/api/crm/email-templates?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت قالب‌ها');
        return;
      }

      setTemplates(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterCategory]);

  useEffect(() => {
    fetchTemplates();
  }, [fetchTemplates]);

  /* ── Computed ── */

  const stats = useMemo(() => ({
    total: templates.length,
    active: templates.filter(t => t.isActive).length,
    defaults: templates.filter(t => t.isDefault).length,
    categories: new Set(templates.map(t => t.category)).size,
  }), [templates]);

  /* ── Handlers ── */

  const openAddDialog = () => {
    setEditMode(false);
    setEditId('');
    setFormName('');
    setFormSubject('');
    setFormBody('');
    setFormCategory('GENERAL');
    setFormVariables('');
    setFormIsDefault(false);
    setFormIsActive(true);
    setDialogOpen(true);
  };

  const openEditDialog = (template: EmailTemplate) => {
    setEditMode(true);
    setEditId(template.id);
    setFormName(template.name);
    setFormSubject(template.subject);
    setFormBody(template.body);
    setFormCategory(template.category);
    setFormVariables(template.variables);
    setFormIsDefault(template.isDefault);
    setFormIsActive(template.isActive);
    setDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formName.trim() || !formSubject.trim() || !formBody.trim()) return;
    setSubmitting(true);
    try {
      const url = '/api/crm/email-templates';
      const method = editMode ? 'PATCH' : 'POST';
      const body: Record<string, unknown> = {
        name: formName,
        subject: formSubject,
        body: formBody,
        category: formCategory,
        variables: formVariables,
        isDefault: formIsDefault,
        isActive: formIsActive,
      };
      if (editMode) {
        body.templateId = editId;
      }

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (res.ok) {
        setDialogOpen(false);
        fetchTemplates();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const openPreview = (template: EmailTemplate) => {
    setPreviewTemplate(template);
    setPreviewOpen(true);
  };

  const getPreviewContent = (template: EmailTemplate) => {
    const sampleData: Record<string, string> = {
      name: 'علی محمدی',
      firstName: 'علی',
      lastName: 'محمدی',
      course: 'برنامه‌نویسی پایتون',
      phone: '۰۹۱۲۱۲۳۴۵۶۷',
      email: 'ali@example.com',
      date: '۱۴۰۴/۰۳/۱۵',
      time: '۱۰:۰۰',
      instructor: 'استاد رضایی',
      amount: '۵,۰۰۰,۰۰۰',
      certificateNo: 'BR-۱۴۰۴-۰۰۱',
    };

    let preview = template.body;
    const vars = template.variables.split(',').map(v => v.trim()).filter(Boolean);
    for (const v of vars) {
      const cleanVar = v.replace(/[{}]/g, '');
      const regex = new RegExp(`\\{\\{${cleanVar}\\}\\}`, 'g');
      preview = preview.replace(regex, sampleData[cleanVar] || `[${cleanVar}]`);
    }
    return preview;
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Mail className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">قالب‌های ایمیل</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {loading ? <Skeleton className="h-4 w-6" /> : toPersianNumber(stats.total)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت قالب‌های ایمیل و متغیرها</p>
          </div>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          قالب جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کل قالب‌ها</p>
                <p className="text-2xl font-bold mt-1 text-gray-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.total)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-200">
                <Mail className="w-5 h-5 text-gray-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">فعال</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.active)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <ToggleRight className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">پیش‌فرض</p>
                <p className="text-2xl font-bold mt-1 text-yellow-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.defaults)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-yellow-50 border border-yellow-200">
                <Star className="w-5 h-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">دسته‌بندی‌ها</p>
                <p className="text-2xl font-bold mt-1 text-orange-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.categories)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200">
                <FileText className="w-5 h-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="جستجوی نام یا موضوع..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10 bg-white"
          />
        </div>
        <Select value={filterCategory} onValueChange={setFilterCategory}>
          <SelectTrigger className="w-full sm:w-44 bg-white">
            <SelectValue placeholder="دسته‌بندی" />
          </SelectTrigger>
          <SelectContent>
            {CATEGORY_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchTemplates}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : templates.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Mail className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">قالبی یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با ایجاد قالب جدید شروع کنید
            </p>
            <Button
              onClick={openAddDialog}
              className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <Plus className="w-4 h-4" />
              قالب جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">نام</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">موضوع</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">دسته‌بندی</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">متغیرها</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">پیش‌فرض</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">وضعیت</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {templates.map((template) => {
                  const catMeta = CATEGORY_META[template.category] || CATEGORY_META.GENERAL;
                  const vars = template.variables.split(',').filter(v => v.trim());
                  return (
                    <TableRow key={template.id} className="hover:bg-gray-50/50">
                      <TableCell className="text-sm font-medium max-w-[180px] truncate">
                        {template.name}
                      </TableCell>
                      <TableCell className="text-sm text-gray-600 max-w-[200px] truncate">
                        {template.subject}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`${catMeta.bgColor} ${catMeta.color} text-xs border-0`}>
                          {catMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {vars.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {vars.slice(0, 3).map((v, i) => (
                              <Badge key={i} variant="outline" className="text-xs font-mono border-gray-300 text-gray-600">
                                {v.trim()}
                              </Badge>
                            ))}
                            {vars.length > 3 && (
                              <span className="text-xs text-gray-400">+{toPersianNumber(vars.length - 3)}</span>
                            )}
                          </div>
                        ) : (
                          <span className="text-gray-400 text-xs">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {template.isDefault ? (
                          <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        ) : (
                          <Star className="w-4 h-4 text-gray-300" />
                        )}
                      </TableCell>
                      <TableCell>
                        {template.isActive ? (
                          <Badge className="bg-green-100 text-green-700 text-xs border-0">فعال</Badge>
                        ) : (
                          <Badge className="bg-red-100 text-red-700 text-xs border-0">غیرفعال</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                            onClick={() => openPreview(template)}
                            title="پیش‌نمایش"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-blue-700 hover:bg-blue-50"
                            onClick={() => openEditDialog(template)}
                            title="ویرایش"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Add/Edit Template Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Mail className="w-5 h-5 text-teal-600" />
              {editMode ? 'ویرایش قالب' : 'قالب ایمیل جدید'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Name */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نام قالب</Label>
              <Input
                placeholder="نام قالب..."
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
              />
            </div>

            {/* Subject */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">موضوع ایمیل</Label>
              <Input
                placeholder="موضوع ایمیل..."
                value={formSubject}
                onChange={(e) => setFormSubject(e.target.value)}
              />
            </div>

            {/* Body */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">محتوای ایمیل</Label>
              <Textarea
                placeholder="محتوای ایمیل... از {{متغیر}} برای متغیرها استفاده کنید"
                value={formBody}
                onChange={(e) => setFormBody(e.target.value)}
                rows={8}
                className="font-mono text-sm"
              />
              <p className="text-xs text-gray-400">
                متغیرها را با فرمت {'{{نام_متغیر}}'} وارد کنید. مثال: {'{{name}}'}, {'{{course}}'}, {'{{date}}'}
              </p>
            </div>

            {/* Category */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">دسته‌بندی</Label>
              <Select value={formCategory} onValueChange={setFormCategory}>
                <SelectTrigger className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORY_META).map(([key, meta]) => (
                    <SelectItem key={key} value={key}>
                      {meta.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Variables */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">متغیرها (جدا شده با کاما)</Label>
              <Input
                placeholder="name, course, date"
                value={formVariables}
                onChange={(e) => setFormVariables(e.target.value)}
                className="font-mono text-sm"
                dir="ltr"
              />
              <p className="text-xs text-gray-400">
                متغیرهای قابل استفاده را با کاما جدا کنید
              </p>
            </div>

            {/* Toggles */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center justify-between gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  <Label className="text-sm">پیش‌فرض</Label>
                </div>
                <Switch
                  checked={formIsDefault}
                  onCheckedChange={setFormIsDefault}
                />
              </div>
              <div className="flex items-center justify-between gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <ToggleLeft className="w-4 h-4 text-green-500" />
                  <Label className="text-sm">فعال</Label>
                </div>
                <Switch
                  checked={formIsActive}
                  onCheckedChange={setFormIsActive}
                />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              {editMode ? 'به‌روزرسانی' : 'ثبت قالب'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          {previewTemplate && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 text-right">
                  <Eye className="w-5 h-5 text-teal-600" />
                  پیش‌نمایش: {previewTemplate.name}
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-4 py-2">
                {/* Template info */}
                <div className="flex flex-wrap items-center gap-3 text-sm">
                  <Badge className={`${(CATEGORY_META[previewTemplate.category] || CATEGORY_META.GENERAL).bgColor} ${(CATEGORY_META[previewTemplate.category] || CATEGORY_META.GENERAL).color} border-0`}>
                    {(CATEGORY_META[previewTemplate.category] || CATEGORY_META.GENERAL).label}
                  </Badge>
                  {previewTemplate.isDefault && (
                    <Badge className="bg-yellow-100 text-yellow-700 border-0 gap-1">
                      <Star className="w-3 h-3" />
                      پیش‌فرض
                    </Badge>
                  )}
                </div>

                {/* Subject preview */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-bold text-gray-500">موضوع</Label>
                  <div className="bg-gray-50 rounded-lg p-3 text-sm">
                    {previewTemplate.subject}
                  </div>
                </div>

                {/* Body preview with sample data */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-bold text-gray-500">پیش‌نمایش محتوا (با داده‌های نمونه)</Label>
                  <div className="bg-white border rounded-lg p-4 text-sm leading-relaxed whitespace-pre-wrap">
                    {getPreviewContent(previewTemplate)}
                  </div>
                </div>

                {/* Variables used */}
                {previewTemplate.variables && (
                  <div className="space-y-1.5">
                    <Label className="text-xs font-bold text-gray-500">متغیرها</Label>
                    <div className="flex flex-wrap gap-1.5">
                      {previewTemplate.variables.split(',').map((v, i) => (
                        <Badge key={i} variant="outline" className="font-mono text-xs border-teal-300 text-teal-700">
                          {v.trim()}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Last updated */}
                <div className="text-xs text-gray-400 text-left" dir="ltr">
                  آخرین به‌روزرسانی: {formatPersianDate(previewTemplate.updatedAt)}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
