'use client';

import { useEffect, useState } from 'react';
import { Plus, Search, Trash2, Edit, Gift, Copy, CheckCircle, XCircle, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface DiscountCode {
  id: string;
  code: string;
  type: string;
  value: number;
  maxUses: number | null;
  currentUses: number;
  maxDiscount: number | null;
  startDate: string | null;
  endDate: string | null;
  isActive: boolean;
  minOrderAmount: number | null;
  applicableCourses: string | null;
  forNewStudentsOnly: boolean;
  referrerId: string | null;
  referrer?: { id: string; firstName: string; lastName: string; code: string } | null;
  createdAt: string;
}

export default function AdminDiscountCodesPage() {
  const [codes, setCodes] = useState<DiscountCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editCode, setEditCode] = useState<DiscountCode | null>(null);
  const [referrers, setReferrers] = useState<Array<{ id: string; firstName: string; lastName: string; code: string }>>([]);

  const [form, setForm] = useState({
    code: '', referrerId: '', type: 'PERCENTAGE', value: '',
    maxUses: '', maxDiscount: '', startDate: '', endDate: '',
    isActive: true, minOrderAmount: '', applicableCourses: '', forNewStudentsOnly: false,
  });

  useEffect(() => {
    fetchCodes();
    fetchReferrers();
  }, [search]);

  async function fetchCodes() {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      const res = await fetch(`/api/crm/discount-codes?${params}`);
      const data = await res.json();
      if (data.codes) setCodes(data.codes);
    } catch {
      console.error('Error fetching discount codes');
    } finally {
      setLoading(false);
    }
  }

  async function fetchReferrers() {
    try {
      const res = await fetch('/api/crm/referrers?limit=100');
      const data = await res.json();
      if (data.referrers) setReferrers(data.referrers);
    } catch {
      // Silently fail
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const url = editCode ? `/api/crm/discount-codes/${editCode.id}` : '/api/crm/discount-codes';
      const method = editCode ? 'PATCH' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.success) {
        setShowAddForm(false);
        setEditCode(null);
        setForm({ code: '', referrerId: '', type: 'PERCENTAGE', value: '', maxUses: '', maxDiscount: '', startDate: '', endDate: '', isActive: true, minOrderAmount: '', applicableCourses: '', forNewStudentsOnly: false });
        fetchCodes();
      } else {
        alert(data.error || 'خطا در ثبت');
      }
    } catch {
      alert('خطا در ارتباط با سرور');
    }
  }

  async function handleToggleActive(code: DiscountCode) {
    try {
      await fetch(`/api/crm/discount-codes/${code.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !code.isActive }),
      });
      fetchCodes();
    } catch {
      alert('خطا در تغییر وضعیت');
    }
  }

  async function handleDelete(id: string) {
    if (!confirm('آیا از حذف این کد تخفیف اطمینان دارید؟')) return;
    try {
      await fetch(`/api/crm/discount-codes/${id}`, { method: 'DELETE' });
      fetchCodes();
    } catch {
      alert('خطا در حذف');
    }
  }

  function handleEdit(code: DiscountCode) {
    setEditCode(code);
    setForm({
      code: code.code,
      referrerId: code.referrerId || '',
      type: code.type,
      value: String(code.value),
      maxUses: code.maxUses ? String(code.maxUses) : '',
      maxDiscount: code.maxDiscount ? String(code.maxDiscount) : '',
      startDate: code.startDate ? new Date(code.startDate).toISOString().split('T')[0] : '',
      endDate: code.endDate ? new Date(code.endDate).toISOString().split('T')[0] : '',
      isActive: code.isActive,
      minOrderAmount: code.minOrderAmount ? String(code.minOrderAmount) : '',
      applicableCourses: code.applicableCourses || '',
      forNewStudentsOnly: code.forNewStudentsOnly,
    });
    setShowAddForm(true);
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Tag className="h-6 w-6 text-purple-600" />
            مدیریت کدهای تخفیف
          </h1>
          <p className="text-gray-500 text-sm mt-1">ایجاد و مدیریت کدهای تخفیف برای معرفین و مشتریان</p>
        </div>
        <Button onClick={() => { setEditCode(null); setForm({ code: '', referrerId: '', type: 'PERCENTAGE', value: '', maxUses: '', maxDiscount: '', startDate: '', endDate: '', isActive: true, minOrderAmount: '', applicableCourses: '', forNewStudentsOnly: false }); setShowAddForm(true); }} size="sm" className="gap-2 bg-purple-600 hover:bg-purple-700">
          <Plus className="h-4 w-4" />
          کد تخفیف جدید
        </Button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="جستجوی کد تخفیف..."
          className="w-full max-w-md pr-10 pl-4 py-2 border border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
        />
      </div>

      {/* Cards */}
      <div className="grid gap-3">
        {loading ? (
          <div className="text-center py-8 text-gray-400">در حال بارگذاری...</div>
        ) : codes.length === 0 ? (
          <div className="text-center py-8 text-gray-400">کد تخفیفی یافت نشد</div>
        ) : (
          codes.map(code => (
            <div key={code.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${code.isActive ? 'bg-green-100' : 'bg-gray-100'}`}>
                    <Gift className={`h-6 w-6 ${code.isActive ? 'text-green-600' : 'text-gray-400'}`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-lg font-mono text-purple-700">{code.code}</span>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${code.type === 'PERCENTAGE' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'}`}>
                        {code.type === 'PERCENTAGE' ? `${code.value}%` : `${Number(code.value).toLocaleString('fa-IR')} ریال`}
                      </span>
                      {!code.isActive && <span className="px-2 py-0.5 rounded-full text-xs bg-red-100 text-red-700">غیرفعال</span>}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {code.referrer ? `معرف: ${code.referrer.firstName} ${code.referrer.lastName}` : 'عمومی'}
                      {' • '}
                      استفاده: {code.currentUses}{code.maxUses ? `/${code.maxUses}` : ''}
                      {code.endDate && ` • انقضا: ${new Date(code.endDate).toLocaleDateString('fa-IR')}`}
                    </p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => handleToggleActive(code)} className="p-2 hover:bg-gray-100 rounded-lg" title={code.isActive ? 'غیرفعال کردن' : 'فعال کردن'}>
                    {code.isActive ? <XCircle className="h-4 w-4 text-red-500" /> : <CheckCircle className="h-4 w-4 text-green-500" />}
                  </button>
                  <button onClick={() => handleEdit(code)} className="p-2 hover:bg-gray-100 rounded-lg text-gray-500" title="ویرایش">
                    <Edit className="h-4 w-4" />
                  </button>
                  <button onClick={() => handleDelete(code.id)} className="p-2 hover:bg-gray-100 rounded-lg text-red-500" title="حذف">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add/Edit Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => { setShowAddForm(false); setEditCode(null); }}>
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6" onClick={e => e.stopPropagation()}>
            <h2 className="text-lg font-bold text-gray-900 mb-4">
              {editCode ? 'ویرایش کد تخفیف' : 'کد تخفیف جدید'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">کد تخفیف <span className="text-red-500">*</span></label>
                  <input type="text" required value={form.code} onChange={e => setForm(p => ({ ...p, code: e.target.value.toUpperCase() }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none font-mono" dir="ltr" placeholder="SUMMER1404" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">معرف اختصاصی</label>
                  <select value={form.referrerId} onChange={e => setForm(p => ({ ...p, referrerId: e.target.value }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                    <option value="">بدون معرف (عمومی)</option>
                    {referrers.map(r => (
                      <option key={r.id} value={r.id}>{r.firstName} {r.lastName} ({r.code})</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">نوع تخفیف</label>
                  <select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                    <option value="PERCENTAGE">درصدی</option>
                    <option value="FIXED">مبلغ ثابت</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">مقدار <span className="text-red-500">*</span></label>
                  <input type="number" step="0.1" required value={form.value} onChange={e => setForm(p => ({ ...p, value: e.target.value }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none" dir="ltr" placeholder="10" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">حداکثر استفاده</label>
                  <input type="number" value={form.maxUses} onChange={e => setForm(p => ({ ...p, maxUses: e.target.value }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none" dir="ltr" placeholder="نامحدود" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">حداکثر تخفیف (ریال)</label>
                  <input type="number" value={form.maxDiscount} onChange={e => setForm(p => ({ ...p, maxDiscount: e.target.value }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none" dir="ltr" placeholder="بدون محدودیت" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ شروع</label>
                  <input type="date" value={form.startDate} onChange={e => setForm(p => ({ ...p, startDate: e.target.value }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ پایان</label>
                  <input type="date" value={form.endDate} onChange={e => setForm(p => ({ ...p, endDate: e.target.value }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">حداقل مبلغ سفارش</label>
                  <input type="number" value={form.minOrderAmount} onChange={e => setForm(p => ({ ...p, minOrderAmount: e.target.value }))} className="w-full px-3 py-2 border rounded-xl text-sm focus:ring-2 focus:ring-purple-500 outline-none" dir="ltr" placeholder="بدون محدودیت" />
                </div>
                <div className="flex items-center gap-4 pt-6">
                  <label className="flex items-center gap-2 text-sm">
                    <input type="checkbox" checked={form.isActive} onChange={e => setForm(p => ({ ...p, isActive: e.target.checked }))} className="rounded" />
                    فعال
                  </label>
                  <label className="flex items-center gap-2 text-sm">
                    <input type="checkbox" checked={form.forNewStudentsOnly} onChange={e => setForm(p => ({ ...p, forNewStudentsOnly: e.target.checked }))} className="rounded" />
                    فقط دانشجویان جدید
                  </label>
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <Button type="submit" className="flex-1 bg-purple-600 hover:bg-purple-700">
                  {editCode ? 'به‌روزرسانی' : 'ایجاد کد تخفیف'}
                </Button>
                <Button type="button" variant="outline" onClick={() => { setShowAddForm(false); setEditCode(null); }} className="flex-1">انصراف</Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
