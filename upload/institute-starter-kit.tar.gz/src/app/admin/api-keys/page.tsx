'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Key,
  Plus,
  Loader2,
  AlertTriangle,
  Eye,
  EyeOff,
  Copy,
  Check,
  Power,
  PowerOff,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface ApiKeyItem {
  id: string;
  name: string;
  key: string;
  permissions: string;
  isActive: boolean;
  lastUsedAt: string | null;
  expiresAt: string | null;
  createdAt: string;
}

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string | null) {
  if (!dateStr) return '-';
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric', month: 'short', day: 'numeric',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function ApiKeysPage() {
  const [keys, setKeys] = useState<ApiKeyItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [formName, setFormName] = useState('');
  const [formPermissions, setFormPermissions] = useState<string[]>(['READ']);
  const [formExpiresAt, setFormExpiresAt] = useState('');

  // Show full key after creation
  const [newKeyDialogOpen, setNewKeyDialogOpen] = useState(false);
  const [newKey, setNewKey] = useState('');
  const [copied, setCopied] = useState(false);

  // Show/hide key toggle per row
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());

  /* ── Data fetching ── */

  const fetchKeys = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/crm/api-keys');
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت کلیدها');
        return;
      }

      setKeys(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchKeys();
  }, [fetchKeys]);

  /* ── Handlers ── */

  const handleSubmit = async () => {
    if (!formName.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/api-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formName,
          permissions: formPermissions.join(','),
          expiresAt: formExpiresAt || null,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const apiKey = data['داده'];
        setNewKey(apiKey.key);
        setAddDialogOpen(false);
        setNewKeyDialogOpen(true);
        setFormName('');
        setFormPermissions(['READ']);
        setFormExpiresAt('');
        fetchKeys();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const copyKey = async () => {
    try {
      await navigator.clipboard.writeText(newKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* silent */ }
  };

  const toggleKeyVisibility = (id: string) => {
    setVisibleKeys(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleActive = async (keyId: string, currentActive: boolean) => {
    try {
      const res = await fetch('/api/crm/api-keys', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyId, isActive: !currentActive }),
      });
      if (res.ok) fetchKeys();
    } catch { /* silent */ }
  };

  const togglePermission = (perm: string) => {
    setFormPermissions(prev =>
      prev.includes(perm) ? prev.filter(p => p !== perm) : [...prev, perm]
    );
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Key className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">کلیدهای API</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(keys.length)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت دسترسی API به سیستم</p>
          </div>
        </div>
        <Button
          onClick={() => {
            setFormName('');
            setFormPermissions(['READ']);
            setFormExpiresAt('');
            setAddDialogOpen(true);
          }}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          کلید جدید
        </Button>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchKeys}>تلاش مجدد</Button>
          </CardContent>
        </Card>
      ) : keys.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Key className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">کلیدی یافت نشد</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">نام</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">کلید</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">دسترسی‌ها</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">وضعیت</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">آخرین استفاده</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {keys.map((k) => (
                  <TableRow key={k.id} className="hover:bg-gray-50/50">
                    <TableCell className="font-medium text-sm">{k.name}</TableCell>
                    <TableCell className="text-sm font-mono">
                      <div className="flex items-center gap-1">
                        <span className="text-xs">
                          {visibleKeys.has(k.id) ? k.key : k.key}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-gray-400"
                          onClick={() => toggleKeyVisibility(k.id)}
                        >
                          {visibleKeys.has(k.id) ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        {k.permissions.split(',').map((p) => (
                          <Badge key={p} variant="secondary" className="bg-gray-100 text-gray-600 text-xs border-0">
                            {p}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="secondary"
                        className={`${k.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'} text-xs border-0`}
                      >
                        {k.isActive ? 'فعال' : 'غیرفعال'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {formatPersianDate(k.lastUsedAt)}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        className={`h-8 w-8 ${k.isActive ? 'text-red-500 hover:bg-red-50' : 'text-green-500 hover:bg-green-50'}`}
                        onClick={() => toggleActive(k.id, k.isActive)}
                        title={k.isActive ? 'غیرفعال کردن' : 'فعال کردن'}
                      >
                        {k.isActive ? <PowerOff className="w-4 h-4" /> : <Power className="w-4 h-4" />}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Add Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Key className="w-5 h-5 text-teal-600" />
              کلید API جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نام کلید</Label>
              <Input
                placeholder="نام کلید..."
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium">دسترسی‌ها</Label>
              <div className="flex gap-3">
                {['READ', 'WRITE', 'ADMIN'].map(perm => (
                  <label key={perm} className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formPermissions.includes(perm)}
                      onChange={() => togglePermission(perm)}
                      className="rounded border-gray-300"
                    />
                    <span className="text-sm">{perm}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">تاریخ انقضا (اختیاری)</Label>
              <Input
                type="date"
                value={formExpiresAt}
                onChange={(e) => setFormExpiresAt(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>انصراف</Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting || !formName.trim()}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ایجاد کلید
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Key Display Dialog */}
      <Dialog open={newKeyDialogOpen} onOpenChange={setNewKeyDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Key className="w-5 h-5 text-teal-600" />
              کلید API ایجاد شد
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <p className="text-sm text-yellow-800 font-medium">
                ⚠️ این کلید فقط یک بار نمایش داده می‌شود. حتماً آن را ذخیره کنید.
              </p>
            </div>

            <div className="bg-gray-50 rounded-lg p-3 font-mono text-sm break-all leading-6" dir="ltr">
              {newKey}
            </div>

            <Button
              onClick={copyKey}
              variant="outline"
              className="w-full gap-2"
            >
              {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
              {copied ? 'کپی شد!' : 'کپی کلید'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
