'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  GraduationCap,
  Loader2,
  AlertTriangle,
  RefreshCw,
  Activity,
  Brain,
  BarChart3,
  CheckCircle2,
  Clock,
  Users,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface ExamItem {
  id: string;
  title: string;
  type: string;
  isActive: boolean;
  adaptiveMode: boolean;
  questions: { id: string; difficulty: string }[];
  _count: { questions: number; attempts: number };
  skillProgram?: { id: string; name: string } | null;
}

interface AdaptiveSession {
  id: string;
  examId: string;
  karAmuzId: string;
  currentDifficulty: string;
  abilityEstimate: number;
  currentQuestionIndex: number;
  isCompleted: boolean;
  finalScore: number | null;
  finalLevel: string | null;
  responses: Array<{
    questionId: string;
    correct: boolean;
    difficulty: string;
    thetaAfter: number;
  }>;
  exam?: { title: string };
  karAmuz?: { firstName: string; lastName: string };
  createdAt: string;
}

/* ─────────── Constants ─────────── */

const DIFFICULTY_META: Record<string, { label: string; color: string; bgColor: string }> = {
  EASY: { label: 'آسان', color: 'text-green-700', bgColor: 'bg-green-100' },
  MEDIUM: { label: 'متوسط', color: 'text-yellow-700', bgColor: 'bg-yellow-100' },
  HARD: { label: 'سخت', color: 'text-red-700', bgColor: 'bg-red-100' },
};

const LEVEL_META: Record<string, { label: string; color: string; bgColor: string }> = {
  BEGINNER: { label: 'مبتدی', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  INTERMEDIATE: { label: 'متوسط', color: 'text-yellow-700', bgColor: 'bg-yellow-100' },
  ADVANCED: { label: 'پیشرفته', color: 'text-orange-700', bgColor: 'bg-orange-100' },
  EXPERT: { label: 'متخصص', color: 'text-purple-700', bgColor: 'bg-purple-100' },
};

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  }).format(new Date(dateStr));
}

function thetaToVisual(theta: number) {
  // Map theta (-3 to 3) to a 0-100 visual range
  return Math.max(0, Math.min(100, ((theta + 3) / 6) * 100));
}

function thetaColor(theta: number): string {
  if (theta < -1) return '#3b82f6'; // blue — low ability
  if (theta < 1) return '#eab308';  // yellow — mid ability
  return '#22c55e';                  // green — high ability
}

/* ─────────── Sub Components ─────────── */

function AbilityGauge({ theta }: { theta: number }) {
  const pct = thetaToVisual(theta);
  const color = thetaColor(theta);

  return (
    <div className="space-y-1">
      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, backgroundColor: color }}
        />
      </div>
      <div className="flex justify-between text-xs text-gray-400">
        <span>-۳</span>
        <span className="font-mono font-bold" style={{ color }}>θ = {toPersianNumber(theta.toFixed(2))}</span>
        <span>+۳</span>
      </div>
    </div>
  );
}

function LevelDistributionChart({ sessions }: { sessions: AdaptiveSession[] }) {
  const completed = sessions.filter(s => s.isCompleted && s.finalLevel);
  const counts: Record<string, number> = { BEGINNER: 0, INTERMEDIATE: 0, ADVANCED: 0, EXPERT: 0 };
  for (const s of completed) {
    if (s.finalLevel && counts[s.finalLevel] !== undefined) {
      counts[s.finalLevel]++;
    }
  }
  const total = completed.length || 1;

  return (
    <div className="flex items-end gap-4 h-40 pt-4">
      {Object.entries(LEVEL_META).map(([key, meta]) => {
        const count = counts[key] || 0;
        const heightPct = Math.max((count / total) * 100, 5);
        return (
          <div key={key} className="flex-1 flex flex-col items-center gap-1">
            <span className="text-xs font-medium">{toPersianNumber(count)}</span>
            <div
              className="w-full rounded-t-md transition-all duration-500"
              style={{
                height: `${heightPct}%`,
                backgroundColor: key === 'BEGINNER' ? '#3b82f6' : key === 'INTERMEDIATE' ? '#eab308' : key === 'ADVANCED' ? '#f97316' : '#8b5cf6',
              }}
            />
            <span className={`text-xs ${meta.color}`}>{meta.label}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ─────────── Main Component ─────────── */

export default function AdaptiveExamsPage() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [exams, setExams] = useState<ExamItem[]>([]);
  const [sessions, setSessions] = useState<AdaptiveSession[]>([]);
  const [togglingId, setTogglingId] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError('');

      // Fetch all exams
      const examsRes = await fetch('/api/admin/exams?limit=100');
      if (!examsRes.ok) throw new Error('Failed to fetch exams');
      const examsJson = await examsRes.json();
      const allExams: ExamItem[] = examsJson['داده‌ها'] || examsJson.data || [];

      // Mark which exams have adaptive mode (based on question difficulty tags)
      const enrichedExams = allExams.map((exam: ExamItem) => {
        const hasDifficultyTags = (exam.questions || []).some(
          q => ['EASY', 'MEDIUM', 'HARD'].includes(q.difficulty)
        );
        return { ...exam, adaptiveMode: hasDifficultyTags };
      });
      setExams(enrichedExams);

      // Fetch adaptive sessions
      const sessionsRes = await fetch('/api/admin/adaptive-exams/sessions');
      if (sessionsRes.ok) {
        const sessionsJson = await sessionsRes.json();
        setSessions(sessionsJson.sessions || sessionsJson.data || []);
      }
    } catch {
      setError('خطا در دریافت اطلاعات');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  /* ── Toggle adaptive mode ── */

  const toggleAdaptive = async (examId: string, currentMode: boolean) => {
    setTogglingId(examId);
    try {
      const res = await fetch(`/api/admin/exams/${examId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adaptiveMode: !currentMode }),
      });
      if (res.ok) {
        setExams(prev =>
          prev.map(e => e.id === examId ? { ...e, adaptiveMode: !currentMode } : e)
        );
      }
    } catch { /* silent */ } finally {
      setTogglingId(null);
    }
  };

  /* ── Computed ── */

  const stats = useMemo(() => {
    const activeSessions = sessions.filter(s => !s.isCompleted);
    const completedSessions = sessions.filter(s => s.isCompleted);
    const avgTheta = activeSessions.length > 0
      ? activeSessions.reduce((sum, s) => sum + s.abilityEstimate, 0) / activeSessions.length
      : 0;

    return {
      activeCount: activeSessions.length,
      avgTheta: Math.round(avgTheta * 100) / 100,
      completedCount: completedSessions.length,
    };
  }, [sessions]);

  const adaptiveExams = useMemo(() => exams.filter(e => e.adaptiveMode), [exams]);

  const activeSessions = useMemo(() => sessions.filter(s => !s.isCompleted), [sessions]);

  const avgScoreByExam = useMemo(() => {
    const completed = sessions.filter(s => s.isCompleted && s.finalScore !== null);
    const map = new Map<string, { total: number; count: number; title: string }>();
    for (const s of completed) {
      const key = s.examId;
      if (!map.has(key)) {
        map.set(key, { total: 0, count: 0, title: (s.exam as { title?: string })?.title ?? key });
      }
      const entry = map.get(key)!;
      entry.total += s.finalScore ?? 0;
      entry.count++;
    }
    return Array.from(map.entries()).map(([examId, data]) => ({
      examId,
      title: data.title,
      avgScore: Math.round(data.total / data.count),
      count: data.count,
    }));
  }, [sessions]);

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
            <GraduationCap className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">آزمون‌های تطبیقی</h1>
            <p className="text-gray-500 mt-0.5 text-sm">سیستم ارزیابی هوشمند بر اساس سطح توانایی</p>
          </div>
        </div>
        <Button variant="outline" onClick={fetchData} className="gap-2">
          <RefreshCw className="w-4 h-4" /> بروزرسانی
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">جلسات فعال</p>
                {loading ? (
                  <Skeleton className="h-7 w-12 mt-1" />
                ) : (
                  <p className="text-xl font-bold text-blue-700 mt-1">{toPersianNumber(stats.activeCount)}</p>
                )}
              </div>
              <div className="p-2.5 rounded-xl bg-blue-100 border border-blue-200">
                <Activity className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">میانگین سطح (θ)</p>
                {loading ? (
                  <Skeleton className="h-7 w-16 mt-1" />
                ) : (
                  <p className="text-xl font-bold text-yellow-700 mt-1">{toPersianNumber(stats.avgTheta.toFixed(2))}</p>
                )}
              </div>
              <div className="p-2.5 rounded-xl bg-yellow-100 border border-yellow-200">
                <Brain className="w-5 h-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">تکمیل‌شده</p>
                {loading ? (
                  <Skeleton className="h-7 w-12 mt-1" />
                ) : (
                  <p className="text-xl font-bold text-green-700 mt-1">{toPersianNumber(stats.completedCount)}</p>
                )}
              </div>
              <div className="p-2.5 rounded-xl bg-green-100 border border-green-200">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Error */}
      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchData}>تلاش مجدد</Button>
          </CardContent>
        </Card>
      )}

      {/* Tabs */}
      <Tabs defaultValue="exams" dir="rtl">
        <TabsList className="bg-gray-100">
          <TabsTrigger value="exams" className="gap-1.5">
            <GraduationCap className="w-3.5 h-3.5" /> آزمون‌ها
          </TabsTrigger>
          <TabsTrigger value="sessions" className="gap-1.5">
            <Activity className="w-3.5 h-3.5" /> جلسات فعال
          </TabsTrigger>
          <TabsTrigger value="results" className="gap-1.5">
            <BarChart3 className="w-3.5 h-3.5" /> نتایج
          </TabsTrigger>
        </TabsList>

        {/* Exams Tab */}
        <TabsContent value="exams" className="space-y-4">
          {loading ? (
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
            </div>
          ) : exams.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <GraduationCap className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">آزمونی یافت نشد</p>
              </CardContent>
            </Card>
          ) : (
            <Card className="border-0 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50/80">
                      <TableHead className="text-xs font-bold text-gray-600">نام آزمون</TableHead>
                      <TableHead className="text-xs font-bold text-gray-600">تعداد سؤالات</TableHead>
                      <TableHead className="text-xs font-bold text-gray-600">سطوح دشواری</TableHead>
                      <TableHead className="text-xs font-bold text-gray-600">جلسات</TableHead>
                      <TableHead className="text-xs font-bold text-gray-600">میانگین نمره</TableHead>
                      <TableHead className="text-xs font-bold text-gray-600">حالت تطبیقی</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {exams.map((exam) => {
                      const difficulties = new Set(
                        (exam.questions || []).map(q => q.difficulty).filter(d => ['EASY', 'MEDIUM', 'HARD'].includes(d))
                      );
                      const examAvg = avgScoreByExam.find(e => e.examId === exam.id);

                      return (
                        <TableRow key={exam.id} className="hover:bg-gray-50/50">
                          <TableCell className="text-sm">
                            <div className="font-medium">{exam.title}</div>
                            {exam.skillProgram && (
                              <div className="text-xs text-gray-400 mt-0.5">{exam.skillProgram.name}</div>
                            )}
                          </TableCell>
                          <TableCell className="text-sm">{toPersianNumber(exam._count?.questions ?? 0)}</TableCell>
                          <TableCell className="text-sm">
                            <div className="flex gap-1 flex-wrap">
                              {difficulties.size > 0 ? (
                                Array.from(difficulties).map(d => {
                                  const meta = DIFFICULTY_META[d];
                                  return meta ? (
                                    <Badge key={d} variant="secondary" className={`${meta.bgColor} ${meta.color} text-xs border-0`}>
                                      {meta.label}
                                    </Badge>
                                  ) : null;
                                })
                              ) : (
                                <span className="text-gray-400 text-xs">بدون برچسب</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">{toPersianNumber(exam._count?.attempts ?? 0)}</TableCell>
                          <TableCell className="text-sm font-medium">
                            {examAvg ? toPersianNumber(examAvg.avgScore) : '—'}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Switch
                                checked={exam.adaptiveMode}
                                onCheckedChange={() => toggleAdaptive(exam.id, exam.adaptiveMode)}
                                disabled={togglingId === exam.id}
                              />
                              {togglingId === exam.id && <Loader2 className="w-3 h-3 animate-spin text-gray-400" />}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </Card>
          )}
        </TabsContent>

        {/* Active Sessions Tab */}
        <TabsContent value="sessions" className="space-y-4">
          {loading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
            </div>
          ) : activeSessions.length === 0 ? (
            <Card className="border-0 shadow-sm">
              <CardContent className="p-12 text-center">
                <Activity className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 font-medium">جلسه فعالی وجود ندارد</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeSessions.map((session) => {
                const diffMeta = DIFFICULTY_META[session.currentDifficulty] || DIFFICULTY_META.MEDIUM;
                const responses = session.responses || [];
                const progress = responses.length;

                return (
                  <Card key={session.id} className="border-0 shadow-sm">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm font-bold text-gray-700">
                          {(session.exam as { title?: string })?.title ?? 'آزمون'}
                        </CardTitle>
                        <Badge variant="secondary" className={`${diffMeta.bgColor} ${diffMeta.color} text-xs border-0`}>
                          {diffMeta.label}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {/* Student info */}
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Users className="w-4 h-4" />
                        <span>
                          {(session.karAmuz as { firstName?: string; lastName?: string })?.firstName ?? ''}{' '}
                          {(session.karAmuz as { firstName?: string; lastName?: string })?.lastName ?? ''}
                        </span>
                      </div>

                      {/* Ability estimate */}
                      <div>
                        <p className="text-xs text-gray-500 mb-1">تخمین توانایی (θ)</p>
                        <AbilityGauge theta={session.abilityEstimate} />
                      </div>

                      {/* Progress */}
                      <div>
                        <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                          <span>پیشرفت سؤالات</span>
                          <span>{toPersianNumber(progress)} سؤال</span>
                        </div>
                        <Progress value={Math.min(progress * 10, 100)} className="h-2" />
                      </div>

                      {/* Current difficulty indicator */}
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-xs text-gray-500">
                          شروع: {formatPersianDate(session.createdAt)}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* Results Analysis Tab */}
        <TabsContent value="results" className="space-y-4">
          {loading ? (
            <div className="space-y-3">
              <Skeleton className="h-56 rounded-xl" />
              <Skeleton className="h-40 rounded-xl" />
            </div>
          ) : (
            <>
              {/* Level distribution */}
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-bold text-gray-700">توزیع سطوح توانایی</CardTitle>
                </CardHeader>
                <CardContent>
                  {sessions.filter(s => s.isCompleted).length === 0 ? (
                    <div className="text-center py-8 text-gray-400 text-sm">
                      هنوز آزمون تطبیقی تکمیل‌شده‌ای وجود ندارد
                    </div>
                  ) : (
                    <LevelDistributionChart sessions={sessions} />
                  )}
                </CardContent>
              </Card>

              {/* Average θ by exam */}
              <Card className="border-0 shadow-sm overflow-hidden">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-bold text-gray-700">میانگین θ به تفکیک آزمون</CardTitle>
                </CardHeader>
                <CardContent>
                  {avgScoreByExam.length === 0 ? (
                    <div className="text-center py-8 text-gray-400 text-sm">
                      داده‌ای موجود نیست
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-gray-50/80">
                            <TableHead className="text-xs font-bold text-gray-600">آزمون</TableHead>
                            <TableHead className="text-xs font-bold text-gray-600">تعداد جلسات</TableHead>
                            <TableHead className="text-xs font-bold text-gray-600">میانگین نمره</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {avgScoreByExam.map((item) => (
                            <TableRow key={item.examId} className="hover:bg-gray-50/50">
                              <TableCell className="text-sm font-medium">{item.title}</TableCell>
                              <TableCell className="text-sm">{toPersianNumber(item.count)}</TableCell>
                              <TableCell className="text-sm">
                                <div className="flex items-center gap-2">
                                  <Progress value={item.avgScore} className="h-2 w-20" />
                                  <span className="font-medium">{toPersianNumber(item.avgScore)}</span>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Question difficulty analysis */}
              <Card className="border-0 shadow-sm overflow-hidden">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-bold text-gray-700">تحلیل دشواری سؤالات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    {Object.entries(DIFFICULTY_META).map(([key, meta]) => {
                      // Count questions in adaptive exams by difficulty
                      const questionCount = adaptiveExams.reduce((sum, exam) => {
                        return sum + (exam.questions || []).filter(q => q.difficulty === key).length;
                      }, 0);

                      return (
                        <div key={key} className={`p-4 rounded-xl ${meta.bgColor} border border-gray-200`}>
                          <p className={`text-sm font-bold ${meta.color}`}>{meta.label}</p>
                          <p className="text-2xl font-bold mt-1">{toPersianNumber(questionCount)}</p>
                          <p className="text-xs text-gray-500 mt-0.5">سؤال</p>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
