'use client';

import { useEffect, useState, useCallback } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  BookOpen,
  Plus,
  Search,
  Pencil,
  Trash2,
  CheckCircle,
  XCircle,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Clock,
  Loader2,
  GraduationCap,
  User,
} from 'lucide-react';
import { toast } from 'sonner';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface SkillProgram {
  id: string;
  code: string | null;
  name: string;
  description: string | null;
  totalHours: number;
  theoryHours: number;
  practicalHours: number;
  minAttendancePct: number;
  price: number | null;
  capacity: number | null;
  isActive: boolean;
  cluster: string | null;
  instructorName: string | null;
  level: string | null;
  createdAt: string;
  updatedAt: string;
  _count?: {
    enrollments: number;
    sessions: number;
  };
}

interface PaginationInfo {
  صفحه: number;
  حجم: number;
  کل: number;
  تعداد_صفحات: number;
}

interface FormData {
  name: string;
  code: string;
  cluster: string;
  level: string;
  totalHours: string;
  theoryHours: string;
  practicalHours: string;
  minAttendancePct: string;
  capacity: string;
  price: string;
  instructorName: string;
  description: string;
}

/* ─────────── Constants ─────────── */

const CLUSTER_MAP: Record<string, { label: string; color: string; bg: string }> = {
  'tech-ai': {
    label: 'کامپیوتر و هوش مصنوعی',
    color: 'text-blue-700',
    bg: 'bg-blue-50 border-blue-200',
  },
  financial: {
    label: 'بازار سرمایه',
    color: 'text-emerald-700',
    bg: 'bg-emerald-50 border-emerald-200',
  },
  management: {
    label: 'مدیریت',
    color: 'text-purple-700',
    bg: 'bg-purple-50 border-purple-200',
  },
  entrepreneurship: {
    label: 'کارآفرینی',
    color: 'text-orange-700',
    bg: 'bg-orange-50 border-orange-200',
  },
};

const LEVEL_MAP: Record<string, { label: string; color: string; bg: string }> = {
  'مبتدی': {
    label: 'مبتدی',
    color: 'text-blue-700',
    bg: 'bg-blue-100 text-blue-700',
  },
  'متوسط': {
    label: 'متوسط',
    color: 'text-yellow-700',
    bg: 'bg-yellow-100 text-yellow-700',
  },
  'پیشرفته': {
    label: 'پیشرفته',
    color: 'text-red-700',
    bg: 'bg-red-100 text-red-700',
  },
};

const EMPTY_FORM: FormData = {
  name: '',
  code: '',
  cluster: '',
  level: '',
  totalHours: '',
  theoryHours: '',
  practicalHours: '',
  minAttendancePct: '80',
  capacity: '',
  price: '',
  instructorName: '',
  description: '',
};

const ITEMS_PER_PAGE = 12;

/* ─────────── Helpers ─────────── */

function formatRials(amount: number | null): string {
  if (amount === null || amount === 0) return '—';
  return toPersianNumber(amount.toLocaleString('en-US')) + ' ریال';
}

function formatPercent(value: number): string {
  return toPersianNumber(Math.round(value * 100)) + '٪';
}

/* ─────────── Main Component ─────────── */

export default function SkillProgramsPage() {
  /* ── State ── */
  const [programs, setPrograms] = useState<SkillProgram[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<PaginationInfo | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [clusterFilter, setClusterFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProgram, setEditingProgram] = useState<SkillProgram | null>(null);
  const [form, setForm] = useState<FormData>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  // Delete
  const [deleteId, setDeleteId] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchPrograms = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      params.set('page', currentPage.toString());
      params.set('limit', ITEMS_PER_PAGE.toString());

      if (search) params.set('search', search);
      if (clusterFilter !== 'all') params.set('cluster', clusterFilter);
      if (statusFilter !== 'all') params.set('isActive', statusFilter);

      const res = await fetch(`/api/crm/skill-programs?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        toast.error(data['خطا'] || 'خطا در دریافت لیست دوره‌ها');
        return;
      }

      setPrograms(data['داده‌ها'] || []);
      setPagination(data['صفحه‌بندی'] || null);
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [currentPage, search, clusterFilter, statusFilter]);

  useEffect(() => {
    fetchPrograms();
  }, [fetchPrograms]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [search, clusterFilter, statusFilter]);

  /* ── Computed stats ── */

  const totalPrograms = pagination?.کل ?? programs.length;
  const activeCount = programs.filter((p) => p.isActive).length;
  const inactiveCount = programs.filter((p) => !p.isActive).length;
  const atCapacityCount = programs.filter(
    (p) => p.capacity && p._count && p._count.enrollments >= p.capacity
  ).length;

  /* ── Modal handlers ── */

  const openCreateModal = () => {
    setEditingProgram(null);
    setForm(EMPTY_FORM);
    setModalOpen(true);
  };

  const openEditModal = (program: SkillProgram) => {
    setEditingProgram(program);
    setForm({
      name: program.name,
      code: program.code || '',
      cluster: program.cluster || '',
      level: program.level || '',
      totalHours: program.totalHours.toString(),
      theoryHours: program.theoryHours.toString(),
      practicalHours: program.practicalHours.toString(),
      minAttendancePct: Math.round(program.minAttendancePct * 100).toString(),
      capacity: program.capacity?.toString() || '',
      price: program.price?.toString() || '',
      instructorName: program.instructorName || '',
      description: program.description || '',
    });
    setModalOpen(true);
  };

  const handleSubmit = async () => {
    // Validate required fields
    if (!form.name.trim()) {
      toast.error('نام دوره الزامی است');
      return;
    }

    const totalHours = parseInt(form.totalHours) || 0;
    if (totalHours <= 0) {
      toast.error('مجموع ساعات باید بزرگتر از صفر باشد');
      return;
    }

    const theoryHours = parseInt(form.theoryHours) || 0;
    const practicalHours = parseInt(form.practicalHours) || 0;

    if (totalHours < theoryHours + practicalHours) {
      toast.error(
        `مجموع ساعات (${toPersianNumber(totalHours)}) نمی‌تواند کمتر از مجموع تئوری (${toPersianNumber(theoryHours)}) و عملی (${toPersianNumber(practicalHours)}) باشد`
      );
      return;
    }

    setSubmitting(true);

    try {
      const payload = {
        name: form.name.trim(),
        code: form.code.trim() || null,
        cluster: form.cluster || null,
        level: form.level || null,
        totalHours,
        theoryHours,
        practicalHours,
        minAttendancePct: (parseInt(form.minAttendancePct) || 80) / 100,
        capacity: form.capacity ? parseInt(form.capacity) : null,
        price: form.price ? parseInt(form.price) : null,
        instructorName: form.instructorName.trim() || null,
        description: form.description.trim() || null,
      };

      let res: Response;

      if (editingProgram) {
        res = await fetch(`/api/crm/skill-programs/${editingProgram.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch('/api/crm/skill-programs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      const data = await res.json();

      if (!res.ok) {
        toast.error(data['خطا'] || 'خطا در ذخیره‌سازی');
        return;
      }

      toast.success(
        editingProgram ? 'دوره با موفقیت ویرایش شد' : 'دوره جدید با موفقیت ایجاد شد'
      );
      setModalOpen(false);
      fetchPrograms();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setSubmitting(false);
    }
  };

  /* ── Delete handler ── */

  const handleDelete = async () => {
    if (!deleteId) return;

    try {
      const res = await fetch(`/api/crm/skill-programs/${deleteId}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        const data = await res.json();
        toast.error(data['خطا'] || 'خطا در حذف دوره');
        return;
      }

      toast.success('دوره با موفقیت غیرفعال شد');
      fetchPrograms();
    } catch {
      toast.error('خطا در ارتباط با سرور');
    }

    setDeleteId(null);
  };

  /* ── Page navigation ── */

  const totalPages = pagination?.تعداد_صفحات ?? 1;

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const getPageNumbers = (): (number | '...')[] => {
    if (totalPages <= 5) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }

    const pages: (number | '...')[] = [1];

    if (currentPage > 3) {
      pages.push('...');
    }

    const start = Math.max(2, currentPage - 1);
    const end = Math.min(totalPages - 1, currentPage + 1);

    for (let i = start; i <= end; i++) {
      pages.push(i);
    }

    if (currentPage < totalPages - 2) {
      pages.push('...');
    }

    pages.push(totalPages);

    return pages;
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <BookOpen className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">دوره‌های مهارتی</h1>
            <p className="text-gray-500 mt-0.5 text-sm">
              مدیریت دوره‌های آموزشی فنی و حرفه‌ای
            </p>
          </div>
        </div>
        <Button
          onClick={openCreateModal}
          className="bg-teal-600 hover:bg-teal-700 gap-2 text-white"
        >
          <Plus className="h-4 w-4" />
          افزودن دوره
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">کل دوره‌ها</p>
                <p className="text-2xl font-bold mt-1 text-gray-900">
                  {loading ? (
                    <Skeleton className="h-8 w-12 inline-block" />
                  ) : (
                    toPersianNumber(totalPrograms)
                  )}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <BookOpen className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Active */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">فعال</p>
                <p className="text-2xl font-bold mt-1 text-emerald-700">
                  {loading ? (
                    <Skeleton className="h-8 w-12 inline-block" />
                  ) : (
                    toPersianNumber(activeCount)
                  )}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* At Capacity */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">ظرفیت پر</p>
                <p className="text-2xl font-bold mt-1 text-orange-700">
                  {loading ? (
                    <Skeleton className="h-8 w-12 inline-block" />
                  ) : (
                    toPersianNumber(atCapacityCount)
                  )}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-orange-50 border border-orange-200">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Inactive */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">غیرفعال</p>
                <p className="text-2xl font-bold mt-1 text-red-700">
                  {loading ? (
                    <Skeleton className="h-8 w-12 inline-block" />
                  ) : (
                    toPersianNumber(inactiveCount)
                  )}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200">
                <XCircle className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter Bar */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="جستجو نام، کد یا مدرس..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>
            <Select value={clusterFilter} onValueChange={setClusterFilter}>
              <SelectTrigger className="w-full sm:w-52">
                <SelectValue placeholder="خوشه" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه خوشه‌ها</SelectItem>
                <SelectItem value="tech-ai">کامپیوتر و هوش مصنوعی</SelectItem>
                <SelectItem value="financial">بازار سرمایه</SelectItem>
                <SelectItem value="management">مدیریت</SelectItem>
                <SelectItem value="entrepreneurship">کارآفرینی</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-36">
                <SelectValue placeholder="وضعیت" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه</SelectItem>
                <SelectItem value="true">فعال</SelectItem>
                <SelectItem value="false">غیرفعال</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Cards Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="border-0 shadow-sm">
              <CardContent className="p-5 space-y-3">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <div className="flex gap-2">
                  <Skeleton className="h-6 w-20" />
                  <Skeleton className="h-6 w-16" />
                </div>
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : programs.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">دوره مهارتی یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با افزودن دوره جدید شروع کنید
            </p>
            <Button
              onClick={openCreateModal}
              className="mt-4 bg-teal-600 hover:bg-teal-700 gap-2 text-white"
            >
              <Plus className="h-4 w-4" />
              افزودن دوره
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {programs.map((program) => {
            const clusterMeta = program.cluster
              ? CLUSTER_MAP[program.cluster]
              : null;
            const levelMeta = program.level
              ? LEVEL_MAP[program.level]
              : null;
            const enrolled = program._count?.enrollments ?? 0;
            const isAtCapacity =
              program.capacity !== null && enrolled >= program.capacity;

            return (
              <Card
                key={program.id}
                className="bg-white rounded-xl shadow-sm border hover:shadow-md transition-shadow duration-200 group"
              >
                <CardContent className="p-5">
                  {/* Header: Name + Code Badge */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <h3 className="font-bold text-gray-900 text-base leading-relaxed line-clamp-2">
                      {program.name}
                    </h3>
                    {program.code && (
                      <Badge
                        variant="outline"
                        className="shrink-0 text-[10px] font-mono bg-gray-50 text-gray-600 border-gray-200"
                      >
                        {program.code}
                      </Badge>
                    )}
                  </div>

                  {/* Cluster Tag + Level Badge */}
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    {clusterMeta && (
                      <Badge
                        variant="outline"
                        className={`${clusterMeta.bg} text-[11px] font-medium`}
                      >
                        {clusterMeta.label}
                      </Badge>
                    )}
                    {levelMeta && (
                      <Badge
                        variant="secondary"
                        className={`${levelMeta.bg} text-[11px] font-medium`}
                      >
                        <GraduationCap className="w-3 h-3 ml-1" />
                        {levelMeta.label}
                      </Badge>
                    )}
                  </div>

                  {/* Hours Breakdown */}
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                    <Clock className="w-4 h-4 text-gray-400 shrink-0" />
                    <span>
                      {toPersianNumber(program.totalHours)} ساعت
                    </span>
                    <span className="text-gray-400">•</span>
                    <span className="text-gray-500 text-xs">
                      {toPersianNumber(program.theoryHours)} تئوری + {toPersianNumber(program.practicalHours)} عملی
                    </span>
                  </div>

                  {/* Instructor */}
                  {program.instructorName && (
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                      <User className="w-4 h-4 text-gray-400 shrink-0" />
                      <span>{program.instructorName}</span>
                    </div>
                  )}

                  {/* Capacity */}
                  {program.capacity && (
                    <div className="mb-3">
                      <div className="flex items-center justify-between text-sm mb-1.5">
                        <span className="text-gray-500">ظرفیت</span>
                        <span
                          className={`font-medium ${
                            isAtCapacity
                              ? 'text-orange-600'
                              : enrolled > 0
                              ? 'text-teal-600'
                              : 'text-gray-600'
                          }`}
                        >
                          {toPersianNumber(enrolled)} / {toPersianNumber(program.capacity)}
                        </span>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all duration-300 ${
                            isAtCapacity
                              ? 'bg-orange-500'
                              : enrolled > 0
                              ? 'bg-teal-500'
                              : 'bg-gray-300'
                          }`}
                          style={{
                            width: `${Math.min(
                              100,
                              program.capacity > 0
                                ? (enrolled / program.capacity) * 100
                                : 0
                            )}%`,
                          }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Price + Status */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm font-semibold text-gray-900">
                      {formatRials(program.price)}
                    </span>
                    <Badge
                      variant="secondary"
                      className={
                        program.isActive
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px]'
                          : 'bg-red-50 text-red-700 border border-red-200 text-[11px]'
                      }
                    >
                      {program.isActive ? 'فعال' : 'غیرفعال'}
                    </Badge>
                  </div>

                  {/* Min Attendance */}
                  <div className="text-[11px] text-gray-400 mb-3">
                    حداقل حضور: {formatPercent(program.minAttendancePct)}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 pt-3 border-t border-gray-100">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditModal(program)}
                      className="gap-1.5 text-gray-600 hover:text-teal-700 hover:bg-teal-50 flex-1"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      ویرایش
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteId(program.id)}
                      className="gap-1.5 text-gray-600 hover:text-red-700 hover:bg-red-50 flex-1"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      حذف
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {!loading && totalPages > 1 && (
        <div className="flex items-center justify-center gap-1 pt-2">
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={() => goToPage(currentPage - 1)}
            disabled={currentPage <= 1}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>

          {getPageNumbers().map((page, index) =>
            page === '...' ? (
              <span
                key={`dots-${index}`}
                className="px-2 text-gray-400 text-sm"
              >
                ...
              </span>
            ) : (
              <Button
                key={page}
                variant={page === currentPage ? 'default' : 'outline'}
                size="icon"
                className={`h-9 w-9 ${
                  page === currentPage
                    ? 'bg-teal-600 hover:bg-teal-700 text-white'
                    : ''
                }`}
                onClick={() => goToPage(page)}
              >
                {toPersianNumber(page)}
              </Button>
            )
          )}

          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={() => goToPage(currentPage + 1)}
            disabled={currentPage >= totalPages}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Add/Edit Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingProgram ? 'ویرایش دوره مهارتی' : 'افزودن دوره مهارتی جدید'}
            </DialogTitle>
            <DialogDescription>
              {editingProgram
                ? 'اطلاعات دوره را ویرایش کنید'
                : 'اطلاعات دوره جدید را وارد کنید'}
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-2">
            {/* Name */}
            <div className="sm:col-span-2">
              <Label htmlFor="name" className="text-sm font-medium text-gray-700">
                نام دوره <span className="text-red-500">*</span>
              </Label>
              <Input
                id="name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="مثلاً: برنامه‌نویسی وب"
                className="mt-1.5"
              />
            </div>

            {/* Code */}
            <div>
              <Label htmlFor="code" className="text-sm font-medium text-gray-700">
                کد استاندارد
              </Label>
              <Input
                id="code"
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value })}
                placeholder="مثلاً: TVTO-32012"
                className="mt-1.5 font-mono"
                dir="ltr"
              />
            </div>

            {/* Cluster */}
            <div>
              <Label className="text-sm font-medium text-gray-700">خوشه</Label>
              <Select
                value={form.cluster || 'none'}
                onValueChange={(val) =>
                  setForm({ ...form, cluster: val === 'none' ? '' : val })
                }
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="انتخاب خوشه" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون خوشه</SelectItem>
                  <SelectItem value="tech-ai">کامپیوتر و هوش مصنوعی</SelectItem>
                  <SelectItem value="financial">بازار سرمایه</SelectItem>
                  <SelectItem value="management">مدیریت</SelectItem>
                  <SelectItem value="entrepreneurship">کارآفرینی</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Level */}
            <div>
              <Label className="text-sm font-medium text-gray-700">سطح</Label>
              <Select
                value={form.level || 'none'}
                onValueChange={(val) =>
                  setForm({ ...form, level: val === 'none' ? '' : val })
                }
              >
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="انتخاب سطح" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون سطح</SelectItem>
                  <SelectItem value="مبتدی">مبتدی</SelectItem>
                  <SelectItem value="متوسط">متوسط</SelectItem>
                  <SelectItem value="پیشرفته">پیشرفته</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Total Hours */}
            <div>
              <Label htmlFor="totalHours" className="text-sm font-medium text-gray-700">
                مجموع ساعات <span className="text-red-500">*</span>
              </Label>
              <Input
                id="totalHours"
                type="number"
                min={0}
                value={form.totalHours}
                onChange={(e) => setForm({ ...form, totalHours: e.target.value })}
                placeholder="مثلاً: 120"
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Theory Hours */}
            <div>
              <Label htmlFor="theoryHours" className="text-sm font-medium text-gray-700">
                ساعات تئوری
              </Label>
              <Input
                id="theoryHours"
                type="number"
                min={0}
                value={form.theoryHours}
                onChange={(e) =>
                  setForm({ ...form, theoryHours: e.target.value })
                }
                placeholder="مثلاً: 40"
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Practical Hours */}
            <div>
              <Label htmlFor="practicalHours" className="text-sm font-medium text-gray-700">
                ساعات عملی
              </Label>
              <Input
                id="practicalHours"
                type="number"
                min={0}
                value={form.practicalHours}
                onChange={(e) =>
                  setForm({ ...form, practicalHours: e.target.value })
                }
                placeholder="مثلاً: 80"
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Min Attendance */}
            <div>
              <Label htmlFor="minAttendancePct" className="text-sm font-medium text-gray-700">
                حداقل درصد حضور
              </Label>
              <div className="relative mt-1.5">
                <Input
                  id="minAttendancePct"
                  type="number"
                  min={0}
                  max={100}
                  value={form.minAttendancePct}
                  onChange={(e) =>
                    setForm({ ...form, minAttendancePct: e.target.value })
                  }
                  className="pl-8"
                  dir="ltr"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                  ٪
                </span>
              </div>
            </div>

            {/* Capacity */}
            <div>
              <Label htmlFor="capacity" className="text-sm font-medium text-gray-700">
                ظرفیت
              </Label>
              <Input
                id="capacity"
                type="number"
                min={0}
                value={form.capacity}
                onChange={(e) => setForm({ ...form, capacity: e.target.value })}
                placeholder="مثلاً: 25"
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Price */}
            <div>
              <Label htmlFor="price" className="text-sm font-medium text-gray-700">
                شهریه (ریال)
              </Label>
              <Input
                id="price"
                type="number"
                min={0}
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                placeholder="مثلاً: 15000000"
                className="mt-1.5"
                dir="ltr"
              />
            </div>

            {/* Instructor */}
            <div>
              <Label htmlFor="instructorName" className="text-sm font-medium text-gray-700">
                نام مدرس
              </Label>
              <Input
                id="instructorName"
                value={form.instructorName}
                onChange={(e) =>
                  setForm({ ...form, instructorName: e.target.value })
                }
                placeholder="مثلاً: مهندس احمدی"
                className="mt-1.5"
              />
            </div>

            {/* Description */}
            <div className="sm:col-span-2">
              <Label htmlFor="description" className="text-sm font-medium text-gray-700">
                توضیحات
              </Label>
              <Textarea
                id="description"
                value={form.description}
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
                placeholder="توضیحات دوره..."
                className="mt-1.5 min-h-[80px]"
              />
            </div>
          </div>

          {/* Validation message */}
          {form.totalHours &&
            form.theoryHours &&
            form.practicalHours &&
            parseInt(form.totalHours) <
              (parseInt(form.theoryHours) || 0) +
                (parseInt(form.practicalHours) || 0) && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700 mt-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                مجموع ساعات نمی‌تواند کمتر از مجموع تئوری و عملی باشد
              </div>
            )}

          <DialogFooter className="gap-2 mt-2">
            <Button
              variant="outline"
              onClick={() => setModalOpen(false)}
              disabled={submitting}
            >
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {editingProgram ? 'ذخیره تغییرات' : 'ایجاد دوره'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>غیرفعال‌سازی دوره</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از غیرفعال‌سازی این دوره اطمینان دارید؟ دوره غیرفعال شده همچنان در سیستم باقی
              می‌ماند و می‌توانید مجدداً آن را فعال کنید.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              غیرفعال‌سازی
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
