'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Users, GraduationCap, Building2, Store, Package, Palette,
  CheckCircle2, LayoutGrid, BarChart3, Bot,
  Zap, Shield, AlertTriangle, Brain, Ticket,
  CalendarCheck, Wallet, ClipboardList, BookMarked,
  TrendingUp, FileSpreadsheet, Receipt, Target,
  UserPlus, ClipboardCheck, Award, Key, Globe,
  Cpu, MapPin, Radar, Sparkles, GitBranch, Megaphone,
  Mail, Headphones, Layers, FileText,
} from 'lucide-react';

interface KPIs {
  totalLeads: number;
  activeEnrollments: number;
  revenue: number;
  pendingTickets: number;
}

export default function AdminDashboard() {
  const [kpis, setKpis] = useState<KPIs | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/dashboard')
      .then(res => res.json())
      .then(data => {
        if (data.kpis) setKpis(data.kpis);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="bg-gradient-to-l from-teal-600 to-emerald-800 rounded-2xl p-5 text-white">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <LayoutGrid className="h-6 w-6" /> داشبورد پلتفرم بهان رایانه
        </h1>
        <p className="text-teal-100 text-xs mt-1">
          نمای کلی وضعیت سیستم — از منوی کناری به بخش‌ها دسترسی پیدا کنید
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'کل سرن‌ها', value: kpis?.totalLeads, icon: Users, color: 'teal', fallback: '—' },
          { label: 'ثبت‌نام فعال', value: kpis?.activeEnrollments, icon: GraduationCap, color: 'blue', fallback: '—' },
          { label: 'درآمد (ریال)', value: kpis?.revenue, icon: Wallet, color: 'green', fallback: '—', format: true },
          { label: 'تیکت باز', value: kpis?.pendingTickets, icon: Ticket, color: 'amber', fallback: '—' },
        ].map((kpi, idx) => (
          <div
            key={idx}
            className="bg-white border-2 border-gray-100 rounded-xl p-4 shadow-sm"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                kpi.color === 'teal' ? 'bg-teal-100 text-teal-600' :
                kpi.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                kpi.color === 'green' ? 'bg-green-100 text-green-600' :
                'bg-amber-100 text-amber-600'
              }`}>
                <kpi.icon className="h-4 w-4" />
              </div>
              <span className="text-xs text-gray-500">{kpi.label}</span>
            </div>
            {loading ? (
              <div className="h-7 w-24 bg-gray-200 rounded animate-pulse" />
            ) : (
              <p className="text-lg font-bold text-gray-800">
                {kpi.value !== undefined && kpi.value !== null
                  ? (kpi.format ? kpi.value.toLocaleString('fa-IR') : kpi.value.toLocaleString('fa-IR'))
                  : kpi.fallback}
              </p>
            )}
          </div>
        ))}
      </div>

      {/* Phases */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { id: 1, t: 'CRM هوشمند', desc: 'مدیریت سرن‌ها، قراردادها، فاکتورها', color: 'teal', h: '/admin/crm', i: Users },
          { id: 2, t: 'اتوماسیون و AI', desc: 'عامل‌های هوشمند، کمپین‌ها، پایگاه دانش', color: 'purple', h: '/admin/automation', i: Zap },
          { id: 3, t: 'تحلیل و بینایی', desc: 'پیش‌بینی، سایبرنتیک، نقشه مشتریان', color: 'sky', h: '/admin/analytics', i: Brain },
          { id: 4, t: 'Enterprise', desc: 'Tenantها، فرانچایز، مارکت‌پلیس', color: 'amber', h: '/admin/tenants', i: Building2 },
        ].map(p => (
          <Link key={p.id} href={p.h}>
            <div className="bg-white border-2 border-gray-100 rounded-xl p-4 hover:border-teal-300 hover:shadow-lg transition-all cursor-pointer group">
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  p.id === 1 ? 'bg-teal-100 text-teal-600' :
                  p.id === 2 ? 'bg-purple-100 text-purple-600' :
                  p.id === 3 ? 'bg-sky-100 text-sky-600' :
                  'bg-amber-100 text-amber-600'
                }`}>
                  <p.i className="h-4 w-4" />
                </div>
                <p className="text-sm font-bold text-gray-800">فاز {p.id}: {p.t}</p>
              </div>
              <p className="text-xs text-gray-500">{p.desc}</p>
              <p className="text-[10px] text-emerald-600 mt-2 font-medium">
                <CheckCircle2 className="h-3 w-3 inline" /> تکمیل شده
              </p>
            </div>
          </Link>
        ))}
      </div>

      {/* Quick Links - CRM */}
      <div>
        <p className="text-xs font-bold text-gray-500 mb-2">فاز ۱ — CRM هوشمند</p>
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-2">
          {[
            { l: 'CRM', h: '/admin/crm', i: Users },
            { l: 'کارآموزان', h: '/admin/karamuz', i: GraduationCap },
            { l: 'دوره‌ها', h: '/admin/skill-programs', i: ClipboardList },
            { l: 'آزمون‌ها', h: '/admin/exams', i: ClipboardCheck },
            { l: 'کیفیت آموزشی', h: '/admin/quality', i: Award },
            { l: 'تیکت‌ها', h: '/admin/tickets', i: Ticket },
            { l: 'قرارها', h: '/admin/appointments', i: CalendarCheck },
            { l: 'فاکتورها', h: '/admin/invoices', i: Receipt },
            { l: 'پیشنهادها', h: '/admin/quotes', i: FileSpreadsheet },
            { l: 'اهداف فروش', h: '/admin/sales-targets', i: Target },
            { l: 'معرف‌ها', h: '/admin/referrers', i: UserPlus },
            { l: 'قراردادها', h: '/admin/service-contracts', i: Shield },
          ].map(lk => (
            <Link key={lk.h} href={lk.h} className="flex items-center gap-2 p-3 rounded-lg border border-gray-100 hover:border-teal-200 hover:bg-teal-50 text-xs text-gray-600 hover:text-teal-700 transition">
              <lk.i className="h-4 w-4" />{lk.l}
            </Link>
          ))}
        </div>
      </div>

      {/* Quick Links - Automation & AI */}
      <div>
        <p className="text-xs font-bold text-gray-500 mb-2">فاز ۲ — اتوماسیون و AI</p>
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-2">
          {[
            { l: 'اتوماسیون', h: '/admin/automation', i: Zap },
            { l: 'فرآیندها', h: '/admin/business-processes', i: GitBranch },
            { l: 'عامل‌های AI', h: '/admin/ai-agents', i: Bot },
            { l: 'مکالمات', h: '/admin/conversations', i: Headphones },
            { l: 'کمپین‌ها', h: '/admin/campaigns', i: Megaphone },
            { l: 'پایگاه دانش', h: '/admin/knowledge-base', i: BookMarked },
            { l: 'قالب‌های ایمیل', h: '/admin/email-templates', i: Mail },
            { l: 'تحلیل CRM', h: '/admin/analytics', i: BarChart3 },
          ].map(lk => (
            <Link key={lk.h} href={lk.h} className="flex items-center gap-2 p-3 rounded-lg border border-gray-100 hover:border-purple-200 hover:bg-purple-50 text-xs text-gray-600 hover:text-purple-700 transition">
              <lk.i className="h-4 w-4" />{lk.l}
            </Link>
          ))}
        </div>
      </div>

      {/* Quick Links - Analytics */}
      <div>
        <p className="text-xs font-bold text-gray-500 mb-2">فاز ۳ — تحلیل و بینایی</p>
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-2">
          {[
            { l: 'سایبرنتیک', h: '/admin/cybernetic', i: Cpu },
            { l: 'نقشه مشتریان', h: '/admin/geo', i: MapPin },
            { l: 'پیش‌بینی AI', h: '/admin/predictions', i: Brain },
            { l: 'پیش‌بینی ریزش', h: '/admin/churn-predictions', i: AlertTriangle },
            { l: 'تشخیص خودکار', h: '/admin/auto-lead-rules', i: Radar },
            { l: 'گزارش‌های AI', h: '/admin/ai-reports', i: Sparkles },
            { l: 'پورتال مشتری', h: '/admin/customer-portal', i: Globe },
            { l: 'کلیدهای API', h: '/admin/api-keys', i: Key },
          ].map(lk => (
            <Link key={lk.h} href={lk.h} className="flex items-center gap-2 p-3 rounded-lg border border-gray-100 hover:border-sky-200 hover:bg-sky-50 text-xs text-gray-600 hover:text-sky-700 transition">
              <lk.i className="h-4 w-4" />{lk.l}
            </Link>
          ))}
        </div>
      </div>

      {/* Quick Links - Enterprise */}
      <div>
        <p className="text-xs font-bold text-gray-500 mb-2">فاز ۴ — Enterprise</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {[
            { l: 'مدیریت Tenantها', h: '/admin/tenants', i: Building2 },
            { l: 'فرانچایز', h: '/admin/franchise', i: Store },
            { l: 'API Marketplace', h: '/admin/marketplace', i: Package },
            { l: 'White-Label', h: '/admin/white-label', i: Palette },
          ].map(lk => (
            <Link key={lk.h} href={lk.h} className="flex items-center gap-2 p-3 rounded-lg border border-gray-100 hover:border-amber-200 hover:bg-amber-50 text-xs text-gray-600 hover:text-amber-700 transition">
              <lk.i className="h-4 w-4" />{lk.l}
            </Link>
          ))}
        </div>
      </div>

      {/* Architecture */}
      <div>
        <p className="text-xs font-bold text-gray-500 mb-2">معماری و تنظیمات</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {[
            { l: 'معماری Enterprise', h: '/admin/architecture', i: Layers },
            { l: 'مستندسازی فرآیندها', h: '/admin/process-docs', i: FileText },
            { l: 'کاربران سیستم', h: '/admin/users', i: Users },
            { l: 'نقش‌ها و دسترسی‌ها', h: '/admin/roles', i: Shield },
            { l: 'تنظیمات', h: '/admin/settings', i: Shield },
          ].map(lk => (
            <Link key={lk.h} href={lk.h} className="flex items-center gap-2 p-3 rounded-lg border border-gray-100 hover:border-gray-200 hover:bg-gray-50 text-xs text-gray-600 hover:text-gray-800 transition">
              <lk.i className="h-4 w-4" />{lk.l}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
