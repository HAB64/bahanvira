'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  CalendarCheck,
  Plus,
  Search,
  Loader2,
  AlertTriangle,
  X,
  MapPin,
  Video,
  Clock,
  User,
  CheckCircle2,
  XCircle,
  Eye,
  Calendar,
  Users,
  Phone,
  MessageCircle,
  List,
  Grid3X3,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';
import AppointmentCalendar from '@/components/admin/AppointmentCalendar';

/* ─────────── Types ─────────── */

interface Appointment {
  id: string;
  title: string;
  description: string | null;
  leadId: string | null;
  karAmuzId: string | null;
  startTime: string;
  endTime: string;
  location: string | null;
  meetingUrl: string | null;
  type: string;
  status: string;
  assignedTo: string;
  reminderSent: boolean;
  createdAt: string;
  updatedAt: string;
  lead?: { id: string; name: string; phone: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string; phone: string } | null;
}

interface LeadOption {
  id: string;
  name: string;
}

interface KarAmuzOption {
  id: string;
  firstName: string;
  lastName: string;
}

/* ─────────── Constants ─────────── */

const TYPE_META: Record<string, { label: string; color: string; bgColor: string }> = {
  CONSULTATION: { label: 'مشاوره', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  FOLLOW_UP: { label: 'پیگیری', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  DEMO: { label: 'نمایش', color: 'text-purple-700', bgColor: 'bg-purple-100' },
  CLASS: { label: 'کلاس', color: 'text-green-700', bgColor: 'bg-green-100' },
  OTHER: { label: 'سایر', color: 'text-gray-600', bgColor: 'bg-gray-100' },
};

const STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  SCHEDULED: { label: 'برنامه‌ریزی شده', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  CONFIRMED: { label: 'تایید شده', color: 'text-green-700', bgColor: 'bg-green-100' },
  COMPLETED: { label: 'انجام شده', color: 'text-gray-600', bgColor: 'bg-gray-100' },
  CANCELLED: { label: 'لغو شده', color: 'text-red-700', bgColor: 'bg-red-100' },
  NO_SHOW: { label: 'عدم حضور', color: 'text-orange-700', bgColor: 'bg-orange-100' },
};

const TYPE_OPTIONS = [
  { value: 'CONSULTATION', label: 'مشاوره' },
  { value: 'FOLLOW_UP', label: 'پیگیری' },
  { value: 'DEMO', label: 'نمایش' },
  { value: 'CLASS', label: 'کلاس' },
  { value: 'OTHER', label: 'سایر' },
];

const STATUS_OPTIONS = [
  { value: 'all', label: 'همه وضعیت‌ها' },
  { value: 'SCHEDULED', label: 'برنامه‌ریزی شده' },
  { value: 'CONFIRMED', label: 'تایید شده' },
  { value: 'COMPLETED', label: 'انجام شده' },
  { value: 'CANCELLED', label: 'لغو شده' },
  { value: 'NO_SHOW', label: 'عدم حضور' },
];

/* ─────────── Helpers ─────────── */

function formatPersianDateTime(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function formatTime(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

function getRelatedName(apt: Appointment): string {
  if (apt.lead) return apt.lead.name;
  if (apt.karAmuz) return `${apt.karAmuz.firstName} ${apt.karAmuz.lastName}`;
  return '-';
}

function getInitials(name: string): string {
  if (!name) return '؟';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].charAt(0);
  return parts[0].charAt(0) + parts[parts.length - 1].charAt(0);
}

/* ─────────── Main Component ─────────── */

export default function AppointmentsPage() {
  /* ── State ── */
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');

  // Add dialog
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formTitle, setFormTitle] = useState('');
  const [formType, setFormType] = useState('CONSULTATION');
  const [formStartTime, setFormStartTime] = useState('');
  const [formEndTime, setFormEndTime] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formMeetingUrl, setFormMeetingUrl] = useState('');
  const [formAssignedTo, setFormAssignedTo] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formLeadId, setFormLeadId] = useState('');
  const [formKarAmuzId, setFormKarAmuzId] = useState('');

  // Lead/KarAmuz search
  const [leadOptions, setLeadOptions] = useState<LeadOption[]>([]);
  const [karAmuzOptions, setKarAmuzOptions] = useState<KarAmuzOption[]>([]);
  const [leadSearch, setLeadSearch] = useState('');
  const [karAmuzSearch, setKarAmuzSearch] = useState('');
  const [leadsLoading, setLeadsLoading] = useState(false);
  const [karAmuzLoading, setKarAmuzLoading] = useState(false);

  // Status change
  const [statusSubmitting, setStatusSubmitting] = useState<string | null>(null);

  // View mode
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');

  /* ── Data fetching ── */

  const fetchAppointments = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (filterStatus && filterStatus !== 'all') params.set('status', filterStatus);
      if (filterType && filterType !== 'all') params.set('type', filterType);

      const res = await fetch(`/api/crm/appointments?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت قرارها');
        return;
      }

      setAppointments(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterStatus, filterType]);

  useEffect(() => {
    fetchAppointments();
  }, [fetchAppointments]);

  const fetchLeads = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setLeadOptions([]); return; }
    setLeadsLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/leads?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setLeadOptions((data['داده‌ها'] || []).map((l: { id: string; name: string }) => ({ id: l.id, name: l.name })));
      }
    } catch { /* silent */ } finally { setLeadsLoading(false); }
  }, []);

  const fetchKarAmuz = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setKarAmuzOptions([]); return; }
    setKarAmuzLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/karamuz?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setKarAmuzOptions((data['داده‌ها'] || []).map((k: { id: string; firstName: string; lastName: string }) => ({ id: k.id, firstName: k.firstName, lastName: k.lastName })));
      }
    } catch { /* silent */ } finally { setKarAmuzLoading(false); }
  }, []);

  /* ── Computed ── */

  const now = useMemo(() => new Date(), []);

  const upcoming = useMemo(() =>
    appointments
      .filter(a => new Date(a.startTime) >= now && a.status !== 'CANCELLED')
      .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()),
    [appointments, now]
  );

  const past = useMemo(() =>
    appointments
      .filter(a => new Date(a.startTime) < now || a.status === 'CANCELLED')
      .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime()),
    [appointments, now]
  );

  /* ── Modal handlers ── */

  const openAddDialog = () => {
    setFormTitle('');
    setFormType('CONSULTATION');
    setFormStartTime('');
    setFormEndTime('');
    setFormLocation('');
    setFormMeetingUrl('');
    setFormAssignedTo('');
    setFormDescription('');
    setFormLeadId('');
    setFormKarAmuzId('');
    setLeadSearch('');
    setKarAmuzSearch('');
    setLeadOptions([]);
    setKarAmuzOptions([]);
    setAddDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formTitle.trim() || !formStartTime || !formEndTime) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formTitle.trim(),
          type: formType,
          startTime: formStartTime,
          endTime: formEndTime,
          location: formLocation || null,
          meetingUrl: formMeetingUrl || null,
          assignedTo: formAssignedTo || null,
          description: formDescription || null,
          leadId: formLeadId || null,
          karAmuzId: formKarAmuzId || null,
        }),
      });

      if (res.ok) {
        setAddDialogOpen(false);
        fetchAppointments();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const handleStatusChange = async (appointmentId: string, newStatus: string) => {
    setStatusSubmitting(appointmentId);
    try {
      const res = await fetch('/api/crm/appointments', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appointmentId, status: newStatus }),
      });

      if (res.ok) {
        fetchAppointments();
      }
    } catch { /* silent */ } finally { setStatusSubmitting(null); }
  };

  /* ──── Render ──── */

  const renderAppointmentCard = (apt: Appointment) => {
    const typeMeta = TYPE_META[apt.type] || TYPE_META.OTHER;
    const statusMeta = STATUS_META[apt.status] || STATUS_META.SCHEDULED;
    const isSubmitting = statusSubmitting === apt.id;

    return (
      <div
        key={apt.id}
        className={`bg-white rounded-xl shadow-sm border p-4 transition-all hover:shadow-md ${
          apt.status === 'CANCELLED' ? 'opacity-50' :
          apt.status === 'COMPLETED' ? 'opacity-60' : ''
        }`}
      >
        {/* Title + badges */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <h3 className="font-bold text-gray-900 text-base">{apt.title}</h3>
          <Badge variant="secondary" className={`${typeMeta.bgColor} ${typeMeta.color} text-xs border-0`}>
            {typeMeta.label}
          </Badge>
          <Badge variant="secondary" className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
            {statusMeta.label}
          </Badge>
        </div>

        {/* Date/Time */}
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
          <Clock className="w-4 h-4 text-gray-400 shrink-0" />
          <span>{formatPersianDateTime(apt.startTime)}</span>
          <span className="text-gray-400">تا</span>
          <span>{formatTime(apt.endTime)}</span>
        </div>

        {/* Location */}
        {apt.location && (
          <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
            <MapPin className="w-4 h-4 text-gray-400 shrink-0" />
            <span>{apt.location}</span>
          </div>
        )}

        {/* Meeting URL */}
        {apt.meetingUrl && (
          <div className="flex items-center gap-2 text-sm mb-2">
            <Video className="w-4 h-4 text-gray-400 shrink-0" />
            <a
              href={apt.meetingUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-teal-600 hover:text-teal-800 hover:underline truncate"
            >
              لینک جلسه
            </a>
          </div>
        )}

        {/* Related person + assigned to */}
        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mt-2">
          {(apt.lead || apt.karAmuz) && (
            <div className="flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-teal-500" />
              <span className="text-teal-700 font-medium">{getRelatedName(apt)}</span>
            </div>
          )}
          {apt.assignedTo && (
            <div className="flex items-center gap-1.5">
              <div className="w-5 h-5 rounded-full bg-teal-100 flex items-center justify-center">
                <span className="text-[10px] font-bold text-teal-700">
                  {getInitials(apt.assignedTo)}
                </span>
              </div>
              <span>{apt.assignedTo}</span>
            </div>
          )}
        </div>

        {/* Status change buttons */}
        {apt.status !== 'COMPLETED' && apt.status !== 'CANCELLED' && (
          <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-gray-100">
            {apt.status === 'SCHEDULED' && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleStatusChange(apt.id, 'CONFIRMED')}
                disabled={!!isSubmitting}
                className="gap-1 text-green-700 border-green-200 hover:bg-green-50 text-xs"
              >
                {isSubmitting ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
                تایید
              </Button>
            )}
            {(apt.status === 'SCHEDULED' || apt.status === 'CONFIRMED') && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleStatusChange(apt.id, 'COMPLETED')}
                disabled={!!isSubmitting}
                className="gap-1 text-gray-700 border-gray-200 hover:bg-gray-50 text-xs"
              >
                {isSubmitting ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
                انجام شد
              </Button>
            )}
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleStatusChange(apt.id, 'CANCELLED')}
              disabled={!!isSubmitting}
              className="gap-1 text-red-700 border-red-200 hover:bg-red-50 text-xs"
            >
              {isSubmitting ? <Loader2 className="w-3 h-3 animate-spin" /> : <XCircle className="w-3 h-3" />}
              لغو
            </Button>
            {(apt.status === 'SCHEDULED' || apt.status === 'CONFIRMED') && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleStatusChange(apt.id, 'NO_SHOW')}
                disabled={!!isSubmitting}
                className="gap-1 text-orange-700 border-orange-200 hover:bg-orange-50 text-xs"
              >
                {isSubmitting ? <Loader2 className="w-3 h-3 animate-spin" /> : <XCircle className="w-3 h-3" />}
                عدم حضور
              </Button>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <CalendarCheck className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">قرارهای ملاقات</h1>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت قرارها و جلسات</p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          {/* View Mode Toggle */}
          <div className="flex border border-gray-200 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 text-xs font-medium transition-colors flex items-center gap-1.5 ${
                viewMode === 'list'
                  ? 'bg-teal-600 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              لیست
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`px-3 py-1.5 text-xs font-medium transition-colors flex items-center gap-1.5 border-r border-gray-200 ${
                viewMode === 'calendar'
                  ? 'bg-teal-600 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" />
              تقویم
            </button>
          </div>
          <Button
            onClick={openAddDialog}
            className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
          >
            <Plus className="w-4 h-4" />
            قرار جدید
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="جستجوی عنوان..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10 bg-white"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-44 bg-white">
            <SelectValue placeholder="وضعیت" />
          </SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-full sm:w-40 bg-white">
            <SelectValue placeholder="نوع" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه انواع</SelectItem>
            {TYPE_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Content */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-36 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchAppointments}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : viewMode === 'calendar' ? (
        /* Calendar View */
        <AppointmentCalendar appointments={appointments} />
      ) : (
        /* List View */
        <div className="space-y-8">
          {/* Upcoming */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-5 h-5 text-teal-600" />
              <h2 className="text-lg font-bold text-gray-900">قرارهای پیش‌رو</h2>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(upcoming.length)}
              </Badge>
            </div>
            {upcoming.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-8 text-center">
                  <CalendarCheck className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">قرار پیش‌رویی وجود ندارد</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {upcoming.map(renderAppointmentCard)}
              </div>
            )}
          </div>

          {/* Past */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-gray-500" />
              <h2 className="text-lg font-bold text-gray-900">گذشته</h2>
              <Badge variant="secondary" className="bg-gray-100 text-gray-600 text-xs">
                {toPersianNumber(past.length)}
              </Badge>
            </div>
            {past.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-8 text-center">
                  <Clock className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">قرار گذشته‌ای وجود ندارد</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {past.map(renderAppointmentCard)}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Appointment Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <CalendarCheck className="w-5 h-5 text-teal-600" />
              قرار جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Title */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">
                عنوان <span className="text-red-500">*</span>
              </Label>
              <Input
                placeholder="عنوان قرار..."
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
              />
            </div>

            {/* Type */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">نوع</Label>
              <Select value={formType} onValueChange={setFormType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TYPE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Start/End time */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">
                  شروع <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="datetime-local"
                  value={formStartTime}
                  onChange={(e) => setFormStartTime(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">
                  پایان <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="datetime-local"
                  value={formEndTime}
                  onChange={(e) => setFormEndTime(e.target.value)}
                />
              </div>
            </div>

            {/* Location */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">محل</Label>
              <Input
                placeholder="آدرس یا محل برگزاری..."
                value={formLocation}
                onChange={(e) => setFormLocation(e.target.value)}
              />
            </div>

            {/* Meeting URL */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">لینک جلسه آنلاین</Label>
              <Input
                placeholder="https://..."
                value={formMeetingUrl}
                onChange={(e) => setFormMeetingUrl(e.target.value)}
                dir="ltr"
              />
            </div>

            {/* Assigned to */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">مسئول</Label>
              <Input
                placeholder="نام مسئول..."
                value={formAssignedTo}
                onChange={(e) => setFormAssignedTo(e.target.value)}
              />
            </div>

            {/* Lead search */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">لید مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder="جستجوی لید..."
                  value={leadSearch}
                  onChange={(e) => {
                    setLeadSearch(e.target.value);
                    fetchLeads(e.target.value);
                  }}
                />
                {leadsLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {leadOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {leadOptions.map((lead) => (
                    <button
                      key={lead.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-teal-50 transition-colors ${
                        formLeadId === lead.id ? 'bg-teal-50 text-teal-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormLeadId(lead.id);
                        setLeadSearch(lead.name);
                        setLeadOptions([]);
                      }}
                    >
                      {lead.name}
                    </button>
                  ))}
                </div>
              )}
              {formLeadId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                    {leadSearch}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => { setFormLeadId(''); setLeadSearch(''); }}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* KarAmuz search */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">کارآموز مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder="جستجوی کارآموز..."
                  value={karAmuzSearch}
                  onChange={(e) => {
                    setKarAmuzSearch(e.target.value);
                    fetchKarAmuz(e.target.value);
                  }}
                />
                {karAmuzLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {karAmuzOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {karAmuzOptions.map((ka) => (
                    <button
                      key={ka.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-purple-50 transition-colors ${
                        formKarAmuzId === ka.id ? 'bg-purple-50 text-purple-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormKarAmuzId(ka.id);
                        setKarAmuzSearch(`${ka.firstName} ${ka.lastName}`);
                        setKarAmuzOptions([]);
                      }}
                    >
                      {ka.firstName} {ka.lastName}
                    </button>
                  ))}
                </div>
              )}
              {formKarAmuzId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-purple-50 text-purple-700 text-xs">
                    {karAmuzSearch}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => { setFormKarAmuzId(''); setKarAmuzSearch(''); }}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">توضیحات</Label>
              <Textarea
                placeholder="توضیحات..."
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                rows={2}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ثبت قرار
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
