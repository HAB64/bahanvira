'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import {
  Target,
  Plus,
  Loader2,
  AlertTriangle,
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface SalesTarget {
  id: string;
  title: string;
  period: string;
  startDate: string;
  endDate: string;
  assignedTo: string;
  targetRevenue: number;
  targetEnrollments: number;
  targetLeads: number;
  actualRevenue: number;
  actualEnrollments: number;
  actualLeads: number;
  status: string;
  revenueProgress: number;
  enrollmentProgress: number;
  leadsProgress: number;
  createdAt: string;
  updatedAt: string;
}

/* ─────────── Constants ─────────── */

const PERIOD_META: Record<string, { label: string; color: string; bgColor: string }> = {
  MONTHLY: { label: 'ماهانه', color: 'text-teal-700', bgColor: 'bg-teal-100' },
  QUARTERLY: { label: 'فصلی', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  YEARLY: { label: 'سالانه', color: 'text-purple-700', bgColor: 'bg-purple-100' },
};

const PERIOD_OPTIONS = [
  { value: 'MONTHLY', label: 'ماهانه' },
  { value: 'QUARTERLY', label: 'فصلی' },
  { value: 'YEARLY', label: 'سالانه' },
];

/* ─────────── Helpers ─────────── */

function formatToman(amount: number) {
  const toman = Math.round(amount / 10);
  return toPersianNumber(toman.toLocaleString('en-US')) + ' تومان';
}

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function getProgressColor(pct: number): string {
  if (pct >= 80) return 'bg-green-500';
  if (pct >= 50) return 'bg-yellow-500';
  return 'bg-red-500';
}

function getProgressTextColor(pct: number): string {
  if (pct >= 80) return 'text-green-700';
  if (pct >= 50) return 'text-yellow-700';
  return 'text-red-700';
}

function getProgressBgColor(pct: number): string {
  if (pct >= 80) return 'bg-green-50';
  if (pct >= 50) return 'bg-yellow-50';
  return 'bg-red-50';
}

/* ─────────── Main Component ─────────── */

export default function SalesTargetsPage() {
  /* ── State ── */
  const [targets, setTargets] = useState<SalesTarget[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Add dialog
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formTitle, setFormTitle] = useState('');
  const [formPeriod, setFormPeriod] = useState('MONTHLY');
  const [formStartDate, setFormStartDate] = useState('');
  const [formEndDate, setFormEndDate] = useState('');
  const [formTargetRevenue, setFormTargetRevenue] = useState('');
  const [formTargetEnrollments, setFormTargetEnrollments] = useState('');
  const [formTargetLeads, setFormTargetLeads] = useState('');
  const [formAssignedTo, setFormAssignedTo] = useState('');

  // Status change
  const [statusSubmitting, setStatusSubmitting] = useState<string | null>(null);

  /* ── Data fetching ── */

  const fetchTargets = useCallback(async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/crm/sales-targets');
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت اهداف');
        return;
      }

      setTargets(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTargets();
  }, [fetchTargets]);

  /* ── Computed ── */

  const activeTargets = useMemo(() =>
    targets.filter(t => t.status === 'ACTIVE'),
    [targets]
  );

  const completedTargets = useMemo(() =>
    targets.filter(t => t.status === 'COMPLETED' || t.status === 'CANCELLED'),
    [targets]
  );

  /* ── Modal handlers ── */

  const openAddDialog = () => {
    setFormTitle('');
    setFormPeriod('MONTHLY');
    setFormStartDate('');
    setFormEndDate('');
    setFormTargetRevenue('');
    setFormTargetEnrollments('');
    setFormTargetLeads('');
    setFormAssignedTo('');
    setAddDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formTitle.trim() || !formStartDate || !formEndDate) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/sales-targets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formTitle.trim(),
          period: formPeriod,
          startDate: formStartDate,
          endDate: formEndDate,
          assignedTo: formAssignedTo || null,
          targetRevenue: parseInt(formTargetRevenue) * 10 || 0, // convert toman to rial
          targetEnrollments: parseInt(formTargetEnrollments) || 0,
          targetLeads: parseInt(formTargetLeads) || 0,
        }),
      });

      if (res.ok) {
        setAddDialogOpen(false);
        fetchTargets();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const handleStatusChange = async (targetId: string, newStatus: string) => {
    setStatusSubmitting(targetId);
    try {
      const res = await fetch('/api/crm/sales-targets', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetId, status: newStatus }),
      });

      if (res.ok) {
        fetchTargets();
      }
    } catch { /* silent */ } finally { setStatusSubmitting(null); }
  };

  /* ── Progress bar component ── */
  const ProgressBar = ({ label, actual, target, pct, icon: Icon, formatFn }: {
    label: string;
    actual: number;
    target: number;
    pct: number;
    icon: React.ElementType;
    formatFn: (n: number) => string;
  }) => (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Icon className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-600">{label}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500">
            {formatFn(actual)} / {formatFn(target)}
          </span>
          <Badge
            variant="secondary"
            className={`${getProgressBgColor(pct)} ${getProgressTextColor(pct)} text-xs border-0 px-1.5 py-0 h-5`}
          >
            {toPersianNumber(Math.min(pct, 999))}٪
          </Badge>
        </div>
      </div>
      <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-500 ${getProgressColor(pct)}`}
          style={{ width: `${Math.min(pct, 100)}%` }}
        />
      </div>
    </div>
  );

  /* ──── Render ──── */

  const renderTargetCard = (target: SalesTarget, showActions: boolean = true) => {
    const periodMeta = PERIOD_META[target.period] || PERIOD_META.MONTHLY;
    const isSubmitting = statusSubmitting === target.id;

    return (
      <Card key={target.id} className="border-0 shadow-sm">
        <CardContent className="p-5">
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <div>
              <h3 className="font-bold text-gray-900 text-base">{target.title}</h3>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="secondary" className={`${periodMeta.bgColor} ${periodMeta.color} text-xs border-0`}>
                  {periodMeta.label}
                </Badge>
                {target.assignedTo && (
                  <span className="text-xs text-gray-500">مسئول: {target.assignedTo}</span>
                )}
              </div>
            </div>
            {target.status === 'COMPLETED' && (
              <Badge className="bg-green-100 text-green-700 border-0 text-xs">
                <CheckCircle2 className="w-3 h-3 ml-1" />
                تکمیل شده
              </Badge>
            )}
            {target.status === 'CANCELLED' && (
              <Badge className="bg-red-100 text-red-700 border-0 text-xs">
                <XCircle className="w-3 h-3 ml-1" />
                لغو شده
              </Badge>
            )}
          </div>

          {/* Date range */}
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
            <Calendar className="w-4 h-4" />
            <span>{formatPersianDate(target.startDate)} تا {formatPersianDate(target.endDate)}</span>
          </div>

          {/* Progress bars */}
          <div className="space-y-4">
            <ProgressBar
              label="درآمد"
              actual={target.actualRevenue}
              target={target.targetRevenue}
              pct={target.revenueProgress}
              icon={DollarSign}
              formatFn={formatToman}
            />
            <ProgressBar
              label="ثبت‌نام"
              actual={target.actualEnrollments}
              target={target.targetEnrollments}
              pct={target.enrollmentProgress}
              icon={TrendingUp}
              formatFn={(n) => toPersianNumber(n)}
            />
            <ProgressBar
              label="لیدها"
              actual={target.actualLeads}
              target={target.targetLeads}
              pct={target.leadsProgress}
              icon={Users}
              formatFn={(n) => toPersianNumber(n)}
            />
          </div>

          {/* Actions */}
          {showActions && target.status === 'ACTIVE' && (
            <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-gray-100">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleStatusChange(target.id, 'COMPLETED')}
                disabled={!!isSubmitting}
                className="gap-1 text-green-700 border-green-200 hover:bg-green-50 text-xs"
              >
                {isSubmitting ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
                تکمیل
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleStatusChange(target.id, 'CANCELLED')}
                disabled={!!isSubmitting}
                className="gap-1 text-red-700 border-red-200 hover:bg-red-50 text-xs"
              >
                {isSubmitting ? <Loader2 className="w-3 h-3 animate-spin" /> : <XCircle className="w-3 h-3" />}
                لغو
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Target className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">اهداف فروش</h1>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت و پیگیری اهداف فروش</p>
          </div>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          هدف جدید
        </Button>
      </div>

      {/* Content */}
      {loading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-64 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchTargets}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {/* Active targets */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-teal-600" />
              <h2 className="text-lg font-bold text-gray-900">اهداف فعال</h2>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(activeTargets.length)}
              </Badge>
            </div>
            {activeTargets.length === 0 ? (
              <Card className="border-0 shadow-sm">
                <CardContent className="p-8 text-center">
                  <Target className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">هدف فعالی وجود ندارد</p>
                  <Button
                    onClick={openAddDialog}
                    className="mt-3 bg-teal-600 hover:bg-teal-700 text-white gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    ایجاد هدف
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {activeTargets.map(t => renderTargetCard(t, true))}
              </div>
            )}
          </div>

          {/* Completed targets */}
          {completedTargets.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-4">
                <CheckCircle2 className="w-5 h-5 text-gray-500" />
                <h2 className="text-lg font-bold text-gray-900">اهداف تکمیل شده</h2>
                <Badge variant="secondary" className="bg-gray-100 text-gray-600 text-xs">
                  {toPersianNumber(completedTargets.length)}
                </Badge>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {completedTargets.map(t => renderTargetCard(t, false))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Add Target Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Target className="w-5 h-5 text-teal-600" />
              هدف فروش جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Title */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">
                عنوان <span className="text-red-500">*</span>
              </Label>
              <Input
                placeholder="عنوان هدف..."
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
              />
            </div>

            {/* Period */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">دوره</Label>
              <Select value={formPeriod} onValueChange={setFormPeriod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PERIOD_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date range */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">
                  تاریخ شروع <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="date"
                  value={formStartDate}
                  onChange={(e) => setFormStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">
                  تاریخ پایان <span className="text-red-500">*</span>
                </Label>
                <Input
                  type="date"
                  value={formEndDate}
                  onChange={(e) => setFormEndDate(e.target.value)}
                />
              </div>
            </div>

            {/* Targets */}
            <div className="space-y-3 border-t pt-3">
              <p className="text-sm font-bold text-gray-700">اهداف عددی</p>

              <div className="space-y-1.5">
                <Label className="text-sm font-medium">هدف درآمد (تومان)</Label>
                <Input
                  type="number"
                  min={0}
                  placeholder="مبلغ به تومان..."
                  value={formTargetRevenue}
                  onChange={(e) => setFormTargetRevenue(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">هدف ثبت‌نام</Label>
                  <Input
                    type="number"
                    min={0}
                    placeholder="تعداد..."
                    value={formTargetEnrollments}
                    onChange={(e) => setFormTargetEnrollments(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-sm font-medium">هدف لیدها</Label>
                  <Input
                    type="number"
                    min={0}
                    placeholder="تعداد..."
                    value={formTargetLeads}
                    onChange={(e) => setFormTargetLeads(e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Assigned to */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">مسئول (اختیاری)</Label>
              <Input
                placeholder="خالی = کل سازمان"
                value={formAssignedTo}
                onChange={(e) => setFormAssignedTo(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ثبت هدف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
