import { db } from '@/lib/db';
import { toPersianNumber } from '@/lib/persian';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ClipboardCheck,
  Star,
  TrendingUp,
  TrendingDown,
  Minus,
  Users,
  ThumbsUp,
  MessageSquare,
  Award,
  Building2,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  ArrowLeftRight,
} from 'lucide-react';

// ─── Types ──────────────────────────────────────────────────────────

interface SurveyStats {
  totalCount: number;
  avgContentQuality: number;
  avgInstructorScore: number;
  avgFacilitiesScore: number;
  avgOverallScore: number;
  avgNps: number;
  npsValue: number;
  recommendRate: number;
  promoters: number;
  passives: number;
  detractors: number;
  instructorStats: Record<string, {
    count: number;
    avgOverall: number;
    avgInstructor: number;
    recentAvg: number;
    previousAvg: number;
  }>;
  typeStats: Record<string, {
    count: number;
    avgOverall: number;
  }>;
  trend: {
    recentAvg: number;
    previousAvg: number;
    change: number;
  };
  recentComments: {
    id: string;
    comment: string | null;
    type: string;
    overallScore: number;
    createdAt: Date;
    karAmuzName: string | null;
  }[];
}

// ─── Data Fetching ──────────────────────────────────────────────────

async function getQualityData(): Promise<SurveyStats> {
  const empty: SurveyStats = {
    totalCount: 0,
    avgContentQuality: 0,
    avgInstructorScore: 0,
    avgFacilitiesScore: 0,
    avgOverallScore: 0,
    avgNps: 0,
    npsValue: 0,
    recommendRate: 0,
    promoters: 0,
    passives: 0,
    detractors: 0,
    instructorStats: {},
    typeStats: {},
    trend: { recentAvg: 0, previousAvg: 0, change: 0 },
    recentComments: [],
  };

  try {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);

    // Fetch all surveys with related data
    const surveys = await db.surveyResult.findMany({
      select: {
        id: true,
        contentQuality: true,
        instructorScore: true,
        facilitiesScore: true,
        overallScore: true,
        npsScore: true,
        wouldRecommend: true,
        type: true,
        instructorName: true,
        comment: true,
        createdAt: true,
        karAmuz: {
          select: { firstName: true, lastName: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const totalCount = surveys.length;

    if (totalCount === 0) return empty;

    // Calculate averages
    const avgContentQuality = surveys.reduce((sum, s) => sum + s.contentQuality, 0) / totalCount;
    const avgInstructorScore = surveys.reduce((sum, s) => sum + s.instructorScore, 0) / totalCount;
    const avgFacilitiesScore = surveys.reduce((sum, s) => sum + s.facilitiesScore, 0) / totalCount;
    const avgOverallScore = surveys.reduce((sum, s) => sum + s.overallScore, 0) / totalCount;
    const avgNps = surveys.reduce((sum, s) => sum + s.npsScore, 0) / totalCount;

    // NPS breakdown
    const promoters = surveys.filter(s => s.npsScore >= 9).length;
    const passives = surveys.filter(s => s.npsScore >= 7 && s.npsScore <= 8).length;
    const detractors = surveys.filter(s => s.npsScore <= 6).length;
    const npsValue = Math.round((promoters - detractors) / totalCount * 100);

    // Recommend rate
    const recommendCount = surveys.filter(s => s.wouldRecommend === true).length;
    const totalRecommendAnswered = surveys.filter(s => s.wouldRecommend !== null).length;
    const recommendRate = totalRecommendAnswered > 0
      ? (recommendCount / totalRecommendAnswered) * 100
      : 0;

    // Group by instructor
    const instructorStats: SurveyStats['instructorStats'] = {};
    for (const s of surveys) {
      const key = s.instructorName || 'نامشخص';
      if (!instructorStats[key]) {
        instructorStats[key] = { count: 0, avgOverall: 0, avgInstructor: 0, recentAvg: 0, previousAvg: 0 };
      }
      instructorStats[key].count++;
      instructorStats[key].avgOverall += s.overallScore;
      instructorStats[key].avgInstructor += s.instructorScore;
    }

    // Finalize instructor averages + trend
    for (const key of Object.keys(instructorStats)) {
      const stat = instructorStats[key];
      stat.avgOverall = Number((stat.avgOverall / stat.count).toFixed(2));
      stat.avgInstructor = Number((stat.avgInstructor / stat.count).toFixed(2));

      // Calculate per-instructor trend
      const instructorSurveys = surveys.filter(s => (s.instructorName || 'نامشخص') === key);
      const recentInstructor = instructorSurveys.filter(s => new Date(s.createdAt) >= thirtyDaysAgo);
      const previousInstructor = instructorSurveys.filter(s => {
        const d = new Date(s.createdAt);
        return d >= sixtyDaysAgo && d < thirtyDaysAgo;
      });
      stat.recentAvg = recentInstructor.length > 0
        ? Number((recentInstructor.reduce((sum, s) => sum + s.overallScore, 0) / recentInstructor.length).toFixed(2))
        : 0;
      stat.previousAvg = previousInstructor.length > 0
        ? Number((previousInstructor.reduce((sum, s) => sum + s.overallScore, 0) / previousInstructor.length).toFixed(2))
        : 0;
    }

    // Group by type
    const typeStats: SurveyStats['typeStats'] = {};
    for (const s of surveys) {
      if (!typeStats[s.type]) {
        typeStats[s.type] = { count: 0, avgOverall: 0 };
      }
      typeStats[s.type].count++;
      typeStats[s.type].avgOverall += s.overallScore;
    }
    for (const key of Object.keys(typeStats)) {
      typeStats[key].avgOverall = Number((typeStats[key].avgOverall / typeStats[key].count).toFixed(2));
    }

    // Trend (last 30 vs previous 30)
    const recentSurveys = surveys.filter(s => new Date(s.createdAt) >= thirtyDaysAgo);
    const previousSurveys = surveys.filter(s => {
      const d = new Date(s.createdAt);
      return d >= sixtyDaysAgo && d < thirtyDaysAgo;
    });
    const recentAvg = recentSurveys.length > 0
      ? recentSurveys.reduce((sum, s) => sum + s.overallScore, 0) / recentSurveys.length
      : 0;
    const previousAvg = previousSurveys.length > 0
      ? previousSurveys.reduce((sum, s) => sum + s.overallScore, 0) / previousSurveys.length
      : 0;

    // Recent comments (last 10)
    const recentComments = surveys
      .filter(s => s.comment && s.comment.trim() !== '')
      .slice(0, 10)
      .map(s => ({
        id: s.id,
        comment: s.comment,
        type: s.type,
        overallScore: s.overallScore,
        createdAt: s.createdAt,
        karAmuzName: s.karAmuz ? `${s.karAmuz.firstName} ${s.karAmuz.lastName}` : null,
      }));

    return {
      totalCount,
      avgContentQuality: Number(avgContentQuality.toFixed(2)),
      avgInstructorScore: Number(avgInstructorScore.toFixed(2)),
      avgFacilitiesScore: Number(avgFacilitiesScore.toFixed(2)),
      avgOverallScore: Number(avgOverallScore.toFixed(2)),
      avgNps: Number(avgNps.toFixed(2)),
      npsValue,
      recommendRate: Number(recommendRate.toFixed(1)),
      promoters,
      passives,
      detractors,
      instructorStats,
      typeStats,
      trend: {
        recentAvg: Number(recentAvg.toFixed(2)),
        previousAvg: Number(previousAvg.toFixed(2)),
        change: Number((recentAvg - previousAvg).toFixed(2)),
      },
      recentComments,
    };
  } catch (error) {
    console.error('Quality dashboard data fetch error:', error);
    return empty;
  }
}

// ─── Helper Functions ────────────────────────────────────────────────

const TYPE_LABELS: Record<string, string> = {
  POST_COURSE: 'پایان دوره',
  MID_COURSE: 'اواسط دوره',
  INSTRUCTOR: 'مدرس',
  GENERAL: 'عمومی',
};

function getScoreColor(score: number): string {
  if (score >= 4) return 'text-emerald-600';
  if (score >= 3) return 'text-amber-600';
  return 'text-red-600';
}

function getScoreBadgeVariant(score: number): 'default' | 'secondary' | 'destructive' {
  if (score >= 4) return 'default';
  if (score >= 3) return 'secondary';
  return 'destructive';
}

function getScoreBg(score: number): string {
  if (score >= 4) return 'bg-emerald-500';
  if (score >= 3) return 'bg-amber-500';
  return 'bg-red-500';
}

function getScoreBgLight(score: number): string {
  if (score >= 4) return 'bg-emerald-50 border-emerald-200';
  if (score >= 3) return 'bg-amber-50 border-amber-200';
  return 'bg-red-50 border-red-200';
}

function formatPersianDate(date: Date): string {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(date));
}

// ─── Main Component ─────────────────────────────────────────────────

export default async function QualityDashboard() {
  const data = await getQualityData();

  // Sort instructor stats by avgOverall descending
  const sortedInstructors = Object.entries(data.instructorStats)
    .sort((a, b) => b[1].avgOverall - a[1].avgOverall);

  const hasData = data.totalCount > 0;

  return (
    <div className="space-y-6">
      {/* ─── Header ─── */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <ClipboardCheck className="h-7 w-7 text-teal-600" />
          داشبورد کیفیت آموزشی
        </h1>
        <p className="text-gray-500 mt-1">
          تحلیل نظرسنجی‌ها، امتیاز مدرسان و شاخص NPS
        </p>
      </div>

      {!hasData ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <ClipboardCheck className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <p className="text-lg font-medium text-gray-500">هنوز نظرسنجی ثبت نشده است</p>
            <p className="text-sm text-gray-400 mt-1">
              پس از ثبت اولین نظرسنجی، آمار کیفیت آموزشی نمایش داده می‌شود
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* ─── 1. Overview Cards ─── */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {/* Total Surveys */}
            <Card className="p-0 border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 rounded-lg bg-teal-100">
                    <ClipboardCheck className="h-5 w-5 text-teal-700" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-gray-900">
                  {toPersianNumber(data.totalCount)}
                </p>
                <p className="text-xs text-gray-500 mt-1">کل نظرسنجی‌ها</p>
              </CardContent>
            </Card>

            {/* Average Overall Score */}
            <Card className="p-0 border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 rounded-lg bg-amber-100">
                    <Star className="h-5 w-5 text-amber-700" />
                  </div>
                  <span className="text-xs text-gray-400">از ۵</span>
                </div>
                <p className={`text-2xl font-bold ${getScoreColor(data.avgOverallScore)}`}>
                  {toPersianNumber(data.avgOverallScore)}
                </p>
                <p className="text-xs text-gray-500 mt-1">میانگین امتیاز کلی</p>
              </CardContent>
            </Card>

            {/* NPS Score */}
            <Card className="p-0 border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 rounded-lg bg-violet-100">
                    <BarChart3 className="h-5 w-5 text-violet-700" />
                  </div>
                  <span className="text-xs text-gray-400">-۱۰۰ تا ۱۰۰</span>
                </div>
                <p className={`text-2xl font-bold ${data.npsValue >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {toPersianNumber(data.npsValue)}
                </p>
                <p className="text-xs text-gray-500 mt-1">شاخص NPS</p>
              </CardContent>
            </Card>

            {/* Recommend Rate */}
            <Card className="p-0 border-0 shadow-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 rounded-lg bg-emerald-100">
                    <ThumbsUp className="h-5 w-5 text-emerald-700" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-gray-900">
                  {toPersianNumber(data.recommendRate)}٪
                </p>
                <p className="text-xs text-gray-500 mt-1">نرخ توصیه به دیگران</p>
              </CardContent>
            </Card>
          </div>

          {/* ─── 2. Score Breakdown ─── */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Award className="h-5 w-5 text-teal-600" />
                تفکیک امتیازات
              </CardTitle>
              <CardDescription>میانگین امتیازات در هر بعد کیفیت</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Content Quality */}
                <div className={`p-4 rounded-xl border ${getScoreBgLight(data.avgContentQuality)}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-md bg-white/60">
                        <Star className="h-4 w-4 text-teal-600" />
                      </div>
                      <span className="text-sm font-medium text-gray-700">کیفیت محتوا</span>
                    </div>
                    <span className={`text-lg font-bold ${getScoreColor(data.avgContentQuality)}`}>
                      {toPersianNumber(data.avgContentQuality)}
                    </span>
                  </div>
                  <div className="h-2 bg-white/50 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreBg(data.avgContentQuality)} transition-all duration-700`}
                      style={{ width: `${(data.avgContentQuality / 5) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Instructor Score */}
                <div className={`p-4 rounded-xl border ${getScoreBgLight(data.avgInstructorScore)}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-md bg-white/60">
                        <Users className="h-4 w-4 text-teal-600" />
                      </div>
                      <span className="text-sm font-medium text-gray-700">امتیاز مدرس</span>
                    </div>
                    <span className={`text-lg font-bold ${getScoreColor(data.avgInstructorScore)}`}>
                      {toPersianNumber(data.avgInstructorScore)}
                    </span>
                  </div>
                  <div className="h-2 bg-white/50 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreBg(data.avgInstructorScore)} transition-all duration-700`}
                      style={{ width: `${(data.avgInstructorScore / 5) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Facilities Score */}
                <div className={`p-4 rounded-xl border ${getScoreBgLight(data.avgFacilitiesScore)}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-md bg-white/60">
                        <Building2 className="h-4 w-4 text-teal-600" />
                      </div>
                      <span className="text-sm font-medium text-gray-700">امتیاز امکانات</span>
                    </div>
                    <span className={`text-lg font-bold ${getScoreColor(data.avgFacilitiesScore)}`}>
                      {toPersianNumber(data.avgFacilitiesScore)}
                    </span>
                  </div>
                  <div className="h-2 bg-white/50 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreBg(data.avgFacilitiesScore)} transition-all duration-700`}
                      style={{ width: `${(data.avgFacilitiesScore / 5) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Overall Score */}
                <div className={`p-4 rounded-xl border ${getScoreBgLight(data.avgOverallScore)}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-md bg-white/60">
                        <Award className="h-4 w-4 text-teal-600" />
                      </div>
                      <span className="text-sm font-medium text-gray-700">امتیاز کلی</span>
                    </div>
                    <span className={`text-lg font-bold ${getScoreColor(data.avgOverallScore)}`}>
                      {toPersianNumber(data.avgOverallScore)}
                    </span>
                  </div>
                  <div className="h-2 bg-white/50 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${getScoreBg(data.avgOverallScore)} transition-all duration-700`}
                      style={{ width: `${(data.avgOverallScore / 5) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ─── 3. NPS Breakdown ─── */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-teal-600" />
                تفکیک NPS (شاخص خالص ترویج‌کنندگان)
              </CardTitle>
              <CardDescription>
                توزیع پاسخ‌دهندگان بر اساس امتیاز NPS (۰ تا ۱۰)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* NPS visual bar */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-bold text-gray-700">NPS:</span>
                    <span className={`text-2xl font-bold ${data.npsValue >= 50 ? 'text-emerald-600' : data.npsValue >= 0 ? 'text-amber-600' : 'text-red-600'}`}>
                      {toPersianNumber(data.npsValue)}
                    </span>
                    <Badge variant={data.npsValue >= 50 ? 'default' : data.npsValue >= 0 ? 'secondary' : 'destructive'} className="text-xs">
                      {data.npsValue >= 50 ? 'عالی' : data.npsValue >= 30 ? 'خوب' : data.npsValue >= 0 ? 'متوسط' : 'ضعیف'}
                    </Badge>
                  </div>
                  {/* Stacked bar */}
                  <div className="h-8 rounded-lg overflow-hidden flex bg-gray-100">
                    {data.detractors > 0 && (
                      <div
                        className="bg-red-400 flex items-center justify-center transition-all duration-700"
                        style={{ width: `${(data.detractors / data.totalCount) * 100}%`, minWidth: '2rem' }}
                      >
                        <span className="text-xs font-bold text-white drop-shadow-sm">
                          {toPersianNumber(data.detractors)}
                        </span>
                      </div>
                    )}
                    {data.passives > 0 && (
                      <div
                        className="bg-amber-400 flex items-center justify-center transition-all duration-700"
                        style={{ width: `${(data.passives / data.totalCount) * 100}%`, minWidth: '2rem' }}
                      >
                        <span className="text-xs font-bold text-white drop-shadow-sm">
                          {toPersianNumber(data.passives)}
                        </span>
                      </div>
                    )}
                    {data.promoters > 0 && (
                      <div
                        className="bg-emerald-400 flex items-center justify-center transition-all duration-700"
                        style={{ width: `${(data.promoters / data.totalCount) * 100}%`, minWidth: '2rem' }}
                      >
                        <span className="text-xs font-bold text-white drop-shadow-sm">
                          {toPersianNumber(data.promoters)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* NPS Categories */}
                <div className="grid grid-cols-3 gap-4">
                  {/* Promoters */}
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1.5 rounded-md bg-emerald-100">
                        <TrendingUp className="h-4 w-4 text-emerald-600" />
                      </div>
                      <span className="text-sm font-bold text-emerald-800">ترویج‌کننده</span>
                    </div>
                    <p className="text-xs text-emerald-600 mb-1">امتیاز ۹-۱۰</p>
                    <p className="text-xl font-bold text-emerald-900">
                      {toPersianNumber(data.promoters)}
                    </p>
                    <p className="text-xs text-emerald-500">
                      {toPersianNumber(data.totalCount > 0 ? ((data.promoters / data.totalCount) * 100).toFixed(1) : 0)}٪
                    </p>
                  </div>

                  {/* Passives */}
                  <div className="p-4 rounded-xl bg-amber-50 border border-amber-200">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1.5 rounded-md bg-amber-100">
                        <Minus className="h-4 w-4 text-amber-600" />
                      </div>
                      <span className="text-sm font-bold text-amber-800">مطمئن</span>
                    </div>
                    <p className="text-xs text-amber-600 mb-1">امتیاز ۷-۸</p>
                    <p className="text-xl font-bold text-amber-900">
                      {toPersianNumber(data.passives)}
                    </p>
                    <p className="text-xs text-amber-500">
                      {toPersianNumber(data.totalCount > 0 ? ((data.passives / data.totalCount) * 100).toFixed(1) : 0)}٪
                    </p>
                  </div>

                  {/* Detractors */}
                  <div className="p-4 rounded-xl bg-red-50 border border-red-200">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-1.5 rounded-md bg-red-100">
                        <TrendingDown className="h-4 w-4 text-red-600" />
                      </div>
                      <span className="text-sm font-bold text-red-800">منتقد</span>
                    </div>
                    <p className="text-xs text-red-600 mb-1">امتیاز ۰-۶</p>
                    <p className="text-xl font-bold text-red-900">
                      {toPersianNumber(data.detractors)}
                    </p>
                    <p className="text-xs text-red-500">
                      {toPersianNumber(data.totalCount > 0 ? ((data.detractors / data.totalCount) * 100).toFixed(1) : 0)}٪
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ─── 4. Instructor Quality Table ─── */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="h-5 w-5 text-teal-600" />
                جدول کیفیت مدرسان
              </CardTitle>
              <CardDescription>
                رتبه‌بندی مدرسان بر اساس میانگین امتیازات
              </CardDescription>
            </CardHeader>
            <CardContent>
              {sortedInstructors.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-right">رتبه</TableHead>
                        <TableHead className="text-right">نام مدرس</TableHead>
                        <TableHead className="text-right">تعداد نظرسنجی</TableHead>
                        <TableHead className="text-right">میانگین امتیاز کلی</TableHead>
                        <TableHead className="text-right">میانگین امتیاز مدرس</TableHead>
                        <TableHead className="text-right">روند</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedInstructors.map(([name, stat], index) => {
                        const trendDiff = stat.recentAvg - stat.previousAvg;
                        return (
                          <TableRow key={name}>
                            <TableCell>
                              <div className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-xs font-bold ${
                                index === 0 ? 'bg-amber-100 text-amber-700' :
                                index === 1 ? 'bg-gray-100 text-gray-600' :
                                index === 2 ? 'bg-orange-100 text-orange-700' :
                                'bg-gray-50 text-gray-500'
                              }`}>
                                {toPersianNumber(index + 1)}
                              </div>
                            </TableCell>
                            <TableCell className="font-medium text-gray-900">
                              {name}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs">
                                {toPersianNumber(stat.count)}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span className={`font-bold ${getScoreColor(stat.avgOverall)}`}>
                                  {toPersianNumber(stat.avgOverall)}
                                </span>
                                <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                  <div
                                    className={`h-full rounded-full ${getScoreBg(stat.avgOverall)}`}
                                    style={{ width: `${(stat.avgOverall / 5) * 100}%` }}
                                  />
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <span className={`font-bold ${getScoreColor(stat.avgInstructor)}`}>
                                {toPersianNumber(stat.avgInstructor)}
                              </span>
                            </TableCell>
                            <TableCell>
                              {stat.previousAvg > 0 ? (
                                <div className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${
                                  trendDiff > 0 ? 'bg-emerald-50 text-emerald-700' :
                                  trendDiff < 0 ? 'bg-red-50 text-red-700' :
                                  'bg-gray-50 text-gray-500'
                                }`}>
                                  {trendDiff > 0 ? (
                                    <ArrowUpRight className="h-3 w-3" />
                                  ) : trendDiff < 0 ? (
                                    <ArrowDownRight className="h-3 w-3" />
                                  ) : (
                                    <ArrowLeftRight className="h-3 w-3" />
                                  )}
                                  {toPersianNumber(Math.abs(trendDiff).toFixed(2))}
                                </div>
                              ) : (
                                <span className="text-xs text-gray-400">داده کافی نیست</span>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <Users className="h-10 w-10 mx-auto mb-2 opacity-40" />
                  <p className="text-sm">اطلاعاتی در مورد مدرسان موجود نیست</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* ─── 5. Survey Type Breakdown ─── */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <ClipboardCheck className="h-5 w-5 text-teal-600" />
                تفکیک بر اساس نوع نظرسنجی
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(data.typeStats).map(([type, stat]) => (
                  <div key={type} className={`p-4 rounded-xl border ${getScoreBgLight(stat.avgOverall)}`}>
                    <p className="text-sm font-bold text-gray-800 mb-1">
                      {TYPE_LABELS[type] || type}
                    </p>
                    <p className="text-xs text-gray-500 mb-3">
                      {toPersianNumber(stat.count)} نظرسنجی
                    </p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-white/50 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${getScoreBg(stat.avgOverall)} transition-all duration-700`}
                          style={{ width: `${(stat.avgOverall / 5) * 100}%` }}
                        />
                      </div>
                      <span className={`text-sm font-bold ${getScoreColor(stat.avgOverall)}`}>
                        {toPersianNumber(stat.avgOverall)}
                      </span>
                    </div>
                  </div>
                ))}

                {/* Show empty cards for missing types */}
                {['POST_COURSE', 'MID_COURSE', 'INSTRUCTOR', 'GENERAL']
                  .filter(t => !data.typeStats[t])
                  .map(t => (
                    <div key={t} className="p-4 rounded-xl border bg-gray-50 border-gray-200">
                      <p className="text-sm font-bold text-gray-400 mb-1">
                        {TYPE_LABELS[t]}
                      </p>
                      <p className="text-xs text-gray-400 mb-3">بدون داده</p>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-white/50 rounded-full overflow-hidden">
                          <div className="h-full rounded-full bg-gray-300" style={{ width: '0%' }} />
                        </div>
                        <span className="text-sm font-bold text-gray-400">—</span>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>

          {/* ─── 6. Monthly Trend ─── */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-teal-600" />
                روند ماهانه
              </CardTitle>
              <CardDescription>مقایسه میانگین امتیاز ۳۰ روز اخیر با ۳۰ روز قبلی</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Previous 30 days */}
                <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
                  <p className="text-xs text-gray-500 mb-1">۳۰ روز قبلی</p>
                  <p className="text-2xl font-bold text-gray-700">
                    {toPersianNumber(data.trend.previousAvg)}
                  </p>
                  <p className="text-xs text-gray-400">میانگین امتیاز کلی</p>
                </div>

                {/* Recent 30 days */}
                <div className="p-4 rounded-xl bg-teal-50 border border-teal-200">
                  <p className="text-xs text-teal-600 mb-1">۳۰ روز اخیر</p>
                  <p className="text-2xl font-bold text-teal-700">
                    {toPersianNumber(data.trend.recentAvg)}
                  </p>
                  <p className="text-xs text-teal-500">میانگین امتیاز کلی</p>
                </div>

                {/* Change */}
                <div className={`p-4 rounded-xl border ${
                  data.trend.change > 0 ? 'bg-emerald-50 border-emerald-200' :
                  data.trend.change < 0 ? 'bg-red-50 border-red-200' :
                  'bg-gray-50 border-gray-200'
                }`}>
                  <p className="text-xs text-gray-500 mb-1">تغییر</p>
                  <div className="flex items-center gap-2">
                    {data.trend.change > 0 ? (
                      <TrendingUp className="h-6 w-6 text-emerald-600" />
                    ) : data.trend.change < 0 ? (
                      <TrendingDown className="h-6 w-6 text-red-600" />
                    ) : (
                      <Minus className="h-6 w-6 text-gray-500" />
                    )}
                    <p className={`text-2xl font-bold ${
                      data.trend.change > 0 ? 'text-emerald-700' :
                      data.trend.change < 0 ? 'text-red-700' :
                      'text-gray-700'
                    }`}>
                      {data.trend.change > 0 ? '+' : ''}{toPersianNumber(data.trend.change)}
                    </p>
                  </div>
                  <p className="text-xs text-gray-400 mt-1">
                    {data.trend.change > 0 ? 'بهبود' : data.trend.change < 0 ? 'کاهش' : 'بدون تغییر'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* ─── 7. Recent Comments ─── */}
          <Card className="border-0 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-teal-600" />
                نظرات اخیر
              </CardTitle>
              <CardDescription>۱۰ نظر آخر ثبت‌شده در نظرسنجی‌ها</CardDescription>
            </CardHeader>
            <CardContent>
              {data.recentComments.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {data.recentComments.map((c) => (
                    <div
                      key={c.id}
                      className="p-4 rounded-xl bg-gray-50 border border-gray-100 hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            {c.karAmuzName && (
                              <span className="text-sm font-medium text-gray-800">
                                {c.karAmuzName}
                              </span>
                            )}
                            <Badge variant="outline" className="text-[10px] shrink-0 h-5">
                              {TYPE_LABELS[c.type] || c.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 leading-relaxed">
                            {c.comment}
                          </p>
                          <p className="text-[10px] text-gray-400 mt-1.5">
                            {formatPersianDate(c.createdAt)}
                          </p>
                        </div>
                        <div className={`shrink-0 inline-flex items-center justify-center w-10 h-10 rounded-lg text-sm font-bold ${
                          c.overallScore >= 4
                            ? 'bg-emerald-100 text-emerald-700'
                            : c.overallScore >= 3
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-red-100 text-red-700'
                        }`}>
                          {toPersianNumber(c.overallScore)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <MessageSquare className="h-10 w-10 mx-auto mb-2 opacity-40" />
                  <p className="text-sm">هنوز نظری ثبت نشده است</p>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
