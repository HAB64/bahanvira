'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Receipt,
  Plus,
  Search,
  Loader2,
  AlertTriangle,
  X,
  Trash2,
  Eye,
  Send,
  CheckCircle2,
  CreditCard,
  Clock,
  DollarSign,
  AlertOctagon,
  Wallet,
  Download,
  FileDown,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';
import { exportToCSV } from '@/lib/csv-export';

/* ─────────── Types ─────────── */

interface InvoiceItem {
  title: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface Invoice {
  id: string;
  invoiceNumber: string;
  leadId: string | null;
  karAmuzId: string | null;
  items: InvoiceItem[];
  subtotal: number;
  discountPct: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  paidAmount: number;
  status: string;
  issuedAt: string | null;
  dueDate: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  lead?: { id: string; name: string; phone: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string; phone: string } | null;
}

interface LeadOption {
  id: string;
  name: string;
}

interface KarAmuzOption {
  id: string;
  firstName: string;
  lastName: string;
}

/* ─────────── Constants ─────────── */

const STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  DRAFT: { label: 'پیش‌نویس', color: 'text-gray-700', bgColor: 'bg-gray-100' },
  SENT: { label: 'ارسال شده', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  PAID: { label: 'پرداخت شده', color: 'text-green-700', bgColor: 'bg-green-100' },
  PARTIALLY_PAID: { label: 'پرداخت جزئی', color: 'text-yellow-700', bgColor: 'bg-yellow-100' },
  CANCELLED: { label: 'لغو شده', color: 'text-red-700', bgColor: 'bg-red-100' },
  REFUNDED: { label: 'بازگشت وجه', color: 'text-purple-700', bgColor: 'bg-purple-100' },
};

const STATUS_OPTIONS = [
  { value: 'all', label: 'همه وضعیت‌ها' },
  { value: 'DRAFT', label: 'پیش‌نویس' },
  { value: 'SENT', label: 'ارسال شده' },
  { value: 'PAID', label: 'پرداخت شده' },
  { value: 'PARTIALLY_PAID', label: 'پرداخت جزئی' },
  { value: 'CANCELLED', label: 'لغو شده' },
  { value: 'REFUNDED', label: 'بازگشت وجه' },
];

/* ─────────── Helpers ─────────── */

function formatToman(amount: number) {
  const toman = Math.round(amount / 10);
  return toPersianNumber(toman.toLocaleString('en-US')) + ' تومان';
}

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function getRelatedName(invoice: Invoice): string {
  if (invoice.lead) return invoice.lead.name;
  if (invoice.karAmuz) return `${invoice.karAmuz.firstName} ${invoice.karAmuz.lastName}`;
  return '-';
}

/* ─────────── Main Component ─────────── */

export default function InvoicesPage() {
  /* ── State ── */
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Add dialog
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formLeadId, setFormLeadId] = useState('');
  const [formKarAmuzId, setFormKarAmuzId] = useState('');
  const [formItems, setFormItems] = useState<InvoiceItem[]>([
    { title: '', description: '', quantity: 1, unitPrice: 0, total: 0 },
  ]);
  const [formDiscountPct, setFormDiscountPct] = useState(0);
  const [formDueDate, setFormDueDate] = useState('');
  const [formIssuedAt, setFormIssuedAt] = useState('');
  const [formNotes, setFormNotes] = useState('');

  // Lead/KarAmuz search
  const [leadOptions, setLeadOptions] = useState<LeadOption[]>([]);
  const [karAmuzOptions, setKarAmuzOptions] = useState<KarAmuzOption[]>([]);
  const [leadSearch, setLeadSearch] = useState('');
  const [karAmuzSearch, setKarAmuzSearch] = useState('');
  const [leadsLoading, setLeadsLoading] = useState(false);
  const [karAmuzLoading, setKarAmuzLoading] = useState(false);

  // Detail dialog
  const [detailInvoice, setDetailInvoice] = useState<Invoice | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [statusSubmitting, setStatusSubmitting] = useState(false);

  // Payment dialog
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [paymentInvoiceId, setPaymentInvoiceId] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [paymentSubmitting, setPaymentSubmitting] = useState(false);

  /* ── Data fetching ── */

  const fetchInvoices = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (search) params.set('search', search);
      if (filterStatus && filterStatus !== 'all') params.set('status', filterStatus);

      const res = await fetch(`/api/crm/invoices?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت فاکتورها');
        return;
      }

      setInvoices(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterStatus]);

  useEffect(() => {
    fetchInvoices();
  }, [fetchInvoices]);

  const fetchLeads = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setLeadOptions([]); return; }
    setLeadsLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/leads?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setLeadOptions((data['داده‌ها'] || []).map((l: { id: string; name: string }) => ({ id: l.id, name: l.name })));
      }
    } catch { /* silent */ } finally { setLeadsLoading(false); }
  }, []);

  const fetchKarAmuz = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setKarAmuzOptions([]); return; }
    setKarAmuzLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/karamuz?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setKarAmuzOptions((data['داده‌ها'] || []).map((k: { id: string; firstName: string; lastName: string }) => ({ id: k.id, firstName: k.firstName, lastName: k.lastName })));
      }
    } catch { /* silent */ } finally { setKarAmuzLoading(false); }
  }, []);

  /* ── Computed ── */

  const stats = useMemo(() => ({
    total: invoices.length,
    DRAFT: invoices.filter(i => i.status === 'DRAFT').length,
    SENT: invoices.filter(i => i.status === 'SENT').length,
    PAID: invoices.filter(i => i.status === 'PAID').length,
    OVERDUE: invoices.filter(i => {
      if (!i.dueDate || i.status === 'PAID' || i.status === 'CANCELLED' || i.status === 'REFUNDED') return false;
      return new Date(i.dueDate) < new Date();
    }).length,
  }), [invoices]);

  const formSubtotal = useMemo(() =>
    formItems.reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0),
    [formItems]
  );

  const formDiscountAmount = useMemo(() =>
    Math.round(formSubtotal * formDiscountPct / 100),
    [formSubtotal, formDiscountPct]
  );

  const formAfterDiscount = useMemo(() =>
    formSubtotal - formDiscountAmount,
    [formSubtotal, formDiscountAmount]
  );

  const formTaxAmount = useMemo(() =>
    Math.round(formAfterDiscount * 0.09),
    [formAfterDiscount]
  );

  const formTotalAmount = useMemo(() =>
    formAfterDiscount + formTaxAmount,
    [formAfterDiscount, formTaxAmount]
  );

  /* ── Item editor handlers ── */

  const updateItem = (index: number, field: keyof InvoiceItem, value: string | number) => {
    setFormItems(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      if (field === 'unitPrice' || field === 'quantity') {
        updated[index].total = updated[index].unitPrice * updated[index].quantity;
      }
      return updated;
    });
  };

  const addItem = () => {
    setFormItems(prev => [...prev, { title: '', description: '', quantity: 1, unitPrice: 0, total: 0 }]);
  };

  const removeItem = (index: number) => {
    if (formItems.length <= 1) return;
    setFormItems(prev => prev.filter((_, i) => i !== index));
  };

  /* ── Modal handlers ── */

  const openAddDialog = () => {
    setFormLeadId('');
    setFormKarAmuzId('');
    setFormItems([{ title: '', description: '', quantity: 1, unitPrice: 0, total: 0 }]);
    setFormDiscountPct(0);
    setFormDueDate('');
    setFormIssuedAt('');
    setFormNotes('');
    setLeadSearch('');
    setKarAmuzSearch('');
    setLeadOptions([]);
    setKarAmuzOptions([]);
    setAddDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (formItems.length === 0 || formItems.every(i => !i.title.trim())) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leadId: formLeadId || null,
          karAmuzId: formKarAmuzId || null,
          items: formItems.map(i => ({ ...i, total: i.unitPrice * i.quantity })),
          discountPct: formDiscountPct,
          dueDate: formDueDate || null,
          issuedAt: formIssuedAt || null,
          notes: formNotes || null,
        }),
      });

      if (res.ok) {
        setAddDialogOpen(false);
        fetchInvoices();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const openDetail = (invoice: Invoice) => {
    setDetailInvoice(invoice);
    setDetailDialogOpen(true);
  };

  const handleStatusChange = async (invoiceId: string, newStatus: string) => {
    setStatusSubmitting(true);
    try {
      const res = await fetch('/api/crm/invoices', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invoiceId, status: newStatus }),
      });

      if (res.ok) {
        const data = await res.json();
        setDetailInvoice(data['داده'] as Invoice);
        fetchInvoices();
      }
    } catch { /* silent */ } finally { setStatusSubmitting(false); }
  };

  const openPaymentDialog = (invoiceId: string) => {
    setPaymentInvoiceId(invoiceId);
    setPaymentAmount('');
    setPaymentDialogOpen(true);
  };

  const handlePaymentSubmit = async () => {
    if (!paymentAmount) return;
    setPaymentSubmitting(true);
    try {
      const amountInRial = parseInt(paymentAmount) * 10; // convert toman to rial
      const res = await fetch('/api/crm/invoices', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoiceId: paymentInvoiceId,
          paidAmount: amountInRial,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setDetailInvoice(data['داده'] as Invoice);
        setPaymentDialogOpen(false);
        fetchInvoices();
      }
    } catch { /* silent */ } finally { setPaymentSubmitting(false); }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Receipt className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">فاکتورها</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {toPersianNumber(stats.total)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت و صدور فاکتور</p>
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              exportToCSV(
                invoices.map((inv) => ({
                  invoiceNumber: inv.invoiceNumber,
                  relatedName: getRelatedName(inv),
                  total: Math.round(inv.totalAmount / 10).toLocaleString('en-US') + ' تومان',
                  status: STATUS_META[inv.status]?.label || inv.status,
                  createdAt: new Intl.DateTimeFormat('fa-IR').format(new Date(inv.createdAt)),
                })),
                'invoices-export.csv',
                [
                  { key: 'invoiceNumber', header: 'شماره فاکتور' },
                  { key: 'relatedName', header: 'نام شخص' },
                  { key: 'total', header: 'مبلغ نهایی' },
                  { key: 'status', header: 'وضعیت' },
                  { key: 'createdAt', header: 'تاریخ ایجاد' },
                ]
              );
            }}
            className="gap-2"
            disabled={invoices.length === 0}
          >
            <Download className="w-4 h-4" />
            خروجی CSV
          </Button>
          <Button
            onClick={openAddDialog}
            className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
          >
            <Plus className="w-4 h-4" />
            فاکتور جدید
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">پیش‌نویس</p>
                <p className="text-2xl font-bold mt-1 text-gray-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.DRAFT)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-gray-50 border border-gray-200">
                <Receipt className="w-5 h-5 text-gray-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">ارسال شده</p>
                <p className="text-2xl font-bold mt-1 text-blue-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.SENT)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <Send className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">پرداخت شده</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.PAID)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">سررسید گذشته</p>
                <p className="text-2xl font-bold mt-1 text-red-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.OVERDUE)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200">
                <AlertOctagon className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="جستجوی شماره یا یادداشت..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10 bg-white"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full sm:w-44 bg-white">
            <SelectValue placeholder="وضعیت" />
          </SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchInvoices}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : invoices.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Receipt className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">فاکتوری یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با ایجاد فاکتور جدید شروع کنید
            </p>
            <Button
              onClick={openAddDialog}
              className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <Plus className="w-4 h-4" />
              فاکتور جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">شماره</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">شخص مرتبط</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">جمع کل</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">مبلغ نهایی</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">پرداخت شده</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">مانده</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">وضعیت</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">سررسید</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((invoice) => {
                  const statusMeta = STATUS_META[invoice.status] || STATUS_META.DRAFT;
                  const remaining = invoice.totalAmount - invoice.paidAmount;
                  const isOverdue = invoice.dueDate && new Date(invoice.dueDate) < new Date() &&
                    invoice.status !== 'PAID' && invoice.status !== 'CANCELLED' && invoice.status !== 'REFUNDED';
                  return (
                    <TableRow key={invoice.id} className={`hover:bg-gray-50/50 ${isOverdue ? 'bg-red-50/30' : ''}`}>
                      <TableCell className="font-mono text-sm">
                        {invoice.invoiceNumber}
                      </TableCell>
                      <TableCell className="text-sm">
                        {getRelatedName(invoice)}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatToman(invoice.subtotal)}
                      </TableCell>
                      <TableCell className="text-sm font-bold">
                        {formatToman(invoice.totalAmount)}
                      </TableCell>
                      <TableCell className="text-sm text-green-700">
                        {invoice.paidAmount > 0 ? formatToman(invoice.paidAmount) : '-'}
                      </TableCell>
                      <TableCell className="text-sm">
                        {remaining > 0 ? (
                          <span className="text-red-600 font-medium">{formatToman(remaining)}</span>
                        ) : '-'}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="secondary"
                          className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}
                        >
                          {statusMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {invoice.dueDate ? formatPersianDate(invoice.dueDate) : '-'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                            onClick={() => openDetail(invoice)}
                            title="مشاهده جزئیات"
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-teal-600 hover:text-teal-800 hover:bg-teal-50"
                            onClick={() => window.open(`/api/crm/invoices/${invoice.id}/pdf`, '_blank')}
                            title="دانلود PDF"
                          >
                            <FileDown className="w-4 h-4" />
                          </Button>
                          {invoice.status !== 'PAID' && invoice.status !== 'CANCELLED' && invoice.status !== 'REFUNDED' && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-green-600 hover:text-green-800 hover:bg-green-50"
                              onClick={() => openPaymentDialog(invoice.id)}
                              title="ثبت پرداخت"
                            >
                              <CreditCard className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Add Invoice Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Receipt className="w-5 h-5 text-teal-600" />
              فاکتور جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Lead search */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">لید مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder="جستجوی لید..."
                  value={leadSearch}
                  onChange={(e) => {
                    setLeadSearch(e.target.value);
                    fetchLeads(e.target.value);
                  }}
                />
                {leadsLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {leadOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {leadOptions.map((lead) => (
                    <button
                      key={lead.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-teal-50 transition-colors ${
                        formLeadId === lead.id ? 'bg-teal-50 text-teal-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormLeadId(lead.id);
                        setLeadSearch(lead.name);
                        setLeadOptions([]);
                      }}
                    >
                      {lead.name}
                    </button>
                  ))}
                </div>
              )}
              {formLeadId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                    {leadSearch}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => { setFormLeadId(''); setLeadSearch(''); }}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* KarAmuz search */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">کارآموز مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder="جستجوی کارآموز..."
                  value={karAmuzSearch}
                  onChange={(e) => {
                    setKarAmuzSearch(e.target.value);
                    fetchKarAmuz(e.target.value);
                  }}
                />
                {karAmuzLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {karAmuzOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {karAmuzOptions.map((ka) => (
                    <button
                      key={ka.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-purple-50 transition-colors ${
                        formKarAmuzId === ka.id ? 'bg-purple-50 text-purple-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormKarAmuzId(ka.id);
                        setKarAmuzSearch(`${ka.firstName} ${ka.lastName}`);
                        setKarAmuzOptions([]);
                      }}
                    >
                      {ka.firstName} {ka.lastName}
                    </button>
                  ))}
                </div>
              )}
              {formKarAmuzId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-purple-50 text-purple-700 text-xs">
                    {karAmuzSearch}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => { setFormKarAmuzId(''); setKarAmuzSearch(''); }}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* Items editor */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-bold">آیتم‌های فاکتور</Label>
                <Button variant="outline" size="sm" onClick={addItem} className="gap-1 text-xs">
                  <Plus className="w-3 h-3" />
                  افزودن آیتم
                </Button>
              </div>

              {formItems.map((item, idx) => (
                <div key={idx} className="border rounded-lg p-3 space-y-2 bg-gray-50/50">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-500">آیتم {toPersianNumber(idx + 1)}</span>
                    {formItems.length > 1 && (
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500 hover:bg-red-50" onClick={() => removeItem(idx)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      placeholder="عنوان آیتم"
                      value={item.title}
                      onChange={(e) => updateItem(idx, 'title', e.target.value)}
                    />
                    <Input
                      placeholder="توضیحات"
                      value={item.description}
                      onChange={(e) => updateItem(idx, 'description', e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-xs text-gray-500">تعداد</Label>
                      <Input
                        type="number"
                        min={1}
                        value={item.quantity}
                        onChange={(e) => updateItem(idx, 'quantity', parseInt(e.target.value) || 1)}
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">قیمت واحد (ریال)</Label>
                      <Input
                        type="number"
                        min={0}
                        value={item.unitPrice || ''}
                        onChange={(e) => updateItem(idx, 'unitPrice', parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">جمع</Label>
                      <Input
                        readOnly
                        value={formatToman(item.unitPrice * item.quantity)}
                        className="bg-gray-100 text-gray-600"
                      />
                    </div>
                  </div>
                </div>
              ))}

              {/* Calculations */}
              <div className="border-t pt-3 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">جمع کل:</span>
                  <span className="font-medium">{formatToman(formSubtotal)}</span>
                </div>
                <div className="flex items-center justify-between gap-3 text-sm">
                  <span className="text-gray-600">درصد تخفیف:</span>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      min={0}
                      max={100}
                      value={formDiscountPct || ''}
                      onChange={(e) => setFormDiscountPct(parseFloat(e.target.value) || 0)}
                      className="w-20 text-center"
                    />
                    <span className="text-gray-500">٪</span>
                  </div>
                </div>
                {formDiscountAmount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">مبلغ تخفیف:</span>
                    <span className="text-red-600 font-medium">-{formatToman(formDiscountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">مالیات (۹٪):</span>
                  <span className="font-medium">{formatToman(formTaxAmount)}</span>
                </div>
                <div className="flex justify-between text-base font-bold border-t pt-2">
                  <span>مبلغ نهایی:</span>
                  <span className="text-teal-700">{formatToman(formTotalAmount)}</span>
                </div>
              </div>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">تاریخ صدور</Label>
                <Input
                  type="date"
                  value={formIssuedAt}
                  onChange={(e) => setFormIssuedAt(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">سررسید</Label>
                <Input
                  type="date"
                  value={formDueDate}
                  onChange={(e) => setFormDueDate(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">يادداشت</Label>
              <Textarea
                placeholder="يادداشت..."
                value={formNotes}
                onChange={(e) => setFormNotes(e.target.value)}
                rows={2}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ثبت فاکتور
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
          {detailInvoice && (() => {
            const statusMeta = STATUS_META[detailInvoice.status] || STATUS_META.DRAFT;
            const remaining = detailInvoice.totalAmount - detailInvoice.paidAmount;
            return (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2 text-right">
                    <Receipt className="w-5 h-5 text-teal-600" />
                    جزئیات فاکتور {detailInvoice.invoiceNumber}
                  </DialogTitle>
                </DialogHeader>

                <div className="space-y-4 py-2">
                  {/* Status + related person */}
                  <div className="flex flex-wrap items-center gap-3">
                    <Badge className={`${statusMeta.bgColor} ${statusMeta.color} text-sm border-0`}>
                      {statusMeta.label}
                    </Badge>
                    <span className="text-sm text-gray-600">
                      {detailInvoice.lead ? `لید: ${detailInvoice.lead.name}` :
                       detailInvoice.karAmuz ? `کارآموز: ${detailInvoice.karAmuz.firstName} ${detailInvoice.karAmuz.lastName}` : ''}
                    </span>
                  </div>

                  {/* Items table */}
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-gray-50">
                          <TableHead className="text-xs">عنوان</TableHead>
                          <TableHead className="text-xs text-center">تعداد</TableHead>
                          <TableHead className="text-xs text-center">قیمت واحد</TableHead>
                          <TableHead className="text-xs text-center">جمع</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(detailInvoice.items as InvoiceItem[]).map((item, idx) => (
                          <TableRow key={idx}>
                            <TableCell>
                              <div className="font-medium text-sm">{item.title}</div>
                              {item.description && <div className="text-xs text-gray-500">{item.description}</div>}
                            </TableCell>
                            <TableCell className="text-center text-sm">{toPersianNumber(item.quantity)}</TableCell>
                            <TableCell className="text-center text-sm">{formatToman(item.unitPrice)}</TableCell>
                            <TableCell className="text-center text-sm font-bold">{formatToman(item.total)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Totals */}
                  <div className="bg-gray-50 rounded-lg p-3 space-y-1.5">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">جمع کل:</span>
                      <span>{formatToman(detailInvoice.subtotal)}</span>
                    </div>
                    {detailInvoice.discountPct > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">تخفیف ({toPersianNumber(detailInvoice.discountPct)}٪):</span>
                        <span className="text-red-600">-{formatToman(detailInvoice.discountAmount)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">مالیات (۹٪):</span>
                      <span>{formatToman(detailInvoice.taxAmount)}</span>
                    </div>
                    <div className="flex justify-between text-base font-bold border-t pt-1.5">
                      <span>مبلغ نهایی:</span>
                      <span className="text-teal-700">{formatToman(detailInvoice.totalAmount)}</span>
                    </div>
                    <div className="flex justify-between text-sm border-t pt-1.5">
                      <span className="text-green-700">پرداخت شده:</span>
                      <span className="text-green-700 font-medium">{formatToman(detailInvoice.paidAmount)}</span>
                    </div>
                    {remaining > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="text-red-700">مانده:</span>
                        <span className="text-red-700 font-bold">{formatToman(remaining)}</span>
                      </div>
                    )}
                  </div>

                  {/* Dates */}
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                    {detailInvoice.issuedAt && (
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-4 h-4" />
                        <span>صدور: {formatPersianDate(detailInvoice.issuedAt)}</span>
                      </div>
                    )}
                    {detailInvoice.dueDate && (
                      <div className="flex items-center gap-1.5">
                        <AlertOctagon className="w-4 h-4" />
                        <span>سررسید: {formatPersianDate(detailInvoice.dueDate)}</span>
                      </div>
                    )}
                  </div>

                  {/* Notes */}
                  {detailInvoice.notes && (
                    <div>
                      <p className="text-xs font-bold text-gray-500 mb-1">يادداشت:</p>
                      <p className="text-sm text-gray-700 bg-gray-50 rounded-lg p-2">{detailInvoice.notes}</p>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="border-t pt-3 flex flex-wrap gap-2">
                    {detailInvoice.status === 'DRAFT' && (
                      <Button
                        size="sm"
                        onClick={() => handleStatusChange(detailInvoice.id, 'SENT')}
                        disabled={statusSubmitting}
                        className="bg-blue-600 hover:bg-blue-700 text-white gap-1"
                      >
                        <Send className="w-3 h-3" />
                        ارسال
                      </Button>
                    )}
                    {detailInvoice.status !== 'PAID' && detailInvoice.status !== 'CANCELLED' && detailInvoice.status !== 'REFUNDED' && (
                      <Button
                        size="sm"
                        onClick={() => {
                          setDetailDialogOpen(false);
                          openPaymentDialog(detailInvoice.id);
                        }}
                        disabled={statusSubmitting}
                        className="bg-green-600 hover:bg-green-700 text-white gap-1"
                      >
                        <CreditCard className="w-3 h-3" />
                        ثبت پرداخت
                      </Button>
                    )}
                  </div>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <CreditCard className="w-5 h-5 text-green-600" />
              ثبت پرداخت
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">مبلغ پرداخت (تومان)</Label>
              <Input
                type="number"
                min={0}
                placeholder="مبلغ به تومان..."
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setPaymentDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handlePaymentSubmit}
              disabled={paymentSubmitting || !paymentAmount}
              className="bg-green-600 hover:bg-green-700 text-white gap-2"
            >
              {paymentSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <CreditCard className="w-4 h-4" />}
              ثبت
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
