'use client';

import { useEffect, useState } from 'react';
import {
  BarChart3, TrendingUp, Users, Zap, Brain, Activity,
  Target, Layers, RefreshCw, ArrowDown, ArrowUp, AlertTriangle,
  CheckCircle2, Clock, Eye, MousePointer, Monitor,
  Cpu, Shield, GitBranch, Sparkles, Bot
} from 'lucide-react';
import Link from 'next/link';

/* ═══════════════════════════════════════════════════════
   داشبورد مدیریتی — فاز ۳: نمای جامع سایبرنتیک
   شامل: KPI های لید، رفتار کاربران، عملکرد AI، وضعیت سیستم
   ═══════════════════════════════════════════════════════ */

interface SystemKPIS {
  totalLeads: number;
  activeSessions: number;
  conversionRate: number;
  avgLeadScore: number;
  behaviorPatterns: number;
  selfRegLogs: number;
  activeDrips: number;
  totalCampaigns: number;
}

interface WebVital {
  name: string;
  value: number;
  rating: string;
  target: string;
}

interface PhaseProgress {
  phase1: number;
  phase2: number;
  phase3: number;
  phase4: number;
}

interface SystemAnalysisData {
  kpis: SystemKPIS;
  webVitals: WebVital[];
  roadmapProgress: PhaseProgress;
  cognitiveLoad: {
    overallScore: number;
    rating: string;
  };
  architectureHealth: {
    overallHealth: number;
    rating: string;
  };
  agilityScore: {
    overallAgility: number;
    rating: string;
  };
}

const phaseLabels: Record<string, { title: string; color: string }> = {
  phase1: { title: 'مهندسی مجدد صفحه اصلی', color: 'from-blue-500 to-cyan-500' },
  phase2: { title: 'سیستم هدایت تعاملی', color: 'from-violet-500 to-purple-500' },
  phase3: { title: 'داشبورد مدیریتی', color: 'from-emerald-500 to-teal-500' },
  phase4: { title: 'سیستم سایبرنتیک آموزشی', color: 'from-amber-500 to-orange-500' },
};

const vitalLabels: Record<string, string> = {
  LCP: 'بزرگ‌ترین رنگ‌آمیزی محتوا',
  INP: 'تاخیر تعامل تا رنگ‌آمیزی',
  CLS: 'جابه‌جایی تجمعی طرح‌بندی',
  TTFB: 'زمان تا اولین بایت',
  FCP: 'اولین رنگ‌آمیزی محتوا',
  TBT: 'مجموع زمان مسدودسازی',
};

function formatRating(rating: string) {
  const map: Record<string, { label: string; color: string }> = {
    good: { label: 'خوب', color: 'text-green-600 bg-green-50' },
    'needs-improvement': { label: 'نیاز به بهبود', color: 'text-amber-600 bg-amber-50' },
    poor: { label: 'ضعیف', color: 'text-red-600 bg-red-50' },
    optimal: { label: 'بهینه', color: 'text-green-600 bg-green-50' },
    acceptable: { label: 'قابل‌قبول', color: 'text-blue-600 bg-blue-50' },
    heavy: { label: 'سنگین', color: 'text-amber-600 bg-amber-50' },
    critical: { label: 'بحرانی', color: 'text-red-600 bg-red-50' },
    excellent: { label: 'عالی', color: 'text-green-600 bg-green-50' },
    fair: { label: 'متوسط', color: 'text-amber-600 bg-amber-50' },
    agile: { label: 'چابک', color: 'text-green-600 bg-green-50' },
    moderate: { label: 'متوسط', color: 'text-blue-600 bg-blue-50' },
    bloated: { label: 'سنگین', color: 'text-red-600 bg-red-50' },
  };
  return map[rating] || { label: rating, color: 'text-gray-600 bg-gray-50' };
}

function toPersianNum(n: number | undefined): string {
  if (n === undefined || n === null) return '—';
  return n.toLocaleString('fa-IR');
}

export default function ManagerialDashboard() {
  const [data, setData] = useState<SystemAnalysisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAnalysis = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/admin/system-analysis');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطای ناشناخته');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalysis();
  }, []);

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-l from-emerald-700 to-teal-800 rounded-2xl p-6 text-white flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2">
            <Activity className="h-6 w-6" /> داشبورد مدیریتی — سیستم سایبرنتیک
          </h1>
          <p className="text-emerald-100 text-sm mt-1">
            تحلیل لحظه‌ای عملکرد پلتفرم، رفتار کاربران و وضعیت سیستم
          </p>
        </div>
        <button
          onClick={fetchAnalysis}
          disabled={loading}
          className="bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-xl px-4 py-2 text-sm flex items-center gap-2 transition-colors"
        >
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          بروزرسانی
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3 text-red-700">
          <AlertTriangle className="h-5 w-5 flex-shrink-0" />
          <span className="text-sm">خطا در بارگذاری: {error}</span>
        </div>
      )}

      {loading && !data && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="bg-white rounded-xl p-5 border border-gray-100">
              <div className="h-4 w-20 bg-gray-200 rounded animate-pulse mb-3" />
              <div className="h-8 w-16 bg-gray-200 rounded animate-pulse" />
            </div>
          ))}
        </div>
      )}

      {data && (
        <>
          {/* ─── KPI Cards ─── */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: 'کل سرن‌ها', value: toPersianNum(data.kpis?.totalLeads), icon: Users, color: 'bg-teal-100 text-teal-600', change: null },
              { label: 'نرخ تبدیل', value: `${toPersianNum(data.kpis?.conversionRate)}%`, icon: Target, color: 'bg-blue-100 text-blue-600', change: null },
              { label: 'الگوهای رفتاری', value: toPersianNum(data.kpis?.behaviorPatterns), icon: Brain, color: 'bg-purple-100 text-purple-600', change: null },
              { label: 'میانگین امتیاز لید', value: toPersianNum(data.kpis?.avgLeadScore), icon: Sparkles, color: 'bg-amber-100 text-amber-600', change: null },
              { label: 'جلسات فعال AI', value: toPersianNum(data.kpis?.activeSessions), icon: Bot, color: 'bg-indigo-100 text-indigo-600', change: null },
              { label: 'کمپین‌های فعال', value: toPersianNum(data.kpis?.totalCampaigns), icon: Zap, color: 'bg-orange-100 text-orange-600', change: null },
              { label: 'لاگ‌های خودتنظیم‌گر', value: toPersianNum(data.kpis?.selfRegLogs), icon: GitBranch, color: 'bg-pink-100 text-pink-600', change: null },
              { label: 'دریپ‌های فعال', value: toPersianNum(data.kpis?.activeDrips), icon: Activity, color: 'bg-green-100 text-green-600', change: null },
            ].map((kpi, idx) => (
              <div key={idx} className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${kpi.color}`}>
                    <kpi.icon className="h-4 w-4" />
                  </div>
                  <span className="text-xs text-gray-500">{kpi.label}</span>
                </div>
                <p className="text-xl font-bold text-gray-800">{kpi.value}</p>
              </div>
            ))}
          </div>

          {/* ─── Phase Progress ─── */}
          <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
            <h2 className="text-base font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Layers className="h-5 w-5 text-teal-600" /> پیشرفت نقشه راه ۴ فازی
            </h2>
            <div className="space-y-3">
              {(['phase1', 'phase2', 'phase3', 'phase4'] as const).map((phase) => {
                const info = phaseLabels[phase];
                const progress = data.roadmapProgress?.[phase] || 0;
                const isComplete = progress >= 100;
                return (
                  <div key={phase} className="space-y-1">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-medium text-gray-700">{info.title}</span>
                      <span className={`font-bold ${isComplete ? 'text-green-600' : 'text-amber-600'}`}>
                        {toPersianNum(progress)}%
                        {isComplete && <CheckCircle2 className="inline h-4 w-4 mr-1" />}
                      </span>
                    </div>
                    <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-l ${info.color} rounded-full transition-all duration-700 ease-out`}
                        style={{ width: `${Math.min(progress, 100)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ─── Core Web Vitals ─── */}
          <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
            <h2 className="text-base font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Monitor className="h-5 w-5 text-blue-600" /> Core Web Vitals — عملکرد صفحه
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {data.webVitals?.map((vital, idx) => {
                const rating = formatRating(vital.rating);
                return (
                  <div key={idx} className="bg-gray-50 rounded-lg p-3 text-center">
                    <p className="text-xs font-bold text-gray-600 mb-1">{vital.name}</p>
                    <p className="text-lg font-bold text-gray-800">{vital.value}</p>
                    <span className={`inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full font-medium ${rating.color}`}>
                      {rating.label}
                    </span>
                    <p className="text-[10px] text-gray-400 mt-1">{vitalLabels[vital.name] || vital.name}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ─── System Health Row ─── */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Cognitive Load */}
            <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
              <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                <Brain className="h-4 w-4 text-purple-500" /> بار شناختی
              </h3>
              <div className="text-center">
                <p className="text-3xl font-bold text-gray-800">{toPersianNum(data.cognitiveLoad?.overallScore)}</p>
                <span className={`inline-block mt-2 text-xs px-3 py-1 rounded-full font-medium ${formatRating(data.cognitiveLoad?.rating).color}`}>
                  {formatRating(data.cognitiveLoad?.rating).label}
                </span>
              </div>
            </div>

            {/* Architecture Health */}
            <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
              <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                <Cpu className="h-4 w-4 text-teal-500" /> سلامت معماری
              </h3>
              <div className="text-center">
                <p className="text-3xl font-bold text-gray-800">{toPersianNum(data.architectureHealth?.overallHealth)}</p>
                <span className={`inline-block mt-2 text-xs px-3 py-1 rounded-full font-medium ${formatRating(data.architectureHealth?.rating).color}`}>
                  {formatRating(data.architectureHealth?.rating).label}
                </span>
              </div>
            </div>

            {/* Agility Score */}
            <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
              <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                <Zap className="h-4 w-4 text-amber-500" /> امتیاز چابکی
              </h3>
              <div className="text-center">
                <p className="text-3xl font-bold text-gray-800">{toPersianNum(data.agilityScore?.overallAgility)}</p>
                <span className={`inline-block mt-2 text-xs px-3 py-1 rounded-full font-medium ${formatRating(data.agilityScore?.rating).color}`}>
                  {formatRating(data.agilityScore?.rating).label}
                </span>
              </div>
            </div>
          </div>

          {/* ─── Quick Navigation ─── */}
          <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
            <h2 className="text-base font-bold text-gray-800 mb-4 flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-gray-600" /> دسترسی سریع به بخش‌های مدیریتی
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {[
                { href: '/admin/crm', label: 'CRM', icon: Users },
                { href: '/admin/analytics', label: 'تحلیل‌ها', icon: BarChart3 },
                { href: '/admin/cybernetic', label: 'سایبرنتیک', icon: Brain },
                { href: '/admin/predictions', label: 'پیش‌بینی‌ها', icon: TrendingUp },
                { href: '/admin/campaigns', label: 'کمپین‌ها', icon: Zap },
                { href: '/admin/ai-agents', label: 'عوامل AI', icon: Bot },
                { href: '/admin/courses', label: 'دوره‌ها', icon: Layers },
                { href: '/admin/knowledge-base', label: 'پایگاه دانش', icon: Shield },
              ].map((item, idx) => (
                <Link
                  key={idx}
                  href={item.href}
                  className="flex items-center gap-2 p-3 bg-gray-50 hover:bg-teal-50 hover:border-teal-200 border border-gray-100 rounded-lg transition-colors"
                >
                  <item.icon className="h-4 w-4 text-teal-600" />
                  <span className="text-sm text-gray-700">{item.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}