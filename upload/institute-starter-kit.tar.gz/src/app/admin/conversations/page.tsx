'use client';

import { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Headphones,
  Plus,
  Search,
  Loader2,
  AlertTriangle,
  X,
  Eye,
  Sparkles,
  Phone,
  MessageSquare,
  Mail,
  MessageCircle,
  CheckCircle2,
  Clock,
  Send,
  FileText,
  SmilePlus,
  Frown,
  Meh,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface ConversationMessage {
  id: string;
  content: string;
  speaker: string;
  speakerName: string | null;
  aiSuggestion: string | null;
  aiConfidence: number | null;
  timestamp: string;
  metadata?: Record<string, unknown>;
}

interface Conversation {
  id: string;
  leadId: string | null;
  karAmuzId: string | null;
  channel: string;
  subject: string | null;
  summary: string | null;
  sentiment: string | null;
  keyTopics: string | null;
  actionItems: string | null;
  durationSec: number | null;
  startedAt: string;
  endedAt: string | null;
  status: string;
  createdAt: string;
  updatedAt: string;
  lead?: { id: string; name: string; phone: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string; phone: string } | null;
  _count?: { messages: number };
  messages?: ConversationMessage[];
}

interface LeadOption {
  id: string;
  name: string;
}

interface KarAmuzOption {
  id: string;
  firstName: string;
  lastName: string;
}

/* ─────────── Constants ─────────── */

const CHANNEL_META: Record<string, { label: string; icon: typeof Phone; color: string; bgColor: string }> = {
  PHONE: { label: 'تلفن', icon: Phone, color: 'text-blue-700', bgColor: 'bg-blue-100' },
  CHAT: { label: 'چت', icon: MessageSquare, color: 'text-green-700', bgColor: 'bg-green-100' },
  EMAIL: { label: 'ایمیل', icon: Mail, color: 'text-orange-700', bgColor: 'bg-orange-100' },
  WHATSAPP: { label: 'واتساپ', icon: MessageCircle, color: 'text-emerald-700', bgColor: 'bg-emerald-100' },
};

const SENTIMENT_META: Record<string, { label: string; color: string; bgColor: string; icon: typeof SmilePlus }> = {
  POSITIVE: { label: 'مثبت', color: 'text-green-700', bgColor: 'bg-green-100', icon: SmilePlus },
  NEUTRAL: { label: 'خنثی', color: 'text-gray-700', bgColor: 'bg-gray-100', icon: Meh },
  NEGATIVE: { label: 'منفی', color: 'text-red-700', bgColor: 'bg-red-100', icon: Frown },
  MIXED: { label: 'ترکیبی', color: 'text-yellow-700', bgColor: 'bg-yellow-100', icon: Meh },
};

const STATUS_META: Record<string, { label: string; color: string; bgColor: string }> = {
  ACTIVE: { label: 'فعال', color: 'text-green-700', bgColor: 'bg-green-100' },
  COMPLETED: { label: 'تکمیل شده', color: 'text-blue-700', bgColor: 'bg-blue-100' },
  ARCHIVED: { label: 'بایگانی', color: 'text-gray-700', bgColor: 'bg-gray-100' },
};

const CHANNEL_OPTIONS = [
  { value: 'all', label: 'همه کانال‌ها' },
  { value: 'PHONE', label: 'تلفن' },
  { value: 'CHAT', label: 'چت' },
  { value: 'EMAIL', label: 'ایمیل' },
  { value: 'WHATSAPP', label: 'واتساپ' },
];

const SENTIMENT_OPTIONS = [
  { value: 'all', label: 'همه احساسات' },
  { value: 'POSITIVE', label: 'مثبت' },
  { value: 'NEUTRAL', label: 'خنثی' },
  { value: 'NEGATIVE', label: 'منفی' },
  { value: 'MIXED', label: 'ترکیبی' },
];

/* ─────────── Helpers ─────────── */

function formatPersianDate(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(dateStr));
}

function formatDuration(sec: number | null): string {
  if (!sec) return '-';
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m === 0) return toPersianNumber(s) + ' ثانیه';
  return toPersianNumber(m) + ':' + toPersianNumber(s.toString().padStart(2, '0'));
}

function getRelatedName(conv: Conversation): string {
  if (conv.lead) return conv.lead.name;
  if (conv.karAmuz) return `${conv.karAmuz.firstName} ${conv.karAmuz.lastName}`;
  return '-';
}

function formatPersianTime(dateStr: string) {
  return new Intl.DateTimeFormat('fa-IR', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

/* ─────────── Main Component ─────────── */

export default function ConversationsPage() {
  /* ── State ── */
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [filterChannel, setFilterChannel] = useState<string>('all');
  const [filterSentiment, setFilterSentiment] = useState<string>('all');

  // Add dialog
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [formSubject, setFormSubject] = useState('');
  const [formChannel, setFormChannel] = useState('PHONE');
  const [formLeadId, setFormLeadId] = useState('');
  const [formKarAmuzId, setFormKarAmuzId] = useState('');
  const [formStartedAt, setFormStartedAt] = useState('');

  // Lead/KarAmuz search
  const [leadOptions, setLeadOptions] = useState<LeadOption[]>([]);
  const [karAmuzOptions, setKarAmuzOptions] = useState<KarAmuzOption[]>([]);
  const [leadSearch, setLeadSearch] = useState('');
  const [karAmuzSearch, setKarAmuzSearch] = useState('');
  const [leadsLoading, setLeadsLoading] = useState(false);
  const [karAmuzLoading, setKarAmuzLoading] = useState(false);

  // Detail dialog
  const [detailConv, setDetailConv] = useState<Conversation | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [newMessage, setNewMessage] = useState('');
  const [newMessageSpeaker, setNewMessageSpeaker] = useState('AGENT');
  const [messageSubmitting, setMessageSubmitting] = useState(false);

  // AI actions
  const [aiSuggesting, setAiSuggesting] = useState(false);
  const [aiSummarizing, setAiSummarizing] = useState(false);
  const [aiSuggestionText, setAiSuggestionText] = useState('');
  const [statusSubmitting, setStatusSubmitting] = useState(false);

  /* ── Data fetching ── */

  const fetchConversations = useCallback(async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      params.set('limit', '100');
      if (search) params.set('search', search);
      if (filterChannel && filterChannel !== 'all') params.set('channel', filterChannel);
      if (filterSentiment && filterSentiment !== 'all') params.set('sentiment', filterSentiment);

      const res = await fetch(`/api/crm/conversations?${params.toString()}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data['خطا'] || 'خطا در دریافت مکالمات');
        return;
      }

      setConversations(data['داده‌ها'] || []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [search, filterChannel, filterSentiment]);

  useEffect(() => {
    fetchConversations();
  }, [fetchConversations]);

  const fetchLeads = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setLeadOptions([]); return; }
    setLeadsLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/leads?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setLeadOptions((data['داده‌ها'] || []).map((l: { id: string; name: string }) => ({ id: l.id, name: l.name })));
      }
    } catch { /* silent */ } finally { setLeadsLoading(false); }
  }, []);

  const fetchKarAmuz = useCallback(async (q: string) => {
    if (!q || q.length < 2) { setKarAmuzOptions([]); return; }
    setKarAmuzLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('search', q);
      params.set('limit', '10');
      const res = await fetch(`/api/crm/karamuz?${params.toString()}`);
      const data = await res.json();
      if (res.ok) {
        setKarAmuzOptions((data['داده‌ها'] || []).map((k: { id: string; firstName: string; lastName: string }) => ({ id: k.id, firstName: k.firstName, lastName: k.lastName })));
      }
    } catch { /* silent */ } finally { setKarAmuzLoading(false); }
  }, []);

  /* ── Computed ── */

  const stats = useMemo(() => ({
    total: conversations.length,
    ACTIVE: conversations.filter(c => c.status === 'ACTIVE').length,
    COMPLETED: conversations.filter(c => c.status === 'COMPLETED').length,
    POSITIVE: conversations.filter(c => c.sentiment === 'POSITIVE').length,
    NEGATIVE: conversations.filter(c => c.sentiment === 'NEGATIVE').length,
  }), [conversations]);

  /* ── Handlers ── */

  const openAddDialog = () => {
    setFormSubject('');
    setFormChannel('PHONE');
    setFormLeadId('');
    setFormKarAmuzId('');
    setFormStartedAt('');
    setLeadSearch('');
    setKarAmuzSearch('');
    setLeadOptions([]);
    setKarAmuzOptions([]);
    setAddDialogOpen(true);
  };

  const handleSubmit = async () => {
    if (!formSubject.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/crm/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: formSubject,
          channel: formChannel,
          leadId: formLeadId || null,
          karAmuzId: formKarAmuzId || null,
          startedAt: formStartedAt || new Date().toISOString(),
        }),
      });
      if (res.ok) {
        setAddDialogOpen(false);
        fetchConversations();
      }
    } catch { /* silent */ } finally { setSubmitting(false); }
  };

  const openDetail = async (conv: Conversation) => {
    setDetailConv(conv);
    setDetailDialogOpen(true);
    setNewMessage('');
    setAiSuggestionText('');
    setDetailLoading(true);
    try {
      const res = await fetch(`/api/crm/conversations/${conv.id}`);
      const data = await res.json();
      if (res.ok) {
        setDetailConv(data['داده'] as Conversation);
      }
    } catch { /* silent */ } finally { setDetailLoading(false); }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !detailConv) return;
    setMessageSubmitting(true);
    try {
      const res = await fetch(`/api/crm/conversations/${detailConv.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: newMessage,
          speaker: newMessageSpeaker,
          speakerName: newMessageSpeaker === 'AGENT' ? 'مشاور' : newMessageSpeaker === 'AI_ASSISTANT' ? 'دستیار AI' : 'مشتری',
        }),
      });
      if (res.ok) {
        setNewMessage('');
        // Refresh detail
        const detailRes = await fetch(`/api/crm/conversations/${detailConv.id}`);
        const detailData = await detailRes.json();
        if (detailRes.ok) {
          setDetailConv(detailData['داده'] as Conversation);
        }
      }
    } catch { /* silent */ } finally { setMessageSubmitting(false); }
  };

  const handleAiSuggest = async () => {
    if (!detailConv) return;
    setAiSuggesting(true);
    setAiSuggestionText('');
    try {
      const messagesText = (detailConv.messages || [])
        .map(m => `${m.speakerName || m.speaker}: ${m.content}`)
        .join('\n');

      const res = await fetch('/api/crm/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'suggest_response',
          conversationId: detailConv.id,
          messages: messagesText,
          subject: detailConv.subject,
          channel: detailConv.channel,
        }),
      });
      const data = await res.json();
      if (res.ok && data['داده']) {
        setAiSuggestionText(data['داده'].suggestion || data['داده'] || 'پیشنهادی یافت نشد');
      } else {
        setAiSuggestionText('پیشنهادی تولید نشد. لطفاً دوباره تلاش کنید.');
      }
    } catch {
      setAiSuggestionText('خطا در ارتباط با سرویس AI');
    } finally {
      setAiSuggesting(false);
    }
  };

  const handleAiSummarize = async () => {
    if (!detailConv) return;
    setAiSummarizing(true);
    try {
      const messagesText = (detailConv.messages || [])
        .map(m => `${m.speakerName || m.speaker}: ${m.content}`)
        .join('\n');

      const res = await fetch('/api/crm/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'summarize',
          conversationId: detailConv.id,
          messages: messagesText,
          subject: detailConv.subject,
        }),
      });
      const data = await res.json();
      if (res.ok && data['داده']) {
        // Update conversation with summary
        const updateRes = await fetch('/api/crm/conversations', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            conversationId: detailConv.id,
            summary: data['داده'].summary || data['داده'] || '',
            sentiment: data['داده'].sentiment || undefined,
          }),
        });
        if (updateRes.ok) {
          const updatedData = await updateRes.json();
          setDetailConv(prev => prev ? { ...prev, ...updatedData['داده'] } : prev);
        }
      }
    } catch { /* silent */ } finally { setAiSummarizing(false); }
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!detailConv) return;
    setStatusSubmitting(true);
    try {
      const res = await fetch('/api/crm/conversations', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ conversationId: detailConv.id, status: newStatus }),
      });
      if (res.ok) {
        const data = await res.json();
        setDetailConv(prev => prev ? { ...prev, ...data['داده'] } : prev);
        fetchConversations();
      }
    } catch { /* silent */ } finally { setStatusSubmitting(false); }
  };

  /* ──── Render ──── */

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200">
            <Headphones className="w-6 h-6 text-teal-600" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-gray-900">مکالمات و هوش مصنوعی</h1>
              <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                {loading ? <Skeleton className="h-4 w-6" /> : toPersianNumber(stats.total)}
              </Badge>
            </div>
            <p className="text-gray-500 mt-0.5 text-sm">مدیریت مکالمات و تحلیل هوشمند</p>
          </div>
        </div>
        <Button
          onClick={openAddDialog}
          className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
        >
          <Plus className="w-4 h-4" />
          مکالمه جدید
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">فعال</p>
                <p className="text-2xl font-bold mt-1 text-green-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.ACTIVE)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-green-50 border border-green-200">
                <Headphones className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">تکمیل شده</p>
                <p className="text-2xl font-bold mt-1 text-blue-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.COMPLETED)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200">
                <CheckCircle2 className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">احساس مثبت</p>
                <p className="text-2xl font-bold mt-1 text-emerald-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.POSITIVE)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <SmilePlus className="w-5 h-5 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-500">احساس منفی</p>
                <p className="text-2xl font-bold mt-1 text-red-700">
                  {loading ? <Skeleton className="h-8 w-12" /> : toPersianNumber(stats.NEGATIVE)}
                </p>
              </div>
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200">
                <Frown className="w-5 h-5 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="جستجوی موضوع یا خلاصه..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10 bg-white"
          />
        </div>
        <Select value={filterChannel} onValueChange={setFilterChannel}>
          <SelectTrigger className="w-full sm:w-40 bg-white">
            <SelectValue placeholder="کانال" />
          </SelectTrigger>
          <SelectContent>
            {CHANNEL_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterSentiment} onValueChange={setFilterSentiment}>
          <SelectTrigger className="w-full sm:w-40 bg-white">
            <SelectValue placeholder="احساس" />
          </SelectTrigger>
          <SelectContent>
            {SENTIMENT_OPTIONS.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-xl" />
          ))}
        </div>
      ) : error ? (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6 text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2" />
            <p className="text-red-700 font-medium">{error}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchConversations}>
              تلاش مجدد
            </Button>
          </CardContent>
        </Card>
      ) : conversations.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-12 text-center">
            <Headphones className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">مکالمه‌ای یافت نشد</p>
            <p className="text-gray-400 text-sm mt-1">
              با ایجاد مکالمه جدید شروع کنید
            </p>
            <Button
              onClick={openAddDialog}
              className="mt-4 bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <Plus className="w-4 h-4" />
              مکالمه جدید
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-0 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50/80">
                  <TableHead className="text-xs font-bold text-gray-600">موضوع</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">شخص مرتبط</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">کانال</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">احساس</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">مدت</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">وضعیت</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">تاریخ</TableHead>
                  <TableHead className="text-xs font-bold text-gray-600">عملیات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {conversations.map((conv) => {
                  const channelMeta = CHANNEL_META[conv.channel] || CHANNEL_META.PHONE;
                  const sentimentMeta = conv.sentiment ? SENTIMENT_META[conv.sentiment] : null;
                  const statusMeta = STATUS_META[conv.status] || STATUS_META.ACTIVE;
                  const ChannelIcon = channelMeta.icon;
                  return (
                    <TableRow key={conv.id} className="hover:bg-gray-50/50">
                      <TableCell className="text-sm font-medium max-w-[200px] truncate">
                        {conv.subject || '-'}
                      </TableCell>
                      <TableCell className="text-sm">
                        {getRelatedName(conv)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <ChannelIcon className="w-3.5 h-3.5" />
                          <span className="text-xs">{channelMeta.label}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {sentimentMeta ? (
                          <Badge variant="secondary" className={`${sentimentMeta.bgColor} ${sentimentMeta.color} text-xs border-0`}>
                            {sentimentMeta.label}
                          </Badge>
                        ) : (
                          <span className="text-gray-400 text-xs">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">
                        {formatDuration(conv.durationSec)}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`${statusMeta.bgColor} ${statusMeta.color} text-xs border-0`}>
                          {statusMeta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {formatPersianDate(conv.createdAt)}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-500 hover:text-teal-700 hover:bg-teal-50"
                          onClick={() => openDetail(conv)}
                          title="مشاهده جزئیات"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Add Conversation Dialog */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Headphones className="w-5 h-5 text-teal-600" />
              مکالمه جدید
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Subject */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">موضوع مکالمه</Label>
              <Input
                placeholder="موضوع مکالمه..."
                value={formSubject}
                onChange={(e) => setFormSubject(e.target.value)}
              />
            </div>

            {/* Channel */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">کانال</Label>
              <Select value={formChannel} onValueChange={setFormChannel}>
                <SelectTrigger className="bg-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(CHANNEL_META).map(([key, meta]) => (
                    <SelectItem key={key} value={key}>
                      {meta.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Lead search */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">لید مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder="جستجوی لید..."
                  value={leadSearch}
                  onChange={(e) => {
                    setLeadSearch(e.target.value);
                    fetchLeads(e.target.value);
                  }}
                />
                {leadsLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {leadOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {leadOptions.map((lead) => (
                    <button
                      key={lead.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-teal-50 transition-colors ${
                        formLeadId === lead.id ? 'bg-teal-50 text-teal-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormLeadId(lead.id);
                        setLeadSearch(lead.name);
                        setLeadOptions([]);
                      }}
                    >
                      {lead.name}
                    </button>
                  ))}
                </div>
              )}
              {formLeadId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-teal-50 text-teal-700 text-xs">
                    {leadSearch}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => { setFormLeadId(''); setLeadSearch(''); }}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* KarAmuz search */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">کارآموز مرتبط</Label>
              <div className="relative">
                <Input
                  placeholder="جستجوی کارآموز..."
                  value={karAmuzSearch}
                  onChange={(e) => {
                    setKarAmuzSearch(e.target.value);
                    fetchKarAmuz(e.target.value);
                  }}
                />
                {karAmuzLoading && (
                  <Loader2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                )}
              </div>
              {karAmuzOptions.length > 0 && (
                <div className="border rounded-lg max-h-32 overflow-y-auto bg-white shadow-sm">
                  {karAmuzOptions.map((ka) => (
                    <button
                      key={ka.id}
                      className={`w-full text-right px-3 py-2 text-sm hover:bg-purple-50 transition-colors ${
                        formKarAmuzId === ka.id ? 'bg-purple-50 text-purple-700 font-medium' : 'text-gray-700'
                      }`}
                      onClick={() => {
                        setFormKarAmuzId(ka.id);
                        setKarAmuzSearch(`${ka.firstName} ${ka.lastName}`);
                        setKarAmuzOptions([]);
                      }}
                    >
                      {ka.firstName} {ka.lastName}
                    </button>
                  ))}
                </div>
              )}
              {formKarAmuzId && (
                <div className="flex items-center gap-1.5">
                  <Badge variant="secondary" className="bg-purple-50 text-purple-700 text-xs">
                    {karAmuzSearch}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => { setFormKarAmuzId(''); setKarAmuzSearch(''); }}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>

            {/* Start time */}
            <div className="space-y-1.5">
              <Label className="text-sm font-medium">زمان شروع</Label>
              <Input
                type="datetime-local"
                value={formStartedAt}
                onChange={(e) => setFormStartedAt(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
              ثبت مکالمه
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col" dir="rtl">
          {detailConv && (() => {
            const statusMeta = STATUS_META[detailConv.status] || STATUS_META.ACTIVE;
            const channelMeta = CHANNEL_META[detailConv.channel] || CHANNEL_META.PHONE;
            const sentimentMeta = detailConv.sentiment ? SENTIMENT_META[detailConv.sentiment] : null;
            const ChannelIcon = channelMeta.icon;
            return (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2 text-right">
                    <Headphones className="w-5 h-5 text-teal-600" />
                    {detailConv.subject || 'مکالمه بدون عنوان'}
                  </DialogTitle>
                </DialogHeader>

                <div className="flex-1 overflow-y-auto space-y-4 py-2">
                  {/* Info bar */}
                  <div className="flex flex-wrap items-center gap-3 text-sm">
                    <Badge className={`${statusMeta.bgColor} ${statusMeta.color} border-0`}>
                      {statusMeta.label}
                    </Badge>
                    <div className="flex items-center gap-1.5 text-gray-600">
                      <ChannelIcon className="w-4 h-4" />
                      <span>{channelMeta.label}</span>
                    </div>
                    {sentimentMeta && (
                      <Badge className={`${sentimentMeta.bgColor} ${sentimentMeta.color} border-0`}>
                        {sentimentMeta.label}
                      </Badge>
                    )}
                    {detailConv.durationSec && (
                      <span className="text-gray-500 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {formatDuration(detailConv.durationSec)}
                      </span>
                    )}
                    <span className="text-gray-500">
                      {getRelatedName(detailConv)}
                    </span>
                  </div>

                  {/* AI Summary */}
                  {detailConv.summary && (
                    <div className="bg-teal-50 border border-teal-200 rounded-lg p-3">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Sparkles className="w-4 h-4 text-teal-600" />
                        <span className="text-xs font-bold text-teal-700">خلاصه AI</span>
                      </div>
                      <p className="text-sm text-teal-800 leading-relaxed">{detailConv.summary}</p>
                    </div>
                  )}

                  {/* Key Topics */}
                  {detailConv.keyTopics && (
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs text-gray-500 font-bold">موضوعات:</span>
                      {detailConv.keyTopics.split(',').map((topic, i) => (
                        <Badge key={i} variant="secondary" className="bg-gray-100 text-gray-600 text-xs border-0">
                          {topic.trim()}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Messages */}
                  <div className="space-y-3 max-h-96 overflow-y-auto p-1">
                    {detailLoading ? (
                      <div className="space-y-3">
                        {[...Array(3)].map((_, i) => (
                          <Skeleton key={i} className="h-12 rounded-xl" />
                        ))}
                      </div>
                    ) : (detailConv.messages || []).length === 0 ? (
                      <div className="text-center py-8 text-gray-400">
                        <MessageSquare className="w-8 h-8 mx-auto mb-2" />
                        <p className="text-sm">هنوز پیامی ثبت نشده</p>
                      </div>
                    ) : (
                      (detailConv.messages || []).map((msg) => {
                        const isCustomer = msg.speaker === 'CUSTOMER';
                        const isAI = msg.speaker === 'AI_ASSISTANT';
                        return (
                          <div
                            key={msg.id}
                            className={`flex ${isCustomer ? 'justify-start' : 'justify-end'}`}
                          >
                            <div
                              className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                                isCustomer
                                  ? 'bg-blue-100 text-blue-900 rounded-br-sm'
                                  : isAI
                                    ? 'bg-teal-100 text-teal-900 rounded-bl-sm'
                                    : 'bg-gray-100 text-gray-900 rounded-bl-sm'
                              }`}
                            >
                              {/* Speaker label */}
                              <div className="flex items-center gap-1.5 mb-1">
                                {isAI && <Sparkles className="w-3 h-3 text-teal-600" />}
                                <span className={`text-xs font-bold ${
                                  isCustomer ? 'text-blue-700' : isAI ? 'text-teal-700' : 'text-gray-600'
                                }`}>
                                  {msg.speakerName || (isCustomer ? 'مشتری' : isAI ? 'دستیار AI' : 'مشاور')}
                                </span>
                                <span className="text-xs text-gray-400">
                                  {formatPersianTime(msg.timestamp)}
                                </span>
                              </div>
                              {/* Content */}
                              <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                              {/* AI suggestion */}
                              {msg.aiSuggestion && (
                                <div className="mt-2 pt-2 border-t border-gray-200/50">
                                  <div className="flex items-center gap-1 mb-1">
                                    <Sparkles className="w-3 h-3 text-yellow-600" />
                                    <span className="text-xs font-bold text-yellow-700">پیشنهاد AI</span>
                                    {msg.aiConfidence && (
                                      <span className="text-xs text-gray-400">
                                        ({toPersianNumber(Math.round(msg.aiConfidence * 100))}٪)
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-xs text-gray-600">{msg.aiSuggestion}</p>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* AI Suggestion result */}
                  {aiSuggestionText && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Sparkles className="w-4 h-4 text-yellow-600" />
                        <span className="text-xs font-bold text-yellow-700">پیشنهاد پاسخ AI</span>
                      </div>
                      <p className="text-sm text-yellow-800 leading-relaxed whitespace-pre-wrap">{aiSuggestionText}</p>
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-2 text-xs gap-1"
                        onClick={() => {
                          setNewMessage(aiSuggestionText);
                          setNewMessageSpeaker('AGENT');
                        }}
                      >
                        <Send className="w-3 h-3" />
                        استفاده از پیشنهاد
                      </Button>
                    </div>
                  )}

                  {/* Action buttons */}
                  <div className="flex flex-wrap gap-2">
                    {detailConv.status === 'ACTIVE' && (
                      <Button
                        size="sm"
                        onClick={() => handleStatusChange('COMPLETED')}
                        disabled={statusSubmitting}
                        className="bg-blue-600 hover:bg-blue-700 text-white gap-1"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        تکمیل مکالمه
                      </Button>
                    )}
                    {detailConv.status === 'COMPLETED' && (
                      <Button
                        size="sm"
                        onClick={() => handleStatusChange('ARCHIVED')}
                        disabled={statusSubmitting}
                        className="bg-gray-600 hover:bg-gray-700 text-white gap-1"
                      >
                        بایگانی
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleAiSuggest}
                      disabled={aiSuggesting}
                      className="gap-1 border-teal-300 text-teal-700 hover:bg-teal-50"
                    >
                      {aiSuggesting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                      پیشنهاد AI
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={handleAiSummarize}
                      disabled={aiSummarizing}
                      className="gap-1 border-teal-300 text-teal-700 hover:bg-teal-50"
                    >
                      {aiSummarizing ? <Loader2 className="w-3 h-3 animate-spin" /> : <FileText className="w-3 h-3" />}
                      خلاصه‌سازی AI
                    </Button>
                  </div>

                  {/* Message input */}
                  <div className="border-t pt-3 space-y-2">
                    <div className="flex gap-2">
                      <Select value={newMessageSpeaker} onValueChange={setNewMessageSpeaker}>
                        <SelectTrigger className="w-32 bg-white text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="AGENT">مشاور</SelectItem>
                          <SelectItem value="CUSTOMER">مشتری</SelectItem>
                          <SelectItem value="AI_ASSISTANT">دستیار AI</SelectItem>
                        </SelectContent>
                      </Select>
                      <div className="flex-1 relative">
                        <Input
                          placeholder="پیام جدید..."
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                              e.preventDefault();
                              handleSendMessage();
                            }
                          }}
                          className="pr-4 pl-10"
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="absolute left-1 top-1/2 -translate-y-1/2 h-7 w-7 text-teal-600 hover:text-teal-700"
                          onClick={handleSendMessage}
                          disabled={messageSubmitting || !newMessage.trim()}
                        >
                          {messageSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>
    </div>
  );
}
