import { Metadata } from 'next';
import { siteConfig } from '@/config/site';
import { courses, competencyClusters } from '@/data/courses';
import FaniHerfeiClient from './FaniHerfeiClient';

export default function FaniHerfeiPage() {
  // JSON-LD: EducationalOrganization
  const orgSchema = {
    '@context': 'https://schema.org',
    '@type': 'EducationalOrganization',
    name: siteConfig.name.fullName,
    alternateName: [siteConfig.name.fa, siteConfig.name.en, siteConfig.name.fullEn],
    url: siteConfig.url.base,
    logo: `${siteConfig.url.base}${siteConfig.assets.logo}`,
    description: `آموزشگاه فنی و حرفه‌ای بهان رایانه با ۲۷ سال سابقه در محمودآباد مازندران. ارائه‌دهنده دوره‌های مهارتی مبتنی بر شایستگی (CBT) با مجوز رسمی سازمان فنی و حرفه‌ای ایران.`,
    telephone: siteConfig.contact.phoneRaw,
    email: siteConfig.contact.email,
    address: {
      '@type': 'PostalAddress',
      streetAddress: 'خیابان امام، کوچه آسیاب (نسیم ۴)، انتهای کوچه',
      addressLocality: siteConfig.location.city,
      addressRegion: siteConfig.location.province,
      postalCode: '47716',
      addressCountry: 'IR',
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: siteConfig.location.latitude,
      longitude: siteConfig.location.longitude,
    },
    foundingDate: '1377',
    sameAs: [
      siteConfig.social.instagram,
      siteConfig.social.telegram,
    ],
  };

  // JSON-LD: FAQPage
  const faqSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: 'آموزشگاه فنی و حرفه‌ای بهان رایانه چه دوره‌هایی دارد؟',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'دوره‌ها در ۳ خوشه و ۸ گروه آموزشی ارائه می‌شوند: خوشه خدمات (فن آوری اطلاعات شامل ICDL، پایتون، هوش مصنوعی؛ امور مالی و بازرگانی شامل فارکس، MQL5، حسابداری، بورس؛ خدمات آموزشی و خدمات حقوقی)، خوشه صنعت (معماری و ساختمان شامل AutoCAD، 3D Max) و خوشه فرهنگ و هنر (صنایع پوشاک و هنرهای تجسمی شامل فتوشاپ، کورل‌دراو).',
        },
      },
      {
        '@type': 'Question',
        name: 'مدارک فنی و حرفه‌ای آیا معتبر هستند؟',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'بله. گواهینامه ICDL بین‌المللی و در ۱۴۰+ کشور معتبر است. سایر گواهینامه‌ها توسط سازمان فنی و حرفه‌ای صادر می‌شوند و دارای اعتبار رسمی هستند. مدرک فنی و حرفه‌ای برای اشتغال، مهاجرت و ارتقای شغلی معتبر است.',
        },
      },
      {
        '@type': 'Question',
        name: 'شرایط ثبت‌نام در دوره‌های فنی و حرفه‌ای چیست؟',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'ثبت‌نام برای اکثر دوره‌های پایه بدون پیش‌نیاز است. دوره‌های پیشرفته نیازمند گذراندن دوره‌های پایه‌ای هستند. امکان قسط‌بندی ۲ تا ۳ ماهه بدون چک و بدون بهره وجود دارد. برای ثبت‌نام به کارت شناسایی و عکس نیاز است.',
        },
      },
      {
        '@type': 'Question',
        name: 'آموزشگاه فنی و حرفه‌ای بهان رایانه مجوز رسمی دارد؟',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'بله، آموزشگاه بهان رایانه دارای مجوز رسمی سازمان آموزش فنی و حرفه‌ای ایران و عضو نظام صنفی رایانه‌ای استان مازندران است. همچنین مرکز آزمون بین‌المللی ICDL نیز می‌باشد.',
        },
      },
      {
        '@type': 'Question',
        name: 'آموزش مبتنی بر شایستگی (CBT) چیست؟',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'CBT یا Competency-Based Training روشی آموزشی است که بر کسب شایستگی‌های عملی و قابل اندازه‌گیری تمرکز دارد. در این روش، کارآموز بر اساس تسلط بر مهارت‌ها ارزیابی می‌شود، نه فقط حضور در کلاس. سازمان فنی و حرفه‌ای ایران از این روش استفاده می‌کند.',
        },
      },
    ],
  };

  // JSON-LD: BreadcrumbList
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'خانه', item: siteConfig.url.base },
      { '@type': 'ListItem', position: 2, name: 'فنی و حرفه‌ای', item: `${siteConfig.url.base}/fani-herfei` },
    ],
  };

  // JSON-LD: ItemList (courses)
  const courseListSchema = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: 'دوره‌های فنی و حرفه‌ای بهان رایانه',
    numberOfItems: courses.length,
    itemListElement: courses.map((course, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      item: {
        '@type': 'Course',
        name: course.title,
        url: `${siteConfig.url.base}/courses/${course.slug}`,
        description: course.subtitle,
        provider: {
          '@type': 'Organization',
          name: siteConfig.name.fullName,
        },
      },
    })),
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(courseListSchema) }} />
      <FaniHerfeiClient courses={courses} clusters={competencyClusters} />
    </>
  );
}
