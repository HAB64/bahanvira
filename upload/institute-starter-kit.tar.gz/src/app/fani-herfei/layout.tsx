import { Metadata } from 'next';
import { siteConfig } from '@/config/site';

export const metadata: Metadata = {
  title: 'آموزشگاه فنی و حرفه‌ای در محمودآباد مازندران | ثبت‌نام دوره‌های مهارتی',
  description: `آموزشگاه فنی و حرفه‌ای بهان رایانه با ۲۷ سال سابقه در محمودآباد مازندران. ثبت‌نام دوره‌های ICDL، برنامه‌نویسی، فارکس، حسابداری، طراحی دوخت و هوش مصنوعی. مدرک معتبر بین‌المللی و ملی. مجوز رسمی سازمان فنی و حرفه‌ای ایران.`,
  keywords: [
    'آموزشگاه فنی و حرفه‌ای محمودآباد',
    'ثبت‌نام فنی و حرفه‌ای',
    'دوره فنی و حرفه‌ای',
    'مدرک فنی و حرفه‌ای',
    'آموزش فنی و حرفه‌ای در محمودآباد',
    'آموزشگاه مهارتی محمودآباد',
    'سازمان فنی و حرفه‌ای',
    'CBT فنی و حرفه‌ای',
    'آموزش مبتنی بر شایستگی',
    'گواهینامه فنی و حرفه‌ای',
    siteConfig.name.fa,
    siteConfig.location.city,
    siteConfig.location.province,
  ],
  alternates: {
    canonical: `${siteConfig.url.base}/fani-herfei`,
  },
  openGraph: {
    title: 'آموزشگاه فنی و حرفه‌ای در محمودآباد | ثبت‌نام دوره‌های مهارتی',
    description: `ثبت‌نام دوره‌های مهارتی فنی و حرفه‌ای در محمودآباد مازندران. ICDL، پایتون، فارکس، حسابداری و بیشتر. مدرک معتبر.`,
    locale: 'fa_IR',
    url: `${siteConfig.url.base}/fani-herfei`,
    type: 'website',
    siteName: siteConfig.name.fullName,
    images: [
      {
        url: `${siteConfig.url.base}${siteConfig.assets.ogImage}`,
        width: 1200,
        height: 630,
        alt: `آموزشگاه فنی و حرفه‌ای ${siteConfig.name.fa}`,
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'آموزشگاه فنی و حرفه‌ای در محمودآباد | ثبت‌نام دوره‌های مهارتی',
    description: `ثبت‌نام دوره‌های مهارتی فنی و حرفه‌ای. مدرک معتبر بین‌المللی و ملی.`,
  },
};

export default function FaniHerfeiLayout({ children }: { children: React.ReactNode }) {
  return children;
}
