'use client';

import { useState } from 'react';
import Link from 'next/link';
import {
  GraduationCap, Shield, Award, Clock, Users, CheckCircle2,
  Phone, MessageCircle, ChevronDown, ChevronUp, MapPin,
  BookOpen, Cpu, TrendingUp, Briefcase, Palette, ArrowLeft,
  Star, Zap, Heart, Target, FileText, Globe, Brain
} from 'lucide-react';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { siteConfig } from '@/config/site';

type Course = import('@/data/courses').Course;
type CompetencyCluster = import('@/data/courses').CompetencyCluster;

const clusterIcons: Record<string, React.ElementType> = {
  'it': Cpu,
  'ai': Brain,
  'financial': TrendingUp,
  'management': Briefcase,
  'creative': Palette,
};

const clusterColors: Record<string, string> = {
  'it': '#0d9488',
  'ai': '#8B5CF6',
  'financial': '#d97706',
  'management': '#7c3aed',
  'creative': '#e11d48',
};

const faqs = [
  {
    q: 'آموزشگاه فنی و حرفه‌ای بهان رایانه چه دوره‌هایی دارد؟',
    a: 'دوره‌ها در ۳ خوشه و ۸ گروه آموزشی ارائه می‌شوند: خوشه خدمات (فن آوری اطلاعات شامل ICDL، پایتون، هوش مصنوعی؛ امور مالی و بازرگانی شامل فارکس، MQL5، حسابداری، بورس؛ خدمات آموزشی و خدمات حقوقی)، خوشه صنعت (معماری و ساختمان شامل AutoCAD، 3D Max) و خوشه فرهنگ و هنر (صنایع پوشاک و هنرهای تجسمی شامل فتوشاپ، کورل‌دراو). هر گروه شامل دوره‌های پایه، متوسط و پیشرفته است تا کارآموزان بتوانند مسیر شغلی خود را به‌صورت گام‌به‌گام طی کنند.',
  },
  {
    q: 'مدارک فنی و حرفه‌ای آیا معتبر هستند؟',
    a: 'بله. گواهینامه ICDL بین‌المللی و در بیش از ۱۴۰ کشور معتبر است و توسط بنیاد ICDL جهانی صادر می‌شود. سایر گواهینامه‌ها توسط سازمان فنی و حرفه‌ای صادر می‌شوند و دارای اعتبار رسمی دولتی هستند. مدرک فنی و حرفه‌ای برای اشتغال، ارتقای شغلی، استخدام در نهادهای دولتی و حتی مهاجرت معتبر شناخته می‌شود.',
  },
  {
    q: 'شرایط ثبت‌نام در دوره‌های فنی و حرفه‌ای چیست؟',
    a: 'ثبت‌نام برای اکثر دوره‌های پایه (مانند ICDL و Scratch) بدون پیش‌نیاز است و هر علاقه‌مندی می‌تواند شرکت کند. دوره‌های متوسط و پیشرفته نیازمند گذراندن دوره‌های پایه‌ای هستند. امکان قسط‌بندی ۲ تا ۳ ماهه بدون چک و بدون بهره وجود دارد. برای ثبت‌نام نهایی به کارت شناسایی ملی و ۲ قطعه عکس نیاز است.',
  },
  {
    q: 'آموزشگاه فنی و حرفه‌ای بهان رایانه مجوز رسمی دارد؟',
    a: 'بله، آموزشگاه بهان رایانه دارای مجوز رسمی سازمان آموزش فنی و حرفه‌ای ایران با شماره پروانه مجاز است. همچنین عضو رسمی نظام صنفی رایانه‌ای استان مازندران و مرکز آزمون بین‌المللی ICDL نیز می‌باشد. تمامی مدارک صادره از این آموزشگاه دارای اعتبار قانونی هستند.',
  },
  {
    q: 'آموزش مبتنی بر شایستگی (CBT) چیست؟',
    a: 'CBT یا Competency-Based Training روشی آموزشی است که بر کسب شایستگی‌های عملی و قابل اندازه‌گیری تمرکز دارد. در این روش، کارآموز بر اساس تسلط بر مهارت‌ها و انجام کارهای عملی ارزیابی می‌شود، نه فقط بر اساس حضور در کلاس یا آزمون تئوری. سازمان فنی و حرفه‌ای ایران از این استاندارد آموزشی استفاده می‌کند و مدرک صادره نشان‌دهنده تسلط واقعی فرد بر مهارت‌ها است.',
  },
  {
    q: 'آیا پس از اتمام دوره پشتیبانی ارائه می‌شود؟',
    a: 'بله، آموزشگاه بهان رایانه تا زمان اخذ مدرک و حتی پس از آن پشتیبانی رایگان ارائه می‌دهد. برای دوره‌های فناوری، دسترسی به مخزن کد و آپدیت‌های دوره فراهم است. همچنین مشاوران آموزشگاه برای تعیین مسیر شغلی و پیشنهاد دوره‌های بعدی در دسترس هستند.',
  },
  {
    q: 'آیا امکان شرکت در آزمون آنلاین وجود دارد؟',
    a: 'بله، آموزشگاه بهان رایانه به‌عنوان مرکز آزمون معتبر، امکان برگزاری آزمون‌های آنلاین و حضوری را فراهم کرده است. آزمون‌های ICDL به‌صورت بین‌المللی و آنلاین برگزار می‌شوند. آزمون‌های فنی و حرفه‌ای نیز مطابق استانداردهای سازمان برگزار می‌گردند.',
  },
  {
    q: 'ساعات کاری آموزشگاه چگونه است؟',
    a: 'ساعات کاری آموزشگاه: شنبه تا چهارشنبه ۸ صبح تا ۸ شب و پنجشنبه ۸ صبح تا ۱ ظهر می‌باشد. کلاس‌ها در شیفت‌های صبح، عصر و شب برگزار می‌شوند تا تناسب بیشتری با برنامه زمانی کارآموزان داشته باشند.',
  },
];

const advantages = [
  { icon: Shield, title: 'مجوز رسمی فنی و حرفه‌ای', desc: 'دارای پروانه مجاز از سازمان آموزش فنی و حرفه‌ای ایران' },
  { icon: Award, title: 'مدرک بین‌المللی ICDL', desc: 'مرکز آزمون رسمی ICDL با گواهینامه معتبر در ۱۴۰+ کشور' },
  { icon: Clock, title: '۲۷ سال تجربه آموزشی', desc: 'یکی از قدیمی‌ترین و معتبرترین آموزشگاه‌های استان مازندران' },
  { icon: Users, title: 'آموزش مبتنی بر شایستگی', desc: 'روش CBT — ارزیابی بر اساس مهارت عملی، نه فقط تئوری' },
  { icon: Zap, title: 'قسط‌بندی بدون بهره', desc: 'امکان پرداخت اقساط ۲ تا ۳ ماهه بدون چک و بدون بهره' },
  { icon: Heart, title: 'پشتیبانی تا اخذ مدرک', desc: 'همراهی کامل از ثبت‌نام تا دریافت گواهینامه و بعد از آن' },
];

interface Props {
  courses: Course[];
  clusters: CompetencyCluster[];
}

export default function FaniHerfeiClient({ courses, clusters }: Props) {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <main className="flex-1">
        {/* ═══ Hero ═══ */}
        <section className="bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#065f46] py-14 sm:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              <span className="inline-block text-sm font-medium text-teal-200 bg-white/10 rounded-full px-5 py-2 mb-5">
                آموزشگاه فنی و حرفه‌ای در {siteConfig.location.city}
              </span>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white mb-5 leading-tight">
                آموزشگاه فنی و حرفه‌ای بهان رایانه
              </h1>
              <p className="text-white/85 text-lg sm:text-xl leading-relaxed mb-8">
                با {siteConfig.experience.yearsFa} سال تجربه در {siteConfig.location.city} {siteConfig.location.province}،
                دوره‌های مهارتی مبتنی بر شایستگی (CBT) با مجوز رسمی سازمان فنی و حرفه‌ای ایران.
                از ICDL تا هوش مصنوعی، مسیر شغلی خود را بسازید.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="/consulting"
                  className="inline-flex items-center justify-center gap-2 bg-white text-[#0d9488] font-bold py-3.5 px-8 rounded-xl hover:bg-gray-50 transition-colors shadow-lg text-sm sm:text-base"
                >
                  <GraduationCap className="w-5 h-5" />
                  ثبت‌نام دوره‌ها
                </a>
                <a
                  href={siteConfig.contact.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white font-bold py-3.5 px-8 rounded-xl hover:bg-[#20ba5c] transition-colors shadow-lg text-sm sm:text-base"
                >
                  <MessageCircle className="w-5 h-5" />
                  مشاوره رایگان
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* ═══ مزیت‌ها ═══ */}
        <section className="py-14 sm:py-18 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
                چرا آموزشگاه فنی و حرفه‌ای بهان رایانه؟
              </h2>
              <p className="text-[#64748b] max-w-2xl mx-auto">
                اعتبار، تجربه و کیفیت آموزش، سه ستون اصلی آموزشگاه بهان رایانه
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {advantages.map((adv) => (
                <div key={adv.title} className="bg-gray-50 rounded-2xl p-6 hover:shadow-lg transition-all border border-gray-100">
                  <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-4">
                    <adv.icon className="w-6 h-6 text-[#0d9488]" />
                  </div>
                  <h3 className="font-bold text-[#0f172a] text-lg mb-2">{adv.title}</h3>
                  <p className="text-sm text-[#64748b] leading-relaxed">{adv.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ═══ خوشه‌های شایستگی ═══ */}
        <section className="py-14 sm:py-18 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
                دوره‌های فنی و حرفه‌ای در ۳ خوشه و ۸ گروه آموزشی
              </h2>
              <p className="text-[#64748b] max-w-2xl mx-auto">
                سازمان فنی و حرفه‌ای ایران، دوره‌های مهارتی را در قالب خوشه‌های شایستگی دسته‌بندی می‌کند.
                هر خوشه شامل مسیر آموزشی از سطح پایه تا پیشرفته است.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {clusters.map((cluster) => {
                const Icon = clusterIcons[cluster.id] || BookOpen;
                const color = clusterColors[cluster.id] || '#0d9488';
                const clusterCourses = courses.filter((c) => c.cluster === cluster.id);
                return (
                  <div key={cluster.id} className="bg-white rounded-2xl p-6 hover:shadow-lg transition-all border border-gray-100">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-4" style={{ backgroundColor: `${color}15` }}>
                      <Icon className="w-6 h-6" style={{ color }} />
                    </div>
                    <h3 className="font-bold text-[#0f172a] text-lg mb-1">{cluster.name}</h3>
                    <p className="text-xs text-[#64748b] mb-4" dir="ltr">{cluster.nameEn}</p>
                    <ul className="space-y-2">
                      {clusterCourses.map((course) => (
                        <li key={course.slug}>
                          <Link
                            href={`/courses/${course.slug}`}
                            className="flex items-center gap-2 text-sm text-[#475569] hover:text-[#0d9488] transition-colors"
                          >
                            <ArrowLeft className="w-3.5 h-3.5 flex-shrink-0" />
                            {course.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
            <div className="text-center mt-10">
              <Link
                href="/courses"
                className="inline-flex items-center gap-2 bg-[#0d9488] text-white font-bold py-3 px-8 rounded-xl hover:bg-[#0f766e] transition-colors shadow-sm"
              >
                مشاهده همه دوره‌ها
                <ArrowLeft className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* ═══ مسیر شغلی ═══ */}
        <section className="py-14 sm:py-18 bg-white">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
                از ثبت‌نام تا اشتغال — مسیر شغلی شما
              </h2>
              <p className="text-[#64748b] max-w-2xl mx-auto">
                آموزشگاه فنی و حرفه‌ای بهان رایانه، فقط آموزش نمی‌دهد؛ مسیر شغلی شما را از نقطه صفر تا بازار کار هماهنگ می‌کند.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Target, step: '۱', title: 'مشاوره و انتخاب مسیر', desc: 'مشاوره رایگان برای شناخت مهارت‌ها و انتخاب بهترین مسیر شغلی متناسب با علاقه و شرایط شما' },
                { icon: BookOpen, step: '۲', title: 'آموزش عملی (CBT)', desc: 'یادگیری مهارت‌ها با روش مبتنی بر شایستگی: تمرین عملی، پروژه‌های واقعی و ارزیابی مستمر' },
                { icon: FileText, step: '۳', title: 'اخذ گواهینامه', desc: 'دریافت مدرک معتبر بین‌المللی (ICDL) یا ملی (فنی و حرفه‌ای) پس از قبولی در آزمون رسمی' },
                { icon: Globe, step: '۴', title: 'ورود به بازار کار', desc: 'پشتیبانی شغلی، معرفی به کارفرمایان و راهنمایی برای فریلنسری یا راه‌اندازی کسب‌وکار مستقل' },
              ].map((item) => (
                <div key={item.step} className="text-center">
                  <div className="relative mx-auto mb-4">
                    <div className="w-16 h-16 rounded-full bg-[#0d9488] flex items-center justify-center mx-auto">
                      <item.icon className="w-7 h-7 text-white" />
                    </div>
                    <span className="absolute -top-1 -right-1 w-7 h-7 rounded-full bg-[#0f172a] text-white text-xs font-bold flex items-center justify-center">
                      {item.step}
                    </span>
                  </div>
                  <h3 className="font-bold text-[#0f172a] mb-2">{item.title}</h3>
                  <p className="text-sm text-[#64748b] leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ═══ شرایط ثبت‌نام ═══ */}
        <section className="py-14 sm:py-18 bg-gray-50">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
                شرایط و مراحل ثبت‌نام
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <h3 className="font-bold text-[#0f172a] text-lg mb-4 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#0d9488]" />
                  مدارک مورد نیاز
                </h3>
                <ul className="space-y-3">
                  {[
                    'کارت شناسایی ملی (کدملی)',
                    '۲ قطعه عکس پرسنلی',
                    'برای دوره‌های پایه: بدون پیش‌نیاز',
                    'برای دوره‌های پیشرفته: مدرک دوره پایه',
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-[#475569]">
                      <CheckCircle2 className="w-4 h-4 text-[#0d9488] mt-0.5 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <h3 className="font-bold text-[#0f172a] text-lg mb-4 flex items-center gap-2">
                  <Star className="w-5 h-5 text-[#0d9488]" />
                  شرایط ویژه
                </h3>
                <ul className="space-y-3">
                  {[
                    'قسط‌بندی ۲ تا ۳ ماهه بدون چک و بدون بهره',
                    'تخفیف ویژه برای ثبت‌نام هم‌زمان در ۲ دوره',
                    'رایگان‌آموزی برای کارآموزان متعهد و مستعد',
                    'مشاوره رایگان قبل از ثبت‌نام',
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-[#475569]">
                      <Star className="w-4 h-4 text-[#d97706] mt-0.5 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* ═══ سؤالات متداول ═══ */}
        <section className="py-14 sm:py-18 bg-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
                سؤالات متداول درباره فنی و حرفه‌ای
              </h2>
              <p className="text-[#64748b]">
                پاسخ سؤالات رایج درباره دوره‌ها، مدارک و ثبت‌نام
              </p>
            </div>
            <div className="space-y-3">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="border border-gray-200 rounded-xl overflow-hidden hover:border-[#0d9488]/30 transition-colors"
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 text-right bg-white hover:bg-gray-50/50 transition-colors"
                  >
                    <span className="font-medium text-[#0f172a] text-sm sm:text-base">{faq.q}</span>
                    {openFaq === i ? (
                      <ChevronUp className="w-5 h-5 text-[#0d9488] flex-shrink-0 mr-3" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-[#64748b] flex-shrink-0 mr-3" />
                    )}
                  </button>
                  {openFaq === i && (
                    <div className="px-5 pb-5 pt-0">
                      <p className="text-sm text-[#475569] leading-relaxed">{faq.a}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ═══ اطلاعات تماس و موقعیت ═══ */}
        <section className="py-14 sm:py-18 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
                آموزشگاه فنی و حرفه‌ای بهان رایانه در {siteConfig.location.city}
              </h2>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <MapPin className="w-8 h-8 text-[#0d9488] mb-3" />
                <h3 className="font-bold text-[#0f172a] mb-2">آدرس</h3>
                <p className="text-sm text-[#64748b] leading-relaxed">{siteConfig.location.fullAddress}</p>
                <p className="text-sm text-[#64748b] mt-1">{siteConfig.location.province}، ایران</p>
              </div>
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <Phone className="w-8 h-8 text-[#0d9488] mb-3" />
                <h3 className="font-bold text-[#0f172a] mb-2">تماس</h3>
                <p className="text-sm text-[#64748b] mb-1">تلفن: {siteConfig.contact.phone}</p>
                <p className="text-sm text-[#64748b] mb-1">واتساپ: {siteConfig.contact.whatsappDisplay}</p>
                <p className="text-sm text-[#64748b]">ایمیل: {siteConfig.contact.email}</p>
              </div>
              <div className="bg-white rounded-2xl p-6 border border-gray-100">
                <Clock className="w-8 h-8 text-[#0d9488] mb-3" />
                <h3 className="font-bold text-[#0f172a] mb-2">ساعات کاری</h3>
                <p className="text-sm text-[#64748b]">{siteConfig.workHours}</p>
                <p className="text-sm text-[#64748b] mt-2">کلاس‌ها در شیفت صبح، عصر و شب</p>
              </div>
            </div>
          </div>
        </section>

        {/* ═══ CTA ═══ */}
        <section className="py-14 sm:py-18 bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#065f46]">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
              همین الان ثبت‌نام کنید
            </h2>
            <p className="text-white/80 text-lg mb-8 leading-relaxed">
              ترم جدید دوره‌های فنی و حرفه‌ای آغاز شده است.
              ظرفیت کلاس‌ها محدود است — همین الان مشاوره رایگان دریافت کنید.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/consulting"
                className="inline-flex items-center justify-center gap-2 bg-white text-[#0d9488] font-bold py-3.5 px-8 rounded-xl hover:bg-gray-50 transition-colors shadow-lg"
              >
                <GraduationCap className="w-5 h-5" />
                ثبت‌نام دوره‌ها
              </a>
              <a
                href={siteConfig.contact.phoneHref}
                className="inline-flex items-center justify-center gap-2 bg-white/10 text-white font-bold py-3.5 px-8 rounded-xl hover:bg-white/20 transition-colors border border-white/20"
              >
                <Phone className="w-5 h-5" />
                {siteConfig.contact.phone}
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
