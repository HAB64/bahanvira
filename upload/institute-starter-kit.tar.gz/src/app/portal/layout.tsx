'use client';

import { useEffect, useState, useCallback, createContext, useContext } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  LayoutDashboard,
  User,
  Receipt,
  Ticket,
  LogOut,
  Menu,
  X,
  GraduationCap,
  ChevronLeft,
  ClipboardCheck,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { siteConfig } from '@/config/site';

// Portal auth context
interface PortalUser {
  id: string;
  username: string;
  displayName?: string;
  leadId?: string | null;
  karAmuzId?: string | null;
  lead?: { id: string; name: string; phone: string; email: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string; phone: string; email: string } | null;
}

interface PortalContextType {
  user: PortalUser | null;
  token: string | null;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const PortalContext = createContext<PortalContextType>({
  user: null,
  token: null,
  logout: () => {},
  refreshUser: async () => {},
});

export function usePortalAuth() {
  return useContext(PortalContext);
}

const navItems = [
  { href: '/portal/dashboard', label: 'داشبورد', icon: LayoutDashboard },
  { href: '/portal/exams', label: 'آزمون‌ها', icon: ClipboardCheck },
  { href: '/portal/profile', label: 'پروفایل', icon: User },
  { href: '/portal/invoices', label: 'فاکتورها', icon: Receipt },
  { href: '/portal/tickets', label: 'تیکت‌ها', icon: Ticket },
];

export default function PortalLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<PortalUser | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isLoginPage = pathname === '/portal/login';

  const refreshUser = useCallback(async () => {
    const storedToken = localStorage.getItem('portal_token');
    if (!storedToken) {
      if (!isLoginPage) {
        router.push('/portal/login');
      }
      setIsLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/portal/auth', {
        headers: { Authorization: `Bearer ${storedToken}` },
      });
      const data = await res.json();

      if (data.authenticated && data.data) {
        setUser(data.data);
        setToken(storedToken);
        localStorage.setItem('portal_user', JSON.stringify(data.data));
      } else {
        localStorage.removeItem('portal_token');
        localStorage.removeItem('portal_user');
        if (!isLoginPage) {
          router.push('/portal/login');
        }
      }
    } catch {
      // On error, try to use cached user data
      const cachedUser = localStorage.getItem('portal_user');
      if (cachedUser) {
        try {
          setUser(JSON.parse(cachedUser));
          setToken(storedToken);
        } catch {
          localStorage.removeItem('portal_token');
          localStorage.removeItem('portal_user');
          if (!isLoginPage) {
            router.push('/portal/login');
          }
        }
      } else if (!isLoginPage) {
        router.push('/portal/login');
      }
    } finally {
      setIsLoading(false);
    }
  }, [isLoginPage, router]);

  useEffect(() => {
    if (isLoginPage) {
      // If already logged in, redirect to dashboard
      const storedToken = localStorage.getItem('portal_token');
      if (storedToken) {
        router.push('/portal/dashboard');
        return;
      }
      setIsLoading(false);
      return;
    }

    refreshUser();
  }, [isLoginPage, refreshUser, router]);

  const logout = useCallback(() => {
    localStorage.removeItem('portal_token');
    localStorage.removeItem('portal_user');
    setUser(null);
    setToken(null);
    router.push('/portal/login');
  }, [router]);

  // Login page renders without layout
  if (isLoginPage) {
    return (
      <PortalContext.Provider value={{ user: null, token: null, logout, refreshUser }}>
        {children}
      </PortalContext.Provider>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-50 via-emerald-50 to-cyan-50">
        <div className="flex flex-col items-center gap-4">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-teal-600 border-t-transparent" />
          <p className="text-sm text-gray-500">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const initials = user.displayName
    ? user.displayName.split(' ').map(w => w[0]).join('').slice(0, 2)
    : user.username.slice(0, 2);

  return (
    <PortalContext.Provider value={{ user, token, logout, refreshUser }}>
      <div className="min-h-screen bg-gray-50/50 flex" dir="rtl">
        {/* SEO: Prevent search engine indexing of portal pages */}
        <head>
          <meta name="robots" content="noindex, nofollow" />
        </head>
        {/* Mobile overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/40 z-40 lg:hidden backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside
          className={`fixed top-0 right-0 z-50 h-full w-64 bg-white border-l border-gray-100 shadow-sm transform transition-transform duration-300 lg:translate-x-0 lg:static lg:z-auto ${
            sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
          }`}
        >
          <div className="flex flex-col h-full">
            {/* Logo area */}
            <div className="p-4 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center shadow-md shadow-teal-500/20">
                    <GraduationCap className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h2 className="font-bold text-gray-900 text-sm">پورتال مشتریان</h2>
                    <p className="text-xs text-gray-400">{siteConfig.name.fa}</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden h-8 w-8"
                  onClick={() => setSidebarOpen(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* User info */}
            <div className="p-4 bg-gradient-to-l from-teal-50/50 to-transparent">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10 border-2 border-teal-200">
                  <AvatarFallback className="bg-teal-100 text-teal-700 text-sm font-bold">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {user.displayName || user.username}
                  </p>
                  <p className="text-xs text-gray-400 truncate">
                    @{user.username}
                  </p>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <ScrollArea className="flex-1 px-3 py-2">
              <nav className="space-y-1">
                {navItems.map((item) => {
                  const isActive = pathname === item.href || (item.href !== '/portal/dashboard' && pathname.startsWith(item.href + '/'));
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                        isActive
                          ? 'bg-teal-50 text-teal-700 shadow-sm'
                          : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                      }`}
                    >
                      <item.icon className={`h-5 w-5 ${isActive ? 'text-teal-600' : ''}`} />
                      {item.label}
                      {isActive && <ChevronLeft className="h-4 w-4 mr-auto text-teal-500" />}
                    </Link>
                  );
                })}
              </nav>
            </ScrollArea>

            {/* Footer */}
            <div className="p-3 border-t border-gray-100">
              <Button
                variant="ghost"
                onClick={logout}
                className="w-full justify-start gap-3 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-xl h-11"
              >
                <LogOut className="h-5 w-5" />
                خروج از حساب
              </Button>
            </div>
          </div>
        </aside>

        {/* Main content */}
        <div className="flex-1 flex flex-col min-h-screen">
          {/* Top bar */}
          <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-gray-100 px-4 py-3 lg:px-6">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden h-9 w-9"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-3 mr-auto">
                <Separator orientation="vertical" className="h-5 hidden lg:block" />
                <span className="text-sm text-gray-400 hidden lg:block">
                  پورتال مشتریان {siteConfig.name.fa}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-700 hidden sm:block">
                  {user.displayName || user.username}
                </span>
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-teal-100 text-teal-700 text-xs font-bold">
                    {initials}
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>
          </header>

          {/* Page content */}
          <main className="flex-1 p-4 lg:p-6">
            {children}
          </main>
        </div>
      </div>
    </PortalContext.Provider>
  );
}
