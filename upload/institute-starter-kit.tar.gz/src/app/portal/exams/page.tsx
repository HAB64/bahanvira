'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import {
  Clock,
  Target,
  CheckCircle2,
  XCircle,
  AlertCircle,
  PlayCircle,
  FileCheck2,
  Ban,
  BookOpen,
  History,
  Loader2,
} from 'lucide-react';
import { usePortalAuth } from '@/app/portal/layout';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface AvailableExam {
  id: string;
  title: string;
  type: string;
  durationMinutes: number;
  passingScore: number;
  maxAttempts: number;
  questionCount: number;
  programName: string | null;
  openAt: string | null;
  closeAt: string | null;
  attemptsUsed: number;
  hasInProgress: boolean;
  bestScore: number | null;
  bestIsPassed: boolean | null;
}

interface PastAttempt {
  id: string;
  examId: string;
  examTitle: string;
  examType: string;
  programName: string | null;
  status: string;
  score: number | null;
  maxScore: number | null;
  percentage: number | null;
  isPassed: boolean | null;
  startedAt: string;
  submittedAt: string | null;
  timeSpentSec: number | null;
}

/* ─────────── Helpers ─────────── */

function getExamTypeBadge(type: string) {
  switch (type) {
    case 'QUIZ':
      return <Badge className="bg-blue-100 text-blue-700 border-0 text-xs">آزمون کوتاه</Badge>;
    case 'MIDTERM':
      return <Badge className="bg-purple-100 text-purple-700 border-0 text-xs">میان‌ترم</Badge>;
    case 'FINAL':
      return <Badge className="bg-red-100 text-red-700 border-0 text-xs">پایان‌ترم</Badge>;
    case 'PRACTICAL':
      return <Badge className="bg-teal-100 text-teal-700 border-0 text-xs">عملی</Badge>;
    case 'CERTIFICATION':
      return <Badge className="bg-amber-100 text-amber-700 border-0 text-xs">صدور گواهینامه</Badge>;
    default:
      return <Badge className="bg-gray-100 text-gray-700 border-0 text-xs">{type}</Badge>;
  }
}

function getAttemptStatusBadge(status: string) {
  switch (status) {
    case 'SUBMITTED':
      return <Badge className="bg-blue-100 text-blue-700 border-0 text-xs">تحویل شده</Badge>;
    case 'TIMED_OUT':
      return <Badge className="bg-amber-100 text-amber-700 border-0 text-xs">وقت تمام</Badge>;
    case 'AUTO_SUBMITTED':
      return <Badge className="bg-orange-100 text-orange-700 border-0 text-xs">خودکار</Badge>;
    case 'IN_PROGRESS':
      return <Badge className="bg-teal-100 text-teal-700 border-0 text-xs">در حال انجام</Badge>;
    default:
      return <Badge className="bg-gray-100 text-gray-700 border-0 text-xs">{status}</Badge>;
  }
}

function formatTimeSpent(seconds: number | null) {
  if (!seconds) return '—';
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${toPersianNumber(m)}:${toPersianNumber(s.toString().padStart(2, '0'))}`;
}

function formatDate(dateStr: string) {
  try {
    return new Date(dateStr).toLocaleDateString('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
}

/* ─────────── Main Component ─────────── */

export default function PortalExamsPage() {
  const router = useRouter();
  const { user, token } = usePortalAuth();
  const [availableExams, setAvailableExams] = useState<AvailableExam[]>([]);
  const [pastAttempts, setPastAttempts] = useState<PastAttempt[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchExams = useCallback(async () => {
    if (!token) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      // Use the correct API route that handles auth via token
      const res = await fetch('/api/exams/student', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(errData.error || errData['خطا'] || 'خطا در دریافت آزمون‌ها');
        return;
      }

      const result = await res.json();
      // API returns Persian keys: داده (past attempts) and آزمون‌های_فعال (available exams)
      const exams = result['آزمون‌های_فعال'] || result['داده'] || result.exams || result.data || [];
      const attempts = result['داده'] || result.attempts || [];

      setAvailableExams(Array.isArray(exams) ? exams : []);
      setPastAttempts(Array.isArray(attempts) ? attempts : []);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    if (user && token) {
      fetchExams();
    } else if (user && !token) {
      setLoading(false);
    }
  }, [user, token, fetchExams]);

  const handleStartExam = (examId: string) => {
    router.push(`/portal/exam/take?examId=${examId}`);
  };

  const handleViewResults = (attemptId: string) => {
    router.push(`/portal/exam/results?attemptId=${attemptId}`);
  };

  /* ──── Loading Skeleton ──── */
  if (loading || (!user && !token)) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Skeleton className="w-10 h-10 rounded-xl" />
          <div className="space-y-2">
            <Skeleton className="h-6 w-40" />
            <Skeleton className="h-4 w-24" />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-56 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  /* ──── Error State ──── */
  if (error && availableExams.length === 0 && pastAttempts.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="border-0 shadow-lg max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-lg font-bold text-gray-900 mb-2">خطا در بارگذاری</h2>
            <p className="text-gray-500 text-sm mb-4">{error}</p>
            <div className="flex gap-3 justify-center">
              <Button variant="outline" onClick={fetchExams}>تلاش مجدد</Button>
              <Button variant="ghost" onClick={() => router.push('/portal/dashboard')}>بازگشت</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  /* ──── No karAmuz linked ──── */
  if (!user?.karAmuzId) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="border-0 shadow-lg max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-12 h-12 text-amber-400 mx-auto mb-4" />
            <h2 className="text-lg font-bold text-gray-900 mb-2">حساب کارآموزی فعال نیست</h2>
            <p className="text-gray-500 text-sm mb-4">
              حساب پورتال شما هنوز به پرونده کارآموزی متصل نشده است.
              لطفاً با پشتیبانی تماس بگیرید.
            </p>
            <Button variant="ghost" onClick={() => router.push('/portal/dashboard')}>
              بازگشت به داشبورد
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalExams = availableExams.length;

  /* ──── Main Content ──── */
  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="flex items-center gap-3">
        <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-200">
          <BookOpen className="w-5 h-5 text-purple-600" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-gray-900">آزمون‌های من</h2>
          <p className="text-xs text-gray-400">
            {toPersianNumber(totalExams)} آزمون فعال
          </p>
        </div>
      </div>

      {/* Available Exams */}
      {totalExams === 0 && pastAttempts.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <CardContent className="p-8 text-center">
            <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">آزمونی برای شما یافت نشد</p>
            <p className="text-xs text-gray-400 mt-1">آزمون‌های اختصاص‌یافته به شما اینجا نمایش داده خواهد شد</p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Active Exams Section */}
          {totalExams > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {availableExams.map((exam) => {
                const maxReached = exam.maxAttempts > 0 && exam.attemptsUsed >= exam.maxAttempts;
                const hasPassed = exam.bestIsPassed === true;
                const canStart = !maxReached && !hasPassed;

                // If has in-progress attempt, show resume button
                const showResume = exam.hasInProgress && !maxReached;

                return (
                  <Card key={exam.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-5">
                      {/* Title & Type */}
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-gray-900 text-sm truncate">{exam.title}</h3>
                          {exam.programName && (
                            <p className="text-xs text-teal-600 mt-0.5">{exam.programName}</p>
                          )}
                        </div>
                        {getExamTypeBadge(exam.type)}
                      </div>

                      {/* Exam Details */}
                      <div className="flex flex-wrap gap-3 mb-4 text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-gray-400" />
                          {toPersianNumber(exam.durationMinutes)} دقیقه
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="w-3.5 h-3.5 text-gray-400" />
                          نمره قبولی: {toPersianNumber(exam.passingScore)}
                        </span>
                        <span className="flex items-center gap-1">
                          <FileCheck2 className="w-3.5 h-3.5 text-gray-400" />
                          {toPersianNumber(exam.questionCount || 0)} سؤال
                        </span>
                        {exam.maxAttempts > 0 && (
                          <span className="flex items-center gap-1">
                            {toPersianNumber(exam.attemptsUsed)} از {toPersianNumber(exam.maxAttempts)} تلاش
                          </span>
                        )}
                      </div>

                      {/* Best Result */}
                      {exam.bestScore !== null && exam.bestScore !== undefined && (
                        <div className="bg-gray-50 rounded-lg p-3 mb-4">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-500">بهترین نتیجه</span>
                            {hasPassed ? (
                              <Badge className="bg-green-100 text-green-700 border-0 text-xs gap-1">
                                <CheckCircle2 className="w-3 h-3" />
                                قبول
                              </Badge>
                            ) : (
                              <Badge className="bg-red-100 text-red-700 border-0 text-xs gap-1">
                                <XCircle className="w-3 h-3" />
                                مردود
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-1.5">
                            <span className="text-lg font-bold text-teal-600">{toPersianNumber(Math.round(exam.bestScore))}</span>
                            <span className="text-xs text-gray-400">درصد</span>
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex items-center gap-2">
                        {maxReached && !hasPassed ? (
                          <Button disabled className="flex-1 bg-gray-100 text-gray-400 gap-2">
                            <Ban className="w-4 h-4" />
                            حداکثر تلاش انجام شد
                          </Button>
                        ) : hasPassed && maxReached ? (
                          <Button disabled className="flex-1 bg-gray-100 text-gray-400 gap-2">
                            <CheckCircle2 className="w-4 h-4" />
                            قبول شده‌اید
                          </Button>
                        ) : (
                          <Button
                            onClick={() => handleStartExam(exam.id)}
                            className="flex-1 bg-teal-600 hover:bg-teal-700 text-white gap-2"
                          >
                            {showResume ? (
                              <>
                                <Loader2 className="w-4 h-4" />
                                ادامه آزمون
                              </>
                            ) : exam.attemptsUsed > 0 ? (
                              <>
                                <PlayCircle className="w-4 h-4" />
                                تلاش مجدد
                              </>
                            ) : (
                              <>
                                <PlayCircle className="w-4 h-4" />
                                شروع آزمون
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {/* Past Attempts Section */}
          {pastAttempts.length > 0 && (
            <>
              <Separator className="my-2" />
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-gray-100 border border-gray-200">
                  <History className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-gray-900">سوابق آزمون</h2>
                  <p className="text-xs text-gray-400">
                    {toPersianNumber(pastAttempts.length)} تلاش ثبت شده
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {pastAttempts.map((attempt) => (
                  <Card key={attempt.id} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-bold text-gray-900 text-sm truncate">{attempt.examTitle}</h3>
                            {getAttemptStatusBadge(attempt.status)}
                          </div>
                          <div className="flex flex-wrap gap-3 text-xs text-gray-500">
                            {attempt.programName && (
                              <span className="text-teal-600">{attempt.programName}</span>
                            )}
                            <span>{formatDate(attempt.startedAt)}</span>
                            {attempt.timeSpentSec && (
                              <span>زمان: {formatTimeSpent(attempt.timeSpentSec)}</span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {/* Score */}
                          {attempt.percentage !== null && attempt.percentage !== undefined ? (
                            <div className="text-center">
                              <p className={`text-lg font-bold ${attempt.isPassed ? 'text-emerald-600' : 'text-red-500'}`}>
                                {toPersianNumber(Math.round(attempt.percentage))}%
                              </p>
                              <p className="text-[10px] text-gray-400">
                                {toPersianNumber(attempt.score ?? 0)}/{toPersianNumber(attempt.maxScore ?? 0)}
                              </p>
                            </div>
                          ) : attempt.status === 'IN_PROGRESS' ? (
                            <Badge className="bg-teal-100 text-teal-700 border-0 text-xs gap-1">
                              <Loader2 className="w-3 h-3 animate-spin" />
                              در حال انجام
                            </Badge>
                          ) : null}

                          {/* View Results Button */}
                          {(attempt.status === 'SUBMITTED' || attempt.status === 'TIMED_OUT' || attempt.status === 'AUTO_SUBMITTED') && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleViewResults(attempt.id)}
                              className="shrink-0 border-teal-200 text-teal-600 hover:bg-teal-50 gap-1.5"
                            >
                              <FileCheck2 className="w-3.5 h-3.5" />
                              نتایج
                            </Button>
                          )}

                          {/* Resume In-Progress */}
                          {attempt.status === 'IN_PROGRESS' && (
                            <Button
                              size="sm"
                              onClick={() => handleStartExam(attempt.examId)}
                              className="shrink-0 bg-teal-600 hover:bg-teal-700 text-white gap-1.5"
                            >
                              <PlayCircle className="w-3.5 h-3.5" />
                              ادامه
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}