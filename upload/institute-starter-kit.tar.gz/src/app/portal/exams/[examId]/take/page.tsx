'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Progress } from '@/components/ui/progress';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  GraduationCap,
  Clock,
  AlertCircle,
  ArrowLeft,
  Send,
  ChevronLeft,
  ChevronRight,
  Circle,
  CheckCircle2,
  XCircle,
  FileCheck2,
  Shield,
  RotateCcw,
  Loader2,
} from 'lucide-react';
import { siteConfig } from '@/config/site';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface ExamInfo {
  id: string;
  title: string;
  description: string | null;
  type: string;
  duration: number;
  passingScore: number;
  maxAttempts: number;
  questionCount: number;
}

interface NormalizedOption {
  label: string;
  text: string;
}

interface Question {
  id: string;
  text: string;
  type: 'MULTIPLE_CHOICE' | 'TRUE_FALSE' | 'SHORT_ANSWER';
  options: NormalizedOption[] | string[] | { label?: string; text?: string; key?: string; id?: number; isCorrect?: boolean }[] | null;
  points: number;
  difficulty: string;
}

interface AttemptData {
  attemptId: string;
  exam: ExamInfo;
  questions: Question[];
  startedAt: string;
  duration: number;
  answers: Record<string, string>;
}

interface ResultData {
  attemptId: string;
  examTitle: string;
  score: number;
  maxScore: number;
  percentage: number;
  isPassed: boolean;
  timeSpent: number;
  questions: {
    id: string;
    text: string;
    type: string;
    options: string[] | null;
    selectedAnswer: string | null;
    correctAnswer: string;
    isCorrect: boolean;
    points: number;
    earnedPoints: number;
    explanation: string | null;
  }[];
}

type PageState = 'loading' | 'start' | 'exam' | 'submitting' | 'results' | 'error';

/* ─────────── Helpers ─────────── */

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${toPersianNumber(m.toString().padStart(2, '0'))}:${toPersianNumber(s.toString().padStart(2, '0'))}`;
}

function getDifficultyLabel(d: string) {
  switch (d) {
    case 'EASY': return 'آسان';
    case 'MEDIUM': return 'متوسط';
    case 'HARD': return 'سخت';
    default: return d;
  }
}

const PERSIAN_LETTERS = ['الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ'];

function normalizeOptions(options: Question['options']): NormalizedOption[] {
  if (!options || !Array.isArray(options)) return [];
  return options.map((opt, idx) => {
    if (typeof opt === 'object' && opt !== null && 'label' in opt && 'text' in opt && typeof opt.label === 'string' && typeof opt.text === 'string') {
      return { label: opt.label, text: opt.text };
    }
    if (typeof opt === 'object' && opt !== null && 'key' in opt && 'text' in opt) {
      return { label: String(opt.key), text: String(opt.text) };
    }
    if (typeof opt === 'object' && opt !== null && 'text' in opt) {
      return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: String(opt.text) };
    }
    if (typeof opt === 'string') {
      return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: opt };
    }
    return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: String(opt) };
  });
}

/* ─────────── Main Component ─────────── */

export default function ExamTakePage() {
  const router = useRouter();
  const params = useParams();
  const examId = params.examId as string;

  const [pageState, setPageState] = useState<PageState>('loading');
  const [examInfo, setExamInfo] = useState<ExamInfo | null>(null);
  const [attemptData, setAttemptData] = useState<AttemptData | null>(null);
  const [resultData, setResultData] = useState<ResultData | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [currentQ, setCurrentQ] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [error, setError] = useState('');
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [showLeaveDialog, setShowLeaveDialog] = useState(false);
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoSaveRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const answersRef = useRef(answers);
  const submitRef = useRef<((auto?: boolean) => Promise<void>) | null>(null);

  // Keep answersRef in sync
  useEffect(() => {
    answersRef.current = answers;
  }, [answers]);

  /* ──── Initial load: fetch exam info ──── */
  const fetchExamInfo = useCallback(async () => {
    const token = localStorage.getItem('portal_token');
    if (!token) {
      router.push('/portal/login');
      return;
    }

    try {
      setPageState('loading');
      const res = await fetch(`/api/exams/${examId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(errData.error || 'خطا در دریافت اطلاعات آزمون');
        setPageState('error');
        return;
      }

      const data = await res.json();
      setExamInfo(data.exam || data);
      setPageState('start');
    } catch {
      setError('خطا در ارتباط با سرور');
      setPageState('error');
    }
  }, [examId, router]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    fetchExamInfo();
  }, [fetchExamInfo]);

  /* ──── Start exam ──── */
  const startExam = async () => {
    const token = localStorage.getItem('portal_token');
    if (!token) {
      router.push('/portal/login');
      return;
    }

    try {
      setPageState('loading');
      const res = await fetch(`/api/exams/${examId}/start`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(errData.error || 'خطا در شروع آزمون');
        setPageState('error');
        return;
      }

      const data = await res.json();
      const attempt: AttemptData = {
        attemptId: data.attemptId || data.id,
        exam: data.exam || examInfo!,
        questions: data.questions || [],
        startedAt: data.startedAt || new Date().toISOString(),
        duration: data.duration || examInfo?.duration || 0,
        answers: data.answers || {},
      };

      setAttemptData(attempt);
      setQuestions(attempt.questions);
      setAnswers(attempt.answers);
      setCurrentQ(0);

      // Calculate time left from startedAt
      const startedTime = new Date(attempt.startedAt).getTime();
      const endTime = startedTime + attempt.duration * 60 * 1000;
      const remaining = Math.max(0, Math.floor((endTime - Date.now()) / 1000));
      setTimeLeft(remaining);

      setPageState('exam');
    } catch {
      setError('خطا در ارتباط با سرور');
      setPageState('error');
    }
  };

  /* ──── Timer ──── */
  useEffect(() => {
    if (pageState !== 'exam') return;

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          if (autoSaveRef.current) clearInterval(autoSaveRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [pageState]);

  /* ──── Auto-submit when timer hits 0 ──── */
  useEffect(() => {
    if (timeLeft === 0 && pageState === 'exam' && submitRef.current) {
      submitRef.current(true);
    }
  }, [timeLeft, pageState]);

  /* ──── Auto-save every 30 seconds ──── */
  useEffect(() => {
    if (pageState !== 'exam' || !attemptData) return;

    autoSaveRef.current = setInterval(async () => {
      const token = localStorage.getItem('portal_token');
      if (!token || !attemptData) return;

      try {
        setAutoSaveStatus('saving');
        await fetch(`/api/exams/attempts/${attemptData.attemptId}/save`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ answers: answersRef.current }),
        });
        setAutoSaveStatus('saved');
        setTimeout(() => setAutoSaveStatus('idle'), 2000);
      } catch {
        setAutoSaveStatus('idle');
      }
    }, 30000);

    return () => {
      if (autoSaveRef.current) clearInterval(autoSaveRef.current);
    };
  }, [pageState, attemptData]);

  /* ──── Warn before leaving ──── */
  useEffect(() => {
    if (pageState !== 'exam') return;

    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [pageState]);

  /* ──── Submit exam ──── */
  const handleSubmit = async (autoSubmit = false) => {
    if (!attemptData) return;

    if (!autoSubmit && !showSubmitDialog) {
      setShowSubmitDialog(true);
      return;
    }

    setShowSubmitDialog(false);

    // Clear timers
    if (timerRef.current) clearInterval(timerRef.current);
    if (autoSaveRef.current) clearInterval(autoSaveRef.current);

    const token = localStorage.getItem('portal_token');
    if (!token) {
      router.push('/portal/login');
      return;
    }

    try {
      setPageState('submitting');

      const res = await fetch(`/api/exams/attempts/${attemptData.attemptId}/submit`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ answers: answersRef.current }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        setError(errData.error || 'خطا در ارسال آزمون');
        setPageState('error');
        return;
      }

      const data = await res.json();
      setResultData(data.results || data);
      setPageState('results');
    } catch {
      setError('خطا در ارتباط با سرور');
      setPageState('error');
    }
  };

  // Keep submitRef in sync
  useEffect(() => {
    submitRef.current = handleSubmit;
  });

  /* ──── Answer handlers ──── */
  const setAnswer = (questionId: string, answer: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: answer }));
  };

  /* ──── Back to exams ──── */
  const handleBack = () => {
    if (pageState === 'exam') {
      setShowLeaveDialog(true);
    } else {
      router.push('/portal/exams');
    }
  };

  /* ──── Calculate progress ──── */
  const answeredCount = Object.keys(answers).filter((k) => answers[k] && answers[k].trim() !== '').length;
  const totalQuestions = questions.length;
  const progressPercent = totalQuestions > 0 ? (answeredCount / totalQuestions) * 100 : 0;
  const timerPercent = attemptData && attemptData.duration > 0
    ? (timeLeft / (attemptData.duration * 60)) * 100
    : 100;

  /* ══════════════════════════════════════ */
  /* ──── RENDER: Loading ──── */
  /* ══════════════════════════════════════ */
  if (pageState === 'loading') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4" dir="rtl">
        <div className="flex flex-col items-center gap-4">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-teal-600 border-t-transparent" />
          <p className="text-sm text-gray-500">در حال بارگذاری...</p>
        </div>
      </div>
    );
  }

  /* ══════════════════════════════════════ */
  /* ──── RENDER: Error ──── */
  /* ══════════════════════════════════════ */
  if (pageState === 'error') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4" dir="rtl">
        <Card className="border-0 shadow-lg max-w-md w-full">
          <CardContent className="p-8 text-center">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-lg font-bold text-gray-900 mb-2">خطا</h2>
            <p className="text-gray-500 text-sm mb-4">{error}</p>
            <div className="flex gap-3 justify-center">
              <Button variant="outline" onClick={fetchExamInfo}>تلاش مجدد</Button>
              <Button variant="ghost" onClick={() => router.push('/portal/exams')}>بازگشت</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  /* ══════════════════════════════════════ */
  /* ──── RENDER: Start Screen ──── */
  /* ══════════════════════════════════════ */
  if (pageState === 'start' && examInfo) {
    return (
      <div className="min-h-screen flex flex-col" dir="rtl">
        {/* Header */}
        <header className="bg-white border-b border-gray-100 px-4 py-3 sticky top-0 z-30 shadow-sm">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center shadow-md">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-gray-900 text-sm">آزمون</h1>
                <p className="text-xs text-gray-400">{siteConfig.nameShort}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={handleBack} className="text-gray-500 hover:text-teal-600 gap-1.5">
              <ChevronRight className="w-4 h-4" />
              بازگشت
            </Button>
          </div>
        </header>

        <main className="flex-1 max-w-4xl mx-auto w-full p-4 flex items-center justify-center">
          <Card className="border-0 shadow-lg w-full max-w-lg">
            <CardContent className="p-6 space-y-5">
              {/* Title */}
              <div className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-teal-500 flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <FileCheck2 className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-xl font-bold text-gray-900">{examInfo.title}</h2>
                {examInfo.description && (
                  <p className="text-sm text-gray-500 mt-2">{examInfo.description}</p>
                )}
              </div>

              {/* Exam details */}
              <div className="bg-gray-50 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500 flex items-center gap-1.5">
                    <Clock className="w-4 h-4" />
                    مدت آزمون
                  </span>
                  <span className="font-bold text-gray-900">{toPersianNumber(examInfo.duration)} دقیقه</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500 flex items-center gap-1.5">
                    <FileCheck2 className="w-4 h-4" />
                    تعداد سؤالات
                  </span>
                  <span className="font-bold text-gray-900">{toPersianNumber(examInfo.questionCount || 0)} سؤال</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500 flex items-center gap-1.5">
                    <Shield className="w-4 h-4" />
                    نمره قبولی
                  </span>
                  <span className="font-bold text-gray-900">{toPersianNumber(examInfo.passingScore)} از ۱۰۰</span>
                </div>
              </div>

              {/* Rules */}
              <div className="bg-amber-50 rounded-xl p-4 space-y-2">
                <h3 className="text-sm font-bold text-amber-800 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" />
                  نکات مهم
                </h3>
                <ul className="text-xs text-amber-700 space-y-1.5 pr-1">
                  <li className="flex items-start gap-2">
                    <span className="text-amber-400 mt-0.5">•</span>
                    پس از شروع، تایمر شمارش معکوس فعال می‌شود
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-amber-400 mt-0.5">•</span>
                    صفحه را رفرش نکنید — پاسخ‌ها هر ۳۰ ثانیه ذخیره می‌شوند
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-amber-400 mt-0.5">•</span>
                    هنگام اتمام زمان، آزمون خودکار ارسال خواهد شد
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-amber-400 mt-0.5">•</span>
                    می‌توانید بین سؤالات رفت و برگشت کنید
                  </li>
                </ul>
              </div>

              {/* Start button */}
              <Button
                onClick={startExam}
                className="w-full bg-teal-600 hover:bg-teal-700 text-white py-6 text-base font-bold gap-2"
              >
                شروع آزمون
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  /* ══════════════════════════════════════ */
  /* ──── RENDER: Submitting ──── */
  /* ══════════════════════════════════════ */
  if (pageState === 'submitting') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4" dir="rtl">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-teal-600" />
          <p className="text-sm text-gray-500">در حال ارسال پاسخ‌ها...</p>
        </div>
      </div>
    );
  }

  /* ══════════════════════════════════════ */
  /* ──── RENDER: Results ──── */
  /* ══════════════════════════════════════ */
  if (pageState === 'results' && resultData) {
    const pct = resultData.percentage || (resultData.maxScore > 0 ? Math.round((resultData.score / resultData.maxScore) * 100) : 0);

    return (
      <div className="min-h-screen flex flex-col" dir="rtl">
        <header className="bg-white border-b border-gray-100 px-4 py-3 sticky top-0 z-30 shadow-sm">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center shadow-md">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-gray-900 text-sm">نتیجه آزمون</h1>
                <p className="text-xs text-gray-400">{siteConfig.nameShort}</p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 max-w-4xl mx-auto w-full p-4 space-y-4">
          {/* Result Card */}
          <Card className={`border-0 shadow-lg ${resultData.isPassed ? 'bg-gradient-to-br from-green-50 to-emerald-50' : 'bg-gradient-to-br from-red-50 to-rose-50'}`}>
            <CardContent className="p-6 text-center">
              <div className={`w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center ${
                resultData.isPassed ? 'bg-green-100' : 'bg-red-100'
              }`}>
                {resultData.isPassed ? (
                  <CheckCircle2 className="w-10 h-10 text-green-600" />
                ) : (
                  <XCircle className="w-10 h-10 text-red-600" />
                )}
              </div>
              <h2 className="text-xl font-bold text-gray-900 mb-1">
                {resultData.isPassed ? 'تبریک! قبول شدید' : 'متأسفانه مردود شدید'}
              </h2>
              <p className="text-sm text-gray-500">{resultData.examTitle}</p>

              <div className="flex items-center justify-center gap-6 mt-4">
                <div>
                  <p className="text-3xl font-bold text-teal-600">{toPersianNumber(pct)}٪</p>
                  <p className="text-xs text-gray-500">درصد</p>
                </div>
                <div className="w-px h-12 bg-gray-200" />
                <div>
                  <p className="text-3xl font-bold text-gray-900">{toPersianNumber(resultData.score)}</p>
                  <p className="text-xs text-gray-500">از {toPersianNumber(resultData.maxScore)} نمره</p>
                </div>
              </div>

              <div className="mt-4">
                <Progress value={pct} className="h-3" />
              </div>
            </CardContent>
          </Card>

          {/* Question Review */}
          {resultData.questions && resultData.questions.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-bold text-gray-900">بررسی پاسخ‌ها</h3>
              {resultData.questions.map((q, idx) => (
                <Card key={q.id} className={`border-0 shadow-sm ${
                  q.isCorrect ? 'border-r-4 border-r-green-400' :
                  q.selectedAnswer ? 'border-r-4 border-r-red-400' :
                  'border-r-4 border-r-gray-300'
                }`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        q.isCorrect ? 'bg-green-100 text-green-700' :
                        q.selectedAnswer ? 'bg-red-100 text-red-700' :
                        'bg-gray-100 text-gray-500'
                      }`}>
                        {toPersianNumber(idx + 1)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900">{q.text}</p>

                        <div className="mt-2 space-y-1.5 text-xs">
                          {q.selectedAnswer ? (
                            <div className={`flex items-center gap-1.5 ${q.isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                              {q.isCorrect ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                              <span>پاسخ شما: {q.selectedAnswer}</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 text-gray-400">
                              <Circle className="w-3.5 h-3.5" />
                              <span>بدون پاسخ</span>
                            </div>
                          )}

                          {!q.isCorrect && (
                            <div className="flex items-center gap-1.5 text-green-700">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>پاسخ صحیح: {q.correctAnswer}</span>
                            </div>
                          )}

                          {q.explanation && (
                            <p className="text-gray-500 mt-2 bg-gray-50 rounded-lg p-2">
                              {q.explanation}
                            </p>
                          )}
                        </div>
                      </div>
                      <Badge variant="secondary" className={`text-xs border-0 ${
                        q.isCorrect ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                      }`}>
                        {toPersianNumber(q.earnedPoints)}/{toPersianNumber(q.points)}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Back button */}
          <div className="flex justify-center pt-4">
            <Button
              onClick={() => router.push('/portal/exams')}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              <ChevronRight className="w-4 h-4" />
              بازگشت به لیست آزمون‌ها
            </Button>
          </div>
        </main>
      </div>
    );
  }

  /* ══════════════════════════════════════ */
  /* ──── RENDER: Exam In Progress ──── */
  /* ══════════════════════════════════════ */
  if (pageState === 'exam' && questions.length > 0) {
    const currentQuestion = questions[currentQ];

    return (
      <div className="min-h-screen flex flex-col" dir="rtl">
        {/* ── Top Bar ── */}
        <header className="bg-white border-b border-gray-100 sticky top-0 z-30 shadow-sm">
          <div className="max-w-4xl mx-auto px-4 py-2.5">
            <div className="flex items-center justify-between">
              {/* Back button */}
              <Button variant="ghost" size="sm" onClick={handleBack} className="text-gray-500 hover:text-red-600 gap-1">
                <ChevronRight className="w-4 h-4" />
                <span className="text-xs">خروج</span>
              </Button>

              {/* Timer */}
              <div className={`flex items-center gap-2 px-4 py-1.5 rounded-full ${
                timeLeft < 60 ? 'bg-red-50 text-red-700' :
                timeLeft < 300 ? 'bg-amber-50 text-amber-700' :
                'bg-teal-50 text-teal-700'
              }`}>
                <Clock className="w-4 h-4" />
                <span className="font-bold text-sm font-mono">{formatTime(timeLeft)}</span>
              </div>

              {/* Auto-save status */}
              <div className="flex items-center gap-1.5 text-xs text-gray-400">
                {autoSaveStatus === 'saving' && (
                  <>
                    <Loader2 className="w-3 h-3 animate-spin" />
                    <span>ذخیره...</span>
                  </>
                )}
                {autoSaveStatus === 'saved' && (
                  <>
                    <CheckCircle2 className="w-3 h-3 text-green-500" />
                    <span className="text-green-600">ذخیره شد</span>
                  </>
                )}
                {autoSaveStatus === 'idle' && (
                  <span>{toPersianNumber(answeredCount)}/{toPersianNumber(totalQuestions)} پاسخ</span>
                )}
              </div>
            </div>

            {/* Progress bar */}
            <div className="mt-2">
              <Progress value={progressPercent} className="h-1.5" />
            </div>
          </div>
        </header>

        {/* ── Question Content ── */}
        <main className="flex-1 max-w-4xl mx-auto w-full p-4">
          <div className="space-y-4">
            {/* Question Card */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-5 space-y-5">
                {/* Question header */}
                <div className="flex items-start gap-3 pb-4 border-b border-gray-100">
                  <div className="shrink-0 w-10 h-10 rounded-xl bg-teal-50 flex items-center justify-center">
                    <span className="text-sm font-bold text-teal-600">{toPersianNumber(currentQ + 1)}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-base font-medium text-gray-900 leading-7">{currentQuestion.text}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="secondary" className="text-xs border-0 bg-gray-100 text-gray-500">
                        {toPersianNumber(currentQuestion.points)} نمره
                      </Badge>
                      <Badge variant="secondary" className={`text-xs border-0 ${
                        currentQuestion.difficulty === 'EASY' ? 'bg-green-50 text-green-600' :
                        currentQuestion.difficulty === 'MEDIUM' ? 'bg-amber-50 text-amber-600' :
                        'bg-red-50 text-red-600'
                      }`}>
                        {getDifficultyLabel(currentQuestion.difficulty)}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Answer area */}
                <div className="pr-13 space-y-3">
                  {/* MULTIPLE_CHOICE */}
                  {currentQuestion.type === 'MULTIPLE_CHOICE' && currentQuestion.options && (() => {
                    const normalized = normalizeOptions(currentQuestion.options);
                    if (normalized.length === 0) return null;
                    return (
                      <RadioGroup
                        value={answers[currentQuestion.id] || ''}
                        onValueChange={(val) => setAnswer(currentQuestion.id, val)}
                        className="space-y-3"
                      >
                        {normalized.map((opt, idx) => (
                          <label
                            key={`${currentQuestion.id}-opt-${idx}`}
                            className={`flex items-center gap-3 p-3.5 rounded-xl border cursor-pointer transition-all block ${
                              answers[currentQuestion.id] === opt.label
                                ? 'border-teal-300 bg-teal-50'
                                : 'border-gray-100 bg-white hover:border-gray-200 hover:bg-gray-50'
                            }`}
                          >
                            <RadioGroupItem value={opt.label} id={`opt-${idx}`} />
                            <Label htmlFor={`opt-${idx}`} className="flex-1 cursor-pointer text-sm leading-7">
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-md bg-gray-100 text-xs font-bold text-gray-600 ml-2 shrink-0">
                                {PERSIAN_LETTERS[idx] || toPersianNumber(idx + 1)}
                              </span>
                              {opt.text}
                            </Label>
                          </label>
                        ))}
                      </RadioGroup>
                    );
                  })()}

                  {/* TRUE_FALSE */}
                  {currentQuestion.type === 'TRUE_FALSE' && (
                    <RadioGroup
                      value={answers[currentQuestion.id] || ''}
                      onValueChange={(val) => setAnswer(currentQuestion.id, val)}
                      className="flex gap-3"
                    >
                      <label className={`flex-1 flex items-center justify-center gap-2 p-4 rounded-xl border cursor-pointer transition-all ${
                        answers[currentQuestion.id] === 'true'
                          ? 'border-green-300 bg-green-50'
                          : 'border-gray-100 bg-white hover:border-gray-200'
                      }`}>
                        <RadioGroupItem value="true" id="tf-true" />
                        <Label htmlFor="tf-true" className="cursor-pointer text-sm font-medium">
                          <CheckCircle2 className="w-4 h-4 text-green-600 ml-1 inline" />
                          صحیح
                        </Label>
                      </label>
                      <label className={`flex-1 flex items-center justify-center gap-2 p-4 rounded-xl border cursor-pointer transition-all ${
                        answers[currentQuestion.id] === 'false'
                          ? 'border-red-300 bg-red-50'
                          : 'border-gray-100 bg-white hover:border-gray-200'
                      }`}>
                        <RadioGroupItem value="false" id="tf-false" />
                        <Label htmlFor="tf-false" className="cursor-pointer text-sm font-medium">
                          <XCircle className="w-4 h-4 text-red-600 ml-1 inline" />
                          غلط
                        </Label>
                      </label>
                    </RadioGroup>
                  )}

                  {/* SHORT_ANSWER */}
                  {currentQuestion.type === 'SHORT_ANSWER' && (
                    <div className="space-y-1.5">
                      <Label className="text-sm text-gray-500">پاسخ خود را وارد کنید:</Label>
                      <Input
                        value={answers[currentQuestion.id] || ''}
                        onChange={(e) => setAnswer(currentQuestion.id, e.target.value)}
                        placeholder="پاسخ..."
                        className="text-base"
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex items-center justify-between gap-3">
              <Button
                variant="outline"
                onClick={() => setCurrentQ(Math.max(0, currentQ - 1))}
                disabled={currentQ === 0}
                className="gap-1.5"
              >
                <ChevronRight className="w-4 h-4" />
                قبلی
              </Button>

              {/* Question dots */}
              <div className="flex-1 flex items-center justify-center gap-1 flex-wrap max-h-16 overflow-y-auto">
                {questions.map((q, idx) => {
                  const isAnswered = answers[q.id] && answers[q.id].trim() !== '';
                  const isCurrent = idx === currentQ;
                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQ(idx)}
                      className={`w-7 h-7 rounded-lg text-xs font-bold flex items-center justify-center transition-all ${
                        isCurrent
                          ? 'bg-teal-600 text-white shadow-md'
                          : isAnswered
                          ? 'bg-teal-100 text-teal-700 hover:bg-teal-200'
                          : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                      }`}
                    >
                      {toPersianNumber(idx + 1)}
                    </button>
                  );
                })}
              </div>

              {currentQ < totalQuestions - 1 ? (
                <Button
                  onClick={() => setCurrentQ(Math.min(totalQuestions - 1, currentQ + 1))}
                  className="bg-teal-600 hover:bg-teal-700 text-white gap-1.5"
                >
                  بعدی
                  <ChevronLeft className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  onClick={() => handleSubmit()}
                  className="bg-green-600 hover:bg-green-700 text-white gap-1.5"
                >
                  <Send className="w-4 h-4" />
                  ارسال
                </Button>
              )}
            </div>
          </div>
        </main>

        {/* ── Bottom Timer Bar ── */}
        <div className="bg-white border-t border-gray-100 px-4 py-2">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span>
                سؤال {toPersianNumber(currentQ + 1)} از {toPersianNumber(totalQuestions)}
              </span>
              <button
                onClick={() => handleSubmit()}
                className="flex items-center gap-1.5 text-green-600 hover:text-green-700 font-medium"
              >
                <Send className="w-3.5 h-3.5" />
                ارسال آزمون
              </button>
            </div>
            <Progress value={timerPercent} className={`h-1 mt-1.5 ${timeLeft < 60 ? '[&>div]:bg-red-500' : timeLeft < 300 ? '[&>div]:bg-amber-500' : ''}`} />
          </div>
        </div>

        {/* ── Submit Confirmation Dialog ── */}
        <AlertDialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
          <AlertDialogContent dir="rtl">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-right">ارسال آزمون</AlertDialogTitle>
              <AlertDialogDescription className="text-right">
                آیا مطمئن هستید که می‌خواهید آزمون را ارسال کنید؟
                {answeredCount < totalQuestions && (
                  <span className="block mt-2 text-amber-600">
                    توجه: شما {toPersianNumber(totalQuestions - answeredCount)} سؤال بدون پاسخ دارید!
                  </span>
                )}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="gap-2">
              <AlertDialogCancel>انصراف</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => handleSubmit(true)}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                ارسال نهایی
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* ── Leave Confirmation Dialog ── */}
        <AlertDialog open={showLeaveDialog} onOpenChange={setShowLeaveDialog}>
          <AlertDialogContent dir="rtl">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-right">خروج از آزمون</AlertDialogTitle>
              <AlertDialogDescription className="text-right">
                آیا مطمئن هستید؟ اگر الان خارج شوید، پیشرفت شما از بین می‌رود و آزمون به صورت خودکار ارسال نخواهد شد.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="gap-2">
              <AlertDialogCancel>ماندن</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  if (timerRef.current) clearInterval(timerRef.current);
                  if (autoSaveRef.current) clearInterval(autoSaveRef.current);
                  router.push('/portal/exams');
                }}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                خروج
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    );
  }

  // Fallback
  return null;
}
