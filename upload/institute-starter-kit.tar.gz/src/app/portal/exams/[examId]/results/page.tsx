'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter, useParams, useSearchParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import {
  GraduationCap,
  LogOut,
  CheckCircle2,
  XCircle,
  Circle,
  AlertCircle,
  ChevronRight,
  Clock,
  ArrowLeft,
  Award,
} from 'lucide-react';
import { siteConfig } from '@/config/site';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface ResultQuestion {
  id: string;
  text: string;
  type: string;
  options: string[] | null;
  selectedAnswer: string | null;
  correctAnswer: string;
  isCorrect: boolean;
  points: number;
  earnedPoints: number;
  explanation: string | null;
}

interface ResultData {
  attemptId: string;
  examTitle: string;
  score: number;
  maxScore: number;
  percentage: number;
  isPassed: boolean;
  timeSpent: number;
  startedAt: string;
  submittedAt: string;
  questions: ResultQuestion[];
}

/* ─────────── Helpers ─────────── */

function formatTimeSpent(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${toPersianNumber(h)} ساعت ${toPersianNumber(m)} دقیقه`;
  if (m > 0) return `${toPersianNumber(m)} دقیقه ${toPersianNumber(s)} ثانیه`;
  return `${toPersianNumber(s)} ثانیه`;
}

function formatPersianDate(dateStr: string | null | undefined) {
  if (!dateStr) return '-';
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit',
    }).format(new Date(dateStr));
  } catch {
    return '-';
  }
}

/* ─────────── Main Component ─────────── */

export default function ExamResultsPage() {
  const router = useRouter();
  const params = useParams();
  const searchParams = useSearchParams();
  const examId = params.examId as string;
  const attemptId = searchParams.get('attemptId');

  const [result, setResult] = useState<ResultData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchResults = useCallback(async () => {
    const token = localStorage.getItem('portal_token');
    if (!token) {
      router.push('/portal/login');
      return;
    }

    if (!attemptId) {
      setError('شناسه تلاش مشخص نیست');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const res = await fetch(`/api/exams/attempts/${attemptId}/results`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) {
        if (res.status === 401) {
          localStorage.removeItem('portal_token');
          localStorage.removeItem('portal_user');
          router.push('/portal/login');
          return;
        }
        const errData = await res.json().catch(() => ({}));
        setError(errData.error || 'خطا در دریافت نتایج');
        return;
      }

      const data = await res.json();
      setResult(data.results || data);
      setError('');
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  }, [attemptId, router]);

  useEffect(() => {
    fetchResults();
  }, [fetchResults]);

  const handleLogout = () => {
    localStorage.removeItem('portal_token');
    localStorage.removeItem('portal_user');
    router.push('/portal/login');
  };

  /* ──── Loading ──── */
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" dir="rtl">
        <header className="bg-white border-b border-gray-100 px-4 py-3 sticky top-0 z-30 shadow-sm">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Skeleton className="w-10 h-10 rounded-xl" />
              <div className="space-y-2">
                <Skeleton className="h-5 w-24" />
                <Skeleton className="h-3 w-20" />
              </div>
            </div>
            <Skeleton className="h-9 w-20 rounded-lg" />
          </div>
        </header>
        <div className="max-w-4xl mx-auto p-4 space-y-4">
          <Skeleton className="h-64 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
        </div>
      </div>
    );
  }

  /* ──── Error ──── */
  if (error || !result) {
    return (
      <div className="min-h-screen flex flex-col" dir="rtl">
        <header className="bg-white border-b border-gray-100 px-4 py-3 sticky top-0 z-30 shadow-sm">
          <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center shadow-md">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-gray-900 text-sm">نتایج آزمون</h1>
                <p className="text-xs text-gray-400">{siteConfig.nameShort}</p>
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={() => router.push('/portal/exams')} className="text-gray-500 gap-1.5">
              <ArrowLeft className="w-4 h-4" />
              بازگشت
            </Button>
          </div>
        </header>
        <div className="flex-1 flex items-center justify-center p-4">
          <Card className="border-0 shadow-lg max-w-md w-full">
            <CardContent className="p-8 text-center">
              <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
              <h2 className="text-lg font-bold text-gray-900 mb-2">خطا</h2>
              <p className="text-gray-500 text-sm mb-4">{error || 'نتایج یافت نشد'}</p>
              <div className="flex gap-3 justify-center">
                <Button variant="outline" onClick={fetchResults}>تلاش مجدد</Button>
                <Button variant="ghost" onClick={() => router.push('/portal/exams')}>بازگشت</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const pct = result.percentage || (result.maxScore > 0 ? Math.round((result.score / result.maxScore) * 100) : 0);
  const correctCount = result.questions?.filter(q => q.isCorrect).length || 0;
  const unansweredCount = result.questions?.filter(q => !q.selectedAnswer).length || 0;

  /* ──── Main Render ──── */
  return (
    <div className="min-h-screen flex flex-col" dir="rtl">
      {/* Header */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-30 shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center shadow-md">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-gray-900 text-sm">نتایج آزمون</h1>
              <p className="text-xs text-gray-400">{siteConfig.nameShort}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => router.push('/portal/exams')} className="text-gray-500 hover:text-teal-600 gap-1.5">
              <ChevronRight className="w-4 h-4" />
              <span className="hidden sm:inline text-xs">لیست آزمون‌ها</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-gray-500 hover:text-red-600 gap-1.5">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 max-w-4xl mx-auto w-full p-4 space-y-4">
        {/* Result Header Card */}
        <Card className={`border-0 shadow-lg overflow-hidden ${
          result.isPassed
            ? 'bg-gradient-to-br from-green-50 to-emerald-50'
            : 'bg-gradient-to-br from-red-50 to-rose-50'
        }`}>
          <CardContent className="p-6">
            <div className="text-center">
              <div className={`w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center ${
                result.isPassed ? 'bg-green-100' : 'bg-red-100'
              }`}>
                {result.isPassed ? (
                  <Award className="w-12 h-12 text-green-600" />
                ) : (
                  <XCircle className="w-12 h-12 text-red-500" />
                )}
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-1">
                {result.isPassed ? 'تبریک! قبول شدید 🎉' : 'متأسفانه مردود شدید'}
              </h2>
              <p className="text-sm text-gray-500">{result.examTitle}</p>

              <div className="flex items-center justify-center gap-8 mt-6">
                <div>
                  <p className="text-4xl font-bold text-teal-600">{toPersianNumber(pct)}٪</p>
                  <p className="text-xs text-gray-500 mt-1">درصد نمره</p>
                </div>
                <div className="w-px h-16 bg-gray-200" />
                <div>
                  <p className="text-4xl font-bold text-gray-900">{toPersianNumber(result.score)}</p>
                  <p className="text-xs text-gray-500 mt-1">از {toPersianNumber(result.maxScore)} نمره</p>
                </div>
              </div>

              <div className="mt-4 max-w-xs mx-auto">
                <Progress value={pct} className="h-3" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 text-center">
              <CheckCircle2 className="w-5 h-5 text-green-600 mx-auto mb-1" />
              <p className="text-xl font-bold text-green-700">{toPersianNumber(correctCount)}</p>
              <p className="text-xs text-gray-500">صحیح</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 text-center">
              <XCircle className="w-5 h-5 text-red-500 mx-auto mb-1" />
              <p className="text-xl font-bold text-red-600">{toPersianNumber((result.questions?.length || 0) - correctCount - unansweredCount)}</p>
              <p className="text-xs text-gray-500">غلط</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 text-center">
              <Circle className="w-5 h-5 text-gray-400 mx-auto mb-1" />
              <p className="text-xl font-bold text-gray-500">{toPersianNumber(unansweredCount)}</p>
              <p className="text-xs text-gray-500">بدون پاسخ</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4 text-center">
              <Clock className="w-5 h-5 text-teal-600 mx-auto mb-1" />
              <p className="text-sm font-bold text-teal-700">
                {result.timeSpent ? formatTimeSpent(result.timeSpent) : '-'}
              </p>
              <p className="text-xs text-gray-500">زمان صرف‌شده</p>
            </CardContent>
          </Card>
        </div>

        {/* Date Info */}
        <Card className="border-0 shadow-sm bg-gray-50">
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
              <div className="flex items-center gap-2 text-gray-500">
                <Clock className="w-4 h-4" />
                شروع: {formatPersianDate(result.startedAt)}
              </div>
              <div className="flex items-center gap-2 text-gray-500">
                <CheckCircle2 className="w-4 h-4" />
                ارسال: {formatPersianDate(result.submittedAt)}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Question Review */}
        {result.questions && result.questions.length > 0 && (
          <div className="space-y-3">
            <h3 className="font-bold text-gray-900 text-base">بررسی پاسخ‌ها</h3>
            {result.questions.map((q, idx) => (
              <Card
                key={q.id}
                className={`border-0 shadow-sm overflow-hidden ${
                  q.isCorrect
                    ? 'border-r-4 border-r-green-400'
                    : q.selectedAnswer
                    ? 'border-r-4 border-r-red-400'
                    : 'border-r-4 border-r-gray-300'
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    {/* Question number */}
                    <div className={`shrink-0 w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold ${
                      q.isCorrect ? 'bg-green-100 text-green-700' :
                      q.selectedAnswer ? 'bg-red-100 text-red-700' :
                      'bg-gray-100 text-gray-500'
                    }`}>
                      {toPersianNumber(idx + 1)}
                    </div>

                    <div className="flex-1 min-w-0">
                      {/* Question text */}
                      <p className="text-sm font-medium text-gray-900 leading-6">{q.text}</p>

                      {/* Type badge */}
                      <div className="flex items-center gap-2 mt-1.5 mb-3">
                        <Badge variant="secondary" className="text-xs border-0 bg-gray-100 text-gray-500">
                          {q.type === 'MULTIPLE_CHOICE' ? 'چندگزینه‌ای' :
                           q.type === 'TRUE_FALSE' ? 'صحیح/غلط' : 'تشریحی'}
                        </Badge>
                        <Badge variant="secondary" className={`text-xs border-0 ${
                          q.isCorrect ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                        }`}>
                          {toPersianNumber(q.earnedPoints)}/{toPersianNumber(q.points)} نمره
                        </Badge>
                      </div>

                      {/* Selected answer */}
                      {q.selectedAnswer ? (
                        <div className={`flex items-center gap-1.5 text-sm ${
                          q.isCorrect ? 'text-green-700' : 'text-red-700'
                        }`}>
                          {q.isCorrect ? (
                            <CheckCircle2 className="w-4 h-4 shrink-0" />
                          ) : (
                            <XCircle className="w-4 h-4 shrink-0" />
                          )}
                          <span>پاسخ شما: <strong>{q.selectedAnswer}</strong></span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-sm text-gray-400">
                          <Circle className="w-4 h-4 shrink-0" />
                          <span>بدون پاسخ</span>
                        </div>
                      )}

                      {/* Correct answer (if wrong) */}
                      {!q.isCorrect && (
                        <div className="flex items-center gap-1.5 text-sm text-green-700 mt-1.5">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>پاسخ صحیح: <strong>{q.correctAnswer}</strong></span>
                        </div>
                      )}

                      {/* Explanation */}
                      {q.explanation && (
                        <div className="mt-3 bg-blue-50 rounded-lg p-3 text-sm text-blue-800">
                          <strong>توضیح:</strong> {q.explanation}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Back button */}
        <div className="flex justify-center pt-4 pb-6">
          <Button
            onClick={() => router.push('/portal/exams')}
            className="bg-teal-600 hover:bg-teal-700 text-white gap-2 px-8"
          >
            <ChevronRight className="w-4 h-4" />
            بازگشت به لیست آزمون‌ها
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 mt-auto">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <p className="text-xs text-gray-400">{siteConfig.nameShort} — {siteConfig.address.city}</p>
          <Button variant="ghost" size="sm" onClick={handleLogout} className="text-xs text-gray-400 hover:text-red-600 gap-1">
            <LogOut className="w-3 h-3" />
            خروج
          </Button>
        </div>
      </footer>
    </div>
  );
}
