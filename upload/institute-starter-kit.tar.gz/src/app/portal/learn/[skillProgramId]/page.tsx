'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { usePortalAuth } from '@/app/portal/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toPersianNumber } from '@/lib/persian';
import {
  BookOpen,
  Video,
  FileText,
  HelpCircle,
  Monitor,
  CheckCircle2,
  Circle,
  Play,
  ChevronLeft,
  ChevronRight,
  Clock,
  Download,
  ArrowLeft,
  Loader2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────────────────

interface LessonItem {
  id: string;
  title: string;
  description: string | null;
  type: string;
  order: number;
  isFree: boolean;
  estimatedMinutes: number;
  videoDuration: number | null;
  createdAt: string;
  progress: {
    status: string;
    progressPercent: number;
    timeSpent: number;
    lastPosition: number;
    completedAt: string | null;
    updatedAt: string | null;
  };
}

interface LessonsData {
  skillProgramId: string;
  enrollmentId: string;
  enrollmentStatus: string;
  lessons: LessonItem[];
}

interface LessonDetail {
  id: string;
  title: string;
  description: string | null;
  type: string;
  order: number;
  isFree: boolean;
  isPublished: boolean;
  estimatedMinutes: number;
  videoDuration: number | null;
  videoUrl: string | null;
  content: string | null;
  documentUrl: string | null;
  program: {
    id: string;
    name: string;
    instructorName: string | null;
    level: string | null;
  };
  progress: {
    status: string;
    progressPercent: number;
    timeSpent: number;
    lastPosition: number;
    completedAt: string | null;
    updatedAt: string | null;
  };
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getLessonTypeIcon(type: string) {
  switch (type) {
    case 'VIDEO':
      return Video;
    case 'TEXT':
      return FileText;
    case 'QUIZ':
      return HelpCircle;
    case 'DOCUMENT':
      return FileText;
    case 'LIVE_SESSION':
      return Monitor;
    default:
      return BookOpen;
  }
}

function getLessonTypeLabel(type: string): string {
  switch (type) {
    case 'VIDEO':
      return 'ویدیو';
    case 'TEXT':
      return 'متن';
    case 'QUIZ':
      return 'آزمون';
    case 'DOCUMENT':
      return 'فایل';
    case 'LIVE_SESSION':
      return 'جلسه زنده';
    default:
      return 'درس';
  }
}

function getLessonTypeBadgeVariant(type: string): 'default' | 'secondary' | 'outline' | 'destructive' {
  switch (type) {
    case 'VIDEO':
      return 'default';
    case 'QUIZ':
      return 'destructive';
    case 'LIVE_SESSION':
      return 'secondary';
    default:
      return 'outline';
  }
}

function isYouTubeUrl(url: string): boolean {
  return /(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)/.test(url);
}

function isAparatUrl(url: string): boolean {
  return /aparat\.com/.test(url);
}

function getYouTubeEmbedUrl(url: string): string {
  const match = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  if (match) return `https://www.youtube.com/embed/${match[1]}`;
  return url;
}

function getAparatEmbedUrl(url: string): string {
  const match = url.match(/aparat\.com\/v\/([a-zA-Z0-9]+)/);
  if (match) return `https://www.aparat.com/video/video/embed/videohash/${match[1]}/vt/frame`;
  return url;
}

function formatDuration(seconds: number | null): string {
  if (!seconds) return '—';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  if (mins < 60) return `${toPersianNumber(mins)}:${toPersianNumber(secs.toString().padStart(2, '0'))}`;
  const hrs = Math.floor(mins / 60);
  const remMins = mins % 60;
  return `${toPersianNumber(hrs)}:${toPersianNumber(remMins.toString().padStart(2, '0'))}:${toPersianNumber(secs.toString().padStart(2, '0'))}`;
}

function formatTimeSpent(seconds: number): string {
  if (seconds < 60) return `${toPersianNumber(Math.round(seconds))} ثانیه`;
  const mins = Math.floor(seconds / 60);
  if (mins < 60) return `${toPersianNumber(mins)} دقیقه`;
  const hrs = Math.floor(mins / 60);
  const remMins = mins % 60;
  return `${toPersianNumber(hrs)} ساعت و ${toPersianNumber(remMins)} دقیقه`;
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function LearnPage() {
  const params = useParams();
  const router = useRouter();
  const { token } = usePortalAuth();
  const skillProgramId = params.skillProgramId as string;

  // ─── State ────────────────────────────────────────────────────────────
  const [lessonsData, setLessonsData] = useState<LessonsData | null>(null);
  const [currentLessonDetail, setCurrentLessonDetail] = useState<LessonDetail | null>(null);
  const [currentLessonId, setCurrentLessonId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingLesson, setIsLoadingLesson] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSavingProgress, setIsSavingProgress] = useState(false);

  const autoSaveIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timeSpentRef = useRef(0);

  // ─── Fetch Lessons List ───────────────────────────────────────────────
  const fetchLessons = useCallback(async () => {
    if (!token || !skillProgramId) return;

    try {
      setIsLoading(true);
      setError(null);
      const res = await fetch(
        `/api/portal/lms/lessons?skillProgramId=${skillProgramId}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'خطا در دریافت دروس');
        return;
      }

      setLessonsData(data.data);

      // Auto-select the first incomplete lesson, or the first lesson
      if (data.data?.lessons?.length > 0) {
        const firstIncomplete = data.data.lessons.find(
          (l: LessonItem) => l.progress.status !== 'COMPLETED'
        );
        const firstLesson = firstIncomplete || data.data.lessons[0];
        setCurrentLessonId(firstLesson.id);
      }
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setIsLoading(false);
    }
  }, [token, skillProgramId]);

  useEffect(() => {
    fetchLessons();
  }, [fetchLessons]);

  // ─── Fetch Lesson Content ─────────────────────────────────────────────
  const fetchLessonContent = useCallback(
    async (lessonId: string) => {
      if (!token) return;

      try {
        setIsLoadingLesson(true);
        const res = await fetch(`/api/portal/lms/lesson/${lessonId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();

        if (!res.ok) {
          console.error('Error loading lesson:', data.error);
          return;
        }

        setCurrentLessonDetail(data.data);
        timeSpentRef.current = 0;
      } catch {
        console.error('Error loading lesson content');
      } finally {
        setIsLoadingLesson(false);
      }
    },
    [token]
  );

  useEffect(() => {
    if (currentLessonId) {
      fetchLessonContent(currentLessonId);
    }
  }, [currentLessonId, fetchLessonContent]);

  // ─── Auto-save Progress for Videos ────────────────────────────────────
  useEffect(() => {
    // Clear previous interval
    if (autoSaveIntervalRef.current) {
      clearInterval(autoSaveIntervalRef.current);
      autoSaveIntervalRef.current = null;
    }

    // Only auto-save for video lessons that are in progress
    if (
      currentLessonDetail?.type === 'VIDEO' &&
      currentLessonDetail?.progress?.status !== 'COMPLETED'
    ) {
      autoSaveIntervalRef.current = setInterval(() => {
        timeSpentRef.current += 30;
        saveProgress({
          lessonId: currentLessonDetail.id,
          status: 'IN_PROGRESS',
          progressPercent: Math.min(
            95,
            currentLessonDetail.progress.progressPercent || 0
          ),
          timeSpent: (currentLessonDetail.progress.timeSpent || 0) + 30,
        });
      }, 30000);
    }

    return () => {
      if (autoSaveIntervalRef.current) {
        clearInterval(autoSaveIntervalRef.current);
      }
    };
  }, [currentLessonDetail?.id, currentLessonDetail?.type, currentLessonDetail?.progress?.status]);

  // ─── Save Progress ────────────────────────────────────────────────────
  const saveProgress = useCallback(
    async (body: {
      lessonId: string;
      status?: string;
      progressPercent?: number;
      timeSpent?: number;
      lastPosition?: number;
    }) => {
      if (!token) return;

      try {
        setIsSavingProgress(true);
        await fetch('/api/portal/lms/progress', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(body),
        });
      } catch {
        // Silently fail for auto-save
      } finally {
        setIsSavingProgress(false);
      }
    },
    [token]
  );

  // ─── Mark Lesson Complete ─────────────────────────────────────────────
  const markComplete = useCallback(async () => {
    if (!token || !currentLessonId) return;

    try {
      setIsSavingProgress(true);
      const res = await fetch('/api/portal/lms/progress', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          lessonId: currentLessonId,
          status: 'COMPLETED',
          progressPercent: 100,
          timeSpent:
            (currentLessonDetail?.progress?.timeSpent || 0) +
            timeSpentRef.current,
        }),
      });
      const data = await res.json();

      if (res.ok) {
        // Update local state
        setCurrentLessonDetail((prev) =>
          prev
            ? {
                ...prev,
                progress: {
                  ...prev.progress,
                  status: 'COMPLETED',
                  progressPercent: 100,
                },
              }
            : prev
        );

        // Update lesson list
        setLessonsData((prev) =>
          prev
            ? {
                ...prev,
                lessons: prev.lessons.map((l) =>
                  l.id === currentLessonId
                    ? {
                        ...l,
                        progress: { ...l.progress, status: 'COMPLETED', progressPercent: 100 },
                      }
                    : l
                ),
              }
            : prev
        );

        // Clear auto-save timer
        if (autoSaveIntervalRef.current) {
          clearInterval(autoSaveIntervalRef.current);
          autoSaveIntervalRef.current = null;
        }
      }
    } catch {
      console.error('Error marking lesson complete');
    } finally {
      setIsSavingProgress(false);
    }
  }, [token, currentLessonId, currentLessonDetail?.progress?.timeSpent]);

  // ─── Navigate to Next/Prev Lesson ─────────────────────────────────────
  const goToLesson = useCallback(
    (lessonId: string) => {
      setCurrentLessonId(lessonId);
    },
    []
  );

  const goToNextLesson = useCallback(() => {
    if (!lessonsData || !currentLessonId) return;
    const idx = lessonsData.lessons.findIndex((l) => l.id === currentLessonId);
    if (idx < lessonsData.lessons.length - 1) {
      goToLesson(lessonsData.lessons[idx + 1].id);
    }
  }, [lessonsData, currentLessonId, goToLesson]);

  const goToPrevLesson = useCallback(() => {
    if (!lessonsData || !currentLessonId) return;
    const idx = lessonsData.lessons.findIndex((l) => l.id === currentLessonId);
    if (idx > 0) {
      goToLesson(lessonsData.lessons[idx - 1].id);
    }
  }, [lessonsData, currentLessonId, goToLesson]);

  // ─── Computed ─────────────────────────────────────────────────────────
  const currentLessonIndex = lessonsData?.lessons.findIndex(
    (l) => l.id === currentLessonId
  );
  const hasPrev = (currentLessonIndex ?? -1) > 0;
  const hasNext =
    (currentLessonIndex ?? -1) >= 0 &&
    (currentLessonIndex ?? -1) < (lessonsData?.lessons.length ?? 0) - 1;

  const completedCount =
    lessonsData?.lessons.filter((l) => l.progress.status === 'COMPLETED').length ?? 0;
  const totalLessons = lessonsData?.lessons.length ?? 0;
  const overallProgress =
    totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0;

  const programName = currentLessonDetail?.program?.name || lessonsData?.skillProgramId || '';
  const instructorName = currentLessonDetail?.program?.instructorName || null;

  // ─── Loading State ────────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Skeleton className="h-9 w-9 rounded-lg" />
          <div>
            <Skeleton className="h-6 w-48 mb-1" />
            <Skeleton className="h-4 w-32" />
          </div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Skeleton className="h-[600px] rounded-xl lg:col-span-1" />
          <Skeleton className="h-[600px] rounded-xl lg:col-span-2" />
        </div>
      </div>
    );
  }

  // ─── Error State ──────────────────────────────────────────────────────
  if (error || !lessonsData) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center mb-4">
          <AlertCircle className="h-8 w-8 text-red-500" />
        </div>
        <p className="text-gray-700 font-medium mb-2">
          {error || 'خطا در بارگذاری دروس'}
        </p>
        <div className="flex gap-2 mt-4">
          <Button onClick={fetchLessons} variant="outline">
            تلاش مجدد
          </Button>
          <Button variant="ghost" onClick={() => router.push('/portal/my-courses')}>
            بازگشت به دوره‌ها
          </Button>
        </div>
      </div>
    );
  }

  // ─── No Lessons ───────────────────────────────────────────────────────
  if (lessonsData.lessons.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
          <BookOpen className="h-8 w-8 text-gray-400" />
        </div>
        <p className="text-gray-700 font-medium mb-2">هنوز درسی منتشر نشده است</p>
        <p className="text-gray-500 text-sm mb-4">
          محتوای آموزشی این دوره در حال آماده‌سازی است.
        </p>
        <Button variant="outline" onClick={() => router.push('/portal/my-courses')}>
          بازگشت به دوره‌ها
        </Button>
      </div>
    );
  }

  // ─── Render Lesson Content ────────────────────────────────────────────
  const renderContent = () => {
    if (isLoadingLesson) {
      return (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-teal-600" />
        </div>
      );
    }

    if (!currentLessonDetail) {
      return (
        <div className="flex items-center justify-center py-20 text-gray-500">
          درسی انتخاب نشده است
        </div>
      );
    }

    const lesson = currentLessonDetail;

    switch (lesson.type) {
      case 'VIDEO':
        return (
          <div className="space-y-4">
            {/* Video Player */}
            {lesson.videoUrl ? (
              <div className="aspect-video bg-black rounded-xl overflow-hidden">
                {isYouTubeUrl(lesson.videoUrl) ? (
                  <iframe
                    src={getYouTubeEmbedUrl(lesson.videoUrl)}
                    className="w-full h-full"
                    allowFullScreen
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    title={lesson.title}
                  />
                ) : isAparatUrl(lesson.videoUrl) ? (
                  <iframe
                    src={getAparatEmbedUrl(lesson.videoUrl)}
                    className="w-full h-full"
                    allowFullScreen
                    title={lesson.title}
                  />
                ) : (
                  <video
                    controls
                    className="w-full h-full"
                    src={lesson.videoUrl}
                    title={lesson.title}
                  >
                    مرورگر شما از پخش ویدیو پشتیبانی نمی‌کند.
                  </video>
                )}
              </div>
            ) : (
              <div className="aspect-video bg-gray-100 rounded-xl flex flex-col items-center justify-center text-gray-400">
                <Video className="h-12 w-12 mb-2" />
                <p className="text-sm">ویدیو هنوز بارگذاری نشده است</p>
              </div>
            )}

            {/* Video info */}
            {lesson.videoDuration && (
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Clock className="h-4 w-4" />
                <span>مدت ویدیو: {formatDuration(lesson.videoDuration)}</span>
              </div>
            )}

            {/* Description */}
            {lesson.description && (
              <div className="text-gray-600 text-sm leading-relaxed">
                {lesson.description}
              </div>
            )}
          </div>
        );

      case 'TEXT':
        return (
          <div className="space-y-4">
            {lesson.description && (
              <p className="text-gray-600 text-sm">{lesson.description}</p>
            )}
            {lesson.content ? (
              <div
                className="prose prose-sm max-w-none text-gray-800 leading-relaxed"
                dir="rtl"
                dangerouslySetInnerHTML={{ __html: lesson.content }}
              />
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-gray-400">
                <FileText className="h-12 w-12 mb-2" />
                <p className="text-sm">محتوای متنی هنوز بارگذاری نشده است</p>
              </div>
            )}
          </div>
        );

      case 'DOCUMENT':
        return (
          <div className="space-y-4">
            {lesson.description && (
              <p className="text-gray-600 text-sm">{lesson.description}</p>
            )}
            <div className="flex items-center gap-3">
              {lesson.documentUrl && (
                <a
                  href={lesson.documentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-sm transition-colors"
                >
                  <Download className="h-4 w-4" />
                  دانلود فایل
                </a>
              )}
            </div>
            {lesson.documentUrl && lesson.documentUrl.endsWith('.pdf') && (
              <div className="border rounded-xl overflow-hidden">
                <iframe
                  src={lesson.documentUrl}
                  className="w-full h-[500px]"
                  title={lesson.title}
                />
              </div>
            )}
            {!lesson.documentUrl && (
              <div className="flex flex-col items-center justify-center py-16 text-gray-400">
                <FileText className="h-12 w-12 mb-2" />
                <p className="text-sm">فایل هنوز بارگذاری نشده است</p>
              </div>
            )}
          </div>
        );

      case 'QUIZ':
        return (
          <div className="space-y-4">
            {lesson.description && (
              <p className="text-gray-600 text-sm">{lesson.description}</p>
            )}
            <Card className="border-amber-200 bg-amber-50/50">
              <CardContent className="flex flex-col items-center justify-center py-10">
                <HelpCircle className="h-12 w-12 text-amber-500 mb-3" />
                <h3 className="text-lg font-semibold text-gray-800 mb-2">
                  آزمون آنلاین
                </h3>
                <p className="text-gray-600 text-sm mb-4 text-center max-w-md">
                  برای شرکت در آزمون به بخش آزمون‌های پورتال مراجعه کنید.
                </p>
                <Button
                  variant="outline"
                  className="gap-2"
                  onClick={() => router.push('/portal/exams')}
                >
                  <ExternalLink className="h-4 w-4" />
                  رفتن به آزمون‌ها
                </Button>
              </CardContent>
            </Card>
          </div>
        );

      case 'LIVE_SESSION':
        return (
          <div className="space-y-4">
            {lesson.description && (
              <p className="text-gray-600 text-sm">{lesson.description}</p>
            )}
            <Card className="border-purple-200 bg-purple-50/50">
              <CardContent className="flex flex-col items-center justify-center py-10">
                <Monitor className="h-12 w-12 text-purple-500 mb-3" />
                <h3 className="text-lg font-semibold text-gray-800 mb-2">
                  جلسه زنده
                </h3>
                <p className="text-gray-600 text-sm mb-4 text-center max-w-md">
                  این درس به‌صورت جلسه زنده برگزار می‌شود. لطفاً در زمان مقرر وارد شوید.
                </p>
                {lesson.content && (
                  <a
                    href={lesson.content}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors"
                  >
                    <ExternalLink className="h-4 w-4" />
                    ورود به جلسه
                  </a>
                )}
              </CardContent>
            </Card>
          </div>
        );

      default:
        return (
          <div className="text-gray-500 text-center py-10">
            نوع محتوا پشتیبانی نمی‌شود
          </div>
        );
    }
  };

  // ─── Main Render ──────────────────────────────────────────────────────
  return (
    <div className="space-y-4">
      {/* ─── Top Header ────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            className="shrink-0 h-9 w-9"
            onClick={() => router.push('/portal/my-courses')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-lg font-bold text-gray-900 truncate">
              {programName}
            </h1>
            {instructorName && (
              <p className="text-sm text-gray-500 truncate">مدرس: {instructorName}</p>
            )}
          </div>
        </div>
        {/* Auto-save indicator */}
        {isSavingProgress && (
          <div className="flex items-center gap-1 text-xs text-gray-400">
            <Loader2 className="h-3 w-3 animate-spin" />
            ذخیره...
          </div>
        )}
      </div>

      {/* ─── Mobile Lesson Selector ────────────────────────────────────── */}
      <div className="lg:hidden">
        <Select
          value={currentLessonId || ''}
          onValueChange={(val) => goToLesson(val)}
        >
          <SelectTrigger className="w-full">
            <SelectValue placeholder="انتخاب درس" />
          </SelectTrigger>
          <SelectContent>
            {lessonsData.lessons.map((lesson, idx) => {
              const TypeIcon = getLessonTypeIcon(lesson.type);
              const isCompleted = lesson.progress.status === 'COMPLETED';
              return (
                <SelectItem key={lesson.id} value={lesson.id}>
                  <div className="flex items-center gap-2">
                    {isCompleted ? (
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                    ) : (
                      <Circle className="h-3.5 w-3.5 text-gray-300 shrink-0" />
                    )}
                    <span className="truncate">
                      {toPersianNumber(idx + 1)}. {lesson.title}
                    </span>
                  </div>
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>
      </div>

      {/* ─── Main Content Area ─────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* ─── Sidebar (Desktop) ──────────────────────────────────────── */}
        <div className="hidden lg:block lg:col-span-1">
          <Card className="sticky top-20">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold text-gray-900">
                فهرست دروس
              </CardTitle>
              <div className="space-y-2 mt-2">
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>
                    {toPersianNumber(completedCount)} از {toPersianNumber(totalLessons)} درس تکمیل
                  </span>
                  <span className="font-medium text-teal-700">
                    {toPersianNumber(overallProgress)}٪
                  </span>
                </div>
                <Progress value={overallProgress} className="h-1.5" />
              </div>
            </CardHeader>
            <Separator />
            <ScrollArea className="h-[450px]">
              <div className="py-2">
                {lessonsData.lessons.map((lesson, idx) => {
                  const TypeIcon = getLessonTypeIcon(lesson.type);
                  const isCompleted = lesson.progress.status === 'COMPLETED';
                  const isCurrent = lesson.id === currentLessonId;

                  return (
                    <button
                      key={lesson.id}
                      onClick={() => goToLesson(lesson.id)}
                      className={`w-full text-right px-4 py-3 flex items-start gap-3 transition-colors duration-150 ${
                        isCurrent
                          ? 'bg-teal-50 border-l-2 border-teal-500'
                          : 'hover:bg-gray-50 border-l-2 border-transparent'
                      }`}
                    >
                      <div className="flex items-center justify-center w-6 h-6 rounded-full text-xs font-medium shrink-0 mt-0.5">
                        {isCompleted ? (
                          <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                        ) : (
                          <span
                            className={`${
                              isCurrent
                                ? 'bg-teal-100 text-teal-700'
                                : 'bg-gray-100 text-gray-500'
                            } w-6 h-6 rounded-full flex items-center justify-center`}
                          >
                            {toPersianNumber(idx + 1)}
                          </span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p
                          className={`text-sm font-medium truncate ${
                            isCurrent ? 'text-teal-800' : 'text-gray-800'
                          } ${isCompleted ? 'line-through text-gray-400' : ''}`}
                        >
                          {lesson.title}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <TypeIcon
                            className={`h-3.5 w-3.5 ${
                              isCurrent ? 'text-teal-500' : 'text-gray-400'
                            }`}
                          />
                          <span className="text-xs text-gray-400">
                            {getLessonTypeLabel(lesson.type)}
                          </span>
                          {lesson.estimatedMinutes > 0 && (
                            <>
                              <span className="text-xs text-gray-300">•</span>
                              <span className="text-xs text-gray-400">
                                {toPersianNumber(lesson.estimatedMinutes)} دقیقه
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </ScrollArea>
          </Card>
        </div>

        {/* ─── Main Content (Desktop + Mobile) ─────────────────────────── */}
        <div className="lg:col-span-2 space-y-4">
          {/* Lesson Title and Type */}
          {currentLessonDetail && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={getLessonTypeBadgeVariant(currentLessonDetail.type)}>
                        {getLessonTypeLabel(currentLessonDetail.type)}
                      </Badge>
                      {currentLessonDetail.estimatedMinutes > 0 && (
                        <span className="text-xs text-gray-500 flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {toPersianNumber(currentLessonDetail.estimatedMinutes)} دقیقه
                        </span>
                      )}
                      {currentLessonDetail.progress.status === 'COMPLETED' && (
                        <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                          <CheckCircle2 className="h-3 w-3 ml-1" />
                          تکمیل‌شده
                        </Badge>
                      )}
                    </div>
                    <h2 className="text-lg font-bold text-gray-900">
                      {currentLessonDetail.title}
                    </h2>
                  </div>
                </div>

                {/* Progress for this lesson */}
                {currentLessonDetail.progress.status === 'IN_PROGRESS' && (
                  <div className="mt-3">
                    <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                      <span>پیشرفت درس</span>
                      <span>{toPersianNumber(currentLessonDetail.progress.progressPercent)}٪</span>
                    </div>
                    <Progress value={currentLessonDetail.progress.progressPercent} className="h-1.5" />
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Lesson Content */}
          <Card>
            <CardContent className="p-4 lg:p-6">{renderContent()}</CardContent>
          </Card>

          {/* Navigation & Actions */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-3">
                <Button
                  variant="outline"
                  onClick={goToPrevLesson}
                  disabled={!hasPrev}
                  className="gap-1"
                >
                  <ChevronRight className="h-4 w-4" />
                  درس قبلی
                </Button>

                <div className="flex items-center gap-2">
                  {currentLessonDetail &&
                    currentLessonDetail.progress.status !== 'COMPLETED' && (
                      <Button
                        onClick={markComplete}
                        disabled={isSavingProgress}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white gap-1"
                      >
                        {isSavingProgress ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <CheckCircle2 className="h-4 w-4" />
                        )}
                        تکمیل درس
                      </Button>
                    )}
                </div>

                <Button
                  variant="outline"
                  onClick={goToNextLesson}
                  disabled={!hasNext}
                  className="gap-1"
                >
                  درس بعدی
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              </div>

              {/* Mobile progress bar */}
              <div className="mt-4 lg:hidden">
                <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                  <span>
                    {toPersianNumber(completedCount)} از {toPersianNumber(totalLessons)} درس تکمیل
                  </span>
                  <span className="font-medium text-teal-700">
                    {toPersianNumber(overallProgress)}٪
                  </span>
                </div>
                <Progress value={overallProgress} className="h-1.5" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
