'use client';

import { useEffect, useState } from 'react';
import { usePortalAuth } from '@/app/portal/layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toPersianNumber } from '@/lib/persian';
import {
  Ticket,
  Plus,
  MessageCircle,
  Send,
  Clock,
  CheckCircle2,
  AlertCircle,
  User,
  Headphones,
  Eye,
} from 'lucide-react';

interface TicketItem {
  id: string;
  subject: string;
  description: string;
  category: string;
  priority: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  resolution?: string | null;
  _count?: { responses: number };
  responses?: TicketResponse[];
}

interface TicketResponse {
  id: string;
  content: string;
  authorType: string;
  authorName: string;
  isInternal: boolean;
  createdAt: string;
}

const ticketStatusMap: Record<string, { label: string; color: string }> = {
  OPEN: { label: 'باز', color: 'bg-blue-100 text-blue-700' },
  IN_PROGRESS: { label: 'در حال بررسی', color: 'bg-yellow-100 text-yellow-700' },
  WAITING_CUSTOMER: { label: 'منتظر پاسخ شما', color: 'bg-orange-100 text-orange-700' },
  RESOLVED: { label: 'حل‌شده', color: 'bg-green-100 text-green-700' },
  CLOSED: { label: 'بسته‌شده', color: 'bg-gray-100 text-gray-700' },
};

const ticketPriorityMap: Record<string, { label: string; color: string }> = {
  LOW: { label: 'کم', color: 'bg-gray-100 text-gray-600' },
  MEDIUM: { label: 'متوسط', color: 'bg-blue-100 text-blue-600' },
  HIGH: { label: 'زیاد', color: 'bg-orange-100 text-orange-600' },
  URGENT: { label: 'فوری', color: 'bg-red-100 text-red-600' },
};

const ticketCategoryMap: Record<string, string> = {
  GENERAL: 'عمومی',
  ENROLLMENT: 'ثبت‌نام',
  PAYMENT: 'پرداخت',
  CERTIFICATE: 'گواهینامه',
  TECHNICAL: 'فنی',
  COMPLAINT: 'شکایت',
};

function formatDate(dateStr: string): string {
  try {
    return new Date(dateStr).toLocaleDateString('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
}

export default function PortalTicketsPage() {
  const { token, user } = usePortalAuth();
  const [tickets, setTickets] = useState<TicketItem[]>([]);
  const [stats, setStats] = useState<{ openTickets: number; totalTickets: number } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');

  // New ticket dialog
  const [newTicketOpen, setNewTicketOpen] = useState(false);
  const [newSubject, setNewSubject] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newCategory, setNewCategory] = useState('GENERAL');
  const [newPriority, setNewPriority] = useState('MEDIUM');
  const [isCreating, setIsCreating] = useState(false);
  const [createMessage, setCreateMessage] = useState('');

  // Ticket detail dialog
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<TicketItem | null>(null);
  const [ticketResponses, setTicketResponses] = useState<TicketResponse[]>([]);
  const [isLoadingDetail, setIsLoadingDetail] = useState(false);
  const [responseText, setResponseText] = useState('');
  const [isSendingResponse, setIsSendingResponse] = useState(false);

  const fetchTickets = async () => {
    if (!token) return;
    try {
      const params = new URLSearchParams();
      if (statusFilter) params.set('status', statusFilter);

      const res = await fetch(`/api/portal/tickets?${params.toString()}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setTickets(data.data || []);
        setStats(data.stats || null);
      }
    } catch (error) {
      console.error('Tickets fetch error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [token, statusFilter]);

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsCreating(true);
    setCreateMessage('');

    try {
      const res = await fetch('/api/portal/tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          subject: newSubject,
          description: newDescription,
          category: newCategory,
          priority: newPriority,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setCreateMessage('تیکت با موفقیت ایجاد شد');
        setNewSubject('');
        setNewDescription('');
        setNewCategory('GENERAL');
        setNewPriority('MEDIUM');
        await fetchTickets();
        setTimeout(() => {
          setNewTicketOpen(false);
          setCreateMessage('');
        }, 1500);
      } else {
        setCreateMessage(data.error || 'خطا در ایجاد تیکت');
      }
    } catch {
      setCreateMessage('خطا در اتصال به سرور');
    } finally {
      setIsCreating(false);
    }
  };

  const openTicketDetail = async (ticket: TicketItem) => {
    setSelectedTicket(ticket);
    setDetailOpen(true);
    setIsLoadingDetail(true);

    try {
      const res = await fetch(`/api/portal/tickets/${ticket.id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok && data.data) {
        setTicketResponses(data.data.responses || []);
        setSelectedTicket(data.data);
      }
    } catch (error) {
      console.error('Ticket detail error:', error);
    } finally {
      setIsLoadingDetail(false);
    }
  };

  const handleSendResponse = async () => {
    if (!selectedTicket || !responseText.trim() || !token) return;
    setIsSendingResponse(true);

    try {
      const res = await fetch(`/api/portal/tickets/${selectedTicket.id}/responses`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ content: responseText }),
      });

      const data = await res.json();
      if (res.ok) {
        setResponseText('');
        // Refresh ticket detail
        await openTicketDetail(selectedTicket);
        await fetchTickets();
      }
    } catch (error) {
      console.error('Response error:', error);
    } finally {
      setIsSendingResponse(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-40 mb-2" />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Skeleton className="h-24 rounded-xl" />
          <Skeleton className="h-24 rounded-xl" />
        </div>
        <Skeleton className="h-96 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">تیکت‌ها</h1>
          <p className="text-gray-500 text-sm mt-1">مدیریت تیکت‌های پشتیبانی</p>
        </div>
        <Button
          onClick={() => setNewTicketOpen(true)}
          className="bg-teal-600 hover:bg-teal-700 text-white h-10"
        >
          <Plus className="h-4 w-4 ml-2" />
          تیکت جدید
        </Button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-2 gap-4">
          <Card className="border-0 shadow-sm bg-gradient-to-bl from-blue-50 to-white">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-blue-500" />
                <span className="text-xs text-gray-500">تیکت‌های باز</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(stats.openTickets)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm bg-gradient-to-bl from-gray-50 to-white">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Ticket className="h-4 w-4 text-gray-500" />
                <span className="text-xs text-gray-500">کل تیکت‌ها</span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{toPersianNumber(stats.totalTickets)}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-sm text-gray-500">فیلتر:</span>
        {[
          { value: '', label: 'همه' },
          { value: 'OPEN', label: 'باز' },
          { value: 'IN_PROGRESS', label: 'در حال بررسی' },
          { value: 'WAITING_CUSTOMER', label: 'منتظر پاسخ' },
          { value: 'RESOLVED', label: 'حل‌شده' },
          { value: 'CLOSED', label: 'بسته‌شده' },
        ].map(filter => (
          <Button
            key={filter.value}
            variant={statusFilter === filter.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => setStatusFilter(filter.value)}
            className={`h-8 text-xs rounded-lg ${
              statusFilter === filter.value
                ? 'bg-teal-600 hover:bg-teal-700 text-white'
                : 'border-gray-200 text-gray-600 hover:text-gray-900'
            }`}
          >
            {filter.label}
          </Button>
        ))}
      </div>

      {/* Tickets List */}
      <div className="space-y-3">
        {tickets.length > 0 ? (
          tickets.map((ticket) => {
            const statusInfo = ticketStatusMap[ticket.status] || { label: ticket.status, color: 'bg-gray-100 text-gray-700' };
            const priorityInfo = ticketPriorityMap[ticket.priority] || { label: ticket.priority, color: 'bg-gray-100 text-gray-600' };
            const responseCount = ticket._count?.responses || 0;

            return (
              <Card
                key={ticket.id}
                className="border-0 shadow-sm hover:shadow-md transition-all cursor-pointer group"
                onClick={() => openTicketDetail(ticket)}
              >
                <CardContent className="p-4 sm:p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <h3 className="text-sm font-bold text-gray-900 truncate">{ticket.subject}</h3>
                        <Badge className={`text-xs ${statusInfo.color} border-0`}>
                          {statusInfo.label}
                        </Badge>
                        <Badge className={`text-xs ${priorityInfo.color} border-0`}>
                          {priorityInfo.label}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-500 line-clamp-1 mb-2">{ticket.description}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-400">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatDate(ticket.createdAt)}
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageCircle className="h-3 w-3" />
                          {toPersianNumber(responseCount)} پاسخ
                        </span>
                        <span>
                          {ticketCategoryMap[ticket.category] || ticket.category}
                        </span>
                      </div>
                    </div>
                    <Eye className="h-4 w-4 text-gray-300 group-hover:text-teal-600 transition-colors flex-shrink-0 mt-1" />
                  </div>
                </CardContent>
              </Card>
            );
          })
        ) : (
          <Card className="border-0 shadow-sm">
            <CardContent className="py-12 text-center">
              <Ticket className="h-12 w-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm text-gray-400">تیکتی یافت نشد</p>
              <Button
                variant="outline"
                onClick={() => setNewTicketOpen(true)}
                className="mt-4 border-teal-200 text-teal-600 hover:bg-teal-50"
              >
                <Plus className="h-4 w-4 ml-2" />
                ایجاد تیکت جدید
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* New Ticket Dialog */}
      <Dialog open={newTicketOpen} onOpenChange={setNewTicketOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-teal-600" />
              تیکت جدید
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleCreateTicket} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="subject" className="text-gray-700">موضوع</Label>
              <Input
                id="subject"
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                className="h-11 bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400"
                placeholder="موضوع تیکت خود را بنویسید"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-700">دسته‌بندی</Label>
                <Select value={newCategory} onValueChange={setNewCategory}>
                  <SelectTrigger className="h-11 bg-gray-50 border-gray-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="GENERAL">عمومی</SelectItem>
                    <SelectItem value="ENROLLMENT">ثبت‌نام</SelectItem>
                    <SelectItem value="PAYMENT">پرداخت</SelectItem>
                    <SelectItem value="CERTIFICATE">گواهینامه</SelectItem>
                    <SelectItem value="TECHNICAL">فنی</SelectItem>
                    <SelectItem value="COMPLAINT">شکایت</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-700">اولویت</Label>
                <Select value={newPriority} onValueChange={setNewPriority}>
                  <SelectTrigger className="h-11 bg-gray-50 border-gray-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LOW">کم</SelectItem>
                    <SelectItem value="MEDIUM">متوسط</SelectItem>
                    <SelectItem value="HIGH">زیاد</SelectItem>
                    <SelectItem value="URGENT">فوری</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-gray-700">توضیحات</Label>
              <Textarea
                id="description"
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                className="bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400 min-h-[120px]"
                placeholder="توضیحات کامل تیکت خود را بنویسید..."
                required
              />
            </div>

            {createMessage && (
              <Alert className={createMessage.includes('موفقیت') ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
                <CheckCircle2 className={`h-4 w-4 ${createMessage.includes('موفقیت') ? 'text-green-600' : 'text-red-600'}`} />
                <AlertDescription className={createMessage.includes('موفقیت') ? 'text-green-700' : 'text-red-700'}>
                  {createMessage}
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-3 pt-2">
              <Button
                type="submit"
                disabled={isCreating}
                className="flex-1 h-11 bg-teal-600 hover:bg-teal-700 text-white"
              >
                {isCreating ? (
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    <span>در حال ارسال...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Send className="h-4 w-4" />
                    <span>ارسال تیکت</span>
                  </div>
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setNewTicketOpen(false)}
                className="h-11 border-gray-200"
              >
                انصراف
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Ticket Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Ticket className="h-5 w-5 text-teal-600" />
              {selectedTicket?.subject}
            </DialogTitle>
          </DialogHeader>

          {isLoadingDetail ? (
            <div className="space-y-4 p-4">
              <Skeleton className="h-6 w-40" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
          ) : selectedTicket ? (
            <div className="flex-1 overflow-y-auto space-y-4 -mx-6 px-6">
              {/* Ticket Info */}
              <div className="flex flex-wrap gap-2 mb-2">
                <Badge className={`text-xs ${ticketStatusMap[selectedTicket.status]?.color || 'bg-gray-100 text-gray-700'} border-0`}>
                  {ticketStatusMap[selectedTicket.status]?.label || selectedTicket.status}
                </Badge>
                <Badge className={`text-xs ${ticketPriorityMap[selectedTicket.priority]?.color || 'bg-gray-100 text-gray-600'} border-0`}>
                  {ticketPriorityMap[selectedTicket.priority]?.label || selectedTicket.priority}
                </Badge>
                <Badge variant="outline" className="text-xs border-gray-200 text-gray-500">
                  {ticketCategoryMap[selectedTicket.category] || selectedTicket.category}
                </Badge>
                <span className="text-xs text-gray-400 flex items-center gap-1 mr-auto">
                  <Clock className="h-3 w-3" />
                  {formatDate(selectedTicket.createdAt)}
                </span>
              </div>

              {/* Original message */}
              <div className="p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-7 h-7 rounded-full bg-teal-100 flex items-center justify-center">
                    <User className="h-3.5 w-3.5 text-teal-600" />
                  </div>
                  <span className="text-sm font-medium text-gray-900">
                    {user?.displayName || 'شما'}
                  </span>
                  <span className="text-xs text-gray-400">{formatDate(selectedTicket.createdAt)}</span>
                </div>
                <p className="text-sm text-gray-700 whitespace-pre-wrap">{selectedTicket.description}</p>
              </div>

              {/* Resolution */}
              {selectedTicket.resolution && (
                <div className="p-4 bg-green-50 rounded-xl border border-green-100">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium text-green-700">نتیجه نهایی</span>
                  </div>
                  <p className="text-sm text-green-600">{selectedTicket.resolution}</p>
                </div>
              )}

              {/* Responses */}
              {ticketResponses.length > 0 && (
                <div className="space-y-3">
                  <p className="text-sm font-medium text-gray-700">پاسخ‌ها</p>
                  {ticketResponses.map((response) => (
                    <div
                      key={response.id}
                      className={`p-4 rounded-xl ${
                        response.authorType === 'CUSTOMER'
                          ? 'bg-teal-50 border border-teal-100'
                          : 'bg-gray-50 border border-gray-100'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                          response.authorType === 'CUSTOMER'
                            ? 'bg-teal-100'
                            : 'bg-purple-100'
                        }`}>
                          {response.authorType === 'CUSTOMER' ? (
                            <User className="h-3.5 w-3.5 text-teal-600" />
                          ) : (
                            <Headphones className="h-3.5 w-3.5 text-purple-600" />
                          )}
                        </div>
                        <span className="text-sm font-medium text-gray-900">{response.authorName}</span>
                        <Badge variant="outline" className="text-xs border-gray-200 text-gray-400">
                          {response.authorType === 'CUSTOMER' ? 'مشتری' : 'پشتیبان'}
                        </Badge>
                        <span className="text-xs text-gray-400 mr-auto">{formatDate(response.createdAt)}</span>
                      </div>
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{response.content}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Reply box */}
              {selectedTicket.status !== 'CLOSED' && (
                <div className="sticky bottom-0 bg-white pt-3 pb-2 border-t border-gray-100">
                  <div className="flex gap-2">
                    <Input
                      value={responseText}
                      onChange={(e) => setResponseText(e.target.value)}
                      placeholder="پاسخ خود را بنویسید..."
                      className="h-11 bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey && responseText.trim()) {
                          e.preventDefault();
                          handleSendResponse();
                        }
                      }}
                    />
                    <Button
                      onClick={handleSendResponse}
                      disabled={!responseText.trim() || isSendingResponse}
                      className="h-11 bg-teal-600 hover:bg-teal-700 text-white px-4"
                    >
                      {isSendingResponse ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              )}

              {selectedTicket.status === 'CLOSED' && (
                <div className="text-center py-4">
                  <AlertCircle className="h-5 w-5 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-400">این تیکت بسته شده است</p>
                </div>
              )}
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}
