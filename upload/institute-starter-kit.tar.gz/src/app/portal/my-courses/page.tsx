'use client';

import { useEffect, useState, useCallback } from 'react';
import { usePortalAuth } from '@/app/portal/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { toPersianNumber } from '@/lib/persian';
import {
  BookOpen,
  Clock,
  CheckCircle2,
  TrendingUp,
  Play,
  GraduationCap,
  ArrowLeft,
  AlertCircle,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

// ─── Types ───────────────────────────────────────────────────────────────────

interface CourseData {
  enrollmentId: string;
  skillProgramId: string;
  program: {
    id: string;
    name: string;
    instructor: string | null;
    level: string | null;
    totalHours: number;
    description: string | null;
  };
  lessonCount: number;
  publishedLessonCount: number;
  progress: {
    completedLessons: number;
    totalLessons: number;
    overallCompletionPercent: number;
  };
  enrollmentStatus: string;
  enrollmentDate: string;
  completionDate: string | null;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getStatusBadgeVariant(status: string): 'default' | 'secondary' | 'destructive' | 'outline' {
  switch (status) {
    case 'ENROLLED':
      return 'default';
    case 'COMPLETED':
      return 'secondary';
    case 'DROPPED':
      return 'destructive';
    default:
      return 'outline';
  }
}

function getStatusLabel(status: string): string {
  switch (status) {
    case 'ENROLLED':
      return 'فعال';
    case 'COMPLETED':
      return 'تکمیل‌شده';
    case 'DROPPED':
      return 'ترک‌شده';
    case 'FAILED':
      return 'مردود';
    default:
      return status;
  }
}

function getLevelLabel(level: string | null): string {
  switch (level) {
    case 'BEGINNER':
    case 'مبتدی':
      return 'مبتدی';
    case 'INTERMEDIATE':
    case 'متوسط':
      return 'متوسط';
    case 'ADVANCED':
    case 'پیشرفته':
      return 'پیشرفته';
    default:
      return level || '—';
  }
}

function formatLearningTime(totalMinutes: number): string {
  if (totalMinutes < 60) {
    return `${toPersianNumber(totalMinutes)} دقیقه`;
  }
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  if (mins === 0) {
    return `${toPersianNumber(hours)} ساعت`;
  }
  return `${toPersianNumber(hours)} ساعت و ${toPersianNumber(mins)} دقیقه`;
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function MyCoursesPage() {
  const { token } = usePortalAuth();
  const router = useRouter();
  const [courses, setCourses] = useState<CourseData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCourses = useCallback(async () => {
    if (!token) return;

    try {
      setIsLoading(true);
      setError(null);
      const res = await fetch('/api/portal/lms/courses', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'خطا در دریافت دوره‌ها');
        return;
      }

      setCourses(data.data || []);
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setIsLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchCourses();
  }, [fetchCourses]);

  // ─── Compute Stats ──────────────────────────────────────────────────────

  const enrolledCount = courses.filter((c) => c.enrollmentStatus === 'ENROLLED').length;
  const completedCount = courses.filter((c) => c.enrollmentStatus === 'COMPLETED').length;
  const totalHours = courses.reduce((sum, c) => sum + c.program.totalHours, 0);
  const avgProgress =
    courses.length > 0
      ? Math.round(courses.reduce((sum, c) => sum + c.progress.overallCompletionPercent, 0) / courses.length)
      : 0;

  // ─── Loading State ─────────────────────────────────────────────────────

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64" />
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-56 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  // ─── Error State ───────────────────────────────────────────────────────

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center mb-4">
          <AlertCircle className="h-8 w-8 text-red-500" />
        </div>
        <p className="text-gray-700 font-medium mb-2">خطا در بارگذاری دوره‌ها</p>
        <p className="text-gray-500 text-sm mb-4">{error}</p>
        <Button onClick={fetchCourses} variant="outline">
          تلاش مجدد
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* ─── Header ─────────────────────────────────────────────────────── */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <BookOpen className="h-6 w-6 text-teal-600" />
          دوره‌های من
        </h1>
        <p className="text-gray-500 mt-1">محتوای آموزشی و پیشرفت شما</p>
      </div>

      {/* ─── Stats Cards ────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-teal-50 to-emerald-50 border-teal-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-teal-700 font-medium">دوره‌های فعال</p>
                <p className="text-2xl font-bold text-teal-900 mt-1">
                  {toPersianNumber(enrolledCount)}
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-teal-500/10 flex items-center justify-center">
                <BookOpen className="h-5 w-5 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-cyan-50 to-sky-50 border-cyan-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-cyan-700 font-medium">مجموع ساعات</p>
                <p className="text-2xl font-bold text-cyan-900 mt-1">
                  {toPersianNumber(totalHours)}
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center">
                <Clock className="h-5 w-5 text-cyan-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-amber-700 font-medium">میانگین پیشرفت</p>
                <p className="text-2xl font-bold text-amber-900 mt-1">
                  {toPersianNumber(avgProgress)}٪
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-emerald-50 to-green-50 border-emerald-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-emerald-700 font-medium">تکمیل‌شده</p>
                <p className="text-2xl font-bold text-emerald-900 mt-1">
                  {toPersianNumber(completedCount)}
                </p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                <CheckCircle2 className="h-5 w-5 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ─── Course Cards ───────────────────────────────────────────────── */}
      {courses.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4">
              <GraduationCap className="h-10 w-10 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">
              هنوز در دوره‌ای ثبت‌نام نکرده‌اید
            </h3>
            <p className="text-gray-500 text-sm mb-6 text-center max-w-md">
              پس از ثبت‌نام در برنامه‌های مهارت‌آموزی، دوره‌های شما در اینجا نمایش داده می‌شود.
            </p>
            <Button variant="outline" onClick={() => router.push('/portal/dashboard')}>
              بازگشت به داشبورد
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {courses.map((course) => (
            <Card
              key={course.enrollmentId}
              className="hover:shadow-md transition-shadow duration-200 border-gray-200/80"
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <CardTitle className="text-base font-bold text-gray-900 truncate">
                      {course.program.name}
                    </CardTitle>
                    <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                      {course.program.instructor && (
                        <span className="truncate">{course.program.instructor}</span>
                      )}
                      {course.program.instructor && course.program.level && (
                        <Separator orientation="vertical" className="h-3" />
                      )}
                      {course.program.level && (
                        <span>{getLevelLabel(course.program.level)}</span>
                      )}
                      {(course.program.instructor || course.program.level) && (
                        <Separator orientation="vertical" className="h-3" />
                      )}
                      <span>{toPersianNumber(course.program.totalHours)} ساعت</span>
                    </div>
                  </div>
                  <Badge variant={getStatusBadgeVariant(course.enrollmentStatus)}>
                    {getStatusLabel(course.enrollmentStatus)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0 space-y-4">
                {/* Progress */}
                <div>
                  <div className="flex items-center justify-between text-sm mb-1.5">
                    <span className="text-gray-600">
                      {toPersianNumber(course.progress.completedLessons)} از{' '}
                      {toPersianNumber(course.progress.totalLessons)} درس
                    </span>
                    <span className="font-medium text-gray-900">
                      {toPersianNumber(course.progress.overallCompletionPercent)}٪
                    </span>
                  </div>
                  <Progress
                    value={course.progress.overallCompletionPercent}
                    className="h-2"
                  />
                </div>

                {/* Action */}
                <Button
                  onClick={() => router.push(`/portal/learn/${course.skillProgramId}`)}
                  className="w-full bg-teal-600 hover:bg-teal-700 text-white gap-2"
                  disabled={course.enrollmentStatus === 'DROPPED'}
                >
                  {course.enrollmentStatus === 'COMPLETED' ? (
                    <>
                      <CheckCircle2 className="h-4 w-4" />
                      مرور دوره
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4" />
                      ادامه یادگیری
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* ─── Back Link ──────────────────────────────────────────────────── */}
      <div className="pt-2">
        <Link
          href="/portal/dashboard"
          className="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-teal-600 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          بازگشت به داشبورد
        </Link>
      </div>
    </div>
  );
}
