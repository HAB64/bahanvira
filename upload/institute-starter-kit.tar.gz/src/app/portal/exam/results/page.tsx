'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { usePortalAuth } from '@/app/portal/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { toPersianNumber } from '@/lib/persian';
import {
  Trophy,
  XCircle,
  Clock,
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  AlertCircle,
} from 'lucide-react';

interface NormalizedOption {
  label: string;
  text: string;
}

interface QuestionResult {
  questionId: string;
  text: string;
  type: string;
  options?: NormalizedOption[] | string[] | { label?: string; text?: string; key?: string; id?: number; isCorrect?: boolean }[] | null;
  points: number;
  difficulty: string;
  explanation?: string | null;
  image?: string | null;
  selectedAnswer: string | null;
  correctAnswer: string;
  isCorrect: boolean | null;
  pointsEarned: number;
}

interface AttemptResult {
  attemptId: string;
  status: string;
  score: number | null;
  maxScore: number | null;
  percentage: number | null;
  isPassed: boolean | null;
  startedAt: string;
  submittedAt: string | null;
  timeSpentSec: number | null;
  exam: {
    id: string;
    title: string;
    type: string;
    description?: string | null;
    passingScore: number;
    programName?: string | null;
  };
  questions: QuestionResult[];
  message?: string;
  resultsAvailableAt?: string | null;
}

const PERSIAN_LETTERS = ['الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ'];

function normalizeOptions(options: QuestionResult['options']): NormalizedOption[] {
  if (!options || !Array.isArray(options)) return [];
  return options.map((opt, idx) => {
    if (typeof opt === 'object' && opt !== null && 'label' in opt && 'text' in opt && typeof opt.label === 'string' && typeof opt.text === 'string') {
      return { label: opt.label, text: opt.text };
    }
    if (typeof opt === 'object' && opt !== null && 'key' in opt && 'text' in opt) {
      return { label: String(opt.key), text: String(opt.text) };
    }
    if (typeof opt === 'object' && opt !== null && 'text' in opt) {
      return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: String(opt.text) };
    }
    if (typeof opt === 'string') {
      return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: opt };
    }
    return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: String(opt) };
  });
}

function ExamResultsContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { token } = usePortalAuth();
  const attemptId = searchParams.get('attemptId');

  const [result, setResult] = useState<AttemptResult | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openQuestions, setOpenQuestions] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!token || !attemptId) {
      setError('شناسه تلاش آزمون یافت نشد');
      setIsLoading(false);
      return;
    }

    const fetchResults = async () => {
      try {
        const res = await fetch(`/api/exams/attempts/${attemptId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        const data = await res.json();
        if (!res.ok) {
          setError(data.error || 'خطا در دریافت نتایج');
          return;
        }

        setResult(data.داده);
      } catch {
        setError('خطا در ارتباط با سرور');
      } finally {
        setIsLoading(false);
      }
    };

    fetchResults();
  }, [token, attemptId]);

  const toggleQuestion = (questionId: string) => {
    setOpenQuestions(prev => {
      const next = new Set(prev);
      if (next.has(questionId)) {
        next.delete(questionId);
      } else {
        next.add(questionId);
      }
      return next;
    });
  };

  if (isLoading) {
    return <ExamResultsSkeleton />;
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4" dir="rtl">
        <AlertCircle className="h-16 w-16 text-amber-500" />
        <h2 className="text-xl font-bold text-gray-900">{error}</h2>
        <Button onClick={() => router.push('/portal/dashboard')} variant="outline">
          بازگشت به داشبورد
        </Button>
      </div>
    );
  }

  if (!result) return null;

  // If results are not available yet
  if (result.message && result.score === null) {
    return (
      <div className="max-w-2xl mx-auto" dir="rtl">
        <Card className="border-0 shadow-sm">
          <CardContent className="p-8 text-center space-y-4">
            <Clock className="h-16 w-16 mx-auto text-amber-500" />
            <h2 className="text-xl font-bold text-gray-900">{result.exam.title}</h2>
            <p className="text-gray-600">{result.message}</p>
            {result.resultsAvailableAt && (
              <p className="text-sm text-gray-400">
                نتایج از: {new Date(result.resultsAvailableAt).toLocaleDateString('fa-IR')}
              </p>
            )}
            <Button onClick={() => router.push('/portal/dashboard')} variant="outline" className="mt-4">
              بازگشت به داشبورد
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const scorePercent = result.percentage ?? 0;
  const isPassed = result.isPassed ?? false;
  const correctCount = result.questions.filter(q => q.isCorrect === true).length;
  const wrongCount = result.questions.filter(q => q.isCorrect === false).length;
  const unansweredCount = result.questions.filter(q => q.selectedAnswer === null || q.selectedAnswer === '').length;

  // Score circle color
  const circleColor = isPassed ? 'text-emerald-500' : 'text-red-500';
  const circleBg = isPassed ? 'from-emerald-50 to-green-50' : 'from-red-50 to-rose-50';
  const circleStroke = isPassed ? '#10b981' : '#ef4444';

  // Circle SVG parameters
  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (scorePercent / 100) * circumference;

  const formatTime = (seconds: number | null) => {
    if (!seconds) return '—';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${toPersianNumber(m)} دقیقه و ${toPersianNumber(s)} ثانیه`;
  };

  const examTypeLabel: Record<string, string> = {
    QUIZ: 'کوییز',
    MIDTERM: 'میان‌ترم',
    FINAL: 'پایان‌ترم',
    DIAGNOSTIC: 'تشخیصی',
    PRACTICAL: 'عملی',
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => router.push('/portal/dashboard')}
          className="h-9 w-9"
        >
          <ArrowRight className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-xl font-bold text-gray-900">نتایج آزمون</h1>
          <p className="text-sm text-gray-400">{result.exam.title}</p>
        </div>
      </div>

      {/* Score Circle */}
      <Card className={`border-0 shadow-sm bg-gradient-to-bl ${circleBg}`}>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            {/* SVG Circle */}
            <div className="relative">
              <svg width="200" height="200" className="-rotate-90">
                <circle
                  cx="100"
                  cy="100"
                  r={radius}
                  fill="none"
                  stroke="#e5e7eb"
                  strokeWidth="12"
                />
                <circle
                  cx="100"
                  cy="100"
                  r={radius}
                  fill="none"
                  stroke={circleStroke}
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  className="transition-all duration-1000 ease-out"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className={`text-4xl font-bold ${circleColor}`}>
                  {toPersianNumber(Math.round(scorePercent))}
                </span>
                <span className="text-sm text-gray-500">درصد</span>
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 space-y-3 text-center sm:text-right">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                {isPassed ? (
                  <Trophy className="h-6 w-6 text-emerald-500" />
                ) : (
                  <XCircle className="h-6 w-6 text-red-500" />
                )}
                <span className={`text-lg font-bold ${isPassed ? 'text-emerald-600' : 'text-red-600'}`}>
                  {isPassed ? 'قبول' : 'مردود'}
                </span>
              </div>
              <p className="text-sm text-gray-600">
                نمره: <span className="font-bold">{toPersianNumber(result.score ?? 0)}</span>
                {' از '}
                <span className="font-bold">{toPersianNumber(result.maxScore ?? 0)}</span>
              </p>
              <p className="text-sm text-gray-600">
                نمره قبولی: <span className="font-bold">{toPersianNumber(result.exam.passingScore)}</span>
              </p>
              {result.exam.programName && (
                <p className="text-xs text-gray-400">{result.exam.programName}</p>
              )}
              <Badge variant="outline" className="text-xs">
                {examTypeLabel[result.exam.type] || result.exam.type}
              </Badge>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
            <div className="bg-white/60 rounded-xl p-3 text-center">
              <p className="text-xs text-gray-500 mb-1">صحیح</p>
              <p className="text-lg font-bold text-emerald-600">{toPersianNumber(correctCount)}</p>
            </div>
            <div className="bg-white/60 rounded-xl p-3 text-center">
              <p className="text-xs text-gray-500 mb-1">غلط</p>
              <p className="text-lg font-bold text-red-600">{toPersianNumber(wrongCount)}</p>
            </div>
            <div className="bg-white/60 rounded-xl p-3 text-center">
              <p className="text-xs text-gray-500 mb-1">بی‌پاسخ</p>
              <p className="text-lg font-bold text-gray-600">{toPersianNumber(unansweredCount)}</p>
            </div>
            <div className="bg-white/60 rounded-xl p-3 text-center">
              <p className="text-xs text-gray-500 mb-1">زمان</p>
              <p className="text-sm font-bold text-gray-700">{formatTime(result.timeSpentSec)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Question-by-Question Review */}
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold text-gray-900">بررسی سؤالات</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {result.questions.map((q, idx) => {
            const isOpen = openQuestions.has(q.questionId);
            return (
              <Collapsible
                key={q.questionId}
                open={isOpen}
                onOpenChange={() => toggleQuestion(q.questionId)}
              >
                <CollapsibleTrigger asChild>
                  <button className="w-full flex items-center gap-3 p-3 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors text-right">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      q.isCorrect === true ? 'bg-emerald-100' :
                      q.isCorrect === false ? 'bg-red-100' :
                      'bg-gray-200'
                    }`}>
                      {q.isCorrect === true ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                      ) : q.isCorrect === false ? (
                        <XCircle className="h-4 w-4 text-red-600" />
                      ) : (
                        <span className="text-xs text-gray-400">—</span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-900 truncate">
                        سؤال {toPersianNumber(idx + 1)}: {q.text.substring(0, 60)}...
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {toPersianNumber(q.pointsEarned)} از {toPersianNumber(q.points)} نمره
                      </p>
                    </div>
                    {isOpen ? (
                      <ChevronUp className="h-4 w-4 text-gray-400 flex-shrink-0" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-gray-400 flex-shrink-0" />
                    )}
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="p-4 bg-gray-50/50 rounded-xl mt-1 space-y-4 border border-gray-100">
                    <p className="text-sm text-gray-800 leading-7 whitespace-pre-wrap">{q.text}</p>

                    {/* Options for MCQ */}
                    {q.type === 'MULTIPLE_CHOICE' && q.options && (() => {
                      const normalized = normalizeOptions(q.options);
                      if (normalized.length === 0) return null;
                      return (
                        <div className="space-y-2">
                          {normalized.map((opt, idx) => {
                            const isCorrectOption = opt.label === q.correctAnswer;
                            const isSelectedOption = opt.label === q.selectedAnswer;
                            return (
                              <div
                                key={`${q.questionId}-opt-${idx}`}
                                className={`flex items-center gap-2 p-2 rounded-lg text-sm ${
                                  isCorrectOption ? 'bg-emerald-50 border border-emerald-200' :
                                  isSelectedOption && !isCorrectOption ? 'bg-red-50 border border-red-200' :
                                  'bg-white border border-gray-100'
                                }`}
                              >
                                <span className="font-bold text-xs w-6 text-center">{opt.label}</span>
                                <span className="flex-1">{opt.text}</span>
                                {isCorrectOption && <CheckCircle2 className="h-4 w-4 text-emerald-500 flex-shrink-0" />}
                                {isSelectedOption && !isCorrectOption && <XCircle className="h-4 w-4 text-red-500 flex-shrink-0" />}
                              </div>
                            );
                          })}
                        </div>
                      );
                    })()}

                    {/* True/False */}
                    {q.type === 'TRUE_FALSE' && (
                      <div className="flex gap-3">
                        <div className={`flex-1 p-2 rounded-lg text-sm text-center ${
                          q.correctAnswer === 'true' ? 'bg-emerald-50 border border-emerald-200 font-bold text-emerald-700' : 'bg-white border border-gray-100'
                        }`}>
                          صحیح {q.correctAnswer === 'true' && '✓'}
                          {q.selectedAnswer === 'true' && q.correctAnswer !== 'true' && ' ✗'}
                        </div>
                        <div className={`flex-1 p-2 rounded-lg text-sm text-center ${
                          q.correctAnswer === 'false' ? 'bg-emerald-50 border border-emerald-200 font-bold text-emerald-700' : 'bg-white border border-gray-100'
                        }`}>
                          غلط {q.correctAnswer === 'false' && '✓'}
                          {q.selectedAnswer === 'false' && q.correctAnswer !== 'false' && ' ✗'}
                        </div>
                      </div>
                    )}

                    {/* Short Answer */}
                    {q.type === 'SHORT_ANSWER' && (
                      <div className="space-y-2">
                        <div className="text-sm">
                          <span className="text-gray-500">پاسخ شما: </span>
                          <span className={q.isCorrect ? 'text-emerald-600 font-bold' : 'text-red-600'}>
                            {q.selectedAnswer || '—'}
                          </span>
                        </div>
                        <div className="text-sm">
                          <span className="text-gray-500">پاسخ صحیح: </span>
                          <span className="text-emerald-600 font-bold">{q.correctAnswer}</span>
                        </div>
                      </div>
                    )}

                    {/* Explanation */}
                    {q.explanation && (
                      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                        <p className="text-xs text-amber-700 font-bold mb-1">توضیح:</p>
                        <p className="text-sm text-amber-800">{q.explanation}</p>
                      </div>
                    )}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            );
          })}
        </CardContent>
      </Card>

      {/* Back Button */}
      <div className="flex justify-center pb-6">
        <Button
          onClick={() => router.push('/portal/dashboard')}
          className="gap-2 bg-teal-600 hover:bg-teal-700"
        >
          بازگشت به داشبورد
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

function ExamResultsSkeleton() {
  return (
    <div className="max-w-3xl mx-auto space-y-6" dir="rtl">
      <div className="flex items-center gap-3">
        <Skeleton className="h-9 w-9 rounded-lg" />
        <div>
          <Skeleton className="h-6 w-40 mb-1" />
          <Skeleton className="h-4 w-60" />
        </div>
      </div>
      <Skeleton className="h-64 w-full rounded-xl" />
      <Skeleton className="h-48 w-full rounded-xl" />
    </div>
  );
}

export default function ExamResultsPage() {
  return (
    <Suspense fallback={<ExamResultsSkeleton />}>
      <ExamResultsContent />
    </Suspense>
  );
}
