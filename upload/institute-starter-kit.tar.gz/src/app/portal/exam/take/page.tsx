'use client';

import { useEffect, useState, useCallback, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { usePortalAuth } from '@/app/portal/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import { toPersianNumber } from '@/lib/persian';
import {
  Clock,
  ChevronLeft,
  ChevronRight,
  Send,
  Save,
  AlertTriangle,
  CheckCircle2,
  XCircle,
} from 'lucide-react';

interface NormalizedOption {
  label: string;
  text: string;
}

interface ExamQuestion {
  id: string;
  text: string;
  type: string;
  options?: NormalizedOption[] | string[] | { label?: string; text?: string; key?: string; id?: number; isCorrect?: boolean }[] | null;
  points: number;
  difficulty: string;
  image?: string | null;
}

interface ExamInfo {
  id: string;
  title: string;
  description?: string | null;
  type: string;
  durationMinutes: number;
  passingScore: number;
  showResults: string;
  programName?: string | null;
}

interface ExamData {
  attemptId: string;
  exam: ExamInfo;
  questions: ExamQuestion[];
  savedAnswers: Record<string, string>;
  startedAt: string;
  remainingSeconds: number;
}

const PERSIAN_LETTERS = ['الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ'];

function normalizeOptions(options: ExamQuestion['options']): NormalizedOption[] {
  if (!options || !Array.isArray(options)) return [];
  return options.map((opt, idx) => {
    // Already normalized {label, text}
    if (typeof opt === 'object' && opt !== null && 'label' in opt && 'text' in opt && typeof opt.label === 'string' && typeof opt.text === 'string') {
      return { label: opt.label, text: opt.text };
    }
    // {key, text} format (seed data)
    if (typeof opt === 'object' && opt !== null && 'key' in opt && 'text' in opt) {
      return { label: String(opt.key), text: String(opt.text) };
    }
    // {id, text, isCorrect} format (question bank import)
    if (typeof opt === 'object' && opt !== null && 'text' in opt) {
      return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: String(opt.text) };
    }
    // Plain string
    if (typeof opt === 'string') {
      return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: opt };
    }
    // Fallback
    return { label: PERSIAN_LETTERS[idx] || String(idx + 1), text: String(opt) };
  });
}

function ExamTakeContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { token } = usePortalAuth();
  const examId = searchParams.get('examId');

  const [examData, setExamData] = useState<ExamData | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [remainingSeconds, setRemainingSeconds] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastSaveTime, setLastSaveTime] = useState<Date | null>(null);

  // Start exam
  useEffect(() => {
    if (!token || !examId) return;

    const startExam = async () => {
      try {
        const res = await fetch('/api/exams/start', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ examId }),
        });

        const data = await res.json();
        if (!res.ok) {
          setError(data.error || 'خطا در شروع آزمون');
          return;
        }

        setExamData(data.داده);
        setAnswers(data.داده.savedAnswers || {});
        setRemainingSeconds(data.داده.remainingSeconds);
      } catch {
        setError('خطا در ارتباط با سرور');
      } finally {
        setIsLoading(false);
      }
    };

    startExam();
  }, [token, examId]);

  // Timer countdown
  useEffect(() => {
    if (remainingSeconds <= 0 || !examData) return;

    const timer = setInterval(() => {
      setRemainingSeconds(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [remainingSeconds > 0, examData]);

  // Auto-save every 30 seconds
  useEffect(() => {
    if (!examData || remainingSeconds <= 0) return;

    const autoSave = setInterval(() => {
      saveAnswers();
    }, 30000);

    return () => clearInterval(autoSave);
  }, [examData, answers, remainingSeconds]);

  const saveAnswers = useCallback(async () => {
    if (!token || !examData || isSaving) return;

    setIsSaving(true);
    try {
      const res = await fetch('/api/exams/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          attemptId: examData.attemptId,
          answers,
        }),
      });

      const data = await res.json();
      if (data.داده?.autoSubmitted) {
        router.push(`/portal/exam/results?attemptId=${examData.attemptId}`);
        return;
      }

      if (data.داده?.remainingSeconds !== undefined) {
        setRemainingSeconds(data.داده.remainingSeconds);
      }
      setLastSaveTime(new Date());
    } catch {
      // Silent fail for auto-save
    } finally {
      setIsSaving(false);
    }
  }, [token, examData, answers, isSaving, router]);

  const handleAutoSubmit = useCallback(async () => {
    if (!token || !examData) return;

    try {
      await fetch('/api/exams/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          attemptId: examData.attemptId,
          answers,
        }),
      });
    } catch {
      // ignore
    }
    router.push(`/portal/exam/results?attemptId=${examData.attemptId}`);
  }, [token, examData, answers, router]);

  const handleSubmit = async () => {
    if (!token || !examData) return;

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/exams/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          attemptId: examData.attemptId,
          answers,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        router.push(`/portal/exam/results?attemptId=${examData.attemptId}`);
      } else {
        setError(data.error || 'خطا در تحویل آزمون');
      }
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setIsSubmitting(false);
      setShowConfirmDialog(false);
    }
  };

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) {
      return `${toPersianNumber(h)}:${toPersianNumber(m.toString().padStart(2, '0'))}:${toPersianNumber(s.toString().padStart(2, '0'))}`;
    }
    return `${toPersianNumber(m.toString().padStart(2, '0'))}:${toPersianNumber(s.toString().padStart(2, '0'))}`;
  };

  if (isLoading) {
    return <ExamTakeSkeleton />;
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4" dir="rtl">
        <AlertTriangle className="h-16 w-16 text-amber-500" />
        <h2 className="text-xl font-bold text-gray-900">{error}</h2>
        <Button onClick={() => router.push('/portal/dashboard')} variant="outline">
          بازگشت به داشبورد
        </Button>
      </div>
    );
  }

  if (!examData) return null;

  const currentQuestion = examData.questions[currentQuestionIndex];
  const totalQuestions = examData.questions.length;
  const answeredCount = Object.keys(answers).filter(k => answers[k] && answers[k].trim() !== '').length;
  const progressPercent = totalQuestions > 0 ? (answeredCount / totalQuestions) * 100 : 0;
  const isLowTime = remainingSeconds < 300; // Less than 5 minutes

  return (
    <div className="max-w-4xl mx-auto space-y-4" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white/90 backdrop-blur-md border-b border-gray-100 -mx-4 lg:-mx-6 px-4 lg:px-6 py-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex-1 min-w-0">
            <h1 className="text-lg font-bold text-gray-900 truncate">{examData.exam.title}</h1>
            {examData.exam.programName && (
              <p className="text-xs text-gray-400 mt-0.5">{examData.exam.programName}</p>
            )}
          </div>
          <div className={`flex items-center gap-2 px-4 py-2 rounded-xl ${
            isLowTime ? 'bg-red-50 border border-red-200' : 'bg-teal-50 border border-teal-200'
          }`}>
            <Clock className={`h-4 w-4 ${isLowTime ? 'text-red-500' : 'text-teal-600'}`} />
            <span className={`font-mono font-bold text-sm ${isLowTime ? 'text-red-600' : 'text-teal-700'}`}>
              {formatTime(remainingSeconds)}
            </span>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-3">
          <Progress value={progressPercent} className="flex-1 h-2" />
          <span className="text-xs text-gray-500 whitespace-nowrap">
            {toPersianNumber(answeredCount)} / {toPersianNumber(totalQuestions)}
          </span>
        </div>
      </div>

      {/* Question Navigation */}
      <div className="flex gap-1.5 flex-wrap">
        {examData.questions.map((q, idx) => {
          const isAnswered = answers[q.id] && answers[q.id].trim() !== '';
          const isCurrent = idx === currentQuestionIndex;
          return (
            <button
              key={q.id}
              onClick={() => setCurrentQuestionIndex(idx)}
              className={`w-9 h-9 rounded-lg text-sm font-bold transition-all ${
                isCurrent
                  ? 'bg-teal-500 text-white shadow-md shadow-teal-500/30'
                  : isAnswered
                  ? 'bg-teal-100 text-teal-700 border border-teal-200'
                  : 'bg-gray-100 text-gray-500 border border-gray-200 hover:bg-gray-200'
              }`}
            >
              {toPersianNumber(idx + 1)}
            </button>
          );
        })}
      </div>

      {/* Current Question */}
      {currentQuestion && (
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <Badge variant="outline" className="text-xs border-teal-200 text-teal-600">
                سؤال {toPersianNumber(currentQuestionIndex + 1)} از {toPersianNumber(totalQuestions)}
              </Badge>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  {toPersianNumber(currentQuestion.points)} نمره
                </Badge>
                <Badge variant="outline" className={`text-xs ${
                  currentQuestion.difficulty === 'EASY' ? 'border-green-200 text-green-600' :
                  currentQuestion.difficulty === 'HARD' ? 'border-red-200 text-red-600' :
                  'border-amber-200 text-amber-600'
                }`}>
                  {currentQuestion.difficulty === 'EASY' ? 'آسان' :
                   currentQuestion.difficulty === 'HARD' ? 'سخت' : 'متوسط'}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="pb-2 border-b border-gray-100">
              <p className="text-base font-medium text-gray-900 leading-8 whitespace-pre-wrap">
                {currentQuestion.text}
              </p>
            </div>

            {/* Multiple Choice */}
            {currentQuestion.type === 'MULTIPLE_CHOICE' && currentQuestion.options && (() => {
              const normalized = normalizeOptions(currentQuestion.options);
              if (normalized.length === 0) return null;
              return (
                <RadioGroup
                  value={answers[currentQuestion.id] || ''}
                  onValueChange={(value) => {
                    setAnswers(prev => ({ ...prev, [currentQuestion.id]: value }));
                  }}
                  className="space-y-3 pt-2"
                >
                  {normalized.map((option, idx) => (
                    <Label
                      key={`${currentQuestion.id}-opt-${idx}`}
                      htmlFor={`option-${idx}`}
                      className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all block ${
                        answers[currentQuestion.id] === option.label
                          ? 'border-teal-400 bg-teal-50'
                          : 'border-gray-200 bg-white hover:border-gray-300'
                      }`}
                    >
                      <RadioGroupItem value={option.label} id={`option-${idx}`} />
                      <span className="flex-1 text-sm text-gray-800 leading-7">{option.text}</span>
                      <span className="text-xs font-bold text-gray-400 ml-2 shrink-0">{option.label}</span>
                    </Label>
                  ))}
                </RadioGroup>
              );
            })()}

            {/* True/False */}
            {currentQuestion.type === 'TRUE_FALSE' && (
              <RadioGroup
                value={answers[currentQuestion.id] || ''}
                onValueChange={(value) => {
                  setAnswers(prev => ({ ...prev, [currentQuestion.id]: value }));
                }}
                className="flex gap-4"
              >
                <Label
                  htmlFor="option-true"
                  className={`flex-1 flex items-center justify-center gap-2 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    answers[currentQuestion.id] === 'true'
                      ? 'border-green-400 bg-green-50'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <RadioGroupItem value="true" id="option-true" />
                  <CheckCircle2 className={`h-5 w-5 ${answers[currentQuestion.id] === 'true' ? 'text-green-500' : 'text-gray-400'}`} />
                  <span className="text-sm font-medium">صحیح</span>
                </Label>
                <Label
                  htmlFor="option-false"
                  className={`flex-1 flex items-center justify-center gap-2 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                    answers[currentQuestion.id] === 'false'
                      ? 'border-red-400 bg-red-50'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <RadioGroupItem value="false" id="option-false" />
                  <XCircle className={`h-5 w-5 ${answers[currentQuestion.id] === 'false' ? 'text-red-500' : 'text-gray-400'}`} />
                  <span className="text-sm font-medium">غلط</span>
                </Label>
              </RadioGroup>
            )}

            {/* Short Answer */}
            {currentQuestion.type === 'SHORT_ANSWER' && (
              <Textarea
                value={answers[currentQuestion.id] || ''}
                onChange={(e) => {
                  setAnswers(prev => ({ ...prev, [currentQuestion.id]: e.target.value }));
                }}
                placeholder="پاسخ خود را بنویسید..."
                className="min-h-[100px] text-base"
                dir="rtl"
              />
            )}
          </CardContent>
        </Card>
      )}

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between gap-3">
        <Button
          variant="outline"
          onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
          disabled={currentQuestionIndex === 0}
          className="gap-2"
        >
          <ChevronRight className="h-4 w-4" />
          قبلی
        </Button>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            onClick={saveAnswers}
            disabled={isSaving}
            className="gap-2 text-teal-600 border-teal-200 hover:bg-teal-50"
          >
            <Save className="h-4 w-4" />
            {isSaving ? 'در حال ذخیره...' : 'ذخیره'}
          </Button>
          {lastSaveTime && (
            <span className="text-xs text-gray-400">
              آخرین ذخیره: {lastSaveTime.toLocaleTimeString('fa-IR')}
            </span>
          )}
        </div>

        {currentQuestionIndex < totalQuestions - 1 ? (
          <Button
            onClick={() => setCurrentQuestionIndex(prev => Math.min(totalQuestions - 1, prev + 1))}
            className="gap-2 bg-teal-600 hover:bg-teal-700"
          >
            بعدی
            <ChevronLeft className="h-4 w-4" />
          </Button>
        ) : (
          <Button
            onClick={() => setShowConfirmDialog(true)}
            className="gap-2 bg-emerald-600 hover:bg-emerald-700"
          >
            <Send className="h-4 w-4" />
            تحویل آزمون
          </Button>
        )}
      </div>

      {/* Submit Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent dir="rtl" className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-center">تأیید تحویل آزمون</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="text-center space-y-2">
              <p className="text-sm text-gray-600">
                آیا از تحویل آزمون اطمینان دارید؟
              </p>
              {answeredCount < totalQuestions && (
                <div className="flex items-center justify-center gap-2 text-amber-600">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="text-sm">
                    {toPersianNumber(totalQuestions - answeredCount)} سؤال بی‌پاسخ
                  </span>
                </div>
              )}
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setShowConfirmDialog(false)}
              className="flex-1"
            >
              انصراف
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="flex-1 bg-emerald-600 hover:bg-emerald-700 gap-2"
            >
              {isSubmitting ? (
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              تحویل
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ExamTakeSkeleton() {
  return (
    <div className="max-w-4xl mx-auto space-y-4" dir="rtl">
      <Skeleton className="h-20 w-full rounded-xl" />
      <div className="flex gap-1.5 flex-wrap">
        {Array.from({ length: 10 }).map((_, i) => (
          <Skeleton key={i} className="w-9 h-9 rounded-lg" />
        ))}
      </div>
      <Skeleton className="h-64 w-full rounded-xl" />
      <Skeleton className="h-12 w-full rounded-xl" />
    </div>
  );
}

export default function ExamTakePage() {
  return (
    <Suspense fallback={<ExamTakeSkeleton />}>
      <ExamTakeContent />
    </Suspense>
  );
}
