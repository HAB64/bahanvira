'use client';

import { useEffect, useState } from 'react';
import { usePortalAuth } from '@/app/portal/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toPersianNumber, formatPrice } from '@/lib/persian';
import {
  GraduationCap,
  Receipt,
  Ticket,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  ClipboardCheck,
  Trophy,
  XCircle,
  PlayCircle,
  Eye,
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

interface DashboardData {
  user: {
    id: string;
    username: string;
    name: string;
    phone: string;
  };
  enrollments?: Array<{
    id: string;
    status: string;
    programName: string;
    totalHours: number;
    enrollmentDate: string;
    completionDate?: string | null;
    finalGrade?: number | null;
  }>;
  certificates?: Array<{
    id: string;
    certificateNo: string | null;
    status: string;
    programName: string;
    issueDate?: string | null;
  }>;
  payments?: Array<{
    id: string;
    amount: number;
    type: string;
    status: string;
    paidAt?: string | null;
  }>;
  upcomingSessions?: Array<{
    id: string;
    title: string;
    date: string;
    startTime: string;
    endTime: string;
    type: string;
    programName: string;
  }>;
  attendanceRate?: number;
  recentInvoices?: Array<{
    id: string;
    invoiceNumber: string;
    totalAmount: number;
    status: string;
    dueDate?: string | null;
    createdAt: string;
  }>;
  recentTickets?: Array<{
    id: string;
    subject: string;
    status: string;
    priority: string;
    category: string;
    responseCount: number;
    createdAt: string;
  }>;
  openTicketsCount?: number;
  openInvoicesCount?: number;
}

interface ExamAttempt {
  id: string;
  examId: string;
  examTitle: string;
  examType: string;
  programName: string | null;
  status: string;
  score: number | null;
  maxScore: number | null;
  percentage: number | null;
  isPassed: boolean | null;
  startedAt: string;
  submittedAt: string | null;
  timeSpentSec: number | null;
}

interface AvailableExam {
  id: string;
  title: string;
  type: string;
  durationMinutes: number;
  passingScore: number;
  maxAttempts: number;
  questionCount: number;
  programName: string | null;
  openAt: string | null;
  closeAt: string | null;
  attemptsUsed: number;
  hasInProgress: boolean;
  bestScore: number | null;
  bestIsPassed: boolean | null;
}

const enrollmentStatusMap: Record<string, { label: string; color: string }> = {
  ENROLLED: { label: 'فعال', color: 'bg-teal-100 text-teal-700' },
  COMPLETED: { label: 'تکمیل‌شده', color: 'bg-green-100 text-green-700' },
  DROPPED: { label: 'ترک‌شده', color: 'bg-red-100 text-red-700' },
  FAILED: { label: 'مردود', color: 'bg-orange-100 text-orange-700' },
};

const invoiceStatusMap: Record<string, { label: string; color: string }> = {
  DRAFT: { label: 'پیش‌نویس', color: 'bg-gray-100 text-gray-700' },
  SENT: { label: 'ارسال‌شده', color: 'bg-blue-100 text-blue-700' },
  PAID: { label: 'پرداخت‌شده', color: 'bg-green-100 text-green-700' },
  PARTIALLY_PAID: { label: 'پرداخت‌جزئی', color: 'bg-yellow-100 text-yellow-700' },
  CANCELLED: { label: 'لغوشده', color: 'bg-red-100 text-red-700' },
  REFUNDED: { label: 'بازپرداخت', color: 'bg-purple-100 text-purple-700' },
};

const ticketStatusMap: Record<string, { label: string; color: string }> = {
  OPEN: { label: 'باز', color: 'bg-blue-100 text-blue-700' },
  IN_PROGRESS: { label: 'در حال بررسی', color: 'bg-yellow-100 text-yellow-700' },
  WAITING_CUSTOMER: { label: 'منتظر پاسخ شما', color: 'bg-orange-100 text-orange-700' },
  RESOLVED: { label: 'حل‌شده', color: 'bg-green-100 text-green-700' },
  CLOSED: { label: 'بسته‌شده', color: 'bg-gray-100 text-gray-700' },
};

const examTypeMap: Record<string, string> = {
  QUIZ: 'کوییز',
  MIDTERM: 'میان‌ترم',
  FINAL: 'پایان‌ترم',
  DIAGNOSTIC: 'تشخیصی',
  PRACTICAL: 'عملی',
};

const attemptStatusMap: Record<string, { label: string; color: string }> = {
  IN_PROGRESS: { label: 'در حال انجام', color: 'bg-blue-100 text-blue-700' },
  SUBMITTED: { label: 'تحویل‌شده', color: 'bg-green-100 text-green-700' },
  TIMED_OUT: { label: 'اتمام زمان', color: 'bg-orange-100 text-orange-700' },
  AUTO_SUBMITTED: { label: 'تحویل خودکار', color: 'bg-amber-100 text-amber-700' },
};

function formatDate(dateStr: string): string {
  try {
    return new Date(dateStr).toLocaleDateString('fa-IR');
  } catch {
    return dateStr;
  }
}

export default function PortalDashboardPage() {
  const { user, token } = usePortalAuth();
  const router = useRouter();
  const [data, setData] = useState<DashboardData | null>(null);
  const [examAttempts, setExamAttempts] = useState<ExamAttempt[]>([]);
  const [availableExams, setAvailableExams] = useState<AvailableExam[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!token) return;

    const fetchDashboard = async () => {
      try {
        const res = await fetch('/api/portal/dashboard', {
          headers: { Authorization: `Bearer ${token}` },
        });
        const result = await res.json();
        if (res.ok && result.data) {
          setData(result.data);
        }
      } catch (error) {
        console.error('Dashboard fetch error:', error);
      }
    };

    const fetchExams = async () => {
      try {
        const res = await fetch('/api/exams/student', {
          headers: { Authorization: `Bearer ${token}` },
        });
        const result = await res.json();
        if (res.ok) {
          setExamAttempts(result.داده || []);
          setAvailableExams(result.آزمون‌های_فعال || []);
        }
      } catch (error) {
        console.error('Exams fetch error:', error);
      }
    };

    Promise.all([fetchDashboard(), fetchExams()]).finally(() => {
      setIsLoading(false);
    });
  }, [token]);

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  const enrollmentsCount = data?.enrollments?.length || 0;
  const openInvoices = data?.openInvoicesCount || 0;
  const openTickets = data?.openTicketsCount || 0;
  const totalExams = availableExams.length + examAttempts.length;

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            سلام، {data?.user?.name || user?.displayName || 'کاربر'} 👋
          </h1>
          <p className="text-gray-500 text-sm mt-1">به پورتال مشتریان خوش آمدید</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm bg-gradient-to-bl from-teal-50 to-white hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-gray-500 mb-1">تعداد دوره‌ها</p>
                <p className="text-2xl sm:text-3xl font-bold text-gray-900">{toPersianNumber(enrollmentsCount)}</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-teal-100 flex items-center justify-center">
                <GraduationCap className="h-5 w-5 sm:h-6 sm:w-6 text-teal-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm bg-gradient-to-bl from-emerald-50 to-white hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-gray-500 mb-1">آزمون‌ها</p>
                <p className="text-2xl sm:text-3xl font-bold text-gray-900">{toPersianNumber(totalExams)}</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                <ClipboardCheck className="h-5 w-5 sm:h-6 sm:w-6 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm bg-gradient-to-bl from-amber-50 to-white hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-gray-500 mb-1">فاکتورهای باز</p>
                <p className="text-2xl sm:text-3xl font-bold text-gray-900">{toPersianNumber(openInvoices)}</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-amber-100 flex items-center justify-center">
                <Receipt className="h-5 w-5 sm:h-6 sm:w-6 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm bg-gradient-to-bl from-purple-50 to-white hover:shadow-md transition-shadow">
          <CardContent className="p-4 sm:p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm text-gray-500 mb-1">تیکت‌های باز</p>
                <p className="text-2xl sm:text-3xl font-bold text-gray-900">{toPersianNumber(openTickets)}</p>
              </div>
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                <Ticket className="h-5 w-5 sm:h-6 sm:w-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attendance & Certificates (for KarAmuz) */}
      {data?.attendanceRate !== undefined && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-500">میزان حضور</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3">
                <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-l from-teal-400 to-emerald-500 rounded-full transition-all duration-500"
                    style={{ width: `${data.attendanceRate}%` }}
                  />
                </div>
                <span className="text-lg font-bold text-gray-900">
                  {toPersianNumber(data.attendanceRate)}٪
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-500">گواهینامه‌ها</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-green-500" />
                <span className="text-lg font-bold text-gray-900">
                  {toPersianNumber(data?.certificates?.length || 0)} گواهینامه
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tabbed Content */}
      <Tabs defaultValue="courses" dir="rtl" className="w-full">
        <TabsList className="flex flex-nowrap overflow-x-auto w-full justify-start gap-1 bg-gray-100/50 p-1 rounded-xl">
          <TabsTrigger value="courses" className="text-xs sm:text-sm whitespace-nowrap">
            دوره‌ها
          </TabsTrigger>
          <TabsTrigger value="exams" className="text-xs sm:text-sm whitespace-nowrap">
            آزمون‌ها
            {availableExams.length > 0 && (
              <Badge className="mr-1 h-5 w-5 p-0 flex items-center justify-center text-[10px] bg-emerald-500 text-white border-0">
                {toPersianNumber(availableExams.length)}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="certificates" className="text-xs sm:text-sm whitespace-nowrap">
            گواهینامه‌ها
          </TabsTrigger>
          <TabsTrigger value="invoices" className="text-xs sm:text-sm whitespace-nowrap">
            فاکتورها
          </TabsTrigger>
          <TabsTrigger value="tickets" className="text-xs sm:text-sm whitespace-nowrap">
            تیکت‌ها
          </TabsTrigger>
        </TabsList>

        {/* Courses Tab */}
        <TabsContent value="courses" className="mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Enrollments */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-bold text-gray-900">دوره‌های من</CardTitle>
                  {enrollmentsCount > 0 && (
                    <GraduationCap className="h-5 w-5 text-gray-400" />
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {data?.enrollments && data.enrollments.length > 0 ? (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {data.enrollments.map((enrollment) => {
                      const statusInfo = enrollmentStatusMap[enrollment.status] || { label: enrollment.status, color: 'bg-gray-100 text-gray-700' };
                      return (
                        <div key={enrollment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{enrollment.programName}</p>
                            <p className="text-xs text-gray-400 mt-0.5">
                              {toPersianNumber(enrollment.totalHours)} ساعت
                            </p>
                          </div>
                          <Badge className={`text-xs ${statusInfo.color} border-0`}>
                            {statusInfo.label}
                          </Badge>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <GraduationCap className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">هنوز دوره‌ای ثبت نشده است</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Upcoming Sessions */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold text-gray-900">جلسات آینده</CardTitle>
              </CardHeader>
              <CardContent>
                {data?.upcomingSessions && data.upcomingSessions.length > 0 ? (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {data.upcomingSessions.map((session) => (
                      <div key={session.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-xl">
                        <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Calendar className="h-5 w-5 text-teal-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{session.title}</p>
                          <p className="text-xs text-gray-400 mt-0.5">
                            {formatDate(session.date)} · {session.startTime} تا {session.endTime}
                          </p>
                          <Badge variant="outline" className="text-xs mt-1 border-teal-200 text-teal-600">
                            {session.type === 'THEORY' ? 'تئوری' : 'عملی'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">جلسه‌ای برنامه‌ریزی نشده است</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Exams Tab */}
        <TabsContent value="exams" className="mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Available Exams */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base font-bold text-gray-900">آزمون‌های فعال</CardTitle>
                  <ClipboardCheck className="h-5 w-5 text-gray-400" />
                </div>
              </CardHeader>
              <CardContent>
                {availableExams.length > 0 ? (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {availableExams.map((exam) => (
                      <div key={exam.id} className="p-4 bg-gray-50 rounded-xl space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{exam.title}</p>
                            <p className="text-xs text-gray-400 mt-0.5">
                              {exam.programName && `${exam.programName} · `}
                              {toPersianNumber(exam.questionCount)} سؤال · {toPersianNumber(exam.durationMinutes)} دقیقه
                            </p>
                          </div>
                          <Badge variant="outline" className="text-xs border-emerald-200 text-emerald-600 whitespace-nowrap">
                            {examTypeMap[exam.type] || exam.type}
                          </Badge>
                        </div>

                        {/* Best score if attempted before */}
                        {exam.bestScore !== null && (
                          <div className="flex items-center gap-2 text-xs">
                            {exam.bestIsPassed ? (
                              <Trophy className="h-3.5 w-3.5 text-emerald-500" />
                            ) : (
                              <XCircle className="h-3.5 w-3.5 text-red-400" />
                            )}
                            <span className="text-gray-500">
                              بهترین نمره: {toPersianNumber(Math.round(exam.bestScore))}٪
                              {exam.bestIsPassed ? ' (قبول)' : ' (مردود)'}
                            </span>
                          </div>
                        )}

                        {/* Attempt progress */}
                        <div className="flex items-center gap-2">
                          <Progress
                            value={(exam.attemptsUsed / exam.maxAttempts) * 100}
                            className="flex-1 h-1.5"
                          />
                          <span className="text-xs text-gray-400">
                            {toPersianNumber(exam.attemptsUsed)}/{toPersianNumber(exam.maxAttempts)} تلاش
                          </span>
                        </div>

                        <Button
                          size="sm"
                          onClick={() => router.push(`/portal/exam/take?examId=${exam.id}`)}
                          className="w-full gap-2 bg-emerald-600 hover:bg-emerald-700"
                        >
                          {exam.hasInProgress ? (
                            <>
                              <Eye className="h-4 w-4" />
                              ادامه آزمون
                            </>
                          ) : (
                            <>
                              <PlayCircle className="h-4 w-4" />
                              شروع آزمون
                            </>
                          )}
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <ClipboardCheck className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">آزمون فعالی موجود نیست</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Past Attempts */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-bold text-gray-900">سوابق آزمون‌ها</CardTitle>
              </CardHeader>
              <CardContent>
                {examAttempts.length > 0 ? (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {examAttempts.map((attempt) => {
                      const statusInfo = attemptStatusMap[attempt.status] || { label: attempt.status, color: 'bg-gray-100 text-gray-700' };
                      return (
                        <div
                          key={attempt.id}
                          className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100 transition-colors"
                          onClick={() => {
                            if (attempt.status !== 'IN_PROGRESS') {
                              router.push(`/portal/exam/results?attemptId=${attempt.id}`);
                            }
                          }}
                        >
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            attempt.isPassed ? 'bg-emerald-100' :
                            attempt.status === 'IN_PROGRESS' ? 'bg-blue-100' :
                            'bg-red-100'
                          }`}>
                            {attempt.isPassed ? (
                              <Trophy className="h-5 w-5 text-emerald-600" />
                            ) : attempt.status === 'IN_PROGRESS' ? (
                              <Clock className="h-5 w-5 text-blue-600" />
                            ) : (
                              <XCircle className="h-5 w-5 text-red-500" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">{attempt.examTitle}</p>
                            <p className="text-xs text-gray-400 mt-0.5">
                              {attempt.programName && `${attempt.programName} · `}
                              {formatDate(attempt.startedAt)}
                            </p>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            <Badge className={`text-xs ${statusInfo.color} border-0`}>
                              {statusInfo.label}
                            </Badge>
                            {attempt.percentage !== null && (
                              <span className={`text-xs font-bold ${
                                attempt.isPassed ? 'text-emerald-600' : 'text-red-500'
                              }`}>
                                {toPersianNumber(Math.round(attempt.percentage))}٪
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <ClipboardCheck className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">سابقه آزمونی ثبت نشده است</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Certificates Tab */}
        <TabsContent value="certificates" className="mt-4">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-base font-bold text-gray-900">گواهینامه‌ها</CardTitle>
            </CardHeader>
            <CardContent>
              {data?.certificates && data.certificates.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {data.certificates.map((cert) => (
                    <div key={cert.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center flex-shrink-0">
                          <CheckCircle2 className="h-5 w-5 text-green-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{cert.programName}</p>
                          {cert.certificateNo && (
                            <p className="text-xs text-gray-400 mt-0.5">
                              شماره: {cert.certificateNo}
                            </p>
                          )}
                        </div>
                      </div>
                      <Badge className={`text-xs border-0 ${
                        cert.status === 'ISSUED' ? 'bg-green-100 text-green-700' :
                        cert.status === 'EXAM_PASSED' ? 'bg-emerald-100 text-emerald-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {cert.status === 'ISSUED' ? 'صادرشده' :
                         cert.status === 'EXAM_PASSED' ? 'قبول آزمون' :
                         cert.status === 'EXAM_REGISTERED' ? 'ثبت‌نام آزمون' :
                         cert.status === 'EXAM_FAILED' ? 'مردود آزمون' :
                         'در حال بررسی'}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <CheckCircle2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">گواهینامه‌ای صادر نشده است</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Invoices Tab */}
        <TabsContent value="invoices" className="mt-4">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-bold text-gray-900">فاکتورهای اخیر</CardTitle>
                <Link href="/portal/invoices" className="text-xs text-teal-600 hover:text-teal-700 flex items-center gap-1">
                  مشاهده همه
                  <ArrowUpRight className="h-3 w-3" />
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              {data?.recentInvoices && data.recentInvoices.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {data.recentInvoices.map((inv) => {
                    const statusInfo = invoiceStatusMap[inv.status] || { label: inv.status, color: 'bg-gray-100 text-gray-700' };
                    return (
                      <div key={inv.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900">{inv.invoiceNumber}</p>
                          <p className="text-xs text-gray-400 mt-0.5">
                            {formatDate(inv.createdAt)}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-gray-900">
                            {formatPrice(inv.totalAmount)} ریال
                          </span>
                          <Badge className={`text-xs ${statusInfo.color} border-0`}>
                            {statusInfo.label}
                          </Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <Receipt className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">فاکتوری یافت نشد</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tickets Tab */}
        <TabsContent value="tickets" className="mt-4">
          <Card className="border-0 shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-bold text-gray-900">تیکت‌های اخیر</CardTitle>
                <Link href="/portal/tickets" className="text-xs text-teal-600 hover:text-teal-700 flex items-center gap-1">
                  مشاهده همه
                  <ArrowUpRight className="h-3 w-3" />
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              {data?.recentTickets && data.recentTickets.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {data.recentTickets.map((ticket) => {
                    const statusInfo = ticketStatusMap[ticket.status] || { label: ticket.status, color: 'bg-gray-100 text-gray-700' };
                    return (
                      <div key={ticket.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">{ticket.subject}</p>
                          <p className="text-xs text-gray-400 mt-0.5">
                            {formatDate(ticket.createdAt)} · {toPersianNumber(ticket.responseCount)} پاسخ
                          </p>
                        </div>
                        <Badge className={`text-xs ${statusInfo.color} border-0`}>
                          {statusInfo.label}
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400">
                  <AlertCircle className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">تیکتی ثبت نشده است</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div>
        <Skeleton className="h-8 w-48 mb-2" />
        <Skeleton className="h-4 w-32" />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => (
          <Skeleton key={i} className="h-28 rounded-xl" />
        ))}
      </div>
      <Skeleton className="h-12 w-full rounded-xl" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Skeleton className="h-64 rounded-xl" />
        <Skeleton className="h-64 rounded-xl" />
      </div>
    </div>
  );
}
