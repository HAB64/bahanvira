'use client';

import { useEffect, useState } from 'react';
import { usePortalAuth } from '@/app/portal/layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { User, Phone, Mail, MapPin, Lock, Save, CheckCircle2 } from 'lucide-react';

interface ProfileData {
  id: string;
  username: string;
  displayName: string;
  phone: string;
  email: string;
  address: string;
  nationalId: string;
  type: 'karAmuz' | 'lead';
}

export default function PortalProfilePage() {
  const { token, refreshUser } = usePortalAuth();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState('');

  // Editable fields
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');

  useEffect(() => {
    if (!token) return;

    const fetchProfile = async () => {
      try {
        const res = await fetch('/api/portal/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        if (res.ok && data.data) {
          setProfile(data.data);
          setPhone(data.data.phone || '');
          setEmail(data.data.email || '');
          setAddress(data.data.address || '');
        }
      } catch (error) {
        console.error('Profile fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProfile();
  }, [token]);

  const handleSaveProfile = async () => {
    if (!token) return;
    setIsSaving(true);
    setSaveMessage('');

    try {
      const res = await fetch('/api/portal/profile', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ phone, email, address }),
      });

      const data = await res.json();

      if (res.ok) {
        setSaveMessage('پروفایل با موفقیت ذخیره شد');
        await refreshUser();
        setTimeout(() => setSaveMessage(''), 3000);
      } else {
        setSaveMessage(data.error || 'خطا در ذخیره پروفایل');
      }
    } catch {
      setSaveMessage('خطا در اتصال به سرور');
    } finally {
      setIsSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    if (newPassword !== confirmPassword) {
      setPasswordMessage('رمز عبور جدید و تکرار آن مطابقت ندارند');
      return;
    }

    if (newPassword.length < 6) {
      setPasswordMessage('رمز عبور جدید باید حداقل ۶ کاراکتر باشد');
      return;
    }

    setIsChangingPassword(true);
    setPasswordMessage('');

    try {
      const res = await fetch('/api/portal/profile/password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });

      const data = await res.json();

      if (res.ok) {
        setPasswordMessage('رمز عبور با موفقیت تغییر کرد');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        setTimeout(() => setPasswordMessage(''), 3000);
      } else {
        setPasswordMessage(data.error || 'خطا در تغییر رمز عبور');
      }
    } catch {
      setPasswordMessage('خطا در اتصال به سرور');
    } finally {
      setIsChangingPassword(false);
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-40 mb-2" />
        <Skeleton className="h-4 w-60" />
        <Skeleton className="h-96 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">پروفایل من</h1>
        <p className="text-gray-500 text-sm mt-1">اطلاعات حساب کاربری خود را مشاهده و ویرایش کنید</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Info */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base font-bold text-gray-900">اطلاعات شخصی</CardTitle>
            <CardDescription>اطلاعات پایه حساب کاربری شما</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Read-only fields */}
            <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-xl">
              <div>
                <p className="text-xs text-gray-400 mb-1">نام و نام خانوادگی</p>
                <p className="text-sm font-medium text-gray-900">{profile?.displayName}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 mb-1">نام کاربری</p>
                <p className="text-sm font-medium text-gray-900">@{profile?.username}</p>
              </div>
              {profile?.nationalId && (
                <div>
                  <p className="text-xs text-gray-400 mb-1">کد ملی</p>
                  <p className="text-sm font-medium text-gray-900">{profile.nationalId}</p>
                </div>
              )}
              <div>
                <p className="text-xs text-gray-400 mb-1">نوع حساب</p>
                <Badge className="border-0 bg-teal-100 text-teal-700">
                  {profile?.type === 'karAmuz' ? 'کارآموز' : 'مشتری'}
                </Badge>
              </div>
            </div>

            <Separator />

            {/* Editable fields */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-gray-700 flex items-center gap-2">
                  <Phone className="h-4 w-4 text-gray-400" />
                  شماره تماس
                </Label>
                <Input
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="h-11 bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400"
                  placeholder="شماره تماس"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-700 flex items-center gap-2">
                  <Mail className="h-4 w-4 text-gray-400" />
                  ایمیل
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11 bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400"
                  placeholder="آدرس ایمیل"
                  dir="ltr"
                />
              </div>

              {profile?.type === 'karAmuz' && (
                <div className="space-y-2">
                  <Label htmlFor="address" className="text-gray-700 flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-gray-400" />
                    آدرس
                  </Label>
                  <Input
                    id="address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="h-11 bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400"
                    placeholder="آدرس محل سکونت"
                  />
                </div>
              )}
            </div>

            {saveMessage && (
              <Alert className={saveMessage.includes('موفقیت') ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
                <CheckCircle2 className={`h-4 w-4 ${saveMessage.includes('موفقیت') ? 'text-green-600' : 'text-red-600'}`} />
                <AlertDescription className={saveMessage.includes('موفقیت') ? 'text-green-700' : 'text-red-700'}>
                  {saveMessage}
                </AlertDescription>
              </Alert>
            )}

            <Button
              onClick={handleSaveProfile}
              disabled={isSaving}
              className="w-full h-11 bg-teal-600 hover:bg-teal-700 text-white"
            >
              {isSaving ? (
                <div className="flex items-center gap-2">
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  <span>در حال ذخیره...</span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Save className="h-4 w-4" />
                  <span>ذخیره تغییرات</span>
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Change Password */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-base font-bold text-gray-900">تغییر رمز عبور</CardTitle>
            <CardDescription>رمز عبور حساب کاربری خود را تغییر دهید</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword" className="text-gray-700 flex items-center gap-2">
                  <Lock className="h-4 w-4 text-gray-400" />
                  رمز عبور فعلی
                </Label>
                <Input
                  id="currentPassword"
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="h-11 bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400"
                  placeholder="رمز عبور فعلی خود را وارد کنید"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPassword" className="text-gray-700 flex items-center gap-2">
                  <Lock className="h-4 w-4 text-gray-400" />
                  رمز عبور جدید
                </Label>
                <Input
                  id="newPassword"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="h-11 bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400"
                  placeholder="رمز عبور جدید (حداقل ۶ کاراکتر)"
                  required
                  minLength={6}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-gray-700 flex items-center gap-2">
                  <Lock className="h-4 w-4 text-gray-400" />
                  تکرار رمز عبور جدید
                </Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="h-11 bg-gray-50 border-gray-200 focus:border-teal-400 focus:ring-teal-400"
                  placeholder="رمز عبور جدید را مجدداً وارد کنید"
                  required
                  minLength={6}
                />
              </div>

              {passwordMessage && (
                <Alert className={passwordMessage.includes('موفقیت') ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
                  <CheckCircle2 className={`h-4 w-4 ${passwordMessage.includes('موفقیت') ? 'text-green-600' : 'text-red-600'}`} />
                  <AlertDescription className={passwordMessage.includes('موفقیت') ? 'text-green-700' : 'text-red-700'}>
                    {passwordMessage}
                  </AlertDescription>
                </Alert>
              )}

              <Button
                type="submit"
                disabled={isChangingPassword}
                className="w-full h-11 bg-gray-900 hover:bg-gray-800 text-white"
              >
                {isChangingPassword ? (
                  <div className="flex items-center gap-2">
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    <span>در حال تغییر...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Lock className="h-4 w-4" />
                    <span>تغییر رمز عبور</span>
                  </div>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
