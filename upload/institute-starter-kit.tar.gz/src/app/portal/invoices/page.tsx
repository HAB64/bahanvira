'use client';

import { useEffect, useState } from 'react';
import { usePortalAuth } from '@/app/portal/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { toPersianNumber, formatPrice } from '@/lib/persian';
import {
  Receipt,
  FileText,
  Wallet,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Eye,
} from 'lucide-react';

interface Invoice {
  id: string;
  invoiceNumber: string;
  items: unknown;
  subtotal: number;
  discountPct: number;
  discountAmount: number;
  taxAmount: number;
  totalAmount: number;
  status: string;
  issuedAt: string | null;
  dueDate: string | null;
  paidAmount: number;
  notes: string | null;
  createdAt: string;
}

interface InvoiceSummary {
  totalInvoices: number;
  totalAmount: number;
  totalPaid: number;
  totalRemaining: number;
  openInvoices: number;
}

const invoiceStatusMap: Record<string, { label: string; color: string; icon?: React.ReactNode }> = {
  DRAFT: { label: 'پیش‌نویس', color: 'bg-gray-100 text-gray-700' },
  SENT: { label: 'ارسال‌شده', color: 'bg-blue-100 text-blue-700' },
  PAID: { label: 'پرداخت‌شده', color: 'bg-green-100 text-green-700' },
  PARTIALLY_PAID: { label: 'پرداخت‌جزئی', color: 'bg-yellow-100 text-yellow-700' },
  CANCELLED: { label: 'لغوشده', color: 'bg-red-100 text-red-700' },
  REFUNDED: { label: 'بازپرداخت', color: 'bg-purple-100 text-purple-700' },
};

function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  try {
    return new Date(dateStr).toLocaleDateString('fa-IR');
  } catch {
    return dateStr;
  }
}

export default function PortalInvoicesPage() {
  const { token } = usePortalAuth();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [summary, setSummary] = useState<InvoiceSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('');

  useEffect(() => {
    if (!token) return;

    const fetchInvoices = async () => {
      try {
        const params = new URLSearchParams();
        if (statusFilter) params.set('status', statusFilter);

        const res = await fetch(`/api/portal/invoices?${params.toString()}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        if (res.ok) {
          setInvoices(data.data || []);
          setSummary(data.summary || null);
        }
      } catch (error) {
        console.error('Invoices fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchInvoices();
  }, [token, statusFilter]);

  const openDetail = (invoice: Invoice) => {
    setSelectedInvoice(invoice);
    setDetailOpen(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-40 mb-2" />
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-24 rounded-xl" />)}
        </div>
        <Skeleton className="h-96 rounded-xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">فاکتورها</h1>
        <p className="text-gray-500 text-sm mt-1">مشاهده و پیگیری فاکتورهای شما</p>
      </div>

      {/* Summary Cards */}
      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <FileText className="h-4 w-4 text-gray-400" />
                <span className="text-xs text-gray-500">کل فاکتورها</span>
              </div>
              <p className="text-xl font-bold text-gray-900">{toPersianNumber(summary.totalInvoices)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Wallet className="h-4 w-4 text-green-500" />
                <span className="text-xs text-gray-500">پرداخت‌شده</span>
              </div>
              <p className="text-lg font-bold text-green-600">{formatPrice(summary.totalPaid)} <span className="text-xs font-normal">ریال</span></p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                <span className="text-xs text-gray-500">مانده</span>
              </div>
              <p className="text-lg font-bold text-amber-600">{formatPrice(summary.totalRemaining)} <span className="text-xs font-normal">ریال</span></p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Receipt className="h-4 w-4 text-blue-500" />
                <span className="text-xs text-gray-500">باز</span>
              </div>
              <p className="text-xl font-bold text-blue-600">{toPersianNumber(summary.openInvoices)}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-sm text-gray-500">فیلتر:</span>
        {[
          { value: '', label: 'همه' },
          { value: 'DRAFT', label: 'پیش‌نویس' },
          { value: 'SENT', label: 'ارسال‌شده' },
          { value: 'PAID', label: 'پرداخت‌شده' },
          { value: 'PARTIALLY_PAID', label: 'پرداخت‌جزئی' },
          { value: 'CANCELLED', label: 'لغوشده' },
        ].map(filter => (
          <Button
            key={filter.value}
            variant={statusFilter === filter.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => setStatusFilter(filter.value)}
            className={`h-8 text-xs rounded-lg ${
              statusFilter === filter.value
                ? 'bg-teal-600 hover:bg-teal-700 text-white'
                : 'border-gray-200 text-gray-600 hover:text-gray-900'
            }`}
          >
            {filter.label}
          </Button>
        ))}
      </div>

      {/* Invoices List */}
      <Card className="border-0 shadow-sm">
        <CardContent className="p-0">
          {invoices.length > 0 ? (
            <div className="divide-y divide-gray-50">
              {/* Table header - hidden on mobile */}
              <div className="hidden sm:grid sm:grid-cols-12 gap-4 px-5 py-3 bg-gray-50/50 text-xs text-gray-400 font-medium">
                <div className="col-span-3">شماره فاکتور</div>
                <div className="col-span-2">تاریخ صدور</div>
                <div className="col-span-2">سررسید</div>
                <div className="col-span-2 text-left">مبلغ کل</div>
                <div className="col-span-2">وضعیت</div>
                <div className="col-span-1"></div>
              </div>

              {invoices.map((invoice) => {
                const statusInfo = invoiceStatusMap[invoice.status] || { label: invoice.status, color: 'bg-gray-100 text-gray-700' };
                return (
                  <div
                    key={invoice.id}
                    className="grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-4 px-5 py-4 hover:bg-gray-50/50 transition-colors cursor-pointer"
                    onClick={() => openDetail(invoice)}
                  >
                    <div className="sm:col-span-3">
                      <span className="sm:hidden text-xs text-gray-400">شماره: </span>
                      <span className="text-sm font-medium text-gray-900">{invoice.invoiceNumber}</span>
                    </div>
                    <div className="sm:col-span-2">
                      <span className="sm:hidden text-xs text-gray-400">تاریخ: </span>
                      <span className="text-sm text-gray-600">{formatDate(invoice.issuedAt || invoice.createdAt)}</span>
                    </div>
                    <div className="sm:col-span-2">
                      <span className="sm:hidden text-xs text-gray-400">سررسید: </span>
                      <span className="text-sm text-gray-600">{formatDate(invoice.dueDate)}</span>
                    </div>
                    <div className="sm:col-span-2">
                      <span className="sm:hidden text-xs text-gray-400">مبلغ: </span>
                      <span className="text-sm font-bold text-gray-900 sm:float-left">
                        {formatPrice(invoice.totalAmount)} <span className="text-xs font-normal text-gray-400">ریال</span>
                      </span>
                    </div>
                    <div className="sm:col-span-2">
                      <Badge className={`text-xs ${statusInfo.color} border-0`}>
                        {statusInfo.label}
                      </Badge>
                    </div>
                    <div className="sm:col-span-1 flex justify-end">
                      <Eye className="h-4 w-4 text-gray-400 hover:text-teal-600 transition-colors" />
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-400">
              <Receipt className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p className="text-sm">فاکتوری یافت نشد</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invoice Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Receipt className="h-5 w-5 text-teal-600" />
              جزئیات فاکتور
            </DialogTitle>
          </DialogHeader>

          {selectedInvoice && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-xl">
                <div>
                  <p className="text-xs text-gray-400">شماره فاکتور</p>
                  <p className="text-sm font-bold text-gray-900">{selectedInvoice.invoiceNumber}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">وضعیت</p>
                  <Badge className={`text-xs ${invoiceStatusMap[selectedInvoice.status]?.color || 'bg-gray-100 text-gray-700'} border-0`}>
                    {invoiceStatusMap[selectedInvoice.status]?.label || selectedInvoice.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-xs text-gray-400">تاریخ صدور</p>
                  <p className="text-sm text-gray-700">{formatDate(selectedInvoice.issuedAt || selectedInvoice.createdAt)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">سررسید</p>
                  <p className="text-sm text-gray-700">{formatDate(selectedInvoice.dueDate)}</p>
                </div>
              </div>

              <Separator />

              {/* Items */}
              <div>
                <p className="text-sm font-medium text-gray-700 mb-2">آیتم‌ها</p>
                {Array.isArray(selectedInvoice.items) && (selectedInvoice.items as Array<{ title?: string; description?: string; quantity?: number; unitPrice?: number; total?: number }>).map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                    <div>
                      <p className="text-sm text-gray-900">{item.title || `آیتم ${idx + 1}`}</p>
                      {item.description && <p className="text-xs text-gray-400">{item.description}</p>}
                    </div>
                    <p className="text-sm font-medium text-gray-700">
                      {formatPrice(item.total || 0)} ریال
                    </p>
                  </div>
                ))}
              </div>

              <Separator />

              {/* Totals */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">جمع کل</span>
                  <span className="text-gray-700">{formatPrice(selectedInvoice.subtotal)} ریال</span>
                </div>
                {selectedInvoice.discountAmount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">تخفیف ({toPersianNumber(selectedInvoice.discountPct)}٪)</span>
                    <span className="text-green-600">-{formatPrice(selectedInvoice.discountAmount)} ریال</span>
                  </div>
                )}
                {selectedInvoice.taxAmount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">مالیات</span>
                    <span className="text-gray-700">{formatPrice(selectedInvoice.taxAmount)} ریال</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between text-sm font-bold">
                  <span className="text-gray-900">مبلغ نهایی</span>
                  <span className="text-gray-900">{formatPrice(selectedInvoice.totalAmount)} ریال</span>
                </div>
                {selectedInvoice.paidAmount > 0 && (
                  <>
                    <div className="flex justify-between text-sm">
                      <span className="text-green-600">پرداخت‌شده</span>
                      <span className="text-green-600">{formatPrice(selectedInvoice.paidAmount)} ریال</span>
                    </div>
                    <div className="flex justify-between text-sm font-bold">
                      <span className="text-amber-600">مانده</span>
                      <span className="text-amber-600">{formatPrice(selectedInvoice.totalAmount - selectedInvoice.paidAmount)} ریال</span>
                    </div>
                  </>
                )}
              </div>

              {selectedInvoice.notes && (
                <>
                  <Separator />
                  <div>
                    <p className="text-xs text-gray-400 mb-1">یادداشت</p>
                    <p className="text-sm text-gray-600">{selectedInvoice.notes}</p>
                  </div>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
