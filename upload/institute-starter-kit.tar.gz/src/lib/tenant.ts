import { db } from '@/lib/db';
import { headers } from 'next/headers';

// ─── Tenant Context ───

export interface TenantContext {
  id: string;
  name: string;
  slug: string;
  domain: string | null;
  primaryColor: string;
  plan: string;
  status: string;
  locale: string;
  currency: string;
  timezone: string;
  parentId: string | null;
  maxUsers: number;
  maxStorage: number;
  maxApiCalls: number;
}

// ─── Tenant Resolution ───

/**
 * Resolve tenant from request headers.
 * Priority:
 * 1. X-Tenant-Slug header (for API requests)
 * 2. X-Tenant-Domain header (for custom domain requests)
 * 3. Default tenant (slug = "default")
 */
export async function resolveTenant(): Promise<TenantContext | null> {
  try {
    const headersList = await headers();
    const tenantSlug = headersList.get('x-tenant-slug');
    const tenantDomain = headersList.get('x-tenant-domain');

    let tenant = null;

    if (tenantSlug) {
      tenant = await db.tenant.findUnique({
        where: { slug: tenantSlug },
      });
    } else if (tenantDomain) {
      tenant = await db.tenant.findFirst({
        where: { domain: tenantDomain },
      });
    }

    // Fallback to default tenant
    if (!tenant) {
      tenant = await db.tenant.findUnique({
        where: { slug: 'default' },
      });
    }

    if (!tenant) return null;

    return {
      id: tenant.id,
      name: tenant.name,
      slug: tenant.slug,
      domain: tenant.domain,
      primaryColor: tenant.primaryColor,
      plan: tenant.plan,
      status: tenant.status,
      locale: tenant.locale,
      currency: tenant.currency,
      timezone: tenant.timezone,
      parentId: tenant.parentId,
      maxUsers: tenant.maxUsers,
      maxStorage: tenant.maxStorage,
      maxApiCalls: tenant.maxApiCalls,
    };
  } catch {
    return null;
  }
}

/**
 * Get tenant by ID with full context
 */
export async function getTenantById(id: string): Promise<TenantContext | null> {
  try {
    const tenant = await db.tenant.findUnique({ where: { id } });
    if (!tenant) return null;

    return {
      id: tenant.id,
      name: tenant.name,
      slug: tenant.slug,
      domain: tenant.domain,
      primaryColor: tenant.primaryColor,
      plan: tenant.plan,
      status: tenant.status,
      locale: tenant.locale,
      currency: tenant.currency,
      timezone: tenant.timezone,
      parentId: tenant.parentId,
      maxUsers: tenant.maxUsers,
      maxStorage: tenant.maxStorage,
      maxApiCalls: tenant.maxApiCalls,
    };
  } catch {
    return null;
  }
}

/**
 * Get White-Label config for a tenant
 */
export async function getWhiteLabelConfig(tenantId: string) {
  try {
    return await db.whiteLabelConfig.findUnique({
      where: { tenantId },
    });
  } catch {
    return null;
  }
}

// ─── Tenant Quota Check ───

export async function checkTenantQuota(
  tenantId: string,
  resourceType: 'users' | 'storage' | 'apiCalls'
): Promise<{ allowed: boolean; current: number; max: number }> {
  const tenant = await db.tenant.findUnique({ where: { id: tenantId } });
  if (!tenant) return { allowed: false, current: 0, max: 0 };

  const now = new Date();
  const period = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  switch (resourceType) {
    case 'users': {
      const userCount = await db.adminUser.count();
      return {
        allowed: userCount < tenant.maxUsers,
        current: userCount,
        max: tenant.maxUsers,
      };
    }
    case 'apiCalls': {
      const usageLog = await db.tenantUsageLog.findFirst({
        where: { tenantId, resourceType: 'API_CALL', period },
      });
      const current = usageLog?.quantity ?? 0;
      return {
        allowed: current < tenant.maxApiCalls,
        current,
        max: tenant.maxApiCalls,
      };
    }
    case 'storage': {
      const usageLog = await db.tenantUsageLog.findFirst({
        where: { tenantId, resourceType: 'STORAGE', period },
      });
      const current = usageLog?.quantity ?? 0;
      return {
        allowed: current < tenant.maxStorage,
        current,
        max: tenant.maxStorage,
      };
    }
    default:
      return { allowed: false, current: 0, max: 0 };
  }
}

// ─── Tenant Usage Logging ───

export async function logTenantUsage(
  tenantId: string,
  resourceType: string,
  quantity: number = 1
) {
  const now = new Date();
  const period = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  const existing = await db.tenantUsageLog.findFirst({
    where: { tenantId, resourceType, period },
  });

  if (existing) {
    await db.tenantUsageLog.update({
      where: { id: existing.id },
      data: { quantity: existing.quantity + quantity },
    });
  } else {
    await db.tenantUsageLog.create({
      data: { tenantId, resourceType, quantity, period },
    });
  }
}

// ─── Plan Limits ───

export const PLAN_LIMITS = {
  BASIC: {
    maxUsers: 50,
    maxStorage: 1024,  // MB
    maxApiCalls: 10000,
    price: 0,
    name: 'پایه',
  },
  PROFESSIONAL: {
    maxUsers: 200,
    maxStorage: 10240,  // MB
    maxApiCalls: 100000,
    price: 2500000,  // ریال
    name: 'حرفه‌ای',
  },
  ENTERPRISE: {
    maxUsers: -1,  // unlimited
    maxStorage: -1,
    maxApiCalls: -1,
    price: 10000000,  // ریال
    name: 'سازمانی',
  },
} as const;

export type PlanType = keyof typeof PLAN_LIMITS;
