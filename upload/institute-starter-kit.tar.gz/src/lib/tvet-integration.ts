/**
 * TVET Integration Engine — Sync data with فنی‌وحرفه‌ای (TVET) system.
 *
 * This is a simulated implementation with proper data structures.
 * In production, this would connect to the actual TVET API.
 *
 * Key functions:
 * - syncSkillProgram: Sync program data to TVET format
 * - syncCertificate: Issue certificate via TVET
 * - syncAttendance: Sync attendance records
 * - getSyncStatus: Check sync status
 * - retryFailedSync: Retry a failed sync
 * - getTVETReport: Get TVET compliance report
 */

import { db } from '@/lib/db';

// ────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────

export interface TVETSyncResult {
  syncId: string;
  entityType: string;
  entityId: string;
  status: 'PENDING' | 'SYNCED' | 'FAILED' | 'CONFLICT';
  tvetCode: string | null;
  errorMessage: string | null;
  syncedAt: Date | null;
}

export interface TVETSkillProgramData {
  code: string;
  name: string;
  description: string;
  totalHours: number;
  theoryHours: number;
  practicalHours: number;
  level: string;
  instructorName: string;
  cluster: string;
  capacity: number;
  minAttendancePct: number;
}

export interface TVETCertificateData {
  certificateNo: string;
  karAmuzNationalId: string;
  karAmuzFirstName: string;
  karAmuzLastName: string;
  karAmuzFatherName: string;
  programCode: string;
  programName: string;
  issueDate: string;
  finalGrade: number;
  attendancePct: number;
}

export interface TVETAttendanceData {
  programCode: string;
  sessionDate: string;
  sessionType: string;
  startTime: string;
  endTime: string;
  instructorName: string;
  attendees: Array<{
    nationalId: string;
    firstName: string;
    lastName: string;
    status: string;
    hours: number;
  }>;
}

export interface TVETReport {
  totalPrograms: number;
  syncedPrograms: number;
  pendingPrograms: number;
  failedPrograms: number;
  totalCertificates: number;
  syncedCertificates: number;
  pendingCertificates: number;
  failedCertificates: number;
  totalAttendance: number;
  syncedAttendance: number;
  pendingAttendance: number;
  failedAttendance: number;
  overallCompliance: number; // percentage
  lastSyncAt: Date | null;
  failedSyncs: Array<{
    id: string;
    entityType: string;
    entityId: string;
    errorMessage: string;
    lastSyncAt: string | null;
  }>;
}

// ────────────────────────────────────────────────
// Simulated TVET API
// ────────────────────────────────────────────────

/**
 * Simulated TVET API call.
 * In production, this would make an actual HTTP request to the TVET system.
 * Returns success ~80% of the time for simulation purposes.
 */
async function simulateTVETApiCall(
  action: string,
  data: unknown,
): Promise<{ success: boolean; tvetCode: string | null; errorMessage: string | null }> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 100));

  // Simulate 80% success rate
  const isSuccess = Math.random() > 0.2;

  if (isSuccess) {
    // Generate a simulated TVET code
    const tvetCode = `TVET-${action.substring(0, 3).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
    return { success: true, tvetCode, errorMessage: null };
  }

  // Simulated errors
  const errors = [
    'Connection timeout to TVET server',
    'Invalid program code format',
    'Duplicate record exists in TVET system',
    'Authentication failed with TVET service',
    'TVET server maintenance in progress',
  ];
  const errorMessage = errors[Math.floor(Math.random() * errors.length)];
  return { success: false, tvetCode: null, errorMessage };
}

// ────────────────────────────────────────────────
// syncSkillProgram
// ────────────────────────────────────────────────

export async function syncSkillProgram(skillProgramId: string): Promise<TVETSyncResult> {
  // Fetch skill program
  const program = await db.skillProgram.findUnique({
    where: { id: skillProgramId },
  });

  if (!program) {
    throw new Error(`Skill program not found: ${skillProgramId}`);
  }

  // Prepare data in TVET standard format
  const tvetData: TVETSkillProgramData = {
    code: program.code ?? '',
    name: program.name,
    description: program.description ?? '',
    totalHours: program.totalHours,
    theoryHours: program.theoryHours,
    practicalHours: program.practicalHours,
    level: program.level ?? 'مبتدی',
    instructorName: program.instructorName ?? '',
    cluster: program.cluster ?? '',
    capacity: program.capacity ?? 0,
    minAttendancePct: program.minAttendancePct,
  };

  // Call simulated TVET API
  const result = await simulateTVETApiCall('SYNC_PROGRAM', tvetData);

  // Create/update TVETSync record
  const sync = await db.tVETSync.upsert({
    where: {
      entityType_entityId: {
        entityType: 'SKILL_PROGRAM',
        entityId: skillProgramId,
      },
    },
    create: {
      entityType: 'SKILL_PROGRAM',
      entityId: skillProgramId,
      tvetCode: result.tvetCode,
      syncStatus: result.success ? 'SYNCED' : 'FAILED',
      syncData: tvetData as never,
      errorMessage: result.errorMessage,
      lastSyncAt: result.success ? new Date() : null,
    },
    update: {
      tvetCode: result.tvetCode ?? undefined,
      syncStatus: result.success ? 'SYNCED' : 'FAILED',
      syncData: tvetData as never,
      errorMessage: result.errorMessage,
      lastSyncAt: result.success ? new Date() : undefined,
    },
  });

  return {
    syncId: sync.id,
    entityType: 'SKILL_PROGRAM',
    entityId: skillProgramId,
    status: sync.syncStatus as TVETSyncResult['status'],
    tvetCode: sync.tvetCode,
    errorMessage: sync.errorMessage,
    syncedAt: sync.lastSyncAt,
  };
}

// ────────────────────────────────────────────────
// syncCertificate
// ────────────────────────────────────────────────

export async function syncCertificate(certificateId: string): Promise<TVETSyncResult> {
  // Fetch certificate with related data
  const certificate = await db.certificate.findUnique({
    where: { id: certificateId },
    include: {
      karAmuz: { select: { nationalId: true, firstName: true, lastName: true, fatherName: true } },
      skillProgram: { select: { code: true, name: true } },
    },
  });

  if (!certificate) {
    throw new Error(`Certificate not found: ${certificateId}`);
  }

  if (!certificate.karAmuz) {
    throw new Error('Certificate has no associated KarAmuz');
  }

  // Calculate attendance percentage
  const attendances = await db.attendance.findMany({
    where: {
      karAmuzId: certificate.karAmuzId,
      session: { skillProgramId: certificate.skillProgramId },
    },
  });

  const totalSessions = attendances.length;
  const presentSessions = attendances.filter(
    (a) => a.status === 'PRESENT' || a.status === 'LATE',
  ).length;
  const attendancePct = totalSessions > 0 ? (presentSessions / totalSessions) * 100 : 0;

  // Get final grade from enrollment
  const enrollment = await db.enrollment.findFirst({
    where: {
      karAmuzId: certificate.karAmuzId,
      skillProgramId: certificate.skillProgramId,
    },
  });

  // Prepare certificate data in TVET format
  const tvetData: TVETCertificateData = {
    certificateNo: certificate.certificateNo ?? '',
    karAmuzNationalId: certificate.karAmuz.nationalId,
    karAmuzFirstName: certificate.karAmuz.firstName,
    karAmuzLastName: certificate.karAmuz.lastName,
    karAmuzFatherName: certificate.karAmuz.fatherName ?? '',
    programCode: certificate.skillProgram.code ?? '',
    programName: certificate.skillProgram.name,
    issueDate: certificate.issueDate?.toISOString() ?? new Date().toISOString(),
    finalGrade: enrollment?.finalGrade ?? 0,
    attendancePct: Math.round(attendancePct * 100) / 100,
  };

  // Call simulated TVET API
  const result = await simulateTVETApiCall('ISSUE_CERT', tvetData);

  // Create/update TVETSync record
  const sync = await db.tVETSync.upsert({
    where: {
      entityType_entityId: {
        entityType: 'CERTIFICATE',
        entityId: certificateId,
      },
    },
    create: {
      entityType: 'CERTIFICATE',
      entityId: certificateId,
      tvetCode: result.tvetCode,
      syncStatus: result.success ? 'SYNCED' : 'FAILED',
      syncData: tvetData as never,
      errorMessage: result.errorMessage,
      lastSyncAt: result.success ? new Date() : null,
    },
    update: {
      tvetCode: result.tvetCode ?? undefined,
      syncStatus: result.success ? 'SYNCED' : 'FAILED',
      syncData: tvetData as never,
      errorMessage: result.errorMessage,
      lastSyncAt: result.success ? new Date() : undefined,
    },
  });

  return {
    syncId: sync.id,
    entityType: 'CERTIFICATE',
    entityId: certificateId,
    status: sync.syncStatus as TVETSyncResult['status'],
    tvetCode: sync.tvetCode,
    errorMessage: sync.errorMessage,
    syncedAt: sync.lastSyncAt,
  };
}

// ────────────────────────────────────────────────
// syncAttendance
// ────────────────────────────────────────────────

export async function syncAttendance(
  skillProgramId: string,
  sessionId: string,
): Promise<TVETSyncResult> {
  // Fetch session with attendances
  const sessionData = await db.session.findUnique({
    where: { id: sessionId },
    include: {
      attendances: {
        include: {
          karAmuz: {
            select: { nationalId: true, firstName: true, lastName: true },
          },
        },
      },
      skillProgram: { select: { code: true, name: true } },
    },
  });

  if (!sessionData) {
    throw new Error(`Session not found: ${sessionId}`);
  }

  // Prepare attendance data in TVET format
  const tvetData: TVETAttendanceData = {
    programCode: sessionData.skillProgram.code ?? '',
    sessionDate: sessionData.date.toISOString().split('T')[0],
    sessionType: sessionData.type,
    startTime: sessionData.startTime,
    endTime: sessionData.endTime,
    instructorName: sessionData.instructorName ?? '',
    attendees: sessionData.attendances.map((a) => ({
      nationalId: a.karAmuz.nationalId,
      firstName: a.karAmuz.firstName,
      lastName: a.karAmuz.lastName,
      status: a.status,
      hours: a.hours,
    })),
  };

  // Use session ID as the entity ID for attendance sync
  const entityId = `attendance_${sessionId}`;

  // Call simulated TVET API
  const result = await simulateTVETApiCall('SYNC_ATTENDANCE', tvetData);

  // Create/update TVETSync record
  const sync = await db.tVETSync.upsert({
    where: {
      entityType_entityId: {
        entityType: 'ATTENDANCE',
        entityId,
      },
    },
    create: {
      entityType: 'ATTENDANCE',
      entityId,
      tvetCode: result.tvetCode,
      syncStatus: result.success ? 'SYNCED' : 'FAILED',
      syncData: tvetData as never,
      errorMessage: result.errorMessage,
      lastSyncAt: result.success ? new Date() : null,
    },
    update: {
      tvetCode: result.tvetCode ?? undefined,
      syncStatus: result.success ? 'SYNCED' : 'FAILED',
      syncData: tvetData as never,
      errorMessage: result.errorMessage,
      lastSyncAt: result.success ? new Date() : undefined,
    },
  });

  return {
    syncId: sync.id,
    entityType: 'ATTENDANCE',
    entityId,
    status: sync.syncStatus as TVETSyncResult['status'],
    tvetCode: sync.tvetCode,
    errorMessage: sync.errorMessage,
    syncedAt: sync.lastSyncAt,
  };
}

// ────────────────────────────────────────────────
// getSyncStatus
// ────────────────────────────────────────────────

export async function getSyncStatus(
  entityType?: string,
  entityId?: string,
): Promise<{
  syncs: Array<{
    id: string;
    entityType: string;
    entityId: string;
    tvetCode: string | null;
    syncStatus: string;
    errorMessage: string | null;
    lastSyncAt: string | null;
    createdAt: string;
  }>;
  total: number;
}> {
  const where: Record<string, unknown> = {};
  if (entityType) where.entityType = entityType;
  if (entityId) where.entityId = entityId;

  const syncs = await db.tVETSync.findMany({
    where,
    orderBy: { createdAt: 'desc' },
  });

  return {
    syncs: syncs.map((s) => ({
      id: s.id,
      entityType: s.entityType,
      entityId: s.entityId,
      tvetCode: s.tvetCode,
      syncStatus: s.syncStatus,
      errorMessage: s.errorMessage,
      lastSyncAt: s.lastSyncAt?.toISOString() ?? null,
      createdAt: s.createdAt.toISOString(),
    })),
    total: syncs.length,
  };
}

// ────────────────────────────────────────────────
// retryFailedSync
// ────────────────────────────────────────────────

export async function retryFailedSync(syncId: string): Promise<TVETSyncResult> {
  const sync = await db.tVETSync.findUnique({
    where: { id: syncId },
  });

  if (!sync) {
    throw new Error(`Sync record not found: ${syncId}`);
  }

  if (sync.syncStatus !== 'FAILED') {
    throw new Error(`Sync record is not in FAILED state: ${sync.syncStatus}`);
  }

  // Retry based on entity type
  switch (sync.entityType) {
    case 'SKILL_PROGRAM':
      return syncSkillProgram(sync.entityId);
    case 'CERTIFICATE':
      return syncCertificate(sync.entityId);
    case 'ATTENDANCE': {
      // For attendance, the entityId is "attendance_{sessionId}"
      const sessionId = sync.entityId.replace('attendance_', '');
      // We need the skillProgramId — extract from syncData
      const syncData = sync.syncData as { programCode?: string } | null;
      // Find the skill program from the code
      if (syncData?.programCode) {
        const program = await db.skillProgram.findFirst({
          where: { code: syncData.programCode },
        });
        if (program) {
          return syncAttendance(program.id, sessionId);
        }
      }
      throw new Error('Cannot retry attendance sync: missing program information');
    }
    default:
      throw new Error(`Unknown entity type: ${sync.entityType}`);
  }
}

// ────────────────────────────────────────────────
// getTVETReport
// ────────────────────────────────────────────────

export async function getTVETReport(): Promise<TVETReport> {
  // Get all sync records grouped by entity type
  const allSyncs = await db.tVETSync.findMany({
    orderBy: { createdAt: 'desc' },
  });

  // Count skill programs
  const totalPrograms = await db.skillProgram.count({ where: { isActive: true } });
  const programSyncs = allSyncs.filter((s) => s.entityType === 'SKILL_PROGRAM');
  const syncedPrograms = programSyncs.filter((s) => s.syncStatus === 'SYNCED').length;
  const pendingPrograms = programSyncs.filter((s) => s.syncStatus === 'PENDING').length;
  const failedPrograms = programSyncs.filter((s) => s.syncStatus === 'FAILED').length;

  // Count certificates
  const totalCertificates = await db.certificate.count();
  const certSyncs = allSyncs.filter((s) => s.entityType === 'CERTIFICATE');
  const syncedCertificates = certSyncs.filter((s) => s.syncStatus === 'SYNCED').length;
  const pendingCertificates = certSyncs.filter((s) => s.syncStatus === 'PENDING').length;
  const failedCertificates = certSyncs.filter((s) => s.syncStatus === 'FAILED').length;

  // Count attendance syncs
  const attSyncs = allSyncs.filter((s) => s.entityType === 'ATTENDANCE');
  const syncedAttendance = attSyncs.filter((s) => s.syncStatus === 'SYNCED').length;
  const pendingAttendance = attSyncs.filter((s) => s.syncStatus === 'PENDING').length;
  const failedAttendance = attSyncs.filter((s) => s.syncStatus === 'FAILED').length;

  // Calculate overall compliance
  const totalSynced = syncedPrograms + syncedCertificates + syncedAttendance;
  const totalRecords = Math.max(1, totalPrograms + totalCertificates + attSyncs.length);
  const overallCompliance = Math.round((totalSynced / totalRecords) * 100);

  // Find last sync
  const lastSyncAt = allSyncs
    .filter((s) => s.lastSyncAt)
    .sort((a, b) => new Date(b.lastSyncAt!).getTime() - new Date(a.lastSyncAt!).getTime())[0]
    ?.lastSyncAt ?? null;

  // Failed syncs details
  const failedSyncs = allSyncs
    .filter((s) => s.syncStatus === 'FAILED')
    .map((s) => ({
      id: s.id,
      entityType: s.entityType,
      entityId: s.entityId,
      errorMessage: s.errorMessage ?? 'Unknown error',
      lastSyncAt: s.lastSyncAt?.toISOString() ?? null,
    }));

  return {
    totalPrograms,
    syncedPrograms,
    pendingPrograms,
    failedPrograms,
    totalCertificates,
    syncedCertificates,
    pendingCertificates,
    failedCertificates,
    totalAttendance: attSyncs.length,
    syncedAttendance,
    pendingAttendance,
    failedAttendance,
    overallCompliance,
    lastSyncAt,
    failedSyncs,
  };
}
