/**
 * Adaptive Exam Engine — IRT-inspired adaptive testing system.
 *
 * Key concepts:
 * - Questions have difficulty levels (EASY, MEDIUM, HARD)
 * - Student has an ability estimate (θ) that adjusts based on answers
 * - If student answers correctly → increase difficulty
 * - If student answers incorrectly → decrease difficulty
 * - The exam adapts to find the student's true ability level
 *
 * Uses simplified IRT (Item Response Theory):
 * - Correct: θ = θ + 0.4 * (1 - P(difficulty))
 * - Incorrect: θ = θ - 0.4 * P(difficulty)
 * - Where P(difficulty) is the probability of the difficulty level
 */

import { db } from '@/lib/db';

// ────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────

type Difficulty = 'EASY' | 'MEDIUM' | 'HARD';
type Level = 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED' | 'EXPERT';

export interface AdaptiveExamStartResult {
  sessionId: string;
  question: {
    id: string;
    text: string;
    type: string;
    options: unknown;
    difficulty: Difficulty;
    points: number;
    image: string | null;
  } | null;
  difficulty: Difficulty;
  isFallback: boolean; // true if exam lacks difficulty-tagged questions
}

export interface AdaptiveAnswerResult {
  correct: boolean;
  nextQuestion: {
    id: string;
    text: string;
    type: string;
    options: unknown;
    difficulty: Difficulty;
    points: number;
    image: string | null;
  } | null;
  difficulty: Difficulty;
  abilityEstimate: number;
  isCompleted: boolean;
}

export interface AdaptiveResult {
  score: number;
  level: Level;
  abilityEstimate: number;
  questionBreakdown: {
    total: number;
    correct: number;
    incorrect: number;
    byDifficulty: Record<Difficulty, { total: number; correct: number }>;
  };
}

// ────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────

/** Convert difficulty to a numeric value for IRT calculations */
function difficultyToValue(d: Difficulty): number {
  switch (d) {
    case 'EASY': return -1;
    case 'MEDIUM': return 0;
    case 'HARD': return 1;
  }
}

/** Probability of correct answer given ability θ and difficulty d (simplified 2PL IRT) */
function probabilityCorrect(theta: number, difficulty: Difficulty): number {
  const d = difficultyToValue(difficulty);
  // 2PL logistic function: P(θ) = 1 / (1 + e^(-1.7*(θ - d)))
  return 1 / (1 + Math.exp(-1.7 * (theta - d)));
}

/** Select difficulty based on ability estimate */
function selectDifficulty(theta: number): Difficulty {
  if (theta < -1) return 'EASY';
  if (theta > 1) return 'HARD';
  return 'MEDIUM';
}

/** Determine final level from ability estimate */
function determineLevel(theta: number): Level {
  if (theta < -1.5) return 'BEGINNER';
  if (theta < 0) return 'INTERMEDIATE';
  if (theta < 1.5) return 'ADVANCED';
  return 'EXPERT';
}

// ────────────────────────────────────────────────
// startAdaptiveExam
// ────────────────────────────────────────────────

export async function startAdaptiveExam(
  examId: string,
  karAmuzId: string,
): Promise<AdaptiveExamStartResult> {
  // Verify exam exists and is active
  const exam = await db.exam.findUnique({
    where: { id: examId },
    include: { questions: true },
  });

  if (!exam || !exam.isActive) {
    throw new Error('Exam not found or inactive');
  }

  // Check if questions have difficulty tags
  const hasDifficultyTags = exam.questions.some((q) =>
    ['EASY', 'MEDIUM', 'HARD'].includes(q.difficulty),
  );

  // If no difficulty tags, fall back to standard exam mode
  if (!hasDifficultyTags) {
    // Create a standard session (non-adaptive)
    const session = await db.adaptiveExamSession.create({
      data: {
        examId,
        karAmuzId,
        currentDifficulty: 'MEDIUM',
        currentQuestionIndex: 0,
        abilityEstimate: 0.0,
        responses: [],
        isCompleted: false,
      },
    });

    // Return first question without adaptive logic
    const firstQuestion = exam.questions[0];
    return {
      sessionId: session.id,
      question: firstQuestion
        ? {
            id: firstQuestion.id,
            text: firstQuestion.text,
            type: firstQuestion.type,
            options: firstQuestion.options,
            difficulty: 'MEDIUM' as Difficulty,
            points: firstQuestion.points,
            image: firstQuestion.image,
          }
        : null,
      difficulty: 'MEDIUM',
      isFallback: true,
    };
  }

  // Filter questions by difficulty level
  const mediumQuestions = exam.questions.filter((q) => q.difficulty === 'MEDIUM');
  const easyQuestions = exam.questions.filter((q) => q.difficulty === 'EASY');
  const hardQuestions = exam.questions.filter((q) => q.difficulty === 'HARD');

  // Create adaptive session
  const session = await db.adaptiveExamSession.create({
    data: {
      examId,
      karAmuzId,
      currentDifficulty: 'MEDIUM',
      currentQuestionIndex: 0,
      abilityEstimate: 0.0,
      responses: [],
      isCompleted: false,
    },
  });

  // Select first question (MEDIUM difficulty preferred)
  const pool = mediumQuestions.length > 0 ? mediumQuestions : easyQuestions.length > 0 ? easyQuestions : hardQuestions;
  const firstQuestion = pool[0];

  return {
    sessionId: session.id,
    question: firstQuestion
      ? {
          id: firstQuestion.id,
          text: firstQuestion.text,
          type: firstQuestion.type,
          options: firstQuestion.options,
          difficulty: firstQuestion.difficulty as Difficulty,
          points: firstQuestion.points,
          image: firstQuestion.image,
        }
      : null,
    difficulty: 'MEDIUM',
    isFallback: false,
  };
}

// ────────────────────────────────────────────────
// submitAdaptiveAnswer
// ────────────────────────────────────────────────

export async function submitAdaptiveAnswer(
  sessionId: string,
  questionId: string,
  answer: string,
): Promise<AdaptiveAnswerResult> {
  // Get session
  const session = await db.adaptiveExamSession.findUnique({
    where: { id: sessionId },
  });

  if (!session) {
    throw new Error('Session not found');
  }

  if (session.isCompleted) {
    throw new Error('Session is already completed');
  }

  // Get the question
  const question = await db.examQuestion.findUnique({
    where: { id: questionId },
  });

  if (!question) {
    throw new Error('Question not found');
  }

  // Check if answer is correct
  const correct = answer === question.correctAnswer;

  // Current ability estimate and difficulty
  let theta = session.abilityEstimate;
  const currentDifficulty = question.difficulty as Difficulty;

  // Update ability estimate using simplified IRT
  const prob = probabilityCorrect(theta, currentDifficulty);
  if (correct) {
    // Correct: θ = θ + 0.4 * (1 - P(difficulty))
    theta = theta + 0.4 * (1 - prob);
  } else {
    // Incorrect: θ = θ - 0.4 * P(difficulty)
    theta = theta - 0.4 * prob;
  }

  // Clamp theta to reasonable bounds
  theta = Math.max(-3, Math.min(3, theta));

  // Update responses
  const responses = (session.responses as Array<{
    questionId: string;
    answer: string;
    correct: boolean;
    difficulty: string;
    thetaAfter: number;
  }>) ?? [];

  responses.push({
    questionId,
    answer,
    correct,
    difficulty: currentDifficulty,
    thetaAfter: Math.round(theta * 100) / 100,
  });

  // Select next question based on new ability estimate
  const nextDifficulty = selectDifficulty(theta);

  // Get all questions for the exam
  const allQuestions = await db.examQuestion.findMany({
    where: { examId: session.examId },
  });

  // Get IDs of already answered questions
  const answeredIds = new Set(responses.map((r) => r.questionId));

  // Filter available questions
  const availableByDifficulty = {
    EASY: allQuestions.filter((q) => q.difficulty === 'EASY' && !answeredIds.has(q.id)),
    MEDIUM: allQuestions.filter((q) => q.difficulty === 'MEDIUM' && !answeredIds.has(q.id)),
    HARD: allQuestions.filter((q) => q.difficulty === 'HARD' && !answeredIds.has(q.id)),
  };

  // Determine if exam should end
  const totalAvailable = availableByDifficulty.EASY.length +
    availableByDifficulty.MEDIUM.length +
    availableByDifficulty.HARD.length;

  const MIN_QUESTIONS = 5; // Minimum questions for adaptive exam
  const MAX_QUESTIONS = Math.min(allQuestions.length, 20); // Cap at 20
  const answeredCount = responses.length;

  let isCompleted = false;

  // End exam conditions:
  // 1. No more questions available
  // 2. Answered enough questions AND ability has stabilized
  // 3. Answered max questions
  if (totalAvailable === 0) {
    isCompleted = true;
  } else if (answeredCount >= MAX_QUESTIONS) {
    isCompleted = true;
  } else if (answeredCount >= MIN_QUESTIONS) {
    // Check if ability has stabilized (last 3 theta changes are small)
    if (responses.length >= 3) {
      const lastThree = responses.slice(-3);
      const thetaChanges = lastThree.map((r, i) =>
        i === 0 ? 0 : Math.abs(r.thetaAfter - lastThree[i - 1].thetaAfter),
      );
      const avgChange = thetaChanges.reduce((a, b) => a + b, 0) / thetaChanges.length;
      if (avgChange < 0.1) {
        isCompleted = true;
      }
    }
  }

  // Select next question
  let nextQuestion: {
    id: string;
    text: string;
    type: string;
    options: unknown;
    difficulty: string;
    points: number;
    image: string | null;
  } | null = null;
  let selectedDifficulty = nextDifficulty;

  if (!isCompleted) {
    // Try to get a question at the target difficulty
    let pool = availableByDifficulty[nextDifficulty];

    // If no questions at target difficulty, try others
    if (pool.length === 0) {
      if (nextDifficulty === 'HARD') pool = availableByDifficulty.MEDIUM.length > 0 ? availableByDifficulty.MEDIUM : availableByDifficulty.EASY;
      else if (nextDifficulty === 'EASY') pool = availableByDifficulty.MEDIUM.length > 0 ? availableByDifficulty.MEDIUM : availableByDifficulty.HARD;
      else pool = availableByDifficulty.EASY.length > 0 ? availableByDifficulty.EASY : availableByDifficulty.HARD;
    }

    // If still no questions, mark as completed
    if (pool.length === 0) {
      isCompleted = true;
      selectedDifficulty = currentDifficulty;
    } else {
      // Pick a random question from the pool (or first one for determinism)
      const picked = pool[0];
      nextQuestion = {
        id: picked.id,
        text: picked.text,
        type: picked.type,
        options: picked.options,
        difficulty: picked.difficulty,
        points: picked.points,
        image: picked.image,
      };
      selectedDifficulty = picked.difficulty as Difficulty;
    }
  }

  // Update session
  await db.adaptiveExamSession.update({
    where: { id: sessionId },
    data: {
      currentDifficulty: selectedDifficulty,
      currentQuestionIndex: answeredCount,
      abilityEstimate: Math.round(theta * 100) / 100,
      responses,
      isCompleted,
      completedAt: isCompleted ? new Date() : null,
      finalScore: isCompleted ? calculateScore(responses) : null,
      finalLevel: isCompleted ? determineLevel(theta) : null,
    },
  });

  return {
    correct,
    nextQuestion: nextQuestion
      ? {
          id: nextQuestion.id,
          text: nextQuestion.text,
          type: nextQuestion.type,
          options: nextQuestion.options,
          difficulty: nextQuestion.difficulty as Difficulty,
          points: nextQuestion.points,
          image: nextQuestion.image,
        }
      : null,
    difficulty: selectedDifficulty,
    abilityEstimate: Math.round(theta * 100) / 100,
    isCompleted,
  };
}

// ────────────────────────────────────────────────
// getAdaptiveResults
// ────────────────────────────────────────────────

export async function getAdaptiveResults(sessionId: string): Promise<AdaptiveResult> {
  const session = await db.adaptiveExamSession.findUnique({
    where: { id: sessionId },
  });

  if (!session) {
    throw new Error('Session not found');
  }

  if (!session.isCompleted) {
    throw new Error('Session is not yet completed');
  }

  const responses = (session.responses as Array<{
    questionId: string;
    answer: string;
    correct: boolean;
    difficulty: string;
    thetaAfter: number;
  }>) ?? [];

  const theta = session.abilityEstimate;
  const level = determineLevel(theta);
  const score = session.finalScore ?? calculateScore(responses);

  // Build breakdown
  const byDifficulty: Record<Difficulty, { total: number; correct: number }> = {
    EASY: { total: 0, correct: 0 },
    MEDIUM: { total: 0, correct: 0 },
    HARD: { total: 0, correct: 0 },
  };

  for (const r of responses) {
    const d = r.difficulty as Difficulty;
    if (byDifficulty[d]) {
      byDifficulty[d].total++;
      if (r.correct) byDifficulty[d].correct++;
    }
  }

  return {
    score: Math.round(score * 100) / 100,
    level,
    abilityEstimate: Math.round(theta * 100) / 100,
    questionBreakdown: {
      total: responses.length,
      correct: responses.filter((r) => r.correct).length,
      incorrect: responses.filter((r) => !r.correct).length,
      byDifficulty,
    },
  };
}

// ────────────────────────────────────────────────
// calculateScore
// ────────────────────────────────────────────────

function calculateScore(
  responses: Array<{ correct: boolean; difficulty: string }>,
): number {
  if (responses.length === 0) return 0;

  // Weighted scoring: harder questions are worth more
  const weightMap: Record<string, number> = {
    EASY: 1,
    MEDIUM: 2,
    HARD: 3,
  };

  let totalWeight = 0;
  let earnedWeight = 0;

  for (const r of responses) {
    const w = weightMap[r.difficulty] ?? 1;
    totalWeight += w;
    if (r.correct) earnedWeight += w;
  }

  return totalWeight > 0 ? (earnedWeight / totalWeight) * 100 : 0;
}
