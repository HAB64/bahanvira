/**
 * ─── Embedding & Vector Search — جستجوی معنایی بدون Embedding Model ───
 * 
 * از TF-IDF + Cosine Similarity برای جستجوی معنایی فارسی استفاده می‌کند.
 * ترکیبی از Vector Search و BM25 برای Hybrid Search.
 */

import { Chunk } from './chunker'

// ─── Persian Stopwords ─────────────────────────────────────────────────────────
const PERSIAN_STOPWORDS = new Set([
  'و', 'در', 'به', 'از', 'با', 'برای', 'که', 'این', 'آن', 'را', 'هم', 'می',
  'است', 'بود', 'شد', 'خواهد', 'کرد', 'دارد', 'نشده', 'نیست', 'بودند',
  'کنند', 'شود', 'ما', 'شما', 'او', 'آنها', 'هر', 'یک', 'بعضی', 'بسیاری',
  'خیلی', 'بسیار', 'ممکن', 'توان', 'باید', 'چون', 'چونکه', 'اگر', 'هنگامی',
  'پس', 'بنابراین', 'اما', 'ولی', 'تا', 'همچنین', 'یعنی', 'یعنی‌که', 'مثل',
  'همان', 'دیگر', 'چند', 'بیشتر', 'کمتر', 'اول', 'آخر', 'قبل', 'بعد',
  'بین', 'ضد', 'درباره', 'پیش', 'روی', 'تحت', 'علی‌رغم', 'همراه', 'بدون',
  'دارای', 'حاوی', 'بر اساس', 'نسبت', ' نسبت به', 'توسط', 'برای', 'از طریق',
  'همین', 'حالا', 'الان', 'امروز', 'فردا', 'دیروز', 'همواره', 'گاهی',
  'من', 'تو', 'های', 'شان', 'تان', 'مان', 'کردند', 'خواهند', 'خواهیم',
  'خواهید', 'دارم', 'داری', 'داریم', 'دارید', 'دارند', 'باشد', 'باشم',
  'باشی', 'باشیم', 'باشید', 'باشند', 'هستیم', 'هستید', 'هستند', 'بودم',
  'بودی', 'بودیم', 'بودید', 'شدیم', 'شدی', 'شدم', 'شدی', 'شوید',
  'بله', 'خیر', 'نه', 'آیا', 'چگونه', 'چرا', 'کجا', 'کدام', 'چه',
  'کو', 'کی', 'چقدر', 'چند', 'کمی', 'بله', 'شاید', 'حتماً', 'حتما',
])

// ─── Text Preprocessing ────────────────────────────────────────────────────────

function normalizePersian(text: string): string {
  return text
    .replace(/[٠-٩]/g, d => '۰۱۲۳۴۵۶۷۸۹'['٠١٢٣٤٥٦٧٨٩'.indexOf(d)])
    .replace(/[۰-۹]/g, '')
    .replace(/[^\u0600-\u06FF\u0020-\u007E]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function tokenize(text: string): string[] {
  return normalizePersian(text)
    .split(/\s+/)
    .filter(w => w.length > 1 && !PERSIAN_STOPWORDS.has(w))
    .map(w => w.replace(/^[^\w]+|[^\w]+$/g, ''))
    .filter(w => w.length > 1)
}

// ─── TF-IDF Vectorizer ──────────────────────────────────────────────────────────

interface TermInfo {
  idf: number
  docFreq: number
}

interface TfidfVector {
  terms: string[]
  values: number[]
}

/**
 * ساخت vocabulary و IDF از مجموعه‌ای ازChunks
 */
export function buildVocabulary(chunks: Chunk[]): Map<string, TermInfo> {
  const N = chunks.length
  const docFreq = new Map<string, number>()

  for (const chunk of chunks) {
    const tokens = new Set(tokenize(chunk.content))
    for (const token of tokens) {
      docFreq.set(token, (docFreq.get(token) || 0) + 1)
    }
  }

  const vocab = new Map<string, TermInfo>()
  for (const [term, df] of docFreq.entries()) {
    const idf = Math.log((N + 1) / (df + 1)) + 1  // Smooth IDF
    vocab.set(term, { idf, docFreq: df })
  }

  return vocab
}

/**
 * تبدیل متن به بردار TF-IDF
 */
export function textToTfidf(text: string, vocab: Map<string, TermInfo>): TfidfVector {
  const tokens = tokenize(text)
  const tf = new Map<string, number>()

  for (const token of tokens) {
    tf.set(token, (tf.get(token) || 0) + 1)
  }

  const terms: string[] = []
  const values: number[] = []

  for (const [term, count] of tf.entries()) {
    const termInfo = vocab.get(term)
    if (termInfo) {
      terms.push(term)
      values.push((1 + Math.log(count)) * termInfo.idf)  // Log-normalized TF
    }
  }

  return { terms, values }
}

// ─── Cosine Similarity ────────────────────────────────────────────────────────

function dotProduct(a: TfidfVector, b: TfidfVector): number {
  let sum = 0
  const bMap = new Map(b.terms.map((t, i) => [t, b.values[i]]))

  for (let i = 0; i < a.terms.length; i++) {
    const bv = bMap.get(a.terms[i])
    if (bv !== undefined) {
      sum += a.values[i] * bv
    }
  }
  return sum
}

function magnitude(v: TfidfVector): number {
  return Math.sqrt(v.values.reduce((sum, val) => sum + val * val, 0))
}

function cosineSimilarity(a: TfidfVector, b: TfidfVector): number {
  const dot = dotProduct(a, b)
  const magA = magnitude(a)
  const magB = magnitude(b)
  if (magA === 0 || magB === 0) return 0
  return dot / (magA * magB)
}

// ─── BM25 Scoring ──────────────────────────────────────────────────────────────

const BM25_K1 = 1.5
const BM25_B = 0.75

function bm25Score(queryTokens: string[], chunkTokens: string[], vocab: Map<string, TermInfo>, avgDL: number): number {
  const dl = chunkTokens.length
  let score = 0

  const chunkFreq = new Map<string, number>()
  for (const t of chunkTokens) {
    chunkFreq.set(t, (chunkFreq.get(t) || 0) + 1)
  }

  for (const qt of queryTokens) {
    const termInfo = vocab.get(qt)
    const freq = chunkFreq.get(qt) || 0

    if (termInfo && freq > 0) {
      const idf = termInfo.idf
      const tfNorm = (freq * (BM25_K1 + 1)) / (freq + BM25_K1 * (1 - BM25_B + BM25_B * (dl / avgDL)))
      score += idf * tfNorm
    }
  }

  return score
}

// ─── Vector Store ──────────────────────────────────────────────────────────────

export interface SearchResult {
  chunk: Chunk
  score: number
  method: 'vector' | 'bm25' | 'hybrid'
}

export class VectorStore {
  private chunks: Chunk[] = []
  private vocab: Map<string, TermInfo> = new Map()
  private chunkVectors: Map<string, TfidfVector> = new Map()
  private chunkTokens: Map<string, string[]> = new Map()
  private avgDocLength = 0
  private built = false

  /**
   * اضافه کردن chunks به store
   */
  addChunks(newChunks: Chunk[]): void {
    this.chunks.push(...newChunks)
    this.built = false
  }

  /**
   * ساخت Index — باید قبل از جستجو فراخوانی شود
   */
  buildIndex(): void {
    this.vocab = buildVocabulary(this.chunks)

    let totalLen = 0
    for (const chunk of this.chunks) {
      const tokens = tokenize(chunk.content)
      this.chunkTokens.set(chunk.id, tokens)
      this.chunkVectors.set(chunk.id, textToTfidf(chunk.content, this.vocab))
      totalLen += tokens.length
    }

    this.avgDocLength = this.chunks.length > 0 ? totalLen / this.chunks.length : 0
    this.built = true
  }

  /**
   * Hybrid Search: Vector (TF-IDF Cosine) + BM25
   */
  search(query: string, topK = 8, alpha = 0.6): SearchResult[] {
    if (!this.built) this.buildIndex()

    const queryTokens = tokenize(query)
    const queryVector = textToTfidf(query, this.vocab)

    const results: SearchResult[] = []

    for (const chunk of this.chunks) {
      const vectorScore = cosineSimilarity(queryVector, this.chunkVectors.get(chunk.id)!)
      const bm25 = bm25Score(queryTokens, this.chunkTokens.get(chunk.id)!, this.vocab, this.avgDocLength)

      // Normalize scores to 0-1
      const normVector = vectorScore
      const normBM25 = bm25 > 0 ? Math.min(bm25 / 20, 1) : 0  // Cap BM25 at 1

      const hybridScore = alpha * normVector + (1 - alpha) * normBM25

      results.push({
        chunk,
        score: hybridScore,
        method: 'hybrid',
      })
    }

    return results
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .filter(r => r.score > 0.05)  // Minimum threshold
  }

  /**
   * فقط جستجوی Vector
   */
  searchVector(query: string, topK = 8): SearchResult[] {
    if (!this.built) this.buildIndex()

    const queryVector = textToTfidf(query, this.vocab)

    return this.chunks
      .map(chunk => ({
        chunk,
        score: cosineSimilarity(queryVector, this.chunkVectors.get(chunk.id)!),
        method: 'vector' as const,
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .filter(r => r.score > 0.05)
  }

  /**
   * فقط جستجوی BM25
   */
  searchBM25(query: string, topK = 8): SearchResult[] {
    if (!this.built) this.buildIndex()

    const queryTokens = tokenize(query)

    return this.chunks
      .map(chunk => ({
        chunk,
        score: bm25Score(queryTokens, this.chunkTokens.get(chunk.id)!, this.vocab, this.avgDocLength),
        method: 'bm25' as const,
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .filter(r => r.score > 0.05)
  }

  /**
   * تعداد chunks
   */
  get size(): number {
    return this.chunks.length
  }
}

// ─── Re-Ranker ─────────────────────────────────────────────────────────────────

/**
 * Re-Ranking بر اساس تناسب محتوا با سؤال
 * الگوریتم: امتیاز بر اساس تطبیق کلمات کلیدی + موقعیت + طول
 */
export function reRank(results: SearchResult[], query: string): SearchResult[] {
  const queryTokens = new Set(tokenize(query))
  const queryLower = query.toLowerCase()

  return results.map(result => {
    const content = result.chunk.content
    const tokens = new Set(tokenize(content))

    // Keyword overlap score
    let overlap = 0
    for (const qt of queryTokens) {
      if (tokens.has(qt)) overlap++
    }
    const keywordScore = queryTokens.size > 0 ? overlap / queryTokens.size : 0

    // Position score: earlier matches are better
    let firstMatchPos = content.length
    for (const qt of queryTokens) {
      const pos = content.indexOf(qt)
      if (pos >= 0 && pos < firstMatchPos) firstMatchPos = pos
    }
    const positionScore = 1 - (firstMatchPos / content.length)

    // Length preference: prefer medium-length chunks (200-600 tokens)
    const tokenCount = result.chunk.tokens
    let lengthScore = 0
    if (tokenCount >= 200 && tokenCount <= 600) lengthScore = 1
    else if (tokenCount < 200) lengthScore = 0.5
    else lengthScore = 0.7

    // Combined re-rank score
    const rerankScore = result.score * 0.5 + keywordScore * 0.25 + positionScore * 0.15 + lengthScore * 0.1

    return { ...result, score: rerankScore }
  }).sort((a, b) => b.score - a.score)
}
