/**
 * Prediction Engine — Statistical prediction for revenue, enrollment, churn, and demand.
 *
 * Uses linear regression for revenue, exponential smoothing for enrollment,
 * multi-factor risk scoring for churn, and trend analysis for demand.
 */

import { db } from '@/lib/db';

// ────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────

export interface PredictionPoint {
  month: string;        // e.g. "1404-03"
  predicted: number;
  confidence: number;   // 0-1
}

export interface RevenuePredictionResult {
  predictions: PredictionPoint[];
  trend: 'GROWING' | 'STABLE' | 'DECLINING';
  growthRate: number;   // percentage
}

export interface EnrollmentPredictionResult {
  predictions: PredictionPoint[];
  trend: 'GROWING' | 'STABLE' | 'DECLINING';
}

export interface ChurnPredictionEntry {
  leadId: string;
  leadName: string;
  riskScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  factors: Record<string, number>;
  recommendedActions: string[];
}

export interface ChurnPredictionResult {
  highRisk: number;
  mediumRisk: number;
  lowRisk: number;
  predictions: ChurnPredictionEntry[];
}

export interface DemandPredictionEntry {
  courseSlug: string;
  courseName: string;
  predictedDemand: number;
  confidence: number;
}

// ────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────

function toPersianMonth(date: Date): string {
  // Simple Gregorian-based month key (production would use jalaali-js)
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

function addMonths(date: Date, months: number): Date {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
}

/** Simple linear regression: returns { slope, intercept } */
function linearRegression(xs: number[], ys: number[]): { slope: number; intercept: number } {
  const n = xs.length;
  if (n === 0) return { slope: 0, intercept: 0 };
  const sumX = xs.reduce((a, b) => a + b, 0);
  const sumY = ys.reduce((a, b) => a + b, 0);
  const sumXY = xs.reduce((acc, x, i) => acc + x * ys[i], 0);
  const sumX2 = xs.reduce((acc, x) => acc + x * x, 0);
  const denom = n * sumX2 - sumX * sumX;
  if (denom === 0) return { slope: 0, intercept: sumY / n };
  const slope = (n * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / n;
  return { slope, intercept };
}

/** Exponential smoothing forecast */
function exponentialSmoothing(values: number[], alpha: number = 0.4): number[] {
  if (values.length === 0) return [];
  const smoothed: number[] = [values[0]];
  for (let i = 1; i < values.length; i++) {
    smoothed.push(alpha * values[i] + (1 - alpha) * smoothed[i - 1]);
  }
  return smoothed;
}

// ────────────────────────────────────────────────
// predictRevenue
// ────────────────────────────────────────────────

export async function predictRevenue(monthsAhead: number = 3): Promise<RevenuePredictionResult> {
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

  // Fetch paid payments grouped by month
  const payments = await db.payment.findMany({
    where: {
      status: 'PAID',
      paidAt: { gte: sixMonthsAgo },
    },
    select: { amount: true, paidAt: true },
    orderBy: { paidAt: 'asc' },
  });

  // Group by month
  const monthlyRevenue = new Map<string, number>();
  for (const p of payments) {
    if (!p.paidAt) continue;
    const key = toPersianMonth(p.paidAt);
    monthlyRevenue.set(key, (monthlyRevenue.get(key) ?? 0) + p.amount);
  }

  const months = Array.from(monthlyRevenue.keys()).sort();
  const values = months.map((m) => monthlyRevenue.get(m) ?? 0);

  // Handle empty data
  if (months.length === 0) {
    const now = new Date();
    const predictions: PredictionPoint[] = [];
    for (let i = 1; i <= monthsAhead; i++) {
      predictions.push({
        month: toPersianMonth(addMonths(now, i)),
        predicted: 0,
        confidence: 0.1,
      });
    }
    return { predictions, trend: 'STABLE', growthRate: 0 };
  }

  // Linear regression
  const xs = months.map((_, i) => i);
  const { slope, intercept } = linearRegression(xs, values);

  // Generate predictions
  const now = new Date();
  const predictions: PredictionPoint[] = [];
  for (let i = 1; i <= monthsAhead; i++) {
    const x = months.length - 1 + i;
    const predicted = Math.max(0, slope * x + intercept);
    // Confidence decreases with distance
    const confidence = Math.max(0.3, 1 - i * 0.15);
    predictions.push({
      month: toPersianMonth(addMonths(now, i)),
      predicted: Math.round(predicted),
      confidence,
    });
  }

  // Determine trend & growth rate
  const firstVal = values[0] || 1;
  const lastVal = values[values.length - 1] || 0;
  const growthRate = firstVal !== 0 ? ((lastVal - firstVal) / firstVal) * 100 : 0;
  let trend: RevenuePredictionResult['trend'] = 'STABLE';
  if (growthRate > 5) trend = 'GROWING';
  else if (growthRate < -5) trend = 'DECLINING';

  return { predictions, trend, growthRate: Math.round(growthRate * 100) / 100 };
}

// ────────────────────────────────────────────────
// predictEnrollment
// ────────────────────────────────────────────────

export async function predictEnrollment(monthsAhead: number = 3): Promise<EnrollmentPredictionResult> {
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

  const enrollments = await db.enrollment.findMany({
    where: {
      enrollmentDate: { gte: sixMonthsAgo },
    },
    select: { enrollmentDate: true },
    orderBy: { enrollmentDate: 'asc' },
  });

  // Group by month
  const monthlyCounts = new Map<string, number>();
  for (const e of enrollments) {
    const key = toPersianMonth(e.enrollmentDate);
    monthlyCounts.set(key, (monthlyCounts.get(key) ?? 0) + 1);
  }

  const months = Array.from(monthlyCounts.keys()).sort();
  const values = months.map((m) => monthlyCounts.get(m) ?? 0);

  // Handle empty data
  if (months.length === 0) {
    const now = new Date();
    const predictions: PredictionPoint[] = [];
    for (let i = 1; i <= monthsAhead; i++) {
      predictions.push({
        month: toPersianMonth(addMonths(now, i)),
        predicted: 0,
        confidence: 0.1,
      });
    }
    return { predictions, trend: 'STABLE' };
  }

  // Pad to at least 6 months for smoother smoothing
  while (values.length < 6) {
    values.unshift(0);
  }

  // Exponential smoothing
  const smoothed = exponentialSmoothing(values, 0.4);
  const lastSmoothed = smoothed[smoothed.length - 1];
  const secondLast = smoothed[smoothed.length - 2] ?? lastSmoothed;
  const trendDelta = lastSmoothed - secondLast;

  const now = new Date();
  const predictions: PredictionPoint[] = [];
  for (let i = 1; i <= monthsAhead; i++) {
    const predicted = Math.max(0, Math.round(lastSmoothed + trendDelta * i));
    const confidence = Math.max(0.3, 1 - i * 0.12);
    predictions.push({
      month: toPersianMonth(addMonths(now, i)),
      predicted,
      confidence,
    });
  }

  // Determine trend
  let trend: EnrollmentPredictionResult['trend'] = 'STABLE';
  if (trendDelta > 0.5) trend = 'GROWING';
  else if (trendDelta < -0.5) trend = 'DECLINING';

  return { predictions, trend };
}

// ────────────────────────────────────────────────
// predictChurn
// ────────────────────────────────────────────────

export async function predictChurn(): Promise<ChurnPredictionResult> {
  const leads = await db.lead.findMany({
    where: {
      stage: { in: ['NEW', 'CONTACTED', 'INTERESTED', 'ENROLLED'] },
    },
    include: {
      payments: { select: { status: true, dueDate: true } },
      activityLogs: { select: { createdAt: true }, orderBy: { createdAt: 'desc' }, take: 1 },
      churnPrediction: true,
    },
  });

  const predictions: ChurnPredictionEntry[] = [];

  for (const lead of leads) {
    const factors: Record<string, number> = {};

    // Factor 1: Days since last contact (0-1, higher = more risk)
    const lastContact = lead.lastContactedAt;
    const daysSinceContact = lastContact
      ? (Date.now() - new Date(lastContact).getTime()) / (1000 * 60 * 60 * 24)
      : 999;
    factors.daysSinceContact = Math.min(1, daysSinceContact / 30);

    // Factor 2: Payment status (overdue payments increase risk)
    const hasOverdue = lead.payments.some((p) => p.status === 'OVERDUE');
    factors.paymentRisk = hasOverdue ? 0.8 : 0.1;

    // Factor 3: Lead score (lower score = higher risk)
    factors.lowScore = Math.max(0, 1 - lead.score / 100);

    // Factor 4: Stage risk (NEW leads without progress are risky)
    const stageRisk: Record<string, number> = {
      NEW: 0.6,
      CONTACTED: 0.4,
      INTERESTED: 0.2,
      ENROLLED: 0.1,
    };
    factors.stageRisk = stageRisk[lead.stage] ?? 0.3;

    // Factor 5: Engagement (has recent activity logs?)
    const lastActivity = lead.activityLogs[0]?.createdAt;
    const daysSinceActivity = lastActivity
      ? (Date.now() - new Date(lastActivity).getTime()) / (1000 * 60 * 60 * 24)
      : 999;
    factors.inactivityRisk = Math.min(1, daysSinceActivity / 14);

    // Weighted risk score
    const weights: Record<string, number> = {
      daysSinceContact: 0.25,
      paymentRisk: 0.2,
      lowScore: 0.2,
      stageRisk: 0.15,
      inactivityRisk: 0.2,
    };

    let riskScore = 0;
    for (const [key, weight] of Object.entries(weights)) {
      riskScore += (factors[key] ?? 0) * weight;
    }
    riskScore = Math.min(1, Math.max(0, riskScore));

    // Determine risk level
    let riskLevel: ChurnPredictionEntry['riskLevel'] = 'LOW';
    if (riskScore >= 0.7) riskLevel = 'CRITICAL';
    else if (riskScore >= 0.5) riskLevel = 'HIGH';
    else if (riskScore >= 0.3) riskLevel = 'MEDIUM';

    // Recommended actions
    const recommendedActions: string[] = [];
    if (factors.daysSinceContact > 0.5) recommendedActions.push('تماس فوری با لید');
    if (factors.paymentRisk > 0.5) recommendedActions.push('پیگیری پرداخت‌های معوقه');
    if (factors.lowScore > 0.5) recommendedActions.push('ارائه تخفیف ویژه');
    if (factors.inactivityRisk > 0.5) recommendedActions.push('ارسال پیام بازگشت');
    if (recommendedActions.length === 0) recommendedActions.push('پایش معمول');

    predictions.push({
      leadId: lead.id,
      leadName: lead.name,
      riskScore: Math.round(riskScore * 100) / 100,
      riskLevel,
      factors,
      recommendedActions,
    });

    // Upsert ChurnPrediction record
    await db.churnPrediction.upsert({
      where: { leadId: lead.id },
      create: {
        leadId: lead.id,
        riskLevel,
        riskScore,
        factors,
        reasoning: `Risk factors: ${Object.entries(factors).map(([k, v]) => `${k}=${v.toFixed(2)}`).join(', ')}`,
        recommendedActions: JSON.stringify(recommendedActions),
      },
      update: {
        riskLevel,
        riskScore,
        factors,
        reasoning: `Risk factors: ${Object.entries(factors).map(([k, v]) => `${k}=${v.toFixed(2)}`).join(', ')}`,
        recommendedActions: JSON.stringify(recommendedActions),
        predictedAt: new Date(),
      },
    });
  }

  const highRisk = predictions.filter((p) => p.riskLevel === 'HIGH' || p.riskLevel === 'CRITICAL').length;
  const mediumRisk = predictions.filter((p) => p.riskLevel === 'MEDIUM').length;
  const lowRisk = predictions.filter((p) => p.riskLevel === 'LOW').length;

  return { highRisk, mediumRisk, lowRisk, predictions };
}

// ────────────────────────────────────────────────
// predictCourseDemand
// ────────────────────────────────────────────────

export async function predictCourseDemand(): Promise<DemandPredictionEntry[]> {
  // Get all courses
  const courses = await db.course.findMany({
    where: { published: true },
    select: { id: true, slug: true, title: true, cluster: true },
  });

  const results: DemandPredictionEntry[] = [];

  for (const course of courses) {
    let demandScore = 50; // baseline

    // Factor 1: Lead interest — count leads whose interest/course matches this course
    const leadInterests = await db.lead.count({
      where: {
        OR: [
          { interest: { contains: course.slug } },
          { course: { contains: course.slug } },
          { cluster: course.cluster },
        ],
      },
    });
    demandScore += Math.min(30, leadInterests * 2);

    // Factor 2: Current enrollments via skill programs in the same cluster
    const clusterEnrollments = await db.enrollment.count({
      where: {
        skillProgram: { cluster: course.cluster },
      },
    });
    demandScore += Math.min(20, clusterEnrollments);

    // Factor 3: Page views from event logs
    const pageViews = await db.eventLog.count({
      where: {
        event: 'PAGE_VIEW',
        page: { contains: course.slug },
      },
    });
    demandScore += Math.min(15, Math.floor(pageViews / 5));

    // Factor 4: Seasonal patterns (simple — boost tech courses in summer)
    const month = new Date().getMonth();
    if (course.cluster === 'tech-ai' && (month >= 5 && month <= 8)) {
      demandScore += 10; // summer boost
    }
    if (course.cluster === 'financial' && (month >= 0 && month <= 2)) {
      demandScore += 10; // Q1 boost for financial courses
    }

    // Confidence based on data availability
    const dataPoints = leadInterests + clusterEnrollments + pageViews;
    const confidence = Math.min(0.9, 0.3 + dataPoints * 0.02);

    results.push({
      courseSlug: course.slug,
      courseName: course.title,
      predictedDemand: Math.min(100, demandScore),
      confidence: Math.round(confidence * 100) / 100,
    });
  }

  // Sort by predicted demand descending
  results.sort((a, b) => b.predictedDemand - a.predictedDemand);

  return results;
}

// ────────────────────────────────────────────────
// savePrediction
// ────────────────────────────────────────────────

export async function savePrediction(
  type: string,
  period: string,
  predictions: PredictionPoint[],
  model: string = 'LINEAR',
): Promise<void> {
  for (const p of predictions) {
    // Parse month string into a date (first of month)
    const [yearStr, monthStr] = p.month.split('-');
    const targetDate = new Date(parseInt(yearStr), parseInt(monthStr) - 1, 1);

    await db.prediction.create({
      data: {
        type,
        period,
        targetDate,
        predictedValue: p.predicted,
        confidence: p.confidence,
        model,
        factors: { source: 'prediction-engine' },
      },
    });
  }
}

// ────────────────────────────────────────────────
// evaluateAccuracy
// ────────────────────────────────────────────────

export async function evaluateAccuracy(): Promise<{
  evaluated: number;
  averageAccuracy: number;
  byType: Record<string, { count: number; avgAccuracy: number }>;
}> {
  // Find predictions that have actual values
  const predictions = await db.prediction.findMany({
    where: {
      actualValue: { not: null },
    },
  });

  if (predictions.length === 0) {
    return { evaluated: 0, averageAccuracy: 0, byType: {} };
  }

  let totalAccuracy = 0;
  const byType: Record<string, { count: number; avgAccuracy: number; sum: number }> = {};

  for (const pred of predictions) {
    const actual = pred.actualValue!;
    const predicted = pred.predictedValue;
    // Accuracy = 1 - |predicted - actual| / |actual| (capped at 0)
    const accuracy = actual !== 0
      ? Math.max(0, 1 - Math.abs(predicted - actual) / Math.abs(actual))
      : predicted === 0 ? 1 : 0;

    totalAccuracy += accuracy;

    // Update the record
    await db.prediction.update({
      where: { id: pred.id },
      data: { accuracy },
    });

    // Track by type
    if (!byType[pred.type]) {
      byType[pred.type] = { count: 0, avgAccuracy: 0, sum: 0 };
    }
    byType[pred.type].count++;
    byType[pred.type].sum += accuracy;
  }

  // Calculate averages
  const resultByType: Record<string, { count: number; avgAccuracy: number }> = {};
  for (const [type, data] of Object.entries(byType)) {
    resultByType[type] = {
      count: data.count,
      avgAccuracy: Math.round((data.sum / data.count) * 100) / 100,
    };
  }

  return {
    evaluated: predictions.length,
    averageAccuracy: Math.round((totalAccuracy / predictions.length) * 100) / 100,
    byType: resultByType,
  };
}
