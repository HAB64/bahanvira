/**
 * ─── Chunker — تقسیم محتوا به قطعات کوچک ───
 * 
 * Chunk Size: ~500-800 token
 * Overlap: 50-100 token (~20%)
 */

export interface Chunk {
  id: string
  content: string
  metadata: {
    source: string        // e.g. 'course:python', 'page:about', 'faq:3'
    title: string
    type: 'course' | 'page' | 'faq' | 'institute' | 'career' | 'alumni' | 'policy'
    cluster?: string
    slug?: string
  }
  tokens: number         // approximate token count
}

const APPROX_CHARS_PER_TOKEN = 1.5  // Persian avg: ~1.5 chars per token
const CHUNK_SIZE = 750              // ~500 tokens
const OVERLAP_SIZE = 120            // ~80 tokens
const MIN_CHUNK_SIZE = 200          // ~130 tokens minimum

/**
 * تقسیم متن به قطعات با Overlap
 */
export function chunkText(text: string): string[] {
  if (text.length <= CHUNK_SIZE) return [text]

  const chunks: string[] = []
  let start = 0

  while (start < text.length) {
    let end = Math.min(start + CHUNK_SIZE, text.length)

    // If not the last chunk, try to break at sentence boundary
    if (end < text.length) {
      const lastPeriod = text.lastIndexOf('。', end)
      const lastNewline = text.lastIndexOf('\n', end)
      const lastDot = text.lastIndexOf('.', end)
      const breakPoint = Math.max(lastPeriod, lastNewline, lastDot)

      if (breakPoint > start + MIN_CHUNK_SIZE) {
        end = breakPoint + 1
      }
    }

    chunks.push(text.slice(start, end).trim())
    start = end - OVERLAPS_SIZE

    if (start < 0) start = 0
  }

  return chunks.filter(c => c.length >= MIN_CHUNK_SIZE)
}

// Fix: use OVERLAP_SIZE consistently
const OVERLAPS_SIZE = OVERLAP_SIZE

/**
 * محاسبه تعداد تقریبی توکن
 */
export function estimateTokens(text: string): number {
  return Math.ceil(text.length / APPROX_CHARS_PER_TOKEN)
}

/**
 * ساخت Chunk با شناسه یکتا
 */
export function createChunk(content: string, source: string, title: string, type: Chunk['metadata']['type'], extra?: Partial<Chunk['metadata']>): Chunk {
  const textChunks = chunkText(content)
  return textChunks.map((text, index) => ({
    id: `${source}::${index}`,
    content: text,
    metadata: {
      source,
      title,
      type,
      ...extra,
    },
    tokens: estimateTokens(text),
  }))
}

/**
 * ساخت Index از تمام منابع دانش
 */
export function buildKnowledgeIndex(): Chunk[] {
  const chunks: Chunk[] = []

  // فقط import داینامیک برای جلوگیری از circular deps
  // chunks از data files ساخته می‌شوند
  return chunks
}
