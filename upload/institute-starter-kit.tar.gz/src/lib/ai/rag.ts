// Phase 3 Completion — Hybrid Search (Keyword + Semantic RRF)

/**
 * ─── RAG Pipeline — Lightweight Keyword-Based Retrieval ───
 * 
 * جایگزین سبک برای TF-IDF Vector Store که OOM ایجاد می‌کرد.
 * از Keyword Matching + TF Scoring استفاده می‌کند.
 * مصرف حافظه: <5MB (به جای 200MB+ قبل)
 */

import {
  COURSES_KNOWLEDGE,
  CAREER_PATHS,
  FAQ_KNOWLEDGE,
  COURSE_COMPARISONS,
  ALUMNI_STORIES,
  AGE_RECOMMENDATIONS,
  CONTACT_KNOWLEDGE,
  INSTITUTE_INFO,
  CLUSTERS_KNOWLEDGE,
} from './knowledge-base'
import { buildVocabulary, textToTfidf } from './embeddings'

// ─── Persian Stopwords ─────────────────────────────────────────────────────────

const STOPWORDS = new Set([
  'و', 'در', 'به', 'از', 'با', 'برای', 'که', 'این', 'آن', 'را', 'هم', 'می',
  'است', 'بود', 'شد', 'خواهد', 'کرد', 'دارد', 'نشده', 'نیست', 'بودند',
  'کنند', 'شود', 'ما', 'شما', 'او', 'آنها', 'هر', 'یک', 'بسیاری',
  'خیلی', 'بسیار', 'ممکن', 'توان', 'باید', 'چون', 'اگر', 'هنگامی',
  'پس', 'اما', 'ولی', 'تا', 'همچنین', 'یعنی', 'مثل',
  'همان', 'دیگر', 'چند', 'بیشتر', 'کمتر', 'اول', 'آخر', 'قبل', 'بعد',
  'بین', 'ضد', 'درباره', 'پیش', 'روی', 'تحت', 'بدون',
  'دارای', 'حاوی', 'توسط', 'همین', 'حالا', 'گاهی',
  'من', 'تو', 'های', 'شان', 'تان', 'مان',
  'بله', 'خیر', 'نه', 'آیا', 'چگونه', 'چرا', 'کجا', 'کدام', 'چه',
  'کو', 'کی', 'چقدر', 'شاید', 'حتما',
  'خواهیم', 'خواهید', 'دارم', 'داری', 'داریم', 'دارید', 'دارند',
  'باشد', 'باشم', 'باشی', 'باشیم', 'باشید', 'باشند',
  'هستیم', 'هستید', 'هستند',
  'است؟', 'است', 'هست', 'هست؟',
])

// ─── Simple Text Processing ────────────────────────────────────────────────────

function normalizeAndTokenize(text: string): string[] {
  return text
    .replace(/[٠-٩]/g, d => '۰۱۲۳۴۵۶۷۸۹'['٠١٢٣٤٥٦٧٨٩'.indexOf(d)])
    .replace(/[۰-۹]/g, '')
    .replace(/[^\u0600-\u06FF\u0020-\u007E]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .split(/\s+/)
    .filter(w => w.length > 1 && !STOPWORDS.has(w))
}

function normalize(text: string): string {
  return text
    .replace(/[٠-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'['٠١٢٣٤٥٦٧٨٩'.indexOf(d)] || d)
    .replace(/\s+/g, ' ')
    .trim()
}

// ─── Knowledge Document (lightweight) ─────────────────────────────────────────

interface KDoc {
  content: string
  source: string
  title: string
  type: string
  tokens: string[]
}

// ─── Build Knowledge Base (once, cached) ────────────────────────────────────────

let cachedDocs: KDoc[] | null = null

function buildKnowledgeDocs(): KDoc[] {
  if (cachedDocs) return cachedDocs

  const docs: KDoc[] = []

  // 1. ─── Institute Info ───
  const infoContent = [
    `آموزگاه ${INSTITUTE_INFO.fullName} در ${INSTITUTE_INFO.city}، ${INSTITUTE_INFO.province}.`,
    `بنیان‌گذار: ${INSTITUTE_INFO.founder} — ${INSTITUTE_INFO.founderTitle}.`,
    `${INSTITUTE_INFO.founderCredentials.join(' | ')}.`,
    `سابقه: ${INSTITUTE_INFO.yearsExperience} سال.`,
    `تلفن: ${INSTITUTE_INFO.phone}.`,
    `موبایل: ${INSTITUTE_INFO.mobiles.map(m => m.display).join(' و ')}.`,
    `واتساپ: ${INSTITUTE_INFO.whatsapp}.`,
    `آدرس: ${INSTITUTE_INFO.fullAddress}.`,
    `ساعات کاری: ${INSTITUTE_INFO.workHours}.`,
    `ایمیل: ${INSTITUTE_INFO.email}.`,
    `وبسایت: ${INSTITUTE_INFO.website}.`,
    `اینستاگرام: ${INSTITUTE_INFO.instagramHandle}.`,
    `مجوزها: ${INSTITUTE_INFO.licenses.join(' | ')}.`,
    `روش آموزش: ${INSTITUTE_INFO.teachingMethod}.`,
    `پرداخت: ${INSTITUTE_INFO.paymentOptions.join(' | ')}.`,
  ].join(' ')
  docs.push({
    content: infoContent,
    source: 'institute:info',
    title: 'اطلاعات آموزشگاه',
    type: 'institute',
    tokens: normalizeAndTokenize(infoContent),
  })

  // 2. ─── Courses (one doc per course) ───
  for (const course of COURSES_KNOWLEDGE) {
    const content = [
      `دوره: ${course.title}`,
      course.subtitle,
      `سطح: ${course.level}`,
      `مدت: ${course.duration} (${course.sessions} جلسه)`,
      `مدرک: ${course.certificate}`,
      `پیش‌نیاز: ${(course.prerequisites || ['بدون پیش‌نیاز']).join('، ')}`,
      `نتایج یادگیری: ${(course.learningOutcomes || []).join('، ')}`,
      `سرفصل‌ها: ${(course.modules || []).map(m => m.title).join('، ')}`,
      `خوشه: ${course.cluster}`,
      `لینک: https://bahanrayaneh.ir/courses/${course.slug}`,
    ].join(' ')
    docs.push({
      content,
      source: `course:${course.slug}`,
      title: course.title,
      type: 'course',
      tokens: normalizeAndTokenize(content),
    })
  }

  // 3. ─── FAQ (one doc per FAQ) ───
  for (let i = 0; i < FAQ_KNOWLEDGE.length; i++) {
    const faq = FAQ_KNOWLEDGE[i]
    const content = `سؤال: ${faq.question} پاسخ: ${faq.answer}`
    docs.push({
      content,
      source: `faq:${i}`,
      title: faq.question,
      type: 'faq',
      tokens: normalizeAndTokenize(content),
    })
  }

  // 4. ─── Career Paths (one doc per path) ───
  for (const [key, path] of Object.entries(CAREER_PATHS)) {
    const content = [
      `مسیر شغلی: ${path.title}`,
      `مجموع مدت: ${path.totalDuration}`,
      ...path.steps.map((s, i) => `مرحله ${i + 1}: ${s.course} (${s.duration}) — ${s.description || ''}`),
    ].join(' ')
    docs.push({
      content,
      source: `career:${key}`,
      title: path.title,
      type: 'career',
      tokens: normalizeAndTokenize(content),
    })
  }

  // 5. ─── Course Comparisons (one doc per comparison) ───
  for (const [key, comp] of Object.entries(COURSE_COMPARISONS)) {
    const content = `مقایسه: ${comp.question} ${comp.answer}`
    docs.push({
      content,
      source: `comparison:${key}`,
      title: comp.question,
      type: 'policy',
      tokens: normalizeAndTokenize(content),
    })
  }

  // 6. ─── Alumni Stories ───
  for (let i = 0; i < ALUMNI_STORIES.length; i++) {
    const a = ALUMNI_STORIES[i]
    const content = `فارغ‌التحصیل: ${a.name}. دوره: ${a.course}. ${a.company ? 'شرکت: ' + a.company + '.' : ''} شغل فعلی: ${a.role}. دستاورد: ${a.achievement}.`
    docs.push({
      content,
      source: `alumni:${i}`,
      title: `${a.name} — ${a.course}`,
      type: 'alumni',
      tokens: normalizeAndTokenize(content),
    })
  }

  // 7. ─── Age Recommendations ───
  for (const [key, rec] of Object.entries(AGE_RECOMMENDATIONS)) {
    const content = `گروه سنی ${rec.label}: ${rec.message}. دوره‌ها: ${rec.courses.join('، ')}`
    docs.push({
      content,
      source: `age:${key}`,
      title: `توصیه سنی ${rec.label}`,
      type: 'policy',
      tokens: normalizeAndTokenize(content),
    })
  }

  // 8. ─── Clusters ───
  for (const cluster of CLUSTERS_KNOWLEDGE) {
    const clusterCourses = COURSES_KNOWLEDGE.filter(c => c.cluster === cluster.id).map(c => c.title).join('، ')
    const content = `خوشه ${cluster.title}: ${cluster.description}. دوره‌ها: ${clusterCourses}`
    docs.push({
      content,
      source: `cluster:${cluster.id}`,
      title: cluster.title,
      type: 'page',
      tokens: normalizeAndTokenize(content),
    })
  }

  // 9. ─── Contact Info ───
  const contactContent = [
    `تلفن ثابت: ${CONTACT_KNOWLEDGE.phone.display}.`,
    `موبایل: ${CONTACT_KNOWLEDGE.mobiles.map(m => m.display).join(' و ')}.`,
    `واتساپ: ${CONTACT_KNOWLEDGE.whatsapp.url}.`,
    `اینستاگرام: ${CONTACT_KNOWLEDGE.social.instagram.handle}.`,
    `تلگرام: ${CONTACT_KNOWLEDGE.social.telegram.url}.`,
    `ایمیل: ${CONTACT_KNOWLEDGE.email}.`,
    `آدرس: ${CONTACT_KNOWLEDGE.address.full}.`,
    `ساعات کاری: ${CONTACT_KNOWLEDGE.workHours}`,
  ].join(' ')
  docs.push({
    content: contactContent,
    source: 'contact:info',
    title: 'اطلاعات تماس',
    type: 'institute',
    tokens: normalizeAndTokenize(contactContent),
  })

  console.log(`[RAG-Lite] Knowledge base built: ${docs.length} docs`)
  cachedDocs = docs
  return docs
}

// ─── Simple Keyword Scoring ────────────────────────────────────────────────────

interface ScoredDoc {
  doc: KDoc
  score: number
}

function scoreQuery(query: string, docs: KDoc[]): ScoredDoc[] {
  const queryTokens = normalizeAndTokenize(query)
  if (queryTokens.length === 0) return []
  const queryTokenSet = new Set(queryTokens)
  const normalizedQuery = normalize(query)

  return docs.map(doc => {
    let score = 0

    // 1. Exact token overlap in document content (core relevance)
    const docTokenSet = new Set(doc.tokens)
    let overlap = 0
    for (const qt of queryTokens) {
      if (docTokenSet.has(qt)) overlap++
    }
    score += (overlap / queryTokens.length) * 0.35

    // 2. Title match — very strong signal (exact keyword in title = highly relevant)
    const titleTokens = normalizeAndTokenize(doc.title)
    let titleMatch = 0
    for (const qt of queryTokens) {
      if (titleTokens.includes(qt) || doc.title.includes(qt)) titleMatch++
    }
    score += (titleMatch / queryTokens.length) * 0.35

    // 3. Raw substring match in content (catches partial/variant matches)
    let substrMatch = 0
    for (const qt of queryTokens) {
      if (doc.content.includes(qt)) substrMatch++
    }
    score += (substrMatch / queryTokens.length) * 0.15

    // 4. Full query substring bonus
    if (normalizedQuery.length > 3 && doc.content.includes(normalizedQuery)) score += 0.1

    // 5. Type priority bonus: course > faq > career > institute
    const typeBonus: Record<string, number> = {
      course: 0.05, faq: 0.03, career: 0.02, policy: 0.02,
      alumni: 0.01, page: 0.02, institute: 0.01,
    }
    score += typeBonus[doc.type] || 0

    return { doc, score }
  }).filter(r => r.score > 0.05).sort((a, b) => b.score - a.score)
}

// ─── RAG Retrieval ──────────────────────────────────────────────────────────────

export interface RetrievedContext {
  chunks: { content: string; source: string; title: string }[]
  formatted: string
  sources: string[]
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
}

/**
 * بازیابی محتوای مرتبط با سؤال
 * Lightweight keyword-based scoring
 */
export function retrieve(query: string, topK = 7): RetrievedContext {
  try {
    const docs = buildKnowledgeDocs()
    const scored = scoreQuery(query, docs)
    const topDocs = scored.slice(0, topK)

    if (topDocs.length === 0) {
      return { chunks: [], formatted: '', sources: [], confidence: 'LOW' }
    }

    const topScore = topDocs[0].score
    const confidence: 'HIGH' | 'MEDIUM' | 'LOW' =
      topScore > 0.5 ? 'HIGH' :
      topScore > 0.2 ? 'MEDIUM' : 'LOW'

    const chunks = topDocs.map(r => ({
      content: r.doc.content,
      source: r.doc.source,
      title: r.doc.title,
    }))

    const formatted = chunks.map((c, i) =>
      `[${i + 1}] (${c.title})\n${c.content}`
    ).join('\n\n---\n\n')

    const sources = [...new Set(chunks.map(c => c.source))]

    return { chunks, formatted, sources, confidence }
  } catch (error) {
    console.error('[RAG-Lite] Retrieve error:', error instanceof Error ? error.message : String(error))
    return { chunks: [], formatted: '', sources: [], confidence: 'LOW' }
  }
}

/**
 * بازیابی فقط از یک نوع منبع خاص
 */
export function retrieveByType(query: string, type: string, topK = 3): RetrievedContext {
  try {
    const docs = buildKnowledgeDocs().filter(d => d.type === type)
    const scored = scoreQuery(query, docs)
    const topDocs = scored.slice(0, topK)

    const chunks = topDocs.map(r => ({
      content: r.doc.content,
      source: r.doc.source,
      title: r.doc.title,
    }))

    return {
      chunks,
      formatted: chunks.map((c, i) => `[${i + 1}] ${c.content}`).join('\n\n'),
      sources: chunks.map(c => c.source),
      confidence: chunks.length > 0 && topDocs[0].score > 0.3 ? 'HIGH' : 'LOW',
    }
  } catch (error) {
    console.error('[RAG-Lite] retrieveByType error:', error instanceof Error ? error.message : String(error))
    return { chunks: [], formatted: '', sources: [], confidence: 'LOW' }
  }
}

// ─── Hybrid Search (Keyword + Semantic RRF) ────────────────────────────────────

/** Options for hybridSearch */
export interface HybridSearchOptions {
  /** Number of top results to return (default: 7) */
  topK?: number
  /** Optional type filter (e.g. 'course', 'faq') */
  type?: string
  /** Weights for each ranking method (default: keyword 0.6, semantic 0.4) */
  weights?: { keyword: number; semantic: number }
}

/** Extended result from hybrid search with per-method scores */
export interface HybridResult {
  content: string
  source: string
  title: string
  combinedScore: number
  keywordScore: number
  semanticScore: number
  rrfScore: number
}

/**
 * جستجوی ترکیبی (Hybrid Search) — ترکیب Keyword Search و Semantic Search
 * با استفاده از Reciprocal Rank Fusion (RRF) برای ادغام رتبه‌بندی‌ها.
 *
 * الگوریتم:
 *   1. Keyword: از retrieve() برای نتایج مبتنی بر کلمات کلیدی
 *   2. Semantic: از TF-IDF + Cosine Similarity از embeddings.ts
 *   3. RRF: ادغام دو رتبه‌بندی با فرمول  Σ w_i / (k + rank_i)
 *
 * @param query  — عبارت جستجو
 * @param options — تنظیمات اختیاری (topK, type, weights)
 */
export function hybridSearch(
  query: string,
  options: HybridSearchOptions = {},
): HybridResult[] {
  const {
    topK = 7,
    type,
    weights = { keyword: 0.6, semantic: 0.4 },
  } = options

  const docs = buildKnowledgeDocs()
  const filteredDocs = type ? docs.filter(d => d.type === type) : docs

  if (filteredDocs.length === 0) return []

  // ── 1. Keyword ranking via existing scoreQuery() ──
  const keywordResults = scoreQuery(query, filteredDocs)
  const keywordRanking = new Map<string, number>() // source → rank (1-based)
  const keywordScoreMap = new Map<string, number>() // source → raw score
  keywordResults.forEach((item, index) => {
    keywordRanking.set(item.doc.source, index + 1)
    keywordScoreMap.set(item.doc.source, item.score)
  })

  // ── 2. Semantic ranking via TF-IDF cosine similarity ──
  // Build vocabulary from all filtered docs (treated as chunks for buildVocabulary)
  const pseudoChunks = filteredDocs.map(d => ({ content: d.content } as import('./chunker').Chunk))
  const vocab = buildVocabulary(pseudoChunks)
  const queryVector = textToTfidf(query, vocab)

  // Compute cosine similarity for each doc
  interface SemanticEntry {
    doc: KDoc
    similarity: number
  }

  const semanticEntries: SemanticEntry[] = []
  for (const doc of filteredDocs) {
    const docVector = textToTfidf(doc.content, vocab)
    const sim = cosineSim(queryVector, docVector)
    if (sim > 0) {
      semanticEntries.push({ doc, similarity: sim })
    }
  }
  semanticEntries.sort((a, b) => b.similarity - a.similarity)

  const semanticRanking = new Map<string, number>() // source → rank (1-based)
  const semanticScoreMap = new Map<string, number>() // source → raw score
  semanticEntries.forEach((item, index) => {
    semanticRanking.set(item.doc.source, index + 1)
    semanticScoreMap.set(item.doc.source, item.similarity)
  })

  // ── 3. Reciprocal Rank Fusion ──
  const RRF_K = 60 // Standard RRF constant
  const allSources = new Set<string>([
    ...keywordRanking.keys(),
    ...semanticRanking.keys(),
  ])

  const fused: HybridResult[] = []

  for (const source of allSources) {
    const kRank = keywordRanking.get(source)
    const sRank = semanticRanking.get(source)

    // RRF contribution from each method
    const keywordRRF = kRank !== undefined ? weights.keyword / (RRF_K + kRank) : 0
    const semanticRRF = sRank !== undefined ? weights.semantic / (RRF_K + sRank) : 0
    const rrfScore = keywordRRF + semanticRRF

    // Raw scores for reference
    const keywordScore = keywordScoreMap.get(source) ?? 0
    const semanticScore = semanticScoreMap.get(source) ?? 0

    // Find the doc
    const doc = filteredDocs.find(d => d.source === source)
    if (!doc) continue

    fused.push({
      content: doc.content,
      source: doc.source,
      title: doc.title,
      combinedScore: rrfScore,
      keywordScore,
      semanticScore,
      rrfScore,
    })
  }

  // Sort by combined RRF score (descending) and return top-K
  return fused
    .sort((a, b) => b.rrfScore - a.rrfScore)
    .slice(0, topK)
}

// ─── Lightweight Cosine Similarity (TF-IDF vectors) ────────────────────────────

/**
 * شباهت کسینوسی بین دو بردار TF-IDF
 * (نسخه سبک بدون وابستگی به VectorStore کلاس)
 */
function cosineSim(
  a: { terms: string[]; values: number[] },
  b: { terms: string[]; values: number[] },
): number {
  // Build index for vector b
  const bMap = new Map(b.terms.map((t, i) => [t, b.values[i]]))

  // Dot product
  let dot = 0
  for (let i = 0; i < a.terms.length; i++) {
    const bv = bMap.get(a.terms[i])
    if (bv !== undefined) {
      dot += a.values[i] * bv
    }
  }

  // Magnitudes
  const magA = Math.sqrt(a.values.reduce((s, v) => s + v * v, 0))
  const magB = Math.sqrt(b.values.reduce((s, v) => s + v * v, 0))
  if (magA === 0 || magB === 0) return 0

  return dot / (magA * magB)
}
