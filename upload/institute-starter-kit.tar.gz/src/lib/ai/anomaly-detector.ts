/**
 * ─── Anomaly Detector — تشخیص ناهنجاری و تحلیل سری زمانی ───
 *
 * شامل سه تابع اصلی:
 *   ۱. detectAnomalies    — تشخیص ناهنجاری با روش Z-Score
 *   ۲. seasonalDecompose  — تجزیه فصلی (روند + فصلی + باقیمانده)
 *   ۳. exponentialSmoothingForecast — پیش‌بینی با هموارسازی نمایی دوبل (هالت)
 */

// ─── Types ──────────────────────────────────────────────────────────────────────

/** نتیجه تشخیص ناهنجاری برای یک نقطه داده */
export interface AnomalyResult {
  /** آیا این نقطه ناهنجاری است یا نه */
  isAnomaly: boolean
  /** امتیاز Z-Score قدرمطلق (بزرگ‌تر = ناهنجاری‌تر) */
  score: number
  /** شاخص نقطه در آرایه اصلی */
  index: number
  /** مقدار اصلی نقطه داده */
  value: number
}

/** نتیجه تجزیه فصلی */
export interface SeasonalDecomposition {
  /** مؤلفه روند (میانگین متحرک) */
  trend: number[]
  /** مؤلفه فصلی (تکرار الگو) */
  seasonal: number[]
  /** مؤلفه باقیمانده (تفاوت از روند و فصلی) */
  residual: number[]
}

/** نتیجه پیش‌بینی با هموارسازی نمایی */
export interface ForecastResult {
  /** مقادیر پیش‌بینی‌شده */
  forecast: number[]
  /** بازه اطمینان */
  confidence: {
    /** کران بالایی */
    upper: number[]
    /** کران پایینی */
    lower: number[]
  }
}

// ─── 1. detectAnomalies ────────────────────────────────────────────────────────

/**
 * تشخیص ناهنجاری با روش Z-Score روی پنجره متحرک
 *
 * این تابع هر نقطه داده را با میانگین و انحراف معیار پنجره‌ای از نقاط
 * قبلی مقایسه می‌کند. اگر Z-Score قدرمطلق از آستانه عبور کند، آن نقطه
 * به عنوان ناهنجاری علامت‌گذاری می‌شود.
 *
 * نکته: برای نقاط اولیه که پنجره کامل ندارند، از تمام نقاط قبلی استفاده می‌شود.
 *
 * @param dataPoints  — آرایه اعداد ورودی (سری زمانی)
 * @param windowSize  — اندازه پنجره متحرک (پیش‌فرض: ۵)
 * @param threshold   — آستانه Z-Score برای ناهنجاری (پیش‌فرض: ۲)
 * @returns آرایه‌ای از نتایج ناهنجاری، فقط نقاطی که isAnomaly=true دارند برگردانده می‌شوند
 */
export function detectAnomalies(
  dataPoints: number[],
  windowSize: number = 5,
  threshold: number = 2,
): AnomalyResult[] {
  if (dataPoints.length < 2) return []

  const results: AnomalyResult[] = []

  for (let i = 0; i < dataPoints.length; i++) {
    // تعیین پنجره: از ابتدا تا نقطه فعلی (بدون خود نقطه)
    const start = Math.max(0, i - windowSize)
    const window = dataPoints.slice(start, i)

    if (window.length === 0) continue

    // محاسبه میانگین پنجره
    const mean = window.reduce((sum, v) => sum + v, 0) / window.length

    // محاسبه انحراف معیار پنجره
    const variance =
      window.reduce((sum, v) => sum + (v - mean) ** 2, 0) / window.length
    const stdDev = Math.sqrt(variance)

    // اگر انحراف معیار صفر باشد، ناهنجاری تشخیص داده نمی‌شود
    if (stdDev === 0) {
      results.push({
        isAnomaly: false,
        score: 0,
        index: i,
        value: dataPoints[i],
      })
      continue
    }

    // محاسبه Z-Score
    const zScore = (dataPoints[i] - mean) / stdDev
    const absZScore = Math.abs(zScore)

    results.push({
      isAnomaly: absZScore > threshold,
      score: absZScore,
      index: i,
      value: dataPoints[i],
    })
  }

  // فقط نقاط ناهنجار را برگردان
  return results.filter(r => r.isAnomaly)
}

// ─── 2. seasonalDecompose ──────────────────────────────────────────────────────

/**
 * تجزیه فصلی ساده (Seasonal Decomposition)
 *
 * یک سری زمانی را به سه مؤلفه تجزیه می‌کند:
 *   - روند (Trend): میانگین متحرک با پنجره برابر دوره تکرار
 *   - فصلی (Seasonal): الگوی تکرارشونده با دوره مشخص
 *   - باقیمانده (Residual): تفاوت بین داده اصلی و مجموع روند و فصلی
 *
 * این روش نسخه ساده‌شده additive decomposition است که
 * برای تحلیل‌های اولیه سری‌های زمانی مناسب است.
 *
 * @param dataPoints — آرایه اعداد ورودی (سری زمانی)
 * @param period     — دوره تکرار فصلی (پیش‌فرض: محاسبه خودکار با حداقل ۳)
 * @returns شیء شامل سه آرایه: trend, seasonal, residual
 */
export function seasonalDecompose(
  dataPoints: number[],
  period?: number,
): SeasonalDecomposition {
  const n = dataPoints.length
  if (n === 0) return { trend: [], seasonal: [], residual: [] }

  // تعیین دوره: اگر مشخص نشده، از حداقل ۳ یا نصف طول داده استفاده می‌شود
  const p = period ?? Math.max(3, Math.min(Math.floor(n / 2), n))

  // ── مؤلفه روند: میانگین متحرک با پنجره دوره ──
  const trend: number[] = []
  const halfWindow = Math.floor(p / 2)

  for (let i = 0; i < n; i++) {
    const start = Math.max(0, i - halfWindow)
    const end = Math.min(n, i + halfWindow + 1)
    const windowSlice = dataPoints.slice(start, end)
    trend.push(windowSlice.reduce((s, v) => s + v, 0) / windowSlice.length)
  }

  // ── حذف روند: Detrended = Original - Trend ──
  const detrended = dataPoints.map((v, i) => v - trend[i])

  // ── مؤلفه فصلی: میانگین مقادیر detrended در هر موقعیت دوره‌ای ──
  // هر نقطه به یک موقعیت در دوره نسبت داده می‌شود
  const seasonalAverages = new Array(p).fill(0)
  const seasonalCounts = new Array(p).fill(0)

  for (let i = 0; i < n; i++) {
    const seasonIndex = i % p
    seasonalAverages[seasonIndex] += detrended[i]
    seasonalCounts[seasonIndex]++
  }

  // میانگین‌گیری برای هر موقعیت فصلی
  for (let s = 0; s < p; s++) {
    if (seasonalCounts[s] > 0) {
      seasonalAverages[s] /= seasonalCounts[s]
    }
  }

  // ساخت آرایه فصلی با تکرار الگو
  const seasonal: number[] = []
  for (let i = 0; i < n; i++) {
    seasonal.push(seasonalAverages[i % p])
  }

  // ── مؤلفه باقیمانده: Residual = Original - Trend - Seasonal ──
  const residual = dataPoints.map((v, i) => v - trend[i] - seasonal[i])

  return { trend, seasonal, residual }
}

// ─── 3. exponentialSmoothingForecast ───────────────────────────────────────────

/**
 * پیش‌بینی با روش هموارسازی نمایی دوبل (Double Exponential Smoothing / Holt's Method)
 *
 * این روش دو مؤلفه دارد:
 *   - سطح (Level): مقدار هموارسازی‌شده اصلی با ضریب آلفا
 *   - روند (Trend): شیب هموارسازی‌شده با ضریب آلفا
 *
 * فرمول به‌روزرسانی:
 *   Level(t)  = α × Y(t) + (1 - α) × [Level(t-1) + Trend(t-1)]
 *   Trend(t)  = α × [Level(t) - Level(t-1)] + (1 - α) × Trend(t-1)
 *   Forecast  = Level(last) + h × Trend(last)
 *
 * بازه اطمینان با فرض توزیع نرمال خطاها و افزایش تدریجی عرض با فاصله از آخرین نقطه.
 *
 * @param dataPoints — آرایه اعداد ورودی (سری زمانی تاریخی)
 * @param alpha      — ضریب هموارسازی (پیش‌فرض: ۰.۳) — مقادیر بالاتر = واکنش سریع‌تر
 * @param horizon    — تعداد دوره‌های پیش‌بینی (پیش‌فرض: ۵)
 * @returns شیء شامل آرایه پیش‌بینی و بازه اطمینان
 */
export function exponentialSmoothingForecast(
  dataPoints: number[],
  alpha: number = 0.3,
  horizon: number = 5,
): ForecastResult {
  const n = dataPoints.length

  // حالت لبه: داده ناکافی
  if (n === 0) {
    return {
      forecast: new Array(horizon).fill(0),
      confidence: {
        upper: new Array(horizon).fill(0),
        lower: new Array(horizon).fill(0),
      },
    }
  }

  if (n === 1) {
    const val = dataPoints[0]
    const forecast = new Array(horizon).fill(val)
    return {
      forecast,
      confidence: {
        upper: new Array(horizon).fill(val),
        lower: new Array(horizon).fill(val),
      },
    }
  }

  // مقداردهی اولیه: سطح = اولین مقدار، روند = اختلاف دو مقدار اول
  let level = dataPoints[0]
  let trend = dataPoints[1] - dataPoints[0]

  // محاسبه خطاها برای تخمین انحراف معیار (برای بازه اطمینان)
  const errors: number[] = []

  // ── عبور از داده‌ها و به‌روزرسانی سطح و روند ──
  for (let i = 1; i < n; i++) {
    const prevLevel = level
    const prevTrend = trend

    // به‌روزرسانی سطح
    level = alpha * dataPoints[i] + (1 - alpha) * (prevLevel + prevTrend)

    // به‌روزرسانی روند
    trend = alpha * (level - prevLevel) + (1 - alpha) * prevTrend

    // ثبت خطا (تفاوت پیش‌بینی یک‌قدمه از مقدار واقعی)
    const oneStepForecast = prevLevel + prevTrend
    errors.push(dataPoints[i] - oneStepForecast)
  }

  // ── محاسبه انحراف معیار خطاها ──
  const meanError = errors.reduce((s, e) => s + e, 0) / errors.length
  const errorVariance =
    errors.reduce((s, e) => s + (e - meanError) ** 2, 0) / errors.length
  const errorStdDev = Math.sqrt(errorVariance)

  // ── تولید پیش‌بینی برای horizon دوره آینده ──
  const forecast: number[] = []
  const upper: number[] = []
  const lower: number[] = []

  // ضریب افزایش بازه اطمینان (هرچه دورتر، عدم قطعیت بیشتر)
  const confidenceMultiplier = 1.96 // ≈ 95% confidence interval

  for (let h = 1; h <= horizon; h++) {
    const pointForecast = level + h * trend
    forecast.push(pointForecast)

    // عرض بازه اطمینان با ریشه مربع فاصله افزایش می‌یابد
    const intervalWidth = confidenceMultiplier * errorStdDev * Math.sqrt(h)
    upper.push(pointForecast + intervalWidth)
    lower.push(pointForecast - intervalWidth)
  }

  return { forecast, confidence: { upper, lower } }
}