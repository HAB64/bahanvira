/**
 * ─── موتور عامل‌های هوش مصنوعی بهان رایانه ───
 *
 * سیستم جامع مدیریت عامل‌های AI برای فروش، پشتیبانی و مشاوره
 * از z-ai-web-dev-sdk برای تولید پاسخ هوشمند استفاده می‌کند
 *
 * مهم: این فایل فقط سمت سرور استفاده می‌شود
 */

import { db } from '@/lib/db';
import { buildComprehensiveSystemPrompt } from '@/lib/ai/knowledge-base';

// ─── Types ────────────────────────────────────────────────────────────────────

export type AgentType = 'SALES' | 'SUPPORT' | 'CONSULTANT' | 'FOLLOW_UP' | 'RETENTION';
export type Sentiment = 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE';
export type Intent = 'COURSE_INQUIRY' | 'PRICING' | 'REGISTRATION' | 'COMPLAINT' | 'GENERAL';
export type ConversationStatus = 'ACTIVE' | 'COMPLETED' | 'HANDED_OFF' | 'EXPIRED';
export type ConversationOutcome = 'ENROLLED' | 'INFORMED' | 'HANDED_OFF' | 'ABANDONED' | null;

export interface CreateAgentData {
  name: string;
  type: AgentType;
  description?: string;
  systemPrompt?: string;
  isActive?: boolean;
  maxConversations?: number;
  responseDelayMs?: number;
  handoffToHuman?: boolean;
  handoffCondition?: string;
}

export interface StartConversationData {
  agentId: string;
  leadId?: string;
  karAmuzId?: string;
  channel?: string;
  context?: Record<string, unknown>;
}

export interface SendMessageResult {
  conversationId: string;
  reply: string;
  suggestedActions: string[];
  sentiment: Sentiment;
  intent: Intent;
}

// ─── Agent System Prompts ─────────────────────────────────────────────────────

const AGENT_SYSTEM_PROMPTS: Record<AgentType, string> = {
  SALES: `تو یک عامل فروش هوشمند آموزشگاه بهان رایانه هستی. وظیفه تو تبدیل لیدها به مشتری است.

اهداف:
- معرفی دوره‌های مناسب بر اساس نیاز کاربر
- پاسخ به سؤالات قیمتی و ارائه تخفیف‌ها
- رفع اعتراضات و تشویق به ثبت‌نام
- پیشنهاد مسیرهای شغلی مرتبط

قوانین:
- همیشه فارسی روان و صمیمی صحبت کن
- هرگز اطلاعات ساختی نده — فقط از اطلاعات واقعی آموزشگاه استفاده کن
- اگر کاربر عصبانی شد، بلافاصله پیشنهاد ارجاع به مشاور انسانی بده
- در پایان هر پیام، یک فراخوان به اقدام (CTA) بده
- قسط‌بندی بدون چک و بدون بهره را حتماً ذکر کن
- برای هر کاربر، حداکثر ۳ دوره مرتبط پیشنهاد بده`,

  SUPPORT: `تو یک عامل پشتیبانی هوشمند آموزشگاه بهان رایانه هستی. وظیفه تو حل مشکلات فنی و پاسخ به سؤالات متداول است.

اهداف:
- پاسخ سریع به سؤالات متداول
- راهنمایی در مورد فرآیندهای آموزشگاه (ثبت‌نام، گواهینامه، حضور)
- حل مشکلات ساده فنی
- ارجاع مسائل پیچیده به کارشناس انسانی

قوانین:
- صبور و محترمانه باش
- اگر مشکل خارج از حوزه تخصص توست، صادقانه بگو و ارجاع بده
- مراحل را شماره‌گذاری کن تا کاربر راحت پیگیری کند
- اگر کاربر ناراضی است، اول همدلی نشان بده و بعد راه‌حل بده
- هرگز اطلاعاتی که ندارستی نده — بگو «برای اطلاعات دقیق‌تر با کارشناسان تماس بگیرید»`,

  CONSULTANT: `تو یک مشاور شغلی و آموزشی هوشمند آموزشگاه بهان رایانه هستی. وظیفه تو راهنمایی کاربران برای انتخاب بهترین مسیر شغلی و آموزشی است.

اهداف:
- شناخت نیازها، علاقه‌مندی‌ها و سطح کاربر
- پیشنهاد مسیر شغلی مناسب بر اساس سن، تحصیلات و اهداف
- مقایسه دوره‌ها و کمک به تصمیم‌گیری
- تشویق به شروع یادگیری

قوانین:
- ابتدا از کاربر بپرس: سن، سطح فعلی، هدف شغلی
- بر اساس پاسخ‌ها، مسیر شغلی پیشنهاد بده
- همیشه گزینه‌های مختلف را مقایسه کن
- از تجربیات فارغ‌التحصیلان موفق استفاده کن
- برای کودکان و نوجوانان لحن دوستانه‌تر داشته باش
- اگر کاربر اهدافش مبهم است، سؤالات راهنما بپرس`,

  FOLLOW_UP: `تو یک عامل پیگیری هوشمند آموزشگاه بهان رایانه هستی. وظیفه تو بازگرداندن لیدهای سرد و تشویق دوباره کاربران است.

اهداف:
- بازگرداندن کاربرانی که ثبت‌نام را نیمه‌کاره رها کرده‌اند
- ارسال یادآوری‌های دوره‌های جدید
- پیشنهاد تخفیف‌های ویژه برای بازگشت
- ایجاد حس فوریت و فرصت محدود

قوانین:
- لحن دوستانه و غیرفروشی داشته باش
- هرگز مزاحم به نظر نرسی — حداکثر ۳ پیام پیگیری
- همیشه ارزش پیشنهاد را برجسته کن
- تخفیف‌های واقعی و محدود ارائه بده
- اگر کاربر پاسخ نمی‌دهد، پیام آخر را خوشامدگویانه ببند`,

  RETENTION: `تو یک عامل حفظ مشتری هوشمند آموزشگاه بهان رایانه هستی. وظیفه تو جلوگیری از ریزش کارآموزان و حفظ رضایت آن‌هاست.

اهداف:
- شناسایی کارآموزان ناراضی و رفع نگرانی‌هایشان
- ارائه تخفیف‌های ویژه برای ادامه مسیر
- حل مشکلات پرداخت و حضور
- تشویق به ادامه یادگیری

قوانین:
- همدلانه و حمایتی باش
- مشکلات را سریع به مسئول مربوطه ارجاع بده
- تخفیف ویژه ادامه‌دهندگان ارائه بده
- اگر کاربر قصد ترک دارد، دلیل را بپرس و راه‌حل بده
- هرگز کاربر را مقصر نکن — مشکل را سازمانی ببین`,
};

// ─── ZAI SDK Helper ───────────────────────────────────────────────────────────

async function getZAI() {
  const ZAI = (await import('z-ai-web-dev-sdk')).default;
  return ZAI.create();
}

async function chatCompletion(
  systemPrompt: string,
  messages: Array<{ role: string; content: string }>,
  options?: { temperature?: number; maxTokens?: number }
): Promise<string | null> {
  try {
    const zai = await getZAI();

    const allMessages = [
      { role: 'system', content: systemPrompt },
      ...messages.map(m => ({ role: m.role as 'user' | 'assistant', content: m.content })),
    ];

    const completion = await zai.chat.completions.create({
      messages: allMessages,
      temperature: options?.temperature ?? 0.5,
      ...(options?.maxTokens ? { max_tokens: options.maxTokens } : {}),
    });

    return completion.choices?.[0]?.message?.content || null;
  } catch (error) {
    console.error(
      JSON.stringify({
        level: 'ERROR',
        module: 'agent-engine',
        action: 'chatCompletion',
        message: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
      })
    );
    return null;
  }
}

// ─── Sentiment Analysis ───────────────────────────────────────────────────────

const PERSIAN_POSITIVE_WORDS = [
  'ممنون', 'عالی', 'خوب', 'عالیست', 'خیلی خوب', 'خوشحال', 'راضی', 'تشکر',
  'سپاس', 'مرسی', 'دستت درد نکنه', 'حرف نداره', 'فوق‌العاده', 'بی‌نظیر',
  'مایل', 'می‌خوام', 'ثبت‌نام', 'شروع', 'آماده', 'بله', 'بله حتماً',
];

const PERSIAN_NEGATIVE_WORDS = [
  'ناراضی', 'بد', 'ضعیف', 'مشکل', 'شکایت', 'نمی‌خوام', 'بی‌کیفیت', 'گرون',
  'اسراف', 'وقت تلف', 'ناراحت', 'عصبانی', 'حذف', 'لغو', 'انصراف',
  'برنمی‌گردم', 'دیگه نمیام', 'پولم رو پس بگیرید', 'خیلی بد',
];

export function analyzeSentiment(text: string): Sentiment {
  const normalized = text.toLowerCase().trim();

  let positiveScore = 0;
  let negativeScore = 0;

  for (const word of PERSIAN_POSITIVE_WORDS) {
    if (normalized.includes(word)) positiveScore++;
  }

  for (const word of PERSIAN_NEGATIVE_WORDS) {
    if (normalized.includes(word)) negativeScore++;
  }

  if (negativeScore > positiveScore + 1) return 'NEGATIVE';
  if (positiveScore > negativeScore + 1) return 'POSITIVE';
  if (negativeScore > 0 && negativeScore >= positiveScore) return 'NEGATIVE';
  if (positiveScore > 0 && positiveScore > negativeScore) return 'POSITIVE';
  return 'NEUTRAL';
}

// ─── Intent Detection ─────────────────────────────────────────────────────────

const INTENT_PATTERNS: Record<Intent, string[]> = {
  COURSE_INQUIRY: [
    'دوره', 'کلاس', 'آموزش', 'سرفصل', 'مدرس', 'جلسه', 'مدت', 'ساعت',
    'محتوا', 'برنامه', 'چه یاد می‌گیرم', 'پیش‌نیاز', 'مدرک',
  ],
  PRICING: [
    'قیمت', 'شهریه', 'هزینه', 'تخفیف', 'پرداخت', 'قسط', 'نقد',
    'چقدر', 'مبلغ', 'رایگان', 'اقساط', 'چک',
  ],
  REGISTRATION: [
    'ثبت‌نام', 'فرم', 'ثبت', 'عضویت', 'شرکت', 'شروع',
    'ملحق', 'دانشجو', 'کارآموز', 'مدارک', 'عکس',
  ],
  COMPLAINT: [
    'شکایت', 'مشکل', 'ناراضی', 'بد', 'ضعیف', 'حذف', 'لغو',
    'برنگشت', 'پس گرفتن', 'خرابی', 'خطا', 'نقص',
  ],
  GENERAL: [],
};

export function detectIntent(text: string): Intent {
  const normalized = text.toLowerCase().trim();

  let bestIntent: Intent = 'GENERAL';
  let bestScore = 0;

  for (const [intent, patterns] of Object.entries(INTENT_PATTERNS)) {
    if (intent === 'GENERAL') continue;
    let score = 0;
    for (const pattern of patterns) {
      if (normalized.includes(pattern)) score++;
    }
    if (score > bestScore) {
      bestScore = score;
      bestIntent = intent as Intent;
    }
  }

  return bestIntent;
}

// ─── Fallback Responses ───────────────────────────────────────────────────────

const FALLBACK_RESPONSES: Record<AgentType, string[]> = {
  SALES: [
    'سلام! من مشاور فروش آموزشگاه بهان رایانه هستم. چطور می‌تونم کمکتون کنم؟ برای مشاهده دوره‌ها می‌تونید به صفحه دوره‌ها مراجعه کنید.',
    'ممنون از پیامتون! برای مشاوره رایگان و انتخاب بهترین دوره، لطفاً بگید چه حوزه‌ای بهتون علاقه داره.',
    'بله، حتماً! ما دوره‌های متنوعی در حوزه‌های فناوری، مالی، مدیریت و کارآفرینی داریم. کدوم حوزه رو می‌خواید بیشتر بشنوید؟',
  ],
  SUPPORT: [
    'سلام! من از تیم پشتیبانی آموزشگاه بهان رایانه هستم. مشکلی هست که بتونم کمکتون کنم؟',
    'برای پیگیری مشکلتون لطفاً جزئیات بیشتری بگید. می‌تونم در مورد ثبت‌نام، گواهینامه، یا سؤالات فنی کمکتون کنم.',
    'متوجه شدم. این مشکل رو بررسی می‌کنم. اگر نیاز به راهنمایی بیشتر دارید، با شماره ۰۱۱-۳۲۳۲۶۶۷۵ تماس بگیرید.',
  ],
  CONSULTANT: [
    'سلام! من مشاور شغلی آموزشگاه بهان رایانه هستم. برای پیشنهاد بهترین مسیر، لطفاً بگید سن‌تون چقدره و چه هدف شغلی دارید؟',
    'خوشحالم که به فکر پیشرفت هستید! برای مشاوره بهتر، بگید سطح فعلی‌تون چطوره و به کدوم حوزه علاقه‌مندید.',
    'عالیه! بر اساس علاقه‌مندی‌تون، چند مسیر شغلی می‌تونم پیشنهاد بدم. لطفاً کمی درباره هدفتون بیشتر بگید.',
  ],
  FOLLOW_UP: [
    'سلام! دیدم قبلاً به دوره‌های ما علاقه‌مند بودید. الان تخفیف ویژه‌ای داریم که شاید براتون جالب باشه!',
    'خیلی وقت پیش با هم صحبت کردیم. هنوز به فکر شروع دوره هستید؟ اگر سؤالی دارید، اینجا هستم.',
    'دوره‌های جدیدی اضافه شد که شاید براتون جالب باشه! مایلید اطلاعات بیشتر بدم؟',
  ],
  RETENTION: [
    'سلام! دیدم مدتی نبودید. همه منتظرتون هستیم! اگر مشکلی هست که می‌تونم حل کنم، حتماً بگید.',
    'می‌فهمم ممکنه نگرانی‌هایی داشته باشید. بیایید با هم بررسی کنیم چطور می‌تونیم ادامه مسیر رو براتون راحت‌تر کنیم.',
    'ما برای کارآموزان قدیمی تخفیف ویژه داریم! ادامه بدید، نتیجه‌ش رو خواهید دید.',
  ],
};

function getFallbackResponse(agentType: AgentType): string {
  const responses = FALLBACK_RESPONSES[agentType] || FALLBACK_RESPONSES.GENERAL;
  return responses[Math.floor(Math.random() * responses.length)];
}

// ─── Core Functions ───────────────────────────────────────────────────────────

/**
 * ساخت عامل AI جدید
 */
export async function createAgent(data: CreateAgentData) {
  const systemPrompt = data.systemPrompt || AGENT_SYSTEM_PROMPTS[data.type] || AGENT_SYSTEM_PROMPTS.GENERAL;

  const agent = await db.aIAgent.create({
    data: {
      name: data.name,
      type: data.type,
      description: data.description || '',
      systemPrompt,
      isActive: data.isActive ?? true,
      maxConversations: data.maxConversations ?? 50,
      responseDelayMs: data.responseDelayMs ?? 1000,
      handoffToHuman: data.handoffToHuman ?? true,
      handoffCondition: data.handoffCondition || null,
    },
  });

  return agent;
}

/**
 * شروع مکالمه جدید با عامل AI
 */
export async function startConversation(data: StartConversationData) {
  const agent = await db.aIAgent.findUnique({
    where: { id: data.agentId },
  });

  if (!agent) {
    throw new Error('عامل یافت نشد');
  }

  if (!agent.isActive) {
    throw new Error('عامل غیرفعال است');
  }

  // بررسی تعداد مکالمات فعال
  const activeCount = await db.aIAgentConversation.count({
    where: {
      agentId: data.agentId,
      status: 'ACTIVE',
    },
  });

  if (activeCount >= agent.maxConversations) {
    throw new Error('حداکثر تعداد مکالمات فعال رسید');
  }

  const sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

  const conversation = await db.aIAgentConversation.create({
    data: {
      agentId: data.agentId,
      leadId: data.leadId || null,
      karAmuzId: data.karAmuzId || null,
      sessionId,
      channel: data.channel || 'WEB',
      status: 'ACTIVE',
      context: data.context || null,
    },
  });

  return conversation;
}

/**
 * ارسال پیام و دریافت پاسخ AI
 */
export async function sendMessage(
  conversationId: string,
  userMessage: string
): Promise<SendMessageResult> {
  const conversation = await db.aIAgentConversation.findUnique({
    where: { id: conversationId },
    include: {
      agent: true,
      messages: {
        orderBy: { createdAt: 'asc' },
        take: 20, // آخرین ۲۰ پیام برای زمینه
      },
    },
  });

  if (!conversation) {
    throw new Error('مکالمه یافت نشد');
  }

  if (conversation.status !== 'ACTIVE') {
    throw new Error('مکالمه فعال نیست');
  }

  // ذخیره پیام کاربر
  await db.aIAgentMessage.create({
    data: {
      conversationId,
      role: 'USER',
      content: userMessage,
      metadata: {
        sentiment: analyzeSentiment(userMessage),
        intent: detectIntent(userMessage),
      },
    },
  });

  // تحلیل احساسات و نیت
  const sentiment = analyzeSentiment(userMessage);
  const intent = detectIntent(userMessage);

  // به‌روزرسانی احساسات مکالمه
  await db.aIAgentConversation.update({
    where: { id: conversationId },
    data: { sentiment },
  });

  // ساخت تاریخچه مکالمه برای AI
  const history = conversation.messages.map(m => ({
    role: m.role === 'USER' ? 'user' : 'assistant',
    content: m.content,
  }));

  // اضافه کردن پیام فعلی
  history.push({ role: 'user', content: userMessage });

  // ساخت system prompt با پایگاه دانش
  const knowledgeBasePrompt = buildComprehensiveSystemPrompt({
    cluster: (conversation.context as Record<string, string>)?.cluster as string | undefined,
    courseSlug: (conversation.context as Record<string, string>)?.courseSlug as string | undefined,
  });

  const fullSystemPrompt = `${conversation.agent.systemPrompt}\n\n# ─── پایگاه دانش آموزشگاه ───\n${knowledgeBasePrompt}\n\n# ─── اطلاعات مکالمه فعلی ───\nاحساس کاربر: ${sentiment}\nنیت کاربر: ${intent}\n${conversation.context ? `زمینه: ${JSON.stringify(conversation.context)}` : ''}`;

  // دریافت پاسخ AI
  let reply: string | null = null;

  try {
    reply = await chatCompletion(fullSystemPrompt, history, {
      temperature: 0.6,
      maxTokens: 800,
    });
  } catch {
    // خطا در AI — استفاده از پاسخ جایگزین
  }

  if (!reply) {
    reply = getFallbackResponse(conversation.agent.type as AgentType);
  }

  // تأخیر طبیعی (حس پاسخ واقعی)
  const delay = Math.min(conversation.agent.responseDelayMs || 1000, 3000);
  await new Promise(resolve => setTimeout(resolve, delay));

  // ذخیره پاسخ AI
  await db.aIAgentMessage.create({
    data: {
      conversationId,
      role: 'ASSISTANT',
      content: reply,
      metadata: { sentiment, intent },
    },
  });

  // بررسی نیاز به ارجاع به انسان
  const suggestedActions = generateSuggestedActions(
    conversation.agent.type as AgentType,
    sentiment,
    intent,
    conversation.agent.handoffToHuman,
    conversation.agent.handoffCondition
  );

  // اگر احساسات منفی و ارجاع فعال است، خودکار ارجاع بده
  if (sentiment === 'NEGATIVE' && conversation.agent.handoffToHuman) {
    const shouldHandoff = !conversation.agent.handoffCondition ||
      conversation.agent.handoffCondition.includes('sentiment=negative');

    if (shouldHandoff) {
      suggestedActions.push('HANDOFF_TO_HUMAN');
    }
  }

  return {
    conversationId,
    reply,
    suggestedActions,
    sentiment,
    intent,
  };
}

/**
 * تولید اقدامات پیشنهادی بر اساس وضعیت مکالمه
 */
function generateSuggestedActions(
  agentType: AgentType,
  sentiment: Sentiment,
  intent: Intent,
  handoffEnabled: boolean,
  _handoffCondition?: string | null
): string[] {
  const actions: string[] = [];

  // اقدامات بر اساس نیت
  switch (intent) {
    case 'COURSE_INQUIRY':
      actions.push('SHOW_COURSES');
      break;
    case 'PRICING':
      actions.push('SHOW_PRICING');
      actions.push('OFFER_INSTALLMENT');
      break;
    case 'REGISTRATION':
      actions.push('START_REGISTRATION');
      break;
    case 'COMPLAINT':
      if (handoffEnabled) actions.push('HANDOFF_TO_HUMAN');
      actions.push('CREATE_TICKET');
      break;
  }

  // اقدامات بر اساس احساسات
  if (sentiment === 'NEGATIVE') {
    actions.push('OFFER_DISCOUNT');
  } else if (sentiment === 'POSITIVE') {
    if (agentType === 'SALES') actions.push('PROMOTE_REGISTRATION');
  }

  // اقدامات بر اساس نوع عامل
  switch (agentType) {
    case 'SALES':
      actions.push('SUGGEST_RELATED_COURSES');
      break;
    case 'CONSULTANT':
      actions.push('SUGGEST_CAREER_PATH');
      break;
    case 'RETENTION':
      actions.push('OFFER_RETENTION_DISCOUNT');
      break;
    case 'FOLLOW_UP':
      actions.push('SEND_REMINDER');
      break;
  }

  return [...new Set(actions)]; // حذف تکراری‌ها
}

/**
 * پایان مکالمه
 */
export async function endConversation(
  conversationId: string,
  outcome: ConversationOutcome = 'INFORMED'
) {
  const conversation = await db.aIAgentConversation.update({
    where: { id: conversationId },
    data: {
      status: 'COMPLETED',
      outcome,
      endedAt: new Date(),
    },
  });

  return conversation;
}

/**
 * ارجاع مکالمه به انسان
 */
export async function handoffToHuman(
  conversationId: string,
  reason: string
) {
  const conversation = await db.aIAgentConversation.update({
    where: { id: conversationId },
    data: {
      status: 'HANDED_OFF',
      outcome: 'HANDED_OFF',
      outcomeData: { handoffReason: reason, handoffAt: new Date().toISOString() },
      endedAt: new Date(),
    },
  });

  // افزودن پیام سیستمی
  await db.aIAgentMessage.create({
    data: {
      conversationId,
      role: 'SYSTEM',
      content: `مکالمه به کارشناس انسانی ارجاع شد. دلیل: ${reason}`,
      metadata: { type: 'HANDOFF', reason },
    },
  });

  return conversation;
}

/**
 * ایجاد عامل‌های پیش‌فرض
 */
export async function seedDefaultAgents() {
  const existingCount = await db.aIAgent.count();

  if (existingCount > 0) {
    return { created: 0, message: 'عامل‌ها از قبل وجود دارند' };
  }

  const defaultAgents: CreateAgentData[] = [
    {
      name: 'عامل فروش',
      type: 'SALES',
      description: 'عامل هوشمند فروش — تبدیل لید به مشتری با پیشنهاد دوره‌های مناسب و تخفیف‌ها',
      isActive: true,
      maxConversations: 100,
      responseDelayMs: 1200,
      handoffToHuman: true,
      handoffCondition: 'sentiment=negative,intent=complaint',
    },
    {
      name: 'عامل پشتیبانی',
      type: 'SUPPORT',
      description: 'عامل هوشمند پشتیبانی — پاسخ به سؤالات متداول و حل مشکلات ساده',
      isActive: true,
      maxConversations: 150,
      responseDelayMs: 800,
      handoffToHuman: true,
      handoffCondition: 'sentiment=negative',
    },
    {
      name: 'عامل مشاور',
      type: 'CONSULTANT',
      description: 'عامل هوشمند مشاوره شغلی — راهنمایی برای انتخاب مسیر شغلی و آموزشی',
      isActive: true,
      maxConversations: 80,
      responseDelayMs: 1500,
      handoffToHuman: true,
      handoffCondition: 'sentiment=negative',
    },
    {
      name: 'عامل پیگیری',
      type: 'FOLLOW_UP',
      description: 'عامل هوشمند پیگیری — بازگرداندن لیدهای سرد و ارسال یادآوری',
      isActive: true,
      maxConversations: 200,
      responseDelayMs: 1000,
      handoffToHuman: false,
    },
    {
      name: 'عامل حفظ مشتری',
      type: 'RETENTION',
      description: 'عامل هوشمند حفظ مشتری — جلوگیری از ریزش و ارائه تخفیف‌های ویژه',
      isActive: true,
      maxConversations: 100,
      responseDelayMs: 1200,
      handoffToHuman: true,
      handoffCondition: 'sentiment=negative',
    },
  ];

  const created = [];
  for (const agentData of defaultAgents) {
    const agent = await createAgent(agentData);
    created.push(agent);
  }

  return { created: created.length, message: `${created.length} عامل پیش‌فرض ایجاد شد` };
}

/**
 * دریافت آمار عامل
 */
export async function getAgentStats(agentId: string) {
  const agent = await db.aIAgent.findUnique({
    where: { id: agentId },
    include: {
      _count: {
        select: { conversations: true },
      },
    },
  });

  if (!agent) return null;

  const totalConversations = await db.aIAgentConversation.count({
    where: { agentId },
  });

  const activeConversations = await db.aIAgentConversation.count({
    where: { agentId, status: 'ACTIVE' },
  });

  const completedConversations = await db.aIAgentConversation.count({
    where: { agentId, status: 'COMPLETED' },
  });

  const enrolledConversations = await db.aIAgentConversation.count({
    where: { agentId, outcome: 'ENROLLED' },
  });

  const handedOffConversations = await db.aIAgentConversation.count({
    where: { agentId, status: 'HANDED_OFF' },
  });

  const totalMessages = await db.aIAgentMessage.count({
    where: { conversation: { agentId } },
  });

  const conversionRate = totalConversations > 0
    ? (enrolledConversations / totalConversations) * 100
    : 0;

  return {
    agent,
    totalConversations,
    activeConversations,
    completedConversations,
    enrolledConversations,
    handedOffConversations,
    totalMessages,
    conversionRate: Math.round(conversionRate * 10) / 10,
  };
}
