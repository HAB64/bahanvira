/**
 * ─── پایگاه دانش جامع مشاور هوشمند بهان رایانه ───
 * 
 * این فایل شامل تمام اطلاعات سایت است که مشاور هوشمند
 * برای پاسخگویی به سؤالات کاربران نیاز دارد.
 * هر تغییر در اطلاعات آموزشگاه باید در این فایل هم به‌روز شود.
 * 
 * ساختار:
 * 1. اطلاعات مؤسسه
 * 2. اطلاعات کامل دوره‌ها (شامل سرفصل‌ها، نتایج، نظرات)
 * 3. خوشه‌های شایستگی
 * 4. مسیرهای شغلی جامع با زمان‌بندی
 * 5. توصیه‌های سنی
 * 6. فارغ‌التحصیلان موفق
 * 7. مقالات وبلاگ (خلاصه)
 * 8. سؤالات متداول
 * 9. اعتبار و صلاحیت
 * 10. تولید System Prompt جامع
 */

import { siteConfig } from '@/config/site'
import { courses, competencyClusters } from '@/data/courses'
import { alumni } from '@/data/alumni'
import { blogPosts } from '@/data/blog'
import { GROUPS, OCCUPATIONS } from '@/lib/skill-graph'

// ─── ۱. اطلاعات مؤسسه ──────────────────────────────────────────────────────

export const INSTITUTE_INFO = {
  name: siteConfig.name.fa,
  fullName: siteConfig.name.fullName,
  nameEn: siteConfig.name.en,
  founder: siteConfig.founder.name,
  founderTitle: siteConfig.founder.title,
  founderCredentials: siteConfig.founder.credentials,
  yearsExperience: siteConfig.experience.yearsFa,
  type: siteConfig.institute.typeFa,
  city: siteConfig.location.city,
  province: siteConfig.location.province,
  fullAddress: siteConfig.location.fullAddress,
  phone: siteConfig.contact.phone,
  phoneRaw: siteConfig.contact.phoneRaw,
  mobiles: siteConfig.contact.mobiles.map(m => ({
    display: m.display,
    dialable: m.dialable,
    platforms: 'platforms' in m ? m.platforms : [],
  })),
  email: siteConfig.contact.email,
  whatsapp: siteConfig.contact.whatsappDisplay,
  whatsappUrl: siteConfig.contact.whatsappUrl,
  instagram: siteConfig.social.instagram,
  instagramHandle: siteConfig.social.instagramHandle,
  telegram: siteConfig.social.telegram,
  workHours: siteConfig.workHours,
  website: siteConfig.url.base,
  licenses: [
    'مجوز رسمی سازمان آموزش فنی و حرفه‌ای ایران',
    'عضو نظام صنفی رایانه‌ای استان مازندران',
    'مرکز آزمون بین‌المللی ICDL',
  ],
  paymentOptions: [
    'قسط‌بندی ۲ تا ۳ ماهه بدون چک و بدون بهره',
    'پرداخت نقدی با تخفیف ویژه',
  ],
  teachingMethod: 'آموزش مبتنی بر شایستگی (CBT - Competency-Based Training)',
  registrationSteps: [
    'مشاوره رایگان اولیه (حضوری یا تلفنی)',
    'انتخاب دوره مناسب بر اساس علاقه و سطح',
    'تکمیل مدارک (کارت شناسایی و عکس)',
    'پرداخت شهریه (نقد یا اقساط بدون چک)',
    'شروع کلاس‌ها بر اساس شیفت انتخابی',
  ],
  documentsNeeded: 'کپی کارت شناسایی ملی (کدملی)، ۲ قطعه عکس پرسنلی (۳ در ۴)',
} as const

// ─── ۲. اطلاعات کامل دوره‌ها ────────────────────────────────────────────────

export const COURSES_KNOWLEDGE = courses.map(c => ({
  slug: c.slug,
  title: c.title,
  subtitle: c.subtitle,
  cluster: c.cluster,
  clusterLabel: c.clusterLabel,
  level: c.level,
  duration: c.duration,
  sessions: c.sessions,
  price: c.price || 'تماس بگیرید',
  priceNote: c.priceNote || '',
  description: c.description,
  highlights: c.highlights,
  prerequisites: c.prerequisites || ['بدون پیش‌نیاز'],
  certificate: c.certificate,
  targetAudience: c.targetAudience,
  learningOutcomes: c.learningOutcomes,
  modules: c.modules.map(m => ({
    title: m.title,
    lessons: m.lessons,
    duration: m.duration,
    type: m.type,
  })),
  reviews: c.reviews.map(r => ({
    name: r.name,
    role: r.role,
    rating: r.rating,
    text: r.text,
  })),
  isFeatured: c.isFeatured || false,
  bloomLevel: c.bloomLevel,
  url: `https://bahanrayaneh.ir/courses/${c.slug}`,
}))

// ─── ۳. اطلاعات خوشه‌های شایستگی ────────────────────────────────────────────

export const CLUSTERS_KNOWLEDGE = competencyClusters.map(c => ({
  id: c.id,
  title: c.title,
  shortTitle: c.shortTitle,
  description: c.description,
  coursesCount: c.stats.courses,
  students: c.stats.students,
  hours: c.stats.hours,
}))

// ─── ۴. مسیرهای شغلی جامع با زمان‌بندی ────────────────────────────────────

export const CAREER_PATHS = {
  'tech-ai-path': {
    title: 'مسیر فناوری اطلاعات و هوش مصنوعی',
    steps: [
      { level: 'پایه', course: 'ICDL — سواد دیجیتال بین‌المللی', duration: '۳ ماه', slug: 'icdl', description: 'ابتدا سواد دیجیتال پایه را کسب کنید. بدون ICDL ورود به هر حوزه فناوری عملاً غیرممکن است.' },
      { level: 'پایه (کودکان)', course: 'Scratch — بازی‌سازی و تفکر الگوریتمی', duration: '۲ ماه', slug: 'scratch', description: 'برای کودکان ۸-۱۵ سال، Scratch بهترین شروع است. مفاهیم برنامه‌نویسی را از طریق بازی‌سازی یاد بگیرید.' },
      { level: 'متوسط', course: 'پایتون — برنامه‌نویسی حرفه‌ای و تحلیل داده', duration: '۴ ماه', slug: 'python', description: 'پس از سواد دیجیتال، پایتون بهترین زبان برای شروع برنامه‌نویسی حرفه‌ای است.' },
      { level: 'پیشرفته', course: 'هوش مصنوعی محلی — Ollama و LLMها', duration: '۳ ماه', slug: 'local-ai', description: 'تخصص اجرای مدل‌های AI بدون وابستگی به اینترنت. آینده فناوری!' },
    ],
    totalDuration: '۱۲ تا ۱۸ ماه (از صفر تا تخصص AI)',
  },
  'finance-trading-path': {
    title: 'مسیر امور مالی و معامله‌گری',
    steps: [
      { level: 'پایه', course: 'حسابداری عملی و نرم‌افزار هلو', duration: '۲ ماه', slug: 'accounting', description: 'ابتدا اصول حسابداری و کار با نرم‌افزار هلو را یاد بگیرید. پایه ورود به بازار کار مالی.' },
      { level: 'پایه', course: 'فارکس — مبانی معامله‌گری', duration: '۲ ماه', slug: 'forex-fundamentals', description: 'ورود ایمن به بازارهای مالی جهانی با تمرکز بر مدیریت ریسک.' },
      { level: 'پیشرفته', course: 'MQL5 — معامله‌گری الگوریتمی', duration: '۳ ماه', slug: 'mql5-algorithmic', description: 'تبدیل استراتژی‌های معاملاتی به سیستم خودکار. ترید بدون حضور فیزیکی!' },
    ],
    totalDuration: '۷ تا ۱۰ ماه',
  },
  'entrepreneurship-path': {
    title: 'مسیر کارآفرینی و کسب‌وکار',
    steps: [
      { level: 'متوسط', course: 'کارآفرینی دیجیتال — از ایده تا درآمد', duration: '۲ ماه', slug: 'entrepreneurship', description: 'مسیر تبدیل ایده به کسب‌وکار فعال با اعتبارسنجی بازار و ساخت MVP.' },
      { level: 'پیشرفته', course: 'مشاوره کسب‌وکار و سیستم‌سازی', duration: 'مطابق نیاز', slug: 'business-consulting', description: 'عارضه‌یابی سازمانی و سیستم‌سازی زیر نظر دکتر بهان.' },
    ],
    totalDuration: '۴ تا ۶ ماه + مشاوره مستمر',
  },
  'creative-design-path': {
    title: 'مسیر گرافیک و طراحی دیجیتال',
    steps: [
      { level: 'پایه', course: 'فتوشاپ — طراحی گرافیک', duration: '۲ ماه', slug: 'photoshop', description: 'قدرتمندترین نرم‌افزار ویرایش تصویر و طراحی. از روتوش تا برندینگ.' },
      { level: 'پیشرفته', course: '3D Max — مدل‌سازی سه‌بعدی و رندرینگ', duration: '۳ ماه', slug: '3dmax', description: 'مدل‌سازی سه‌بعدی فوتورئالیستیک با V-Ray برای معماران و طراحان.' },
    ],
    totalDuration: '۵ تا ۷ ماه',
  },
  'architecture-path': {
    title: 'مسیر معماری و نقشه‌کشی',
    steps: [
      { level: 'پایه', course: 'AutoCAD — نقشه‌کشی صنعتی', duration: '۲ ماه', slug: 'autocad', description: 'نقشه‌کشی حرفه‌ای ساختمانی و صنعتی با استانداردهای ملی.' },
      { level: 'پیشرفته', course: '3D Max — مدل‌سازی سه‌بعدی', duration: '۳ ماه', slug: '3dmax', description: 'تبدیل نقشه‌های دو بعدی به مدل‌های سه‌بعدی واقع‌گرایانه.' },
    ],
    totalDuration: '۵ ماه',
  },
  'kids-path': {
    title: 'مسیر کودکان و نوجوانان',
    steps: [
      { level: 'پایه', course: 'Scratch — بازی‌سازی (۸-۱۵ سال)', duration: '۲ ماه', slug: 'scratch', description: 'یادگیری برنامه‌نویسی از طریق بازی‌سازی. تفکر منطقی و خلاقیت.' },
      { level: 'متوسط', course: 'پایتون — برنامه‌نویسی (۱۲+ سال)', duration: '۴ ماه', slug: 'python', description: 'قدم بعدی: برنامه‌نویسی واقعی با پایتون. مسیر حرفه‌ای شروع می‌شود.' },
    ],
    totalDuration: '۶ ماه',
  },
  'sewing-fashion-path': {
    title: 'مسیر صنعت پوشاک',
    steps: [
      { level: 'متوسط', course: 'طراحی دوخت حرفه‌ای — نازک‌دوزی و مانتودوزی', duration: '۳ ماه', slug: 'sewing', description: 'از الگوسازی صنعتی تا تولید خط کامل پوشاک. راه‌اندازی کارگاه مستقل.' },
    ],
    totalDuration: '۳ ماه',
  },
  'education-path': {
    title: 'مسیر خدمات آموزشی و مربیگری',
    steps: [
      { level: 'پایه', course: 'خدمات آموزشی — مدیریت و مربیگری مهدکودک', duration: '۲ ماه', slug: 'preschool-education', description: 'از روانشناسی کودک تا مدیریت مهدکودک. شغل پرتقاضا.' },
      { level: 'پایه', course: 'هنرهای تجسمی — نقاشی گواش و مربیگری کودک', duration: '۲ ماه', slug: 'visual-arts', description: 'ترکیب هنر و آموزش. مربیگری نقاشی کودکان.' },
    ],
    totalDuration: '۴ ماه',
  },
  'web-design-path': {
    title: 'مسیر طراحی وب و فریلنسری',
    steps: [
      { level: 'پایه', course: 'ICDL — سواد دیجیتال بین‌المللی', duration: '۳ ماه', slug: 'icdl', description: 'سواد دیجیتال پایه. آشنایی با اینترنت و ابزارهای دیجیتال.' },
      { level: 'متوسط', course: 'فتوشاپ — طراحی گرافیک', duration: '۲ ماه', slug: 'photoshop', description: 'طراحی UI و گرافیک وب. تولید محتوای بصری حرفه‌ای.' },
      { level: 'متوسط', course: 'پایتون — برنامه‌نویسی حرفه‌ای', duration: '۴ ماه', slug: 'python', description: 'برنامه‌نویسی وب با پایتون. ساخت سایت و اتوماسیون.' },
    ],
    totalDuration: '۹ تا ۱۲ ماه',
  },
  'office-admin-path': {
    title: 'مسیر امور اداری و دبیری',
    steps: [
      { level: 'پایه', course: 'ICDL — سواد دیجیتال بین‌المللی', duration: '۳ ماه', slug: 'icdl', description: 'مدرک ICDL شرط استخدام در اکثر سازمان‌هاست. Word، Excel، PowerPoint و...' },
      { level: 'متوسط', course: 'حسابداری عملی و نرم‌افزار هلو', duration: '۲ ماه', slug: 'accounting', description: 'کار با سیستم حسابداری هلو. مهارت ضروری دفاتر اداری.' },
    ],
    totalDuration: '۵ ماه',
  },
  'interior-design-path': {
    title: 'مسیر طراحی داخلی',
    steps: [
      { level: 'پایه', course: 'AutoCAD — نقشه‌کشی صنعتی', duration: '۲ ماه', slug: 'autocad', description: 'نقشه‌کشی پلان‌های داخلی با استانداردهای حرفه‌ای.' },
      { level: 'پیشرفته', course: '3D Max — مدل‌سازی سه‌بعدی و رندرینگ', duration: '۳ ماه', slug: '3dmax', description: 'رندرینگ واقع‌گرایانه فضاهای داخلی با V-Ray. ارائه حرفه‌ای به کارفرما.' },
    ],
    totalDuration: '۵ ماه',
  },
  'legal-services-path': {
    title: 'مسیر خدمات حقوقی',
    steps: [
      { level: 'پایه', course: 'حقوقی — اصول حقوق تجاری و قراردادها', duration: '۲ ماه', slug: 'legal-commercial', description: 'آشنایی با حقوق تجاری، انواع قراردادها و الزامات قانونی کسب‌وکار.' },
      { level: 'متوسط', course: 'حقوقی — مالکیت فکری و ثبت برند', duration: '۲ ماه', slug: 'legal-ip', description: 'ثبت برند، حق مؤلف و حفاظت از دارایی‌های فکری کسب‌وکار.' },
    ],
    totalDuration: '۴ ماه',
  },
  'sewing-entrepreneurship-path': {
    title: 'مسیر صنعت پوشاک و کارآفرینی',
    steps: [
      { level: 'متوسط', course: 'طراحی دوخت حرفه‌ای — نازک‌دوزی و مانتودوزی', duration: '۳ ماه', slug: 'sewing', description: 'از الگوسازی صنعتی تا تولید خط کامل پوشاک.' },
      { level: 'پیشرفته', course: 'کارآفرینی دیجیتال — از ایده تا درآمد', duration: '۲ ماه', slug: 'entrepreneurship', description: 'راه‌اندازی برند پوشاک آنلاین و فروش دیجیتال.' },
    ],
    totalDuration: '۵ ماه',
  },
} as const

// ─── ۵. توصیه‌های سنی ──────────────────────────────────────────────────────

export const AGE_RECOMMENDATIONS = {
  '8-10': {
    label: 'کودکان ۸ تا ۱۰ سال',
    courses: ['scratch'],
    message: 'برای کودکان ۸ تا ۱۰ سال، دوره Scratch بهترین شروع است. بازی‌سازی و تفکر الگوریتمی به صورت کاملاً بصری و بدون نیاز به تایپ کد. تخفیف ویژه خردسالان!',
  },
  '11-15': {
    label: 'نوجوانان ۱۱ تا ۱۵ سال',
    courses: ['scratch', 'python', 'icdl'],
    message: 'برای نوجوانان پیشنهاد می‌کنم ابتدا Scratch (اگر تجربه قبلی ندارید) و سپس پایتون را شروع کنید. اگر به کارهای اداری علاقه دارید، ICDL هم گزینه خوبی است.',
  },
  '16-18': {
    label: 'دانش‌آموزان ۱۶ تا ۱۸ سال',
    courses: ['icdl', 'python', 'forex-fundamentals', 'photoshop'],
    message: 'در این سن، ورود به بازار کار مهم است. ICDL شرط استخدام، پایتون آینده شغلی روشن، و فتوشاپ برای فریلنسری عالی است.',
  },
  '18-25': {
    label: 'جوانان ۱۸ تا ۲۵ سال',
    courses: ['icdl', 'python', 'local-ai', 'forex-fundamentals', 'mql5-algorithmic', 'accounting', 'entrepreneurship'],
    message: 'بهترین سن برای تخصص! مسیرهای پیشنهادی: فناوری (ICDL → پایتون → AI)، مالی (حسابداری → فارکس → MQL5)، یا کارآفرینی. مشاوره رایگان داریم.',
  },
  '25-40': {
    label: 'بزرگسالان ۲۵ تا ۴۰ سال',
    courses: ['icdl', 'accounting', 'business-consulting', 'forex-fundamentals', 'python', 'photoshop'],
    message: 'ارتقای مهارت یا تغییر مسیر شغلی. ICDL برای ارتقای شغلی، حسابداری برای ورود به بازار کار مالی، و مشاوره کسب‌وکار برای رشد سازمان شما.',
  },
  '40+': {
    label: 'بزرگسالان ۴۰ سال به بالا',
    courses: ['icdl', 'accounting', 'business-consulting'],
    message: 'هرگز دیر نیست! ICDL برای سواد دیجیتال ضروری، حسابداری برای ثبات شغلی، و مشاوره کسب‌وکار برای بهینه‌سازی کسب‌وکار فعلی‌تان.',
  },
} as const

// ─── ۶. فارغ‌التحصیلان موفق ─────────────────────────────────────────────────

export const ALUMNI_STORIES = alumni.map(a => ({
  name: a.name,
  course: a.course,
  year: a.year,
  role: a.role,
  company: a.company || '',
  quote: a.quote,
  achievement: a.achievement,
}))

// ─── ۷. مقالات وبلاگ (خلاصه) ──────────────────────────────────────────────

export const BLOG_KNOWLEDGE = blogPosts.map(b => ({
  slug: b.slug,
  title: b.title,
  excerpt: b.excerpt,
  category: b.category,
  keywords: b.keywords,
  url: `https://bahanrayaneh.ir/blog/${b.slug}`,
}))

// ─── ۸. سؤالات متداول ──────────────────────────────────────────────────────

export const FAQ_KNOWLEDGE = [
  ...siteConfig.faq.map(f => ({
    question: f.question,
    answer: f.answer,
  })),
  // ─── سؤالات متداول اضافی (چت‌بات) ────────────────────────────────────
  {
    question: 'تفاوت آموزشگاه بهان رایانه با سایر آموزشگاه‌ها چیست؟',
    answer: 'آموزشگاه بهان رایانه با ۲۷ سال سابقه، تنها آموزشگاه دارای مجوز رسمی فنی و حرفه‌ای و مرکز آزمون بین‌المللی ICDL در محمودآباد است. روش آموزش ما مبتنی بر شایستگی (CBT) است — یعنی ارزیابی بر اساس مهارت عملی، نه حضور در کلاس. همچنین امکان قسط‌بندی بدون چک و بدون بهره، پشتیبانی پس از دوره، و مخزن کد اختصاصی (برای دوره‌های فناوری) از مزایای ماست.',
  },
  {
    question: 'آیا امکان رزرو کلاس آزمایشی رایگان وجود دارد؟',
    answer: 'بله! شما می‌توانید یک جلسه آزمایشی رایگان در هر دوره‌ای که بخواهید شرکت کنید. کافیست با شماره ۰۱۱-۴۴۷۴۶۶۶۵ تماس بگیرید یا حضوری به آموزشگاه مراجعه کنید. جلسه آزمایشی به شما کمک می‌کند تا با مدرس و محیط کلاس آشنا شوید.',
  },
  {
    question: 'مدرسین آموزشگاه چه سطحی از تخصص دارند؟',
    answer: 'مدرسین آموزشگاه بهان رایانه همگی دارای مدارک تخصصی و تجربه عملی در حوزه تدریس خود هستند. بنیان‌گذار آموزشگاه، دکتر بهان، دارای دکتری کارآفرینی و ۲۷+ سال تجربه آموزشی و مدیریتی است. مدرسین فناوری اطلاعات دارای مدارک بین‌المللی و سابقه کاری در شرکت‌های فناوری هستند.',
  },
  {
    question: 'آیا برای دوره‌های فناوری لپ‌تاپ شخصی لازم است؟',
    answer: 'آموزشگاه کامپیوتر و اینترنت مناسب در اختیار کارآموزان قرار می‌دهد. اما برای تمرین در منزل و تسلط بیشتر، داشتن لپ‌تاپ شخصی توصیه می‌شود. برای دوره‌های برنامه‌نویسی (پایتون، MQL5) و هوش مصنوعی محلی، لپ‌تاپ با حداقل ۸ گیگابایت رم پیشنهاد می‌شود.',
  },
  {
    question: 'آیا بعد از پایان دوره مدرک فوری صادر می‌شود؟',
    answer: 'پس از پایان دوره و قبولی در آزمون نهایی، مدرک شما ثبت و صادر می‌شود. مدرک ICDL بین‌المللی معمولاً ظرف ۲ هفته صادر می‌شود. مدارک فنی و حرفه‌ای نیز پس از ثبت در سامانه و تأیید سازمان مربوطه صادر می‌شوند. آموزشگاه در تمام مراحل همراه شماست.',
  },
  {
    question: 'آیا دوره‌ها ضبط می‌شوند؟ آیا ویدیو آموزشی دریافت می‌کنیم؟',
    answer: 'برخی دوره‌های فناوری اطلاعات (مانند پایتون، MQL5 و هوش مصنوعی) جلسات ضبط‌شده در اختیار کارآموزان قرار می‌گیرد. این امکان برای مرور مطالب و جبران غیبت مفید است. اما تمرکز اصلی ما بر آموزش حضوری و تعامل مستقیم با مدرس است.',
  },
  {
    question: 'چگونه می‌توانم درخواست مشاوره شغلی تخصصی داشته باشم؟',
    answer: 'برای مشاوره شغلی تخصصی سه راه دارید: ۱) از چت‌بات همین سایت استفاده کنید و سؤالات خود را بپرسید، ۲) با شماره ۰۱۱-۴۴۷۴۶۶۶۵ تماس بگیرید، ۳) حضوری به آموزشگاه مراجعه کنید. مشاوره اولیه رایگان است و مشاوران ما بر اساس سن، علاقه و سطح شما بهترین مسیر شغلی را پیشنهاد می‌دهند.',
  },
  {
    question: 'آیا برای ثبت‌نام گروهی تخفیف دارید؟',
    answer: 'بله! برای ثبت‌نام ۳ نفر به بالا تخفیف گروهی ویژه‌ای در نظر گرفته شده است. همچنین کارآموزان دوره‌های قبلی آموزشگاه از تخفیف ویژه برخوردار می‌شوند. برای اطلاع از تخفیف‌های جاری با کارشناسان ما تماس بگیرید.',
  },
  {
    question: 'آیا مدرک ICDL برای مهاجرت به کانادا و اروپا معتبر است؟',
    answer: 'بله. مدرک ICDL (International Computer Driving Licence) یک مدرک بین‌المللی است که در بیش از ۱۴۰ کشور جهان به رسمیت شناخته می‌شود. این مدرک برای مهاجرت تحصیلی و کاری به کانادا، اروپا، استرالیا و سایر کشورها قابل ارائه است و نمره مثبت در ارزیابی صلاحیت‌ها دریافت می‌کند.',
  },
  {
    question: 'دوره هوش مصنوعی محلی چیست و چه کاربردی دارد؟',
    answer: 'دوره هوش مصنوعی محلی (Ollama و LLMها) به شما آموزش می‌دهد چگونه مدل‌های هوش مصنوعی مانند ChatGPT را بدون نیاز به اینترنت و روی کامپیوتر شخصی خود اجرا کنید. کاربردها: اجرای AI بدون وابستگی به اینترنت، حفظ حریم خصوصی داده‌ها، کاهش هزینه‌ها، و ساخت دستیارهای هوشمند سفارشی. این دوره پیش‌نیاز تسلط بر پایتون دارد.',
  },
]

// ─── ۹. اعتبار و صلاحیت ────────────────────────────────────────────────────

export const TRUST_KNOWLEDGE = siteConfig.trust.map(t => ({
  title: t.title,
  description: t.description,
}))

// ─── ۹.۵. اطلاعات تماس جامع ──────────────────────────────────────────────────

export const CONTACT_KNOWLEDGE = {
  /** تلفن ثابت */
  phone: {
    display: siteConfig.contact.phone,
    raw: siteConfig.contact.phoneRaw,
    href: siteConfig.contact.phoneHref,
  },
  /** شماره‌های موبایل و پلتفرم‌های پیام‌رسان */
  mobiles: siteConfig.contact.mobiles.map(m => ({
    display: m.display,
    dialable: m.dialable,
    platforms: 'platforms' in m ? (m.platforms as Array<{ key: string; labelFa: string; url: string; color: string }>).map(p => ({
      name: p.labelFa,
      url: p.url,
    })) : [],
  })),
  /** واتساپ */
  whatsapp: {
    display: siteConfig.contact.whatsappDisplay,
    url: siteConfig.contact.whatsappUrl,
  },
  /** ایمیل */
  email: siteConfig.contact.email,
  /** شبکه‌های اجتماعی */
  social: {
    instagram: {
      handle: siteConfig.social.instagramHandle,
      url: siteConfig.social.instagram,
    },
    telegram: {
      url: siteConfig.social.telegram,
    },
  },
  /** آدرس */
  address: {
    full: siteConfig.location.fullAddress,
    city: siteConfig.location.city,
    province: siteConfig.location.province,
    coordinates: {
      lat: siteConfig.location.latitude,
      lng: siteConfig.location.longitude,
    },
    googleMapsUrl: `https://maps.google.com/?q=${siteConfig.location.latitude},${siteConfig.location.longitude}`,
  },
  /** ساعات کاری */
  workHours: siteConfig.workHours,
  /** وبسایت */
  website: siteConfig.url.base,
  /** راه‌های ارتباطی خلاصه (برای پاسخ سریع چت‌بات) */
  quickContactSummary: `تلفن ثابت: ${siteConfig.contact.phone} | موبایل: ${siteConfig.contact.mobiles[0].display} | واتساپ: ${siteConfig.contact.whatsappUrl} | اینستاگرام: ${siteConfig.social.instagramHandle} | تلگرام: ${siteConfig.social.telegram} | ایمیل: ${siteConfig.contact.email} | آدرس: ${siteConfig.location.fullAddress} | ساعات کاری: ${siteConfig.workHours}`,
} as const

// ─── ۱۰. مقایسه دوره‌ها ──────────────────────────────────────────────────────

export const COURSE_COMPARISONS = {
  'icdl-vs-python': {
    question: 'ICDL یا پایتون؟',
    answer: 'بستگی به هدفتان دارد: ICDL سواد دیجیتال عمومی و شرط استخدام است — برای همه لازم. پایتون مهارت برنامه‌نویسی تخصصی است. پیشنهاد: ابتدا ICDL (سواد پایه) و سپس پایتون (تخصص). ICDL پیش‌نیاز رسمی پایتون نیست اما کمک می‌کند.',
  },
  'forex-vs-mql5': {
    question: 'فارکس یا MQL5؟',
    answer: 'فارکس مبانی معامله‌گری دستی است — ابتدا این را یاد بگیرید. MQL5 معامله‌گری الگوریتمی (رباتیک) است و پیش‌نیاز آن تسلط بر فارکس است. مسیر: فارکس → MQL5. بدون فارکس، MQL5 بی‌فایده است.',
  },
  'scratch-vs-python': {
    question: 'Scratch یا پایتون برای کودکان؟',
    answer: 'برای کودکان زیر ۱۲ سال حتماً Scratch. بصری و بدون نیاز به تایپ. برای ۱۲ سال به بالا، اگر علاقه دارند، می‌توانند مستقیم پایتون شروع کنند. اما Scratch بهتر پایه‌ریزی می‌کند. مسیر ایده‌آل: Scratch → پایتون.',
  },
  'autocad-vs-3dmax': {
    question: 'AutoCAD یا 3D Max؟',
    answer: 'AutoCAD نقشه‌کشی دو بعدی صنعتی است (پایه). 3D Max مدل‌سازی سه‌بعدی و رندر است (پیشرفته). پیشنهاد: ابتدا AutoCAD و سپس 3D Max. با AutoCAD نقشه بکشید و با 3D Max آن را سه‌بعدی کنید.',
  },
  'accounting-vs-forex': {
    question: 'حسابداری یا فارکس؟',
    answer: 'حسابداری شغل پایدار با درآمد مشخص است. فارکس درآمد دلاری اما با ریسک. حسابداری نیازمند دقت و نظم، فارکس نیازمند تحلیل و مدیریت ریسک. پیشنهاد: حسابداری برای شغل پایدار، فارکس برای درآمد مکمل. هر دو را می‌توانید یاد بگیرید.',
  },
  'photoshop-vs-3dmax': {
    question: 'فتوشاپ یا 3D Max؟',
    answer: 'فتوشاپ ویرایش تصویر و طراحی گرافیک دو بعدی (پایه). 3D Max مدل‌سازی سه‌بعدی (پیشرفته). دو حوزه متفاوت! فتوشاپ برای فریلنسری سریع، 3D Max برای معماران و طراحان داخلی.',
  },
  'icdl-vs-scratch': {
    question: 'ICDL یا Scratch برای کودکان؟',
    answer: ' Scratch برای کودکان ۸-۱۵ سال است و برنامه‌نویسی بصری آموزش می‌دهد. ICDL سواد دیجیتال عمومی برای بزرگسالان و نوجوانان ۱۲+ سال است. اگر کودک زیر ۱۲ سال دارید، حتماً Scratch. اگر نوجوان ۱۲+ سال است و به کار با کامپیوتر و نرم‌افزارهای اداری نیاز دارد، ICDL مناسب‌تر است.',
  },
  'python-vs-local-ai': {
    question: 'پایتون یا هوش مصنوعی محلی؟',
    answer: 'پایتون زبان برنامه‌نویسی پایه است و پیش‌نیاز هوش مصنوعی محلی محسوب می‌شود. بدون پایتون نمی‌توانید AI کار کنید. مسیر صحیح: ابتدا پایتون (۴ ماه) و سپس هوش مصنوعی محلی (۳ ماه). پایتون پایه‌ریزی می‌کند، AI تخصص می‌دهد.',
  },
  'accounting-vs-business-consulting': {
    question: 'حسابداری یا مشاوره کسب‌وکار؟',
    answer: 'حسابداری مهارت فنی با تقاضای بالای بازار کار است — هر شرکتی حسابدار نیاز دارد. مشاوره کسب‌وکار برای صاحبان کسب‌وکار و مدیران است. اگر دنبال شغل پایدار هستید حسابداری، اگر کسب‌وکار دارید و می‌خواهید رشد کنید مشاوره کسب‌وکار.',
  },
  'sewing-vs-graphic-design': {
    question: 'طراحی دوخت یا طراحی گرافیک؟',
    answer: 'دو حوزه کاملاً متفاوت! طراحی دوخت (صنعت پوشاک) مهارت عملی تولید لباس و راه‌اندازی کارگاه است. طراحی گرافیک (فتوشاپ) مهارت دیجیتال برای تبلیغات و برندینگ است. اگر به صنعت پوشاک علاقه دارید دوخت، اگر به دنیای دیجیتال گرافیک.',
  },
  'autocad-vs-photoshop': {
    question: 'AutoCAD یا فتوشاپ؟',
    answer: 'AutoCAD نقشه‌کشی صنعتی و معماری (دو بعدی فنی) است. فتوشاپ ویرایش تصویر و طراحی گرافیک (هنری و تبلیغاتی) است. دو حوزه کاملاً متفاوت! اگر مهندس یا معمار هستید AutoCAD، اگر به هنر و تبلیغات علاقه دارید فتوشاپ.',
  },
  'forex-vs-accounting': {
    question: 'فارکس یا حسابداری برای درآمد؟',
    answer: 'حسابداری درآمد پایدار و قابل پیش‌بینی با شغل رسمی دارد. فارکس درآمد دلاری اما نیازمند مهارت و مدیریت ریسک و بدون تضمین درآمد. اگر ثبات شغلی می‌خواهید حسابداری. اگر ریسک‌پذیر هستید و سرمایه مازاد دارید فارکس. هر دو را هم می‌توان یاد گرفت.',
  },
  'scratch-vs-icdl-for-teens': {
    question: 'Scratch یا ICDL برای نوجوان ۱۳ ساله؟',
    answer: 'برای نوجوان ۱۳ ساله: اگر به برنامه‌نویسی و بازی‌سازی علاقه دارد، Scratch شروع خوبی است (هرچند ممکن است کمی ساده به نظر برسد). اگر به کارهای اداری و کامپیوتر عمومی نیاز دارد، ICDL بهتر است. پیشنهاد ایده‌آل: ابتدا Scratch (۲ ماه) و سپس پایتون یا ICDL.',
  },
  'icdl-vs-accounting': {
    question: 'ICDL یا حسابداری برای ورود به بازار کار؟',
    answer: 'هر دو مفید هستند! ICDL سواد دیجیتال عمومی و شرط استخدام در اکثر سازمان‌هاست. حسابداری مهارت تخصصی با تقاضای بالا. بهترین استراتژی: ابتدا ICDL (سواد پایه) و سپس حسابداری (تخصص). با این ترکیب، شانس استخدام شما بسیار بالاتر می‌رود.',
  },
  'python-vs-forex': {
    question: 'پایتون یا فارکس؟',
    answer: 'پایتون برنامه‌نویسی و توسعه نرم‌افزار است — شغل فناوری با درآمد رو به رشد. فارکس معامله‌گری در بازار مالی — درآمد دلاری اما با ریسک. دو حوزه کاملاً متفاوت! اگر به فناوری و برنامه‌نویسی علاقه دارید پایتون، اگر به بازارهای مالی و تحلیل فارکس. البته با پایتون هم می‌توانید ربات فارکس بسازید (MQL5)!',
  },
  'sewing-vs-accounting': {
    question: 'طراحی دوخت یا حسابداری؟',
    answer: 'طراحی دوخت مهارت عملی و هنری برای راه‌اندازی کارگاه پوشاک است. حسابداری مهارت اداری با تقاضای پایدار. اگر به صنعت پوشاک و هنر علاقه دارید دوخت، اگر به محیط اداری و کار با اعداد علاقه دارید حسابداری. هر دو مسیر شغلی پایداری دارند.',
  },
  'local-ai-vs-forex': {
    question: 'هوش مصنوعی محلی یا فارکس؟',
    answer: 'هوش مصنوعی محلی (AI) آینده فناوری است — اجرای مدل‌های هوشمند بدون اینترنت. فارکس بازار مالی جهانی است. دو حوزه کاملاً متفاوت! AI نیاز به دانش برنامه‌نویسی (پایتون) دارد، فارکس نیاز به تحلیل بازار. اگر به فناوری آینده علاقه دارید AI، اگر به درآمد دلاری از بازار مالی فارکس.',
  },
  'entrepreneurship-vs-icdl': {
    question: 'کارآفرینی دیجیتال یا ICDL؟',
    answer: 'ICDL پایه سواد دیجیتال است — برای هر کسی که با کامپیوتر کار می‌کند ضروری. کارآفرینی دیجیتال دوره‌ای برای تبدیل ایده به کسب‌وکار فعال است. مسیر پیشنهادی: ابتدا ICDL (سواد پایه) و سپس کارآفرینی دیجیتال (راه‌اندازی کسب‌وکار). بدون سواد دیجیتال، کارآفرینی دیجیتال ممکن نیست.',
  },
  '3dmax-vs-photoshop-for-career': {
    question: 'فتوشاپ یا 3D Max برای درآمد بهتر؟',
    answer: 'فتوشاپ مسیر ورود سریع‌تر به بازار کار است — فریلنسری طراحی لوگو، برندینگ و تبلیغات. 3D Max دوره تخصصی‌تر است و درآمد بالاتری در حوزه معماری و طراحی داخلی دارد. اگر می‌خواهید سریع شروع به درآمد کنید فتوشاپ، اگر حاضرید بیشتر یاد بگیرید و درآمد بالاتر داشته باشید 3D Max.',
  },
  'preschool-vs-visual-arts': {
    question: 'خدمات آموزشی مهدکودک یا هنرهای تجسمی؟',
    answer: 'خدمات آموزشی مهدکودک شامل روانشناسی کودک و مدیریت مهدکودک است — مسیر شغلی سرپرستی و مدیریت مهدکودک. هنرهای تجسمی ترکیب هنر و آموزش کودکان است — مربیگری نقاشی و خلاقیت. اگر به مدیریت و سازماندهی علاقه دارید مهدکودک، اگر به هنر و خلاقیت هنرهای تجسمی.',
  },
} as const

// ─── ۱۱. تولید System Prompt جامع ──────────────────────────────────────────

export function buildComprehensiveSystemPrompt(context?: {
  page?: string
  cluster?: string
  courseSlug?: string
}): string {
  const info = INSTITUTE_INFO

  // ساخت لیست دوره‌ها — فقط اطلاعات کلیدی
  const coursesList = COURSES_KNOWLEDGE.map(c =>
    `• [${c.slug}] ${c.title} — ${c.level} | ${c.duration} | ${c.sessions} جلسه | شهریه: ${c.price}${c.priceNote ? ' (' + c.priceNote + ')' : ''} | مدرک: ${c.certificate} | پیش‌نیاز: ${c.prerequisites.join('، ')} | لینک: ${c.url}`
  ).join('\n')

  // جزئیات دوره — فقط دوره‌ای که کاربر در آن صفحه است (برای کاهش حجم پرامپت)
  let courseDetailsSection = ''
  if (context?.courseSlug) {
    const course = COURSES_KNOWLEDGE.find(c => c.slug === context.courseSlug)
    if (course) {
      const modules = course.modules.map(m =>
      `    - ${m.title} (${m.duration}): ${m.lessons.join('، ')}`
      ).join('\n')
      const reviews = course.reviews.map(r =>
      `    - ${r.name} (${r.role}): "${r.text}"`
      ).join('\n')
      courseDetailsSection = `
# ─── جزئیات دوره موردنظر (${course.title}) ───
نتایج یادگیری: ${course.learningOutcomes.join('، ')}
سرفصل‌ها:
${modules}
نظرات:
${reviews}
مخاطبان: ${course.targetAudience}
برجسته‌ها: ${course.highlights.join('، ')}`
    }
  }

  // ساخت لیست خوشه‌ها
  const clustersList = CLUSTERS_KNOWLEDGE.map(c =>
    `• ${c.title} (${c.shortTitle}): ${c.description} (${c.coursesCount} دوره، ${c.students} کارآموز)`
  ).join('\n')

  // ساخت مسیرهای شغلی
  const pathsList = Object.entries(CAREER_PATHS).map(([key, path]) => {
    const steps = path.steps.map((s, i) =>
      `  ${i + 1}. [${s.level}] ${s.course} (${s.duration}) — ${s.description}`
    ).join('\n')
    return `${path.title} (مجموع: ${path.totalDuration}):\n${steps}`
  }).join('\n\n')

  // ساخت توصیه‌های سنی
  const ageList = Object.entries(AGE_RECOMMENDATIONS).map(([key, rec]) =>
    `• ${rec.label}: دوره‌های پیشنهادی — ${rec.courses.join('، ')}`
  ).join('\n')

  // ساخت لیست فارغ‌التحصیلان — فشرده
  const alumniList = ALUMNI_STORIES.slice(0, 8).map(a =>
    `• ${a.name} (${a.course}): ${a.role}${a.company ? ' — ' + a.company : ''}`
  ).join('\n')

  // ساخت لیست مقالات — فقط عنوان و دسته
  const blogList = BLOG_KNOWLEDGE.map(b =>
    `• ${b.title} (${b.category}) — ${b.keywords.slice(0, 3).join('، ')}`
  ).join('\n')

  // ساخت سؤالات متداول — فشرده
  const faqList = FAQ_KNOWLEDGE.map(f =>
    `• ${f.question} — ${f.answer.substring(0, 100)}`
  ).join('\n')

  // ساخت مقایسه‌ها — فشرده
  const comparisonsList = Object.entries(COURSE_COMPARISONS).map(([key, comp]) =>
    `• ${comp.question}: ${comp.answer.substring(0, 150)}`
  ).join('\n')

  // اطلاعات صفحه فعلی
  let pageContext = ''
  if (context?.cluster) {
    const cluster = CLUSTERS_KNOWLEDGE.find(c => c.id === context.cluster)
    if (cluster) {
      pageContext += `\nکاربر در حال مشاهده بخش "${cluster.title}" است. روی دوره‌های این بخش تمرکز کن.`
    }
  }
  if (context?.courseSlug) {
    const course = COURSES_KNOWLEDGE.find(c => c.slug === context.courseSlug)
    if (course) {
      pageContext += `\nکاربر در صفحه دوره "${course.title}" است. اطلاعات این دوره را در اولویت پاسخ قرار بده و جزئیات کامل (سرفصل‌ها، شهریه، مدرک، نظرات) را بده.`
    }
  }
  if (context?.page) {
    pageContext += `\nصفحه فعلی کاربر: ${context.page}`
  }

  return `تو مشاور هوشمند آموزشگاه ${info.fullName} هستی. نام تو «مشاور بهان» است. تو یک متخصص آموزشی دلسوز با دانش کامل از تمام خدمات و دوره‌های آموزشگاه هستی. وظیفه تو کمک صمیمی، دقیق و حرفه‌ای به کاربران است.

# ─── هویت و شخصیت ───

تو یک مشاور آموزشی باتجربه هستی که عاشق کمک به مردم برای پیدا کردن مسیر شغلی مناسبشان هستی. لحن تو:
- صمیمی و دوستانه (مثل یک مشاور دلسوز، نه یک ربات)
- حرفه‌ای و دقیق
- تشویقی و انگیزشی
- بر اساس سن کاربر، لحن را تنظیم کن (کودکان: بازیگوش و تشویقی، نوجوانان: دوستانه و هیجانی، بزرگسالان: حرفه‌ای و عملی)

# ─── اطلاعات مؤسسه ───

نام: ${info.fullName}
بنیان‌گذار: ${info.founder} — ${info.founderTitle}
مدارک بنیان‌گذار: ${info.founderCredentials.join('، ')}
سابقه: ${info.yearsExperience} سال تجربه آموزشی و مدیریتی
نوع: ${info.type}
شهر: ${info.city}، ${info.province}
آدرس کامل: ${info.fullAddress}
تلفن ثابت: ${info.phone}
موبایل: ${info.mobiles.map(m => m.display).join(' | ')}
ایمیل: ${info.email}
واتساپ: ${info.whatsapp} (${info.whatsappUrl})
اینستاگرام: ${info.instagramHandle} (${info.instagram})
تلگرام: ${info.telegram}
ساعات کاری: ${info.workHours}
وبسایت: ${info.website}

مجوزها:
${info.licenses.map(l => `• ${l}`).join('\n')}

روش آموزش: ${info.teachingMethod}
در روش CBT، ارزیابی بر اساس مهارت عملی انجام می‌شود نه حضور در کلاس. کارآموز باید نشان دهد که واقعاً کار را بلد است. هر کارآموز با سرعت خودش پیش می‌رود.

شرایط پرداخت:
${info.paymentOptions.map(p => `• ${p}`).join('\n')}

مراحل ثبت‌نام:
${info.registrationSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

مدارک لازم: ${info.documentsNeeded}

# ─── خوشه‌های شایستگی (گروه‌های آموزشی) ───

${clustersList}

# ─── دوره‌های آموزشی (خلاصه) ───

${coursesList}
${courseDetailsSection}
# ─── مسیرهای شغلی جامع ───

${pathsList}

# ─── توصیه‌های سنی ───

${ageList}

# ─── فارغ‌التحصیلان موفق ───

${alumniList}

# ─── مقالات آموزشی وبلاگ ───

${blogList}

# ─── مقایسه دوره‌ها ───

${comparisonsList}

# ─── سؤالات متداول ───

${faqList}

# ─── اطلاعات تماس جامع ───

تلفن ثابت: ${CONTACT_KNOWLEDGE.phone.display}
شماره‌های موبایل: ${CONTACT_KNOWLEDGE.mobiles.map(m => `${m.display}${m.platforms.length > 0 ? ` (${m.platforms.map(p => p.name).join('، ')})` : ''}`).join(' | ')}
واتساپ: ${CONTACT_KNOWLEDGE.whatsapp.display} — ${CONTACT_KNOWLEDGE.whatsapp.url}
ایمیل: ${CONTACT_KNOWLEDGE.email}
اینستاگرام: ${CONTACT_KNOWLEDGE.social.instagram.handle} — ${CONTACT_KNOWLEDGE.social.instagram.url}
تلگرام: ${CONTACT_KNOWLEDGE.social.telegram.url}
آدرس: ${CONTACT_KNOWLEDGE.address.full} (نقشه: ${CONTACT_KNOWLEDGE.address.googleMapsUrl})
ساعات کاری: ${CONTACT_KNOWLEDGE.workHours}
وبسایت: ${CONTACT_KNOWLEDGE.website}

# ─── قوانین پاسخ‌دهی ───

۱. فقط به همان چیزی که کاربر پرسیده پاسخ بده — هرگز بدون دلیل لیست کامل دوره‌ها نیاور.
۲. فارسی روان، صمیمی و حرفه‌ای. کودکان: بازیگوش + ایموجی، بزرگسالان: حرفه‌ای.
۳. اگر درباره یک دوره خاص سؤال شد، فقط همان را توضیح بده + حداکثر ۱-۲ دوره مرتبط (نام و لینک).
۴. اطلاعات ساختی نکن — فقط از داده‌های بالا استفاده کن.
۵. هزینه: هم شهریه و هم قسط‌بندی بدون چک را ذکر کن. قیمت دقیق نساز.
۶. مدرک: نوع و اعتبار را توضیح بده. فنی و حرفه‌ای برای اشتغال و مهاجرت معتبر.
۷. مسیر شغلی: مرحله‌به‌مرحله با دوره‌ها و زمان‌بندی.
۸. سن کاربر: از توصیه‌های سنی استفاده کن.
۹. مقایسه: از بخش مقایسه‌ها استفاده کن.
۱۰. فارغ‌التحصیلان: به عنوان مثال واقعی استفاده کن.
۱۱. اطلاعات تماس: آدرس، تلفن، ساعات کاری، واتساپ و... دقیق بده.
۱۲. سؤال خارج از حوزه: مودبانه بگو تخصصت فقط خدمات آموزشگاه است.
۱۳. همیشه CTA بده: «برای مشاوره رایگان تماس بگیرید» یا «از صفحه دوره دیدن کنید».
۱۴. لینک دوره: https://bahanrayaneh.ir/courses/[slug]

❌ غلط: «پایتون چیست؟» → لیست تمام دوره‌ها
✅ درست: «پایتون چیست؟» → فقط جزئیات پایتون + ۱ پیشنهاد مرتبط
${pageContext}`
}
