/**
 * Cron Scheduler — Phase 2 Completion
 * Manages recurring background tasks for automation, data mining, and maintenance
 */

export interface CronJob {
  id: string;
  name: string;
  nameFa: string;
  cron: string; // cron expression
  type: 'AUTOMATION' | 'DATA_MINING' | 'MAINTENANCE' | 'PREDICTION' | 'NOTIFICATION';
  enabled: boolean;
  lastRun?: Date;
  nextRun?: Date;
  lastStatus?: 'SUCCESS' | 'ERROR' | 'SKIPPED';
  lastError?: string;
  description: string;
}

// ────────────────────────────────────────────────
// Predefined Jobs Registry
// ────────────────────────────────────────────────

export const CRON_JOBS: CronJob[] = [
  // Automation Jobs
  {
    id: 'check-overdue-payments',
    name: 'Check Overdue Payments',
    nameFa: 'بررسی پرداخت‌های معوق',
    cron: '0 9 * * *', // Daily at 9 AM
    type: 'AUTOMATION',
    enabled: true,
    description: 'Checks for overdue payments and triggers reminder automation rules',
  },
  {
    id: 'follow-up-leads',
    name: 'Lead Follow-up Check',
    nameFa: 'پیگیری لیدهای بدون پاسخ',
    cron: '0 10 * * *', // Daily at 10 AM
    type: 'AUTOMATION',
    enabled: true,
    description: 'Identifies leads without recent follow-up and triggers automation',
  },
  {
    id: 'process-drip-campaigns',
    name: 'Process Drip Campaigns',
    nameFa: 'پردازش کمپین‌های چکه‌ای',
    cron: '0 */4 * * *', // Every 4 hours
    type: 'AUTOMATION',
    enabled: true,
    description: 'Processes active drip campaigns and sends scheduled messages',
  },
  {
    id: 'sla-monitor',
    name: 'SLA Breach Monitor',
    nameFa: 'نظارت بر نقض SLA',
    cron: '0 * * * *', // Every hour
    type: 'AUTOMATION',
    enabled: true,
    description: 'Monitors ticket SLA timers and escalates when breached',
  },

  // Data Mining & Analytics Jobs
  {
    id: 'daily-revenue-calc',
    name: 'Daily Revenue Aggregation',
    nameFa: 'محاسبه روزانه درآمد',
    cron: '0 23 * * *', // Daily at 11 PM
    type: 'DATA_MINING',
    enabled: true,
    description: 'Aggregates daily revenue data for BI dashboards',
  },
  {
    id: 'customer-clustering',
    name: 'Customer Clustering',
    nameFa: 'خوشه‌بندی مشتریان',
    cron: '0 2 * * 0', // Weekly on Sunday at 2 AM
    type: 'DATA_MINING',
    enabled: true,
    description: 'Runs K-Means clustering on customer segments for targeted marketing',
  },
  {
    id: 'behavior-pattern-analysis',
    name: 'Behavior Pattern Analysis',
    nameFa: 'تحلیل الگوهای رفتاری',
    cron: '0 3 * * 0', // Weekly on Sunday at 3 AM
    type: 'DATA_MINING',
    enabled: true,
    description: 'Analyzes user behavior patterns for personalization engine',
  },

  // Prediction Jobs
  {
    id: 'weekly-predictions',
    name: 'Weekly Prediction Refresh',
    nameFa: 'بازآوری هفتگی پیش‌بینی‌ها',
    cron: '0 1 * * 1', // Monday at 1 AM
    type: 'PREDICTION',
    enabled: true,
    description: 'Generates fresh revenue, enrollment, churn, and demand predictions',
  },
  {
    id: 'churn-batch-scan',
    name: 'Batch Churn Risk Scan',
    nameFa: 'اسکن دسته‌ای ریسک ریزش',
    cron: '0 4 * * 2,5', // Tue & Fri at 4 AM
    type: 'PREDICTION',
    enabled: true,
    description: 'Batch-scans all active customers for churn risk signals',
  },

  // Notification Jobs
  {
    id: 'course-reminder',
    name: 'Course Start Reminder',
    nameFa: 'یادآوری شروع دوره',
    cron: '0 8 * * *', // Daily at 8 AM
    type: 'NOTIFICATION',
    enabled: true,
    description: 'Sends reminders for courses starting within 48 hours',
  },
  {
    id: 'certificate-expiry',
    name: 'Certificate Expiry Check',
    nameFa: 'بررسی انقضای گواهینامه‌ها',
    cron: '0 7 * * 1', // Monday at 7 AM
    type: 'NOTIFICATION',
    enabled: true,
    description: 'Checks for certificates expiring in next 30 days and notifies holders',
  },

  // Maintenance Jobs
  {
    id: 'cleanup-sessions',
    name: 'Session Cleanup',
    nameFa: 'پاک‌سازی نشست‌ها',
    cron: '0 5 * * *', // Daily at 5 AM
    type: 'MAINTENANCE',
    enabled: true,
    description: 'Cleans up expired sessions and temporary data older than 30 days',
  },
  {
    id: 'db-stats-refresh',
    name: 'Database Statistics Refresh',
    nameFa: 'بازآوری آمار دیتابیس',
    cron: '0 6 * * 0', // Weekly on Sunday at 6 AM
    type: 'MAINTENANCE',
    enabled: true,
    description: 'Refreshes database statistics and optimizes query planning',
  },
];

// ────────────────────────────────────────────────
// Cron Expression Parser (Lightweight)
// ────────────────────────────────────────────────

export function getNextRun(cron: string, fromDate?: Date): Date {
  const parts = cron.split(' ');
  if (parts.length !== 5) throw new Error(`Invalid cron: ${cron}`);

  const [minute, hour, dom, month, dow] = parts;
  const now = fromDate || new Date();
  const next = new Date(now);

  // Simple next-run calculation for common patterns
  if (dom !== '*') {
    // Monthly
    next.setDate(parseInt(dom));
    next.setHours(parseInt(hour), parseInt(minute), 0, 0);
    if (next <= now) next.setMonth(next.getMonth() + 1);
  } else if (dow !== '*') {
    // Weekly
    const targetDow = parseInt(dow);
    const currentDow = next.getDay();
    let daysUntil = targetDow - currentDow;
    if (daysUntil <= 0) daysUntil += 7;
    next.setDate(next.getDate() + daysUntil);
    next.setHours(parseInt(hour), parseInt(minute), 0, 0);
  } else if (hour.includes('/')) {
    // Every N hours
    const [, interval] = hour.split('/');
    const intervalMs = parseInt(interval) * 60 * 60 * 1000;
    const targetHour = parseInt(minute); // minutes
    next.setMinutes(0, 0, 0);
    next.setHours(next.getHours() + 1);
    while (next.getHours() % parseInt(interval) !== 0) {
      next.setHours(next.getHours() + 1);
    }
    next.setMinutes(parseInt(minute), 0, 0);
    if (next <= now) next.setTime(next.getTime() + intervalMs);
  } else {
    // Daily
    next.setHours(parseInt(hour), parseInt(minute), 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
  }

  return next;
}

// ────────────────────────────────────────────────
// Job Execution Tracker (in-memory for now)
// ────────────────────────────────────────────────

const jobHistory: Array<{
  jobId: string;
  startedAt: Date;
  finishedAt?: Date;
  status: 'SUCCESS' | 'ERROR' | 'SKIPPED';
  error?: string;
  duration?: number;
}> = [];

export function recordJobExecution(jobId: string, status: 'SUCCESS' | 'ERROR' | 'SKIPPED', error?: string) {
  const record = {
    jobId,
    startedAt: new Date(),
    finishedAt: new Date(),
    status,
    error,
    duration: 0,
  };
  record.duration = record.finishedAt.getTime() - record.startedAt.getTime();
  jobHistory.unshift(record);
  if (jobHistory.length > 200) jobHistory.pop();
}

export function getJobHistory(limit = 50) {
  return jobHistory.slice(0, limit);
}

export function getJobStatuses(): Record<string, { lastRun?: Date; lastStatus?: string }> {
  const statuses: Record<string, { lastRun?: Date; lastStatus?: string }> = {};
  for (const h of jobHistory) {
    if (!statuses[h.jobId] || h.startedAt > (statuses[h.jobId].lastRun || new Date(0))) {
      statuses[h.jobId] = { lastRun: h.startedAt, lastStatus: h.status };
    }
  }
  return statuses;
}
