/**
 * Server-side personalization utility
 * Reads the br_campaign cookie to determine user persona and returns
 * persona-specific configuration for hero sections and recommendations.
 *
 * Cookie format: br_campaign=utm_source=xxx&utm_medium=xxx&utm_campaign=xxx
 * Alternatively: br_campaign=persona_name (direct persona identifier)
 */

export type Persona = 'teen' | 'trader' | 'entrepreneur' | 'jobseeker' | 'default';

export interface PersonalizationConfig {
  persona: Persona;
  heroTitle: string;
  heroSubtitle: string;
  heroHighlight: string;
  recommendedCluster: string;
  accentColor: string;
  ctaText: string;
  ctaLink: string;
  gradientFrom: string;
  gradientTo: string;
  gradientVia: string;
}

const personaConfigs: Record<Persona, PersonalizationConfig> = {
  teen: {
    persona: 'teen',
    heroTitle: 'مسیر یادگیری نوجوانان',
    heroSubtitle: 'از Scratch تا پایتون — یادگیری برنامه‌نویسی با بازی و خلاقیت',
    heroHighlight: 'دوره‌های ویژه نوجوانان',
    recommendedCluster: 'tech-ai',
    accentColor: '#eab308', // yellow-500
    ctaText: 'مشاهده دوره‌های نوجوانان',
    ctaLink: '/courses?cluster=tech-ai',
    gradientFrom: '#eab308', // yellow-500
    gradientVia: '#f59e0b', // amber-500
    gradientTo: '#f97316', // orange-500
  },
  trader: {
    persona: 'trader',
    heroTitle: 'مسیر معامله‌گری حرفه‌ای',
    heroSubtitle: 'فارکس، ارزدیجیتال و معامله‌گری الگوریتمی — مسیر درآمد دلاری',
    heroHighlight: 'دوره‌های بازارهای مالی',
    recommendedCluster: 'financial',
    accentColor: '#d97706', // amber-600
    ctaText: 'مشاهده دوره‌های معامله‌گری',
    ctaLink: '/courses?cluster=financial',
    gradientFrom: '#d97706', // amber-600
    gradientVia: '#ea580c', // orange-600
    gradientTo: '#dc2626', // red-600
  },
  entrepreneur: {
    persona: 'entrepreneur',
    heroTitle: 'مسیر کارآفرینی دیجیتال',
    heroSubtitle: 'از ایده تا درآمد — کارآفرینی آنلاین و توسعه کسب‌وکار',
    heroHighlight: 'دوره‌های کارآفرینی',
    recommendedCluster: 'management',
    accentColor: '#7c3aed', // violet-600
    ctaText: 'مشاهده دوره کارآفرینی',
    ctaLink: '/courses?cluster=management',
    gradientFrom: '#9333ea', // purple-600
    gradientVia: '#7c3aed', // violet-600
    gradientTo: '#c026d3', // fuchsia-600
  },
  jobseeker: {
    persona: 'jobseeker',
    heroTitle: 'مسیر اشتغال و مهارت‌آموزی',
    heroSubtitle: 'ICDL + مهارت‌های اداری — ورود سریع به بازار کار',
    heroHighlight: 'دوره‌های ICDL و استخدام',
    recommendedCluster: 'tech-ai',
    accentColor: '#0d9488', // teal-600
    ctaText: 'مشاهده دوره ICDL',
    ctaLink: '/courses?cluster=tech-ai',
    gradientFrom: '#0d9488', // teal-600
    gradientVia: '#0891b2', // cyan-600
    gradientTo: '#0284c7', // sky-600
  },
  default: {
    persona: 'default',
    heroTitle: '',
    heroSubtitle: '',
    heroHighlight: '',
    recommendedCluster: '',
    accentColor: '',
    ctaText: '',
    ctaLink: '',
    gradientFrom: '',
    gradientVia: '',
    gradientTo: '',
  },
};

/**
 * Detects persona from a campaign string by matching keywords.
 * Mirrors the logic in useUTMPersonalization hook for consistency.
 */
function detectPersonaFromCampaign(campaign: string): Persona | null {
  const lower = campaign.toLowerCase();

  if (lower.includes('teen') || lower.includes('scratch') || lower.includes('python')) {
    return 'teen';
  }
  if (lower.includes('forex') || lower.includes('trading') || lower.includes('mql5')) {
    return 'trader';
  }
  if (lower.includes('business') || lower.includes('entrepreneur')) {
    return 'entrepreneur';
  }
  if (lower.includes('icdl') || lower.includes('office') || lower.includes('employment')) {
    return 'jobseeker';
  }

  return null;
}

/**
 * Parses the br_campaign cookie value.
 * Supports two formats:
 * 1. URL-encoded UTM params: utm_source=xxx&utm_medium=xxx&utm_campaign=xxx
 * 2. Direct persona name: teen, trader, entrepreneur, jobseeker
 */
function parseBrCampaignCookie(cookieValue: string): {
  utmSource: string;
  utmMedium: string;
  utmCampaign: string;
} {
  const trimmed = cookieValue.trim();

  // Check if it's a direct persona identifier
  const directPersonas: Persona[] = ['teen', 'trader', 'entrepreneur', 'jobseeker'];
  if (directPersonas.includes(trimmed.toLowerCase() as Persona)) {
    return {
      utmSource: '',
      utmMedium: '',
      utmCampaign: trimmed.toLowerCase(),
    };
  }

  // Try URL-encoded format
  try {
    const params = new URLSearchParams(trimmed);
    const utmSource = params.get('utm_source') || '';
    const utmMedium = params.get('utm_medium') || '';
    const utmCampaign = params.get('utm_campaign') || '';

    // If we found at least one UTM param, return them
    if (utmSource || utmMedium || utmCampaign) {
      return { utmSource, utmMedium, utmCampaign };
    }
  } catch {
    // URLSearchParams failed, fall through
  }

  // Treat the whole value as a campaign identifier
  return {
    utmSource: '',
    utmMedium: '',
    utmCampaign: trimmed,
  };
}

/**
 * Reads the br_campaign cookie from the request header and returns
 * persona-specific personalization configuration.
 *
 * @param cookieHeader - The Cookie header string from the request (from headers())
 * @returns PersonalizationConfig for the detected persona, or default config
 */
export function getPersonalizationFromCookies(cookieHeader: string | null): PersonalizationConfig {
  if (!cookieHeader) {
    return personaConfigs.default;
  }

  // Find the br_campaign cookie
  const brCampaignMatch = cookieHeader.split(';').find((cookie) => {
    const [name] = cookie.trim().split('=');
    return name?.trim() === 'br_campaign';
  });

  if (!brCampaignMatch) {
    return personaConfigs.default;
  }

  // Extract the value after the first '=' (cookie value may contain '=')
  const eqIndex = brCampaignMatch.indexOf('=');
  if (eqIndex === -1) {
    return personaConfigs.default;
  }

  const cookieValue = brCampaignMatch.substring(eqIndex + 1).trim();
  if (!cookieValue) {
    return personaConfigs.default;
  }

  // Parse the cookie value
  const { utmSource, utmCampaign } = parseBrCampaignCookie(cookieValue);

  // Try to detect persona: campaign first, then source
  const persona =
    detectPersonaFromCampaign(utmCampaign) ||
    detectPersonaFromCampaign(utmSource);

  if (!persona) {
    return personaConfigs.default;
  }

  return personaConfigs[persona];
}
