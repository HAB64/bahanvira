/**
 * CRM Automation Engine — (configured via siteConfig)
 * Executes automation rules when triggers fire.
 * Integrates with notification-engine for SMS/WhatsApp.
 * 
 * Usage: Call executeAutomationRules(trigger, context) from API routes
 * after data mutations (lead creation, stage change, payment, etc.)
 */
import { db } from '@/lib/db';
import { notify } from './notification-engine';
import { siteConfig } from '@/config/site';

type TriggerType = 'LEAD_CREATED' | 'STAGE_CHANGED' | 'PAYMENT_RECEIVED' | 'PAYMENT_OVERDUE' | 'FOLLOW_UP_DUE' | 'TICKET_CREATED' | 'TICKET_SLA_BREACH' | 'QUOTE_ACCEPTED' | 'QUOTE_SENT' | 'APPOINTMENT_REMINDER' | 'ENROLLMENT_CREATED' | 'CERTIFICATE_ISSUED' | 'COURSE_VIEW' | 'FORM_SUBMIT' | 'CART_ABANDON' | 'INACTIVITY' | 'INBOUND_MESSAGE';

interface AutomationContext {
  leadId?: string;
  karAmuzId?: string;
  stage?: string;
  previousStage?: string;
  cluster?: string;
  assignedTo?: string;
  paymentId?: string;
  paymentStatus?: string;
  leadName?: string;
  leadPhone?: string;
  courseTitle?: string;
  amount?: number;
  dueDate?: string;
  [key: string]: unknown;
}

interface AutomationAction {
  type: 'CREATE_TASK' | 'ADD_TAG' | 'STAGE_CHANGE' | 'ADD_NOTE' | 'SEND_SMS' | 'SEND_WHATSAPP' | 'NOTIFY' | 'CREATE_INVOICE' | 'UPDATE_SEGMENT' | 'SEND_EMAIL' | 'ESCALATE_TICKET' | 'SEND_EITAA' | 'SEND_BALEH' | 'ENROLL_DRIP' | 'EXIT_DRIP' | 'SEND_UNIFIED';
  payload: Record<string, unknown>;
}

/**
 * Check if conditions match the current context
 */
function matchesConditions(conditions: Record<string, unknown> | null, context: AutomationContext): boolean {
  if (!conditions || Object.keys(conditions).length === 0) return true;

  for (const [key, value] of Object.entries(conditions)) {
    if (context[key] !== value) return false;
  }
  return true;
}

/**
 * Execute a single action
 */
async function executeAction(action: AutomationAction, context: AutomationContext): Promise<void> {
  switch (action.type) {
    case 'CREATE_TASK': {
      const { title, description, type, priority, dueDateOffsetHours, assignedTo } = action.payload;
      const dueDate = dueDateOffsetHours
        ? new Date(Date.now() + (Number(dueDateOffsetHours) * 60 * 60 * 1000))
        : undefined;

      await db.task.create({
        data: {
          title: String(title || 'وظیفه خودکار'),
          description: String(description || ''),
          type: String(type || 'FOLLOW_UP'),
          priority: String(priority || 'MEDIUM'),
          status: 'PENDING',
          dueDate,
          assignedTo: String(assignedTo || context.assignedTo || ''),
          leadId: context.leadId || undefined,
          karAmuzId: context.karAmuzId || undefined,
        },
      });
      break;
    }

    case 'ADD_TAG': {
      const { tagName, tagColor } = action.payload;
      if (!context.leadId || !tagName) break;

      // Find or create tag
      const tag = await db.tag.upsert({
        where: { name: String(tagName) },
        create: { name: String(tagName), color: String(tagColor || '#0d9488') },
        update: {},
      });

      // Add tag to lead (ignore if already tagged)
      try {
        await db.tagOnLead.create({
          data: {
            leadId: context.leadId,
            tagId: tag.id,
          },
        });
      } catch {
        // Unique constraint violation — already tagged, ignore
      }
      break;
    }

    case 'STAGE_CHANGE': {
      const { newStage } = action.payload;
      if (!context.leadId || !newStage) break;

      await db.lead.update({
        where: { id: context.leadId },
        data: { stage: String(newStage) },
      });
      break;
    }

    case 'ADD_NOTE': {
      const { content } = action.payload;
      if (!context.leadId || !content) break;

      await db.activityLog.create({
        data: {
          leadId: context.leadId,
          type: 'NOTE',
          content: String(content),
        },
      });
      break;
    }

    case 'SEND_SMS': {
      // Send SMS via Melipayamak using notification engine
      const { event, studentName, phone, courseTitle, amount, dueDate } = action.payload;
      if (!phone && !context.leadPhone) break;

      const name = String(studentName || context.leadName || '');
      const num = String(phone || context.leadPhone || '');
      const course = String(courseTitle || context.courseTitle || '');

      try {
        switch (event) {
          case 'LEAD_CREATED':
            await notify.leadCreated(name, num, course);
            break;
          case 'ENROLLMENT_SUCCESS':
            await notify.enrolled(name, num, course);
            break;
          case 'PAYMENT_OVERDUE':
            await notify.paymentOverdue(name, num, Number(amount || 0), String(dueDate || ''));
            break;
          case 'CLASS_REMINDER':
            await notify.classReminder(name, num, course);
            break;
          case 'CERTIFICATE_READY':
            await notify.certificateReady(name, num, course, '');
            break;
          case 'ALUMNI_RETARGET':
            await notify.alumniRetarget(name, num);
            break;
          default:
            console.warn(`[SMS] Unknown event type: ${event}`);
        }
      } catch (err) {
        console.error('[Automation] SMS action failed:', err);
        // Don't fail the whole rule execution
      }
      break;
    }

    case 'SEND_WHATSAPP': {
      // Send WhatsApp via n8n — handled by same notification engine
      // Same payload as SEND_SMS — both channels fire simultaneously in triggerWorkflow
      const { event: waEvent, studentName: waName, phone: waPhone, courseTitle: waCourse, amount: waAmount, dueDate: waDueDate } = action.payload;
      if (!waPhone && !context.leadPhone) break;

      const name = String(waName || context.leadName || '');
      const num = String(waPhone || context.leadPhone || '');
      const course = String(waCourse || context.courseTitle || '');

      try {
        switch (waEvent) {
          case 'LEAD_CREATED':
            await notify.leadCreated(name, num, course);
            break;
          case 'ENROLLMENT_SUCCESS':
            await notify.enrolled(name, num, course);
            break;
          case 'PAYMENT_OVERDUE':
            await notify.paymentOverdue(name, num, Number(waAmount || 0), String(waDueDate || ''));
            break;
          case 'CLASS_REMINDER':
            await notify.classReminder(name, num, course);
            break;
          case 'CERTIFICATE_READY':
            await notify.certificateReady(name, num, course, '');
            break;
          case 'ALUMNI_RETARGET':
            await notify.alumniRetarget(name, num);
            break;
          default:
            console.warn(`[WhatsApp] Unknown event type: ${waEvent}`);
        }
      } catch (err) {
        console.error('[Automation] WhatsApp action failed:', err);
      }
      break;
    }

    case 'NOTIFY': {
      // Unified notification — sends both SMS + WhatsApp
      const { event: notifyEvent, studentName: nName, phone: nPhone, courseTitle: nCourse, amount: nAmount, dueDate: nDueDate } = action.payload;
      if (!nPhone && !context.leadPhone) break;

      const name = String(nName || context.leadName || '');
      const num = String(nPhone || context.leadPhone || '');
      const course = String(nCourse || context.courseTitle || '');

      try {
        switch (notifyEvent) {
          case 'LEAD_CREATED':
            await notify.leadCreated(name, num, course);
            break;
          case 'ENROLLMENT_SUCCESS':
            await notify.enrolled(name, num, course);
            break;
          case 'PAYMENT_OVERDUE':
            await notify.paymentOverdue(name, num, Number(nAmount || 0), String(nDueDate || ''));
            break;
          case 'CLASS_REMINDER':
            await notify.classReminder(name, num, course);
            break;
          case 'CERTIFICATE_READY':
            await notify.certificateReady(name, num, course, '');
            break;
          case 'ALUMNI_RETARGET':
            await notify.alumniRetarget(name, num);
            break;
          default:
            console.warn(`[Notify] Unknown event type: ${notifyEvent}`);
        }
      } catch (err) {
        console.error('[Automation] Notify action failed:', err);
      }
      break;
    }

    default:
      console.warn(`Unknown automation action type: ${action.type}`);
  }
}

// ─── Phase 2: New action handlers ─────────────────────────────────────────────

async function executePhase2Action(action: AutomationAction, context: AutomationContext): Promise<void> {
  switch (action.type) {
    case 'CREATE_INVOICE': {
      const { items, leadId, karAmuzId, dueDate } = action.payload;
      if (!items || !Array.isArray(items)) break;

      const currentYear = new Date().getFullYear();
      const lastInvoice = await db.invoice.findFirst({
        where: { invoiceNumber: { startsWith: `INV-${currentYear}-` } },
        orderBy: { invoiceNumber: 'desc' },
      });
      let seq = 1;
      if (lastInvoice?.invoiceNumber) {
        const parts = lastInvoice.invoiceNumber.split('-');
        seq = (parseInt(parts[2] || '0', 10) || 0) + 1;
      }
      const invoiceNumber = `INV-${currentYear}-${seq.toString().padStart(4, '0')}`;

      const subtotal = (items as Array<{ total?: number; unitPrice?: number; quantity?: number }>).reduce(
        (sum, item) => sum + (item.total || (item.unitPrice || 0) * (item.quantity || 1)), 0
      );
      const taxAmount = Math.round(subtotal * 0.09);
      const totalAmount = subtotal + taxAmount;

      await db.invoice.create({
        data: {
          invoiceNumber,
          leadId: String(leadId || context.leadId || ''),
          karAmuzId: String(karAmuzId || context.karAmuzId || ''),
          items: items as any,
          subtotal,
          taxAmount,
          totalAmount,
          status: 'DRAFT',
          dueDate: dueDate ? new Date(String(dueDate)) : null,
        },
      });
      break;
    }

    case 'UPDATE_SEGMENT': {
      const { segment } = action.payload;
      if (!context.leadId || !segment) break;
      await db.lead.update({
        where: { id: context.leadId },
        data: { segment: String(segment) },
      });
      break;
    }

    case 'ESCALATE_TICKET': {
      const { ticketId, newPriority, assignedTo } = action.payload;
      if (!ticketId) break;
      const updateData: Record<string, unknown> = {};
      if (newPriority) updateData.priority = String(newPriority);
      if (assignedTo) updateData.assignedTo = String(assignedTo);
      if (Object.keys(updateData).length > 0) {
        await db.ticket.update({ where: { id: String(ticketId) }, data: updateData });
      }
      break;
    }

    case 'SEND_EMAIL': {
      // Use email engine for SMTP integration
      try {
        const { to, subject, body, templateId, variables } = action.payload;
        if (to || context.leadId) {
          const { sendEmail, sendTemplatedEmail } = await import('./email-engine');
          if (templateId) {
            await sendTemplatedEmail(
              String(templateId),
              String(to || ''),
              (variables as Record<string, string>) || {},
              context.leadId || undefined,
              context.karAmuzId || undefined,
            );
          } else if (to && subject && body) {
            await sendEmail({ to: String(to), subject: String(subject), body: String(body) });
          }
        }
      } catch (err) {
        console.error('[Automation] SEND_EMAIL action failed:', err);
      }
      break;
    }

    case 'SEND_EITAA': {
      try {
        const { chatId, text, keyboardButtons } = action.payload;
        if (!chatId && !context.leadPhone) break;
        const { sendUnifiedMessage } = await import('./messaging-unified');
        await sendUnifiedMessage({
          channel: 'EITAA',
          recipient: String(chatId || context.leadPhone || ''),
          content: String(text || ''),
          leadId: context.leadId,
          keyboardButtons: keyboardButtons as string[][] | undefined,
        });
      } catch (err) {
        console.error('[Automation] SEND_EITAA action failed:', err);
      }
      break;
    }

    case 'SEND_BALEH': {
      try {
        const { chatId, text, keyboardButtons } = action.payload;
        if (!chatId && !context.leadPhone) break;
        const { sendUnifiedMessage } = await import('./messaging-unified');
        await sendUnifiedMessage({
          channel: 'BALEH',
          recipient: String(chatId || context.leadPhone || ''),
          content: String(text || ''),
          leadId: context.leadId,
          keyboardButtons: keyboardButtons as string[][] | undefined,
        });
      } catch (err) {
        console.error('[Automation] SEND_BALEH action failed:', err);
      }
      break;
    }

    case 'SEND_UNIFIED': {
      try {
        const { channel, recipient, text, subject, keyboardButtons, inlineButtons } = action.payload;
        if (!recipient && !context.leadPhone) break;
        const { sendUnifiedMessage } = await import('./messaging-unified');
        await sendUnifiedMessage({
          channel: (channel as any) || 'SMS',
          recipient: String(recipient || context.leadPhone || ''),
          content: String(text || ''),
          subject: subject ? String(subject) : undefined,
          leadId: context.leadId,
          keyboardButtons: keyboardButtons as string[][] | undefined,
          inlineButtons: inlineButtons as any,
        });
      } catch (err) {
        console.error('[Automation] SEND_UNIFIED action failed:', err);
      }
      break;
    }

    case 'ENROLL_DRIP': {
      try {
        const { dripCampaignId } = action.payload;
        if (!dripCampaignId || !context.leadId) break;
        const { enrollInDrip } = await import('./drip-engine');
        await enrollInDrip(String(dripCampaignId), context.leadId, context.karAmuzId);
      } catch (err) {
        console.error('[Automation] ENROLL_DRIP action failed:', err);
      }
      break;
    }

    case 'EXIT_DRIP': {
      try {
        const { reason } = action.payload;
        if (!context.leadId) break;
        const { exitDripForLead } = await import('./drip-engine');
        await exitDripForLead(
          context.leadId,
          (reason as any) || 'STAGE_CHANGE'
        );
      } catch (err) {
        console.error('[Automation] EXIT_DRIP action failed:', err);
      }
      break;
    }

    default:
      // Not a Phase 2 action, skip
      break;
  }
}

/**
 * Main entry point: Execute all matching automation rules for a given trigger
 */
export async function executeAutomationRules(
  trigger: TriggerType,
  context: AutomationContext
): Promise<{ rulesExecuted: number; errors: string[] }> {
  const errors: string[] = [];
  let rulesExecuted = 0;

  try {
    // Find all active rules for this trigger
    const rules = await db.automationRule.findMany({
      where: {
        trigger,
        isActive: true,
      },
      orderBy: { priority: 'desc' },
    });

    for (const rule of rules) {
      try {
        // Check conditions
        const conditions = rule.conditions as Record<string, unknown> | null;
        if (!matchesConditions(conditions, context)) continue;

        // Execute actions
        const actions = rule.actions as unknown as AutomationAction[];
        if (!Array.isArray(actions)) continue;

        const phase2Types = ['CREATE_INVOICE', 'UPDATE_SEGMENT', 'ESCALATE_TICKET', 'SEND_EMAIL'];
        for (const action of actions) {
          if (phase2Types.includes(action.type)) {
            await executePhase2Action(action, context);
          } else {
            await executeAction(action, context);
          }
        }

        // Update lastRunAt
        await db.automationRule.update({
          where: { id: rule.id },
          data: { lastRunAt: new Date() },
        });

        rulesExecuted++;
      } catch (ruleError) {
        const msg = `Rule "${rule.name}" failed: ${ruleError instanceof Error ? ruleError.message : String(ruleError)}`;
        console.error(msg);
        errors.push(msg);
      }
    }
  } catch (error) {
    const msg = `Automation engine error: ${error instanceof Error ? error.message : String(error)}`;
    console.error(msg);
    errors.push(msg);
  }

  return { rulesExecuted, errors };
}

/**
 * Seed default automation rules for a new CRM installation
 * Updated with SMS/WhatsApp notification actions
 */
export async function seedDefaultAutomationRules(): Promise<void> {
  const existing = await db.automationRule.count();
  if (existing > 0) return; // Don't seed if rules already exist

  const defaults = [
    {
      name: 'خوش‌آمدگویی و پیگیری لید جدید',
      trigger: 'LEAD_CREATED',
      conditions: {},
      actions: [
        {
          type: 'NOTIFY',
          payload: { event: 'LEAD_CREATED' },
        },
        {
          type: 'CREATE_TASK',
          payload: {
            title: 'پیگیری لید جدید',
            description: 'لید جدید ثبت شده است. در اسرع وقت تماس بگیرید.',
            type: 'FOLLOW_UP',
            priority: 'HIGH',
            dueDateOffsetHours: 24,
          },
        },
      ],
      priority: 10,
      isActive: true,
    },
    {
      name: 'برچسب خودکار لید فنی',
      trigger: 'LEAD_CREATED',
      conditions: { cluster: 'tech-ai' },
      actions: [
        {
          type: 'ADD_TAG',
          payload: { tagName: 'فناوری', tagColor: '#3b82f6' },
        },
      ],
      priority: 5,
      isActive: true,
    },
    {
      name: 'وظیفه پیگیری پس از تماس',
      trigger: 'STAGE_CHANGED',
      conditions: { stage: 'CONTACTED' },
      actions: [
        {
          type: 'CREATE_TASK',
          payload: {
            title: 'پیگیری پس از تماس اولیه',
            description: 'با لید تماس گرفته شده. پیگیری علاقه‌مندی.',
            type: 'FOLLOW_UP',
            priority: 'MEDIUM',
            dueDateOffsetHours: 48,
          },
        },
      ],
      priority: 8,
      isActive: true,
    },
    {
      name: 'نوتیفیکیشن و برچسب ثبت‌نام',
      trigger: 'STAGE_CHANGED',
      conditions: { stage: 'ENROLLED' },
      actions: [
        {
          type: 'NOTIFY',
          payload: { event: 'ENROLLMENT_SUCCESS' },
        },
        {
          type: 'ADD_NOTE',
          payload: { content: 'لید ثبت‌نام کرده است. رکورد کارآموز خودکار ایجاد شد.' },
        },
        {
          type: 'ADD_TAG',
          payload: { tagName: 'ثبت‌نام‌شده', tagColor: '#10b981' },
        },
      ],
      priority: 10,
      isActive: true,
    },
    {
      name: 'یادآور پرداخت سررسیدشده',
      trigger: 'PAYMENT_OVERDUE',
      conditions: {},
      actions: [
        {
          type: 'NOTIFY',
          payload: { event: 'PAYMENT_OVERDUE' },
        },
        {
          type: 'CREATE_TASK',
          payload: {
            title: 'پیگیری پرداخت سررسیدشده',
            description: 'یک پرداخت سررسید شده است. از مشتری پیگیری کنید.',
            type: 'PAYMENT_REMINDER',
            priority: 'URGENT',
          },
        },
      ],
      priority: 15,
      isActive: true,
    },
    // ── Phase 2 Default Rules ──
    {
      name: 'ایجاد فاکتور پس از پذیرش پیشنهاد',
      trigger: 'QUOTE_ACCEPTED',
      conditions: {},
      actions: [
        {
          type: 'CREATE_INVOICE',
          payload: {},
        },
        {
          type: 'ADD_NOTE',
          payload: { content: 'پیشنهاد پذیرفته شد. فاکتور خودکار ایجاد شد.' },
        },
      ],
      priority: 10,
      isActive: true,
    },
    {
      name: 'ارتقای اولویت تیکت SLA نقض‌شده',
      trigger: 'TICKET_SLA_BREACH',
      conditions: {},
      actions: [
        {
          type: 'ESCALATE_TICKET',
          payload: { newPriority: 'URGENT' },
        },
        {
          type: 'CREATE_TASK',
          payload: {
            title: 'تیکت SLA نقض‌شده — اقدام فوری',
            description: 'یک تیکت سطح خدمات نقض شده است. فوراً رسیدگی کنید.',
            type: 'FOLLOW_UP',
            priority: 'URGENT',
            dueDateOffsetHours: 1,
          },
        },
      ],
      priority: 20,
      isActive: true,
    },
  ];

  for (const rule of defaults) {
    await db.automationRule.create({ data: rule });
  }
}
