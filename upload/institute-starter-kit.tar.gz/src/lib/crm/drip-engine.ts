/**
 * موتور Drip Campaign — بهان رایانه
 * اجرای کمپین‌های قطره‌ای رفتاری بر اساس رفتار کاربر
 *
 * قابلیت‌ها:
 *   - ثبت‌نام خودکار در drip بر اساس trigger
 *   - اجرای مرحله‌ای با تأخیر
 *   - خروج خودکار بر اساس رفتار (پاسخ، ثبت‌نام، تغییر stage)
 *   - شخصی‌سازی محتوا با متغیرهای لید
 */

import { db } from '@/lib/db';
import { sendUnifiedMessage, type MessagingChannel } from './messaging-unified';
import { siteConfig } from '@/config/site';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface DripStep {
  day: number;               // روز نسبی از شروع (0 = فوری)
  delayHours?: number;       // تأخیر دقیق به ساعت (اولویت بالاتر از day)
  channel: MessagingChannel; // کانال ارسال
  subject?: string;          // موضوع (برای ایمیل)
  body: string;              // محتوای پیام — از {{name}}, {{course}}, {{institute}} پشتیبانی می‌کند
  templateId?: string;       // شناسه قالب ایمیل
  mediaUrl?: string;         // URL فایل/تصویر
  keyboardButtons?: string[][];       // کیبورد (ایتا/بله)
  inlineButtons?: Array<{ text: string; callbackData: string }[]>; // دکمه شیشه‌ای
}

export type DripTrigger =
  | 'LEAD_CREATED'
  | 'STAGE_CHANGED'
  | 'COURSE_VIEW'
  | 'FORM_SUBMIT'
  | 'CART_ABANDON'
  | 'INACTIVITY'
  | 'CERTIFICATE_ISSUED'
  | 'PAYMENT_OVERDUE';

// ─── Variable Replacement ─────────────────────────────────────────────────────

function replaceVariables(
  template: string,
  variables: Record<string, string>
): string {
  let result = template;
  for (const [key, value] of Object.entries(variables)) {
    const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
    result = result.replace(regex, value);
  }
  // حذف متغیرهای جایگذاری‌نشده
  result = result.replace(/\{\{[^}]+\}\}/g, '');
  return result;
}

async function buildLeadVariables(leadId: string): Promise<Record<string, string>> {
  const lead = await db.lead.findUnique({
    where: { id: leadId },
    select: { name: true, phone: true, email: true, course: true, cluster: true, stage: true },
  });

  return {
    name: lead?.name || 'کاربر',
    phone: lead?.phone || '',
    email: lead?.email || '',
    course: lead?.course || '',
    cluster: lead?.cluster || '',
    stage: lead?.stage || '',
    institute: siteConfig.name.fa,
    institutePhone: siteConfig.contact.phone,
  };
}

// ─── enrollInDrip ─────────────────────────────────────────────────────────────

/**
 * ثبت‌نام یک لید در drip campaign
 * فراخوانی از automation rules یا مستقیم از API
 */
export async function enrollInDrip(
  dripCampaignId: string,
  leadId: string,
  karAmuzId?: string
): Promise<{ enrollmentId: string; nextStepAt: Date } | null> {
  // بررسی اینکه drip فعال است
  const drip = await db.dripCampaign.findUnique({
    where: { id: dripCampaignId },
  });

  if (!drip || !drip.isActive || drip.status !== 'ACTIVE') {
    console.warn(`[Drip] Campaign ${dripCampaignId} is not active`);
    return null;
  }

  // بررسی اینکه لید قبلاً در این drip ثبت‌نام نشده
  const existing = await db.dripEnrollment.findFirst({
    where: {
      dripCampaignId,
      leadId,
      status: 'ACTIVE',
    },
  });

  if (existing) {
    console.log(`[Drip] Lead ${leadId} already enrolled in ${dripCampaignId}`);
    return { enrollmentId: existing.id, nextStepAt: existing.nextStepAt || new Date() };
  }

  // محاسبه زمان مرحله اول
  const steps = drip.steps as DripStep[] | null;
  if (!steps || steps.length === 0) {
    console.warn(`[Drip] Campaign ${dripCampaignId} has no steps`);
    return null;
  }

  const firstStep = steps[0];
  const delayMs = firstStep.delayHours
    ? firstStep.delayHours * 60 * 60 * 1000
    : firstStep.day * 24 * 60 * 60 * 1000;
  const nextStepAt = new Date(Date.now() + delayMs);

  // ایجاد enrollment
  const enrollment = await db.dripEnrollment.create({
    data: {
      dripCampaignId,
      leadId,
      karAmuzId: karAmuzId || null,
      currentStep: 0,
      status: 'ACTIVE',
      nextStepAt,
    },
  });

  // بروزرسانی آمار drip
  await db.dripCampaign.update({
    where: { id: dripCampaignId },
    data: { enrolledCount: { increment: 1 } },
  });

  return { enrollmentId: enrollment.id, nextStepAt };
}

// ─── processDripTriggers ──────────────────────────────────────────────────────

/**
 * بررسی و ثبت‌نام خودکار لیدها در drip campaign ها بر اساس trigger
 * فراخوانی از automation engine یا API routes
 */
export async function processDripTriggers(
  trigger: DripTrigger,
  leadId: string,
  context?: Record<string, string>
): Promise<{ enrolled: string[] }> {
  const enrolled: string[] = [];

  // یافتن drip campaign های فعال با این trigger
  const matchingDrips = await db.dripCampaign.findMany({
    where: {
      trigger,
      isActive: true,
      status: 'ACTIVE',
    },
  });

  for (const drip of matchingDrips) {
    // بررسی شروط trigger
    if (drip.triggerConditions) {
      const conditions = drip.triggerConditions as Record<string, string>;
      let matches = true;
      for (const [key, value] of Object.entries(conditions)) {
        if (context && context[key] !== value) {
          matches = false;
          break;
        }
      }
      if (!matches) continue;
    }

    // بررسی targeting
    if (drip.targetSegment || drip.targetCluster) {
      const lead = await db.lead.findUnique({
        where: { id: leadId },
        select: { segment: true, cluster: true },
      });
      if (lead) {
        if (drip.targetSegment && drip.targetSegment !== 'ALL' && drip.targetSegment !== lead.segment) continue;
        if (drip.targetCluster && drip.targetCluster !== 'all' && drip.targetCluster !== lead.cluster) continue;
      }
    }

    // ثبت‌نام
    const result = await enrollInDrip(drip.id, leadId);
    if (result) {
      enrolled.push(drip.id);
    }
  }

  return { enrolled };
}

// ─── executeDripStep ───────────────────────────────────────────────────────────

/**
 * اجرای یک مرحله drip برای یک enrollment
 */
export async function executeDripStep(
  enrollmentId: string
): Promise<{ sent: boolean; error?: string }> {
  const enrollment = await db.dripEnrollment.findUnique({
    where: { id: enrollmentId },
    include: { dripCampaign: true },
  });

  if (!enrollment || enrollment.status !== 'ACTIVE') {
    return { sent: false, error: 'Enrollment not active' };
  }

  const steps = enrollment.dripCampaign.steps as DripStep[] | null;
  if (!steps || enrollment.currentStep >= steps.length) {
    // تکمیل drip
    await db.dripEnrollment.update({
      where: { id: enrollmentId },
      data: {
        status: 'COMPLETED',
        completedAt: new Date(),
      },
    });
    await db.dripCampaign.update({
      where: { id: enrollment.dripCampaignId },
      data: { completedCount: { increment: 1 } },
    });
    return { sent: false, error: 'Drip completed' };
  }

  const step = steps[enrollment.currentStep];
  const leadId = enrollment.leadId;

  if (!leadId) {
    return { sent: false, error: 'No lead ID' };
  }

  // شخصی‌سازی محتوا
  const variables = await buildLeadVariables(leadId);
  const personalizedBody = replaceVariables(step.body, variables);
  const personalizedSubject = step.subject ? replaceVariables(step.subject, variables) : undefined;

  // یافتن chat_id برای ایتا/بله
  let recipient: string;
  if (step.channel === 'EITAA' || step.channel === 'BALEH') {
    const messengerContact = await db.messengerContact.findFirst({
      where: { leadId, channel: step.channel },
    });
    if (messengerContact) {
      recipient = messengerContact.chatId;
    } else {
      // fallback به شماره تلفن
      const lead = await db.lead.findUnique({ where: { id: leadId }, select: { phone: true, email: true } });
      recipient = step.channel === 'EITAA' || step.channel === 'BALEH'
        ? (lead?.phone || '')
        : (lead?.email || '');
    }
  } else if (step.channel === 'EMAIL') {
    const lead = await db.lead.findUnique({ where: { id: leadId }, select: { email: true } });
    recipient = lead?.email || '';
  } else {
    const lead = await db.lead.findUnique({ where: { id: leadId }, select: { phone: true } });
    recipient = lead?.phone || '';
  }

  if (!recipient) {
    return { sent: false, error: `No recipient for channel ${step.channel}` };
  }

  // ارسال پیام
  const result = await sendUnifiedMessage({
    channel: step.channel,
    recipient,
    content: personalizedBody,
    subject: personalizedSubject,
    mediaUrl: step.mediaUrl,
    leadId,
    karAmuzId: enrollment.karAmuzId || undefined,
    dripStepId: enrollmentId,
    keyboardButtons: step.keyboardButtons,
    inlineButtons: step.inlineButtons,
  });

  // بروزرسانی enrollment
  const nextStepIndex = enrollment.currentStep + 1;
  const isLastStep = nextStepIndex >= steps.length;

  if (isLastStep) {
    await db.dripEnrollment.update({
      where: { id: enrollmentId },
      data: {
        currentStep: nextStepIndex,
        status: 'COMPLETED',
        completedAt: new Date(),
        nextStepAt: null,
      },
    });
    await db.dripCampaign.update({
      where: { id: enrollment.dripCampaignId },
      data: { completedCount: { increment: 1 } },
    });
  } else {
    const nextStep = steps[nextStepIndex];
    const delayMs = nextStep.delayHours
      ? nextStep.delayHours * 60 * 60 * 1000
      : nextStep.day * 24 * 60 * 60 * 1000;
    // محاسبه تأخیر نسب به شروع enrollment
    const nextStepAt = new Date(enrollment.enrolledAt.getTime() + delayMs);

    await db.dripEnrollment.update({
      where: { id: enrollmentId },
      data: {
        currentStep: nextStepIndex,
        nextStepAt,
      },
    });
  }

  return { sent: result.success, error: result.error };
}

// ─── processDueDripSteps ───────────────────────────────────────────────────────

/**
 * پردازش همه drip step های سررسیدشده
 * فراخوانی از cron job
 */
export async function processDueDripSteps(): Promise<{
  processed: number;
  sent: number;
  failed: number;
  errors: string[];
}> {
  const errors: string[] = [];
  let processed = 0;
  let sent = 0;
  let failed = 0;

  // یافتن enrollment های فعال که nextStepAt گذشته
  const dueEnrollments = await db.dripEnrollment.findMany({
    where: {
      status: 'ACTIVE',
      nextStepAt: { lte: new Date() },
    },
    select: { id: true },
  });

  for (const enrollment of dueEnrollments) {
    try {
      const result = await executeDripStep(enrollment.id);
      processed++;
      if (result.sent) {
        sent++;
      } else {
        failed++;
        if (result.error) errors.push(`Enrollment ${enrollment.id}: ${result.error}`);
      }

      // فاصله ۵۰ms بین هر ارسال
      await new Promise(resolve => setTimeout(resolve, 50));
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      errors.push(`Enrollment ${enrollment.id}: ${msg}`);
      failed++;
      processed++;
    }
  }

  return { processed, sent, failed, errors };
}

// ─── exitDripForLead ──────────────────────────────────────────────────────────

/**
 * خروج لید از همه drip campaign های فعال
 * فراخوانی وقتی کاربر ثبت‌نام می‌کند یا stage تغییر می‌کند
 */
export async function exitDripForLead(
  leadId: string,
  reason: 'REPLY' | 'ENROLL' | 'STAGE_CHANGE' | 'MANUAL' | 'UNSUBSCRIBE'
): Promise<{ exited: number }> {
  const activeDrips = await db.dripEnrollment.findMany({
    where: { leadId, status: 'ACTIVE' },
    include: { dripCampaign: true },
  });

  let exited = 0;

  for (const drip of activeDrips) {
    // بررسی شروط exit
    const shouldExit =
      (reason === 'REPLY' && drip.dripCampaign.exitOnReply) ||
      (reason === 'ENROLL' && drip.dripCampaign.exitOnEnroll) ||
      (reason === 'STAGE_CHANGE' && drip.dripCampaign.exitOnStageChange) ||
      reason === 'MANUAL' ||
      reason === 'UNSUBSCRIBE';

    if (shouldExit) {
      await db.dripEnrollment.update({
        where: { id: drip.id },
        data: {
          status: 'EXITED',
          exitedAt: new Date(),
          exitReason: reason,
        },
      });

      // اگر ثبت‌نام کرده، شمارش تبدیل
      if (reason === 'ENROLL') {
        await db.dripEnrollment.update({
          where: { id: drip.id },
          data: {
            convertedAt: new Date(),
            conversionType: 'ENROLLMENT',
          },
        });
        await db.dripCampaign.update({
          where: { id: drip.dripCampaignId },
          data: { conversionCount: { increment: 1 } },
        });
      }

      exited++;
    }
  }

  return { exited };
}

// ─── seedDefaultDripCampaigns ─────────────────────────────────────────────────

/**
 * ایجاد drip campaign های پیش‌فرض
 */
export async function seedDefaultDripCampaigns(): Promise<void> {
  const existing = await db.dripCampaign.count();
  if (existing > 0) return;

  const defaults = [
    {
      name: 'خوش‌آمدگویی لید جدید',
      description: 'دنباله پیام خوش‌آمدگویی و معرفی برای لیدهای جدید',
      trigger: 'LEAD_CREATED',
      triggerConditions: {},
      targetSegment: 'NEW',
      targetCluster: '',
      targetPersona: '',
      exitOnReply: true,
      exitOnEnroll: true,
      exitOnStageChange: true,
      steps: [
        {
          day: 0,
          channel: 'EITAA',
          body: `سلام {{name}} عزیز! 👋\n\nبه ${siteConfig.name.fa} خوش آمدید.\n\nما دوره‌های متنوعی در حوزه‌های فناوری، مالی و مدیریت داریم.\n\nبرای دیدن لیست دوره‌ها عدد ۲ را بفرستید.`,
          keyboardButtons: [
            ['۱. مشاوره رایگان'],
            ['۲. لیست دوره‌ها'],
          ],
        },
        {
          day: 1,
          channel: 'SMS',
          body: `${siteConfig.name.fa}: {{name}} عزیز، منتظر تصمیم شما هستیم! برای مشاوره رایگان تماس بگیرید: ${siteConfig.contact.phone}`,
        },
        {
          day: 3,
          channel: 'EITAA',
          body: `{{name}} عزیز، 🔔\n\nیادآوری: فرصت دریافت مشاوره رایگان و تخفیف ویژه ثبت‌نام زودهنگام هنوز فعال است!\n\nبرای مشاوره عدد ۱ را بفرستید.`,
          keyboardButtons: [
            ['۱. مشاوره رایگان'],
            ['۳. ارتباط با مشاور'],
          ],
        },
        {
          day: 7,
          channel: 'SMS',
          body: `${siteConfig.name.fa}: آخرین فرصت! تخفیف ویژه ثبت‌نام پایان هفته. تماس: ${siteConfig.contact.phone}`,
        },
      ],
    },
    {
      name: 'پیگیری سبد خرید رهاشده',
      description: 'پیگیری لیدهایی که فرم ثبت‌نام را شروع ولی تکمیل نکرده‌اند',
      trigger: 'CART_ABANDON',
      triggerConditions: {},
      exitOnReply: true,
      exitOnEnroll: true,
      exitOnStageChange: false,
      steps: [
        {
          day: 0,
          delayHours: 1,
          channel: 'SMS',
          body: `{{name}} عزیز، ثبت‌نام شما تکمیل نشده است. آیا نیاز به کمک دارید؟ تماس: ${siteConfig.contact.phone}`,
        },
        {
          day: 1,
          channel: 'EITAA',
          body: `🔔 {{name}} عزیز، سبد خرید شما منتظر است!\n\nبرای تکمیل ثبت‌نام و دریافت تخفیف، روی دکمه زیر بزنید:`,
          inlineButtons: [
            [{ text: 'تکمیل ثبت‌نام', callbackData: 'complete_enrollment' }],
          ],
        },
        {
          day: 3,
          channel: 'SMS',
          body: `${siteConfig.name.fa}: فرصت تخفیف ثبت‌نام در حال اتمام! همین الان تماس بگیرید: ${siteConfig.contact.phone}`,
        },
      ],
    },
    {
      name: 'بازگشت کارآموزان غیرفعال',
      description: 'پیگیری کارآموزانی که مدتی فعال نبوده‌اند',
      trigger: 'INACTIVITY',
      triggerConditions: {},
      exitOnReply: true,
      exitOnEnroll: true,
      exitOnStageChange: false,
      steps: [
        {
          day: 0,
          channel: 'SMS',
          body: `{{name}} عزیز، دلتنگتان شدیم! 😊 دوره‌های جدید ${siteConfig.name.fa} منتظر شماست. تماس: ${siteConfig.contact.phone}`,
        },
        {
          day: 3,
          channel: 'EITAA',
          body: `🎓 {{name}} عزیز،\n\nدوره‌های جدید فصل شروع شده! تخفیف ویژه فارغ‌التحصیلان فعال است.\n\nبرای دیدن دوره‌ها عدد ۲ را بفرستید.`,
          keyboardButtons: [
            ['۲. لیست دوره‌ها'],
            ['۳. ارتباط با مشاور'],
          ],
        },
      ],
    },
    {
      name: 'یادآوری پرداخت سررسیدشده',
      description: 'پیگیری پرداخت‌های معوقه',
      trigger: 'PAYMENT_OVERDUE',
      triggerConditions: {},
      exitOnReply: true,
      exitOnEnroll: true,
      exitOnStageChange: false,
      steps: [
        {
          day: 0,
          channel: 'SMS',
          body: `{{name}} عزیز، قسط دوره شما سررسید شده است. لطفاً برای جلوگیری از تعلق جریمه، پرداخت نمایید. تماس: ${siteConfig.contact.phone}`,
        },
        {
          day: 2,
          channel: 'EITAA',
          body: `⚠️ {{name}} عزیز،\n\nیادآوری: قسط دوره شما هنوز پرداخت نشده است.\n\nبرای هماهنگی عدد ۳ را بفرستید.`,
          keyboardButtons: [
            ['۳. ارتباط با مشاور مالی'],
          ],
        },
      ],
    },
  ];

  for (const drip of defaults) {
    await db.dripCampaign.create({
      data: {
        name: drip.name,
        description: drip.description,
        trigger: drip.trigger,
        triggerConditions: drip.triggerConditions,
        targetSegment: (drip as any).targetSegment || '',
        targetCluster: (drip as any).targetCluster || '',
        targetPersona: (drip as any).targetPersona || '',
        exitOnReply: drip.exitOnReply,
        exitOnEnroll: drip.exitOnEnroll,
        exitOnStageChange: drip.exitOnStageChange,
        steps: drip.steps,
        status: 'ACTIVE',
        isActive: true,
      },
    });
  }

  console.log('[Drip] Default drip campaigns seeded');
}
