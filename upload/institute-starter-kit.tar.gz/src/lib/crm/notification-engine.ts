/**
 * موتور نوتیفیکیشن بهان رایانه
 * ملی‌پیامک (REST) + واتساپ از طریق n8n
 *
 * وابستگی‌های خارجی: هیچ (فقط fetch داخلی Node.js 18+)
 * متغیرهای env مورد نیاز:
 *   MELIPAYAMAK_USERNAME    نام کاربری پنل ملی‌پیامک
 *   MELIPAYAMAK_PASSWORD    رمز عبور پنل ملی‌پیامک
 *   MELIPAYAMAK_FROM        شماره خط اختصاصی (مثلاً 50002710...)
 *   N8N_CRM_WORKFLOW_URL    آدرس webhook اتوماسیون n8n
 *   N8N_SECRET              کلید امنیتی header برای احراز هویت n8n
 */

// ─── Types ────────────────────────────────────────────────────────────────────

export type AutomationEvent =
  | "LEAD_CREATED"
  | "ENROLLMENT_SUCCESS"
  | "PAYMENT_OVERDUE"
  | "CLASS_REMINDER"
  | "CERTIFICATE_READY"
  | "ALUMNI_RETARGET";

export interface AutomationPayload {
  studentName: string;
  phone: string;                // فرمت: 09xxxxxxxxx
  courseTitle?: string;
  amount?: number;
  dueDate?: string;             // ISO 8601
  certificateUrl?: string;
  advisorPhone?: string;        // شماره مشاور برای اطلاع‌رسانی موازی
  meta?: Record<string, string>; // داده‌های اضافه برای n8n
}

interface AutomationResult {
  sms: "sent" | "failed" | "skipped";
  whatsapp: "sent" | "failed" | "skipped";
  errors: string[];
}

// ─── Pattern IDs ملی‌پیامک ───────────────────────────────────────────────────
// این IDها را از پنل ملی‌پیامک > پیامک‌های الگو دریافت کنید
// الگوها از siteConfig.smsPatterns خوانده می‌شوند

import { siteConfig } from '@/config/site';

const PATTERN_IDS: Record<AutomationEvent, { student: string; advisor?: string }> = {
  LEAD_CREATED:        siteConfig.smsPatterns.LEAD_CREATED        as { student: string; advisor?: string },
  ENROLLMENT_SUCCESS:  siteConfig.smsPatterns.ENROLLMENT_SUCCESS  as { student: string; advisor?: string },
  PAYMENT_OVERDUE:     siteConfig.smsPatterns.PAYMENT_OVERDUE     as { student: string; advisor?: string },
  CLASS_REMINDER:      siteConfig.smsPatterns.CLASS_REMINDER      as { student: string; advisor?: string },
  CERTIFICATE_READY:   siteConfig.smsPatterns.CERTIFICATE_READY   as { student: string; advisor?: string },
  ALUMNI_RETARGET:     siteConfig.smsPatterns.ALUMNI_RETARGET     as { student: string; advisor?: string },
};

// ─── Env Validation ───────────────────────────────────────────────────────────

function requireEnv(key: string): string {
  const val = process.env[key];
  if (!val || val.trim() === "") {
    throw new Error(
      `[Automation] متغیر محیطی "${key}" تنظیم نشده است. ` +
      `فایل .env.local را بررسی کنید.`
    );
  }
  return val.trim();
}

function optionalEnv(key: string): string | undefined {
  const val = process.env[key];
  return val?.trim() || undefined;
}

/** Check if SMS is configured (without throwing) */
function isSmsConfigured(): boolean {
  return !!(
    process.env.MELIPAYAMAK_USERNAME?.trim() &&
    process.env.MELIPAYAMAK_PASSWORD?.trim() &&
    process.env.MELIPAYAMAK_FROM?.trim()
  );
}

/** Check if WhatsApp/n8n is configured (without throwing) */
function isWhatsappConfigured(): boolean {
  return !!process.env.N8N_CRM_WORKFLOW_URL?.trim();
}

// ─── Phone Normalizer ─────────────────────────────────────────────────────────

function normalizePhone(phone: string): string {
  // تبدیل همه فرمت‌های ممکن به 09xxxxxxxxx
  const digits = phone.replace(/\D/g, "");
  if (digits.startsWith("98") && digits.length === 12) return "0" + digits.slice(2);
  if (digits.startsWith("9")  && digits.length === 10) return "0" + digits;
  if (digits.startsWith("09") && digits.length === 11) return digits;
  throw new Error(`[Automation] شماره تلفن نامعتبر: "${phone}"`);
}

// ─── Melipayamak REST Client ──────────────────────────────────────────────────

interface MelipayamakPatternBody {
  username:    string;
  password:    string;
  to:          string;
  from:        string;
  bodyId:      number;   // Pattern ID به صورت عدد صحیح
  args:        string[]; // متغیرهای الگو به ترتیب
}

interface MelipayamakResponse {
  Value:   string;  // کد نتیجه — "0" یعنی موفق
  RetStatus: number;
}

async function sendMelipayamakPattern(
  to: string,
  patternId: string,
  args: string[]
): Promise<void> {
  const username = requireEnv("MELIPAYAMAK_USERNAME");
  const password = requireEnv("MELIPAYAMAK_PASSWORD");
  const from     = requireEnv("MELIPAYAMAK_FROM");

  const bodyId = parseInt(patternId, 10);
  if (isNaN(bodyId)) {
    throw new Error(`[SMS] Pattern ID نامعتبر است: "${patternId}"`);
  }

  const body: MelipayamakPatternBody = {
    username,
    password,
    to:     normalizePhone(to),
    from,
    bodyId,
    args,
  };

  const response = await fetch(
    "https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber",
    {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(body),
      signal:  AbortSignal.timeout(8_000), // timeout 8 ثانیه
    }
  );

  if (!response.ok) {
    throw new Error(
      `[SMS] HTTP ${response.status} از ملی‌پیامک — ${response.statusText}`
    );
  }

  const result: MelipayamakResponse = await response.json();

  // کدهای خطای ملی‌پیامک: هر چیزی غیر از "0" خطاست
  if (result.Value !== "0" && result.RetStatus !== 1) {
    throw new Error(
      `[SMS] ملی‌پیامک خطا برگرداند — Value: ${result.Value}, RetStatus: ${result.RetStatus}`
    );
  }
}

// ─── Pattern Args Builder ─────────────────────────────────────────────────────
// ترتیب args باید دقیقاً با ترتیب متغیرهای الگو در پنل ملی‌پیامک مطابقت داشته باشد

function buildPatternArgs(event: AutomationEvent, payload: AutomationPayload): string[] {
  const amount = payload.amount
    ? new Intl.NumberFormat("fa-IR").format(payload.amount) + " تومان"
    : "";
  const dueDate = payload.dueDate
    ? new Date(payload.dueDate).toLocaleDateString("fa-IR")
    : "";

  switch (event) {
    case "LEAD_CREATED":
      // الگو: «سلام {نام}، درخواست مشاوره برای دوره {دوره} ثبت شد. به زودی تماس می‌گیریم.»
      return [payload.studentName, payload.courseTitle ?? "رایانه"];

    case "ENROLLMENT_SUCCESS":
      // الگو: «{نام} عزیز، ثبت‌نام شما در دوره {دوره} با موفقیت انجام شد.»
      return [payload.studentName, payload.courseTitle ?? ""];

    case "PAYMENT_OVERDUE":
      // الگو: «{نام} عزیز، قسط {مبلغ} شما تا تاریخ {تاریخ} پرداخت نشده است.»
      return [payload.studentName, amount, dueDate];

    case "CLASS_REMINDER":
      // الگو: «{نام} عزیز، فردا کلاس {دوره} دارید. منتظریم!»
      return [payload.studentName, payload.courseTitle ?? ""];

    case "CERTIFICATE_READY":
      // الگو: «{نام} عزیز، گواهینامه دوره {دوره} آماده است.»
      return [payload.studentName, payload.courseTitle ?? ""];

    case "ALUMNI_RETARGET":
      // الگو: «{نام} عزیز، ${siteConfig.alumniRetargetMessage}»
      return [payload.studentName];

    default:
      return [payload.studentName];
  }
}

function buildAdvisorArgs(event: AutomationEvent, payload: AutomationPayload): string[] {
  switch (event) {
    case "LEAD_CREATED":
      // الگو: «لید جدید: {نام} — دوره: {دوره} — شماره: {تلفن}»
      return [payload.studentName, payload.courseTitle ?? "نامشخص", normalizePhone(payload.phone)];

    case "ENROLLMENT_SUCCESS":
      // الگو: «ثبت‌نام قطعی شد: {نام} — دوره: {دوره}»
      return [payload.studentName, payload.courseTitle ?? ""];

    default:
      return [payload.studentName];
  }
}

// ─── n8n WhatsApp Trigger ─────────────────────────────────────────────────────

async function triggerN8nWhatsapp(
  event: AutomationEvent,
  payload: AutomationPayload
): Promise<void> {
  const webhookUrl = requireEnv("N8N_CRM_WORKFLOW_URL");
  const secret     = optionalEnv("N8N_SECRET");

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };

  // احراز هویت ساده با header — در n8n روی Webhook node فعال کنید
  if (secret) {
    headers[siteConfig.n8nSecretHeader] = secret;
  }

  const n8nBody = {
    event,
    timestamp:   new Date().toISOString(),
    student: {
      name:   payload.studentName,
      phone:  normalizePhone(payload.phone),
    },
    course:      payload.courseTitle  ?? null,
    amount:      payload.amount       ?? null,
    dueDate:     payload.dueDate      ?? null,
    certUrl:     payload.certificateUrl ?? null,
    advisorPhone: payload.advisorPhone
      ? normalizePhone(payload.advisorPhone)
      : null,
    meta:        payload.meta ?? {},
  };

  const response = await fetch(webhookUrl, {
    method:  "POST",
    headers,
    body:    JSON.stringify(n8nBody),
    signal:  AbortSignal.timeout(10_000),
  });

  if (!response.ok) {
    throw new Error(
      `[WhatsApp/n8n] HTTP ${response.status} — ${response.statusText}`
    );
  }
}

// ─── Dead-Letter Logger ───────────────────────────────────────────────────────
// رویدادهای ناموفق را در console ساختاریافته لاگ می‌کند
// در فاز بعدی: ذخیره در جدول AutomationFailureLog پریزما

function logFailure(
  channel: "sms" | "whatsapp",
  event: AutomationEvent,
  phone: string,
  error: unknown
): void {
  const message = error instanceof Error ? error.message : String(error);
  console.error(
    JSON.stringify({
      level:     "ERROR",
      channel,
      event,
      phone,
      message,
      timestamp: new Date().toISOString(),
      action:    "REQUIRES_MANUAL_RETRY",
    })
  );
}

// ─── Main Trigger Function ────────────────────────────────────────────────────

/**
 * نقطه ورود اصلی — هر دو کانال را به صورت موازی اجرا می‌کند
 * خرابی هر کانال مانع ارسال کانال دیگر نمی‌شود
 */
export async function triggerWorkflow(
  event: AutomationEvent,
  payload: AutomationPayload
): Promise<AutomationResult> {
  const result: AutomationResult = {
    sms:       "skipped",
    whatsapp:  "skipped",
    errors:    [],
  };

  const patterns = PATTERN_IDS[event];

  // ── SMS (ملی‌پیامک) ──────────────────────────────────────────────────────
  const smsTask = (async () => {
    if (!isSmsConfigured()) {
      result.sms = "skipped";
      return;
    }

    try {
      // پیامک به دانش‌آموز
      await sendMelipayamakPattern(
        payload.phone,
        patterns.student,
        buildPatternArgs(event, payload)
      );

      // پیامک موازی به مشاور (اگر pattern و شماره موجود باشد)
      if (patterns.advisor && payload.advisorPhone) {
        await sendMelipayamakPattern(
          payload.advisorPhone,
          patterns.advisor,
          buildAdvisorArgs(event, payload)
        ).catch((err) => {
          // خرابی پیامک مشاور کل فرایند را متوقف نمی‌کند
          logFailure("sms", event, payload.advisorPhone!, err);
        });
      }

      result.sms = "sent";
    } catch (err) {
      result.sms = "failed";
      const msg = err instanceof Error ? err.message : String(err);
      result.errors.push(`SMS: ${msg}`);
      logFailure("sms", event, payload.phone, err);
    }
  })();

  // ── WhatsApp (n8n) ───────────────────────────────────────────────────────
  const waTask = (async () => {
    if (!isWhatsappConfigured()) {
      result.whatsapp = "skipped";
      return;
    }

    try {
      await triggerN8nWhatsapp(event, payload);
      result.whatsapp = "sent";
    } catch (err) {
      result.whatsapp = "failed";
      const msg = err instanceof Error ? err.message : String(err);
      result.errors.push(`WhatsApp: ${msg}`);
      logFailure("whatsapp", event, payload.phone, err);
    }
  })();

  // اجرای موازی — هر دو کانال همزمان شروع می‌شوند
  await Promise.allSettled([smsTask, waTask]);

  return result;
}

// ─── Convenience Wrappers ─────────────────────────────────────────────────────
// برای استفاده مستقیم در API routes بدون نیاز به ساختن payload کامل

export const notify = {
  leadCreated: (name: string, phone: string, course: string, advisorPhone?: string) =>
    triggerWorkflow("LEAD_CREATED", { studentName: name, phone, courseTitle: course, advisorPhone }),

  enrolled: (name: string, phone: string, course: string, advisorPhone?: string) =>
    triggerWorkflow("ENROLLMENT_SUCCESS", { studentName: name, phone, courseTitle: course, advisorPhone }),

  paymentOverdue: (name: string, phone: string, amount: number, dueDate: string) =>
    triggerWorkflow("PAYMENT_OVERDUE", { studentName: name, phone, amount, dueDate }),

  classReminder: (name: string, phone: string, course: string) =>
    triggerWorkflow("CLASS_REMINDER", { studentName: name, phone, courseTitle: course }),

  certificateReady: (name: string, phone: string, course: string, certUrl: string) =>
    triggerWorkflow("CERTIFICATE_READY", { studentName: name, phone, courseTitle: course, certificateUrl: certUrl }),

  alumniRetarget: (name: string, phone: string) =>
    triggerWorkflow("ALUMNI_RETARGET", { studentName: name, phone }),
};
