/**
 * سرویس پیام‌رسانی یکپارچه — بهان رایانه
 * یک واسط واحد برای ارسال پیام به همه کانال‌ها:
 *   SMS (ملی‌پیامک) | WhatsApp (n8n) | Eitaa | Baleh | Email (SMTP)
 *
 * همچنین پردازش پیام‌های دریافتی (INBOUND) از وب‌هوک‌ها
 *
 * وابستگی‌ها:
 *   - @/lib/crm/notification-engine (SMS + WhatsApp)
 *   - @/lib/crm/email-engine (Email)
 *   - @/lib/crm/eitaa-client (Eitaa)
 *   - @/lib/crm/baleh-client (Baleh)
 *   - @/lib/db (Prisma)
 */

import { db } from '@/lib/db';
import { notify } from './notification-engine';
import { sendEmail } from './email-engine';
import { eitaa, isEitaaConfigured } from './eitaa-client';
import { baleh, isBalehConfigured } from './baleh-client';
import { siteConfig } from '@/config/site';

// ─── Types ────────────────────────────────────────────────────────────────────

export type MessagingChannel = 'SMS' | 'WHATSAPP' | 'EITAA' | 'BALEH' | 'EMAIL' | 'TELEGRAM';

export interface UnifiedMessageOptions {
  /** کانال ارسال */
  channel: MessagingChannel;
  /** شناسه گیرنده — شماره تلفن، chat_id یا ایمیل */
  recipient: string;
  /** متن پیام */
  content: string;
  /** موضوع (برای ایمیل) */
  subject?: string;
  /** URL فایل/تصویر */
  mediaUrl?: string;
  /** نوع فایل */
  mediaType?: 'IMAGE' | 'VIDEO' | 'DOCUMENT' | 'AUDIO';
  /** شناسه لید */
  leadId?: string;
  /** شناسه کارآموز */
  karAmuzId?: string;
  /** شناسه کمپین */
  campaignId?: string;
  /** شناسه drip step */
  dripStepId?: string;
  /** کلیدواژه‌های کیبورد (برای ایتا و بله) */
  keyboardButtons?: string[][];
  /** دکمه‌های شیشه‌ای */
  inlineButtons?: Array<{ text: string; callbackData: string }[]>;
  /** داده‌های اضافه */
  metadata?: Record<string, unknown>;
  /** نام گیرنده (برای شخصی‌سازی) */
  recipientName?: string;
}

export interface UnifiedMessageResult {
  success: boolean;
  channel: MessagingChannel;
  messageLogId: string;
  externalId?: string;
  error?: string;
}

export interface InboundMessage {
  channel: MessagingChannel;
  senderId: string;          // شماره تلفن یا chat_id
  senderName?: string;
  content: string;
  externalId?: string;
  contact?: {
    phone?: string;
    firstName?: string;
    lastName?: string;
    username?: string;
  };
  location?: {
    latitude: number;
    longitude: number;
  };
  callbackData?: string;     // برای دکمه‌های شیشه‌ای
  metadata?: Record<string, unknown>;
}

// ─── Phone Normalizer ─────────────────────────────────────────────────────────

function normalizePhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.startsWith('98') && digits.length === 12) return '0' + digits.slice(2);
  if (digits.startsWith('9') && digits.length === 10) return '0' + digits;
  if (digits.startsWith('09') && digits.length === 11) return digits;
  return phone;
}

// ─── Log Helper ───────────────────────────────────────────────────────────────

async function logMessage(params: {
  channel: string;
  direction: string;
  content: string;
  subject?: string;
  mediaUrl?: string;
  mediaType?: string;
  recipientId?: string;
  senderId?: string;
  leadId?: string;
  karAmuzId?: string;
  campaignId?: string;
  dripStepId?: string;
  status: string;
  externalId?: string;
  errorMessage?: string;
  metadata?: Record<string, unknown>;
}): Promise<string> {
  const log = await db.messageLog.create({
    data: {
      channel: params.channel,
      direction: params.direction,
      content: params.content,
      subject: params.subject || null,
      mediaUrl: params.mediaUrl || null,
      mediaType: params.mediaType || null,
      recipientId: params.recipientId || null,
      senderId: params.senderId || null,
      leadId: params.leadId || null,
      karAmuzId: params.karAmuzId || null,
      campaignId: params.campaignId || null,
      dripStepId: params.dripStepId || null,
      status: params.status,
      externalId: params.externalId || null,
      errorMessage: params.errorMessage || null,
      metadata: params.metadata || null,
      sentAt: params.status === 'SENT' ? new Date() : null,
    },
  });
  return log.id;
}

// ─── sendUnifiedMessage ──────────────────────────────────────────────────────

/**
 * ارسال پیام از طریق کانال مشخص‌شده
 * همه کانال‌ها از یک واسط استفاده می‌کنند و لاگ یکسان دارند
 */
export async function sendUnifiedMessage(
  options: UnifiedMessageOptions
): Promise<UnifiedMessageResult> {
  const { channel, recipient, content } = options;

  try {
    let externalId: string | undefined;
    let sent = false;

    switch (channel) {
      case 'SMS': {
        // ارسال SMS از طریق ملی‌پیامک
        const phone = normalizePhone(recipient);
        await notify.leadCreated(
          options.recipientName || 'مشتری',
          phone,
          options.subject || ''
        );
        sent = true;
        break;
      }

      case 'WHATSAPP': {
        // ارسال واتساپ از طریق n8n
        const phone = normalizePhone(recipient);
        await notify.leadCreated(
          options.recipientName || 'مشتری',
          phone,
          options.subject || ''
        );
        sent = true;
        break;
      }

      case 'EITAA': {
        if (!isEitaaConfigured()) {
          const logId = await logMessage({
            channel: 'EITAA', direction: 'OUTBOUND', content,
            recipientId: recipient, leadId: options.leadId,
            karAmuzId: options.karAmuzId, campaignId: options.campaignId,
            dripStepId: options.dripStepId, status: 'FAILED',
            errorMessage: 'Eitaa bot not configured',
            metadata: options.metadata,
          });
          return { success: false, channel: 'EITAA', messageLogId: logId, error: 'Eitaa not configured' };
        }

        if (options.inlineButtons) {
          const result = await eitaa.sendWithInlineKeyboard(recipient, content, options.inlineButtons);
          externalId = result?.result?.message_id?.toString();
        } else if (options.keyboardButtons) {
          const result = await eitaa.sendWithKeyboard(recipient, content, options.keyboardButtons);
          externalId = result?.result?.message_id?.toString();
        } else if (options.mediaUrl) {
          const result = await eitaa.sendPhoto(recipient, options.mediaUrl, content);
          externalId = result?.result?.message_id?.toString();
        } else {
          const result = await eitaa.sendText(recipient, content);
          externalId = result?.result?.message_id?.toString();
        }
        sent = true;
        break;
      }

      case 'BALEH': {
        if (!isBalehConfigured()) {
          const logId = await logMessage({
            channel: 'BALEH', direction: 'OUTBOUND', content,
            recipientId: recipient, leadId: options.leadId,
            karAmuzId: options.karAmuzId, campaignId: options.campaignId,
            dripStepId: options.dripStepId, status: 'FAILED',
            errorMessage: 'Baleh bot not configured',
            metadata: options.metadata,
          });
          return { success: false, channel: 'BALEH', messageLogId: logId, error: 'Baleh not configured' };
        }

        if (options.inlineButtons) {
          const result = await baleh.sendWithInlineKeyboard(recipient, content, options.inlineButtons);
          externalId = result?.result?.message_id?.toString();
        } else if (options.keyboardButtons) {
          const result = await baleh.sendWithKeyboard(recipient, content, options.keyboardButtons);
          externalId = result?.result?.message_id?.toString();
        } else if (options.mediaUrl) {
          const result = await baleh.sendPhoto(recipient, options.mediaUrl, content);
          externalId = result?.result?.message_id?.toString();
        } else {
          const result = await baleh.sendText(recipient, content);
          externalId = result?.result?.message_id?.toString();
        }
        sent = true;
        break;
      }

      case 'EMAIL': {
        const emailResult = await sendEmail({
          to: recipient,
          subject: options.subject || siteConfig.name.fa,
          body: content,
          leadId: options.leadId,
          karAmuzId: options.karAmuzId,
          campaignId: options.campaignId,
        });
        sent = emailResult.success;
        externalId = emailResult.messageId;
        break;
      }

      case 'TELEGRAM': {
        // تلگرام از طریق n8n — مشابه واتساپ
        await notify.leadCreated(
          options.recipientName || 'مشتری',
          normalizePhone(recipient),
          options.subject || ''
        );
        sent = true;
        break;
      }

      default:
        throw new Error(`Unknown channel: ${channel}`);
    }

    // لاگ موفق
    const logId = await logMessage({
      channel, direction: 'OUTBOUND', content,
      subject: options.subject,
      mediaUrl: options.mediaUrl,
      mediaType: options.mediaType,
      recipientId: recipient,
      leadId: options.leadId,
      karAmuzId: options.karAmuzId,
      campaignId: options.campaignId,
      dripStepId: options.dripStepId,
      status: sent ? 'SENT' : 'QUEUED',
      externalId,
      metadata: options.metadata,
    });

    return { success: true, channel, messageLogId: logId, externalId };

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`[UnifiedMessaging] Error sending to ${channel}:`, errorMessage);

    const logId = await logMessage({
      channel, direction: 'OUTBOUND', content,
      subject: options.subject,
      mediaUrl: options.mediaUrl,
      mediaType: options.mediaType,
      recipientId: recipient,
      leadId: options.leadId,
      karAmuzId: options.karAmuzId,
      campaignId: options.campaignId,
      dripStepId: options.dripStepId,
      status: 'FAILED',
      errorMessage,
      metadata: options.metadata,
    });

    return { success: false, channel, messageLogId: logId, error: errorMessage };
  }
}

// ─── processInboundMessage ────────────────────────────────────────────────────

/**
 * پردازش پیام دریافتی از هر پیام‌رسان
 * ۱. ثبت پیام در MessageLog
 * ۲. یافتن یا ایجاد MessengerContact
 * ۳. یافتن یا ایجاد Lead
 * ۴. بررسی drip campaign برای exit
 * ۵. پاسخ خودکار (در صورت فعال بودن)
 * ۶. ایجاد Conversation و پیام
 */
export async function processInboundMessage(
  message: InboundMessage
): Promise<{
  contactId: string;
  leadId?: string;
  conversationId?: string;
  autoReplied: boolean;
}> {
  // ۱. ثبت پیام دریافتی
  const logId = await logMessage({
    channel: message.channel,
    direction: 'INBOUND',
    content: message.content,
    senderId: message.senderId,
    status: 'DELIVERED',
    externalId: message.externalId,
    metadata: message.metadata,
  });

  // ۲. یافتن یا ایجاد MessengerContact
  const existingContact = await db.messengerContact.findUnique({
    where: { channel_chatId: { channel: message.channel, chatId: String(message.senderId) } },
  });

  let contactId: string;
  let leadId: string | undefined = existingContact?.leadId || undefined;

  if (existingContact) {
    contactId = existingContact.id;
    // بروزرسانی آخرین پیام
    await db.messengerContact.update({
      where: { id: contactId },
      data: {
        lastMessageAt: new Date(),
        messageCount: { increment: 1 },
        firstName: message.contact?.firstName || existingContact.firstName,
        lastName: message.contact?.lastName || existingContact.lastName,
      },
    });
  } else {
    // ایجاد contact جدید
    const newContact = await db.messengerContact.create({
      data: {
        channel: message.channel,
        chatId: String(message.senderId),
        username: message.contact?.username || null,
        phone: message.contact?.phone || null,
        firstName: message.contact?.firstName || null,
        lastName: message.contact?.lastName || null,
        lastMessageAt: new Date(),
        messageCount: 1,
      },
    });
    contactId = newContact.id;
  }

  // ۳. یافتن یا ایجاد Lead
  if (!leadId && message.contact?.phone) {
    const phone = normalizePhone(message.contact.phone);
    const existingLead = await db.lead.findFirst({
      where: { phone },
    });
    if (existingLead) {
      leadId = existingLead.id;
      // اتصال contact به lead
      await db.messengerContact.update({
        where: { id: contactId },
        data: { leadId },
      });
    }
  }

  // اگر هنوز lead ندارد، ایجاد لید جدید
  if (!leadId) {
    const newLead = await db.lead.create({
      data: {
        name: message.senderName || message.contact?.firstName || `کاربر ${message.channel}`,
        phone: message.contact?.phone || `${message.channel}:${message.senderId}`,
        source: message.channel.toLowerCase(),
        stage: 'NEW',
        score: 25, // امتیاز اولیه برای تماس از پیام‌رسان
      },
    });
    leadId = newLead.id;
    await db.messengerContact.update({
      where: { id: contactId },
      data: { leadId },
    });
  }

  // ۴. بررسی exit drip campaigns
  if (leadId) {
    const activeDrips = await db.dripEnrollment.findMany({
      where: { leadId, status: 'ACTIVE' },
      include: { dripCampaign: true },
    });

    for (const drip of activeDrips) {
      if (drip.dripCampaign.exitOnReply) {
        await db.dripEnrollment.update({
          where: { id: drip.id },
          data: {
            status: 'EXITED',
            exitedAt: new Date(),
            exitReason: 'REPLY',
          },
        });
      }
    }
  }

  // ۵. بروزرسانی MessageLog با leadId
  await db.messageLog.update({
    where: { id: logId },
    data: { leadId },
  });

  // ۶. ایجاد یا به‌روزرسانی Conversation
  let conversationId: string | undefined;

  // یافتن conversation فعال
  const activeConversation = await db.conversation.findFirst({
    where: {
      leadId,
      channel: message.channel,
      status: 'ACTIVE',
    },
    orderBy: { createdAt: 'desc' },
  });

  if (activeConversation) {
    conversationId = activeConversation.id;
    // اضافه کردن پیام جدید
    await db.conversationMessage.create({
      data: {
        conversationId,
        content: message.content,
        speaker: 'CUSTOMER',
        speakerName: message.senderName || message.contact?.firstName || 'مشتری',
        metadata: {
          channel: message.channel,
          senderId: message.senderId,
          callbackData: message.callbackData,
          location: message.location,
        },
      },
    });
  } else {
    // ایجاد conversation جدید
    const newConv = await db.conversation.create({
      data: {
        leadId,
        channel: message.channel,
        subject: message.content.substring(0, 100),
        startedAt: new Date(),
        status: 'ACTIVE',
        messages: {
          create: {
            content: message.content,
            speaker: 'CUSTOMER',
            speakerName: message.senderName || message.contact?.firstName || 'مشتری',
            metadata: {
              channel: message.channel,
              senderId: message.senderId,
              callbackData: message.callbackData,
            },
          },
        },
      },
    });
    conversationId = newConv.id;
  }

  // ۷. بروزرسانی ActivityLog لید
  await db.activityLog.create({
    data: {
      leadId,
      type: message.channel,
      content: `پیام دریافتی از ${message.channel}: ${message.content.substring(0, 200)}`,
    },
  });

  // ۸. بروزرسانی lastContactedAt لید
  await db.lead.update({
    where: { id: leadId },
    data: { lastContactedAt: new Date() },
  });

  // ۹. پاسخ خودکار (Auto-Reply)
  let autoReplied = false;
  const botConfig = await db.messengerBotConfig.findFirst({
    where: { channel: message.channel, isActive: true },
  });

  if (botConfig && message.content) {
    // بررسی دستورات خاص
    const text = message.content.trim().toLowerCase();

    if (text === '/start' || text === 'شروع') {
      // پیام خوش‌آمدگویی
      const welcome = botConfig.welcomeMessage ||
        `سلام! به ${siteConfig.name.fa} خوش آمدید.\n\nچگونه می‌توانیم کمکتان کنیم؟\n\n• مشاوره رایگان: عدد ۱\n• لیست دوره‌ها: عدد ۲\n• ارتباط با مشاور: عدد ۳`;

      await sendUnifiedMessage({
        channel: message.channel as MessagingChannel,
        recipient: String(message.senderId),
        content: welcome,
        leadId,
        keyboardButtons: [
          ['۱. مشاوره رایگان'],
          ['۲. لیست دوره‌ها'],
          ['۳. ارتباط با مشاور'],
        ],
      });
      autoReplied = true;
    } else if (text === '1' || text === '۱' || text.includes('مشاوره')) {
      await sendUnifiedMessage({
        channel: message.channel as MessagingChannel,
        recipient: String(message.senderId),
        content: 'برای دریافت مشاوره رایگان، لطفاً شماره تلفن خود را ارسال کنید یا روی دکمه زیر بزنید:',
        leadId,
        keyboardButtons: [['ارسال شماره تلفن 📱']],
      });
      autoReplied = true;
    } else if (message.contact?.phone) {
      // کاربر شماره تلفن ارسال کرده — ثبت‌نام لید
      const phone = normalizePhone(message.contact.phone);
      await db.lead.update({
        where: { id: leadId },
        data: {
          phone,
          stage: 'CONTACTED',
          score: { increment: 20 },
        },
      });

      await sendUnifiedMessage({
        channel: message.channel as MessagingChannel,
        recipient: String(message.senderId),
        content: `ممنون! شماره تلفن شما ثبت شد. مشاوران ما در اسرع وقت با شما تماس خواهند گرفت.\n\nدر meantime، آیا می‌خواهید لیست دوره‌ها را ببینید؟`,
        leadId,
        keyboardButtons: [
          ['بله، لیست دوره‌ها'],
          ['نه، منتظر تماس می‌مانم'],
        ],
      });
      autoReplied = true;
    } else if (botConfig.enableAiResponse) {
      // پاسخ AI — در فاز بعدی پیاده‌سازی کامل
      const fallback = botConfig.fallbackMessage ||
        'پیام شما دریافت شد. در اسرع وقت پاسخ خواهیم داد. برای مشاوره عدد ۱ را بفرستید.';
      await sendUnifiedMessage({
        channel: message.channel as MessagingChannel,
        recipient: String(message.senderId),
        content: fallback,
        leadId,
      });
      autoReplied = true;
    }
  }

  return { contactId, leadId, conversationId, autoReplied };
}

// ─── sendMultiChannel ─────────────────────────────────────────────────────────

/**
 * ارسال یک پیام به چند کانال همزمان
 * مثلاً: ارسال پیام خوش‌آمدگویی هم به SMS و هم به Eitaa
 */
export async function sendMultiChannel(
  options: Omit<UnifiedMessageOptions, 'channel'> & {
    channels: MessagingChannel[];
  }
): Promise<UnifiedMessageResult[]> {
  const results: UnifiedMessageResult[] = [];

  for (const channel of options.channels) {
    const result = await sendUnifiedMessage({
      ...options,
      channel,
    });
    results.push(result);

    // فاصله ۱۰۰ms بین هر ارسال
    if (options.channels.indexOf(channel) < options.channels.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  return results;
}

// ─── getMessageStats ──────────────────────────────────────────────────────────

/**
 * دریافت آمار پیام‌ها
 */
export async function getMessageStats(
  startDate?: Date,
  endDate?: Date
): Promise<{
  totalSent: number;
  totalReceived: number;
  byChannel: Record<string, { sent: number; received: number }>;
  deliveryRate: number;
}> {
  const where: Record<string, unknown> = {};
  if (startDate || endDate) {
    where.createdAt = {
      ...(startDate && { gte: startDate }),
      ...(endDate && { lte: endDate }),
    };
  }

  const [sent, received] = await Promise.all([
    db.messageLog.count({ where: { ...where, direction: 'OUTBOUND', status: 'SENT' } }),
    db.messageLog.count({ where: { ...where, direction: 'INBOUND' } }),
  ]);

  const totalAttempted = await db.messageLog.count({
    where: { ...where, direction: 'OUTBOUND' },
  });

  // آمار به تفکیک کانال
  const channels: MessagingChannel[] = ['SMS', 'WHATSAPP', 'EITAA', 'BALEH', 'EMAIL', 'TELEGRAM'];
  const byChannel: Record<string, { sent: number; received: number }> = {};

  for (const channel of channels) {
    const [sentCh, receivedCh] = await Promise.all([
      db.messageLog.count({ where: { ...where, channel, direction: 'OUTBOUND', status: 'SENT' } }),
      db.messageLog.count({ where: { ...where, channel, direction: 'INBOUND' } }),
    ]);
    if (sentCh > 0 || receivedCh > 0) {
      byChannel[channel] = { sent: sentCh, received: receivedCh };
    }
  }

  return {
    totalSent: sent,
    totalReceived: received,
    byChannel,
    deliveryRate: totalAttempted > 0 ? Math.round((sent / totalAttempted) * 100) : 0,
  };
}
