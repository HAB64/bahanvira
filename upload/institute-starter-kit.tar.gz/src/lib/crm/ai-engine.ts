/**
 * موتور هوش مصنوعی بهان رایانه
 * یکپارچه‌سازی z-ai-web-dev-sdk برای تحلیل CRM
 *
 * قابلیت‌ها:
 *   - پیشنهاد پاسخ مکالمه
 *   - خلاصه‌سازی مکالمه
 *   - پیش‌بینی ریسک ریزش
 *   - پیشنهاد فروش افزایشی (Upsell)
 *
 * مهم: این فایل فقط سمت سرور استفاده می‌شود
 * z-ai-web-dev-sdk هرگز نباید در client-side import شود
 */

import { db } from '@/lib/db';
import { siteConfig } from '@/config/site';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ConversationMessage {
  role: string;       // 'customer' | 'agent' | 'system'
  content: string;
}

export interface ResponseSuggestion {
  suggestion: string;
  confidence: number; // 0-1
  tone: 'formal' | 'friendly' | 'urgent';
}

export interface ConversationSummary {
  summary: string;
  keyTopics: string[];
  sentiment: 'POSITIVE' | 'NEUTRAL' | 'NEGATIVE' | 'MIXED';
  actionItems: string[];
}

export type ChurnRiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface ChurnPrediction {
  riskLevel: ChurnRiskLevel;
  riskScore: number;        // 0-100
  reasoning: string[];
  recommendedActions: string[];
}

export interface UpsellSuggestion {
  suggestedCourses: Array<{
    name: string;
    reason: string;
    confidence: number;     // 0-1
  }>;
  overallStrategy: string;
}

// ─── ZAI SDK Helper ───────────────────────────────────────────────────────────

/**
 * نمونه ZAI — بارگذاری تنبل (lazy) برای جلوگیری از import در client
 */
async function getZAI() {
  const ZAI = (await import('z-ai-web-dev-sdk')).default;
  return ZAI.create();
}

/**
 * فراخوانی chat completion با مدیریت خطا
 */
async function chatCompletion(
  systemPrompt: string,
  userPrompt: string,
  options?: { temperature?: number; maxTokens?: number }
): Promise<string | null> {
  try {
    const zai = await getZAI();

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      temperature: options?.temperature ?? 0.4,
      // max_tokens is passed through the body
      ...(options?.maxTokens ? { max_tokens: options.maxTokens } : {}),
    });

    return completion.choices?.[0]?.message?.content || null;
  } catch (error) {
    console.error(
      JSON.stringify({
        level: 'ERROR',
        module: 'ai-engine',
        action: 'chatCompletion',
        message: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
      })
    );
    return null;
  }
}

// ─── System Prompts ───────────────────────────────────────────────────────────

const SALES_ASSISTANT_PROMPT = `You are a helpful sales assistant for ${siteConfig.name.en} (${siteConfig.name.fa}), ${siteConfig.institute.typeEn} in ${siteConfig.contact.address.cityEn}, ${siteConfig.contact.address.countryEn}. Help craft professional responses in Persian (Farsi).

Guidelines:
- Always respond in Persian (Farsi)
- Be polite, professional, and culturally appropriate
- Address customers warmly (استفاده از لحن محترمانه و صمیمی)
- Reference relevant courses when appropriate
- Keep responses concise but informative
- If the customer seems interested, suggest next steps (booking a consultation, visiting the institute)
- Institute phone: ${siteConfig.contact.phone}
- Institute location: ${siteConfig.contact.address.short}

The institute offers ${siteConfig.categories.length} competency clusters:
${siteConfig.categories.map((c, i) => `${i + 1}. ${c.labelFa} (${c.labelEn}) — ${c.courses}`).join('\n')}`;

const SUMMARY_PROMPT = `You are an AI assistant analyzing customer conversations for ${siteConfig.name.en} CRM.
Analyze the conversation and provide a structured JSON response with these fields:
{
  "summary": "A concise summary of the conversation in Persian",
  "keyTopics": ["topic1", "topic2"],
  "sentiment": "POSITIVE | NEUTRAL | NEGATIVE | MIXED",
  "actionItems": ["action1", "action2"]
}
Respond ONLY with valid JSON. No markdown fences.`;

const CHURN_PREDICTION_PROMPT = `You are an AI analyst for ${siteConfig.name.en}, ${siteConfig.institute.typeEn}.
Analyze the lead/student data and predict churn risk.

Return a JSON response:
{
  "riskLevel": "LOW | MEDIUM | HIGH | CRITICAL",
  "riskScore": 0-100,
  "reasoning": ["reason1", "reason2"],
  "recommendedActions": ["action1", "action2"]
}

Risk indicators:
- Days since last contact > 14: elevated risk
- No payments or overdue payments: HIGH risk
- Low engagement (few activities): MEDIUM risk
- Stage stuck in NEW/CONTACTED for > 30 days: HIGH risk
- Negative sentiment in conversations: elevated risk
- No email provided: slight risk increase

Respond ONLY with valid JSON. No markdown fences.`;

const UPSELL_PROMPT = `You are an AI sales strategist for ${siteConfig.name.en} ${siteConfig.institute.typeFa}.

Analyze the lead/student's current enrollments, cluster, and profile to suggest relevant upsell opportunities.

The ${siteConfig.categories.length} clusters and their courses:
${siteConfig.categories.map(c => `${c.key} (${c.labelFa}): ${c.courses}`).join('\n')}

Cross-cluster suggestions:
- ICDL → Office Management (computer basics → business software)
- Python → AI/ML (programming → advanced AI)
- Web Dev → Digital Marketing (building sites → promoting them)
- Forex → Crypto (related financial instruments)
- Photoshop → Visual Arts (graphic design → broader arts)

Return JSON:
{
  "suggestedCourses": [
    { "name": "Course Name", "reason": "Why this course fits", "confidence": 0.0-1.0 }
  ],
  "overallStrategy": "Brief strategy description in Persian"
}

Respond ONLY with valid JSON. No markdown fences.`;

// ─── JSON Extraction Helper ───────────────────────────────────────────────────

/**
 * استخراج JSON از پاسخ AI — حتی اگر داخل markdown fence باشد
 */
function extractJSON(text: string): string | null {
  // Try direct parse first
  try {
    JSON.parse(text);
    return text;
  } catch {
    // Continue to extraction
  }

  // Try extracting from markdown code fence
  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    try {
      JSON.parse(fenceMatch[1].trim());
      return fenceMatch[1].trim();
    } catch {
      // Continue
    }
  }

  // Try finding JSON object
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      JSON.parse(jsonMatch[0]);
      return jsonMatch[0];
    } catch {
      // Continue
    }
  }

  return null;
}

// ─── generateResponseSuggestion ───────────────────────────────────────────────

/**
 * پیشنهاد پاسخ برای مکالمه فروش
 * از z-ai-web-dev-sdk chat completions استفاده می‌کند
 */
export async function generateResponseSuggestion(
  conversationMessages: ConversationMessage[]
): Promise<ResponseSuggestion> {
  const threadSummary = conversationMessages
    .map((m) => `[${m.role}]: ${m.content}`)
    .join('\n');

  const aiResponse = await chatCompletion(
    SALES_ASSISTANT_PROMPT,
    `The following is a conversation thread with a potential student/customer. Suggest the best next response from our sales team.\n\nConversation:\n${threadSummary}\n\nSuggested response:`,
    { temperature: 0.5, maxTokens: 400 }
  );

  if (aiResponse) {
    // Detect tone based on content
    let tone: ResponseSuggestion['tone'] = 'formal';
    if (aiResponse.includes('فوری') || aiResponse.includes('فرصت') || aiResponse.includes('آخرین')) {
      tone = 'urgent';
    } else if (aiResponse.includes('عزیز') || aiResponse.includes('دوست') || aiResponse.includes('😊')) {
      tone = 'friendly';
    }

    return {
      suggestion: aiResponse,
      confidence: 0.8,
      tone,
    };
  }

  // Fallback: generic professional response
  return {
    suggestion:
      `با سلام و احترام،\n\nاز تماس شما سپاسگزاریم. برای ارائه مشاوره بهتر، لطفاً دوره مورد علاقه خود را مشخص کنید تا اطلاعات کامل‌تری در اختیارتان قرار دهیم.\n\nبا تشکر\n${siteConfig.name.fa}`,
    confidence: 0.3,
    tone: 'formal',
  };
}

// ─── summarizeConversation ────────────────────────────────────────────────────

/**
 * خلاصه‌سازی مکالمه با تحلیل احساسات و موضوعات کلیدی
 */
export async function summarizeConversation(
  messages: ConversationMessage[]
): Promise<ConversationSummary> {
  const threadContent = messages
    .map((m) => `[${m.role}]: ${m.content}`)
    .join('\n');

  const aiResponse = await chatCompletion(
    SUMMARY_PROMPT,
    `Analyze this conversation:\n\n${threadContent}`,
    { temperature: 0.2, maxTokens: 500 }
  );

  if (aiResponse) {
    const jsonStr = extractJSON(aiResponse);
    if (jsonStr) {
      try {
        const parsed = JSON.parse(jsonStr);
        return {
          summary: parsed.summary || '',
          keyTopics: Array.isArray(parsed.keyTopics) ? parsed.keyTopics : [],
          sentiment: ['POSITIVE', 'NEUTRAL', 'NEGATIVE', 'MIXED'].includes(parsed.sentiment)
            ? parsed.sentiment
            : 'NEUTRAL',
          actionItems: Array.isArray(parsed.actionItems) ? parsed.actionItems : [],
        };
      } catch {
        // Fall through to rule-based fallback
      }
    }
  }

  // Fallback: rule-based summary
  const customerMessages = messages.filter((m) => m.role === 'customer' || m.role === 'CUSTOMER');
  const allText = messages.map((m) => m.content).join(' ');

  // Simple sentiment analysis
  const positiveWords = ['ممنون', 'عالی', 'خوب', 'بله', 'مشکلی', 'راضی', 'خوشحال'];
  const negativeWords = ['ناراضی', 'بد', 'مشکل', 'شکایت', 'غلط', 'کند', 'دیر'];
  let posCount = 0;
  let negCount = 0;
  for (const w of positiveWords) {
    if (allText.includes(w)) posCount++;
  }
  for (const w of negativeWords) {
    if (allText.includes(w)) negCount++;
  }

  let sentiment: ConversationSummary['sentiment'] = 'NEUTRAL';
  if (posCount > negCount + 1) sentiment = 'POSITIVE';
  else if (negCount > posCount + 1) sentiment = 'NEGATIVE';
  else if (posCount > 0 && negCount > 0) sentiment = 'MIXED';

  return {
    summary: `مکالمه با ${customerMessages.length} پیام از مشتری. موضوعات اصلی استخراج نشد (AI در دسترس نیست).`,
    keyTopics: [],
    sentiment,
    actionItems: ['بررسی دستی مکالمه و ثبت خلاصه'],
  };
}

// ─── predictChurnRisk ─────────────────────────────────────────────────────────

/**
 * پیش‌بینی ریسک ریزش مشتری
 * تحلیل بر اساس: روزهای از آخرین تماس، سابقه پرداخت، میزان تعامل
 */
export async function predictChurnRisk(leadData: {
  leadId?: string;
  stage?: string;
  daysSinceLastContact?: number;
  paymentHistory?: Array<{ status: string; amount: number }>;
  activityCount?: number;
  segment?: string;
  satisfactionScore?: number;
  enrollmentProb?: number;
  cluster?: string;
  createdAt?: string;
}): Promise<ChurnPrediction> {
  // Build context for AI
  const contextStr = JSON.stringify(leadData, null, 2);

  const aiResponse = await chatCompletion(
    CHURN_PREDICTION_PROMPT,
    `Analyze this lead/student data for churn risk:\n\n${contextStr}`,
    { temperature: 0.2, maxTokens: 500 }
  );

  if (aiResponse) {
    const jsonStr = extractJSON(aiResponse);
    if (jsonStr) {
      try {
        const parsed = JSON.parse(jsonStr);
        const validLevels: ChurnRiskLevel[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
        return {
          riskLevel: validLevels.includes(parsed.riskLevel) ? parsed.riskLevel : 'MEDIUM',
          riskScore: typeof parsed.riskScore === 'number' ? Math.min(100, Math.max(0, parsed.riskScore)) : 50,
          reasoning: Array.isArray(parsed.reasoning) ? parsed.reasoning : [],
          recommendedActions: Array.isArray(parsed.recommendedActions) ? parsed.recommendedActions : [],
        };
      } catch {
        // Fall through to rule-based fallback
      }
    }
  }

  // Fallback: rule-based churn prediction
  let riskScore = 0;
  const reasoning: string[] = [];
  const recommendedActions: string[] = [];

  // Days since last contact
  const daysSinceContact = leadData.daysSinceLastContact ?? 999;
  if (daysSinceContact > 30) {
    riskScore += 35;
    reasoning.push(`بیش از ۳۰ روز (${daysSinceContact} روز) از آخرین تماس می‌گذرد`);
    recommendedActions.push('فوراً تماس تلفنی بگیرید');
  } else if (daysSinceContact > 14) {
    riskScore += 20;
    reasoning.push(`${daysSinceContact} روز از آخرین تماس گذشته`);
    recommendedActions.push('در ۲۴ ساعت آینده پیگیری کنید');
  } else if (daysSinceContact > 7) {
    riskScore += 10;
    reasoning.push('یک هفته از آخرین تماس گذشته');
  }

  // Payment history
  const payments = leadData.paymentHistory ?? [];
  const overduePayments = payments.filter((p) => p.status === 'OVERDUE');
  const paidPayments = payments.filter((p) => p.status === 'PAID');

  if (overduePayments.length > 0) {
    riskScore += 25;
    reasoning.push(`${overduePayments.length} پرداخت سررسیدشده`);
    recommendedActions.push('یادآوری پرداخت ارسال کنید');
  }

  if (payments.length > 0 && paidPayments.length === 0) {
    riskScore += 20;
    reasoning.push('هیچ پرداخت موفقی ثبت نشده');
  }

  // Activity level
  const activityCount = leadData.activityCount ?? 0;
  if (activityCount < 2) {
    riskScore += 15;
    reasoning.push('تعامل بسیار کم');
    recommendedActions.push('ایجاد فرصت تعامل بیشتر');
  }

  // Stage analysis
  const stage = leadData.stage ?? '';
  if (stage === 'REJECTED') {
    riskScore += 40;
    reasoning.push('لید رد شده');
  } else if (stage === 'NEW') {
    riskScore += 10;
    reasoning.push('لید در مرحله جدید');
  }

  // Segment
  const segment = leadData.segment ?? '';
  if (segment === 'AT_RISK') {
    riskScore += 15;
    reasoning.push('لید در بخش در معرض خطر');
  } else if (segment === 'CHURNED') {
    riskScore += 30;
    reasoning.push('لید ریزش‌شده');
  }

  // Satisfaction
  const satisfaction = leadData.satisfactionScore;
  if (satisfaction !== undefined && satisfaction <= 2) {
    riskScore += 20;
    reasoning.push(`امتیاز رضایت پایین: ${satisfaction}/5`);
    recommendedActions.push('بررسی دلیل نارضایتی');
  }

  // Enrollment probability
  const enrollProb = leadData.enrollmentProb;
  if (enrollProb !== undefined && enrollProb < 0.3) {
    riskScore += 10;
    reasoning.push(`احتمال ثبت‌نام پایین: ${(enrollProb * 100).toFixed(0)}%`);
  }

  // Cap score at 100
  riskScore = Math.min(100, riskScore);

  // Determine risk level
  let riskLevel: ChurnRiskLevel;
  if (riskScore >= 75) riskLevel = 'CRITICAL';
  else if (riskScore >= 50) riskLevel = 'HIGH';
  else if (riskScore >= 25) riskLevel = 'MEDIUM';
  else riskLevel = 'LOW';

  if (recommendedActions.length === 0) {
    recommendedActions.push('پیگیری دوره‌ای ادامه یابد');
  }

  return { riskLevel, riskScore, reasoning, recommendedActions };
}

// ─── suggestUpsell ────────────────────────────────────────────────────────────

/**
 * پیشنهاد فروش افزایشی بر اساس ثبت‌نام‌های فعلی و خوشه لید
 */
export async function suggestUpsell(leadId: string): Promise<UpsellSuggestion> {
  // Load lead data with enrollments
  const lead = await db.lead.findUnique({
    where: { id: leadId },
    include: {
      karAmuz: {
        include: {
          enrollments: {
            include: { skillProgram: true },
            where: { status: { in: ['ENROLLED', 'COMPLETED'] } },
          },
        },
      },
      payments: { where: { status: 'PAID' } },
    },
  });

  if (!lead) {
    return {
      suggestedCourses: [],
      overallStrategy: 'لید یافت نشد.',
    };
  }

  const currentCourses = lead.karAmuz?.enrollments.map((e) => e.skillProgram.name) || [];
  const currentCluster = lead.cluster || '';
  const lifetimeValue = lead.lifetimeValue || 0;

  const contextStr = JSON.stringify(
    {
      name: lead.name,
      cluster: currentCluster,
      segment: lead.segment,
      currentCourses,
      lifetimeValue,
      stage: lead.stage,
      satisfactionScore: lead.satisfactionScore,
    },
    null,
    2
  );

  const aiResponse = await chatCompletion(
    UPSELL_PROMPT,
    `Suggest upsell opportunities for this lead/student:\n\n${contextStr}`,
    { temperature: 0.4, maxTokens: 500 }
  );

  if (aiResponse) {
    const jsonStr = extractJSON(aiResponse);
    if (jsonStr) {
      try {
        const parsed = JSON.parse(jsonStr);
        return {
          suggestedCourses: Array.isArray(parsed.suggestedCourses)
            ? parsed.suggestedCourses.map((c: any) => ({
                name: String(c.name || ''),
                reason: String(c.reason || ''),
                confidence: typeof c.confidence === 'number' ? Math.min(1, Math.max(0, c.confidence)) : 0.5,
              }))
            : [],
          overallStrategy: String(parsed.overallStrategy || ''),
        };
      } catch {
        // Fall through to rule-based fallback
      }
    }
  }

  // Fallback: rule-based upsell suggestions
  const suggestions: UpsellSuggestion['suggestedCourses'] = [];

  // Cross-cluster recommendations based on current enrollments
  if (currentCourses.some((c) => c.includes('ICDL') || c.includes('آیسی‌دی‌ال'))) {
    suggestions.push({
      name: 'مدیریت اداری',
      reason: 'پس از یادگیری مهارت‌های کامپیوتری، مدیریت اداری گام بعدی طبیعی است',
      confidence: 0.8,
    });
  }

  if (currentCourses.some((c) => c.includes('Python') || c.includes('پایتون'))) {
    suggestions.push({
      name: 'هوش مصنوعی و یادگیری ماشین',
      reason: 'پایتون پایه‌ای عالی برای ورود به دنیای AI است',
      confidence: 0.85,
    });
  }

  if (currentCourses.some((c) => c.includes('Web') || c.includes('وب'))) {
    suggestions.push({
      name: 'بازاریابی دیجیتال',
      reason: 'ساخت وب‌سایت + بازاریابی دیجیتال = ترکیب کامل',
      confidence: 0.75,
    });
  }

  if (currentCourses.some((c) => c.includes('Forex') || c.includes('فارکس'))) {
    suggestions.push({
      name: 'ارزدیجیتال',
      reason: 'بازار کریپتو مکمل مناسبی برای دانش فارکسی است',
      confidence: 0.7,
    });
  }

  // Cluster-based suggestions (if no specific course matches)
  if (suggestions.length === 0) {
    switch (currentCluster) {
      case 'tech-ai':
        suggestions.push(
          { name: 'برنامه‌نویسی پایتون', reason: 'محبوب‌ترین دوره خوشه فناوری', confidence: 0.6 },
          { name: 'هوش مصنوعی محلی', reason: 'ترند جدید فناوری', confidence: 0.5 }
        );
        break;
      case 'financial':
        suggestions.push(
          { name: 'فارکس', reason: 'پرطرفدارترین دوره مالی', confidence: 0.6 },
          { name: 'ارزدیجیتال', reason: 'بازار در رشد', confidence: 0.55 }
        );
        break;
      case 'management':
        suggestions.push(
          { name: 'کارآفرینی', reason: 'کسب‌وکار خودتان را راه بیندازید', confidence: 0.65 },
          { name: 'بازاریابی دیجیتال', reason: 'مهارت ضروری هر کسب‌وکاری', confidence: 0.6 }
        );
        break;
      default:
        suggestions.push(
          { name: 'ICDL', reason: 'پایه‌ای‌ترین مهارت دیجیتال', confidence: 0.5 }
        );
    }
  }

  // Segment-based strategy
  let strategy = 'بر اساس علاقه‌مندی‌های مشتری، دوره‌های مرتبط پیشنهاد دهید.';
  if (lead.segment === 'VIP') {
    strategy = 'مشتری VIP — دوره‌های پیشرفته و ویژه پیشنهاد دهید. تخفیف ویژه VIP در نظر بگیرید.';
  } else if (lead.segment === 'AT_RISK') {
    strategy = 'مشتری در معرض خطر — ابتدا رضایت‌سنجی کنید، سپس با تخفیف ویژه بازگردانید.';
  } else if (lead.segment === 'LOYAL') {
    strategy = 'مشتری وفادار — از فرصت cross-sell استفاده کنید. دوره‌های مکمل با شرایط ویژه.';
  }

  return {
    suggestedCourses: suggestions,
    overallStrategy: strategy,
  };
}
