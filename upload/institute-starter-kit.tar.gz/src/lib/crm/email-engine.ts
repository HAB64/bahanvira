/**
 * موتور ایمیل بهان رایانه
 * ارسال ایمیل از طریق SMTP (nodemailer) با پشتیبانی از قالب‌ها
 *
 * وابستگی‌ها: nodemailer, @/lib/db (Prisma)
 * متغیرهای env مورد نیاز:
 *   SMTP_HOST      آدرس سرور SMTP (مثلاً smtp.gmail.com)
 *   SMTP_PORT      پورت سرور (مثلاً 587)
 *   SMTP_USER      نام کاربری SMTP
 *   SMTP_PASS      رمز عبور SMTP (App Password برای Gmail)
 *   SMTP_FROM      آدرس فرستنده (مثلاً siteConfig.contact.emailFromFull)
 */

import nodemailer from 'nodemailer';
import { db } from '@/lib/db';
import { siteConfig } from '@/config/site';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface SendEmailOptions {
  to: string | string[];
  subject: string;
  body: string;                       // HTML content
  cc?: string | string[];
  bcc?: string | string[];
  attachments?: Array<{
    filename: string;
    content?: string | Buffer;
    path?: string;                    // مسیر فایل روی دیسک
    contentType?: string;
  }>;
  /** شناسه قالب استفاده‌شده (برای لاگ) */
  templateId?: string;
  /** شناسه لید مرتبط (برای لاگ) */
  leadId?: string;
  /** شناسه کارآموز مرتبط (برای لاگ) */
  karAmuzId?: string;
  /** شناسه کمپین مرتبط (برای لاگ) */
  campaignId?: string;
}

export interface SendEmailResult {
  success: boolean;
  logId: string;
  messageId?: string;
  error?: string;
}

// ─── Env Helpers ──────────────────────────────────────────────────────────────

function optionalEnv(key: string): string | undefined {
  const val = process.env[key];
  return val?.trim() || undefined;
}

/**
 * آیا SMTP پیکربندی شده؟
 * اگر نه، ایمیل‌ها در console لاگ و وضعیت QUEUED می‌گیرند
 */
function isSmtpConfigured(): boolean {
  return !!(
    process.env.SMTP_HOST?.trim() &&
    process.env.SMTP_PORT?.trim() &&
    process.env.SMTP_USER?.trim() &&
    process.env.SMTP_PASS?.trim()
  );
}

// ─── Transport Singleton ──────────────────────────────────────────────────────

let transporter: nodemailer.Transporter | null = null;

function getTransporter(): nodemailer.Transporter {
  if (transporter) return transporter;

  const host = optionalEnv('SMTP_HOST') || 'smtp.gmail.com';
  const port = parseInt(optionalEnv('SMTP_PORT') || '587', 10);
  const user = optionalEnv('SMTP_USER') || '';
  const pass = optionalEnv('SMTP_PASS') || '';

  transporter = nodemailer.createTransport({
    host,
    port,
    secure: port === 465,              // TLS برای پورت 465
    auth: { user, pass },
    // timeout‌ها
    connectionTimeout: 10_000,
    greetingTimeout: 10_000,
    socketTimeout: 15_000,
  });

  return transporter;
}

// ─── Template Variable Replacement ────────────────────────────────────────────

/**
 * جایگزینی متغیرهای قالب — {{name}} → مقدار واقعی
 * پشتیبانی از متغیرهای تودرتو: {{lead.name}} و ساده: {{name}}
 */
export function replaceTemplateVariables(
  template: string,
  variables: Record<string, string | number | boolean>
): string {
  let result = template;

  for (const [key, value] of Object.entries(variables)) {
    // جایگزینی ساده: {{key}}
    const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
    result = result.replace(regex, String(value));
  }

  // حذف متغیرهای جایگذاری‌نشده
  result = result.replace(/\{\{[^}]+\}\}/g, '');

  return result;
}

// ─── Log Helper ───────────────────────────────────────────────────────────────

/**
 * ثبت ایمیل در EmailLog — همیشه فراخوانی می‌شود
 */
async function logEmail(params: {
  to: string;
  subject: string;
  body: string;
  templateId?: string;
  leadId?: string;
  karAmuzId?: string;
  campaignId?: string;
  status: string;
  providerId?: string;
  errorMessage?: string;
  sentAt?: Date;
}): Promise<string> {
  const log = await db.emailLog.create({
    data: {
      to: params.to,
      subject: params.subject,
      body: params.body,
      templateId: params.templateId,
      leadId: params.leadId,
      karAmuzId: params.karAmuzId,
      campaignId: params.campaignId,
      status: params.status,
      providerId: params.providerId,
      errorMessage: params.errorMessage,
      sentAt: params.sentAt,
    },
  });

  return log.id;
}

// ─── sendEmail ────────────────────────────────────────────────────────────────

/**
 * ارسال ایمیل خام از طریق SMTP
 * اگر SMTP تنظیم نشده باشد: لاگ در console + وضعیت QUEUED
 */
export async function sendEmail(options: SendEmailOptions): Promise<SendEmailResult> {
  const toArray = Array.isArray(options.to) ? options.to : [options.to];
  const toStr = toArray.join(', ');

  // ── SMTP not configured — graceful fallback ──────────────────────────────
  if (!isSmtpConfigured()) {
    console.log(
      JSON.stringify({
        level: 'INFO',
        channel: 'email',
        action: 'SMTP_NOT_CONFIGURED',
        to: toStr,
        subject: options.subject,
        message: 'SMTP not configured. Email queued for later delivery.',
        timestamp: new Date().toISOString(),
      })
    );

    const logId = await logEmail({
      to: toStr,
      subject: options.subject,
      body: options.body,
      templateId: options.templateId,
      leadId: options.leadId,
      karAmuzId: options.karAmuzId,
      campaignId: options.campaignId,
      status: 'QUEUED',
    });

    return { success: true, logId, error: 'SMTP not configured — email queued' };
  }

  // ── Send via SMTP ───────────────────────────────────────────────────────
  try {
    const from = optionalEnv('SMTP_FROM') || optionalEnv('SMTP_USER') || '';
    const transport = getTransporter();

    const mailOptions: nodemailer.SendMailOptions = {
      from,
      to: toArray.join(', '),
      cc: options.cc
        ? Array.isArray(options.cc)
          ? options.cc.join(', ')
          : options.cc
        : undefined,
      bcc: options.bcc
        ? Array.isArray(options.bcc)
          ? options.bcc.join(', ')
          : options.bcc
        : undefined,
      subject: options.subject,
      html: options.body,
      attachments: options.attachments,
    };

    const result = await transport.sendMail(mailOptions);
    const messageId = result.messageId || '';

    const logId = await logEmail({
      to: toStr,
      subject: options.subject,
      body: options.body,
      templateId: options.templateId,
      leadId: options.leadId,
      karAmuzId: options.karAmuzId,
      campaignId: options.campaignId,
      status: 'SENT',
      providerId: messageId,
      sentAt: new Date(),
    });

    return { success: true, logId, messageId };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);

    console.error(
      JSON.stringify({
        level: 'ERROR',
        channel: 'email',
        to: toStr,
        subject: options.subject,
        message: errorMessage,
        timestamp: new Date().toISOString(),
        action: 'REQUIRES_MANUAL_RETRY',
      })
    );

    const logId = await logEmail({
      to: toStr,
      subject: options.subject,
      body: options.body,
      templateId: options.templateId,
      leadId: options.leadId,
      karAmuzId: options.karAmuzId,
      campaignId: options.campaignId,
      status: 'FAILED',
      errorMessage,
    });

    return { success: false, logId, error: errorMessage };
  }
}

// ─── sendTemplatedEmail ───────────────────────────────────────────────────────

/**
 * ارسال ایمیل با قالب از پایگاه داده
 * ۱. بارگذاری قالب از DB
 * ۲. جایگزینی متغیرها
 * ۳. ارسال از طریق SMTP
 * ۴. لاگ در EmailLog
 */
export async function sendTemplatedEmail(
  templateId: string,
  to: string,
  variables: Record<string, string | number | boolean>,
  leadId?: string,
  karAmuzId?: string
): Promise<SendEmailResult> {
  // ۱. بارگذاری قالب
  const template = await db.emailTemplate.findUnique({
    where: { id: templateId },
  });

  if (!template) {
    const logId = await logEmail({
      to,
      subject: '(template not found)',
      body: '',
      templateId,
      leadId,
      karAmuzId,
      status: 'FAILED',
      errorMessage: `Email template not found: ${templateId}`,
    });

    return { success: false, logId, error: `Template not found: ${templateId}` };
  }

  if (!template.isActive) {
    const logId = await logEmail({
      to,
      subject: '(template inactive)',
      body: '',
      templateId,
      leadId,
      karAmuzId,
      status: 'FAILED',
      errorMessage: `Email template is inactive: ${template.name}`,
    });

    return { success: false, logId, error: `Template inactive: ${template.name}` };
  }

  // ۲. جایگزینی متغیرها
  const subject = replaceTemplateVariables(template.subject, variables);
  const body = replaceTemplateVariables(template.body, variables);

  // ۳+۴. ارسال + لاگ
  return sendEmail({
    to,
    subject,
    body,
    templateId,
    leadId,
    karAmuzId,
  });
}

// ─── sendBulkEmail ────────────────────────────────────────────────────────────

/**
 * ارسال انبوه ایمیل برای کمپین‌ها
 * هر گیرنده متغیرهای مخصوص خودش را دارد
 *
 * @param templateId  شناسه قالب ایمیل
 * @param recipients  آرایه‌ای از گیرنده‌ها با متغیرهای اختصاصی
 * @param campaignId  شناسه کمپین (برای لاگ)
 */
export async function sendBulkEmail(
  templateId: string,
  recipients: Array<{
    to: string;
    variables: Record<string, string | number | boolean>;
    leadId?: string;
    karAmuzId?: string;
  }>,
  campaignId?: string
): Promise<{
  total: number;
  sent: number;
  failed: number;
  queued: number;
  results: SendEmailResult[];
}> {
  const template = await db.emailTemplate.findUnique({
    where: { id: templateId },
  });

  if (!template) {
    // اگر قالب یافت نشد، همه گیرنده‌ها FAILED
    const results: SendEmailResult[] = [];
    for (const recipient of recipients) {
      const logId = await logEmail({
        to: recipient.to,
        subject: '(template not found)',
        body: '',
        templateId,
        leadId: recipient.leadId,
        karAmuzId: recipient.karAmuzId,
        campaignId,
        status: 'FAILED',
        errorMessage: `Bulk email template not found: ${templateId}`,
      });
      results.push({ success: false, logId, error: 'Template not found' });
    }
    return { total: recipients.length, sent: 0, failed: recipients.length, queued: 0, results };
  }

  const results: SendEmailResult[] = [];
  let sent = 0;
  let failed = 0;
  let queued = 0;

  // ارسال متوالی (نه موازی) برای جلوگیری از rate limiting
  for (const recipient of recipients) {
    const subject = replaceTemplateVariables(template.subject, recipient.variables);
    const body = replaceTemplateVariables(template.body, recipient.variables);

    const result = await sendEmail({
      to: recipient.to,
      subject,
      body,
      templateId,
      leadId: recipient.leadId,
      karAmuzId: recipient.karAmuzId,
      campaignId,
    });

    results.push(result);

    if (result.success && !result.error?.includes('queued')) {
      sent++;
    } else if (result.error?.includes('queued')) {
      queued++;
    } else {
      failed++;
    }

    // فاصله ۱۰۰ms بین هر ارسال برای احترام به rate limit
    if (recipients.indexOf(recipient) < recipients.length - 1) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  }

  return { total: recipients.length, sent, failed, queued, results };
}

// ─── Convenience Wrappers ─────────────────────────────────────────────────────

export const email = {
  /** ایمیل خوش‌آمدگویی به لید جدید */
  welcomeLead: (to: string, name: string, course: string, leadId?: string) =>
    sendTemplatedEmail(
      'welcome-lead', // باید در DB وجود داشته باشد
      to,
      { name, course, institute: siteConfig.name.fa, phone: siteConfig.contact.phone },
      leadId
    ),

  /** ایمیل پیگیری لید */
  followUpLead: (to: string, name: string, course: string, leadId?: string) =>
    sendTemplatedEmail(
      'follow-up-lead',
      to,
      { name, course, institute: siteConfig.name.fa },
      leadId
    ),

  /** ایمیل تأیید ثبت‌نام */
  enrollmentConfirmation: (to: string, name: string, course: string, karAmuzId?: string) =>
    sendTemplatedEmail(
      'enrollment-confirmation',
      to,
      { name, course, institute: siteConfig.name.fa, date: new Date().toLocaleDateString('fa-IR') },
      undefined,
      karAmuzId
    ),

  /** ایمیل یادآوری پرداخت */
  paymentReminder: (to: string, name: string, amount: number, dueDate: string, leadId?: string) =>
    sendTemplatedEmail(
      'payment-reminder',
      to,
      {
        name,
        amount: new Intl.NumberFormat('fa-IR').format(amount) + ' تومان',
        dueDate: new Date(dueDate).toLocaleDateString('fa-IR'),
        institute: siteConfig.name.fa,
      },
      leadId
    ),

  /** ایمیل آماده‌بودن گواهینامه */
  certificateReady: (to: string, name: string, course: string, karAmuzId?: string) =>
    sendTemplatedEmail(
      'certificate-ready',
      to,
      { name, course, institute: siteConfig.name.fa },
      undefined,
      karAmuzId
    ),
};
