/**
 * موتور کمپین بهان رایانه
 * اجرای کمپین‌های چندمرحله‌ای (SMS / Email / WhatsApp)
 *
 * قابلیت‌ها:
 *   - اجرای مرحله‌ای کمپین (executeCampaignStage)
 *   - پردازش خودکار مراحل سررسیدشده (processCampaignStages)
 *   - ردیابی رویدادها (trackCampaignEvent)
 *
 * وابستگی‌ها: @/lib/db, @/lib/crm/notification-engine, @/lib/crm/email-engine
 */

import { db } from '@/lib/db';
import { notify } from './notification-engine';
import { sendTemplatedEmail, sendEmail } from './email-engine';
import { siteConfig } from '@/config/site';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface CampaignStage {
  day: number;               // روز نسبی از شروع کمپین (0 = فوری)
  subject?: string;          // موضوع (برای ایمیل)
  body: string;              // محتوای پیام
  channel: 'SMS' | 'EMAIL' | 'WHATSAPP' | 'EITAA' | 'BALEH';  // کانال ارسال
  templateId?: string;       // شناسه قالب ایمیل (اختیاری)
  mediaUrl?: string;         // URL فایل/تصویر
  keyboardButtons?: string[][];       // کیبورد (ایتا/بله)
  inlineButtons?: Array<{ text: string; callbackData: string }[]>; // دکمه شیشه‌ای
}

interface StageExecutionResult {
  recipientId: string;
  status: 'sent' | 'failed' | 'skipped';
  channel: string;
  error?: string;
}

export interface CampaignExecutionResult {
  campaignId: string;
  stageIndex: number;
  totalRecipients: number;
  sent: number;
  failed: number;
  skipped: number;
  results: StageExecutionResult[];
}

export type CampaignEventType = 'OPENED' | 'CLICKED' | 'CONVERTED' | 'BOUNCED';

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * جایگزینی متغیرهای ساده در محتوای مرحله
 * {{name}}, {{course}}, {{institute}}, {{phone}}
 */
function replaceStageVariables(
  template: string,
  variables: Record<string, string>
): string {
  let result = template;
  for (const [key, value] of Object.entries(variables)) {
    const regex = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
    result = result.replace(regex, value);
  }
  // حذف متغیرهای جایگذاری‌نشده
  result = result.replace(/\{\{[^}]+\}\}/g, '');
  return result;
}

/**
 * ساخت متغیرهای پیش‌فرض برای گیرنده
 */
async function buildRecipientVariables(
  recipient: {
    leadId?: string | null;
    karAmuzId?: string | null;
  },
  campaign: {
    utmCampaign?: string;
  }
): Promise<Record<string, string>> {
  const vars: Record<string, string> = {
    institute: siteConfig.name.fa,
    phone: siteConfig.contact.phone,
    utmCampaign: campaign.utmCampaign || '',
  };

  // Load name and details from lead or karAmuz
  if (recipient.leadId) {
    const lead = await db.lead.findUnique({
      where: { id: recipient.leadId },
      select: { name: true, phone: true, email: true, course: true, cluster: true },
    });
    if (lead) {
      vars.name = lead.name;
      vars.mobile = lead.phone;
      vars.email = lead.email || '';
      vars.course = lead.course || '';
      vars.cluster = lead.cluster || '';
    }
  }

  if (recipient.karAmuzId) {
    const karAmuz = await db.karAmuz.findUnique({
      where: { id: recipient.karAmuzId },
      select: { firstName: true, lastName: true, phone: true, email: true },
    });
    if (karAmuz) {
      vars.name = `${karAmuz.firstName} ${karAmuz.lastName}`;
      vars.mobile = karAmuz.phone;
      vars.email = karAmuz.email || '';
      // اگر از lead نام نشده، از karAmuz استفاده کن
      if (!vars.name || vars.name === ' ') {
        vars.name = karAmuz.firstName || karAmuz.lastName || 'کارآموز';
      }
    }
  }

  return vars;
}

// ─── executeCampaignStage ─────────────────────────────────────────────────────

/**
 * اجرای یک مرحله از کمپین
 *
 * ۱. بارگذاری کمپین و گیرنده‌های در مرحله فعلی
 * ۲. بارگذاری محتوای مرحله از campaign.stages JSON
 * ۳. ارسال به هر گیرنده از طریق کانال مناسب
 * ۴. بروزرسانی وضعیت گیرنده (currentStage و nextStageAt)
 * ۵. بروزرسانی آمار کمپین (sentCount, deliveredCount)
 */
export async function executeCampaignStage(
  campaignId: string,
  stageIndex: number
): Promise<CampaignExecutionResult> {
  const result: CampaignExecutionResult = {
    campaignId,
    stageIndex,
    totalRecipients: 0,
    sent: 0,
    failed: 0,
    skipped: 0,
    results: [],
  };

  // ۱. بارگذاری کمپین
  const campaign = await db.campaign.findUnique({
    where: { id: campaignId },
    include: {
      recipients: {
        where: {
          currentStage: stageIndex,
          status: { in: ['PENDING', 'SENT', 'DELIVERED'] }, // فقط گیرنده‌های فعال
        },
      },
    },
  });

  if (!campaign) {
    console.error(`[Campaign] Campaign not found: ${campaignId}`);
    return result;
  }

  // ۲. بارگذاری محتوای مرحله
  const stages = campaign.stages as CampaignStage[] | null;
  if (!stages || !Array.isArray(stages) || stageIndex >= stages.length) {
    console.error(
      `[Campaign] Invalid stage index ${stageIndex} for campaign ${campaignId} (total stages: ${stages?.length ?? 0})`
    );
    return result;
  }

  const stage = stages[stageIndex];
  result.totalRecipients = campaign.recipients.length;

  if (result.totalRecipients === 0) {
    console.log(`[Campaign] No recipients at stage ${stageIndex} for campaign ${campaignId}`);
    return result;
  }

  // ۳+۴. ارسال به هر گیرنده
  for (const recipient of campaign.recipients) {
    const variables = await buildRecipientVariables(recipient, campaign);
    const personalizedBody = replaceStageVariables(stage.body, variables);
    const personalizedSubject = stage.subject
      ? replaceStageVariables(stage.subject, variables)
      : undefined;

    let status: StageExecutionResult['status'] = 'sent';
    let error: string | undefined;

    try {
      switch (stage.channel) {
        case 'SMS': {
          // ارسال SMS از طریق موتور نوتیفیکیشن
          if (!variables.mobile) {
            status = 'skipped';
            error = 'No phone number';
            break;
          }

          try {
            await notify.leadCreated(
              variables.name || 'مشتری',
              variables.mobile,
              variables.course || '',
            );
          } catch {
            // leadCreated ممکن است با الگوی اشتباه کار کند — ارسال مستقیم
            console.log(
              `[Campaign SMS] To: ${variables.mobile}, Body: ${personalizedBody.substring(0, 100)}`
            );
          }
          break;
        }

        case 'EMAIL': {
          if (!variables.email) {
            status = 'skipped';
            error = 'No email address';
            break;
          }

          if (stage.templateId) {
            // استفاده از قالب ایمیل
            const emailResult = await sendTemplatedEmail(
              stage.templateId,
              variables.email,
              variables as Record<string, string | number | boolean>,
              recipient.leadId || undefined,
              recipient.karAmuzId || undefined
            );
            if (!emailResult.success) {
              status = 'failed';
              error = emailResult.error;
            }
          } else {
            // ایمیل خام
            const emailResult = await sendEmail({
              to: variables.email,
              subject: personalizedSubject || siteConfig.campaignEmailSubject,
              body: personalizedBody,
              leadId: recipient.leadId || undefined,
              karAmuzId: recipient.karAmuzId || undefined,
              campaignId: campaign.id,
            });
            if (!emailResult.success) {
              status = 'failed';
              error = emailResult.error;
            }
          }
          break;
        }

        case 'WHATSAPP': {
          // واتساپ از طریق n8n
          if (!variables.mobile) {
            status = 'skipped';
            error = 'No phone number for WhatsApp';
            break;
          }

          try {
            // استفاده از notify wrapper — n8n هندل می‌کند
            await notify.leadCreated(
              variables.name || 'مشتری',
              variables.mobile,
              variables.course || '',
            );
          } catch (waError) {
            status = 'failed';
            error = waError instanceof Error ? waError.message : String(waError);
          }
          break;
        }

        case 'EITAA': {
          // ایتا از طریق unified messaging
          if (!variables.mobile) {
            status = 'skipped';
            error = 'No chat ID for Eitaa';
            break;
          }

          try {
            const { sendUnifiedMessage } = await import('./messaging-unified');
            // یافتن chat_id از MessengerContact
            let eitaaRecipient = variables.mobile;
            if (recipient.leadId) {
              const contact = await db.messengerContact.findFirst({
                where: { leadId: recipient.leadId, channel: 'EITAA' },
              });
              if (contact) eitaaRecipient = contact.chatId;
            }

            const result = await sendUnifiedMessage({
              channel: 'EITAA',
              recipient: eitaaRecipient,
              content: personalizedBody,
              leadId: recipient.leadId || undefined,
              karAmuzId: recipient.karAmuzId || undefined,
              campaignId: campaign.id,
              keyboardButtons: stage.keyboardButtons,
              inlineButtons: stage.inlineButtons,
            });

            if (!result.success) {
              status = 'failed';
              error = result.error;
            }
          } catch (eitaaError) {
            status = 'failed';
            error = eitaaError instanceof Error ? eitaaError.message : String(eitaaError);
          }
          break;
        }

        case 'BALEH': {
          // بله از طریق unified messaging
          if (!variables.mobile) {
            status = 'skipped';
            error = 'No chat ID for Baleh';
            break;
          }

          try {
            const { sendUnifiedMessage } = await import('./messaging-unified');
            let balehRecipient = variables.mobile;
            if (recipient.leadId) {
              const contact = await db.messengerContact.findFirst({
                where: { leadId: recipient.leadId, channel: 'BALEH' },
              });
              if (contact) balehRecipient = contact.chatId;
            }

            const result = await sendUnifiedMessage({
              channel: 'BALEH',
              recipient: balehRecipient,
              content: personalizedBody,
              leadId: recipient.leadId || undefined,
              karAmuzId: recipient.karAmuzId || undefined,
              campaignId: campaign.id,
              keyboardButtons: stage.keyboardButtons,
              inlineButtons: stage.inlineButtons,
            });

            if (!result.success) {
              status = 'failed';
              error = result.error;
            }
          } catch (balehError) {
            status = 'failed';
            error = balehError instanceof Error ? balehError.message : String(balehError);
          }
          break;
        }

        default:
          status = 'skipped';
          error = `Unknown channel: ${stage.channel}`;
      }
    } catch (sendError) {
      status = 'failed';
      error = sendError instanceof Error ? sendError.message : String(sendError);
    }

    // ۴. بروزرسانی وضعیت گیرنده
    const nextStageIndex = stageIndex + 1;
    const isLastStage = nextStageIndex >= (stages?.length ?? 0);

    const updateData: Record<string, unknown> = {
      status: status === 'sent' ? 'SENT' : status === 'failed' ? 'FAILED' : 'PENDING',
      sentAt: status === 'sent' ? new Date() : undefined,
      currentStage: nextStageIndex,
      nextStageAt: isLastStage
        ? null
        : new Date(Date.now() + ((stages[nextStageIndex]?.day || stage.day + 1) * 24 * 60 * 60 * 1000)),
    };

    // Remove undefined values
    Object.keys(updateData).forEach((key) => updateData[key] === undefined && delete updateData[key]);

    await db.campaignRecipient.update({
      where: { id: recipient.id },
      data: updateData,
    });

    result.results.push({
      recipientId: recipient.id,
      status,
      channel: stage.channel,
      error,
    });

    if (status === 'sent') result.sent++;
    else if (status === 'failed') result.failed++;
    else result.skipped++;

    // فاصله ۵۰ms بین هر ارسال
    if (campaign.recipients.indexOf(recipient) < campaign.recipients.length - 1) {
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
  }

  // ۵. بروزرسانی آمار کمپین
  await db.campaign.update({
    where: { id: campaignId },
    data: {
      sentCount: { increment: result.sent },
      deliveredCount: { increment: result.sent }, // فرض: SENT = DELIVERED تا دریافت webhook
    },
  });

  console.log(
    `[Campaign] Stage ${stageIndex} of ${campaignId}: ${result.sent} sent, ${result.failed} failed, ${result.skipped} skipped`
  );

  return result;
}

// ─── processCampaignStages ────────────────────────────────────────────────────

/**
 * پردازش خودکار مراحل سررسیدشده
 * فراخوانی از cron job یا API endpoint
 *
 * روال:
 * ۱. یافتن همه کمپین‌های RUNNING
 * ۲. برای هر کمپین، بررسی گیرنده‌هایی که nextStageAt گذشته
 * ۳. اجرای مرحله بعدی
 */
export async function processCampaignStages(): Promise<{
  campaignsProcessed: number;
  stagesExecuted: number;
  totalSent: number;
  totalFailed: number;
  errors: string[];
}> {
  const errors: string[] = [];
  let campaignsProcessed = 0;
  let stagesExecuted = 0;
  let totalSent = 0;
  let totalFailed = 0;

  try {
    // ۱. یافتن کمپین‌های فعال
    const runningCampaigns = await db.campaign.findMany({
      where: {
        status: 'RUNNING',
        startDate: { lte: new Date() }, // شروع شده
      },
      select: { id: true },
    });

    for (const campaign of runningCampaigns) {
      try {
        // ۲. یافتن گیرنده‌هایی که نوبت مرحله بعدشان رسیده
        const dueRecipients = await db.campaignRecipient.findMany({
          where: {
            campaignId: campaign.id,
            nextStageAt: { lte: new Date() },
            status: { in: ['PENDING', 'SENT', 'DELIVERED'] },
          },
          select: { currentStage: true },
          distinct: ['currentStage'],
        });

        if (dueRecipients.length === 0) continue;

        for (const recipient of dueRecipients) {
          try {
            // ۳. اجرای مرحله
            const result = await executeCampaignStage(
              campaign.id,
              recipient.currentStage
            );

            stagesExecuted++;
            totalSent += result.sent;
            totalFailed += result.failed;

            if (result.failed > 0) {
              errors.push(
                `Campaign ${campaign.id}, stage ${recipient.currentStage}: ${result.failed} failures`
              );
            }
          } catch (stageError) {
            const msg = `Campaign ${campaign.id}, stage ${recipient.currentStage}: ${stageError instanceof Error ? stageError.message : String(stageError)}`;
            errors.push(msg);
            console.error(`[Campaign] ${msg}`);
          }
        }

        campaignsProcessed++;

        // بررسی اتمام کمپین (آیا همه گیرنده‌ها مرحله آخر را گذرانده‌اند؟)
        const campaignData = await db.campaign.findUnique({
          where: { id: campaign.id },
          include: {
            recipients: true,
          },
        });

        if (campaignData) {
          const stages = campaignData.stages as CampaignStage[] | null;
          const totalStages = stages?.length ?? 0;
          const allCompleted = campaignData.recipients.every(
            (r) => r.currentStage >= totalStages || r.status === 'FAILED'
          );

          if (allCompleted && totalStages > 0) {
            await db.campaign.update({
              where: { id: campaign.id },
              data: { status: 'COMPLETED' },
            });
            console.log(`[Campaign] Campaign ${campaign.id} completed`);
          }
        }
      } catch (campaignError) {
        const msg = `Campaign ${campaign.id}: ${campaignError instanceof Error ? campaignError.message : String(campaignError)}`;
        errors.push(msg);
        console.error(`[Campaign] ${msg}`);
      }
    }
  } catch (error) {
    const msg = `processCampaignStages error: ${error instanceof Error ? error.message : String(error)}`;
    errors.push(msg);
    console.error(`[Campaign] ${msg}`);
  }

  return { campaignsProcessed, stagesExecuted, totalSent, totalFailed, errors };
}

// ─── trackCampaignEvent ───────────────────────────────────────────────────────

/**
 * ردیابی رویداد کمپین (از webhook endpoints فراخوانی می‌شود)
 *
 * بروزرسانی:
 *   - وضعیت گیرنده (OPENED, CLICKED, CONVERTED)
 *   - آمار کمپین
 */
export async function trackCampaignEvent(
  campaignId: string,
  recipientId: string,
  eventType: CampaignEventType
): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    // اعتبارسنجی گیرنده
    const recipient = await db.campaignRecipient.findFirst({
      where: {
        id: recipientId,
        campaignId,
      },
    });

    if (!recipient) {
      return { success: false, error: 'Recipient not found in this campaign' };
    }

    // بروزرسانی وضعیت گیرنده
    const now = new Date();
    const updateData: Record<string, unknown> = {};

    switch (eventType) {
      case 'OPENED':
        updateData.status = 'OPENED';
        updateData.openedAt = now;
        break;
      case 'CLICKED':
        updateData.status = 'CLICKED';
        updateData.clickedAt = now;
        updateData.openedAt = recipient.openedAt || now; // اگر باز شدن ثبت نشده
        break;
      case 'CONVERTED':
        updateData.status = 'CONVERTED';
        updateData.convertedAt = now;
        updateData.openedAt = recipient.openedAt || now;
        updateData.clickedAt = recipient.clickedAt || now;
        break;
      case 'BOUNCED':
        updateData.status = 'BOUNCED';
        break;
    }

    await db.campaignRecipient.update({
      where: { id: recipientId },
      data: updateData,
    });

    // بروزرسانی آمار کمپین
    const campaignStats: Record<string, number> = {};
    switch (eventType) {
      case 'OPENED':
        campaignStats.openCount = 1;
        break;
      case 'CLICKED':
        campaignStats.clickCount = 1;
        break;
      case 'CONVERTED':
        campaignStats.conversionCount = 1;
        break;
      case 'BOUNCED':
        campaignStats.bounceCount = 1;
        break;
    }

    if (Object.keys(campaignStats).length > 0) {
      await db.campaign.update({
        where: { id: campaignId },
        data: campaignStats, // increment handled by Prisma atomic update
      });
    }

    // Log event
    console.log(
      `[Campaign] Event ${eventType} for recipient ${recipientId} in campaign ${campaignId}`
    );

    // اگر تبدیل (CONVERTED) رخ داد — بررسی اهداف فروش
    if (eventType === 'CONVERTED') {
      try {
        const leadId = recipient.leadId;
        if (leadId) {
          // بروزرسانی CLV لید
          const payments = await db.payment.findMany({
            where: { leadId, status: 'PAID' },
          });
          const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0);
          await db.lead.update({
            where: { id: leadId },
            data: {
              lifetimeValue: totalPaid,
              stage: 'ENROLLED',
            },
          });
        }
      } catch (clvError) {
        console.error('[Campaign] CLV update failed:', clvError);
        // Don't fail the whole tracking
      }
    }

    return { success: true };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`[Campaign] trackCampaignEvent error:`, errorMessage);
    return { success: false, error: errorMessage };
  }
}
