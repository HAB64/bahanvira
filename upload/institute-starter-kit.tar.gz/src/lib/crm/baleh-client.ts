/**
 * بله Bot API Client — بهان رایانه
 * ارسال و دریافت پیام از طریق Baleh Messenger Bot API
 *
 * مستندات API: https://bale.ai/page/api-docs
 *
 * متغیرهای env:
 *   BALEH_BOT_TOKEN    توکن بات بله (از @BotFather بله دریافت می‌شود)
 *   BALEH_API_BASE     آدرس پایه API (پیش‌فرض: https://tapi.bale.ai/bot)
 */

// ─── Types ────────────────────────────────────────────────────────────────────

export interface BalehMessageOptions {
  chatId: string | number;
  text: string;
  parseMode?: 'Markdown' | 'HTML';
  disableWebPagePreview?: boolean;
  replyToMessageId?: number;
  replyMarkup?: BalehReplyMarkup;
}

export interface BalehReplyMarkup {
  inline_keyboard?: BalehInlineKeyboardButton[][];
  keyboard?: BalehKeyboardButton[][];
  resize_keyboard?: boolean;
  one_time_keyboard?: boolean;
  remove_keyboard?: boolean;
}

export interface BalehInlineKeyboardButton {
  text: string;
  url?: string;
  callback_data?: string;
}

export interface BalehKeyboardButton {
  text: string;
  request_contact?: boolean;
  request_location?: boolean;
}

export interface BalehSendMessageResponse {
  ok: boolean;
  result?: {
    message_id: number;
    from: { id: number; first_name: string; username?: string };
    chat: { id: number; type: string };
    date: number;
    text?: string;
  };
  description?: string;
  error_code?: number;
}

export interface BalehWebhookUpdate {
  update_id: number;
  message?: {
    message_id: number;
    from: { id: number; first_name: string; last_name?: string; username?: string };
    chat: { id: number; type: string };
    date: number;
    text?: string;
    contact?: { phone_number: string; first_name: string; last_name?: string; user_id: number };
    location?: { latitude: number; longitude: number };
  };
  callback_query?: {
    id: string;
    from: { id: number; first_name: string; username?: string };
    message?: { message_id: number; chat: { id: number } };
    data?: string;
  };
}

// ─── Env Helpers ──────────────────────────────────────────────────────────────

function requireEnv(key: string): string {
  const val = process.env[key];
  if (!val || val.trim() === '') {
    throw new Error(`[Baleh] متغیر محیطی "${key}" تنظیم نشده است.`);
  }
  return val.trim();
}

function optionalEnv(key: string, fallback: string): string {
  return process.env[key]?.trim() || fallback;
}

function isBalehConfigured(): boolean {
  return !!process.env.BALEH_BOT_TOKEN?.trim();
}

// ─── API Client ───────────────────────────────────────────────────────────────

class BalehClient {
  private token: string;
  private baseUrl: string;

  constructor(token?: string, baseUrl?: string) {
    this.token = token || requireEnv('BALEH_BOT_TOKEN');
    this.baseUrl = baseUrl || optionalEnv('BALEH_API_BASE', 'https://tapi.bale.ai/bot');
  }

  /**
   * ارسال درخواست به API بله
   * بله API شبیه Telegram Bot API است
   */
  private async request<T>(
    method: string,
    params: Record<string, unknown> = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${this.token}/${method}`;

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
      signal: AbortSignal.timeout(10_000),
    });

    if (!response.ok) {
      throw new Error(`[Baleh] HTTP ${response.status} — ${response.statusText}`);
    }

    const data = await response.json();

    if (!data.ok) {
      throw new Error(
        `[Baleh] API Error: ${data.description || 'Unknown error'} (code: ${data.error_code || 'N/A'})`
      );
    }

    return data as T;
  }

  /**
   * ارسال پیام متنی
   */
  async sendMessage(options: BalehMessageOptions): Promise<BalehSendMessageResponse> {
    const params: Record<string, unknown> = {
      chat_id: options.chatId,
      text: options.text,
    };

    if (options.parseMode) params.parse_mode = options.parseMode;
    if (options.disableWebPagePreview) params.disable_web_page_preview = true;
    if (options.replyToMessageId) params.reply_to_message_id = options.replyToMessageId;
    if (options.replyMarkup) params.reply_markup = JSON.stringify(options.replyMarkup);

    return this.request<BalehSendMessageResponse>('sendMessage', params);
  }

  /**
   * ارسال عکس
   */
  async sendPhoto(chatId: string | number, photo: string, caption?: string): Promise<BalehSendMessageResponse> {
    return this.request<BalehSendMessageResponse>('sendPhoto', {
      chat_id: chatId,
      photo,
      caption: caption || undefined,
    });
  }

  /**
   * ارسال فایل/سند
   */
  async sendDocument(chatId: string | number, document: string, caption?: string): Promise<BalehSendMessageResponse> {
    return this.request<BalehSendMessageResponse>('sendDocument', {
      chat_id: chatId,
      document,
      caption: caption || undefined,
    });
  }

  /**
   * پاسخ به callback query
   */
  async answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void> {
    await this.request('answerCallbackQuery', {
      callback_query_id: callbackQueryId,
      text: text || '',
    });
  }

  /**
   * تنظیم وب‌هوک
   */
  async setWebhook(webhookUrl: string, secret?: string): Promise<void> {
    await this.request('setWebhook', {
      url: webhookUrl,
      secret_token: secret || undefined,
    });
  }

  /**
   * حذف وب‌هوک
   */
  async deleteWebhook(): Promise<void> {
    await this.request('deleteWebhook');
  }

  /**
   * دریافت اطلاعات بات
   */
  async getMe(): Promise<{ ok: boolean; result: { id: number; first_name: string; username?: string } }> {
    return this.request('getMe');
  }
}

// ─── Singleton & Exports ──────────────────────────────────────────────────────

let balehClient: BalehClient | null = null;

export function getBalehClient(): BalehClient | null {
  if (!isBalehConfigured()) return null;
  if (!balehClient) {
    balehClient = new BalehClient();
  }
  return balehClient;
}

export { BalehClient, isBalehConfigured };

// ─── Convenience Wrappers ─────────────────────────────────────────────────────

export const baleh = {
  /** ارسال پیام متنی به کاربر بله */
  sendText: (chatId: string | number, text: string, replyMarkup?: BalehReplyMarkup) => {
    const client = getBalehClient();
    if (!client) return Promise.resolve(null);
    return client.sendMessage({ chatId, text, replyMarkup });
  },

  /** ارسال پیام با کیبورد انتخابی */
  sendWithKeyboard: (chatId: string | number, text: string, buttons: string[][]) => {
    const client = getBalehClient();
    if (!client) return Promise.resolve(null);
    const keyboard: BalehKeyboardButton[][] = buttons.map(row =>
      row.map(btn => ({ text: btn }))
    );
    return client.sendMessage({
      chatId,
      text,
      replyMarkup: { keyboard, resize_keyboard: true, one_time_keyboard: true },
    });
  },

  /** ارسال پیام با دکمه‌های شیشه‌ای (inline) */
  sendWithInlineKeyboard: (
    chatId: string | number,
    text: string,
    buttons: Array<{ text: string; callbackData: string }[]>
  ) => {
    const client = getBalehClient();
    if (!client) return Promise.resolve(null);
    const inline_keyboard: BalehInlineKeyboardButton[][] = buttons.map(row =>
      row.map(btn => ({ text: btn.text, callback_data: btn.callbackData }))
    );
    return client.sendMessage({
      chatId,
      text,
      replyMarkup: { inline_keyboard },
    });
  },

  /** ارسال عکس */
  sendPhoto: (chatId: string | number, photoUrl: string, caption?: string) => {
    const client = getBalehClient();
    if (!client) return Promise.resolve(null);
    return client.sendPhoto(chatId, photoUrl, caption);
  },
};
