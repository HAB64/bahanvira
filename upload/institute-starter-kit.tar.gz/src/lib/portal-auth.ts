import { createHash } from 'crypto';
import { db } from '@/lib/db';
import { siteConfig } from '@/config/site';

const PORTAL_COOKIE_NAME = 'portal_session';
const PORTAL_SECRET = process.env.AUTH_SECRET || siteConfig.name.en.toLowerCase().replace(/\s+/g, '-') + '-portal-2024';

export function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

export function createPortalToken(userId: string): string {
  const payload = JSON.stringify({ userId, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 }); // 7 days
  const token = Buffer.from(payload).toString('base64');
  const signature = createHash('sha256').update(token + PORTAL_SECRET).digest('hex');
  return `${token}.${signature}`;
}

export function verifyPortalToken(token: string): { userId: string; exp: number } | null {
  try {
    const [tokenPart, signature] = token.split('.');
    const expectedSignature = createHash('sha256').update(tokenPart + PORTAL_SECRET).digest('hex');
    if (signature !== expectedSignature) return null;

    const payload = JSON.parse(Buffer.from(tokenPart, 'base64').toString());
    if (payload.exp < Date.now()) return null;

    return payload;
  } catch {
    return null;
  }
}

/**
 * Extract and verify portal user from Authorization header
 * Returns the full user object (without passwordHash) or null
 */
export async function getPortalUserFromRequest(request: Request) {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader) return null;

  const token = authHeader.replace('Bearer ', '');
  const decoded = verifyPortalToken(token);
  if (!decoded) return null;

  const user = await db.customerPortalUser.findUnique({
    where: { id: decoded.userId },
    include: {
      lead: { select: { id: true, name: true, phone: true, email: true } },
      karAmuz: { select: { id: true, firstName: true, lastName: true, phone: true, email: true, address: true, nationalId: true } },
    },
  });

  if (!user || !user.isActive) return null;

  const { passwordHash: _, ...safeUser } = user;
  return safeUser;
}

/**
 * Get the display name for a portal user
 */
export function getPortalUserName(user: {
  karAmuz?: { firstName: string; lastName: string } | null;
  lead?: { name: string } | null;
  username: string;
}): string {
  if (user.karAmuz) {
    return `${user.karAmuz.firstName} ${user.karAmuz.lastName}`;
  }
  if (user.lead) {
    return user.lead.name;
  }
  return user.username;
}

export { PORTAL_COOKIE_NAME };
