/**
 * Referrer System — Utility Functions
 * سیستم معرفین — توابع کمکی
 */

import { db } from '@/lib/db';
import { createHash } from 'crypto';

// ==========================================
// Tier Commission Rates (پلکانی)
// ==========================================
export const TIER_RATES: Record<string, number> = {
  BRONZE: 0.10,    // ۱۰٪ - پایه
  SILVER: 0.12,    // ۱۲٪ - نقره‌ای
  GOLD: 0.15,      // ۱۵٪ - طلایی
  PLATINUM: 0.20,  // ۲۰٪ - پلاتین
};

// Tier thresholds (by total enrollments)
export const TIER_THRESHOLDS: Record<string, number> = {
  BRONZE: 0,
  SILVER: 5,
  GOLD: 15,
  PLATINUM: 30,
};

export const TIER_LABELS: Record<string, string> = {
  BRONZE: 'برنزی',
  SILVER: 'نقره‌ای',
  GOLD: 'طلایی',
  PLATINUM: 'پلاتین',
};

export const TIER_COLORS: Record<string, string> = {
  BRONZE: '#CD7F32',
  SILVER: '#C0C0C0',
  GOLD: '#FFD700',
  PLATINUM: '#E5E4E2',
};

// ==========================================
// Generate unique referrer code
// ==========================================
export async function generateReferrerCode(): Promise<string> {
  let code: string;
  let exists = true;

  while (exists) {
    const num = Math.floor(1000 + Math.random() * 9000); // 4-digit
    code = `BR-${num}`;
    const existing = await db.referrer.findUnique({ where: { code } });
    exists = !!existing;
  }

  return code!;
}

// ==========================================
// Get commission rate for a referrer
// ==========================================
export function getCommissionRate(referrer: { tier: string; commissionRate: number | null }): number {
  if (referrer.commissionRate !== null && referrer.commissionRate !== undefined) {
    return referrer.commissionRate;
  }
  return TIER_RATES[referrer.tier] ?? TIER_RATES.BRONZE;
}

// ==========================================
// Auto-upgrade tier based on enrollments
// ==========================================
export function calculateTier(enrollmentCount: number): string {
  if (enrollmentCount >= TIER_THRESHOLDS.PLATINUM) return 'PLATINUM';
  if (enrollmentCount >= TIER_THRESHOLDS.GOLD) return 'GOLD';
  if (enrollmentCount >= TIER_THRESHOLDS.SILVER) return 'SILVER';
  return 'BRONZE';
}

// ==========================================
// Hash password for referrer auth
// ==========================================
export function hashReferrerPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

// ==========================================
// Calculate and create commission for a referral
// ==========================================
export async function createReferralCommission(
  referrerId: string,
  baseAmount: number,
  type: string,
  description?: string,
  leadId?: string,
  karAmuzId?: string
) {
  const referrer = await db.referrer.findUnique({ where: { id: referrerId } });
  if (!referrer || referrer.status !== 'ACTIVE') return null;

  const rate = getCommissionRate(referrer);
  const amount = Math.round(baseAmount * rate);

  const commission = await db.referralCommission.create({
    data: {
      referrerId,
      leadId,
      karAmuzId,
      type,
      amount,
      rate,
      baseAmount,
      description: description || `کمیسیون ${type === 'ENROLLMENT' ? 'ثبت‌نام' : 'پرداخت'} - نرخ ${Math.round(rate * 100)}%`,
    },
  });

  // Update referrer stats
  await db.referrer.update({
    where: { id: referrerId },
    data: {
      totalCommission: { increment: amount },
      totalEnrollments: type === 'ENROLLMENT' ? { increment: 1 } : undefined,
    },
  });

  // Auto-upgrade tier
  const updatedReferrer = await db.referrer.findUnique({ where: { id: referrerId } });
  if (updatedReferrer) {
    const newTier = calculateTier(updatedReferrer.totalEnrollments);
    if (newTier !== updatedReferrer.tier) {
      await db.referrer.update({
        where: { id: referrerId },
        data: { tier: newTier },
      });
    }
  }

  return commission;
}

// ==========================================
// Get referrer stats for dashboard
// ==========================================
export async function getReferrerStats(referrerId: string) {
  const referrer = await db.referrer.findUnique({
    where: { id: referrerId },
    include: {
      leads: {
        select: { id: true, name: true, phone: true, stage: true, createdAt: true },
        orderBy: { createdAt: 'desc' },
        take: 20,
      },
      commissions: {
        orderBy: { createdAt: 'desc' },
        take: 50,
      },
      payments: {
        orderBy: { paidAt: 'desc' },
        take: 20,
      },
      discountCodes: true,
    },
  });

  if (!referrer) return null;

  // Monthly breakdown
  const now = new Date();
  const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);

  const thisMonthLeads = await db.lead.count({
    where: { referrerId, createdAt: { gte: thisMonth } },
  });

  const thisMonthEnrollments = await db.lead.count({
    where: { referrerId, stage: 'ENROLLED', createdAt: { gte: thisMonth } },
  });

  const lastMonthLeads = await db.lead.count({
    where: { referrerId, createdAt: { gte: lastMonth, lt: thisMonth } },
  });

  const thisMonthCommission = await db.referralCommission.aggregate({
    where: { referrerId, createdAt: { gte: thisMonth } },
    _sum: { amount: true },
  });

  const pendingCommission = await db.referralCommission.aggregate({
    where: { referrerId, status: 'PENDING' },
    _sum: { amount: true },
  });

  return {
    ...referrer,
    stats: {
      thisMonthLeads,
      thisMonthEnrollments,
      lastMonthLeads,
      thisMonthCommission: thisMonthCommission._sum.amount ?? 0,
      pendingCommission: pendingCommission._sum.amount ?? 0,
      conversionRate: referrer.totalReferrals > 0
        ? Math.round((referrer.totalEnrollments / referrer.totalReferrals) * 100)
        : 0,
      currentRate: getCommissionRate(referrer),
      nextTier: getNextTier(referrer.tier),
      nextTierProgress: getTierProgress(referrer.totalEnrollments),
    },
  };
}

function getNextTier(currentTier: string): string | null {
  const tiers = ['BRONZE', 'SILVER', 'GOLD', 'PLATINUM'];
  const idx = tiers.indexOf(currentTier);
  return idx < tiers.length - 1 ? tiers[idx + 1] : null;
}

function getTierProgress(enrollments: number): { current: number; target: number; percentage: number } {
  if (enrollments >= TIER_THRESHOLDS.PLATINUM) {
    return { current: enrollments, target: TIER_THRESHOLDS.PLATINUM, percentage: 100 };
  }
  if (enrollments >= TIER_THRESHOLDS.GOLD) {
    const target = TIER_THRESHOLDS.PLATINUM;
    return { current: enrollments, target, percentage: Math.round(((enrollments - TIER_THRESHOLDS.GOLD) / (target - TIER_THRESHOLDS.GOLD)) * 100) };
  }
  if (enrollments >= TIER_THRESHOLDS.SILVER) {
    const target = TIER_THRESHOLDS.GOLD;
    return { current: enrollments, target, percentage: Math.round(((enrollments - TIER_THRESHOLDS.SILVER) / (target - TIER_THRESHOLDS.SILVER)) * 100) };
  }
  const target = TIER_THRESHOLDS.SILVER;
  return { current: enrollments, target, percentage: Math.round((enrollments / target) * 100) };
}
