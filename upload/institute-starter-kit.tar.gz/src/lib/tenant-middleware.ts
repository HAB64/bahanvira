/**
 * Tenant Isolation Middleware
 *
 * Provides tenant-aware query filtering, quota enforcement,
 * and request-based tenant resolution for multi-tenant isolation.
 */

import { db } from '@/lib/db';

// ─── Plan Limits ────────────────────────────────────────────────────────────

/** Storage helper: gigabytes → megabytes */
const GB_TO_MB = 1024;

const PLAN_LIMITS = {
  BASIC: {
    maxUsers: 50,
    maxStorage: 5 * GB_TO_MB, // 5 GB in MB
    maxApiCalls: 1000,        // per day
  },
  PROFESSIONAL: {
    maxUsers: 500,
    maxStorage: 50 * GB_TO_MB, // 50 GB in MB
    maxApiCalls: 10000,        // per day
  },
  ENTERPRISE: {
    maxUsers: -1,   // unlimited
    maxStorage: -1, // unlimited
    maxApiCalls: -1, // unlimited
  },
} as const;

export type PlanKey = keyof typeof PLAN_LIMITS;
export type ResourceType = 'users' | 'storage' | 'apiCalls';

// ─── Types ──────────────────────────────────────────────────────────────────

export interface QuotaResult {
  allowed: boolean;
  remaining: number;
  limit: number;
}

export interface ResolvedTenant {
  id: string;
  name: string;
  slug: string;
  domain: string | null;
  plan: string;
  status: string;
  primaryColor: string;
  locale: string;
  maxUsers: number;
  maxStorage: number;
  maxApiCalls: number;
}

// ─── withTenantId ──────────────────────────────────────────────────────────

/**
 * Returns a Prisma-compatible `where` clause that scopes queries to a tenant.
 * If tenantId is null or undefined, returns an empty object (no filtering).
 */
export function withTenantId(tenantId: string | null): Record<string, unknown> {
  if (!tenantId) return {};
  return { tenantId };
}

// ─── enforceTenantQuota ────────────────────────────────────────────────────

/**
 * Checks whether a tenant's plan allows a given resource action.
 * Looks up the tenant, resolves its plan, and computes remaining capacity.
 *
 * @param tenantId - The tenant's database ID
 * @param resourceType - The resource being checked: 'users' | 'storage' | 'apiCalls'
 * @returns `{ allowed, remaining, limit }` — for ENTERPRISE, remaining = Infinity
 */
export async function enforceTenantQuota(
  tenantId: string,
  resourceType: ResourceType
): Promise<QuotaResult> {
  const tenant = await db.tenant.findUnique({
    where: { id: tenantId },
  });

  if (!tenant) {
    return { allowed: false, remaining: 0, limit: 0 };
  }

  const planKey = (tenant.plan as PlanKey) || 'BASIC';
  const limits = PLAN_LIMITS[planKey] ?? PLAN_LIMITS.BASIC;
  const now = new Date();
  const period = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  // Enterprise plans have no limits
  if (limits.maxUsers === -1 || limits.maxStorage === -1 || limits.maxApiCalls === -1) {
    return { allowed: true, remaining: -1, limit: -1 };
  }

  switch (resourceType) {
    case 'users': {
      const current = await db.adminUser.count();
      const limit = limits.maxUsers;
      return {
        allowed: current < limit,
        remaining: Math.max(0, limit - current),
        limit,
      };
    }

    case 'storage': {
      const usageLog = await db.tenantUsageLog.findFirst({
        where: { tenantId, resourceType: 'STORAGE', period },
      });
      const current = usageLog?.quantity ?? 0;
      const limit = limits.maxStorage; // in MB
      return {
        allowed: current < limit,
        remaining: Math.max(0, limit - current),
        limit,
      };
    }

    case 'apiCalls': {
      const usageLog = await db.tenantUsageLog.findFirst({
        where: { tenantId, resourceType: 'API_CALL', period },
      });
      const current = usageLog?.quantity ?? 0;
      const limit = limits.maxApiCalls;
      return {
        allowed: current < limit,
        remaining: Math.max(0, limit - current),
        limit,
      };
    }

    default:
      return { allowed: false, remaining: 0, limit: 0 };
  }
}

// ─── resolveTenantFromRequest ───────────────────────────────────────────────

/**
 * Resolves a tenant from an incoming Request object by inspecting headers.
 *
 * Priority:
 * 1. `X-Tenant-Slug` header
 * 2. `X-Tenant-Domain` header
 *
 * Returns the resolved tenant record or null if not found.
 */
export async function resolveTenantFromRequest(
  request: Request
): Promise<ResolvedTenant | null> {
  try {
    const tenantSlug = request.headers.get('x-tenant-slug');
    const tenantDomain = request.headers.get('x-tenant-domain');

    let tenant = null;

    if (tenantSlug) {
      tenant = await db.tenant.findUnique({
        where: { slug: tenantSlug },
      });
    } else if (tenantDomain) {
      tenant = await db.tenant.findFirst({
        where: { domain: tenantDomain },
      });
    }

    if (!tenant) return null;

    return {
      id: tenant.id,
      name: tenant.name,
      slug: tenant.slug,
      domain: tenant.domain,
      plan: tenant.plan,
      status: tenant.status,
      primaryColor: tenant.primaryColor,
      locale: tenant.locale,
      maxUsers: tenant.maxUsers,
      maxStorage: tenant.maxStorage,
      maxApiCalls: tenant.maxApiCalls,
    };
  } catch {
    return null;
  }
}