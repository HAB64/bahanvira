import { createHash } from 'crypto';
import { cookies } from 'next/headers';
import { siteConfig } from '@/config/site';

const SESSION_COOKIE_NAME = 'admin_session';
const SESSION_SECRET = process.env.AUTH_SECRET || siteConfig.name.en.toLowerCase().replace(/\s+/g, '-') + '-admin-2024';

export function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

export function createSessionToken(username: string): string {
  const payload = JSON.stringify({ username, exp: Date.now() + 24 * 60 * 60 * 1000 });
  const token = Buffer.from(payload).toString('base64');
  const signature = createHash('sha256').update(token + SESSION_SECRET).digest('hex');
  return `${token}.${signature}`;
}

export function verifySessionToken(token: string): { username: string; exp: number } | null {
  try {
    const [tokenPart, signature] = token.split('.');
    const expectedSignature = createHash('sha256').update(tokenPart + SESSION_SECRET).digest('hex');
    if (signature !== expectedSignature) return null;

    const payload = JSON.parse(Buffer.from(tokenPart, 'base64').toString());
    if (payload.exp < Date.now()) return null;

    return payload;
  } catch {
    return null;
  }
}

export async function getAdminSession(): Promise<{ username: string } | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value;
  if (!token) return null;

  const session = verifySessionToken(token);
  if (!session) return null;

  return { username: session.username };
}

export async function setAdminSession(username: string) {
  const cookieStore = await cookies();
  const token = createSessionToken(username);
  cookieStore.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: false,
    sameSite: 'lax',
    maxAge: 24 * 60 * 60, // 24 hours
    path: '/',
  });
}

export async function clearAdminSession() {
  const cookieStore = await cookies();
  cookieStore.delete(SESSION_COOKIE_NAME);
}
