/**
 * CSV Export Utility
 * Generates CSV files with BOM for proper UTF-8 / Persian display in Excel
 */

interface CSVColumn {
  key: string;
  header: string; // Persian header
}

/**
 * Escapes a CSV value — wraps in quotes if it contains commas, quotes, or newlines
 */
function escapeCSVValue(value: unknown): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  // If the value contains a comma, double quote, or newline, wrap it in quotes
  if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    // Double up any existing double quotes
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Exports an array of objects as a CSV file download.
 *
 * @param data        Array of row objects
 * @param filename    Download file name (e.g. "leads.csv")
 * @param columns     Column definitions with key (object property) and header (Persian label)
 */
export function exportToCSV(
  data: Record<string, unknown>[],
  filename: string,
  columns: CSVColumn[]
): void {
  // Build header row
  const headerRow = columns.map((col) => escapeCSVValue(col.header)).join(',');

  // Build data rows
  const dataRows = data.map((row) =>
    columns
      .map((col) => {
        const raw = row[col.key];
        return escapeCSVValue(raw);
      })
      .join(',')
  );

  // Combine with BOM for Excel UTF-8 compatibility
  const csvContent = '\uFEFF' + headerRow + '\n' + dataRows.join('\n');

  // Create blob and trigger download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();

  // Clean up
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
