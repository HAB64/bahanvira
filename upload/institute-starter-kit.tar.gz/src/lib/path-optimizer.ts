/**
 * Path Optimizer — موتور بهینه‌سازی مسیر کاربران
 * فاز ۴: سیستم سایبرنتیک آموزشی
 *
 * تحلیل مسیرهای کاربران، شناسایی مسیرهای پرنرخ تبدیل، و ارائه پیشنهاد بهینه‌سازی
 */
import { db } from '@/lib/db'

// ─── Types ──────────────────────────────────────────────────

interface PathStep {
  page: string
  event: string
  timestamp: Date
  duration?: number
}

interface UserPath {
  sessionId: string
  steps: PathStep[]
  converted: boolean
  convertedAt?: Date
  totalTime: number
  bouncePage?: string
}

interface ConversionPath {
  path: string
  frequency: number
  conversionRate: number
  avgTimeToConvert: number
  avgSteps: number
}

interface PathBottleneck {
  page: string
  exitRate: number
  avgTimeOnPage: number
  dropOffReason: string
  suggestion: string
}

interface PathOptimizationResult {
  totalSessions: number
  convertedSessions: number
  overallConversionRate: number
  topConversionPaths: ConversionPath[]
  bottlenecks: PathBottleneck[]
  recommendations: string[]
  clusterPerformance: Record<string, { visits: number; conversions: number; rate: number }>
  pathEfficiencyScore: number
  lastAnalyzed: string
}

// ─── Core Functions ─────────────────────────────────────────

/**
 * استخراج مسیرهای کاربران از دیتابیس
 */
export async function extractUserPaths(days = 30): Promise<UserPath[]> {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000)

  // Get all behavior events in the period
  const events = await db.userBehavior.findMany({
    where: { createdAt: { gte: since } },
    orderBy: { createdAt: 'asc' },
    select: {
      sessionId: true,
      eventType: true,
      page: true,
      element: true,
      duration: true,
      cluster: true,
      courseSlug: true,
      createdAt: true,
      metadata: true,
    },
  })

  // Get conversion events (form submits, lead captures)
  const conversionEvents = await db.eventLog.findMany({
    where: {
      createdAt: { gte: since },
      event: { in: ['FORM_SUBMIT', 'LEAD_CAPTURED', 'lead.scored'] },
    },
    select: {
      sessionId: true,
      createdAt: true,
      event: true,
    },
  })

  // Also check leads created in this period
  const recentLeads = await db.lead.findMany({
    where: { createdAt: { gte: since } },
    select: { id: true, createdAt: true, source: true },
  })

  // Build a map of session -> events
  const sessionEvents = new Map<string, PathStep[]>()
  for (const event of events) {
    const steps = sessionEvents.get(event.sessionId) || []
    steps.push({
      page: event.page,
      event: event.eventType,
      timestamp: event.createdAt,
      duration: event.duration || undefined,
    })
    sessionEvents.set(event.sessionId, steps)
  }

  // Build a set of converted session IDs
  const convertedSessions = new Map<string, Date>()
  for (const ce of conversionEvents) {
    if (ce.sessionId) {
      const existing = convertedSessions.get(ce.sessionId)
      if (!existing || ce.createdAt < existing) {
        convertedSessions.set(ce.sessionId, ce.createdAt)
      }
    }
  }

  // Build user paths
  const paths: UserPath[] = []
  for (const [sessionId, steps] of sessionEvents) {
    const convertedAt = convertedSessions.get(sessionId)
    const totalTime = steps.reduce((sum, step) => {
      return sum + (step.duration || 30) // default 30s if no duration
    }, 0)

    // Detect bounce (only one page view, no interaction)
    const pageViews = steps.filter(s => s.event === 'PAGE_VIEW')
    const bouncePage = pageViews.length === 1 && steps.length <= 2
      ? pageViews[0].page
      : undefined

    paths.push({
      sessionId,
      steps,
      converted: !!convertedAt,
      convertedAt: convertedAt || undefined,
      totalTime,
      bouncePage,
    })
  }

  return paths
}

/**
 * شناسایی مسیرهای پرنرخ تبدیل
 */
export function analyzeConversionPaths(paths: UserPath[]): ConversionPath[] {
  // Group paths by their sequence of pages
  const pathCounts = new Map<string, { total: number; converted: number; times: number[]; stepCounts: number[] }>()

  for (const path of paths) {
    // Extract page sequence (deduplicated consecutive)
    const pageSequence: string[] = []
    for (const step of path.steps) {
      if (step.event === 'PAGE_VIEW') {
        if (pageSequence[pageSequence.length - 1] !== step.page) {
          pageSequence.push(step.page)
        }
      }
    }

    // Only consider paths with 2+ pages
    if (pageSequence.length < 2) continue

    // Normalize: keep first 4 pages max (to group similar paths)
    const key = pageSequence.slice(0, 4).join(' → ')

    const existing = pathCounts.get(key) || { total: 0, converted: 0, times: [], stepCounts: [] }
    existing.total++
    if (path.converted) {
      existing.converted++
      if (path.convertedAt) {
        const firstStep = path.steps[0]?.timestamp
        if (firstStep) {
          existing.times.push(path.convertedAt.getTime() - firstStep.getTime())
        }
      }
    }
    existing.stepCounts.push(pageSequence.length)
    pathCounts.set(key, existing)
  }

  // Convert to ConversionPath array and sort by frequency
  const result: ConversionPath[] = []
  for (const [path, data] of pathCounts) {
    if (data.total < 2) continue // Need at least 2 occurrences
    result.push({
      path,
      frequency: data.total,
      conversionRate: Math.round((data.converted / data.total) * 1000) / 10,
      avgTimeToConvert: data.times.length > 0
        ? Math.round(data.times.reduce((a, b) => a + b, 0) / data.times.length / 1000)
        : 0,
      avgSteps: data.stepCounts.length > 0
        ? Math.round(data.stepCounts.reduce((a, b) => a + b, 0) / data.stepCounts.length * 10) / 10
        : 0,
    })
  }

  return result.sort((a, b) => b.frequency - a.frequency)
}

/**
 * شناسایی گلوگاه‌ها در مسیر تبدیل
 */
export function identifyBottlenecks(paths: UserPath[]): PathBottleneck[] {
  // Calculate exit rates per page
  const pageStats = new Map<string, { enters: number; exits: number; totalTime: number; exitsWithoutConversion: number }>()

  for (const path of paths) {
    const pageViews = path.steps.filter(s => s.event === 'PAGE_VIEW')
    for (let i = 0; i < pageViews.length; i++) {
      const page = pageViews[i].page
      const stats = pageStats.get(page) || { enters: 0, exits: 0, totalTime: 0, exitsWithoutConversion: 0 }
      stats.enters++

      if (i === pageViews.length - 1) {
        // Last page = exit page
        stats.exits++
        if (!path.converted) {
          stats.exitsWithoutConversion++
        }
      }

      stats.totalTime += (pageViews[i].duration || 30)
      pageStats.set(page, stats)
    }
  }

  const bottlenecks: PathBottleneck[] = []
  for (const [page, stats] of pageStats) {
    if (stats.enters < 3) continue // Need minimum data

    const exitRate = Math.round((stats.exits / stats.enters) * 1000) / 10
    const avgTime = Math.round(stats.totalTime / stats.enters)

    if (exitRate > 40 || avgTime < 10) {
      // High exit rate or very low time = bottleneck
      let dropOffReason = ''
      let suggestion = ''

      if (avgTime < 10) {
        dropOffReason = 'مدت ماندگاری بسیار کوتاه'
        suggestion = 'بررسی محتوای صفحه و بهبود CTA اولیه'
      } else if (exitRate > 70) {
        dropOffReason = 'نرخ خروج بسیار بالا'
        suggestion = 'اضافه کردن پیشنهاد مرتبط یا فرم مشاوره سریع'
      } else if (exitRate > 40) {
        dropOffReason = 'نرخ خروج بالاتر از حد مطلوب'
        suggestion = 'بهبود ارتباط بصری با صفحه بعدی و افزودن CTA واضح'
      }

      bottlenecks.push({
        page,
        exitRate,
        avgTimeOnPage: avgTime,
        dropOffReason,
        suggestion,
      })
    }
  }

  return bottlenecks.sort((a, b) => b.exitRate - a.exitRate)
}

/**
 * تحلیل عملکرد خوشه‌ها
 */
export async function analyzeClusterPerformance(days = 30): Promise<Record<string, { visits: number; conversions: number; rate: number }>> {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000)

  const behaviors = await db.userBehavior.findMany({
    where: {
      createdAt: { gte: since },
      cluster: { not: '' },
    },
    select: { cluster: true, eventType: true, sessionId: true },
  })

  const leads = await db.lead.findMany({
    where: { createdAt: { gte: since } },
    select: { id: true, cluster: true },
  })

  // Count visits per cluster
  const visits = new Map<string, Set<string>>()
  for (const b of behaviors) {
    if (b.cluster) {
      const set = visits.get(b.cluster) || new Set()
      set.add(b.sessionId)
      visits.set(b.cluster, set)
    }
  }

  // Count conversions per cluster
  const conversions = new Map<string, number>()
  for (const l of leads) {
    if (l.cluster) {
      conversions.set(l.cluster, (conversions.get(l.cluster) || 0) + 1)
    }
  }

  const result: Record<string, { visits: number; conversions: number; rate: number }> = {}
  for (const [cluster, sessionSet] of visits) {
    const v = sessionSet.size
    const c = conversions.get(cluster) || 0
    result[cluster] = {
      visits: v,
      conversions: c,
      rate: v > 0 ? Math.round((c / v) * 1000) / 10 : 0,
    }
  }

  return result
}

/**
 * تولید پیشنهادات بهینه‌سازی
 */
function generateRecommendations(
  paths: UserPath[],
  conversionPaths: ConversionPath[],
  bottlenecks: PathBottleneck[],
  clusterPerf: Record<string, { visits: number; conversions: number; rate: number }>,
): string[] {
  const recommendations: string[] = []

  // 1. Based on top conversion path
  if (conversionPaths.length > 0) {
    const top = conversionPaths[0]
    if (top.conversionRate > 20) {
      recommendations.push(
        `مسیر "${top.path}" بالاترین نرخ تبدیل (${top.conversionRate}%) را دارد. این مسیر را در سایر خوشه‌ها نیز تکرار کنید.`
      )
    }
  }

  // 2. Based on bottlenecks
  for (const bn of bottlenecks.slice(0, 3)) {
    recommendations.push(
      `صفحه ${bn.page}: ${bn.dropOffReason} (نرخ خروج: ${bn.exitRate}%) — ${bn.suggestion}`
    )
  }

  // 3. Based on bounce rate
  const bouncedPaths = paths.filter(p => p.bouncePage)
  if (bouncedPaths.length > paths.length * 0.5) {
    recommendations.push(
      `نرخ Bounce بالا (${Math.round((bouncedPaths.length / paths.length) * 100)}%). بررسی تصویر Hero و CTA اولیه پیشنهاد می‌شود.`
    )
  }

  // 4. Based on cluster performance
  const clusterEntries = Object.entries(clusterPerf)
  if (clusterEntries.length >= 2) {
    clusterEntries.sort((a, b) => b[1].rate - a[1].rate)
    const best = clusterEntries[0]
    const worst = clusterEntries[clusterEntries.length - 1]
    if (best[1].rate > worst[1].rate * 2 && worst[1].visits > 5) {
      recommendations.push(
        `خوشه ${worst[0]} نرخ تبدیل پایینی دارد (${worst[1].rate}%). از الگوی خوشه ${best[0]} (${best[1].rate}%) برای بهبود استفاده کنید.`
      )
    }
  }

  // 5. Quiz effectiveness
  const quizCompleted = paths.filter(p =>
    p.steps.some(s => s.event === 'QUIZ_COMPLETE')
  )
  const quizConverted = quizCompleted.filter(p => p.converted)
  if (quizCompleted.length > 3) {
    const quizRate = Math.round((quizConverted.length / quizCompleted.length) * 1000) / 10
    if (quizRate > 15) {
      recommendations.push(
        `کوییز مسیردهی مؤثر است (نرخ تبدیل ${quizRate}%). نمایش کوییز را به صفحات خوشه نیز گسترش دهید.`
      )
    }
  }

  // 6. Chatbot contribution
  const chatStarted = paths.filter(p =>
    p.steps.some(s => s.event === 'CONSULTATION_START')
  )
  const chatConverted = chatStarted.filter(p => p.converted)
  if (chatStarted.length > 3) {
    const chatRate = Math.round((chatConverted.length / chatStarted.length) * 1000) / 10
    if (chatRate > 10) {
      recommendations.push(
        `چت‌بات مشاوره نرخ تبدیل ${chatRate}% دارد. دکمه مشاوره را در صفحات کلیدی برجسته‌تر کنید.`
      )
    }
  }

  return recommendations
}

/**
 * محاسبه امتیاز کارایی مسیر (0-100)
 */
function calculatePathEfficiency(
  paths: UserPath[],
  conversionPaths: ConversionPath[],
  bottlenecks: PathBottleneck[],
): number {
  if (paths.length === 0) return 50 // Default when no data

  // Factor 1: Overall conversion rate (0-30)
  const converted = paths.filter(p => p.converted).length
  const convRate = converted / paths.length
  const convScore = Math.min(convRate * 100, 30)

  // Factor 2: Best path conversion rate (0-25)
  const bestPathRate = conversionPaths.length > 0
    ? Math.max(...conversionPaths.map(p => p.conversionRate))
    : 0
  const pathScore = Math.min(bestPathRate * 1.2, 25)

  // Factor 3: Low bottleneck count (0-25)
  const severeBottlenecks = bottlenecks.filter(b => b.exitRate > 60).length
  const bottleneckScore = Math.max(25 - severeBottlenecks * 8, 0)

  // Factor 4: Low bounce rate (0-20)
  const bounceRate = paths.filter(p => p.bouncePage).length / paths.length
  const bounceScore = Math.max(20 - bounceRate * 40, 0)

  return Math.round(convScore + pathScore + bottleneckScore + bounceScore)
}

/**
 * تابع اصلی: تحلیل کامل مسیرها
 */
export async function runPathOptimization(days = 30): Promise<PathOptimizationResult> {
  const paths = await extractUserPaths(days)
  const conversionPaths = analyzeConversionPaths(paths)
  const bottlenecks = identifyBottlenecks(paths)
  const clusterPerformance = await analyzeClusterPerformance(days)
  const recommendations = generateRecommendations(paths, conversionPaths, bottlenecks, clusterPerformance)
  const pathEfficiencyScore = calculatePathEfficiency(paths, conversionPaths, bottlenecks)

  const totalSessions = paths.length
  const convertedSessions = paths.filter(p => p.converted).length

  return {
    totalSessions,
    convertedSessions,
    overallConversionRate: totalSessions > 0
      ? Math.round((convertedSessions / totalSessions) * 1000) / 10
      : 0,
    topConversionPaths: conversionPaths.slice(0, 5),
    bottlenecks: bottlenecks.slice(0, 5),
    recommendations,
    clusterPerformance,
    pathEfficiencyScore,
    lastAnalyzed: new Date().toISOString(),
  }
}