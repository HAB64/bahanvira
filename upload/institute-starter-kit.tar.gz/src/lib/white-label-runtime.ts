/**
 * White-Label Runtime
 *
 * Reads WhiteLabelConfig from DB and generates CSS variables,
 * branding config objects, and Next.js Metadata for per-tenant branding.
 */

import { db } from '@/lib/db';
import type { Metadata } from 'next';

// ─── Types ──────────────────────────────────────────────────────────────────

export interface TenantBranding {
  brandName: string;
  brandSlogan: string;
  logoUrl: string;
  faviconUrl: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
  borderRadius: number;
  customDomain: string;
  loginPageTitle: string;
  loginPageSubtitle: string;
  footerText: string;
  termsUrl: string;
  privacyUrl: string;
}

// ─── Defaults ───────────────────────────────────────────────────────────────

const DEFAULT_BRANDING: TenantBranding = {
  brandName: 'نمی آکادمی',
  brandSlogan: 'پلتفرم آموزشی هوشمند',
  logoUrl: '/logo-new.png',
  faviconUrl: '/logo-new.png',
  primaryColor: '#0d9488',
  secondaryColor: '#115e59',
  accentColor: '#f59e0b',
  fontFamily: 'Vazirmatn, system-ui, sans-serif',
  borderRadius: 8,
  customDomain: '',
  loginPageTitle: 'ورود به پنل مدیریت',
  loginPageSubtitle: 'لطفاً اطلاعات ورود خود را وارد کنید',
  footerText: 'تمامی حقوق محفوظ است.',
  termsUrl: '/terms',
  privacyUrl: '/privacy',
};

// ─── getTenantBranding ──────────────────────────────────────────────────────

/**
 * Fetches WhiteLabelConfig for a tenant and returns a fully-resolved
 * TenantBranding object. Falls back to defaults for missing fields.
 *
 * If no tenantId is provided, looks for a default (no-tenant) config.
 */
export async function getTenantBranding(
  tenantId?: string | null
): Promise<TenantBranding> {
  try {
    const config = tenantId
      ? await db.whiteLabelConfig.findUnique({
          where: { tenantId },
        })
      : await db.whiteLabelConfig.findFirst({
          where: { isActive: true },
        });

    if (!config || !config.isActive) {
      return { ...DEFAULT_BRANDING };
    }

    return {
      brandName: config.brandName || DEFAULT_BRANDING.brandName,
      brandSlogan: config.brandSlogan || DEFAULT_BRANDING.brandSlogan,
      logoUrl: DEFAULT_BRANDING.logoUrl,
      faviconUrl: DEFAULT_BRANDING.faviconUrl,
      primaryColor: config.primaryColor || DEFAULT_BRANDING.primaryColor,
      secondaryColor: config.secondaryColor || DEFAULT_BRANDING.secondaryColor,
      accentColor: config.accentColor || DEFAULT_BRANDING.accentColor,
      fontFamily: config.fontFamily || DEFAULT_BRANDING.fontFamily,
      borderRadius: config.borderRadius ?? DEFAULT_BRANDING.borderRadius,
      customDomain: config.customDomain || DEFAULT_BRANDING.customDomain,
      loginPageTitle: DEFAULT_BRANDING.loginPageTitle,
      loginPageSubtitle: DEFAULT_BRANDING.loginPageSubtitle,
      footerText: DEFAULT_BRANDING.footerText,
      termsUrl: DEFAULT_BRANDING.termsUrl,
      privacyUrl: DEFAULT_BRANDING.privacyUrl,
    };
  } catch {
    return { ...DEFAULT_BRANDING };
  }
}

// ─── generateCSSVars ────────────────────────────────────────────────────────

/**
 * Takes a TenantBranding object and returns a string of CSS custom properties
 * ready to be injected into a <style> tag or :root block.
 */
export function generateCSSVars(branding: TenantBranding): string {
  return `
    --brand-primary: ${branding.primaryColor};
    --brand-secondary: ${branding.secondaryColor};
    --brand-accent: ${branding.accentColor};
    --brand-font-family: ${branding.fontFamily};
    --brand-radius: ${branding.borderRadius}px;
  `.trim();
}

// ─── generateMetadata ───────────────────────────────────────────────────────

/**
 * Returns a Next.js Metadata object based on tenant branding.
 * Useful for per-tenant dynamic metadata in layouts/pages.
 */
export function generateMetadata(branding: TenantBranding): Metadata {
  return {
    title: {
      default: branding.brandName,
      template: `%s | ${branding.brandName}`,
    },
    description: branding.brandSlogan,
    icons: {
      icon: branding.faviconUrl,
    },
    metadataBase: branding.customDomain
      ? new URL(`https://${branding.customDomain}`)
      : undefined,
    openGraph: {
      title: branding.brandName,
      description: branding.brandSlogan,
      siteName: branding.brandName,
    },
  };
}