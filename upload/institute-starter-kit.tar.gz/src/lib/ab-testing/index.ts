/**
 * A/B Testing — Client-safe utilities
 * این فایل هیچ وابستگی سمت سرور ندارد و در Client Components قابل استفاده است
 */

// ─── Types ──────────────────────────────────────────────────────

export interface Experiment {
  id: string;
  name: string;
  description: string;
  variants: Variant[];
  isActive: boolean;
  startDate: string;
  endDate?: string;
  trafficPct: number;
}

export interface Variant {
  id: string;
  label: string;
  weight: number;
  description: string;
}

export interface ExperimentResult {
  experimentId: string;
  variantId: string;
  exposures: number;
  conversions: number;
  conversionRate: number;
}

// ─── Defined Experiments ────────────────────────────────────────

export const EXPERIMENTS: Experiment[] = [
  {
    id: 'header-mega-menu',
    name: 'مگامنو vs منوی ساده',
    description: 'مقایسه هدر با مگامنو (مسیر شغلی + خوشه) vs هدر با منوی ساده',
    variants: [
      { id: 'mega', label: 'مگامنو (جدید)', weight: 50, description: 'هدر با ۲ مگامنوی مسیر شغلی و خوشه مهارتی' },
      { id: 'simple', label: 'منوی ساده (کنترل)', weight: 50, description: 'هدر با منوی ساده دوره‌ها' },
    ],
    isActive: true,
    startDate: '2025-01-01',
    trafficPct: 100,
  },
  {
    id: 'cta-color',
    name: 'رنگ دکمه CTA',
    description: 'مقایسه رنگ دکمه مشاوره رایگان: teal vs orange',
    variants: [
      { id: 'teal', label: 'Teal (فعلی)', weight: 50, description: 'دکمه gradient سبز آبی' },
      { id: 'orange', label: 'Orange', weight: 50, description: 'دکمه gradient نارنجی طلایی' },
    ],
    isActive: true,
    startDate: '2025-01-01',
    trafficPct: 50,
  },
  {
    id: 'hero-layout',
    name: 'چیدمان Hero',
    description: 'مقایسه Hero با کوییز vs Hero با معرفی',
    variants: [
      { id: 'quiz-first', label: 'کوییز اول', weight: 50, description: 'Hero با دکمه کوییز شغلی برجسته' },
      { id: 'intro-first', label: 'معرفی اول', weight: 50, description: 'Hero با معرفی آموزشگاه برجسته' },
    ],
    isActive: false,
    startDate: '2025-02-01',
    trafficPct: 100,
  },
];

// ─── Deterministic Variant Assignment ───────────────────────────

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

export function getVariantForUser(
  experimentId: string,
  userId: string
): string | null {
  const experiment = EXPERIMENTS.find(e => e.id === experimentId);
  if (!experiment || !experiment.isActive) return null;

  const trafficHash = hashString(`${experimentId}:traffic:${userId}`) % 100;
  if (trafficHash >= experiment.trafficPct) return null;

  const variantHash = hashString(`${experimentId}:variant:${userId}`) % 100;
  let cumulative = 0;
  for (const variant of experiment.variants) {
    cumulative += variant.weight;
    if (variantHash < cumulative) {
      return variant.id;
    }
  }

  return experiment.variants[0]?.id || null;
}

// ─── Client-side Helper ─────────────────────────────────────────

/**
 * دریافت variant در Client Component
 * ابتدا cookie را چک می‌کند، سپس تخصیص می‌دهد
 */
export function getExperimentVariantClient(
  experimentId: string,
  sessionId?: string
): string | null {
  if (typeof document === 'undefined') return null;

  const cookieName = `ab_${experimentId}`;

  // Check existing cookie
  const cookies = document.cookie.split(';');
  for (const cookie of cookies) {
    const [name, value] = cookie.trim().split('=');
    if (name === cookieName && value) return value;
  }

  // Assign new variant
  const sid = sessionId || 'anonymous';
  const variant = getVariantForUser(experimentId, sid);

  // Save to cookie (30 days)
  if (variant) {
    document.cookie = `${cookieName}=${variant};path=/;max-age=${30 * 86400};SameSite=Lax`;
  }

  return variant;
}

// ─── Client-side Tracking (via API) ─────────────────────────────

/**
 * ثبت رویداد exposure از طریق API
 */
export function trackExposure(
  experimentId: string,
  variantId: string
): void {
  if (typeof fetch === 'undefined') return;
  fetch('/api/ab-track', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ experimentId, variantId, event: 'exposure' }),
    keepalive: true,
  }).catch(() => {});
}

/**
 * ثبت رویداد conversion از طریق API
 */
export function trackConversion(
  experimentId: string,
  variantId: string,
  conversionType: string = 'generic'
): void {
  if (typeof fetch === 'undefined') return;
  fetch('/api/ab-track', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ experimentId, variantId, event: 'conversion', conversionType }),
    keepalive: true,
  }).catch(() => {});
}
