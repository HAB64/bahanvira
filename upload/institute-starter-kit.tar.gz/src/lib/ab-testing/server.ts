/**
 * A/B Testing — Server-only utilities
 * فقط در Server Components و API Routes قابل استفاده است
 */

import { cookies } from 'next/headers';
import { getVariantForUser, EXPERIMENTS, type ExperimentResult } from './index';

/**
 * دریافت variant از cookie یا تخصیص جدید (Server Component)
 */
export async function getExperimentVariant(
  experimentId: string
): Promise<string | null> {
  try {
    const cookieStore = await cookies();
    const cookieName = `ab_${experimentId}`;
    const existing = cookieStore.get(cookieName)?.value;

    if (existing) return existing;

    const sessionId = cookieStore.get('br_session')?.value || 'anonymous';
    const variant = getVariantForUser(experimentId, sessionId);

    return variant;
  } catch {
    return null;
  }
}

/**
 * دریافت نتایج آزمایش (Server-side)
 */
export async function getExperimentResults(
  experimentId: string
): Promise<ExperimentResult[]> {
  const experiment = EXPERIMENTS.find(e => e.id === experimentId);
  if (!experiment) return [];

  try {
    const { db } = await import('@/lib/db');

    const results: ExperimentResult[] = [];

    for (const variant of experiment.variants) {
      const [exposures, conversions] = await Promise.all([
        db.eventLog.count({
          where: { type: `AB_EXPOSURE_${experimentId}`, data: { path: ['variantId'], equals: variant.id } },
        }),
        db.eventLog.count({
          where: { type: `AB_CONVERSION_${experimentId}`, data: { path: ['variantId'], equals: variant.id } },
        }),
      ]);

      results.push({
        experimentId,
        variantId: variant.id,
        exposures,
        conversions,
        conversionRate: exposures > 0 ? Math.round((conversions / exposures) * 10000) / 100 : 0,
      });
    }

    return results;
  } catch {
    return [];
  }
}
