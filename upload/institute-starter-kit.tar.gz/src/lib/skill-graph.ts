// ==========================================
// Skill Graph & Matchmaking Engine (گراف مهارت و مسیریابی)
// ==========================================
// ساختار سه‌سطحی استاندارد TVTO:
//   گروه آموزشی (Group) → رشته (Field) → حرفه (Occupation/Course)
// ==========================================

// ─── Three-Level Hierarchy Types ──────────────────────────────

export type GroupKey =
  | 'it'                          // فناوری اطلاعات
  | 'ai'                          // هوش مصنوعی و علوم داده
  | 'graphic-design'              // گرافیک و طراحی دیجیتال
  | 'architecture'                // معماری و نقشه‌کشی
  | 'finance'                     // امور مالی، بازرگانی و حسابداری
  | 'entrepreneurship-and-business' // کارآفرینی و کسب‌وکار
  | 'capital-market'              // بازار سرمایه
  | 'educational-services'        // خدمات آموزشی
  | 'legal-services'              // خدمات حقوقی

export interface TrainingGroup {
  key: GroupKey
  label: string
  description: string
  color: string
  icon: string        // lucide icon name
}

export interface TrainingField {
  key: string
  groupKey: GroupKey
  label: string
  description: string
}

export interface Occupation {
  slug: string
  fieldKey: string
  groupKey: GroupKey
  title: string
  level: BloomLevel
  duration: string
  description: string
  tags: string[]
  prerequisites: string[]
}

// ─── Legacy Compatibility Types ───────────────────────────────
// These types map the old 4-cluster system to the new 6-group system
// for backward compatibility with existing code (Header, APIs, etc.)

export type ClusterKey = GroupKey

export type BloomLevel = 'FOUNDATION' | 'SPECIALIZED' | 'STRATEGIC'

export interface SkillNode {
  slug: string
  title: string
  cluster: ClusterKey
  level: BloomLevel
  tags: string[]
  prerequisites: string[]
  duration: string
  description: string
}

export interface MatchmakingInput {
  age?: number
  interests: string[]
  goal: string
  source?: string
}

export interface RecommendedProgram {
  slug: string
  title: string
  cluster: ClusterKey
  level: BloomLevel
  matchScore: number
  reason: string
}

export interface RoadmapStep {
  step: number
  title: string
  description: string
  duration: string
}

export interface MatchmakingResult {
  recommendedPrograms: RecommendedProgram[]
  roadmapSteps: RoadmapStep[]
  confidenceScore: number
}

// ─── ۹ گروه آموزشی (Training Groups) ─────────────────────────

export const GROUPS: Record<GroupKey, TrainingGroup> = {
  'it': {
    key: 'it',
    label: 'فناوری اطلاعات',
    description: 'ICDL، برنامه‌نویسی، طراحی وب و نرم‌افزارهای اداری',
    color: '#0d9488',
    icon: 'Cpu',
  },
  'ai': {
    key: 'ai',
    label: 'هوش مصنوعی و علوم داده',
    description: 'اکوسیستم AI محلی: Ollama، n8n، AI Agents، یادگیری ماشین، علوم داده و پایتون',
    color: '#8B5CF6',
    icon: 'Brain',
  },
  'graphic-design': {
    key: 'graphic-design',
    label: 'گرافیک و طراحی دیجیتال',
    description: 'فتوشاپ، کورل‌دراو، سه‌بعدی‌سازی',
    color: '#dc2626',
    icon: 'Palette',
  },
  'architecture': {
    key: 'architecture',
    label: 'معماری و نقشه‌کشی',
    description: 'اتوکد، نقشه‌کشی ساختمان، طراحی داخلی',
    color: '#7c3aed',
    icon: 'PenTool',
  },
  'finance': {
    key: 'finance',
    label: 'امور مالی، بازرگانی و حسابداری',
    description: 'حسابداری مالی، اصول بازرگانی، بازارهای مالی و فارکس',
    color: '#d97706',
    icon: 'TrendingUp',
  },
  'entrepreneurship-and-business': {
    key: 'entrepreneurship-and-business',
    label: 'کارآفرینی و کسب‌وکار',
    description: 'کارآفرینی، مشاوره کسب‌وکار، مدیریت زمان و ارتباطات، مهارت‌های فردی و سازمانی',
    color: '#6366f1',
    icon: 'Rocket',
  },
  'capital-market': {
    key: 'capital-market',
    label: 'بازار سرمایه',
    description: 'آشنایی با بازار سرمایه، تحلیل تکنیکال و بنیادی، تابلوخوانی، مدیریت پرتفوی',
    color: '#0284c7',
    icon: 'CandlestickChart',
  },
  'educational-services': {
    key: 'educational-services',
    label: 'خدمات آموزشی',
    description: 'پداگوژی، فن بیان، طراحی دوره آموزشی، مدیریت کلاس و LMS',
    color: '#059669',
    icon: 'GraduationCap',
  },
  'legal-services': {
    key: 'legal-services',
    label: 'خدمات حقوقی',
    description: 'قراردادنویسی، مشاور حقوقی، نگارش قضایی، خدمات الکترونیک قضایی',
    color: '#b91c1c',
    icon: 'Scale',
  },
}

// ─── رشته‌ها (Fields) ─────────────────────────────────────────

export const FIELDS: TrainingField[] = [
  // ─── گروه فناوری اطلاعات ───
  { key: 'icdl', groupKey: 'it', label: 'کاربر رایانه (ICDL)', description: 'گواهینامه بین‌المللی مهارت‌های رایانه‌ای' },
  { key: 'office', groupKey: 'it', label: 'نرم‌افزارهای اداری (Office)', description: 'اکسل، وورد، پاورپوینت، اکسس' },
  { key: 'programming', groupKey: 'it', label: 'برنامه‌نویسی', description: 'HTML، JavaScript، C++، Java، C#، Matlab' },
  { key: 'web-design', groupKey: 'it', label: 'طراحی وب', description: 'طراحی صفحات وب و Dreamweaver' },
  { key: 'ai-data-science', groupKey: 'ai', label: 'هوش مصنوعی و علوم داده', description: 'پایتون، ML، DL، Data Science، الگوریتم' },
  { key: 'local-ai-agents', groupKey: 'ai', label: 'هوش مصنوعی محلی و عامل‌های هوشمند', description: 'Ollama، n8n، AI Agents، MCP، اتوماسیون فرآیندها' },
  { key: 'creative-coding', groupKey: 'ai', label: 'برنامه‌نویسی خلاق کودکان و نوجوانان', description: 'اسکرچ، هوش مصنوعی برای نوجوانان' },

  // ─── گروه گرافیک و طراحی دیجیتال ───
  { key: 'computer-graphics', groupKey: 'graphic-design', label: 'گرافیک رایانه‌ای', description: 'فتوشاپ، کورل‌دراو، InDesign' },
  { key: '3d-modeling', groupKey: 'graphic-design', label: 'سه‌بعدی‌سازی (3D)', description: '3D Max و نقشه‌کشی سه‌بعدی' },

  // ─── گروه معماری و نقشه‌کشی ───
  { key: 'building-drafting', groupKey: 'architecture', label: 'نقشه‌کشی ساختمان', description: 'نقشه‌کشی ساختمان درجه ۱ و ۲' },
  { key: 'cad-software', groupKey: 'architecture', label: 'نقشه‌کشی با نرم‌افزار', description: 'اتوکد دو‌بعدی و سه‌بعدی' },
  { key: 'interior-design', groupKey: 'architecture', label: 'طراحی داخلی', description: 'طراحی معماری داخلی' },

  // ─── گروه امور مالی، بازرگانی و حسابداری ───
  { key: 'financial-accounting', groupKey: 'finance', label: 'حسابداری مالی', description: 'حسابداری مالی و کار عملی' },
  { key: 'cost-accounting', groupKey: 'finance', label: 'هزینه‌ها', description: 'هزینه‌های گوناگون و هزینه گذشته سازمان' },
  { key: 'finance-basics', groupKey: 'finance', label: 'اصول مالی و بازرگانی', description: 'اصول مالی، بازرگانی درجه ۱ و ۲' },

  // ─── گروه کارآفرینی و کسب‌وکار ───
  { key: 'personal-org-skills', groupKey: 'entrepreneurship-and-business', label: 'مهارت‌های فردی و سازمانی', description: 'مدیریت زمان، مالی، استرس، ارتباطات' },
  { key: 'entrepreneurship-field', groupKey: 'entrepreneurship-and-business', label: 'کارآفرینی و راه‌اندازی کسب‌وکار', description: 'کارآفرینی، مشاوره کسب‌وکار، استارتاپ' },

  // ─── گروه بازار سرمایه ───
  { key: 'capital-market-intro', groupKey: 'capital-market', label: 'آشنایی با بازار سرمایه', description: 'مفاهیم پایه بازار سرمایه و اوراق بهادار' },
  { key: 'capital-market-principles', groupKey: 'capital-market', label: 'اصول بازار سرمایه', description: 'اصول و مقررات بازار سرمایه' },
  { key: 'technical-analysis', groupKey: 'capital-market', label: 'تحلیل تکنیکال', description: 'تحلیل تکنیکال و_chart reading' },
  { key: 'fundamental-analysis', groupKey: 'capital-market', label: 'تحلیل بنیادی', description: 'تحلیل بنیادی و گزارش‌های مالی شرکت‌ها' },
  { key: 'board-reading', groupKey: 'capital-market', label: 'تابلوخوانی و روانشناسی', description: 'تابلوخوانی، روانشناسی بازار و مدیریت احساسات' },
  { key: 'portfolio-management', groupKey: 'capital-market', label: 'مدیریت سرمایه و پرتفوی', description: 'مدیریت سرمایه، تنوع‌بخشی و ساخت پرتفوی' },

  // ─── گروه خدمات آموزشی ───
  { key: 'pedagogy', groupKey: 'educational-services', label: 'پداگوژی و روش تدریس', description: 'روش‌های تدریس مدرن و یادگیری فعال' },
  { key: 'presentation-skills', groupKey: 'educational-services', label: 'فن بیان و مهارت ارائه', description: 'فن بیان، مهارت ارائه و ارتباط مؤثر در کلاس' },
  { key: 'course-design-lms', groupKey: 'educational-services', label: 'طراحی دوره و LMS', description: 'طراحی دوره آموزشی و مدیریت سیستم یادگیری' },

  // ─── گروه خدمات حقوقی ───
  { key: 'contract-writing', groupKey: 'legal-services', label: 'قراردادنویسی', description: 'تنظیم قراردادهای حقوقی و تجاری' },
  { key: 'legal-consulting', groupKey: 'legal-services', label: 'مشاور حقوقی', description: 'مشاوره حقوقی در امور مدنی و تجاری' },
  { key: 'judicial-writing', groupKey: 'legal-services', label: 'نگارش قضایی', description: 'نگارش لایحه و دادخواست قضایی' },
  { key: 'judicial-e-services', groupKey: 'legal-services', label: 'خدمات الکترونیک قضایی', description: 'استفاده از خدمات الکترونیک قضایی و ثنا' },
]

// ─── حرفه‌ها / دوره‌ها (Occupations / Courses) ────────────────

export const OCCUPATIONS: Occupation[] = [
  // ═══════════════════════════════════════════════════════════
  // گروه فناوری اطلاعات (IT)
  // ═══════════════════════════════════════════════════════════

  // ─── رشته: کاربر رایانه (ICDL) ───
  {
    slug: 'icdl',
    fieldKey: 'icdl', groupKey: 'it',
    title: 'رایانه‌کار ICDL',
    level: 'FOUNDATION',
    tags: ['icdl', 'آی‌سی‌دی‌ال', 'کامپیوتر', 'رایانه', 'office', 'وورد', 'اکسل', 'مبانی کامپیوتر', 'دیپلم کامپیوتر', 'استخدام دولتی'],
    prerequisites: [],
    duration: '۶۰ ساعته',
    description: 'گواهینامه بین‌المللی مهارت‌های رایانه‌ای — پایه ورود به بازار کار',
  },
  {
    slug: 'e-citizen',
    fieldKey: 'icdl', groupKey: 'it',
    title: 'E-Citizen',
    level: 'FOUNDATION',
    tags: ['e-citizen', 'ای-سیتیزن', 'شهروندی الکترونیک', 'اینترنت', 'خدمات دیجیتال'],
    prerequisites: [],
    duration: '۲۰ ساعته',
    description: 'شهروندی الکترونیک — مهارت‌های پایه استفاده از خدمات دیجیتال',
  },
  {
    slug: 'computer-user-2',
    fieldKey: 'icdl', groupKey: 'it',
    title: 'کارور رایانه درجه ۲',
    level: 'FOUNDATION',
    tags: ['کارور', 'رایانه درجه ۲', 'کامپیوتر مقدماتی', 'سواد رایانه‌ای'],
    prerequisites: [],
    duration: '۴۰ ساعته',
    description: 'مهارت‌های رایانه‌ای سطح ۲ — مکمل ICDL',
  },

  // ─── رشته: نرم‌افزارهای اداری (Office) ───
  {
    slug: 'excel',
    fieldKey: 'office', groupKey: 'it',
    title: 'کاربر Excel',
    level: 'SPECIALIZED',
    tags: ['excel', 'اکسل', 'جدول', 'فرمول‌نویسی', 'تحلیل داده', 'پیوت', 'نمودار'],
    prerequisites: ['icdl'],
    duration: '۲۴ ساعته',
    description: 'تسلط حرفه‌ای بر اکسل — از فرمول‌نویسی تا تحلیل داده',
  },
  {
    slug: 'access',
    fieldKey: 'office', groupKey: 'it',
    title: 'کاربر Access',
    level: 'SPECIALIZED',
    tags: ['access', 'اکسس', 'پایگاه داده', 'دیتابیس', 'کوئری', 'فرم'],
    prerequisites: ['icdl'],
    duration: '۲۰ ساعته',
    description: 'طراحی و مدیریت پایگاه داده با Microsoft Access',
  },
  {
    slug: 'word',
    fieldKey: 'office', groupKey: 'it',
    title: 'کاربر Word',
    level: 'SPECIALIZED',
    tags: ['word', 'وورد', 'متن', 'سند', 'نامه‌نگاری', 'قالب‌بندی'],
    prerequisites: ['icdl'],
    duration: '۱۶ ساعته',
    description: 'اداره حرفه‌ای اسناد و مکاتبات با Microsoft Word',
  },
  {
    slug: 'powerpoint',
    fieldKey: 'office', groupKey: 'it',
    title: 'کاربر PowerPoint',
    level: 'SPECIALIZED',
    tags: ['powerpoint', 'پاورپوینت', 'ارائه', 'پرزنتیشن', 'اسلاید', 'پیشرفت'],
    prerequisites: ['icdl'],
    duration: '۱۶ ساعته',
    description: 'ساخت ارائه‌های حرفه‌ای و جذاب با PowerPoint',
  },

  // ─── رشته: برنامه‌نویسی ───
  {
    slug: 'html',
    fieldKey: 'programming', groupKey: 'it',
    title: 'HTML',
    level: 'FOUNDATION',
    tags: ['html', 'اچ‌تی‌ام‌ال', 'وب', 'صفحه وب', 'ساختار', 'فرانت‌اند'],
    prerequisites: [],
    duration: '۱۶ ساعته',
    description: 'زبان نشانه‌گذاری وب — پایه طراحی صفحات اینترنتی',
  },
  {
    slug: 'javascript',
    fieldKey: 'programming', groupKey: 'it',
    title: 'JavaScript',
    level: 'SPECIALIZED',
    tags: ['javascript', 'جاواسکریپت', 'js', 'فرانت‌اند', 'وب', 'تعاملی', 'داینامیک'],
    prerequisites: ['html'],
    duration: '۳۲ ساعته',
    description: 'برنامه‌نویسی تعاملی وب — از DOM تا API',
  },
  {
    slug: 'cpp',
    fieldKey: 'programming', groupKey: 'it',
    title: '++C مقدماتی',
    level: 'SPECIALIZED',
    tags: ['c++', 'سی‌پلاس‌پلاس', 'برنامه‌نویسی', 'الگوریتم', 'شی‌گرا', 'oop'],
    prerequisites: [],
    duration: '۳۶ ساعته',
    description: 'مبانی برنامه‌نویسی ساختاریافته و شی‌گرا با ++C',
  },
  {
    slug: 'java-core',
    fieldKey: 'programming', groupKey: 'it',
    title: 'Java Core',
    level: 'SPECIALIZED',
    tags: ['java', 'جاوا', 'oop', 'شی‌گرا', 'اندروید', 'اپلیکیشن'],
    prerequisites: [],
    duration: '۴۰ ساعته',
    description: 'هسته جاوا — برنامه‌نویسی شی‌گرا و ساخت اپلیکیشن',
  },
  {
    slug: 'csharp-windows',
    fieldKey: 'programming', groupKey: 'it',
    title: 'C# Windows Application',
    level: 'SPECIALIZED',
    tags: ['c#', 'سی‌شارپ', 'ویندوز', 'فرم', 'دسکتاپ', 'dotnet', '.net'],
    prerequisites: [],
    duration: '۳۶ ساعته',
    description: 'ساخت اپلیکیشن ویندوزی با C# و .NET',
  },
  {
    slug: 'matlab',
    fieldKey: 'programming', groupKey: 'it',
    title: 'Matlab',
    level: 'SPECIALIZED',
    tags: ['matlab', 'متلب', 'محاسبات', 'ریاضی', 'شبیه‌سازی', 'مهندسی'],
    prerequisites: [],
    duration: '۲۸ ساعته',
    description: 'محاسبات عددی و شبیه‌سازی مهندسی با Matlab',
  },

  // ─── رشته: طراحی وب ───
  {
    slug: 'web-design',
    fieldKey: 'web-design', groupKey: 'it',
    title: 'طراحی صفحات وب',
    level: 'SPECIALIZED',
    tags: ['طراحی وب', 'وب‌سایت', 'html', 'css', 'فرانت‌اند', 'ریسپانسیو'],
    prerequisites: ['html'],
    duration: '۳۲ ساعته',
    description: 'طراحی وب‌سایت‌های مدرن و ریسپانسیو',
  },
  {
    slug: 'dreamweaver',
    fieldKey: 'web-design', groupKey: 'it',
    title: 'Dreamweaver',
    level: 'SPECIALIZED',
    tags: ['dreamweaver', 'دрим‌ویور', 'ادوبی', 'وب', 'طراحی سایت', 'کدنویسی بصری'],
    prerequisites: [],
    duration: '۲۰ ساعته',
    description: 'طراحی بصری وب‌سایت با Adobe Dreamweaver',
  },

  // ─── رشته: هوش مصنوعی و علوم داده ───
  {
    slug: 'cs-fundamentals',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'مبانی علوم کامپیوتر',
    level: 'FOUNDATION',
    tags: ['cs', 'علوم کامپیوتر', 'مبانی', 'کامپیوتر', 'الگوریتم', 'ساختار داده'],
    prerequisites: [],
    duration: '۲۰ ساعته',
    description: 'مبانی علوم کامپیوتر — پیش‌نیاز مسیر هوش مصنوعی',
  },
  {
    slug: 'python',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'پایتون مقدماتی',
    level: 'FOUNDATION',
    tags: ['python', 'پایتون', 'برنامه‌نویسی', 'کدنویسی', 'هوش مصنوعی', 'داده', 'تحلیل داده', 'مبتدی'],
    prerequisites: ['cs-fundamentals'],
    duration: '۴۰ ساعته',
    description: 'یادگیری یکی از پرتقاضاترین زبان‌های برنامه‌نویسی جهان',
  },
  {
    slug: 'python-advanced',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'پایتون پیشرفته',
    level: 'SPECIALIZED',
    tags: ['python', 'پایتون پیشرفته', 'oop', 'decorator', 'async', 'generator', 'تخصصی'],
    prerequisites: ['python'],
    duration: '۳۲ ساعته',
    description: 'تعمیق مهارت پایتون — OOP، async، الگوهای پیشرفته',
  },
  {
    slug: 'ai-python',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'هوش مصنوعی با پایتون',
    level: 'STRATEGIC',
    tags: ['ai', 'هوش مصنوعی', 'پایتون', 'مدل', 'پیش‌بینی', 'یادگیری', 'اتوماسیون هوشمند'],
    prerequisites: ['python-advanced'],
    duration: '۳۶ ساعته',
    description: 'ساخت مدل‌های هوش مصنوعی عملیاتی با پایتون',
  },
  {
    slug: 'machine-learning',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'یادگیری ماشین (ML)',
    level: 'STRATEGIC',
    tags: ['ml', 'machine learning', 'یادگیری ماشین', 'مدل', 'رگرسیون', 'کلاسیفیکیشن', 'sklearn'],
    prerequisites: ['python-advanced'],
    duration: '۴۰ ساعته',
    description: 'الگوریتم‌های یادگیری ماشین — از رگرسیون تا ensemble',
  },
  {
    slug: 'deep-learning',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'یادگیری عمیق و شبکه‌های عصبی',
    level: 'STRATEGIC',
    tags: ['deep learning', 'یادگیری عمیق', 'شبکه عصبی', 'cnn', 'rnn', 'tensorflow', 'pytorch'],
    prerequisites: ['machine-learning'],
    duration: '۴۰ ساعته',
    description: 'شبکه‌های عصبی عمیق — از CNN تا Transformer',
  },
  {
    slug: 'data-science',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'علم داده (Data Science)',
    level: 'STRATEGIC',
    tags: ['data science', 'علم داده', 'تحلیل', 'ویژوالایز', 'آمار', 'datalytika'],
    prerequisites: ['python-advanced'],
    duration: '۳۶ ساعته',
    description: 'فرآیند کامل علم داده — از جمع‌آوری تا استخراج بینش',
  },
  {
    slug: 'numpy-pandas',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'تحلیل داده با NumPy / Pandas',
    level: 'SPECIALIZED',
    tags: ['numpy', 'pandas', 'نام‌پای', 'پانداز', 'دیتافریم', 'تحلیل داده', 'آمار'],
    prerequisites: ['python'],
    duration: '۲۴ ساعته',
    description: 'ابزارهای حرفه‌ای تحلیل داده — NumPy و Pandas',
  },
  {
    slug: 'algorithms',
    fieldKey: 'ai-data-science', groupKey: 'ai',
    title: 'طراحی الگوریتم و تفکر محاسباتی',
    level: 'SPECIALIZED',
    tags: ['الگوریتم', 'طراحی الگوریتم', 'تفکر محاسباتی', 'ساختار داده', 'بهینه‌سازی'],
    prerequisites: ['cs-fundamentals'],
    duration: '۲۸ ساعته',
    description: 'تفکر محاسباتی و طراحی الگوریتم — مهارت بنیادین CS',
  },

  // ─── رشته: هوش مصنوعی محلی و عامل‌های هوشمند ───
  {
    slug: 'local-ai-ollama',
    fieldKey: 'local-ai-agents', groupKey: 'ai',
    title: 'هوش مصنوعی محلی (Ollama)',
    level: 'STRATEGIC',
    tags: ['ollama', 'local ai', 'AI محلی', 'LLM', 'مدل زبانی', 'سرور خصوصی', 'حریم خصوصی'],
    prerequisites: ['python-advanced'],
    duration: '۴۰ ساعته',
    description: 'اجرای مدل‌های زبانی بزرگ روی سرور شخصی با Ollama — بدون وابستگی به اینترنت',
  },
  {
    slug: 'ai-agents-n8n',
    fieldKey: 'local-ai-agents', groupKey: 'ai',
    title: 'عامل‌های هوشمند و اتوماسیون (n8n)',
    level: 'STRATEGIC',
    tags: ['n8n', 'AI Agents', 'اتوماسیون', 'عامل هوشمند', 'workflow', 'MCP', 'خودکارسازی'],
    prerequisites: ['python'],
    duration: '۳۵ ساعته',
    description: 'ساخت عامل‌های هوشمند و فرآیندهای خودکار با n8n و ابزارهای MCP',
  },
  {
    slug: 'claude-code-dev',
    fieldKey: 'local-ai-agents', groupKey: 'ai',
    title: 'توسعه با کمک AI (Claude Code)',
    level: 'SPECIALIZED',
    tags: ['claude code', 'AI development', 'توسعه با AI', 'کدنویسی هوشمند', 'MVP', 'copilot'],
    prerequisites: ['python'],
    duration: '۲۸ ساعته',
    description: 'توسعه سریع نرم‌افزار با کمک هوش مصنوعی — از ایده تا محصول',
  },

  // ─── رشته: برنامه‌نویسی خلاق کودکان و نوجوانان ───
  {
    slug: 'scratch',
    fieldKey: 'creative-coding', groupKey: 'ai',
    title: 'اسکرچ مقدماتی',
    level: 'FOUNDATION',
    tags: ['scratch', 'اسکرچ', 'برنامه‌نویسی کودکان', 'کدنویسی کودک', 'بازی‌سازی', 'نوجوان', 'کودک', 'مبتدی'],
    prerequisites: [],
    duration: '۲۴ ساعته',
    description: 'آموزش منطق برنامه‌نویسی از طریق بازی‌سازی برای کودکان',
  },
  {
    slug: 'scratch-advanced',
    fieldKey: 'creative-coding', groupKey: 'ai',
    title: 'اسکرچ پیشرفته',
    level: 'SPECIALIZED',
    tags: ['scratch پیشرفته', 'اسکرچ پیشرفته', 'بازی‌سازی پیشرفته', 'کدنویسی نوجوان', 'پروژه'],
    prerequisites: ['scratch'],
    duration: '۲۰ ساعته',
    description: 'پروژه‌های پیشرفته اسکرچ — بازی‌سازی و انیمیشن حرفه‌ای',
  },
  {
    slug: 'ai-teens',
    fieldKey: 'creative-coding', groupKey: 'ai',
    title: 'هوش مصنوعی برای نوجوانان',
    level: 'SPECIALIZED',
    tags: ['هوش مصنوعی نوجوان', 'ai kids', 'یادگیری ماشین کودک', 'بات هوشمند'],
    prerequisites: ['scratch'],
    duration: '۲۴ ساعته',
    description: 'آشنایی با مفاهیم AI و ساخت بات‌های هوشمند برای نوجوانان',
  },

  // ═══════════════════════════════════════════════════════════
  // گروه گرافیک و طراحی دیجیتال
  // ═══════════════════════════════════════════════════════════

  // ─── رشته: گرافیک رایانه‌ای ───
  {
    slug: 'computer-graphics',
    fieldKey: 'computer-graphics', groupKey: 'graphic-design',
    title: 'گرافیک کامپیوتری',
    level: 'FOUNDATION',
    tags: ['گرافیک', 'کامپیوتر', 'طراحی دیجیتال', 'مبانی گرافیک'],
    prerequisites: [],
    duration: '۲۰ ساعته',
    description: 'مبانی گرافیک رایانه‌ای — اصول طراحی دیجیتال',
  },
  {
    slug: 'photoshop',
    fieldKey: 'computer-graphics', groupKey: 'graphic-design',
    title: 'Photoshop',
    level: 'SPECIALIZED',
    tags: ['photoshop', 'فتوشاپ', 'طراحی گرافیک', 'عکاسی', 'ادیت', 'گرافیک', 'طراحی', 'پوستر'],
    prerequisites: [],
    duration: '۲۸ ساعته',
    description: 'آموزش حرفه‌ای ویرایش تصویر و طراحی گرافیک',
  },
  {
    slug: 'corel-draw',
    fieldKey: 'computer-graphics', groupKey: 'graphic-design',
    title: 'Corel Draw',
    level: 'SPECIALIZED',
    tags: ['corel', 'کورل', 'وکتور', 'طراحی وکتوری', 'لوگو', 'بروشور'],
    prerequisites: [],
    duration: '۲۴ ساعته',
    description: 'طراحی وکتوری حرفه‌ای — لوگو، بروشور، جلد',
  },
  {
    slug: 'freehand',
    fieldKey: 'computer-graphics', groupKey: 'graphic-design',
    title: 'Freehand',
    level: 'SPECIALIZED',
    tags: ['freehand', 'فری‌هند', 'وکتور', 'طراحی', 'تصویرسازی'],
    prerequisites: [],
    duration: '۲۰ ساعته',
    description: 'طراحی وکتوری و تصویرسازی با Freehand',
  },
  {
    slug: 'indesign',
    fieldKey: 'computer-graphics', groupKey: 'graphic-design',
    title: 'InDesign',
    level: 'SPECIALIZED',
    tags: ['indesign', 'ایندیزاین', 'صفحه‌آرایی', 'کتاب', 'مجله', 'چاپ'],
    prerequisites: [],
    duration: '۲۴ ساعته',
    description: 'صفحه‌آرایی حرفه‌ای — کتاب، مجله، روزنامه',
  },

  // ─── رشته: سه‌بعدی‌سازی ───
  {
    slug: '3dmax',
    fieldKey: '3d-modeling', groupKey: 'graphic-design',
    title: 'سه‌بعدی (3D Max)',
    level: 'SPECIALIZED',
    tags: ['3dmax', '3d', 'سه‌بعدی', 'مدلسازی', 'انیمیشن', 'رندر', 'معماری', 'V-Ray'],
    prerequisites: [],
    duration: '۳۶ ساعته',
    description: 'مدلسازی و رندر سه‌بعدی حرفه‌ای',
  },
  {
    slug: '3dmax-building',
    fieldKey: '3d-modeling', groupKey: 'graphic-design',
    title: 'نقشه‌کشی سه‌بعدی با 3D Max',
    level: 'STRATEGIC',
    tags: ['3d max', 'سه‌بعدی ساختمان', 'معماری', 'رندر', 'V-Ray', 'نقشه سه‌بعدی'],
    prerequisites: ['3dmax'],
    duration: '۲۸ ساعته',
    description: 'نقشه‌کشی و رندر سه‌بعدی ساختمان با 3D Max و V-Ray',
  },

  // ═══════════════════════════════════════════════════════════
  // گروه معماری و نقشه‌کشی
  // ═══════════════════════════════════════════════════════════

  // ─── رشته: نقشه‌کشی ساختمان ───
  {
    slug: 'building-drafting',
    fieldKey: 'building-drafting', groupKey: 'architecture',
    title: 'نقشه‌کشی ساختمان',
    level: 'SPECIALIZED',
    tags: ['نقشه‌کشی', 'ساختمان', 'معماری', 'پلان', 'فاز ۲', 'نقشه'],
    prerequisites: [],
    duration: '۴۰ ساعته',
    description: 'نقشه‌کشی حرفه‌ای ساختمان — پلان، نما، مقطع',
  },
  {
    slug: 'building-drafting-2',
    fieldKey: 'building-drafting', groupKey: 'architecture',
    title: 'نقشه‌کشی ساختمان درجه ۲',
    level: 'STRATEGIC',
    tags: ['نقشه‌کشی درجه ۲', 'ساختمان پیشرفته', 'فاز ۲', 'جزئیات'],
    prerequisites: ['building-drafting'],
    duration: '۳۲ ساعته',
    description: 'نقشه‌کشی پیشرفته ساختمان — جزئیات اجرایی و فاز ۲',
  },

  // ─── رشته: نقشه‌کشی با نرم‌افزار ───
  {
    slug: 'autocad',
    fieldKey: 'cad-software', groupKey: 'architecture',
    title: 'AutoCAD',
    level: 'SPECIALIZED',
    tags: ['autocad', 'اتوکد', 'نقشه‌کشی', 'طراحی فنی', 'مهندسی', 'ساختمان', 'طراحی صنعتی'],
    prerequisites: [],
    duration: '۳۲ ساعته',
    description: 'نقشه‌کشی حرفه‌ای دو و سه‌بعدی برای مهندسی و معماری',
  },
  {
    slug: 'autocad-3d',
    fieldKey: 'cad-software', groupKey: 'architecture',
    title: 'AutoCAD سه‌بعدی',
    level: 'STRATEGIC',
    tags: ['autocad 3d', 'اتوکد سه‌بعدی', 'مدل‌سازی', 'رندر', 'solid'],
    prerequisites: ['autocad'],
    duration: '۲۴ ساعته',
    description: 'مدل‌سازی سه‌بعدی و رندر با AutoCAD',
  },

  // ─── رشته: طراحی داخلی ───
  {
    slug: 'interior-design',
    fieldKey: 'interior-design', groupKey: 'architecture',
    title: 'طراحی معماری داخلی',
    level: 'STRATEGIC',
    tags: ['طراحی داخلی', 'دکوراسیون', 'معماری داخلی', 'چیدمان', 'نورپردازی'],
    prerequisites: [],
    duration: '۳۶ ساعته',
    description: 'طراحی حرفه‌ای فضای داخلی — از مفهوم تا اجرا',
  },

  // ═══════════════════════════════════════════════════════════
  // گروه امور مالی، بازرگانی و حسابداری
  // ═══════════════════════════════════════════════════════════

  // ─── رشته: حسابداری مالی ───
  {
    slug: 'accounting',
    fieldKey: 'financial-accounting', groupKey: 'finance',
    title: 'حسابداری مالی',
    level: 'FOUNDATION',
    tags: ['حسابداری', 'accounting', 'هزینه', 'صورتحساب', 'مالی', 'دفتری', 'حسابداری صنعتی'],
    prerequisites: [],
    duration: '۳۶ ساعته',
    description: 'آموزش اصول حسابداری و نرم‌افزارهای مالی برای کسب‌وکار',
  },
  {
    slug: 'accounting-practice',
    fieldKey: 'financial-accounting', groupKey: 'finance',
    title: 'کار عملی حسابداری مالی',
    level: 'SPECIALIZED',
    tags: ['حسابداری عملی', 'دفتر کل', 'صورتحساب', 'اسناد', 'حسابداری عملیاتی'],
    prerequisites: ['accounting'],
    duration: '۲۸ ساعته',
    description: 'تمرین عملی حسابداری — اسناد، دفاتر، صورتحساب',
  },

  // ─── رشته: هزینه‌ها ───
  {
    slug: 'costs-various',
    fieldKey: 'cost-accounting', groupKey: 'finance',
    title: 'هزینه‌های گوناگون',
    level: 'SPECIALIZED',
    tags: ['هزینه', 'بودجه', 'هزینه‌یابی', 'مدیریت هزینه'],
    prerequisites: [],
    duration: '۲۰ ساعته',
    description: 'آشنایی با انواع هزینه و روش‌های هزینه‌یابی',
  },
  {
    slug: 'costs-past',
    fieldKey: 'cost-accounting', groupKey: 'finance',
    title: 'هزینه گذشته سازمان',
    level: 'SPECIALIZED',
    tags: ['هزینه گذشته', 'سازمان', 'تحلیل هزینه', 'بودجه‌بندی'],
    prerequisites: [],
    duration: '۱۶ ساعته',
    description: 'تحلیل هزینه‌های گذشته سازمان و بودجه‌بندی آینده',
  },

  // ─── رشته: اصول مالی و بازرگانی ───
  // (now part of the finance group)
  {
    slug: 'finance-commerce',
    fieldKey: 'finance-basics', groupKey: 'finance',
    title: 'اصول مالی و بازرگانی',
    level: 'FOUNDATION',
    tags: ['مالی', 'بازرگانی', 'اقتصاد', 'بازار', 'تجارت', 'کسب‌وکار'],
    prerequisites: [],
    duration: '۳۶ ساعته',
    description: 'آشنایی با اصول مالی و بازرگانی — پایه ورود به بازار',
  },
  {
    slug: 'finance-commerce-2',
    fieldKey: 'finance-basics', groupKey: 'finance',
    title: 'اصول مالی و بازرگانی (نسخه دوم)',
    level: 'SPECIALIZED',
    tags: ['مالی پیشرفته', 'بازرگانی', 'مدیریت مالی', 'سرمایه‌گذاری'],
    prerequisites: ['finance-commerce'],
    duration: '۲۸ ساعته',
    description: 'تعمیق اصول مالی و بازرگانی — مدیریت مالی و سرمایه‌گذاری',
  },
  {
    slug: 'finance-commerce-degree2',
    fieldKey: 'finance-basics', groupKey: 'finance',
    title: 'اصول مالی و بازرگانی درجه ۲',
    level: 'STRATEGIC',
    tags: ['مالی درجه ۲', 'بازرگانی پیشرفته', 'تحلیل مالی', 'بازارسازی'],
    prerequisites: ['finance-commerce-2'],
    duration: '۲۴ ساعته',
    description: 'سطح پیشرفته اصول مالی — تحلیل بازار و استراتژی مالی',
  },

  // ─── فارکس (اضافه شده از ساختار قبلی) ───
  {
    slug: 'forex-fundamentals',
    fieldKey: 'finance-basics', groupKey: 'finance',
    title: 'فارکس (مبانی)',
    level: 'FOUNDATION',
    tags: ['forex', 'فارکس', 'بازار ارز', 'ترید', 'معامله', 'تحلیل تکنیکال', 'کندل', 'چارت'],
    prerequisites: [],
    duration: '۳۶ ساعته',
    description: 'ورود حرفه‌ای به بازار تبادل ارز با تحلیل تکنیکال و فاندامنتال',
  },
  {
    slug: 'mql5-algorithmic',
    fieldKey: 'finance-basics', groupKey: 'finance',
    title: 'MQL5 الگوریتمی',
    level: 'STRATEGIC',
    tags: ['mql5', 'الگوریتمی', 'ربات معامله‌گر', 'اکسپرت', 'ترید الگوریتمی', 'اتوماسیون معاملات', 'auto trading'],
    prerequisites: ['forex-fundamentals'],
    duration: '۲۸ ساعته',
    description: 'ساخت ربات‌های معامله‌گر خودکار با زبان MQL5',
  },

  // ─── معامله‌گری حرفه‌ای طلا (بر اساس متد μ–h Phase Shift) ───
  {
    slug: 'gold-trading-phase-shift',
    fieldKey: 'finance-basics', groupKey: 'finance',
    title: 'معامله‌گری حرفه‌ای طلا (XAUUSD)',
    level: 'SPECIALIZED',
    tags: ['طلا', 'XAUUSD', 'معامله‌گری طلا', 'گلد', 'ترید طلا', 'تحلیل طلا', 'phase shift'],
    prerequisites: ['forex-fundamentals'],
    duration: '۳۶ ساعته',
    description: 'معامله‌گری حرفه‌ای طلا با متد μ–h Phase Shift — تشخیص تغییر فاز بازار',
  },
  {
    slug: 'risk-capital-management',
    fieldKey: 'finance-basics', groupKey: 'finance',
    title: 'مدیریت ریسک و سرمایه',
    level: 'SPECIALIZED',
    tags: ['مدیریت ریسک', 'مدیریت سرمایه', 'حجم موقعیت', 'ریک‌ورد', 'ژورنال معاملات'],
    prerequisites: ['forex-fundamentals'],
    duration: '۲۰ ساعته',
    description: 'اصول حرفه‌ای مدیریت ریسک و سرمایه در بازارهای مالی',
  },

  // ═══════════════════════════════════════════════════════════
  // گروه کارآفرینی و کسب‌وکار
  // ═══════════════════════════════════════════════════════════

  // ─── رشته: مهارت‌های فردی و سازمانی ───
  // ─── رشته: کارآفرینی و راه‌اندازی کسب‌وکار ───
  {
    slug: 'time-management',
    fieldKey: 'personal-org-skills', groupKey: 'entrepreneurship-and-business',
    title: 'مدیریت زمان',
    level: 'FOUNDATION',
    tags: ['مدیریت زمان', 'بهره‌وری', 'برنامه‌ریزی', 'اولویت‌بندی'],
    prerequisites: [],
    duration: '۱۲ ساعته',
    description: 'تکنیک‌های مدیریت زمان و بهره‌وری شخصی',
  },
  {
    slug: 'financial-management',
    fieldKey: 'personal-org-skills', groupKey: 'entrepreneurship-and-business',
    title: 'مدیریت مالی',
    level: 'FOUNDATION',
    tags: ['مدیریت مالی', 'بودجه', 'پس‌انداز', 'سرمایه‌گذاری شخصی'],
    prerequisites: [],
    duration: '۱۲ ساعته',
    description: 'اصول مدیریت مالی شخصی و خانوادگی',
  },
  {
    slug: 'stress-management',
    fieldKey: 'personal-org-skills', groupKey: 'entrepreneurship-and-business',
    title: 'مدیریت استرس',
    level: 'FOUNDATION',
    tags: ['استرس', 'مدیریت استرس', 'آرامش', 'ذهن‌آگاهی', 'سلامت روان'],
    prerequisites: [],
    duration: '۱۲ ساعته',
    description: 'روش‌های مقابله با استرس و تقویت تاب‌آوری',
  },
  {
    slug: 'body-language',
    fieldKey: 'personal-org-skills', groupKey: 'entrepreneurship-and-business',
    title: 'زبان بدن',
    level: 'SPECIALIZED',
    tags: ['زبان بدن', 'ارتباط غیرکلامی', 'فیزیولوژی', 'تأثیرگذاری'],
    prerequisites: [],
    duration: '۱۲ ساعته',
    description: 'فهم و استفاده از زبان بدن در ارتباطات حرفه‌ای',
  },
  {
    slug: 'communication-skills',
    fieldKey: 'personal-org-skills', groupKey: 'entrepreneurship-and-business',
    title: 'تعامل و ارتباطات',
    level: 'SPECIALIZED',
    tags: ['ارتباطات', 'تعامل', 'مذاکره', 'صحبت', 'ارائه', 'soft skills'],
    prerequisites: [],
    duration: '۱۲ ساعته',
    description: 'مهارت‌های ارتباطی و تعاملی حرفه‌ای',
  },

  // ─── کارآفرینی ───
  {
    slug: 'entrepreneurship',
    fieldKey: 'entrepreneurship-field', groupKey: 'entrepreneurship-and-business',
    title: 'کارآفرینی',
    level: 'STRATEGIC',
    tags: ['کارآفرینی', 'entrepreneurship', 'استارتاپ', 'بیزینس پلن', 'خوداشتغالی', 'کسب درآمد', 'استارتآپ'],
    prerequisites: [],
    duration: '۲۸ ساعته',
    description: 'از ایده تا اجرا — مسیر راه‌اندازی کسب‌وکار شخصی',
  },
  {
    slug: 'business-consulting',
    fieldKey: 'entrepreneurship-field', groupKey: 'entrepreneurship-and-business',
    title: 'مشاوره کسب‌وکار',
    level: 'STRATEGIC',
    tags: ['مشاوره', 'کسب‌وکار', 'business', 'مدیریت', 'استراتژی', 'توسعه کسب‌وکار', 'مشاوره مدیریت'],
    prerequisites: [],
    duration: '۲۴ ساعته',
    description: 'یادگیری اصول مشاوره کسب‌وکار و کمک به سازمان‌ها',
  },

  // ═══════════════════════════════════════════════════════════
  // گروه بازار سرمایه
  // ═══════════════════════════════════════════════════════════

  // ─── رشته: آشنایی با بازار سرمایه ───
  {
    slug: 'capital-market-intro',
    fieldKey: 'capital-market-intro', groupKey: 'capital-market',
    title: 'آشنایی با بازار سرمایه',
    level: 'FOUNDATION',
    tags: ['بازار سرمایه', 'بورس', 'اوراق بهادار', 'سهام', 'سرمایه‌گذاری'],
    prerequisites: [],
    duration: '۲۴ ساعته',
    description: 'مفاهیم پایه بازار سرمایه و اوراق بهادار — ورود ایمن به بازار بورس',
  },
  {
    slug: 'capital-market-principles',
    fieldKey: 'capital-market-principles', groupKey: 'capital-market',
    title: 'اصول بازار سرمایه',
    level: 'FOUNDATION',
    tags: ['اصول بورس', 'مقررات', 'ناظر بورس', 'قوانین بازار سرمایه'],
    prerequisites: ['capital-market-intro'],
    duration: '۲۰ ساعته',
    description: 'اصول و مقررات حاکم بر بازار سرمایه — شناخت چارچوب قانونی',
  },

  // ─── رشته: تحلیل تکنیکال ───
  {
    slug: 'technical-analysis',
    fieldKey: 'technical-analysis', groupKey: 'capital-market',
    title: 'تحلیل تکنیکال بازار سرمایه',
    level: 'SPECIALIZED',
    tags: ['تحلیل تکنیکال', 'چارت', 'اندیکاتور', 'خط روند', 'حمایت و مقاومت'],
    prerequisites: ['capital-market-intro'],
    duration: '۳۶ ساعته',
    description: 'تحلیل تکنیکال سهام — از خط روند تا اندیکاتورهای پیشرفته',
  },
  {
    slug: 'fundamental-analysis',
    fieldKey: 'fundamental-analysis', groupKey: 'capital-market',
    title: 'تحلیل بنیادی شرکت‌ها',
    level: 'SPECIALIZED',
    tags: ['تحلیل بنیادی', 'صورت‌های مالی', 'ارزش ذاتی', 'صورت سود و زیان'],
    prerequisites: ['capital-market-intro'],
    duration: '۳۲ ساعته',
    description: 'تحلیل بنیادی سهام — بررسی گزارش‌های مالی و ارزش‌گذاری شرکت‌ها',
  },

  // ─── رشته: تابلوخوانی و روانشناسی ───
  {
    slug: 'board-reading',
    fieldKey: 'board-reading', groupKey: 'capital-market',
    title: 'تابلوخوانی و روانشناسی بازار',
    level: 'SPECIALIZED',
    tags: ['تابلوخوانی', 'حجم مشکوک', 'روانشناسی بورس', 'حسابرس'],
    prerequisites: ['capital-market-intro'],
    duration: '۲۰ ساعته',
    description: 'تابلوخوانی حرفه‌ای و روانشناسی معامله‌گری در بازار سرمایه',
  },
  {
    slug: 'portfolio-management',
    fieldKey: 'portfolio-management', groupKey: 'capital-market',
    title: 'مدیریت سرمایه و ساخت پرتفوی',
    level: 'STRATEGIC',
    tags: ['مدیریت پرتفوی', 'تنوع‌بخشی', 'ریسک', 'سبد سهام', 'سرمایه‌گذاری'],
    prerequisites: ['technical-analysis'],
    duration: '۲۴ ساعته',
    description: 'مدیریت حرفه‌ای سرمایه و ساخت پرتفوی بهینه — استراتژی تنوع‌بخشی',
  },

  // ═══════════════════════════════════════════════════════════
  // گروه خدمات آموزشی
  // ═══════════════════════════════════════════════════════════

  // ─── رشته: پداگوژی و روش تدریس ───
  {
    slug: 'pedagogy',
    fieldKey: 'pedagogy', groupKey: 'educational-services',
    title: 'پداگوژی و روش تدریس',
    level: 'FOUNDATION',
    tags: ['پداگوژی', 'تدریس', 'آموزش', 'روش تدریس', 'یادگیری فعال'],
    prerequisites: [],
    duration: '۲۰ ساعته',
    description: 'روش‌های تدریس مدرن و یادگیری فعال — مهارت اساسی هر آموزگار',
  },
  {
    slug: 'presentation-skills',
    fieldKey: 'presentation-skills', groupKey: 'educational-services',
    title: 'فن بیان و مهارت ارائه',
    level: 'SPECIALIZED',
    tags: ['فن بیان', 'ارائه', 'خطابه', 'ارتباط مؤثر', 'سخنرانی'],
    prerequisites: [],
    duration: '۱۶ ساعته',
    description: 'فن بیان و مهارت ارائه حرفه‌ای — از کلاس درس تا سالن کنفرانس',
  },
  {
    slug: 'course-design-lms',
    fieldKey: 'course-design-lms', groupKey: 'educational-services',
    title: 'طراحی دوره آموزشی و LMS',
    level: 'SPECIALIZED',
    tags: ['طراحی دوره', 'LMS', 'آموزش آنلاین', 'مودل', 'محتوای آموزشی'],
    prerequisites: [],
    duration: '۲۴ ساعته',
    description: 'طراحی دوره آموزشی استاندارد و مدیریت سیستم یادگیری الکترونیکی',
  },

  // ═══════════════════════════════════════════════════════════
  // گروه خدمات حقوقی
  // ═══════════════════════════════════════════════════════════

  // ─── رشته: قراردادنویسی ───
  {
    slug: 'contract-writing',
    fieldKey: 'contract-writing', groupKey: 'legal-services',
    title: 'قراردادنویسی',
    level: 'FOUNDATION',
    tags: ['قرارداد', 'قراردادنویسی', 'حقوق', 'تعهد', 'توافق‌نامه'],
    prerequisites: [],
    duration: '۲۰ ساعته',
    description: 'تنظیم قراردادهای حقوقی و تجاری — مهارت پایه هر فعال اقتصادی',
  },
  {
    slug: 'legal-consulting',
    fieldKey: 'legal-consulting', groupKey: 'legal-services',
    title: 'مشاور حقوقی',
    level: 'SPECIALIZED',
    tags: ['مشاور حقوقی', 'حقوق مدنی', 'حقوق تجاری', 'وکیل'],
    prerequisites: [],
    duration: '۲۴ ساعته',
    description: 'مشاوره حقوقی در امور مدنی و تجاری — آشنایی با چارچوب‌های قانونی',
  },
  {
    slug: 'judicial-writing',
    fieldKey: 'judicial-writing', groupKey: 'legal-services',
    title: 'نگارش قضایی',
    level: 'SPECIALIZED',
    tags: ['نگارش قضایی', 'لایحه', 'دادخواست', 'شکواییه', 'دفاعیه'],
    prerequisites: [],
    duration: '۱۶ ساعته',
    description: 'نگارش حرفه‌ای لایحه و دادخواست — مهارت عملی در دادگاه‌ها',
  },
  {
    slug: 'judicial-e-services',
    fieldKey: 'judicial-e-services', groupKey: 'legal-services',
    title: 'خدمات الکترونیک قضایی',
    level: 'SPECIALIZED',
    tags: ['ثنا', 'خدمات قضایی الکترونیک', 'اینترنتی دادگستری', 'ایرانیان'],
    prerequisites: [],
    duration: '۱۲ ساعته',
    description: 'استفاده از سامانه‌های الکترونیک قضایی و ثنا — دیجیتالی‌سازی امور حقوقی',
  },
]

// ─── Legacy Compatibility: CLUSTERS maps to GROUPS ─────────────
// Maps old 4-cluster keys to the new 6-group structure
// This ensures backward compatibility with existing code

export const CLUSTERS: Record<ClusterKey, { label: string; description: string; color: string }> =
  Object.fromEntries(
    Object.entries(GROUPS).map(([key, group]) => [
      key,
      { label: group.label, description: group.description, color: group.color },
    ])
  ) as Record<ClusterKey, { label: string; description: string; color: string }>

// ─── Legacy Compatibility: SKILL_GRAPH maps to OCCUPATIONS ────

export const SKILL_GRAPH: SkillNode[] = OCCUPATIONS.map(occ => ({
  slug: occ.slug,
  title: occ.title,
  cluster: occ.groupKey,
  level: occ.level,
  tags: occ.tags,
  prerequisites: occ.prerequisites,
  duration: occ.duration,
  description: occ.description,
}))

// ─── Helper: Get fields for a group ──────────────────────────

export function getFieldsForGroup(groupKey: GroupKey): TrainingField[] {
  return FIELDS.filter(f => f.groupKey === groupKey)
}

// ─── Helper: Get occupations for a field ─────────────────────

export function getOccupationsForField(fieldKey: string): Occupation[] {
  return OCCUPATIONS.filter(o => o.fieldKey === fieldKey)
}

// ─── Helper: Get occupations for a group ─────────────────────

export function getOccupationsForGroup(groupKey: GroupKey): Occupation[] {
  return OCCUPATIONS.filter(o => o.groupKey === groupKey)
}

// ─── Goal → Group Mapping ─────────────────────────────────────

const GOAL_GROUP_MAP: Record<string, GroupKey[]> = {
  'employment': ['it', 'finance'],
  'کار': ['it', 'finance'],
  'استخدام': ['it', 'finance'],
  'ترید': ['finance'],
  'سرمایه‌گذاری': ['finance'],
  'بازار': ['finance'],
  'فارکس': ['finance'],
  'کسب‌وکار': ['entrepreneurship-and-business'],
  'کارآفرینی': ['entrepreneurship-and-business'],
  'خوداشتغالی': ['entrepreneurship-and-business'],
  'هنر': ['graphic-design'],
  'طراحی': ['graphic-design', 'architecture'],
  'خلاقیت': ['graphic-design'],
  'مهندسی': ['architecture'],
  'آموزگاری': ['educational-services', 'entrepreneurship-and-business'],
  'کودک': ['ai'],
  'نوجوان': ['it', 'ai'],
  'coding': ['it'],
  'برنامه‌نویسی': ['it', 'ai'],
  'هوش مصنوعی': ['ai'],
  'کامپیوتر': ['it'],
  'گرافیک': ['graphic-design'],
  'معماری': ['architecture'],
  'حسابداری': ['finance'],
  'حساب': ['finance'],
  'بورس': ['capital-market'],
  'سرمایه': ['capital-market'],
  'بازار سرمایه': ['capital-market'],
  'سهام': ['capital-market'],
  'تدریس': ['educational-services'],
  'فن بیان': ['educational-services'],
  'حقوق': ['legal-services'],
  'قرارداد': ['legal-services'],
  'قضایی': ['legal-services'],
}

// ─── Matchmaking Algorithm ──────────────────────────────────

export function matchmake(input: MatchmakingInput): MatchmakingResult {
  const { age, interests, goal, source } = input

  // 1. Identify primary group from goal
  const goalGroups = findGroupsForGoal(goal)

  // 2. Match interests to skill tags
  const interestMatches = matchInterests(interests)

  // 3. Consider source context
  const sourceGroup = inferGroupFromSource(source)

  // 4. Score each program
  const scored = SKILL_GRAPH.map(program => {
    let score = 0
    let reasons: string[] = []

    // Goal group match (highest weight: 40 points)
    if (goalGroups.includes(program.cluster as GroupKey)) {
      score += 40
      reasons.push(`هدف شما با گروه ${GROUPS[program.cluster as GroupKey]?.label || program.cluster} همخوانی دارد`)
    }

    // Interest match (30 points max)
    const interestScore = calculateInterestMatch(program, interests)
    score += interestScore
    if (interestScore > 15) {
      reasons.push(`علاقه‌مندی‌های شما با این دوره مرتبط است`)
    }

    // Source match (15 points)
    if (sourceGroup && sourceGroup === program.cluster) {
      score += 15
      reasons.push(`از طریق منبع مرتبط وارد شده‌اید`)
    }

    // Age-appropriate level (15 points)
    const ageScore = calculateAgeScore(program.level, age)
    score += ageScore
    if (ageScore >= 10) {
      reasons.push(`سطح دوره مناسب سن شماست`)
    } else if (ageScore > 0) {
      reasons.push(`این دوره برای شما مناسب است`)
    }

    return {
      slug: program.slug,
      title: program.title,
      cluster: program.cluster,
      level: program.level,
      matchScore: Math.min(score, 100),
      reason: reasons.join(' — ') || 'دوره پیشنهادی',
    } as RecommendedProgram
  })

  // Sort by match score and take top 5
  const recommendedPrograms = scored
    .sort((a, b) => b.matchScore - a.matchScore)
    .slice(0, 5)

  // 5. Generate roadmap from top group
  const topGroup = goalGroups[0] || recommendedPrograms[0]?.cluster || 'it'
  const roadmapSteps = generateRoadmap(topGroup, age)

  // 6. Calculate confidence score
  const confidenceScore = calculateConfidence(recommendedPrograms, interestMatches, goalGroups)

  return {
    recommendedPrograms,
    roadmapSteps,
    confidenceScore,
  }
}

// ─── Helper Functions ────────────────────────────────────────

function findGroupsForGoal(goal: string): GroupKey[] {
  if (!goal) return ['it']

  const goalLower = goal.toLowerCase().trim()
  const matched: GroupKey[] = []

  for (const [key, groups] of Object.entries(GOAL_GROUP_MAP)) {
    if (goalLower.includes(key) || key.includes(goalLower)) {
      matched.push(...groups)
    }
  }

  return [...new Set(matched)].length > 0 ? [...new Set(matched)] : ['it']
}

function matchInterests(interests: string[]): { matched: number; total: number } {
  if (!interests.length) return { matched: 0, total: 0 }

  let matched = 0
  for (const interest of interests) {
    const interestLower = interest.toLowerCase().trim()
    const found = SKILL_GRAPH.some(p =>
      p.tags.some(tag =>
        tag.toLowerCase().includes(interestLower) ||
        interestLower.includes(tag.toLowerCase())
      )
    )
    if (found) matched++
  }

  return { matched, total: interests.length }
}

function calculateInterestMatch(program: SkillNode, interests: string[]): number {
  if (!interests.length) return 0

  let score = 0
  for (const interest of interests) {
    const interestLower = interest.toLowerCase().trim()
    const isMatch = program.tags.some(tag =>
      tag.toLowerCase().includes(interestLower) ||
      interestLower.includes(tag.toLowerCase())
    )
    if (isMatch) {
      score += Math.floor(30 / interests.length)
    }
  }

  return Math.min(score, 30)
}

function inferGroupFromSource(source?: string): GroupKey | null {
  if (!source) return null
  const s = source.toLowerCase()
  if (s.includes('instagram') || s.includes('telegram')) return 'it'
  if (s.includes('forex') || s.includes('trading')) return 'finance'
  if (s.includes('career') || s.includes('quiz')) return 'it'
  return null
}

function calculateAgeScore(level: BloomLevel, age?: number): number {
  if (!age) return 8

  if (age >= 13 && age <= 18) {
    if (level === 'FOUNDATION') return 15
    if (level === 'SPECIALIZED') return 8
    return 3
  }

  if (age >= 19 && age <= 30) {
    if (level === 'SPECIALIZED') return 15
    if (level === 'FOUNDATION') return 10
    return 8
  }

  if (age > 30) {
    if (level === 'STRATEGIC') return 15
    if (level === 'SPECIALIZED') return 10
    return 5
  }

  if (level === 'FOUNDATION') return 15
  return 3
}

function generateRoadmap(groupKey: GroupKey, age?: number): RoadmapStep[] {
  const groupPrograms = SKILL_GRAPH.filter(p => p.cluster === groupKey)
  const foundation = groupPrograms.find(p => p.level === 'FOUNDATION')
  const specialized = groupPrograms.find(p => p.level === 'SPECIALIZED')
  const strategic = groupPrograms.find(p => p.level === 'STRATEGIC')

  const steps: RoadmapStep[] = []

  steps.push({
    step: 1,
    title: foundation ? foundation.title : 'دوره پایه',
    description: foundation
      ? `${foundation.description} — یادگیری مبانی و مهارت‌های اولیه`
      : 'یادگیری مبانی و مهارت‌های اولیه',
    duration: foundation?.duration || '۴۰ ساعته',
  })

  if (specialized && (!age || age >= 16)) {
    steps.push({
      step: 2,
      title: specialized.title,
      description: `${specialized.description} — تخصصی‌سازی مهارت‌ها`,
      duration: specialized.duration,
    })
  } else if (!specialized) {
    steps.push({
      step: 2,
      title: 'تعمیق مهارت',
      description: 'تمرین عملی و پروژه‌محور برای تسلط بر مهارت‌های پایه',
      duration: 'مطابق برنامه آموزشی',
    })
  }

  if (strategic) {
    steps.push({
      step: 3,
      title: strategic.title,
      description: `${strategic.description} — ورود حرفه‌ای به بازار کار`,
      duration: strategic.duration,
    })
  } else {
    steps.push({
      step: 3,
      title: 'ورود به بازار کار',
      description: 'اخذ مدرک معتبر فنی و حرفه‌ای و شروع مسیر شغلی',
      duration: 'پس از اتمام دوره‌ها',
    })
  }

  return steps
}

function calculateConfidence(
  programs: RecommendedProgram[],
  interestMatch: { matched: number; total: number },
  goalGroups: GroupKey[]
): number {
  let confidence = 30

  if (programs[0]?.matchScore >= 70) confidence += 25
  else if (programs[0]?.matchScore >= 50) confidence += 15
  else if (programs[0]?.matchScore >= 30) confidence += 5

  if (interestMatch.total > 0) {
    const ratio = interestMatch.matched / interestMatch.total
    confidence += Math.floor(ratio * 25)
  }

  if (goalGroups.length > 0 && goalGroups[0] !== 'it') {
    confidence += 10
  }

  if (interestMatch.total >= 3) confidence += 10

  return Math.min(confidence, 100)
}
