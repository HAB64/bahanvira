/**
 * Lead Scoring System — Public API
 * ===================================
 * Single import point for the entire lead scoring pipeline.
 *
 * Usage (server):
 *   import { calculateLeadScore, SCORING_CONFIG } from '@/lib/lead-scoring';
 *
 * Usage (client):
 *   import { useGTM } from '@/hooks/useGTM';
 *   import { submitLead } from '@/app/actions/leadActions';
 */

// Types
export type {
  LeadFormData,
  LeadSource,
  InterestedCategory,
  LeadStatus,
  LeadTemperature,
  ScoringEvent,
  ScoringRule,
  LeadScoringResult,
  CRMWebhookPayload,
  GTMEventBase,
  GTMFormSubmissionEvent,
  GTMWhatsappClickEvent,
  GTMCareerTestEvent,
  GTMPricingPageViewEvent,
  GTMEventData,
  LeadSubmissionResult,
  ScoringConfig,
} from '@/types/lead';

// Scoring Engine
export { calculateLeadScore, scoreSingleEvent, classifyTemperature } from './engine';
export { SCORING_CONFIG, SCORING_RULES, SCORING_THRESHOLDS } from './config';
export { leadFormSchema, isValidIranianMobile } from './schemas';
export type { LeadFormSchemaInput } from './schemas';

// Workflows
export { AUTOMATION_WORKFLOWS, findMatchingWorkflow } from './workflows';
export type { Workflow, WorkflowNode, WorkflowNodeType } from './workflows';