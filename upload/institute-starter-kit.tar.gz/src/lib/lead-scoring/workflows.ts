/**
 * Lead Automation Workflows
 * =============================
 * Three temperature-based workflows for the CRM automation engine.
 * Each workflow is a declarative node graph that the CRM admin panel
 * can consume and execute.
 *
 * These are NOT runtime code — they are configuration/data structures
 * that the CRM module (n8n / internal automation engine) interprets.
 *
 * File: src/lib/lead-scoring/workflows.ts
 */

import type { LeadTemperature } from '@/types/lead';

// ─── Node Types ──────────────────────────────────────────────────────────────

export type WorkflowNodeType =
  | 'trigger'          // Entry point — watches for a condition
  | 'condition'        // Branching logic
  | 'action_sms'       // Send SMS via national messaging API
  | 'action_task'      // Create a follow-up task for an advisor
  | 'action_notify'    // Push notification (Telegram/Bale/etc.)
  | 'action_pipeline'  // Move lead to a specific pipeline stage
  | 'action_tag'       // Add a tag to the lead
  | 'delay';           // Wait before next node

export interface WorkflowNode {
  /** Unique node ID within the workflow */
  id: string;
  /** Human-readable label (Farsi) */
  label: string;
  /** Node type */
  type: WorkflowNodeType;
  /** Configuration for this node — varies by type */
  config: Record<string, unknown>;
  /** IDs of next nodes to execute (order matters) */
  next: string[];
}

export interface Workflow {
  /** Unique workflow identifier */
  id: string;
  /** Human-readable name (Farsi) */
  name: string;
  /** Description */
  description: string;
  /** Which temperature tier this workflow handles */
  temperatureTier: LeadTemperature;
  /** Score range that activates this workflow */
  scoreRange: { min: number; max: number };
  /** Ordered list of nodes */
  nodes: WorkflowNode[];
  /** Priority (lower = higher priority) */
  priority: number;
  /** Is this workflow active? */
  active: boolean;
}

// ─── Workflow 1: Cold Lead (Score 0–19) ──────────────────────────────────────

const coldLeadWorkflow: Workflow = {
  id: 'workflow_cold_lead',
  name: 'لید سرد — پیامک خوش‌آمد و لیست انتظار',
  description:
    'وقتی امتیاز لید کمتر از ۲۰ باشد، یک پیامک خوش‌آمد ارسال شده و لید به لیست انتظار اضافه می‌شود. هدف: ایجاد ارتباط اولیه بدون بارگذاری تیم فروش.',
  temperatureTier: 'cold',
  scoreRange: { min: 0, max: 19 },
  priority: 30,
  active: true,
  nodes: [
    {
      id: 'cold_trigger',
      label: 'تغییر امتیاز لید به زیر ۲۰',
      type: 'trigger',
      config: {
        event: 'lead_score_updated',
        condition: 'lead_score < 20 AND lead_status != "spam" AND lead_status != "converted"',
      },
      next: ['cold_sms_welcome'],
    },
    {
      id: 'cold_sms_welcome',
      label: 'ارسال پیامک خوش‌آمدگویی',
      type: 'action_sms',
      config: {
        templateId: 'bahan-lead-welcome',
        recipientField: 'mobile',
        variables: { name: '{{lead.name}}' },
      },
      next: ['cold_tag_waiting'],
    },
    {
      id: 'cold_tag_waiting',
      label: 'افزودن تگ «لیست انتظار»',
      type: 'action_tag',
      config: {
        tag: 'لیست انتظار',
        append: true,
      },
      next: ['cold_delay_followup'],
    },
    {
      id: 'cold_delay_followup',
      label: 'انتظار ۷ روز',
      type: 'delay',
      config: {
        duration: '7d',
      },
      next: ['cold_sms_followup'],
    },
    {
      id: 'cold_sms_followup',
      label: 'ارسال پیامک پیگیری',
      type: 'action_sms',
      config: {
        templateId: 'bahan-cold-followup',
        recipientField: 'mobile',
        variables: { name: '{{lead.name}}' },
      },
      next: [],
    },
  ],
};

// ─── Workflow 2: Warm Lead (Score 20–49) ─────────────────────────────────────

const warmLeadWorkflow: Workflow = {
  id: 'workflow_warm_lead',
  name: 'لید گرم — تسک پیگیری و پیامک شخصی‌سازی‌شده',
  description:
    'وقتی امتیاز لید به بازه ۲۰–۴۹ برسد، یک تسک پیگیری برای مشاور ایجاد شده و پیامک اختصاصی ارسال می‌شود. هدف: تبدیل لید به جلسه مشاوره حضوری/تلفنی.',
  temperatureTier: 'warm',
  scoreRange: { min: 20, max: 49 },
  priority: 20,
  active: true,
  nodes: [
    {
      id: 'warm_trigger',
      label: 'رسیدن امتیاز لید به بازه ۲۰–۴۹',
      type: 'trigger',
      config: {
        event: 'lead_score_updated',
        condition: 'lead_score >= 20 AND lead_score <= 49 AND lead_status != "spam"',
      },
      next: ['warm_create_task'],
    },
    {
      id: 'warm_create_task',
      label: 'ایجاد تسک پیگیری برای مشاور',
      type: 'action_task',
      config: {
        title: 'پیگیری لید گرم: {{lead.name}} ({{lead.mobile}})',
        description:
          'امتیاز: {{lead.lead_score}} | دسته‌بندی: {{lead.interested_category}} | منبع: {{lead.source}}',
        assignTo: 'default_advisor',
        priority: 'medium',
        dueIn: '24h',
      },
      next: ['warm_sms_personalized'],
    },
    {
      id: 'warm_sms_personalized',
      label: 'ارسال پیامک شخصی‌سازی‌شده',
      type: 'action_sms',
      config: {
        templateId: 'bahan-warm-personalized',
        recipientField: 'mobile',
        variables: {
          name: '{{lead.name}}',
          category: '{{lead.interested_category}}',
        },
      },
      next: ['warm_tag_followup'],
    },
    {
      id: 'warm_tag_followup',
      label: 'افزودن تگ «نیاز پیگیری»',
      type: 'action_tag',
      config: {
        tag: 'نیاز پیگیری',
        append: true,
      },
      next: ['warm_delay_48h'],
    },
    {
      id: 'warm_delay_48h',
      label: 'انتظار ۴۸ ساعت',
      type: 'delay',
      config: {
        duration: '48h',
      },
      next: ['warm_check_score'],
    },
    {
      id: 'warm_check_score',
      label: 'بررسی مجدد امتیاز',
      type: 'condition',
      config: {
        conditions: [
          {
            expression: 'lead_score >= 50',
            nextNode: 'hot_pipeline',  // Escalate to hot workflow
          },
          {
            expression: 'lead_status == "converted"',
            nextNode: 'end',
          },
          {
            expression: 'default',
            nextNode: 'warm_sms_reminder',
          },
        ],
      },
      next: [],
    },
    {
      id: 'warm_sms_reminder',
      label: 'ارسال پیامک یادآوری',
      type: 'action_sms',
      config: {
        templateId: 'bahan-warm-reminder',
        recipientField: 'mobile',
        variables: { name: '{{lead.name}}' },
      },
      next: [],
    },
  ],
};

// ─── Workflow 3: Hot Lead (Score 50+) ────────────────────────────────────────

const hotLeadWorkflow: Workflow = {
  id: 'workflow_hot_lead',
  name: 'لید داغ — نوتیفیکیشن فوری و انتقال به Pipeline',
  description:
    'وقتی امتیاز لید از ۵۰ بالاتر برود، وضعیت به «داغ» تغییر کرده، نوتیفیکیشن فوری به تلگرام مدیر ارسال شده و لید به Pipeline فروش منتقل می‌شود. هدف: بستن سریع معامله.',
  temperatureTier: 'hot',
  scoreRange: { min: 50, max: Infinity },
  priority: 10, // Highest priority — hot leads first
  active: true,
  nodes: [
    {
      id: 'hot_trigger',
      label: 'رسیدن امتیاز لید به بالای ۵۰',
      type: 'trigger',
      config: {
        event: 'lead_score_updated',
        condition: 'lead_score >= 50 AND lead_status != "spam" AND lead_status != "converted"',
      },
      next: ['hot_set_status'],
    },
    {
      id: 'hot_set_status',
      label: 'تغییر وضعیت لید به «داغ»',
      type: 'action_pipeline',
      config: {
        status: 'hot',
        stage: 'پیگیری فوری',
      },
      next: ['hot_notify_telegram'],
    },
    {
      id: 'hot_notify_telegram',
      label: 'نوتیفیکیشن فوری به تلگرام مدیر',
      type: 'action_notify',
      config: {
        channel: 'telegram',
        recipient: '{{config.admin_telegram_id}}',
        priority: 'high',
        message:
          '🔥 لید داغ جدید!\n\n' +
          '👤 نام: {{lead.name}}\n' +
          '📱 موبایل: {{lead.mobile}}\n' +
          '📊 امتیاز: {{lead.lead_score}}\n' +
          '📂 دسته‌بندی: {{lead.interested_category}}\n' +
          '🔗 منبع: {{lead.source}}\n' +
          '🟢 لینک CRM: {{crm.lead_url}}',
      },
      next: ['hot_create_urgent_task'],
    },
    {
      id: 'hot_create_urgent_task',
      label: 'ایجاد تسک فوری با اولویت بالا',
      type: 'action_task',
      config: {
        title: '🔴 فوری: تماس با لید داغ — {{lead.name}}',
        description:
          'این لید امتیاز {{lead.lead_score}} دارد و باید ظرف ۲ ساعت تماس گرفته شود.\n' +
          'دسته‌بندی علاقه‌مندی: {{lead.interested_category}}\n' +
          'منبع: {{lead.source}}',
        assignTo: 'senior_advisor',
        priority: 'high',
        dueIn: '2h',
      },
      next: ['hot_sms_exclusive'],
    },
    {
      id: 'hot_sms_exclusive',
      label: 'ارسال پیامک ویژه (پیشنهاد مشاوره رایگان)',
      type: 'action_sms',
      config: {
        templateId: 'bahan-hot-exclusive',
        recipientField: 'mobile',
        variables: {
          name: '{{lead.name}}',
          category: '{{lead.interested_category}}',
        },
      },
      next: ['hot_tag_urgent'],
    },
    {
      id: 'hot_tag_urgent',
      label: 'افزودن تگ «فوری» و «لید داغ»',
      type: 'action_tag',
      config: {
        tags: ['فوری', 'لید داغ'],
        append: true,
      },
      next: [],
    },
  ],
};

// ─── Export All Workflows ─────────────────────────────────────────────────────

export const AUTOMATION_WORKFLOWS: Workflow[] = [
  hotLeadWorkflow,    // Priority 10 — processed first
  warmLeadWorkflow,   // Priority 20
  coldLeadWorkflow,   // Priority 30
];

/**
 * Find the matching workflow for a given score.
 * Returns the highest-priority matching workflow, or null.
 */
export function findMatchingWorkflow(score: number): Workflow | null {
  return (
    AUTOMATION_WORKFLOWS.find(
      (wf) =>
        wf.active &&
        score >= wf.scoreRange.min &&
        score <= wf.scoreRange.max,
    ) ?? null
  );
}