/**
 * Lead Form — Zod Validation Schemas
 * ======================================
 * Server-side validation with Iranian mobile regex.
 *
 * File: src/lib/lead-scoring/schemas.ts
 */

import { z } from 'zod';

/**
 * Iranian mobile number:
 *   - Starts with 09
 *   - Exactly 11 digits
 *   - Third digit: 0-9 (covers all MCI/IRancell/Rightel prefixes)
 */
const IRANIAN_MOBILE_REGEX = /^09[0-9]{9}$/;

export const leadFormSchema = z.object({
  name: z
    .string()
    .min(2, 'نام باید حداقل ۲ حرف باشد')
    .max(100, 'نام نمی‌تواند بیش از ۱۰۰ حرف باشد'),

  mobile: z
    .string()
    .regex(IRANIAN_MOBILE_REGEX, 'شماره موبایل معتبر نیست (فرمت: 09xxxxxxxxx)'),

  email: z
    .string()
    .email('ایمیل معتبر نیست')
    .optional()
    .or(z.literal('')),

  source: z.enum([
    'website_form',
    'whatsapp',
    'telegram',
    'instagram',
    'referral',
    'google_ads',
    'organic_search',
    'direct',
    'campaign_landing_page',
  ] as const),

  interestedCategory: z.enum([
    'AI',
    'Finance',
    'IT',
    'GraphicDesign',
    'Architecture',
    'SoftSkills',
  ] as const),

  courseSlug: z.string().optional(),
  message: z.string().max(1000, 'پیام نمی‌تواند بیش از ۱۰۰۰ حرف باشد').optional(),

  utm: z.object({
    source: z.string().optional(),
    medium: z.string().optional(),
    campaign: z.string().optional(),
    term: z.string().optional(),
    content: z.string().optional(),
  }).optional(),

  pageUrl: z.string().url().optional().or(z.literal('')),
});

/** Inferred TypeScript type from the Zod schema */
export type LeadFormSchemaInput = z.infer<typeof leadFormSchema>;

/**
 * Checks if a mobile number is valid Iranian format.
 * Useful as a standalone utility outside of form validation.
 */
export function isValidIranianMobile(mobile: string): boolean {
  return IRANIAN_MOBILE_REGEX.test(mobile);
}