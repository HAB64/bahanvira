/**
 * Lead Scoring Configuration — B2C Scoring Table
 * ==================================================
 * Single source of truth for all scoring rules and thresholds.
 * Consumed by the scoring engine and (optionally) the admin panel.
 *
 * File: src/lib/lead-scoring/config.ts
 */

import type { ScoringConfig, ScoringRule } from '@/types/lead';

// ─── Scoring Rules (B2C) ──────────────────────────────────────────────────────
// Priority order matters — rules are applied top-to-bottom.
// First rule that sets statusOverride wins the status.

export const SCORING_RULES: ScoringRule[] = [
  {
    event: 'form_submission',
    points: 25,
    description: 'ارسال فرم مشاوره/ثبت‌نام',
  },
  {
    event: 'whatsapp_click',
    points: 15,
    description: 'کلیک روی لینک واتساپ',
  },
  {
    event: 'career_test_completed',
    points: 20,
    description: 'تکمیل تست مسیر شغلی',
  },
  {
    event: 'page_view_pricing',
    points: 15,
    description: 'مشاهده صفحه قیمت‌ها',
  },
  {
    event: 'interested_category_ai',
    points: 10,
    description: 'علاقه‌مندی به حوزه هوش مصنوعی',
  },
  {
    event: 'invalid_phone_pattern',
    points: -30,
    statusOverride: 'spam',
    description: 'شماره موبایل نامعتبر — ارتقاء به اسپم',
  },
];

// ─── Temperature Thresholds ───────────────────────────────────────────────────

export const SCORING_THRESHOLDS = {
  hotThreshold: 50,
  warmThreshold: 20,
  coldMax: 19,
} as const;

// ─── Full Config Object ───────────────────────────────────────────────────────

export const SCORING_CONFIG: ScoringConfig = {
  version: '1.0.0',
  effectiveFrom: '2025-01-01T00:00:00.000Z',
  rules: SCORING_RULES,
  thresholds: {
    hotThreshold: SCORING_THRESHOLDS.hotThreshold,
    warmThreshold: SCORING_THRESHOLDS.warmThreshold,
    coldMax: SCORING_THRESHOLDS.coldMax,
  },
};