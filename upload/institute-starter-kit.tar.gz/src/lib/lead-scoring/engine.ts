/**
 * Lead Scoring Engine
 * ====================
 * Pure function that takes raw events and returns a scored result.
 * No side effects — easily testable.
 *
 * File: src/lib/lead-scoring/engine.ts
 */

import type {
  ScoringEvent,
  LeadScoringResult,
  LeadStatus,
  LeadTemperature,
} from '@/types/lead';
import { SCORING_CONFIG, SCORING_RULES } from './config';

/**
 * Classify a numeric score into a temperature tier.
 */
export function classifyTemperature(score: number): LeadTemperature {
  if (score >= SCORING_CONFIG.thresholds.hotThreshold) return 'hot';
  if (score >= SCORING_CONFIG.thresholds.warmThreshold) return 'warm';
  return 'cold';
}

/**
 * Apply the full scoring table to a list of events.
 *
 * @param events - Chronological list of events the lead has triggered
 * @param baseScore - Starting score (default 0). Useful for cumulative updates.
 * @param currentStatus - Current lead status (default 'new')
 * @returns Full scoring result with audit trail
 */
export function calculateLeadScore(
  events: ScoringEvent[],
  baseScore: number = 0,
  currentStatus: LeadStatus = 'new',
): LeadScoringResult {
  let score = baseScore;
  let status: LeadStatus = currentStatus;
  const appliedRules: LeadScoringResult['appliedRules'] = [];

  for (const event of events) {
    const rule = SCORING_RULES.find((r) => r.event === event);
    if (!rule) continue;

    score += rule.points;
    appliedRules.push({
      event: rule.event,
      points: rule.points,
      description: rule.description,
    });

    // First statusOverride wins
    if (rule.statusOverride && status !== 'spam') {
      status = rule.statusOverride;
    }
  }

  // Never let score drop below 0
  score = Math.max(0, score);

  // If status was overridden to spam, keep it regardless of score
  // Otherwise, if the score qualifies as hot but status hasn't been set, promote
  if (status !== 'spam' && score >= SCORING_CONFIG.thresholds.hotThreshold && status !== 'converted') {
    status = 'hot';
  }

  return {
    score,
    temperature: classifyTemperature(score),
    status,
    appliedRules,
  };
}

/**
 * Quick single-event scoring — convenience wrapper.
 */
export function scoreSingleEvent(
  event: ScoringEvent,
  baseScore: number = 0,
  currentStatus: LeadStatus = 'new',
): LeadScoringResult {
  return calculateLeadScore([event], baseScore, currentStatus);
}