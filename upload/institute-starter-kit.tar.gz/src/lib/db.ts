import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

function createPrismaClient() {
  // Handle missing DATABASE_URL gracefully
  if (!process.env.DATABASE_URL) {
    console.warn('DATABASE_URL is not set. Database operations will fail. Please set DATABASE_URL in your environment variables.')
    // Return a PrismaClient that will throw a clear error when used
    // rather than crashing at import time
  }

  try {
    const client = new PrismaClient({
      log: process.env.NODE_ENV === 'development' ? ['query'] : ['error'],
      // Neon serverless optimization: use connection pooler with proper limits
      datasources: {
        db: {
          url: process.env.DATABASE_URL,
        },
      },
    })

    // Connect lazily - don't connect at import time
    // The connection will be established on first query
    return client
  } catch (error) {
    console.error('Failed to create PrismaClient:', error)
    throw error
  }
}

// Create a proxy that lazily initializes PrismaClient
// This prevents the "Missing DATABASE_URL" error from crashing at module import time
let _prisma: PrismaClient | null = null

function getPrismaClient(): PrismaClient {
  if (!_prisma) {
    _prisma = createPrismaClient()
  }
  return _prisma
}

// Export a proxied db object that lazily creates the PrismaClient
export const db = new Proxy({} as PrismaClient, {
  get(_target, prop, receiver) {
    const client = getPrismaClient()
    const value = Reflect.get(client, prop, receiver)
    if (typeof value === 'function') {
      return value.bind(client)
    }
    return value
  },
})

// For direct access if needed (e.g., in scripts)
export { getPrismaClient }

if (process.env.NODE_ENV !== 'production' && typeof window === 'undefined') {
  // In development, cache the client on global to prevent
  // multiple instances during hot reloading
  if (!globalForPrisma.prisma) {
    globalForPrisma.prisma = getPrismaClient()
  }
}
