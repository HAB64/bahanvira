'use client';

import { Cpu, Palette, PenTool, Calculator, TrendingUp, GraduationCap, CheckCircle } from 'lucide-react';

const fieldGroups = [
  {
    icon: Cpu,
    title: 'فناوری اطلاعات',
    titleEn: 'Information Technology',
    description: 'سواد دیجیتال، نرم‌افزارهای اداری، برنامه‌نویسی و طراحی وب',
    color: '#0d9488',
    bgColor: '#ccfbf1',
    courses: [
      'ICDL درجه ۱',
      'ICDL درجه ۲',
      'E-Citizen',
      'کاربر رایانه ICDL درجه ۱',
      'کاربر رایانه درجه ۲',
      'کاربر نرم‌افزار Excel',
      'کاربر نرم‌افزار Access',
      'کاربر نرم‌افزار Word',
      'کاربر نرم‌افزار PowerPoint',
      'برنامه‌نویسی HTML',
      'برنامه‌نویسی JavaScript',
      'برنامه‌نویسی ++C مقدماتی',
      'برنامه‌نویسی Java',
      'برنامه‌نویسی C#',
      'Matlab',
      'طراحی صفحات وب',
      'Dreamweaver',
    ],
  },
  {
    icon: Palette,
    title: 'گرافیک و طراحی دیجیتال',
    titleEn: 'Graphic Design',
    description: 'فتوشاپ، کورل‌دراو، ایندیزاین، سه‌بعدی‌سازی و طراحی گرافیک',
    color: '#e11d48',
    bgColor: '#ffe4e6',
    courses: [
      'Photoshop',
      'Corel Draw',
      'Freehand',
      'InDesign',
      'گرافیک کامپیوتری',
      '3D Max',
      'طراحی پوستر و بنر',
      'طراحی گرافیک مقدماتی',
    ],
  },
  {
    icon: PenTool,
    title: 'معماری و نقشه‌کشی',
    titleEn: 'Architecture & Drafting',
    description: 'اتوکد، نقشه‌کشی ساختمان و طراحی داخلی',
    color: '#7c3aed',
    bgColor: '#ede9fe',
    courses: [
      'نقشه‌کشی ساختمان',
      'نقشه‌کشی ساختمان درجه ۲',
      'نقشه‌کشی با AutoCAD',
      'نقشه‌کشی سه‌بعدی با AutoCAD',
      'نقشه‌کشی سه‌بعدی با 3D Max',
      'طراحی معماری داخلی',
    ],
  },
  {
    icon: Calculator,
    title: 'حسابداری',
    titleEn: 'Accounting',
    description: 'حسابداری مالی و عملی با رویکرد بازارمحور',
    color: '#d97706',
    bgColor: '#fef3c7',
    courses: [
      'حسابداری مالی',
      'کار عملی حسابداری مالی',
      'هزینه‌های گوناگون',
      'هزینه گذشته سازمان',
    ],
  },
  {
    icon: TrendingUp,
    title: 'امور مالی و بازرگانی',
    titleEn: 'Finance & Commerce',
    description: 'اصول مالی، بازرگانی و مهارت‌های تجاری',
    color: '#0284c7',
    bgColor: '#e0f2fe',
    courses: [
      'اصول مالی و بازرگانی',
      'اصول مالی و بازرگانی (نسخه دوم)',
      'اصول مالی و بازرگانی درجه ۲',
    ],
  },
  {
    icon: GraduationCap,
    title: 'خدمات آموزشی و مهارت‌های نرم',
    titleEn: 'Educational Services & Soft Skills',
    description: 'مدیریت فردی، ارتباطات و مهارت‌های نرم حرفه‌ای',
    color: '#059669',
    bgColor: '#d1fae5',
    courses: [
      'مدیریت زمان',
      'مدیریت مالی',
      'مدیریت استرس',
      'زبان بدن',
      'تعامل و ارتباطات',
      'خدمات آموزشی عمومی',
    ],
  },
];

export default function FieldsSection() {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
            رشته‌های آموزشی بهان رایانه
          </h2>
          <p className="text-[#64748b] text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
            در آموزشگاه بهان رایانه، دوره‌های آموزشی در ۶ گروه تخصصی با مجوز رسمی سازمان فنی و حرفه‌ای ارائه می‌شود.
          </p>
        </div>

        {/* Field Groups Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {fieldGroups.map((group) => {
            const Icon = group.icon;
            return (
              <div
                key={group.title}
                className="group relative bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:shadow-gray-200/50 hover:border-gray-200 transition-all duration-200"
              >
                {/* Top accent bar */}
                <div className="h-1.5" style={{ backgroundColor: group.color }} />

                <div className="p-6">
                  {/* Icon + Title */}
                  <div className="flex items-start gap-4 mb-4">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: group.bgColor }}
                    >
                      <Icon className="w-6 h-6" style={{ color: group.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg font-bold text-[#0f172a] mb-1">{group.title}</h3>
                      <p className="text-xs text-[#64748b] leading-relaxed">{group.description}</p>
                    </div>
                  </div>

                  {/* Course List */}
                  <div className="space-y-2 mt-4">
                    {group.courses.map((course) => (
                      <div
                        key={course}
                        className="flex items-center gap-2.5"
                      >
                        <CheckCircle
                          className="w-3.5 h-3.5 flex-shrink-0"
                          style={{ color: group.color }}
                        />
                        <span className="text-sm text-[#475569]">{course}</span>
                      </div>
                    ))}
                  </div>

                  {/* Course Count Badge */}
                  <div className="mt-4 pt-4 border-t border-gray-100">
                    <span
                      className="text-xs font-semibold px-3 py-1 rounded-full"
                      style={{
                        backgroundColor: group.bgColor,
                        color: group.color,
                      }}
                    >
                      {group.courses.length} رشته آموزشی
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
