'use client';

import { useEffect, useRef, useState } from 'react';
import { Award, Calendar, Users, BookOpen, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toPersianNumber } from '@/lib/persian';

const stats = [
  { icon: Calendar, target: 27, suffix: '', label: 'سال تجربه' },
  { icon: Users, target: 5000, suffix: '+', label: 'فارغ‌التحصیل' },
  { icon: BookOpen, target: 12, suffix: '', label: 'دوره تخصصی' },
  { icon: Award, target: 4, suffix: '', label: 'خوشه شایستگی' },
];

function useCountUp(target: number, duration: number = 2000) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started) {
          setStarted(true);
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;

    let startTime: number;
    let animationFrame: number;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      
      // Easing function for smooth animation
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * target));

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrame);
  }, [started, target, duration]);

  return { count, ref };
}

function StatCounter({
  icon: Icon,
  target,
  suffix,
  label,
}: {
  icon: React.ElementType;
  target: number;
  suffix: string;
  label: string;
}) {
  const { count, ref } = useCountUp(target, target > 100 ? 2500 : 1500);

  return (
    <div
      ref={ref}
      className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-5 border border-white/20"
    >
      <Icon className="h-6 w-6 text-white/80 mx-auto mb-2" />
      <div className="text-xl sm:text-2xl font-bold text-white mb-1">
        {toPersianNumber(count.toLocaleString())}
        {suffix}
      </div>
      <div className="text-sm text-white/80">{label}</div>
    </div>
  );
}

export default function HeroSection() {
  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-bl from-[#0d9488] via-[#0f766e] to-[#115e59]">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="heroGrid" width="60" height="60" patternUnits="userSpaceOnUse">
                <path d="M 60 0 L 0 0 0 60" fill="none" stroke="white" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#heroGrid)" />
          </svg>
        </div>
        <div className="absolute top-20 right-20 w-72 h-72 bg-white/5 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-white/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-28">
        <div className="text-center max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-full px-5 py-2 border border-white/20 mb-6">
            <Award className="h-4 w-4 text-white/90" />
            <span className="text-sm text-white/90 font-medium">تحت مدیریت دکتر بهان</span>
          </div>

          {/* Main Heading */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-white leading-tight mb-6">
            آموزشگاه بهان رایانه
          </h1>
          <p className="text-lg sm:text-xl text-white/90 mb-4 leading-relaxed max-w-2xl mx-auto">
            ۲۷ سال تجربه درخشان در آموزش مهارت‌های کامپیوتری و کسب‌وکار
          </p>
          <p className="text-base text-white/70 mb-10 max-w-xl mx-auto">
            از ICDL تا برنامه‌نویسی حرفه‌ای، مسیر یادگیری خود را با ما آغاز کنید
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-14">
            <Button
              size="lg"
              asChild
              className="bg-white text-[#0d9488] hover:bg-gray-100 text-base sm:text-lg px-8 py-6 rounded-xl shadow-lg hover:shadow-xl transition-all font-bold"
            >
              <a href="#contact">
                مشاوره رایگان
                <ArrowLeft className="h-5 w-5 mr-2" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="border-white/30 text-white hover:bg-white/10 text-base sm:text-lg px-8 py-6 rounded-xl transition-all"
            >
              <a href="#courses">مشاهده دوره‌ها</a>
            </Button>
          </div>

          {/* Stats Row with Counter Animation */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
            {stats.map((stat) => (
              <StatCounter key={stat.label} {...stat} />
            ))}
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 w-full">
        <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M0 80L60 68C120 56 240 32 360 24C480 16 600 24 720 32C840 40 960 48 1080 48C1200 48 1320 40 1380 36L1440 32V80H1380C1320 80 1200 80 1080 80C960 80 840 80 720 80C600 80 480 80 360 80C240 80 120 80 60 80H0Z"
            fill="white"
          />
        </svg>
      </div>
    </section>
  );
}
