'use client'

import { useState, useCallback } from 'react'
import { Star, X, Send, CheckCircle2, Loader2, MessageSquare } from 'lucide-react'

interface SurveyWidgetProps {
  skillProgramId?: string
  instructorName?: string
  type?: string
}

export default function SurveyWidget({ 
  skillProgramId, 
  instructorName, 
  type = 'POST_COURSE' 
}: SurveyWidgetProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Scores (1-5)
  const [contentQuality, setContentQuality] = useState(0)
  const [instructorScore, setInstructorScore] = useState(0)
  const [facilitiesScore, setFacilitiesScore] = useState(0)
  const [overallScore, setOverallScore] = useState(0)

  // Optional text
  const [comment, setComment] = useState('')
  const [suggestion, setSuggestion] = useState('')

  const handleSubmit = useCallback(async () => {
    if (overallScore === 0) {
      setError('لطفاً حداقل امتیاز کلی را وارد کنید')
      return
    }

    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/survey', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          skillProgramId: skillProgramId || undefined,
          instructorName: instructorName || undefined,
          type,
          contentQuality,
          instructorScore,
          facilitiesScore,
          overallScore,
          comment: comment || undefined,
          suggestion: suggestion || undefined,
          wouldRecommend: overallScore >= 4,
          source: 'WEB',
          isAnonymous: false,
        }),
      })

      const data = await res.json()
      if (!res.ok) {
        setError(data['خطا'] || 'خطا در ثبت نظرسنجی')
        return
      }

      setSubmitted(true)

      // Track survey submission event
      fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'FORM_SUBMIT',
          category: 'engagement',
          label: 'Survey submitted',
          metadata: { type, overallScore },
        }),
      }).catch(() => {})
    } catch {
      setError('خطا در ارتباط با سرور')
    } finally {
      setLoading(false)
    }
  }, [contentQuality, instructorScore, facilitiesScore, overallScore, comment, suggestion, skillProgramId, instructorName, type])

  // Star rating component
  const StarRating = ({ value, onChange, label }: { value: number; onChange: (v: number) => void; label: string }) => (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm text-gray-700 font-medium min-w-[100px]">{label}</span>
      <div className="flex gap-1" dir="ltr">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="p-0.5"
          >
            <Star
              className={`w-6 h-6 transition-colors ${
                star <= value ? 'text-amber-400 fill-amber-400' : 'text-gray-300'
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  )

  // Thank you state
  if (submitted && !isOpen) {
    return null
  }

  return (
    <>
      {/* Floating Button */}
      {!isOpen && !submitted && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 left-6 z-50 bg-teal-600 hover:bg-teal-500 text-white rounded-full p-4 shadow-lg shadow-teal-600/30"
          aria-label="نظرسنجی"
        >
          <MessageSquare className="w-6 h-6" />
        </button>
      )}

      {/* Modal Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setIsOpen(false)}
          />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto" dir="rtl">
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b">
              <h3 className="font-bold text-gray-900 text-base">نظرسنجی دوره</h3>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
                aria-label="بستن"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Body */}
            {submitted ? (
              <div className="p-8 text-center">
                <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
                <h4 className="font-bold text-gray-900 text-lg mb-2">
                  با تشکر از نظر شما!
                </h4>
                <p className="text-gray-500 text-sm mb-4">
                  بازخورد شما به بهبود کیفیت دوره‌ها کمک می‌کند
                </p>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-sm text-teal-600 hover:text-teal-700 font-medium"
                >
                  بستن
                </button>
              </div>
            ) : (
              <div className="p-5 space-y-5">
                {/* Star Ratings */}
                <div className="space-y-4">
                  <StarRating value={contentQuality} onChange={setContentQuality} label="کیفیت محتوا" />
                  <StarRating value={instructorScore} onChange={setInstructorScore} label="امتیاز مدرس" />
                  <StarRating value={facilitiesScore} onChange={setFacilitiesScore} label="امکانات" />
                  <div className="border-t pt-4">
                    <StarRating value={overallScore} onChange={setOverallScore} label="امتیاز کلی" />
                  </div>
                </div>

                {/* Comment */}
                <div>
                  <label className="block text-sm text-gray-700 font-medium mb-1.5">
                    نظر شما (اختیاری)
                  </label>
                  <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm resize-none"
                    placeholder="نظر خود را بنویسید..."
                  />
                </div>

                {/* Suggestion */}
                <div>
                  <label className="block text-sm text-gray-700 font-medium mb-1.5">
                    پیشنهاد بهبود (اختیاری)
                  </label>
                  <textarea
                    value={suggestion}
                    onChange={(e) => setSuggestion(e.target.value)}
                    rows={2}
                    className="w-full px-3 py-2.5 rounded-xl border border-gray-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition-all text-sm resize-none"
                    placeholder="چه چیزی می‌تواند بهتر شود؟"
                  />
                </div>

                {error && (
                  <div className="text-red-500 text-xs bg-red-50 rounded-lg px-3 py-2">
                    {error}
                  </div>
                )}

                {/* Submit */}
                <button
                  onClick={handleSubmit}
                  disabled={loading}
                  className="w-full bg-teal-600 hover:bg-teal-500 disabled:bg-teal-600/50 text-white font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 text-sm"
                >
                  {loading ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> در حال ثبت...</>
                  ) : (
                    <><Send className="w-4 h-4" /> ثبت نظرسنجی</>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  )
}
