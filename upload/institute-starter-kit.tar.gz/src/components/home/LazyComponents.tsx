'use client';

import dynamic from 'next/dynamic';

// ─── Lazy-load heavy interactive components that are not critical for initial render ───

const CareerPathQuiz = dynamic(() => import('@/components/home/CareerPathQuiz'), {
  ssr: false,
  loading: () => (
    <section className="py-16 sm:py-20 bg-[#0f172a]">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <div className="w-10 h-10 border-4 border-[#0d9488] border-t-transparent rounded-full animate-spin mx-auto" />
      </div>
    </section>
  ),
});

const ExitIntentPopup = dynamic(() => import('@/components/ExitIntentPopup'), {
  ssr: false,
});

const FAQSection = dynamic(() => import('@/components/home/FAQSection'), {
  loading: () => (
    <section className="py-16 sm:py-20 bg-[#0f172a]">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <div className="w-10 h-10 border-4 border-[#0d9488] border-t-transparent rounded-full animate-spin mx-auto" />
      </div>
    </section>
  ),
});

// Social Proof + CTA ادغام‌شده — یک سکشن فشرده به جای دو سکشن مجزا
const SocialProofAndCTA = dynamic(() => import('@/components/home/SocialProofAndCTA'), {
  ssr: false,
  loading: () => (
    <section className="py-14 sm:py-16 bg-[#0f172a]">
      <div className="max-w-7xl mx-auto px-4 text-center">
        <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto" />
      </div>
    </section>
  ),
});

// Phase 2: PersonalizedRecommendations — پیشنهاد تعاملی هوشمند
const PersonalizedRecommendations = dynamic(() => import('@/components/ai/PersonalizedRecommendations'), {
  ssr: false,
});

// Phase 2: GatedContentSection — محتوای پشت درِ لید
const GatedContentSection = dynamic(() => import('@/components/home/GatedContentSection'), {
  ssr: false,
  loading: () => (
    <section className="py-16 sm:py-20 bg-[#0f172a]">
      <div className="max-w-3xl mx-auto px-4 text-center">
        <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto" />
      </div>
    </section>
  ),
});

// Phase 4: BehaviorTracker — ردیابی رفتار کاربران (deferred 5s)
const BehaviorTracker = dynamic(() => import('@/components/ai/BehaviorTracker'), {
  ssr: false,
});

// Phase 4: WebVitalsReporter — جمع‌آوری Core Web Vitals
const WebVitalsReporter = dynamic(() => import('@/components/home/WebVitalsReporter'), {
  ssr: false,
});

export {
  CareerPathQuiz,
  ExitIntentPopup,
  FAQSection,
  SocialProofAndCTA,
  PersonalizedRecommendations,
  GatedContentSection,
  BehaviorTracker,
  WebVitalsReporter,
};
