import Link from 'next/link';
import { ArrowLeft, Target, Rocket, TrendingUp, Building2, CandlestickChart, GraduationCap, Sparkles } from 'lucide-react';
import { siteConfig } from '@/config/site';

const personaData = [
  {
    title: 'کارجو و ورود به بازار کار',
    description: 'مهارت‌های پایه → استخدام و بازار کار',
    icon: Target,
    color: '#0d9488',
    gradient: 'from-teal-500 to-emerald-600',
    clusters: ['فناوری اطلاعات', 'ICDL'],
    cta: 'شروع از ICDL',
    href: '/courses/icdl',
  },
  {
    title: 'ارتقای مهارت با هوش مصنوعی',
    description: 'AI پیشرفته → اتوماسیون سیستم‌ها و درآمد',
    icon: Rocket,
    color: '#8B5CF6',
    gradient: 'from-violet-500 to-purple-600',
    clusters: ['هوش مصنوعی', 'پایتون'],
    cta: 'شروع از پایتون',
    href: '/courses/python',
  },
  {
    title: 'درآمد از بازار سرمایه',
    description: 'تحلیل تکنیکال و بنیادی → معامله‌گری حرفه‌ای',
    icon: CandlestickChart,
    color: '#0284c7',
    gradient: 'from-blue-500 to-cyan-600',
    clusters: ['بازار سرمایه', 'بورس'],
    cta: 'دوره‌های بازار سرمایه',
    href: '/courses?cluster=capital-market',
  },
  {
    title: 'درآمد دلاری و فارکس',
    description: 'فارکس / MQL5 → بازارهای جهانی',
    icon: TrendingUp,
    color: '#d97706',
    gradient: 'from-amber-500 to-orange-600',
    clusters: ['فارکس', 'ترید الگوریتمی'],
    cta: 'دوره‌های مالی',
    href: '/courses?cluster=finance',
  },
  {
    title: 'مشتری سازمانی و کارآفرین',
    description: 'مشاوره کارآفرینی → توسعه و رشد بنگاه',
    icon: Building2,
    color: '#7c3aed',
    gradient: 'from-purple-500 to-indigo-600',
    clusters: ['کارآفرینی', 'مشاوره'],
    cta: 'درخواست مشاوره',
    href: '/consulting',
  },
  {
    title: 'مربی و مدرس حرفه‌ای',
    description: 'پداگوژی، فن بیان → تدریس حرفه‌ای',
    icon: GraduationCap,
    color: '#059669',
    gradient: 'from-emerald-500 to-green-600',
    clusters: ['خدمات آموزشی', 'LMS'],
    cta: 'دوره‌های آموزشی',
    href: '/courses?cluster=educational-services',
  },
];

export default function PersonaRoutes() {
  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Dark professional background with animated gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#0d1f3c] to-[#0a1628] animate-gradient-shift" />

      {/* Decorative grid */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(13,148,136,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(13,148,136,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Glow effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-teal-600/15 rounded-full blur-[120px] animate-glow-pulse-intense" />
      <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-violet-600/10 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: '3s' }} />

      {/* Floating particles */}
      <div className="absolute top-20 right-1/4 w-2.5 h-2.5 bg-teal-400/30 rounded-full animate-particle-1" />
      <div className="absolute bottom-20 left-1/3 w-2 h-2 bg-violet-400/25 rounded-full animate-particle-2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-10">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-teal-300 bg-teal-500/15 backdrop-blur-md border border-teal-500/20 rounded-full px-4 py-1.5 mb-3 animate-float-slow">
            <Sparkles className="w-3.5 h-3.5" />
            مسیردهی هوشمند
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">
            کدام مسیر شغلی مناسب شماست؟
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto leading-relaxed text-sm">
            مسیر خود را انتخاب کنید و از همان نقطه‌ای که هستید شروع کنید.
          </p>
        </div>

        {/* Persona Cards — dark glassmorphism style */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {personaData.map((persona) => (
            <Link
              key={persona.title}
              href={persona.href}
              className="group relative glass-card rounded-2xl p-5"
            >
              {/* Icon */}
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ backgroundColor: persona.color + '25' }}>
                <persona.icon className="w-5 h-5" style={{ color: persona.color }} />
              </div>

              {/* Content */}
              <h3 className="font-bold text-white text-sm mb-1.5">{persona.title}</h3>
              <p className="text-xs text-gray-400 mb-3 leading-relaxed">{persona.description}</p>

              {/* Cluster tags */}
              <div className="flex gap-1.5 mb-3">
                {persona.clusters.map((tag) => (
                  <span
                    key={tag}
                    className="text-[10px] font-medium px-2 py-0.5 rounded-md border border-white/10"
                    style={{ backgroundColor: persona.color + '15', color: persona.color }}
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Arrow */}
              <div
                className="flex items-center gap-1 text-xs font-medium"
                style={{ color: persona.color }}
              >
                {persona.cta}
                <ArrowLeft className="w-3 h-3" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
