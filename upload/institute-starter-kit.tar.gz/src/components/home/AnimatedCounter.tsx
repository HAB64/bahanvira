'use client';

import { useEffect, useRef, useState } from 'react';

interface AnimatedCounterProps {
  target: number;
  suffix?: string;
  className?: string;
}

export default function AnimatedCounter({ target, suffix = '', className = 'text-3xl sm:text-4xl font-bold text-white' }: AnimatedCounterProps) {
  const [animatedValue, setAnimatedValue] = useState<number | null>(null);
  const hasStarted = useRef(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (hasStarted.current) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasStarted.current) {
          hasStarted.current = true;
          observer.disconnect();

          const duration = 2000;
          const startTime = performance.now();

          const animate = (currentTime: number) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            // Ease-out cubic for smooth deceleration
            const eased = 1 - Math.pow(1 - progress, 3);
            const currentValue = Math.round(eased * target);

            setAnimatedValue(currentValue);

            if (progress < 1) {
              requestAnimationFrame(animate);
            } else {
              setAnimatedValue(target);
            }
          };

          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.2 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  // Before animation starts, show target (correct for SSR/SEO)
  // After animation starts, show animated value
  // This prevents the flash from target → 0 → animate
  const displayValue = animatedValue !== null ? animatedValue : target;

  return (
    <div ref={ref} className={className}>
      {displayValue.toLocaleString('fa-IR')}{suffix}
    </div>
  );
}
