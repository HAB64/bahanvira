'use client';

import { useState } from 'react';
import Link from 'next/link';
import {
  Shield, GraduationCap, CheckCircle2, BookOpen, Star,
  Quote, Briefcase, ArrowLeft, ThumbsUp, Award,
  Phone, MessageCircle, Sparkles,
} from 'lucide-react';
import { alumni, clusterColors } from '@/data/alumni';
import { courses } from '@/data/courses';
import { siteConfig } from '@/config/site';

// ─── فقط ۳ نظر برتر (یک نظر از هر خوشه اصلی) ───
const featuredReviews = courses
  .filter(c => c.reviews.length > 0 && c.isFeatured)
  .map(course => {
    const top = course.reviews.find(r => r.rating === 5) || course.reviews[0];
    return { ...top, courseTitle: course.title, courseColor: course.color, clusterLabel: course.clusterLabel };
  })
  .slice(0, 3);

// ─── فقط ۳ فارغ‌التحصیل برتر ───
const featuredAlumni = alumni.slice(0, 3);

// ─── اعتبارنامه‌ها ───
const credentials = siteConfig.trust.slice(0, 2);

/**
 * ─── Social Proof + CTA ادغام‌شده ───
 * 
 * اصل: کاهش بار شناختی — ۲ سکشن مجزا → یک سکشن فشرده
 * ساختار: آمار → نظرات + فارغ‌التحصیلان → اعتبارنامه‌ها → CTA نهایی
 */
export default function SocialProofAndCTA() {
  const [expandedAlumni, setExpandedAlumni] = useState<number | null>(null);

  return (
    <section className="py-14 sm:py-20 relative overflow-hidden">
      {/* پس‌زمینه */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#111827] to-[#0a1628]" />
      <div className="absolute top-0 right-1/4 w-80 h-80 bg-teal-600/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-amber-600/8 rounded-full blur-[100px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* ── هدر سکشن ── */}
        <div className="text-center mb-10">
          <h2 className="text-xl sm:text-2xl font-bold text-white mb-2">
            اعتبار و نتایج واقعی
          </h2>
          <p className="text-sm text-gray-400 max-w-xl mx-auto">
            {siteConfig.experience.yearsFa} سال اعتبار، {siteConfig.trust[0].title} و هزاران فارغ‌التحصیل موفق
          </p>
        </div>

        {/* ── ردیف ۱: آمار کلیدی + اعتبارنامه‌ها ── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
          {[
            { value: '۴.۸', label: 'امتیاز دوره‌ها', icon: Star },
            { value: '۹۵٪', label: 'رضایت کارآموزان', icon: ThumbsUp },
            { value: '۵,۰۰۰+', label: 'فارغ‌التحصیل', icon: GraduationCap },
            { value: '۹۰٪', label: 'نرخ اشتغال', icon: Briefcase },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={i} className="glass-card-lite rounded-xl p-3.5 text-center">
                <Icon className="w-4 h-4 text-teal-400 mx-auto mb-1.5" />
                <div className="text-lg font-bold text-teal-300">{stat.value}</div>
                <div className="text-[10px] text-gray-400">{stat.label}</div>
              </div>
            );
          })}
        </div>

        {/* ── ردیف ۲: نظرات + فارغ‌التحصیلان ── */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* نظرات کارآموزان */}
          <div>
            <h3 className="text-sm font-bold text-gray-300 mb-4 flex items-center gap-2">
              <Quote className="w-4 h-4 text-teal-400" />
              نظرات کارآموزان
            </h3>
            <div className="space-y-3">
              {featuredReviews.map((review, i) => (
                <div key={i} className="glass-card-lite rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex gap-0.5">
                      {[...Array(5)].map((_, j) => (
                        <Star key={j} className={`w-3 h-3 ${j < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-600'}`} />
                      ))}
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full border border-white/10" style={{ backgroundColor: review.courseColor + '15', color: review.courseColor }}>
                      {review.clusterLabel}
                    </span>
                  </div>
                  <p className="text-xs text-gray-300 leading-relaxed mb-2">&laquo;{review.text}&raquo;</p>
                  <p className="text-[10px] text-gray-500 font-medium">{review.name} — {review.role}</p>
                </div>
              ))}
            </div>
          </div>

          {/* فارغ‌التحصیلان موفق */}
          <div>
            <h3 className="text-sm font-bold text-gray-300 mb-4 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-amber-400" />
              فارغ‌التحصیلان موفق
            </h3>
            <div className="space-y-3">
              {featuredAlumni.map((person, i) => {
                const colors = clusterColors[person.cluster] ?? { color: '#0d9488' };
                return (
                  <div
                    key={i}
                    className="glass-card-lite rounded-xl overflow-hidden cursor-pointer hover:border-teal-500/20 transition-colors"
                    onClick={() => setExpandedAlumni(expandedAlumni === i ? null : i)}
                  >
                    <div className="h-1" style={{ background: `linear-gradient(to left, ${colors.color}, ${colors.color}88)` }} />
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h4 className="font-bold text-sm text-white">{person.name}</h4>
                          <span className="text-[10px] px-2 py-0.5 rounded-full border border-white/10" style={{ backgroundColor: colors.color + '20', color: colors.color }}>
                            {person.course}
                          </span>
                        </div>
                        <span className="text-[10px] text-gray-500">فارغ‌التحصیل {person.year}</span>
                      </div>

                      {/* دستاورد */}
                      <div className="flex items-center gap-1.5 mb-2">
                        <div className="w-5 h-5 rounded flex items-center justify-center" style={{ backgroundColor: colors.color + '20' }}>
                          <Award className="w-3 h-3" style={{ color: colors.color }} />
                        </div>
                        <span className="text-xs font-medium" style={{ color: colors.color }}>{person.achievement}</span>
                      </div>

                      {/* نقل قول (فقط وقتی باز شود) */}
                      {expandedAlumni === i && (
                        <p className="text-xs text-gray-300 leading-relaxed mt-2 pr-4 border-r-2 border-teal-500/30">
                          &laquo;{person.quote}&raquo;
                        </p>
                      )}

                      {/* شغل فعلی */}
                      <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-white/5">
                        <Briefcase className="w-3 h-3 text-teal-400" />
                        <span className="text-[10px] text-gray-400">{person.role}{person.company ? ` — ${person.company}` : ''}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ── ردیف ۳: اعتبارنامه‌ها + بنیان‌گذار ── */}
        <div className="grid sm:grid-cols-3 gap-4 mb-12">
          {credentials.map((cred, i) => {
            const Icon = i === 0 ? Shield : BookOpen;
            return (
              <div key={cred.title} className="glass-card-lite rounded-xl p-4 flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-teal-500/15 flex items-center justify-center flex-shrink-0">
                  <Icon className="w-4.5 h-4.5 text-teal-400" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-white mb-0.5">{cred.title}</h4>
                  <p className="text-[10px] text-gray-400 leading-relaxed">{cred.description}</p>
                </div>
              </div>
            );
          })}

          {/* بنیان‌گذار */}
          <div className="glass-card-lite rounded-xl p-4 flex items-start gap-3" style={{ background: 'linear-gradient(135deg, rgba(13,148,136,0.15), rgba(15,23,42,0.5))' }}>
            <div className="w-9 h-9 rounded-lg bg-teal-500/20 flex items-center justify-center flex-shrink-0">
              <GraduationCap className="w-4.5 h-4.5 text-[#5eead4]" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-white mb-0.5">{siteConfig.founder.name}</h4>
              <p className="text-[10px] text-gray-400">{siteConfig.founder.title}</p>
              <div className="flex items-center gap-1 mt-1">
                <CheckCircle2 className="w-3 h-3 text-teal-400" />
                <span className="text-[10px] text-teal-300">{siteConfig.founder.credentials[0]}</span>
              </div>
            </div>
          </div>
        </div>

        {/* ═══════════════════════════════════════════
            CTA نهایی — ادغام‌شده در انتهای Social Proof
            ═══════════════════════════════════════════ */}
        <div className="relative rounded-2xl overflow-hidden">
          {/* Gradient CTA background */}
          <div className="absolute inset-0 bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#0f766e]" />

          <div className="relative z-10 p-8 sm:p-12 text-center">
            <div className="inline-flex items-center gap-1.5 bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-4 py-1.5 mb-4">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span className="text-xs font-medium text-amber-200">شروع یادگیری</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-white mb-3">
              آماده‌اید مهارت جدید یاد بگیرید؟
            </h2>
            <p className="text-white/80 text-sm leading-relaxed mb-6 max-w-lg mx-auto">
              همین الان مشاوره رایگان دریافت کنید و مسیر شغلی مناسب خود را پیدا کنید.
              تیم مشاوره {siteConfig.name.fullName} آماده راهنمایی شماست.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                href="/consulting"
                className="group inline-flex items-center justify-center gap-2 bg-white text-[#0f766e] font-bold px-8 py-3.5 rounded-xl hover:bg-gray-50 transition-all shadow-lg shadow-black/10 text-sm"
              >
                درخواست مشاوره رایگان
                <ArrowLeft className="w-4 h-4" />
              </Link>
              <a
                href={siteConfig.contact.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white font-bold px-8 py-3.5 rounded-xl hover:bg-[#20ba5c] transition-all shadow-lg shadow-black/10 text-sm"
              >
                <MessageCircle className="w-5 h-5" />
                پیام در واتساپ
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
