'use client';

import { useState } from 'react';
import PersonalizedHero from './PersonalizedHero';
import type { PersonalizationConfig } from '@/lib/personalization';

/**
 * Client wrapper for the PersonalizedHero Server Component.
 * Handles the dismiss state since Server Components can't have onClick handlers.
 * The personalization config is computed server-side from the br_campaign cookie
 * and passed down as a prop.
 */
export default function PersonalizedHeroClient({
  personalization,
}: {
  personalization: PersonalizationConfig;
}) {
  const [dismissed, setDismissed] = useState(false);

  if (personalization.persona === 'default') {
    return null;
  }

  return (
    <PersonalizedHero
      {...personalization}
      dismissed={dismissed}
      onDismiss={() => setDismissed(true)}
    />
  );
}
