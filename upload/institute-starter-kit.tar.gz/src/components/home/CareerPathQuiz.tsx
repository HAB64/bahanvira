'use client';

import { useState } from 'react';
import {
  Target, Rocket, TrendingUp, Building2, Monitor, Code2,
  Brain, BarChart3, Calculator, Lightbulb, Palette,
  Gamepad2, ArrowLeft, ArrowRight, CheckCircle2,
  Sparkles, Phone, User, Clock, BookOpen, Star,
  Briefcase, GraduationCap, Zap, Award, ChevronLeft,
} from 'lucide-react';
import Link from 'next/link';
import { useUTM } from '@/hooks/use-utm';
import { siteConfig } from '@/config/site';

// ─── Types ───────────────────────────────────────────────────────
interface QuizAnswer {
  goal: string;
  level: string;
  interest: string;
  schedule: string;
  style: string;
}

interface RecommendedCourse {
  slug: string;
  title: string;
  icon: React.ElementType;
  color: string;
  level: string;
  duration: string;
  levelOrder: number;
}

interface QuizResult {
  title: string;
  description: string;
  clusterLink: string;
  clusterName: string;
  courses: RecommendedCourse[];
  color: string;
  careerPaths: string[];
  salary: string;
}

// ─── Quiz Data ───────────────────────────────────────────────────
const goalOptions = [
  { id: 'career', label: 'ورود به بازار کار', description: 'می‌خوام مهارت بگیرم و استخدام شم', icon: Target, color: '#0d9488' },
  { id: 'upgrade', label: 'ارتقای مهارت', description: 'می‌خوام سطح فنی‌ام رو بالا ببرم', icon: Rocket, color: '#2563eb' },
  { id: 'income', label: 'درآمد دلاری / مالی', description: 'می‌خوام از بازارهای مالی درآمد داشته باشم', icon: TrendingUp, color: '#d97706' },
  { id: 'business', label: 'رشد کسب‌وکار', description: 'صاحب کسب‌وکار هستم یا می‌خوام بشم', icon: Building2, color: '#7c3aed' },
];

const levelOptions = [
  { id: 'beginner', label: 'مبتدی', description: 'تجربه قبلی ندارم', icon: BookOpen, color: '#10b981' },
  { id: 'intermediate', label: 'متوسط', description: 'آشنایی اولیه دارم', icon: Zap, color: '#f59e0b' },
  { id: 'advanced', label: 'پیشرفته', description: 'تجربه کار دارم', icon: Award, color: '#ef4444' },
];

const interestOptions = [
  { id: 'tech', label: 'فناوری اطلاعات', description: 'کدنویسی، هوش مصنوعی، اتوماسیون', icon: Code2, color: '#0d9488' },
  { id: 'ai', label: 'هوش مصنوعی و علوم داده', description: 'پایتون، یادگیری ماشین، AI محلی', icon: Brain, color: '#8B5CF6' },
  { id: 'capital-market', label: 'بازار سرمایه', description: 'بورس، تحلیل تکنیکال، مدیریت پرتفوی', icon: BarChart3, color: '#0284c7' },
  { id: 'finance', label: 'بازارهای مالی', description: 'فارکس، معامله‌گری، درآمد دلاری', icon: TrendingUp, color: '#d97706' },
  { id: 'management', label: 'کارآفرینی و کسب‌وکار', description: 'حسابداری، مشاوره، سیستم‌سازی', icon: Lightbulb, color: '#7c3aed' },
  { id: 'creative', label: 'مهندسی و هنر کاربردی', description: 'نقشه‌کشی، مدل‌سازی، طراحی', icon: Palette, color: '#e11d48' },
];

const scheduleOptions = [
  { id: 'morning', label: 'صبح', description: 'شنبه تا چهارشنبه ۸ تا ۱۲', icon: Clock, color: '#f59e0b' },
  { id: 'afternoon', label: 'بعدازظهر', description: 'شنبه تا چهارشنبه ۱۴ تا ۱۸', icon: Clock, color: '#0d9488' },
  { id: 'evening', label: 'عصر', description: 'شنبه تا چهارشنبه ۱۸ تا ۲۰', icon: Clock, color: '#8B5CF6' },
  { id: 'flexible', label: 'انعطاف‌پذیر', description: 'هر شیفت ممکن است', icon: Clock, color: '#64748b' },
];

const styleOptions = [
  { id: 'practical', label: 'عملی و پروژه‌محور', description: 'ترجیح می‌دم با انجام پروژه یاد بگیرم', icon: Briefcase, color: '#0d9488' },
  { id: 'theoretical', label: 'تئوری و مفهومی', description: 'اول مفاهیم رو بفهمم بعد عمل کنم', icon: BookOpen, color: '#2563eb' },
  { id: 'fast', label: 'سریع و فشرده', description: 'می‌خوام زودتر تمام کنم و وارد بازار شم', icon: Rocket, color: '#f59e0b' },
];

// ─── Result Logic — Conditional branching with enriched data ───
function getResult(answer: QuizAnswer): QuizResult {
  const { goal, level, interest } = answer;

  if (interest === 'tech') {
    if (level === 'beginner') {
      return {
        title: 'مسیر شغلی: توسعه‌دهنده فناوری',
        description: 'شما مسیر مناسبی برای ورود به دنیای فناوری دارید. از سواد دیجیتال شروع کنید و به برنامه‌نویسی و هوش مصنوعی برسید.',
        clusterLink: '/courses/cluster/it',
        clusterName: 'فناوری اطلاعات',
        color: '#0d9488',
        careerPaths: ['کارشناس IT', 'برنامه‌نویس مبتدی', 'پشتیبان فنی'],
        salary: '۱۵ تا ۳۰ میلیون تومان',
        courses: [
          { slug: 'icdl', title: 'ICDL — سواد دیجیتال بین‌المللی', icon: Monitor, color: '#0d9488', level: 'مبانی', duration: '۲-۳ ماه', levelOrder: 0 },
          { slug: 'python', title: 'Python — برنامه‌نویسی حرفه‌ای', icon: Code2, color: '#2563eb', level: 'تخصصی', duration: '۳-۴ ماه', levelOrder: 1 },
        ],
      };
    }
    if (level === 'intermediate') {
      return {
        title: 'مسیر شغلی: متخصص پایتون و تحلیل داده',
        description: 'با پایه فعلی شما، مسیر حرفه‌ای پایتون و تحلیل داده بهترین گزینه است.',
        clusterLink: '/courses/cluster/it',
        clusterName: 'فناوری اطلاعات',
        color: '#2563eb',
        careerPaths: ['توسعه‌دهنده پایتون', 'تحلیل‌گر داده', 'مهندس نرم‌افزار'],
        salary: '۲۵ تا ۵۰ میلیون تومان',
        courses: [
          { slug: 'python', title: 'Python — برنامه‌نویسی حرفه‌ای', icon: Code2, color: '#2563eb', level: 'تخصصی', duration: '۳-۴ ماه', levelOrder: 0 },
          { slug: 'local-ai-ollama', title: 'هوش مصنوعی محلی — Ollama', icon: Brain, color: '#7c3aed', level: 'پیشرفته', duration: '۳-۵ ماه', levelOrder: 1 },
        ],
      };
    }
    return {
      title: 'مسیر شغلی: مهندس نرم‌افزار',
      description: 'با تجربه فنی شما، توسعه وب و اپلیکیشن گام بعدی است.',
      clusterLink: '/courses/cluster/it',
      clusterName: 'فناوری اطلاعات',
      color: '#7c3aed',
      careerPaths: ['مهندس نرم‌افزار', 'Team Lead', 'CTO'],
      salary: '۴۰ تا ۸۰+ میلیون تومان',
      courses: [
        { slug: 'python', title: 'Python — برنامه‌نویسی حرفه‌ای', icon: Code2, color: '#0d9488', level: 'تخصصی', duration: '۳-۴ ماه', levelOrder: 0 },
        { slug: 'local-ai-ollama', title: 'هوش مصنوعی محلی — Ollama', icon: Brain, color: '#7c3aed', level: 'پیشرفته', duration: '۳-۵ ماه', levelOrder: 1 },
      ],
    };
  }

  if (interest === 'ai') {
    if (level === 'beginner') {
      return {
        title: 'مسیر شغلی: توسعه‌دهنده هوش مصنوعی',
        description: 'از تفکر الگوریتمی شروع کنید و به ساخت سیستم‌های هوشمند برسید.',
        clusterLink: '/courses/cluster/ai',
        clusterName: 'هوش مصنوعی و علوم داده',
        color: '#8B5CF6',
        careerPaths: ['توسعه‌دهنده AI مبتدی', 'پژوهشگر داده', 'AI Engineer'],
        salary: '۲۵ تا ۶۰ میلیون تومان',
        courses: [
          { slug: 'scratch', title: 'Scratch — تفکر الگوریتمی', icon: Gamepad2, color: '#F97316', level: 'مبانی', duration: '۱-۲ ماه', levelOrder: 0 },
          { slug: 'python', title: 'Python — برنامه‌نویسی حرفه‌ای', icon: Code2, color: '#2563eb', level: 'تخصصی', duration: '۳-۴ ماه', levelOrder: 1 },
          { slug: 'local-ai-ollama', title: 'هوش مصنوعی محلی — Ollama', icon: Brain, color: '#7c3aed', level: 'پیشرفته', duration: '۳-۵ ماه', levelOrder: 2 },
        ],
      };
    }
    return {
      title: 'مسیر شغلی: متخصص هوش مصنوعی',
      description: 'با پایه فعلی شما، مسیر حرفه‌ای علوم داده و AI بهترین گزینه است.',
      clusterLink: '/courses/cluster/ai',
      clusterName: 'هوش مصنوعی و علوم داده',
      color: '#2563eb',
      careerPaths: ['AI Engineer', 'Data Scientist', 'ML Researcher'],
      salary: '۴۰ تا ۱۰۰+ میلیون تومان',
      courses: [
        { slug: 'python', title: 'Python — برنامه‌نویسی حرفه‌ای', icon: Code2, color: '#2563eb', level: 'تخصصی', duration: '۳-۴ ماه', levelOrder: 0 },
        { slug: 'local-ai-ollama', title: 'هوش مصنوعی محلی — Ollama', icon: Brain, color: '#7c3aed', level: 'پیشرفته', duration: '۳-۵ ماه', levelOrder: 1 },
      ],
    };
  }

  if (interest === 'capital-market') {
    return {
      title: level === 'beginner' ? 'مسیر شغلی: سرمایه‌گذار بازار سرمایه' : 'مسیر شغلی: تحلیل‌گر حرفه‌ای بازار',
      description: level === 'beginner'
        ? 'ورود ایمن به بازار سرمایه از بورس و تحلیل تکنیکال شروع می‌شود.'
        : 'با پایه فعلی شما، تابلوخوانی و مدیریت پرتفوی گام بعدی است.',
      clusterLink: '/courses/cluster/capital-market',
      clusterName: 'بازار سرمایه',
      color: '#0284c7',
      careerPaths: ['سرمایه‌گذار', 'تحلیل‌گر تکنیکال', 'معامله‌گر حرفه‌ای'],
      salary: 'متغیر — پتانسیل بالا',
      courses: [
        { slug: 'forex-fundamentals', title: 'آشنایی با بازار سرمایه', icon: BarChart3, color: '#0284c7', level: 'مبانی', duration: '۲ ماه', levelOrder: 0 },
        { slug: 'accounting', title: 'تحلیل بنیادی و صورت‌های مالی', icon: Calculator, color: '#d97706', level: 'تخصصی', duration: '۳ ماه', levelOrder: 1 },
      ],
    };
  }

  if (interest === 'finance') {
    return {
      title: 'مسیر شغلی: معامله‌گر بازارهای مالی',
      description: level === 'beginner'
        ? 'از فارکس شروع کنید و به معامله‌گری الگوریتمی ارتقا دهید.'
        : 'با تجربه شما، اتوماسیون استراتژی‌ها با MQL5 درآمد پایدار ایجاد می‌کند.',
      clusterLink: '/courses/cluster/finance',
      clusterName: 'امور مالی و حسابداری',
      color: '#d97706',
      careerPaths: ['معامله‌گر فارکس', 'معامله‌گر الگوریتمی', 'حسابدار رسمی'],
      salary: 'متغیر — پتانسیل درآمد دلاری',
      courses: [
        { slug: 'forex-fundamentals', title: 'فارکس — مبانی معامله‌گری', icon: BarChart3, color: '#d97706', level: 'مبانی', duration: '۲ ماه', levelOrder: 0 },
        { slug: 'mql5-algorithmic', title: 'MQL5 — معامله‌گری الگوریتمی', icon: TrendingUp, color: '#ea580c', level: 'پیشرفته', duration: '۳-۵ ماه', levelOrder: 1 },
      ],
    };
  }

  if (interest === 'management') {
    if (goal === 'business') {
      return {
        title: 'مسیر شغلی: مشاور و سیستم‌ساز کسب‌وکار',
        description: 'برای رشد کسب‌وکار، مشاوره تخصصی و سیستم‌سازی مسیر اثبات‌شده‌ای است.',
        clusterLink: '/courses/cluster/entrepreneurship-and-business',
        clusterName: 'کارآفرینی و کسب‌وکار',
        color: '#8b5cf6',
        careerPaths: ['مشاور کسب‌وکار', 'سیستم‌ساز فرآیندها', 'مدیر عملیات'],
        salary: '۳۰ تا ۷۰ میلیون تومان',
        courses: [
          { slug: 'business-consulting', title: 'مشاوره کسب‌وکار و سیستم‌سازی', icon: Lightbulb, color: '#8b5cf6', level: 'تخصصی', duration: '۳ ماه', levelOrder: 0 },
          { slug: 'entrepreneurship', title: 'کارآفرینی دیجیتال', icon: Rocket, color: '#06b6d4', level: 'پیشرفته', duration: '۲-۳ ماه', levelOrder: 1 },
        ],
      };
    }
    return {
      title: 'مسیر شغلی: کارشناس مالی و حسابداری',
      description: 'حسابداری مهارتی نقطه ورود مطمئن به بازار کار اداری و مالی است.',
      clusterLink: '/courses/cluster/finance',
      clusterName: 'امور مالی و حسابداری',
      color: '#7c3aed',
      careerPaths: ['حسابدار رسمی', 'کارشناس مالی', 'مدیر مالی'],
      salary: '۲۰ تا ۴۵ میلیون تومان',
      courses: [
        { slug: 'accounting', title: 'حسابداری مهارتی و نرم‌افزار هلو', icon: Calculator, color: '#7c3aed', level: 'مبانی', duration: '۳-۴ ماه', levelOrder: 0 },
        { slug: 'business-consulting', title: 'مشاوره کسب‌وکار', icon: Lightbulb, color: '#8b5cf6', level: 'تخصصی', duration: '۳ ماه', levelOrder: 1 },
      ],
    };
  }

  // creative
  return {
    title: level === 'beginner' ? 'مسیر شغلی: طراح صنعتی' : 'مسیر شغلی: متخصص صنایع خلاق',
    description: level === 'beginner'
      ? 'AutoCAD نقطه ورود حرفه‌ای به صنایع خلاق است.'
      : 'با پایه هنری شما، مدل‌سازی سه‌بعدی و طراحی پیشرفته گام بعدی است.',
    clusterLink: level === 'beginner' ? '/courses/cluster/architecture' : '/courses/cluster/graphic-design',
    clusterName: level === 'beginner' ? 'معماری و نقشه‌کشی' : 'گرافیک و طراحی دیجیتال',
    color: '#e11d48',
    careerPaths: ['نقشه‌کش صنعتی', 'طراح داخلی', 'مدل‌ساز سه‌بعدی'],
    salary: '۱۸ تا ۴۰ میلیون تومان',
    courses: [
      { slug: 'autocad', title: 'AutoCAD — نقشه‌کشی صنعتی', icon: Palette, color: '#e11d48', level: 'مبانی', duration: '۲-۳ ماه', levelOrder: 0 },
      { slug: '3d-modeling', title: 'مدل‌سازی سه‌بعدی', icon: Monitor, color: '#dc2626', level: 'تخصصی', duration: '۳-۴ ماه', levelOrder: 1 },
    ],
  };
}

// ─── Step Labels ─────────────────────────────────────────────────
const stepLabels = ['هدف', 'سطح', 'حوزه', 'زمان‌بندی', 'سبک یادگیری'];

// ─── Step Indicator ──────────────────────────────────────────────
function StepIndicator({ current }: { current: number }) {
  return (
    <div className="flex items-center justify-center gap-1.5 mb-8">
      {stepLabels.map((label, i) => (
        <div key={label} className="flex items-center gap-1.5">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold ${
              i < current
                ? 'bg-teal-500 text-white'
                : i === current
                ? 'bg-teal-500/20 text-teal-400 border border-teal-500/40'
                : 'bg-white/5 text-gray-500 border border-white/10'
            }`}
          >
            {i + 1}
          </div>
          <span className={`text-[10px] hidden sm:inline ${i <= current ? 'text-gray-300' : 'text-gray-600'}`}>
            {label}
          </span>
          {i < stepLabels.length - 1 && (
            <ChevronLeft className={`w-3 h-3 hidden sm:block ${i < current ? 'text-teal-500' : 'text-gray-600'}`} />
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Visual Learning Path Component ───────────────────────────────
function LearningPath({ courses, color }: { courses: RecommendedCourse[]; color: string }) {
  return (
    <div className="my-6">
      <p className="text-xs font-medium text-gray-400 mb-4 flex items-center gap-1.5">
        <GraduationCap className="w-3.5 h-3.5" style={{ color }} />
        مسیر یادگیری پیشنهادی شما:
      </p>
      <div className="relative">
        {/* Vertical line */}
        <div className="absolute right-[15px] top-4 bottom-4 w-0.5" style={{ backgroundColor: color + '30' }} />

        {courses.map((course, i) => {
          const Icon = course.icon;
          const isLast = i === courses.length - 1;
          return (
            <div key={course.slug} className="relative flex items-start gap-4 pb-5">
              {/* Circle on the path */}
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 z-10 border-2"
                style={{ backgroundColor: color + '15', borderColor: color }}
              >
                <Icon className="w-4 h-4" style={{ color }} />
              </div>

              {/* Course info */}
              <Link
                href={`/courses/${course.slug}`}
                className="flex-1 group glass-card-lite rounded-xl p-3.5 hover:border-white/25"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                        style={{ backgroundColor: color + '15', color }}
                      >
                        {course.level}
                      </span>
                      <span className="text-[10px] text-gray-500 flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" />
                        {course.duration}
                      </span>
                    </div>
                    <p className="font-bold text-sm text-white group-hover:text-teal-300">
                      {course.title}
                    </p>
                  </div>
                  {!isLast && (
                    <ArrowLeft className="w-4 h-4 text-gray-500 flex-shrink-0 mt-3" />
                  )}
                </div>
              </Link>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Main Component ──────────────────────────────────────────────
export default function CareerPathQuiz() {
  const [step, setStep] = useState(0); // 0-4 steps, 5=result
  const [answer, setAnswer] = useState<QuizAnswer>({ goal: '', level: '', interest: '', schedule: '', style: '' });
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [leadSubmitted, setLeadSubmitted] = useState(false);
  const [leadData, setLeadData] = useState({ name: '', phone: '' });
  const utm = useUTM();

  const result = step === 5 ? getResult(answer) : null;

  const handleNext = (field: keyof QuizAnswer, value: string) => {
    setAnswer((prev) => ({ ...prev, [field]: value }));
    setStep(step + 1);
  };

  const handleBack = () => setStep(Math.max(0, step - 1));

  const handleRestart = () => {
    setStep(0);
    setAnswer({ goal: '', level: '', interest: '', schedule: '', style: '' });
    setShowLeadForm(false);
    setLeadSubmitted(false);
    setLeadData({ name: '', phone: '' });
  };

  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadData.name.trim() || !/^09[0-9]{9}$/.test(leadData.phone)) return;
    try {
      await fetch('/api/crm/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: leadData.name.trim(),
          phone: leadData.phone,
          source: 'career-quiz',
          metadata: { ...answer, result: result?.title },
          utmSource: utm.utmSource,
          utmMedium: utm.utmMedium,
          utmCampaign: utm.utmCampaign,
        }),
      });
      // Track conversion event
      fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'QUIZ_LEAD_CAPTURE',
          category: 'conversion',
          label: 'career-path-quiz',
          metadata: { result: result?.title, cluster: result?.clusterName },
        }),
      }).catch(() => {});
    } catch {
      // Silently fail for UX
    }
    setLeadSubmitted(true);
  };

  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Dark background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a192f] via-[#0d1f3c] to-[#0a1628]" />
      <div className="absolute inset-0 circuit-grid opacity-[0.06]" />

      <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-8">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-violet-300 bg-violet-500/15 border border-violet-500/20 rounded-full px-4 py-1.5 mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            تست هوشمند مسیر شغلی
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">
            مسیر شغلی مناسب شما چیست؟
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto leading-relaxed">
            با پاسخ به ۵ سوال کوتاه، مسیر یادگیری شخصی‌سازی‌شده خود را پیدا کنید.
          </p>
        </div>

        {/* Step Indicator */}
        <StepIndicator current={step} />

        {/* Quiz Card */}
        <div className="glass-card rounded-2xl p-6 sm:p-8 min-h-[380px] flex flex-col relative overflow-hidden">

          {/* ── Step 0: Goal ── */}
          {step === 0 && (
            <div className="flex-1 flex flex-col relative z-10">
              <h3 className="text-lg font-bold text-white mb-6 text-center">هدف اصلی شما چیست؟</h3>
              <div className="grid sm:grid-cols-2 gap-4 flex-1">
                {goalOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => handleNext('goal', opt.id)}
                    className="flex items-start gap-4 p-5 rounded-xl border border-white/10 hover:border-white/25 bg-white/[0.03] hover:bg-white/[0.08] text-right transition-colors"
                  >
                    <div className="w-11 h-11 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: opt.color + '20' }}>
                      <opt.icon className="w-5 h-5" style={{ color: opt.color }} />
                    </div>
                    <div>
                      <p className="font-bold text-white text-sm mb-1">{opt.label}</p>
                      <p className="text-xs text-gray-400 leading-relaxed">{opt.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ── Step 1: Level ── */}
          {step === 1 && (
            <div className="flex-1 flex flex-col relative z-10">
              <h3 className="text-lg font-bold text-white mb-6 text-center">سطح فعلی مهارت شما چقدر است؟</h3>
              <div className="grid sm:grid-cols-3 gap-4 flex-1">
                {levelOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => handleNext('level', opt.id)}
                    className="flex flex-col items-center gap-3 p-6 rounded-xl border border-white/10 hover:border-white/25 bg-white/[0.03] hover:bg-white/[0.08] text-center transition-colors"
                  >
                    <div className="w-14 h-14 rounded-full flex items-center justify-center" style={{ backgroundColor: opt.color }}>
                      <opt.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="font-bold text-white text-sm mb-1">{opt.label}</p>
                      <p className="text-xs text-gray-400">{opt.description}</p>
                    </div>
                  </button>
                ))}
              </div>
              <button onClick={handleBack} className="flex items-center gap-1 text-sm text-gray-400 hover:text-teal-400 mt-6 self-start transition-colors">
                <ArrowRight className="w-3.5 h-3.5" />
                مرحله قبل
              </button>
            </div>
          )}

          {/* ── Step 2: Interest ── */}
          {step === 2 && (
            <div className="flex-1 flex flex-col relative z-10">
              <h3 className="text-lg font-bold text-white mb-6 text-center">کدام حوزه بیشتر شما را جذب می‌کند؟</h3>
              <div className="grid sm:grid-cols-2 gap-3 flex-1">
                {interestOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => handleNext('interest', opt.id)}
                    className="flex items-start gap-3 p-4 rounded-xl border border-white/10 hover:border-white/25 bg-white/[0.03] hover:bg-white/[0.08] text-right transition-colors"
                  >
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: opt.color + '20' }}>
                      <opt.icon className="w-5 h-5" style={{ color: opt.color }} />
                    </div>
                    <div>
                      <p className="font-bold text-white text-sm mb-0.5">{opt.label}</p>
                      <p className="text-xs text-gray-400 leading-relaxed">{opt.description}</p>
                    </div>
                  </button>
                ))}
              </div>
              <button onClick={handleBack} className="flex items-center gap-1 text-sm text-gray-400 hover:text-teal-400 mt-6 self-start transition-colors">
                <ArrowRight className="w-3.5 h-3.5" />
                مرحله قبل
              </button>
            </div>
          )}

          {/* ── Step 3: Schedule ── */}
          {step === 3 && (
            <div className="flex-1 flex flex-col relative z-10">
              <h3 className="text-lg font-bold text-white mb-6 text-center">چه زمانی برای یادگیری دارید؟</h3>
              <div className="grid sm:grid-cols-2 gap-4 flex-1">
                {scheduleOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => handleNext('schedule', opt.id)}
                    className="flex items-center gap-4 p-5 rounded-xl border border-white/10 hover:border-white/25 bg-white/[0.03] hover:bg-white/[0.08] text-right transition-colors"
                  >
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: opt.color + '20' }}>
                      <opt.icon className="w-5 h-5" style={{ color: opt.color }} />
                    </div>
                    <div>
                      <p className="font-bold text-white text-sm mb-0.5">{opt.label}</p>
                      <p className="text-xs text-gray-400">{opt.description}</p>
                    </div>
                  </button>
                ))}
              </div>
              <button onClick={handleBack} className="flex items-center gap-1 text-sm text-gray-400 hover:text-teal-400 mt-6 self-start transition-colors">
                <ArrowRight className="w-3.5 h-3.5" />
                مرحله قبل
              </button>
            </div>
          )}

          {/* ── Step 4: Learning Style ── */}
          {step === 4 && (
            <div className="flex-1 flex flex-col relative z-10">
              <h3 className="text-lg font-bold text-white mb-6 text-center">ترجیح یادگیری شما چیست؟</h3>
              <div className="grid sm:grid-cols-3 gap-4 flex-1">
                {styleOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => handleNext('style', opt.id)}
                    className="flex flex-col items-center gap-3 p-6 rounded-xl border border-white/10 hover:border-white/25 bg-white/[0.03] hover:bg-white/[0.08] text-center transition-colors"
                  >
                    <div className="w-14 h-14 rounded-full flex items-center justify-center" style={{ backgroundColor: opt.color }}>
                      <opt.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="font-bold text-white text-sm mb-1">{opt.label}</p>
                      <p className="text-xs text-gray-400">{opt.description}</p>
                    </div>
                  </button>
                ))}
              </div>
              <button onClick={handleBack} className="flex items-center gap-1 text-sm text-gray-400 hover:text-teal-400 mt-6 self-start transition-colors">
                <ArrowRight className="w-3.5 h-3.5" />
                مرحله قبل
              </button>
            </div>
          )}

          {/* ── Step 5: Result ── */}
          {step === 5 && result && (
            <div className="flex-1 flex flex-col relative z-10">
              {/* Result Header */}
              <div className="text-center mb-4">
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3" style={{ backgroundColor: result.color + '20' }}>
                  <CheckCircle2 className="w-8 h-8" style={{ color: result.color }} />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{result.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed max-w-md mx-auto">{result.description}</p>
              </div>

              {/* Stats row */}
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div className="glass-card-lite rounded-xl p-3 text-center">
                  <GraduationCap className="w-4 h-4 mx-auto mb-1" style={{ color: result.color }} />
                  <p className="text-[10px] text-gray-400">{result.clusterName}</p>
                </div>
                <div className="glass-card-lite rounded-xl p-3 text-center">
                  <Briefcase className="w-4 h-4 mx-auto mb-1 text-amber-400" />
                  <p className="text-[10px] text-gray-400">{result.careerPaths.length} مسیر شغلی</p>
                </div>
                <div className="glass-card-lite rounded-xl p-3 text-center">
                  <Star className="w-4 h-4 mx-auto mb-1 text-emerald-400" />
                  <p className="text-[10px] text-gray-400">{result.salary}</p>
                </div>
              </div>

              {/* Visual Learning Path */}
              <LearningPath courses={result.courses} color={result.color} />

              {/* Career paths */}
              <div className="glass-card-lite rounded-xl p-4 mb-4">
                <p className="text-xs font-medium text-gray-400 mb-2">مسیرهای شغلی بعد از دوره:</p>
                <div className="flex flex-wrap gap-2">
                  {result.careerPaths.map((path) => (
                    <span
                      key={path}
                      className="text-xs px-2.5 py-1 rounded-full"
                      style={{ backgroundColor: result.color + '15', color: result.color }}
                    >
                      {path}
                    </span>
                  ))}
                </div>
              </div>

              {/* Cluster link */}
              <Link
                href={result.clusterLink}
                className="inline-flex items-center gap-2 text-sm font-medium text-teal-400 hover:text-teal-300 mb-4 transition-colors"
              >
                مشاهده همه دوره‌های {result.clusterName}
                <ArrowLeft className="w-3.5 h-3.5" />
              </Link>

              {/* Lead Capture */}
              {!showLeadForm && !leadSubmitted && (
                <div className="glass-card-lite rounded-xl p-5 text-center border border-white/10">
                  <p className="text-sm font-medium text-white mb-1">می‌خواهید مشاوره رایگان دریافت کنید؟</p>
                  <p className="text-xs text-gray-400 mb-4">شماره تماس خود را بگذارید، مشاوران ما تماس می‌گیرند</p>
                  <button
                    onClick={() => setShowLeadForm(true)}
                    className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-500 text-white px-6 py-2.5 rounded-lg font-medium text-sm transition-all"
                  >
                    <Phone className="w-4 h-4" />
                    دریافت مشاوره رایگان
                  </button>
                </div>
              )}

              {/* Lead Form */}
              {showLeadForm && !leadSubmitted && (
                <form onSubmit={handleLeadSubmit} className="glass-card-lite rounded-xl p-5 border border-white/10">
                  <p className="text-sm font-medium text-white mb-4 text-center">اطلاعات تماس خود را وارد کنید</p>
                  <div className="space-y-3">
                    <div className="relative">
                      <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                      <input
                        type="text"
                        placeholder="نام و نام خانوادگی"
                        value={leadData.name}
                        onChange={(e) => setLeadData((prev) => ({ ...prev, name: e.target.value }))}
                        required
                        className="w-full pr-10 pl-4 py-2.5 rounded-lg bg-white/[0.06] border border-white/10 text-white placeholder:text-gray-500 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500/50"
                        dir="rtl"
                      />
                    </div>
                    <div className="relative">
                      <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                      <input
                        type="tel"
                        placeholder="شماره موبایل (09123456789)"
                        value={leadData.phone}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^0-9]/g, '');
                          if (val.length <= 11) setLeadData((prev) => ({ ...prev, phone: val }));
                        }}
                        required
                        className="w-full pr-10 pl-4 py-2.5 rounded-lg bg-white/[0.06] border border-white/10 text-white placeholder:text-gray-500 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500/50 text-left"
                        dir="ltr"
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-teal-600 hover:bg-teal-500 text-white py-2.5 rounded-lg font-medium text-sm transition-all"
                    >
                      ارسال و دریافت مشاوره
                    </button>
                  </div>
                </form>
              )}

              {/* Lead Submitted */}
              {leadSubmitted && (
                <div className="glass-card-lite rounded-xl p-5 text-center border border-white/10">
                  <CheckCircle2 className="w-8 h-8 text-teal-400 mx-auto mb-2" />
                  <p className="text-sm font-bold text-white mb-1">درخواست مشاوره شما ثبت شد!</p>
                  <p className="text-xs text-gray-400">مشاوران ما در اسرع وقت تماس خواهند گرفت.</p>
                </div>
              )}

              {/* Restart */}
              <button
                onClick={handleRestart}
                className="flex items-center gap-1 text-sm text-gray-400 hover:text-teal-400 mt-4 self-start transition-colors"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                شروع مجدد تست
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
