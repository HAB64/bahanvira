'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  TrendingUp,
  BarChart3,
  LineChart,
  ShieldCheck,
  BookOpen,
  GraduationCap,
  ArrowLeft,
  CheckCircle2,
  ChevronDown,
  MessageCircle,
  Eye,
  Brain,
  FileText,
  Scale,
  Wallet,
  Target,
  Layers,
  Award,
  Landmark,
  ChartNoAxesColumn,
  CandlestickChart,
  PieChart,
  Lock,
  Sparkles,
} from 'lucide-react';
import { siteConfig } from '@/config/site';

/* ───────── Tool Logo Map ───────── */
const toolLogos: Record<string, string> = {
  TSETMC: '/images/logos/tsetmc.webp',
  کدال: '/images/logos/codal.webp',
  ره‌آورد: '/images/logos/rahavard.webp',
  TradingView: '/images/logos/tradingview.webp',
  MetaTrader: '/images/logos/metatrader.webp',
  Excel: '/images/logos/excel.webp',
  سجام: '/images/logos/sejam.webp',
  'بورس تهران': '/images/logos/tse.webp',
  پرتفوی: '/images/logos/portfolio.webp',
  'مدیریت ریسک': '/images/logos/risk-management.webp',
  'تحلیل تکنیکال': '/images/logos/technical-analysis.webp',
  'تحلیل بنیادی': '/images/logos/fundamental-analysis.webp',
  'روانشناسی': '/images/logos/trading-psychology.webp',
  'پرایس اکشن': '/images/logos/price-action.webp',
  گواهینامه: '/images/logos/certificate.webp',
};

/* ───────── Tool Logo Component ───────── */
function ToolLogo({ name, size = 16 }: { name: string; size?: number }) {
  const src = toolLogos[name];
  if (!src) {
    return (
      <span
        className="inline-flex items-center justify-center rounded font-bold text-white flex-shrink-0"
        style={{ width: size, height: size, fontSize: size * 0.55, backgroundColor: '#6B7280' }}
      >
        {name.charAt(0)}
      </span>
    );
  }
  return (
    <Image
      src={src}
      alt={name}
      width={size}
      height={size}
      className="rounded flex-shrink-0 object-contain"
    />
  );
}

/* ───────── 6-Step Learning Path ───────── */
const capitalMarketCourses = [
  {
    icon: Landmark,
    title: 'آشنایی با بازار سرمایه و ورود به بورس',
    subtitle: 'Capital Market Basics',
    description:
      'آشنایی کامل با مفهوم بورس، ساختار بازار سرمایه ایران، نحوه دریافت کد بورسی از سجام، انتخاب کارگزاری و انجام اولین معامله. این دوره نقطه شروع هر سرمایه‌گذار است و مفاهیم پایه‌ای مانند عرضه و تقاضا، شاخص و کارگزار را پوشش می‌دهد.',
    color: '#3B82F6',
    colorLight: '#EFF6FF',
    level: 'مبتدی',
    duration: '۲۰ ساعت',
    tools: ['سجام', 'بورس تهران', 'TSETMC'],
    step: 1,
  },
  {
    icon: BookOpen,
    title: 'اصول بازار سرمایه و ابزارها',
    subtitle: 'Market Principles & Instruments',
    description:
      'ایجاد پایه نظری قوی شامل مفاهیم اقتصاد پایه (تورم، نرخ بهره)، انواع اوراق بهادار (سهام، اوراق بدهی، صندوق‌ها، مشتقات)، نهادهای مالی (سبدگردان، تأمین سرمایه) و مقدمات امور مالی شرکتی و ارزش زمانی پول.',
    color: '#0D9488',
    colorLight: '#F0FDFA',
    level: 'پایه',
    duration: '۳۰ ساعت',
    tools: ['بورس تهران', 'کدال', 'Excel'],
    step: 2,
  },
  {
    icon: CandlestickChart,
    title: 'تحلیل تکنیکال مقدماتی',
    subtitle: 'Technical Analysis Fundamentals',
    description:
      'آموزش انواع نمودارها (خطی، میله‌ای، شمعی)، مفهوم روند، حمایت و مقاومت، الگوهای کلاسیک (مثلث، پرچم، سر و شانه)، اندیکاتورهای پایه (RSI، MACD، میانگین متحرک) و اصول مدیریت ریسک در معاملات تکنیکال.',
    color: '#F59E0B',
    colorLight: '#FFFBEB',
    level: 'متوسط',
    duration: '۴۰ ساعت',
    tools: ['TradingView', 'ره‌آورد', 'تحلیل تکنیکال'],
    step: 3,
  },
  {
    icon: FileText,
    title: 'تحلیل بنیادی و صورت‌های مالی',
    subtitle: 'Fundamental Analysis & Financial Statements',
    description:
      'آشنایی با ترازنامه، صورت سود و زیان و جریان وجوه نقد. نسبت‌های مالی اصلی (حاشیه سود، بازده حقوق صاحبان سهام)، مفهوم ارزش ذاتی، نقش EPS و DPS، و آموزش جستجو و خواندن گزارش‌ها در کدال برای انتخاب سهم.',
    color: '#8B5CF6',
    colorLight: '#F5F3FF',
    level: 'متوسط',
    duration: '۳۵ ساعت',
    tools: ['کدال', 'تحلیل بنیادی', 'Excel'],
    step: 4,
  },
  {
    icon: Eye,
    title: 'تابلوخوانی، روانشناسی و استراتژی',
    subtitle: 'Market Reading, Psychology & Strategy',
    description:
      'تابلوخوانی حرفه‌ای شامل سرانه خرید و فروش، قدرت خریدار و فروشنده، شناوری سهم و صف‌ها. روانشناسی معاملات شامل خطاهای رفتاری، مدیریت احساسات و پایبندی به پلن. ساخت یک پلن معاملاتی ساده با قوانین ورود و خروج مشخص.',
    color: '#EC4899',
    colorLight: '#FDF2F8',
    level: 'پیشرفته',
    duration: '۳۰ ساعت',
    tools: ['TSETMC', 'روانشناسی', 'پرایس اکشن'],
    step: 5,
  },
  {
    icon: PieChart,
    title: 'مدیریت سرمایه، پرتفوی و مسیر حرفه‌ای',
    subtitle: 'Portfolio Management & Professional Path',
    description:
      'اصول مدیریت سرمایه شامل اندازه موقعیت، ریسک به ریوارد و تنوع‌بخشی. مدیریت پرتفوی شامل ترکیب سبد، بازبینی دوره‌ای و استراتژی‌های بلندمدت. معرفی گواهینامه‌های حرفه‌ای بازار سرمایه (اصول، معامله‌گری، مدیریت سبد) و مسیر ادامه تحصیل.',
    color: '#059669',
    colorLight: '#ECFDF5',
    level: 'تخصصی',
    duration: '۴۵ ساعت',
    tools: ['پرتفوی', 'مدیریت ریسک', 'گواهینامه'],
    step: 6,
  },
];

/* ───────── Feature Cards ───────── */
const marketFeatures = [
  {
    icon: Landmark,
    title: 'بازار سرمایه ایران',
    description: 'آموزش ساختار بورس تهران، فرابورس، نهادهای ناظر و ارکان بازار سرمایه بر اساس استانداردهای سازمان بورس',
  },
  {
    icon: TrendingUp,
    title: 'تحلیل حرفه‌ای',
    description: 'از تکنیکال کلاسیک و پرایس اکشن تا بنیادی و صورت‌های مالی — تحلیل کامل برای تصمیم‌گیری آگاهانه',
  },
  {
    icon: ShieldCheck,
    title: 'مدیریت ریسک و سرمایه',
    description: 'تنظیم حد ضرر، اندازه موقعیت، تنوع‌بخشی و استراتژی‌های مدیریت پرتفوی برای حفظ و رشد سرمایه',
  },
  {
    icon: Award,
    title: 'مسیر حرفه‌ای و گواهینامه',
    description: 'آمادگی برای آزمون‌های اصول، معامله‌گری و مدیریت سبد — مسیر شغلی در کارگزاری‌ها و نهادهای مالی',
  },
];

/* ───────── Professional Certifications ───────── */
const certifications = [
  {
    icon: BookOpen,
    title: 'گواهینامه اصول بازار سرمایه',
    subtitle: 'LEVEL 1',
    description: 'آمادگی آزمون اصول شامل اقتصاد، بازارها و نهادهای مالی، صورت‌های مالی و مقررات',
    color: '#3B82F6',
  },
  {
    icon: CandlestickChart,
    title: 'گواهینامه معامله‌گری',
    subtitle: 'LEVEL 2',
    description: 'آمادگی آزمون معامله‌گری شامل تحلیل تکنیکال، بنیادی، ابزارها و استراتژی‌های معاملاتی',
    color: '#F59E0B',
  },
  {
    icon: PieChart,
    title: 'گواهینامه مدیریت سبد',
    subtitle: 'LEVEL 3',
    description: 'آمادگی آزمون مدیریت سبد و ارزشیابی اوراق شامل مدیریت پرتفوی، ریسک و مدل‌های ارزش‌گذاری',
    color: '#059669',
  },
];

/* ───────── FAQ ───────── */
const marketFAQ = [
  {
    q: 'آیا برای ورود به بازار سرمایه نیاز به دانش مالی دارم؟',
    a: 'خیر. دوره اول (آشنایی با بازار سرمایه) دقیقاً برای افراد بدون هیچ پیش‌زمینه‌ای طراحی شده. از صفر شروع می‌کنیم و مفاهیم پایه بورس، نحوه ثبت‌نام در سجام و دریافت کد بورسی را آموزش می‌دهیم. تنها پیش‌نیاز، آشنایی اولیه با کامپیوتر و اینترنت است.',
  },
  {
    q: 'تفاوت دوره تحلیل تکنیکال و بنیادی چیست؟',
    a: 'تحلیل تکنیکال بر مطالعه رفتار قیمت و حجم معاملات روی نمودار تمرکز دارد — مناسب برای تصمیم‌گیری کوتاه‌مدت و میان‌مدت. تحلیل بنیادی بر بررسی صورت‌های مالی، نسبت‌ها و ارزش ذاتی شرکت متمرکز است — مناسب برای سرمایه‌گذاری میان‌مدت و بلندمدت. هر دو روش مکمل هم هستند و در مسیر یادگیری ما هر دو آموزش داده می‌شوند.',
  },
  {
    q: 'تابلوخوانی چیست و چرا مهم است؟',
    a: 'تابلوخوانی هنر خواندن داده‌های زنده تابلوی معاملات است — سرانه خرید و فروش، قدرت خریدار و فروشنده، شناوری سهم و صف‌ها. این مهارت به شما کمک می‌کند رفتار بازیگران بزرگ بازار را بشناسید و تصمیمات بهتری بگیرید. تابلوخوانی یکی از مهم‌ترین مهارت‌های عملی برای معامله‌گران ایرانی است.',
  },
  {
    q: 'آیا بعد از پایان دوره‌ها می‌توانم در آزمون‌های حرفه‌ای شرکت کنم؟',
    a: 'بله. مسیر ۶ دوره‌ای ما طوری طراحی شده که پس از پایان آن، شما آمادگی لازم برای شرکت در آزمون‌های گواهینامه اصول بازار سرمایه و معامله‌گری را خواهید داشت. دوره ششم نیز به‌طور اختصاصی مسیر حرفه‌ای و آمادگی آزمون‌ها را پوشش می‌دهد.',
  },
  {
    q: 'چه ابزارها و نرم‌افزارهایی در دوره‌ها آموزش داده می‌شود؟',
    a: 'در طول مسیر یادگیری با ابزارهای کلیدی بازار سرمایه آشنا می‌شوید: سامانه سجام برای ثبت‌نام، سایت TSETMC برای رصد بازار، سایت کدال برای گزارش‌های مالی، نرم‌افزار ره‌آورد نوین برای تحلیل، پلتفرم TradingView برای نمودار، و Excel برای تحلیل داده‌های مالی. هر ابزار در مرحله مناسب مسیر آموزشی معرفی و تمرین می‌شود.',
  },
  {
    q: 'مدیریت سرمایه چرا مهم‌ترین بخش آموزش است؟',
    a: 'بدون مدیریت سرمایه، حتی بهترین تحلیل‌گر هم ممکن است ضرر کند. مدیریت سرمایه شامل تعیین اندازه موقعیت، تنظیم حد ضرر، تنوع‌بخشی سبد و کنترل ریسک است. مطالعات نشان می‌دهد که موفقیت بلندمدت در بازار سرمایه بیشتر به مدیریت ریسک وابسته است تا دقت تحلیل‌ها. به همین دلیل، مدیریت سرمایه در دوره پنجم و ششم با تاکید ویژه آموزش داده می‌شود.',
  },
];

/* ───────── Ecosystem Pillars ───────── */
const marketPillars = [
  {
    icon: BarChart3,
    title: 'تحلیل و ارزیابی',
    subtitle: 'Technical & Fundamental Analysis',
    description:
      'آموزش جامع تحلیل تکنیکال (کلاسیک، هارمونیک، پرایس اکشن) و تحلیل بنیادی (صورت‌های مالی، نسبت‌ها، ارزش‌گذاری). از الگوهای نموداری تا مدل‌های DDM و DCF — ابزارهای تحلیلی که هر سرمایه‌گذار حرفه‌ای باید بداند.',
    color: '#F59E0B',
    tags: ['تحلیل تکنیکال', 'تحلیل بنیادی', 'کدال', 'TradingView'],
  },
  {
    icon: Brain,
    title: 'مهارت معاملاتی',
    subtitle: 'Trading Skills & Psychology',
    description:
      'تابلوخوانی حرفه‌ای، روانشناسی معاملات، ساخت استراتژی معاملاتی و سیستم‌سازی. یادگیری کنترل احساسات، پایبندی به پلن و ثبت و ارزیابی عملکرد معاملاتی — مهارت‌هایی که مرز بین معامله‌گر سودده و زیان‌ده را مشخص می‌کنند.',
    color: '#EC4899',
    tags: ['تابلوخوانی', 'روانشناسی', 'پرایس اکشن', 'TSETMC'],
  },
  {
    icon: ShieldCheck,
    title: 'مدیریت سرمایه و ریسک',
    subtitle: 'Capital & Risk Management',
    description:
      'تنظیم اندازه موقعیت، تعیین حد ضرر، تنوع‌بخشی سبد، محاسبه ریسک و بازده و نسبت‌های ریسک‌تعدیل‌شده. مدیریت پرتفوی شامل ترکیب دارایی‌ها، پایش عملکرد و بازبالانس سبد. سرمایه‌گذاری بدون مدیریت ریسک، قمار است نه سرمایه‌گذاری.',
    color: '#059669',
    tags: ['پرتفوی', 'مدیریت ریسک', 'Excel', 'ره‌آورد'],
  },
  {
    icon: GraduationCap,
    title: 'مسیر حرفه‌ای',
    subtitle: 'Professional Certification Path',
    description:
      'آمادگی برای گواهینامه‌های حرفه‌ای بازار سرمایه — از اصول بازار سرمایه تا مدیریت سبد و ارزشیابی اوراق. مسیر شغلی در کارگزاری‌ها، شرکت‌های سبدگردان و نهادهای مالی. دوره‌های MBA بازار سرمایه و مسیرهای تخصصی بلندمدت.',
    color: '#3B82F6',
    tags: ['گواهینامه', 'بورس تهران', 'کدال', 'سجام'],
  },
];

export default function CapitalMarketSection() {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [activePillar, setActivePillar] = useState(0);

  // ── FAQ Schema for Google rich snippets ──
  const marketFAQSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: marketFAQ.map((faq) => ({
      '@type': 'Question',
      name: faq.q,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.a,
      },
    })),
  };

  return (
    <section className="relative overflow-hidden">
      {/* FAQ Schema for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(marketFAQSchema) }}
      />
      {/* ── Background — more vibrant animated gradient ── */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a1628] via-[#0d1f3c] to-[#0a1628] animate-gradient-shift-reverse" />

      {/* Decorative grid pattern — increased opacity */}
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(59,130,246,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(59,130,246,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Glow effects — much more visible and animated */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[120px] animate-glow-pulse-intense" />
      <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-amber-500/15 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: '2s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-emerald-600/10 rounded-full blur-[150px] animate-glow-pulse-intense" style={{ animationDelay: '4s' }} />

      {/* Floating particles */}
      <div className="absolute top-20 right-1/4 w-3 h-3 bg-blue-400/40 rounded-full animate-particle-1" />
      <div className="absolute top-40 left-1/3 w-2 h-2 bg-amber-400/35 rounded-full animate-particle-2" />
      <div className="absolute bottom-40 right-1/3 w-4 h-4 bg-emerald-400/25 rounded-full animate-particle-3" />
      <div className="absolute top-1/3 left-16 w-2.5 h-2.5 bg-cyan-400/30 rounded-full animate-particle-2" style={{ animationDelay: '3s' }} />

      {/* Noise texture */}
      <div className="noise-overlay absolute inset-0" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28">
        {/* ── Header ── */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-white/8 backdrop-blur-md border border-blue-500/30 rounded-full px-5 py-2 mb-6">
            <TrendingUp className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-bold text-blue-200">
              اتاق معاملات
            </span>
            <span className="text-xs font-medium text-blue-400/70">
              Trading Room
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-5 leading-tight">
            مسیر حرفه‌ای
            <br />
            <span className="bg-gradient-to-l from-blue-400 via-amber-400 to-emerald-400 bg-clip-text text-transparent">
              بازارهای مالی و سرمایه
            </span>
          </h2>
          <p className="text-lg text-gray-300/80 max-w-3xl mx-auto leading-relaxed">
            از صفر تا گواهینامه حرفه‌ای — مسیر ۶ دوره‌ای جامع که شما را از
            آشنایی با بورس تا مدیریت پرتفوی و کسب گواهینامه‌های شغلی بازار
            سرمایه همراهی می‌کند. در {siteConfig.name.fa}، بازار سرمایه را
            حرفه‌ای یاد می‌گیرید.
          </p>
        </div>

        {/* ── Hero Banner — with animated border ── */}
        <div className="relative mb-20 rounded-2xl overflow-hidden border border-blue-500/30 shadow-2xl shadow-blue-500/15 group">
          <Image
            src="/images/capital-market-hero.png"
            alt="دوره تخصصی بازار سرمایه بهان رایانه"
            width={1344}
            height={768}
            className="w-full h-auto object-cover"
            priority
          />
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a1628] via-[#0a1628]/30 to-transparent" />

          {/* Content overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-10">
            <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
              <div>
                <h3 className="text-2xl sm:text-3xl font-black text-white mb-2">
                  دوره جامع بازار سرمایه
                </h3>
                <p className="text-gray-300/80 max-w-xl text-sm sm:text-base">
                  ۶ دوره از مبتدی تا تخصصی — تحلیل تکنیکال، بنیادی، تابلوخوانی، مدیریت ریسک و گواهینامه حرفه‌ای
                </p>
              </div>
              <div className="flex gap-3">
                <Link
                  href="/courses?cluster=capital-market"
                  className="inline-flex items-center gap-2 bg-gradient-to-l from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold px-6 py-3 rounded-xl transition-colors shadow-lg shadow-blue-600/25 text-sm whitespace-nowrap"
                >
                  <BarChart3 className="w-4 h-4" />
                  دوره‌های بازار سرمایه
                </Link>
                <Link
                  href="/consulting"
                  className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/25 text-white font-medium px-6 py-3 rounded-xl hover:bg-white/20 transition-all text-sm whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4" />
                  مشاوره رایگان
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* ── 6-Step Course Cards ── */}
        <div className="mb-20">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              مسیر یادگیری بازار سرمایه
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              از صفر تا حرفه‌ای — ۶ دوره گام‌به‌گام که هر یک پیش‌نیاز دوره بعدی
              هستند و شما را مستقیماً به بازار می‌برند
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {capitalMarketCourses.map((course) => {
              const Icon = course.icon;
              return (
                <Link
                  key={course.title}
                  href="/courses?cluster=capital-market"
                  className="group relative glass-card rounded-2xl p-5"
                >

                  {/* Step number */}
                  <div className="absolute -top-3 -right-2 w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-amber-500 flex items-center justify-center text-xs font-black text-white shadow-lg">
                    {course.step}
                  </div>

                  {/* Icon */}
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: course.color + '20' }}
                  >
                    <Icon
                      className="w-6 h-6"
                      style={{ color: course.color }}
                    />
                  </div>

                  {/* Level badge */}
                  <span
                    className="inline-flex items-center text-[10px] font-bold px-2.5 py-1 rounded-full mb-3"
                    style={{
                      backgroundColor: course.color + '20',
                      color: course.color,
                    }}
                  >
                    {course.level}
                  </span>

                  {/* Title */}
                  <h4 className="font-bold text-white text-sm mb-1">
                    {course.title}
                  </h4>
                  <p className="text-[11px] text-blue-300/70 font-medium mb-2">
                    {course.subtitle}
                  </p>
                  <p className="text-xs text-gray-400 leading-relaxed mb-4 line-clamp-3">
                    {course.description}
                  </p>

                  {/* Tools with logos */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {course.tools.map((tool) => (
                      <span
                        key={tool}
                        className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded bg-white/5 text-gray-300 border border-white/10"
                      >
                        <ToolLogo name={tool} size={12} />
                        {tool}
                      </span>
                    ))}
                  </div>

                  {/* Duration + Arrow */}
                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="text-[11px] text-gray-500">
                      {course.duration}
                    </span>
                    <ArrowLeft className="w-4 h-4 text-blue-400" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* ── Ecosystem Pillars (Interactive Tabs) ── */}
        <div className="mb-20">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              ستون‌های تخصصی بازار سرمایه
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              چهار حوزه تخصصی که مسیر حرفه‌ای شما در بازار سرمایه را شکل می‌دهند
            </p>
          </div>

          {/* Tab Buttons */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {marketPillars.map((pillar, idx) => {
              const Icon = pillar.icon;
              return (
                <button
                  key={pillar.title}
                  onClick={() => setActivePillar(idx)}
                  className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                    activePillar === idx
                      ? 'bg-blue-600/30 border border-blue-500/50 text-white shadow-lg shadow-blue-500/15 scale-105'
                      : 'bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10 hover:text-white hover:border-white/20'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {pillar.title}
                </button>
              );
            })}
          </div>

          {/* Active Pillar Content */}
          {marketPillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            if (activePillar !== idx) return null;
            return (
              <div
                key={pillar.title}
                className="glass-card rounded-2xl p-6 sm:p-8"
              >
                <div className="flex flex-col lg:flex-row gap-8 items-start">
                  {/* Icon + Text */}
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-5">
                      <div
                        className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: pillar.color + '20' }}
                      >
                        <Icon className="w-7 h-7" style={{ color: pillar.color }} />
                      </div>
                      <div>
                        <h4 className="text-xl sm:text-2xl font-bold text-white">
                          {pillar.title}
                        </h4>
                        <p className="text-sm text-blue-300/70 font-medium">
                          {pillar.subtitle}
                        </p>
                      </div>
                    </div>
                    <p className="text-gray-300/80 leading-relaxed mb-6">
                      {pillar.description}
                    </p>

                    {/* Tags with logos */}
                    <div className="flex flex-wrap gap-2 mb-6">
                      {pillar.tags.map((tag) => (
                        <span
                          key={tag}
                          className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border border-white/15 text-gray-300 hover:border-white/30 transition-colors"
                          style={{ backgroundColor: pillar.color + '10' }}
                        >
                          <ToolLogo name={tag} size={14} />
                          {tag}
                        </span>
                      ))}
                    </div>

                    <Link
                      href="/courses?cluster=capital-market"
                      className="animated-underline inline-flex items-center gap-2 font-medium text-sm transition-all hover:gap-3"
                      style={{ color: pillar.color }}
                    >
                      مشاهده دوره‌ها
                      <ArrowLeft className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* ── Feature Cards — with hover glow ── */}
        <div className="mb-20">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {marketFeatures.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="group relative flex flex-col items-start gap-3 glass-card rounded-xl p-5"
                >
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500/20 to-amber-500/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-blue-300" />
                  </div>
                  <h3 className="font-bold text-white text-sm">
                    {feature.title}
                  </h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── Professional Certifications ── */}
        <div className="mb-20">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              مسیر گواهینامه‌های حرفه‌ای
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              سه سطح گواهینامه رسمی بازار سرمایه که دروس آن‌ها در مسیر ۶
              دوره‌ای ما پوشش داده می‌شود
            </p>
          </div>

          <div className="grid sm:grid-cols-3 gap-5">
            {certifications.map((cert) => {
              const Icon = cert.icon;
              return (
                <div
                  key={cert.title}
                  className="group glass-card rounded-xl p-6 text-center"
                >
                  <div
                    className="w-14 h-14 rounded-full mx-auto mb-4 flex items-center justify-center"
                    style={{ backgroundColor: cert.color + '20' }}
                  >
                    <Icon className="w-7 h-7" style={{ color: cert.color }} />
                  </div>
                  <span
                    className="inline-block text-[10px] font-bold px-3 py-1 rounded-full mb-3"
                    style={{ backgroundColor: cert.color + '15', color: cert.color }}
                  >
                    {cert.subtitle}
                  </span>
                  <h4 className="font-bold text-white text-sm mb-2">
                    {cert.title}
                  </h4>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {cert.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── Learning Path Visualization ── */}
        <div className="mb-20">
          <div className="glass-card rounded-2xl p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-amber-500/20 flex items-center justify-center">
                <Layers className="w-5 h-5 text-blue-300" />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg">
                  نقشه راه بازار سرمایه
                </h3>
                <p className="text-xs text-gray-400">
                  از صفر تا گواهینامه حرفه‌ای — مسیر ۶ مرحله‌ای
                </p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
              {capitalMarketCourses.map((course, idx) => {
                const Icon = course.icon;
                return (
                  <div key={course.step} className="relative">
                    <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-center hover:bg-white/10">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <div
                          className="w-9 h-9 rounded-full flex items-center justify-center"
                          style={{ backgroundColor: course.color + '20' }}
                        >
                          <Icon
                            className="w-4 h-4"
                            style={{ color: course.color }}
                          />
                        </div>
                        {course.tools[0] && (
                          <ToolLogo name={course.tools[0]} size={28} />
                        )}
                      </div>
                      <p className="text-xs font-bold text-white mb-0.5">
                        {course.title.split(' ').slice(0, 3).join(' ')}
                      </p>
                      <p className="text-[10px] text-gray-500">{course.level}</p>
                      {idx === 0 && (
                        <span className="inline-block mt-1.5 text-[9px] font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-full">
                          شروع از اینجا
                        </span>
                      )}
                    </div>
                    {/* Arrow between steps */}
                    {idx < capitalMarketCourses.length - 1 && (
                      <div className="hidden xl:block absolute top-1/2 -right-2 transform -translate-y-1/2 text-blue-500/40 z-10">
                        <ArrowLeft className="w-3 h-3" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ── FAQ ── */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
              سوالات متداول درباره دوره بازار سرمایه
            </h3>
          </div>
          <div className="max-w-3xl mx-auto space-y-3">
            {marketFAQ.map((faq, idx) => (
              <div
                key={idx}
                className="glass-card rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setOpenFAQ(openFAQ === idx ? null : idx)}
                  className="w-full flex items-center justify-between gap-3 p-4 text-right hover:bg-white/5 transition-colors"
                >
                  <span className="font-medium text-white text-sm">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-blue-400 flex-shrink-0 transition-transform duration-300 ${
                      openFAQ === idx ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openFAQ === idx && (
                  <div className="px-4 pb-4 pt-0">
                    <p className="text-xs text-gray-400 leading-relaxed">
                      {faq.a}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── Bottom CTA ── */}
        <div className="text-center">
          <div className="inline-flex flex-col sm:flex-row items-center gap-4 bg-gradient-to-l from-blue-600/10 via-cyan-600/10 to-amber-600/10 border border-blue-500/25 rounded-2xl px-8 py-6">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-blue-400" />
              <div className="text-right">
                <p className="font-bold text-white">همین الان شروع کنید</p>
                <p className="text-xs text-gray-400">
                  از صفر تا گواهینامه حرفه‌ای — مشاوره اولیه رایگان
                </p>
              </div>
            </div>
            <Link
              href="/consulting"
              className="inline-flex items-center gap-2 bg-gradient-to-l from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold px-8 py-3 rounded-xl transition-colors shadow-lg shadow-blue-600/25 text-sm"
            >
              رزرو مشاوره رایگان
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
