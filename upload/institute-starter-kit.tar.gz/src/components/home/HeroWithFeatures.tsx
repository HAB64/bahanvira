import Link from 'next/link';
import { ArrowLeft, Compass, Cpu, TrendingUp, Briefcase, Palette, Shield } from 'lucide-react';
import AnimatedCounter from './AnimatedCounter';
import QuickLeadForm from './QuickLeadForm';
import { siteConfig } from '@/config/site';

const strategicPillars = [
  {
    icon: Cpu,
    title: 'فناوری و هوش مصنوعی',
    description: 'از سواد دیجیتال و ICDL تا ارکستراسیون مدل‌های زبانی محلی و خودکارسازی هوشمند',
    href: '/courses?cluster=tech-ai',
    color: '#0d9488',
  },
  {
    icon: TrendingUp,
    title: 'بازارهای مالی',
    description: 'فارکس، ارزدیجیتال، بورس و معامله‌گری الگوریتمی — مسیر درآمد دلاری مستقل',
    href: '/courses?cluster=financial',
    color: '#d97706',
  },
  {
    icon: Briefcase,
    title: 'توسعه فردی و کسب‌وکار',
    description: 'حسابداری عملی، کارآفرینی دیجیتال، مشاوره سازمانی و سیستم‌سازی فرآیندها',
    href: '/courses?cluster=management',
    color: '#7c3aed',
  },
  {
    icon: Palette,
    title: 'مهندسی و هنر کاربردی',
    description: 'AutoCAD، نقشه‌کشی صنعتی، طراحی گرافیک و مدل‌سازی سه‌بعدی — هنر به صنعت',
    href: '/courses?cluster=creative',
    color: '#e11d48',
  },
] as const;

const stats = [
  { label: 'سال تجربه', value: 27, suffix: '', color: 'text-white' },
  { label: 'فارغ‌التحصیل', value: 5000, suffix: '+', color: 'text-white' },
  { label: 'دپارتمان تخصصی', value: 9, suffix: '', color: 'text-amber-300' },
];

export default function HeroWithFeatures() {
  return (
    <>
      {/* ===== Hero Section — Full-width dark background ===== */}
      <section className="relative bg-[#0a1628] overflow-hidden">
        {/* 
          CSS background-image به جای Next.js Image:
          - صفر JS overhead برای LCP
          - مرورگر مستقیماً دانلود و رندر می‌کند بدون انتظار برای hydration
          - fetchPriority="high" در layout.tsx این تصویر را preload می‌کند
        */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('${siteConfig.assets.heroBg}')`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-l from-[#0a1628]/90 via-[#0a1628]/70 to-[#0a1628]/50" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-12 py-12 sm:py-16 lg:py-20 min-h-[85vh]">

            {/* ===== Left: Text Content — یک پیام واضح ===== */}
            <div className="flex-1 text-center lg:text-right order-2 lg:order-1">
              {/* Headline — یک پیام واضح: مسیر شغلی‌ات پیدا کن */}
              <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-black text-white leading-tight mb-4" style={{ textShadow: '0 2px 15px rgba(0,0,0,0.5)' }}>
                مسیر شغلی‌ات پیدا کن
              </h1>

              {/* Subtitle — متمرکز روی ارزش اصلی */}
              <p className="text-sm sm:text-base text-gray-300 leading-relaxed mb-8 max-w-xl mx-auto lg:mx-0" style={{ textShadow: '0 1px 4px rgba(0,0,0,0.3)' }}>
                {`${siteConfig.name.fullName} با ${siteConfig.experience.yearsFa} سال تجربه، کوییز هوشمند و مشاوره رایگان، مسیر تبدیل شما از مبتدی به متخصص را طراحی می‌کند.`}
              </p>

              {/* فقط ۲ CTA واضح */}
              <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start mb-8">
                <Link
                  href="/consulting#quiz"
                  className="group inline-flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-white font-bold px-8 py-4 rounded-xl transition-colors text-sm shadow-lg shadow-amber-500/30"
                >
                  <Compass className="w-5 h-5" />
                  یافتن مسیر شغلی
                </Link>
                <Link
                  href="/courses"
                  className="group inline-flex items-center justify-center gap-2 bg-[#0d9488] hover:bg-[#0f766e] text-white font-bold px-8 py-4 rounded-xl transition-colors text-sm shadow-lg shadow-[#0d9488]/30"
                >
                  مشاهده دوره‌ها
                  <ArrowLeft className="w-4 h-4" />
                </Link>
              </div>

              {/* Social proof فشرده — فقط ۳ عدد کلیدی + یک بج اعتبار */}
              <div className="flex items-center justify-center lg:justify-start gap-4 text-xs sm:text-sm text-white/70 flex-wrap">
                {stats.map((stat) => (
                  <div key={stat.label} className="flex items-center gap-1">
                    <AnimatedCounter
                      target={stat.value}
                      suffix={stat.suffix}
                      className={`text-base sm:text-lg font-black ${stat.color}`}
                    />
                    <span>{stat.label}</span>
                  </div>
                ))}
                <div className="flex items-center gap-1 text-emerald-300">
                  <Shield className="w-3.5 h-3.5" />
                  <span>فنی و حرفه‌ای</span>
                </div>
              </div>
            </div>

            {/* ===== Right: Quick Lead Form — فقط نام + شماره ===== */}
            <div className="w-full lg:w-[380px] xl:w-[400px] flex-shrink-0 order-1 lg:order-2">
              <QuickLeadForm />
            </div>
          </div>
        </div>
      </section>

      {/* ===== Strategic Pillar Cards — ۴ خوشه اصلی ===== */}
      <section className="relative pt-20 pb-12 z-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#111827] to-[#0a1628]" />
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage:
              'linear-gradient(rgba(13,148,136,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(13,148,136,0.5) 1px, transparent 1px)',
            backgroundSize: '60px 60px',
          }}
        />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
            {strategicPillars.map((pillar) => {
              const Icon = pillar.icon;
              return (
                <Link
                  key={pillar.title}
                  href={pillar.href}
                  className="group relative glass-card rounded-2xl p-5 sm:p-6"
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 mb-4"
                    style={{ backgroundColor: `${pillar.color}15` }}
                  >
                    <Icon
                      className="w-6 h-6"
                      style={{ color: pillar.color }}
                    />
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-white leading-tight mb-2">{pillar.title}</h3>
                  <p className="text-sm text-gray-400 leading-relaxed">{pillar.description}</p>
                  <div className="mt-3 flex items-center gap-1 text-sm font-medium" style={{ color: pillar.color }}>
                    <span>اطلاعات بیشتر</span>
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
}
