'use client';

import { useState } from 'react';
import {
  Layers,
  Users,
  GraduationCap,
  Crm,
  Wallet,
  MonitorSmartphone,
  Presentation,
  BrainCircuit,
  BarChart3,
  Bot,
  Plug,
  ChevronDown,
  ChevronLeft,
  Sparkles,
  CheckCircle2,
  ArrowLeft,
  Shield,
  BookOpen,
  PhoneCall,
  DollarSign,
  UserCog,
  ClipboardList,
  Target,
  TrendingUp,
  Cpu,
  Cog,
  MessageSquare,
  LineChart,
  Globe,
} from 'lucide-react';
import { siteConfig } from '@/config/site';

/* ───────── Layer Data ───────── */
const architectureLayers = [
  {
    id: 'core-erp',
    number: 1,
    title: 'هسته مرکزی',
    subtitle: 'Core ERP',
    icon: Shield,
    color: '#6366f1',
    items: ['مدیریت کاربران', 'نقش‌ها و سطوح دسترسی (RBAC)', 'مدیریت شعب', 'مدیریت اساتید', 'مدیریت کارکنان', 'مدیریت کارآموزان', 'مدیریت مدارک', 'مدیریت فرم‌ها', 'مدیریت فرآیندها (BPM)', 'مرکز اعلان‌ها'],
    description: 'ستون فقرات پلتفرم — مدیریت هویت، دسترسی‌ها و فرآیندهای سازمانی. همه ماژول‌ها از طریق این لایه احراز هویت و مجوز دریافت می‌کنند.',
  },
  {
    id: 'lms',
    number: 2,
    title: 'آموزش',
    subtitle: 'LMS',
    icon: BookOpen,
    color: '#0d9488',
    items: ['تعریف دوره', 'سرفصل‌ها', 'کلاس حضوری / آنلاین', 'محتوای آموزشی', 'تکالیف و پروژه‌ها', 'حضور و غیاب', 'تقویم آموزشی', 'بانک سوالات', 'آزمون آنلاین / عملی / تطبیقی', 'صدور گواهینامه', 'آرشیو سوابق'],
    description: 'موتور آموزش پلتفرم — از طراحی دوره و محتوا تا ارزیابی هوشمند و صدور گواهینامه. پشتیبانی از سه مدل آزمون: استاندارد، عملی و Adaptive.',
  },
  {
    id: 'crm',
    number: 3,
    title: 'CRM آموزشی',
    subtitle: 'Educational CRM',
    icon: PhoneCall,
    color: '#f59e0b',
    items: ['لید (Lead)', 'قیف فروش', 'مشاوره آموزشی', 'پیگیری تماس', 'کمپین تبلیغاتی', 'پیامک / واتساپ / ایمیل', 'باشگاه مشتریان', 'سیستم ارجاع', 'نظرسنجی رضایت'],
    description: 'مزیت رقابتی اصلی — مدیریت هوشمند ارتباط با مشتری از لحظه لید تا تبدیل به فارغ‌التحصیل وفادار. قیف فروش آموزشی و اتوماسیون پیگیری.',
  },
  {
    id: 'finance',
    number: 4,
    title: 'مالی',
    subtitle: 'Finance',
    icon: DollarSign,
    color: '#10b981',
    items: ['ثبت درآمد / هزینه', 'شهریه و اقساط', 'صندوق و بانک', 'فاکتور', 'حقوق و دستمزد', 'گزارش سود و زیان', 'بودجه‌بندی'],
    description: 'مدیریت مالی یکپارچه — از شهریه و اقساط کارآموزان تا حقوق کارکنان و گزارش‌های سود و زیان. اتصال مستقیم به CRM و LMS.',
  },
  {
    id: 'student-portal',
    number: 5,
    title: 'پورتال کارآموز',
    subtitle: 'Student Portal',
    icon: MonitorSmartphone,
    color: '#3b82f6',
    items: ['پروفایل', 'انتخاب دوره', 'پرداخت آنلاین', 'مشاهده کلاس‌ها', 'آزمون‌ها و کارنامه', 'گواهینامه‌ها', 'تیکت پشتیبانی'],
    description: 'دسترسی خودکار کارآموز به همه خدمات — از ثبت‌نام و پرداخت تا شرکت در آزمون و دریافت گواهینامه. رابط کاربری ساده و واکنش‌گرا.',
  },
  {
    id: 'instructor-portal',
    number: 6,
    title: 'پورتال استاد',
    subtitle: 'Instructor Portal',
    icon: UserCog,
    color: '#8b5cf6',
    items: ['مدیریت کلاس', 'ثبت حضور', 'بارگذاری محتوا', 'طراحی آزمون', 'تصحیح آزمون', 'گزارش عملکرد'],
    description: 'پنل اختصاصی اساتید — مدیریت کلاس‌ها، بارگذاری محتوا، طراحی و تصحیح آزمون‌ها و مشاهده گزارش عملکرد کارآموزان.',
  },
  {
    id: 'smart-exam',
    number: 7,
    title: 'آزمون هوشمند',
    subtitle: 'Smart Assessment',
    icon: BrainCircuit,
    color: '#ec4899',
    items: ['تولید سوال با AI', 'تحلیل کیفیت سوال', 'تشخیص تقلب', 'بانک ICDL / Python / Scratch', 'آزمون شبیه‌ساز فنی‌وحرفه‌ای'],
    description: 'آزمون‌ساز هوشمند مبتنی بر AI — تولید خودکار سوال، تحلیل دشواری، تشخیص تقلب و بانک سوالات تخصصی ICDL، پایتون و اسکرچ.',
  },
  {
    id: 'bi',
    number: 8,
    title: 'BI و هوش تجاری',
    subtitle: 'Business Intelligence',
    icon: BarChart3,
    color: '#06b6d4',
    items: ['KPI داشبورد مدیرعامل', 'نرخ تبدیل ثبت‌نام', 'CAC / LTV', 'نرخ ریزش', 'عملکرد اساتید', 'درآمد دوره‌ها', 'پیش‌بینی ثبت‌نام'],
    description: 'هوش تجاری تصمیم‌ساز — داشبورد مدیریتی با KPIهای کلیدی، تحلیل نرخ تبدیل، ارزش طول عمر مشتری و پیش‌بینی هوشمند ثبت‌نام.',
  },
  {
    id: 'ai-agents',
    number: 9,
    title: 'AI Agent Layer',
    subtitle: 'Intelligent Automation',
    icon: Bot,
    color: '#f43f5e',
    items: ['Agent مشاور آموزشی', 'Agent فروش', 'Agent پشتیبانی', 'Agent تولید محتوا', 'Agent آزمون‌ساز', 'Agent تحلیل کسب‌وکار', 'Agent پیش‌بینی درآمد', 'Agent گزارش‌ساز مدیریتی'],
    description: 'لایه هوش مصنوعی — عامل‌های خودکاری که مشاوره می‌دهند، می‌فروشند، پشتیبانی می‌کنند، محتوا تولید می‌کنند و گزارش مدیریتی می‌سازند.',
  },
  {
    id: 'integrations',
    number: 10,
    title: 'اتصال به بیرون',
    subtitle: 'Integrations',
    icon: Plug,
    color: '#78716c',
    items: ['سامانه فنی‌وحرفه‌ای', 'درگاه پرداخت', 'پیامک', 'واتساپ', 'ایمیل', 'Moodle', 'n8n', 'Telegram', 'Google Calendar'],
    description: 'اتصال API-First به اکوسیستم خارجی — از درگاه پرداخت و پیامک تا سامانه فنی‌وحرفه‌ای و Moodle. طراحی Microservices برای مقیاس‌پذیری.',
  },
];

/* ───────── Phase Data ───────── */
const implementationPhases = [
  {
    phase: 1,
    title: 'فاز ۱ — ضروری',
    subtitle: 'MVP + Core Revenue',
    color: '#0d9488',
    bgColor: 'rgba(13,148,136,0.08)',
    borderColor: 'rgba(13,148,136,0.25)',
    status: 'در حال اجرا',
    modules: ['CRM آموزشی', 'LMS', 'مالی', 'آزمون آنلاین'],
    description: 'حداقل محصول پذیرفتنی — CRM برای جذب مشتری، LMS برای ارائه آموزش، مالی برای مدیریت درآمد و آزمون آنلاین برای ارزیابی. این فاز پایه درآمدزایی پلتفرم را فراهم می‌کند.',
  },
  {
    phase: 2,
    title: 'فاز ۲ — تحلیلی',
    subtitle: 'Analytics + Automation',
    color: '#3b82f6',
    bgColor: 'rgba(59,130,246,0.08)',
    borderColor: 'rgba(59,130,246,0.25)',
    status: 'برنامه‌ریزی',
    modules: ['BI و هوش تجاری', 'اتوماسیون فرآیندها', 'پورتال استاد', 'پورتال کارآموز'],
    description: 'هوش تجاری و اتوماسیون — داشبوردهای تحلیلی مدیریتی، پورتال‌های اختصاصی اساتید و کارآموزان و خودکارسازی فرآیندهای تکراری.',
  },
  {
    phase: 3,
    title: 'فاز ۳ — هوشمند',
    subtitle: 'AI + Prediction',
    color: '#8b5cf6',
    bgColor: 'rgba(139,92,246,0.08)',
    borderColor: 'rgba(139,92,246,0.25)',
    status: 'آینده',
    modules: ['AI Agent Layer', 'تحلیل پیش‌بینی', 'اتصال کامل فنی‌وحرفه‌ای', 'آزمون تطبیقی'],
    description: 'لایه هوش مصنوعی و پیش‌بینی — عامل‌های AI برای مشاوره، فروش و پشتیبانی خودکار. پیش‌بینی درآمد و نرخ ثبت‌نام. اتصال کامل به سامانه فنی‌وحرفه‌ای.',
  },
  {
    phase: 4,
    title: 'فاز ۴ — مقیاس',
    subtitle: 'Multi-Tenant + Franchise',
    color: '#f59e0b',
    bgColor: 'rgba(245,158,11,0.08)',
    borderColor: 'rgba(245,158,11,0.25)',
    status: 'آینده',
    modules: ['فرانچایز', 'چندشعبه‌ای (Multi-Tenant)', 'API Marketplace', 'White-Label'],
    description: 'مقیاس‌پذیری ملی — معماری Multi-Tenant برای فرانچایز و چندشعبه‌ای. API Marketplace برای توسعه‌دهندگان و نسخه White-Label برای شرکا.',
  },
];

/* ───────── Strategic Insight ───────── */
const strategicInsights = [
  {
    icon: Target,
    title: 'مزیت رقابتی پایدار',
    description: 'ارزش واقعی در «CRM آموزشی + BI + AI Agent» است، نه صرفاً LMS. بسیاری آموزشگاه‌ها LMS دارند؛ مزیت پایدار از داده، اتوماسیون و هوش مصنوعی ایجاد می‌شود.',
    color: '#0d9488',
  },
  {
    icon: Cog,
    title: 'API-First و Microservices',
    description: 'معماری از ابتدا API-First و مبتنی بر Microservices طراحی شده تا در آینده به یک ERP آموزشی ملی تبدیل گردد. هر لایه مستقل مقیاس‌پذیر است.',
    color: '#6366f1',
  },
  {
    icon: TrendingUp,
    title: 'داده محور',
    description: '۲۷ سال سابقه آموزشگاه بهان رایانه، بزرگترین دارایی داده‌ای است. تحلیل این داده با BI و AI، مزیت رقابتی غیرقابل کپی ایجاد می‌کند.',
    color: '#f59e0b',
  },
];

export default function EnterpriseArchitecture() {
  const [activeLayer, setActiveLayer] = useState<number | null>(null);

  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Dark tech background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a192f] via-[#0d1f3c] to-[#0a1628]" />

      {/* Circuit grid pattern */}
      <div className="absolute inset-0 circuit-grid opacity-[0.06]" />

      {/* Glow effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-indigo-600/15 rounded-full blur-[120px]" />
      <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-teal-600/10 rounded-full blur-[100px]" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* ── Section Header ── */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-indigo-300 bg-indigo-500/15 backdrop-blur-md border border-indigo-500/20 rounded-full px-4 py-1.5 mb-4">
            <Layers className="w-3.5 h-3.5" />
            معماری Enterprise
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white mb-4 leading-tight">
            پلتفرم یکپارچه{' '}
            <span className="bg-gradient-to-l from-indigo-400 via-teal-400 to-amber-400 bg-clip-text text-transparent">
              بهان رایانه
            </span>
          </h2>
          <p className="text-gray-400 max-w-3xl mx-auto leading-relaxed text-sm sm:text-base">
            ۱۰ لایه معماری Enterprise که از هسته ERP تا لایه هوش مصنوعی و اتصال به اکوسیستم خارجی،
            پلتفرم {siteConfig.name.fullName} را به یک ERP آموزشی ملی تبدیل می‌کند. طراحی API-First و Microservices
            برای مقیاس‌پذیری آینده.
          </p>
        </div>

        {/* ── Architecture Layers ── */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
              ۱۰ لایه معماری
            </h3>
            <p className="text-gray-500 text-sm">
              هر لایه را انتخاب کنید تا جزئیات ماژول‌ها را ببینید
            </p>
          </div>

          {/* Layer Selection Buttons */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {architectureLayers.map((layer, idx) => {
              const Icon = layer.icon;
              return (
                <button
                  key={layer.id}
                  onClick={() => setActiveLayer(activeLayer === idx ? null : idx)}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-medium transition-colors duration-200 ${
                    activeLayer === idx
                      ? 'text-white shadow-lg'
                      : 'bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10 hover:text-white hover:border-white/20'
                  }`}
                  style={activeLayer === idx ? {
                    backgroundColor: layer.color + '25',
                    borderColor: layer.color + '50',
                    boxShadow: `0 4px 20px ${layer.color}15`,
                  } : undefined}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{layer.title}</span>
                  <span className="sm:hidden">{layer.number}</span>
                </button>
              );
            })}
          </div>

          {/* Active Layer Detail */}
          {architectureLayers.map((layer, idx) => {
            if (activeLayer !== idx) return null;
            const Icon = layer.icon;
            return (
              <div
                key={layer.id}
                className="glass-card rounded-2xl p-6 sm:p-8 mb-6"
              >
                <div className="flex items-start gap-4 mb-5">
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: layer.color + '20' }}
                  >
                    <Icon className="w-7 h-7" style={{ color: layer.color }} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className="text-[10px] font-black px-2 py-0.5 rounded-full text-white"
                        style={{ backgroundColor: layer.color }}
                      >
                        لایه {layer.number}
                      </span>
                      <span className="text-xs text-gray-500 font-mono">{layer.subtitle}</span>
                    </div>
                    <h4 className="text-lg sm:text-xl font-bold text-white">{layer.title}</h4>
                  </div>
                </div>
                <p className="text-sm text-gray-400 leading-relaxed mb-5">
                  {layer.description}
                </p>
                <div className="grid sm:grid-cols-2 gap-2">
                  {layer.items.map((item) => (
                    <div
                      key={item}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg border border-white/5 bg-white/[0.02]"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" style={{ color: layer.color }} />
                      <span className="text-sm text-gray-300">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Layers Visual Stack — always visible */}
          <div className="space-y-1.5">
            {architectureLayers.map((layer, idx) => {
              const Icon = layer.icon;
              return (
                <button
                  key={layer.id}
                  onClick={() => setActiveLayer(activeLayer === idx ? null : idx)}
                  className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.05] transition-colors duration-200 text-right"
                >
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{ backgroundColor: layer.color + '15' }}
                  >
                    <Icon className="w-4 h-4" style={{ color: layer.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">{layer.title}</span>
                      <span className="text-[10px] text-gray-600 font-mono hidden sm:inline">{layer.subtitle}</span>
                    </div>
                  </div>
                  <span
                    className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white flex-shrink-0"
                    style={{ backgroundColor: layer.color + '40' }}
                  >
                    {layer.items.length} ماژول
                  </span>
                  <ChevronLeft className={`w-4 h-4 text-gray-500 transition-transform duration-200 ${activeLayer === idx ? '-rotate-90' : ''}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* ── Implementation Phases ── */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
              فازبندی اجرا
            </h3>
            <p className="text-gray-500 text-sm">
              پیاده‌سازی تدریجی و اثبات‌شده — از MVP تا مقیاس ملی
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {implementationPhases.map((phase) => {
              const statusColor = phase.status === 'در حال اجرا' ? '#10b981' : phase.status === 'برنامه‌ریزی' ? '#3b82f6' : '#6b7280';
              return (
                <div
                  key={phase.phase}
                  className="glass-card rounded-2xl p-5 relative overflow-hidden"
                >
                  {/* Phase number badge */}
                  <div className="absolute top-3 left-3">
                    <span
                      className="text-3xl font-black"
                      style={{ color: phase.color + '20' }}
                    >
                      {phase.phase}
                    </span>
                  </div>

                  {/* Status badge */}
                  <div className="mb-4">
                    <span
                      className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white"
                      style={{ backgroundColor: statusColor }}
                    >
                      {phase.status}
                    </span>
                  </div>

                  {/* Title */}
                  <h4 className="font-bold text-white text-sm mb-0.5">{phase.title}</h4>
                  <p className="text-[10px] font-mono text-gray-500 mb-3">{phase.subtitle}</p>

                  {/* Description */}
                  <p className="text-xs text-gray-400 leading-relaxed mb-4">
                    {phase.description}
                  </p>

                  {/* Modules */}
                  <div className="space-y-1.5">
                    {phase.modules.map((mod) => (
                      <div
                        key={mod}
                        className="flex items-center gap-1.5 text-xs"
                      >
                        <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: phase.color }} />
                        <span className="text-gray-300">{mod}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── Strategic Insights ── */}
        <div>
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
              چرا این معماری؟
            </h3>
            <p className="text-gray-500 text-sm">
              تحلیل استراتژیک مزیت رقابتی پلتفرم
            </p>
          </div>

          <div className="grid sm:grid-cols-3 gap-5">
            {strategicInsights.map((insight) => {
              const Icon = insight.icon;
              return (
                <div
                  key={insight.title}
                  className="glass-card rounded-2xl p-6"
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: insight.color + '15' }}
                  >
                    <Icon className="w-6 h-6" style={{ color: insight.color }} />
                  </div>
                  <h4 className="font-bold text-white text-sm mb-2">{insight.title}</h4>
                  <p className="text-xs text-gray-400 leading-relaxed">{insight.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
