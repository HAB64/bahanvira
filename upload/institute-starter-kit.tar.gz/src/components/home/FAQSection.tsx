'use client';

import { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle, Sparkles } from 'lucide-react';
import { siteConfig } from '@/config/site';

// ─── فقط ۱۰ FAQ اصلی برای صفحه نخست (سؤالات استاندارد آموزشگاهی) ───
// بقیه سؤالات در صفحه اختصاصی FAQ قابل مشاهده است
const homepageFaqIndices = [
  16, // چرا بهان رایانه را انتخاب کنم؟
  17, // چه دوره‌هایی برگزار می‌شود؟
  2,  // مدارک صادره آیا معتبر هستند؟
  19, // مدرک فنی‌وحرفه‌ای چه مزیتی دارد؟
  18, // شهریه دوره‌ها چقدر است؟
  3,  // آیا امکان قسط‌بندی شهریه وجود دارد؟
  6,  // آیا کلاس آنلاین یا غیرحضوری دارید؟
  4,  // پیش‌نیاز دوره‌ها چیست؟
  20, // پس از دوره می‌توان وارد بازار کار شد؟
  21, // چگونه ثبت‌نام کنم؟
];
const faqs = homepageFaqIndices.map(i => siteConfig.faq[i]).filter(Boolean);

// FAQPage Schema for Google Rich Results
// NOTE: Kept only in SchemaMarkup.tsx to avoid duplicate JSON-LD

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Dark glossy background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#111827] to-[#0a1628]" />

      {/* Glow effects */}
      <div className="absolute top-0 right-1/4 w-80 h-80 bg-teal-600/10 rounded-full blur-[100px] animate-glow-pulse" />
      <div className="absolute bottom-0 left-1/3 w-64 h-64 bg-violet-600/8 rounded-full blur-[80px] animate-glow-pulse" style={{ animationDelay: '4s' }} />

      {/* FAQPage Schema is in SchemaMarkup.tsx */}
      <div className="relative z-10 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-teal-300 bg-teal-500/15 backdrop-blur-md border border-teal-500/20 rounded-full px-4 py-1.5 mb-4 animate-float-slow">
            <Sparkles className="w-3.5 h-3.5" />
            سؤالات متداول
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            پاسخ سؤالات شما
          </h2>
        </div>

        {/* FAQ Accordion — glass cards */}
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="glass-card rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-5 hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <HelpCircle className="w-5 h-5 text-teal-400 flex-shrink-0" />
                  <span className="font-medium text-white text-sm text-right">{faq.question}</span>
                </div>
                {openIndex === i ? (
                  <ChevronUp className="w-4 h-4 text-gray-400 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
                )}
              </button>
              {openIndex === i && (
                <div className="px-5 pb-5 pr-13">
                  <p className="text-sm text-gray-400 leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
