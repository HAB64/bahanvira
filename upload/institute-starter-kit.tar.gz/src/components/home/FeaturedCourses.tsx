import Link from 'next/link';
import { Star, ArrowLeft, Clock, Users, Award, Monitor, Gamepad2, Code2, Brain, BarChart3, Zap, Calculator, Lightbulb, Rocket, Ruler, Box, Scissors, Flame, Timer, Sparkles } from 'lucide-react';
import { courses } from '@/data/courses';
import { siteConfig } from '@/config/site';

const courseIconMap: Record<string, React.ElementType> = {
  Monitor, Gamepad2, Code2, Brain, BarChart3, Zap, Calculator, Lightbulb, Rocket, Ruler, Box, Scissors,
};

// Urgency signals per course
const urgencySignals: Record<string, { type: 'hot' | 'limited' | 'new'; label: string }> = {
  'icdl': { type: 'hot', label: 'پرطرفدار' },
  'python': { type: 'hot', label: 'پرطرفدار' },
  'forex-fundamentals': { type: 'limited', label: 'ظرفیت محدود' },
  'local-ai': { type: 'new', label: 'جدید' },
  'mql5-algorithmic': { type: 'limited', label: 'کوهورت ویژه' },
  'scratch': { type: 'hot', label: 'پرطرفدار' },
  'autocad': { type: 'new', label: 'ثبت‌نام باز' },
  'sewing-pattern': { type: 'new', label: 'جدید' },
  '3d-modeling': { type: 'new', label: 'ثبت‌نام باز' },
};

const urgencyStyles: Record<string, string> = {
  hot: 'bg-red-500/15 text-red-400 border-red-500/20',
  limited: 'bg-amber-500/15 text-amber-400 border-amber-500/20',
  new: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
};

const urgencyIcon: Record<string, React.ElementType> = {
  hot: Flame,
  limited: Timer,
  new: Star,
};

export default function FeaturedCourses() {
  const featured = courses.filter((c) => c.isFeatured);

  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Dark glossy background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#111827] to-[#0a1628] animate-gradient-shift" />

      {/* Decorative grid */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(139,92,246,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(139,92,246,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Glow effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-violet-600/15 rounded-full blur-[120px] animate-glow-pulse-intense" />
      <div className="absolute bottom-0 right-1/3 w-80 h-80 bg-teal-600/10 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: '4s' }} />

      {/* Floating particles */}
      <div className="absolute top-20 left-1/4 w-2.5 h-2.5 bg-violet-400/30 rounded-full animate-particle-1" />
      <div className="absolute bottom-20 right-1/3 w-2 h-2 bg-teal-400/25 rounded-full animate-particle-2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-violet-300 bg-violet-500/15 backdrop-blur-md border border-violet-500/20 rounded-full px-4 py-1.5 mb-4 animate-float-slow">
            <Sparkles className="w-3.5 h-3.5" />
            دوره‌های پرمخاطب
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            پرطرفدارترین دوره‌ها
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto leading-relaxed">
            دوره‌هایی که بیشترین تقاضا را در بازار کار دارند و کارآموزان {siteConfig.name.fa} علاقه‌مند به آن‌ها هستند.
          </p>
        </div>

        {/* Course Cards — dark glass style */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map((course) => {
            const urgency = urgencySignals[course.slug];
            const UrgencyIcon = urgency ? urgencyIcon[urgency.type] : null;
            return (
              <Link
                key={course.slug}
                href={`/courses/${course.slug}`}
                className="group glass-card rounded-2xl overflow-hidden"
              >
                {/* Top Color Bar */}
                <div className="h-2" style={{ backgroundColor: course.color }} />

                {/* Urgency Badge */}
                {urgency && (
                  <div className="absolute top-4 left-4 z-10">
                    <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-1 rounded-full border ${urgencyStyles[urgency.type]} ${
                      urgency.type === 'hot' ? 'animate-pulse' : ''
                    }`}>
                      {UrgencyIcon && <UrgencyIcon className="w-3 h-3" />}
                      {urgency.label}
                    </span>
                  </div>
                )}

                {/* Content */}
                <div className="p-5 relative overflow-hidden">
                  {/* Course Icon */}
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ backgroundColor: course.color + '20' }}>
                    {(() => { const Icon = courseIconMap[course.icon] || Monitor; return <Icon className="w-5 h-5" style={{ color: course.color }} />; })()}
                  </div>
                  {/* Badge */}
                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    <span
                      className="text-xs font-medium px-2.5 py-1 rounded-full border border-white/10"
                      style={{ backgroundColor: course.colorLight + '15', color: course.color }}
                    >
                      {course.clusterLabel}
                    </span>
                    <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-white/5 text-gray-400 border border-white/10">
                      {course.level}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-bold text-white mb-2 line-clamp-2 min-h-[3rem]">
                    {course.title}
                  </h3>

                  {/* Subtitle */}
                  <p className="text-xs text-gray-400 leading-relaxed mb-4 line-clamp-2">
                    {course.subtitle}
                  </p>

                  {/* Meta */}
                  <div className="flex items-center gap-3 text-xs text-gray-500 mb-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{course.duration}</span>
                    </div>
                    {course.sessions > 0 && (
                      <div className="flex items-center gap-1">
                        <Users className="w-3.5 h-3.5" />
                        <span>{course.sessions} جلسه</span>
                      </div>
                    )}
                  </div>

                  {/* Rating */}
                  {course.reviews.length > 0 && (
                    <div className="flex items-center gap-1.5 mb-4">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${
                              i < Math.round(course.reviews.reduce((a, r) => a + r.rating, 0) / course.reviews.length)
                                ? 'text-yellow-400 fill-yellow-400'
                                : 'text-gray-600'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-gray-500">
                        ({course.reviews.length} نظر)
                      </span>
                    </div>
                  )}

                  {/* CTA */}
                  <div className="flex items-center justify-end pt-4 border-t border-white/10">
                    <div
                      className="flex items-center gap-1 text-sm font-medium"
                      style={{ color: course.color }}
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>

        {/* View All */}
        <div className="text-center mt-10">
          <Link
            href="/courses"
            className="inline-flex items-center gap-2 bg-gradient-to-l from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-medium px-8 py-3.5 rounded-xl transition-all shadow-lg shadow-violet-600/20 animate-ripple"
          >
            مشاهده همه دوره‌ها
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
