'use client';

import { useState } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote, ThumbsUp, GraduationCap, Briefcase, Sparkles } from 'lucide-react';
import { courses } from '@/data/courses';
import { siteConfig } from '@/config/site';

// Collect all reviews with their course info
const allReviews = courses.flatMap((course) =>
  course.reviews.map((review) => ({
    ...review,
    courseTitle: course.title,
    courseSlug: course.slug,
    courseColor: course.color,
  }))
);

// Pick top reviews (one per course, prioritizing 5-star)
const featuredReviews = courses
  .filter((c) => c.reviews.length > 0)
  .map((course) => {
    const topReview = course.reviews.find((r) => r.rating === 5) || course.reviews[0];
    return {
      ...topReview,
      courseTitle: course.title,
      courseSlug: course.slug,
      courseColor: course.color,
      clusterLabel: course.clusterLabel,
    };
  })
  .slice(0, 6);

export default function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);
  const visibleCount = 3;

  const next = () => {
    setActiveIndex((prev) =>
      prev + visibleCount >= featuredReviews.length ? 0 : prev + 1
    );
  };

  const prev = () => {
    setActiveIndex((prev) =>
      prev === 0 ? Math.max(featuredReviews.length - visibleCount, 0) : prev - 1
    );
  };

  const visibleReviews = featuredReviews.slice(
    activeIndex,
    activeIndex + visibleCount
  );

  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Dark glossy background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#111827] to-[#0a1628]" />

      {/* Glow effects */}
      <div className="absolute top-0 left-1/4 w-80 h-80 bg-teal-600/10 rounded-full blur-[100px] animate-glow-pulse" />
      <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-amber-600/8 rounded-full blur-[80px] animate-glow-pulse" style={{ animationDelay: '3s' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-teal-300 bg-teal-500/15 backdrop-blur-md border border-teal-500/20 rounded-full px-4 py-1.5 mb-4 animate-float-slow">
            <Sparkles className="w-3.5 h-3.5" />
            نظرات کارآموزان
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            کارآموزان {siteConfig.name.fa} چه می‌گویند؟
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto leading-relaxed">
            بیش از ۵,۰۰۰ کارآموز در {siteConfig.experience.yearsFa} سال فعالیت {siteConfig.name.fullName}، مسیر شغلی خود را با ما ساخته‌اند.
          </p>
        </div>

        {/* Testimonial Cards — glass style */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {visibleReviews.map((review, i) => (
            <div
              key={`${review.name}-${i}`}
              className="glass-card rounded-2xl p-6 relative"
            >
              {/* Quote icon */}
              <div className="absolute top-4 left-4 opacity-10">
                <Quote className="w-10 h-10 text-teal-400" />
              </div>

              {/* Stars */}
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, j) => (
                  <Star
                    key={j}
                    className={`w-4 h-4 ${
                      j < review.rating
                        ? 'text-yellow-400 fill-yellow-400'
                        : 'text-gray-600'
                    }`}
                  />
                ))}
              </div>

              {/* Review Text */}
              <p className="text-sm text-gray-300 leading-relaxed mb-5">
                &laquo;{review.text}&raquo;
              </p>

              {/* Reviewer Info */}
              <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                  style={{ backgroundColor: review.courseColor }}
                >
                  {review.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm text-white">{review.name}</p>
                  <p className="text-xs text-gray-400 truncate">{review.role}</p>
                </div>
                <span
                  className="text-[10px] font-medium px-2 py-1 rounded-full flex-shrink-0 border border-white/10"
                  style={{
                    backgroundColor: review.courseColor + '15',
                    color: review.courseColor,
                  }}
                >
                  {review.clusterLabel}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Navigation */}
        {featuredReviews.length > visibleCount && (
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={prev}
              className="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center hover:bg-white/10 transition-colors"
              aria-label="نظر قبلی"
            >
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </button>
            <div className="flex items-center gap-2">
              {featuredReviews.slice(0, Math.ceil(featuredReviews.length / 1)).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveIndex(Math.min(i, featuredReviews.length - visibleCount))}
                  className={`w-2 h-2 rounded-full transition-all ${
                    i >= activeIndex && i < activeIndex + visibleCount
                      ? 'bg-teal-400 w-6'
                      : 'bg-white/20'
                  }`}
                  aria-label={`نظر ${i + 1}`}
                />
              ))}
            </div>
            <button
              onClick={next}
              className="w-10 h-10 rounded-full border border-white/15 flex items-center justify-center hover:bg-white/10 transition-colors"
              aria-label="نظر بعدی"
            >
              <ChevronLeft className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        )}

        {/* Stats Summary — glass style */}
        <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            { value: '۴.۸', label: 'میانگین امتیاز دوره‌ها', icon: Star },
            { value: '۹۵٪', label: 'رضایت کارآموزان', icon: ThumbsUp },
            { value: '۵,۰۰۰+', label: 'فارغ‌التحصیل', icon: GraduationCap },
            { value: '۹۰٪', label: 'نرخ اشتغال فارغ‌التحصیلان', icon: Briefcase },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div
                key={i}
                className="glass-card rounded-xl p-4 text-center"
              >
                <div className="flex items-center justify-center mb-1">
                  <Icon className="w-5 h-5 text-teal-400" />
                </div>
                <div className="text-xl font-bold text-teal-300">{stat.value}</div>
                <div className="text-xs text-gray-400 mt-1">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
