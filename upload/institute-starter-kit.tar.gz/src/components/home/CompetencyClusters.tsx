import Link from 'next/link';
import { Cpu, TrendingUp, Briefcase, Palette, Brain, ArrowLeft, BookOpen, HardHat, PenTool, Ruler, Scissors, Scale, GraduationCap, CandlestickChart, Calculator, BarChart3, Zap, Lightbulb, Rocket, Code2, Monitor, Gamepad2 } from 'lucide-react';
import { competencyClusters, tvtoClusters } from '@/data/courses';
import { siteConfig } from '@/config/site';

const iconMap: Record<string, React.ElementType> = {
  Cpu, Brain, TrendingUp, Briefcase, Palette, HardHat, PenTool, Ruler, Scissors, Scale, GraduationCap, CandlestickChart, Calculator, BarChart3, Zap, Lightbulb, Rocket, Code2, Monitor, Gamepad2,
};

export default function CompetencyClusters() {
  return (
    <section className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-block text-sm font-medium text-[#0d9488] bg-[#ccfbf1] rounded-full px-4 py-1.5 mb-4">
            معماری شایستگی
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
            ۳ خوشه فنی و حرفه‌ای، ۸ گروه آموزشی
          </h2>
          <p className="text-[#64748b] max-w-2xl mx-auto leading-relaxed">
            تمامی دوره‌های آموزشگاه در ۳ خوشه (خدمات، صنعت، فرهنگ و هنر) و ۸ گروه آموزشی سازمان‌دهی شده‌اند.
          </p>
        </div>

        {/* 3 TVTO Cluster Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {tvtoClusters.map((cluster) => {
            const IconComponent = iconMap[cluster.icon] || Briefcase;
            return (
              <Link
                key={cluster.id}
                href={`/courses?cluster=${cluster.groups[0] || 'all'}`}
                className="group bg-white rounded-2xl border border-gray-100 p-6 hover:shadow-xl transition-shadow duration-200 relative overflow-hidden"
              >
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center mb-5"
                  style={{ backgroundColor: cluster.colorLight }}
                >
                  <IconComponent className="w-7 h-7" style={{ color: cluster.color }} />
                </div>
                <h3 className="font-bold text-[#0f172a] text-lg mb-2">{cluster.title}</h3>
                <p className="text-sm text-[#64748b] leading-relaxed mb-3">{cluster.description}</p>
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {cluster.groups.map((gId: string) => {
                    const g = competencyClusters.find(c => c.id === gId);
                    return g ? (
                      <span key={gId} className="text-[10px] font-medium px-2 py-0.5 rounded-full" style={{ backgroundColor: g.colorLight, color: g.colorDark }}>
                        {g.shortTitle}
                      </span>
                    ) : null;
                  })}
                </div>
                <div className="flex items-center gap-1 text-xs text-[#64748b] mb-5">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>{cluster.stats.courses} دوره</span>
                </div>
                <div
                  className="flex items-center gap-1 text-sm font-medium group-hover:gap-2 transition-colors"
                  style={{ color: cluster.color }}
                >
                  مشاهده دوره‌ها
                  <ArrowLeft className="w-3.5 h-3.5" />
                </div>
                <div
                  className="absolute bottom-0 right-0 left-0 h-1 rounded-b-2xl opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{ backgroundColor: cluster.color }}
                />
              </Link>
            );
          })}
        </div>

        {/* CBT Framework */}
        <div className="bg-white rounded-2xl border border-gray-100 p-8 sm:p-10">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-xl font-bold text-[#0f172a] mb-4">
                آموزش مبتنی بر شایستگی (CBT)
              </h3>
              <p className="text-[#64748b] leading-relaxed mb-4">
                در پلتفرم {siteConfig.name.fa}، ارتقا به ماژول بعدی صرفاً بر اساس تأیید یک مأموریت عملی
                انجام می‌پذیرد، نه صرفاً زمان سپری‌شده برای تماشای ویدیو. هر دوره به واحدهای
                شایستگی مجزا تقسیم می‌شود و کارآموز باید خروجی ملموس هر مرحله را ارائه دهد.
              </p>
              <div className="flex items-center gap-2 text-sm text-[#0d9488] font-medium">
                <span>تسلط، نه تماشا</span>
              </div>
            </div>
            <div className="bg-gray-50 rounded-xl p-6">
              <div className="space-y-4">
                {[
                  { step: 'سطح ۱', title: 'آنبوردینگ شناختی', desc: 'شناخت مکانیک‌ها و مفاهیم پایه' },
                  { step: 'سطح ۲', title: 'کاربرد عملی و پروژه', desc: 'پیاده‌سازی پروژه‌های دنیای واقعی' },
                  { step: 'سطح ۳', title: 'بهینه‌سازی پیشرفته', desc: 'اتوماسیون و مهندسی سیستم‌ها' },
                  { step: 'سطح ۴', title: 'سنتز و خروجی بازار', desc: 'مشاوره تخصصی / سیستم‌های خودکار' },
                ].map((item, index) => (
                  <div key={item.step} className="flex items-center gap-3">
                    <div className="flex flex-col items-center">
                      <div className="w-8 h-8 rounded-full bg-[#0d9488] text-white text-xs font-bold flex items-center justify-center">
                        {index + 1}
                      </div>
                      {index < 3 && <div className="w-0.5 h-4 bg-[#ccfbf1]" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#0f172a]">
                        {item.step}: {item.title}
                      </p>
                      <p className="text-xs text-[#64748b]">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}