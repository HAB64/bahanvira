'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  Brain,
  Cpu,
  Sparkles,
  Bot,
  Code2,
  Database,
  GraduationCap,
  ArrowLeft,
  CheckCircle2,
  Zap,
  TrendingUp,
  Shield,
  ChevronDown,
  MessageCircle,
  Bot as RobotIcon,
  Waypoints,
  Settings,
  BarChart3,
  Globe,
  Lock,
  Wifi,
  Users,
  Target,
  Lightbulb,
  Puzzle,
  Gamepad2,
} from 'lucide-react';
import { siteConfig } from '@/config/site';

/* ───────── Tool Logo Map ───────── */
const toolLogos: Record<string, string> = {
  Scratch: '/images/logos/scratch.webp',
  Python: '/images/logos/python.webp',
  Ollama: '/images/logos/ollama.webp',
  'LM Studio': '/images/logos/lmstudio.webp',
  LlamaCPP: '/images/logos/llamacpp.webp',
  vLLM: '/images/logos/ollama.webp',
  TensorFlow: '/images/logos/tensorflow.webp',
  PyTorch: '/images/logos/pytorch.webp',
  'Scikit-learn': '/images/logos/scikitlearn.webp',
  Pandas: '/images/logos/pandas.webp',
  NumPy: '/images/logos/pandas.webp',
  Matplotlib: '/images/logos/pandas.webp',
  Jupyter: '/images/logos/jupyter.webp',
  'VS Code': '/images/logos/vscode.webp',
  Streamlit: '/images/logos/streamlit.webp',
  n8n: '/images/logos/n8n.webp',
  MCP: '/images/logos/mcp.webp',
  'AI Agents': '/images/logos/ollama.webp',
  'Claude Code': '/images/logos/claude.webp',
  'GitHub Copilot': '/images/logos/copilot.webp',
  Cursor: '/images/logos/cursor.webp',
  MVP: '/images/logos/claude.webp',
  Workflows: '/images/logos/n8n.webp',
  'Data Science': '/images/logos/pandas.webp',
  KPI: '/images/logos/streamlit.webp',
};

/* ───────── Tool Logo Component ───────── */
function ToolLogo({ name, size = 16 }: { name: string; size?: number }) {
  const src = toolLogos[name];
  if (!src) {
    return (
      <span
        className="inline-flex items-center justify-center rounded font-bold text-white flex-shrink-0"
        style={{ width: size, height: size, fontSize: size * 0.55, backgroundColor: '#6B7280' }}
      >
        {name.charAt(0)}
      </span>
    );
  }
  return (
    <Image
      src={src}
      alt={name}
      width={size}
      height={size}
      className="rounded flex-shrink-0 object-contain"
    />
  );
}

/* ───────── Ecosystem Pillars ───────── */
const ecosystemPillars = [
  {
    icon: Bot,
    title: 'هوش مصنوعی محلی',
    subtitle: 'Local AI — Ollama & LM Studio',
    description:
      'اجرای مدل‌های زبانی بزرگ روی سرور یا سیستم شخصی شما. بدون وابستگی به اینترنت، با حفظ کامل حریم خصوصی. از LLaMA و Mistral تا Gemma و Qwen — مدل‌ها روی سخت‌افزار خودتان اجرا می‌شوند و داده‌های حساس سازمانتان هرگز مرزهای داخلی را ترک نمی‌کنند.',
    color: '#8B5CF6',
    colorLight: '#F3F0FF',
    image: '/images/ai-local-server.png',
    tags: ['Ollama', 'LM Studio', 'LlamaCPP', 'vLLM'],
  },
  {
    icon: Waypoints,
    title: 'اتوماسیون هوشمند',
    subtitle: 'AI Agents & n8n Workflow',
    description:
      'ساخت عامل‌های هوشمند (AI Agents) و فرآیندهای خودکار با n8n. از پاسخ‌گویی خودکار مشتریان تا تحلیل فروش و تولید محتوا — همه چیز بدون دخالت انسان انجام می‌شود. با اتصال MCP، عامل‌های شما می‌توانند با هر سرویسی ارتباط برقرار کنند.',
    color: '#0D9488',
    colorLight: '#CCFBF1',
    image: '/images/ai-workflow-automation.png',
    tags: ['n8n', 'AI Agents', 'MCP', 'Workflows'],
  },
  {
    icon: Code2,
    title: 'توسعه با هوش مصنوعی',
    subtitle: 'Claude Code & AI-Assisted Dev',
    description:
      'توسعه سریع‌تر نرم‌افزار با کمک Claude Code و ابزارهای AI. نوشتن کد، تست، دیباگ و بهینه‌سازی با کمک هوش مصنوعی — از ایده تا محصول نهایی در زمان کوتاه‌تر. با Cursor و GitHub Copilot، بهره‌وری تیم توسعه چند برابر می‌شود.',
    color: '#2563EB',
    colorLight: '#EFF6FF',
    image: '/images/ai-ecosystem-hero.png',
    tags: ['Claude Code', 'GitHub Copilot', 'Cursor', 'MVP'],
  },
  {
    icon: BarChart3,
    title: 'هوش تجاری و تحلیل',
    subtitle: 'Business AI & Analytics',
    description:
      'تحلیل داده‌های کسب‌وکار، پیش‌بینی روند بازار و بهینه‌سازی فرآیندها با ابزارهای هوشمند. از داشبوردهای KPI تا عامل‌های تحلیل فروش — تصمیم‌گیری بر اساس داده و تبدیل اطلاعات خام به بینش عملیاتی.',
    color: '#EC4899',
    colorLight: '#FDF2F8',
    image: '/images/ai-ecosystem-hero.png',
    tags: ['Data Science', 'KPI', 'Pandas', 'Streamlit'],
  },
];

/* ───────── AI Courses (Scratch FIRST) ───────── */
const aiCourses = [
  {
    icon: Puzzle,
    title: 'برنامه‌نویسی اسکرچ',
    subtitle: 'Scratch Programming',
    description:
      'اولین قدم ورود به دنیای برنامه‌نویسی و هوش مصنوعی. با بلوک‌های بصری اسکرچ، منطق برنامه‌نویسی را بدون نوشتن کد یاد بگیرید. مناسب کودکان و نوجوانان و هر کسی که می‌خواهد مفاهیم پایه الگوریتم و حل مسئله را به‌صورت تعاملی و جذاب بیاموزد.',
    color: '#F97316',
    colorLight: '#FFF7ED',
    level: 'مبتدی',
    duration: '۲۰ ساعت',
    tools: ['Scratch'],
    isStarter: true,
  },
  {
    icon: Code2,
    title: 'برنامه‌نویسی پایتون',
    subtitle: 'Python for AI',
    description:
      'از صفر تا نوشتن اسکریپت‌های هوشمند. پایه اصلی ورود به دنیای هوش مصنوعی و علوم داده. بدون پیش‌نیاز برنامه‌نویسی. پایتون زبان شماره یک هوش مصنوعی در جهان است.',
    color: '#0EA5E9',
    colorLight: '#F0F9FF',
    level: 'پایه',
    duration: '۳۰ ساعت',
    tools: ['Python', 'Jupyter', 'VS Code'],
  },
  {
    icon: Database,
    title: 'علوم داده و تحلیل',
    subtitle: 'Data Science & Analytics',
    description:
      'تحلیل داده، مصورسازی و مدل‌سازی پیش‌بینی. از Pandas و NumPy تا داشبورد تعاملی با Streamlit. تصمیم‌گیری مبتنی بر داده.',
    color: '#2563EB',
    colorLight: '#EFF6FF',
    level: 'متوسط',
    duration: '۵۰ ساعت',
    tools: ['Python', 'Pandas', 'Streamlit'],
  },
  {
    icon: Waypoints,
    title: 'اتوماسیون و عامل‌های AI',
    subtitle: 'AI Agents & Automation',
    description:
      'ساخت عامل‌های هوشمند با n8n و ابزارهای MCP. خودکارسازی فرآیندهای کسب‌وکار از پشتیبانی مشتری تا تولید محتوا و تحلیل فروش.',
    color: '#F59E0B',
    colorLight: '#FFFBEB',
    level: 'متوسط',
    duration: '۳۵ ساعت',
    tools: ['n8n', 'MCP', 'AI Agents'],
  },
  {
    icon: Brain,
    title: 'یادگیری ماشین و عمیق',
    subtitle: 'ML / Deep Learning',
    description:
      'از رگرسیون و تصمیم‌درخت تا شبکه‌های عصبی CNN و Transformer. پروژه‌محور با دیتاست‌های واقعی ایران و پیاده‌سازی عملی هر مفهوم.',
    color: '#0D9488',
    colorLight: '#CCFBF1',
    level: 'پیشرفته',
    duration: '۶۰ ساعت',
    tools: ['TensorFlow', 'PyTorch', 'Scikit-learn'],
  },
  {
    icon: Bot,
    title: 'هوش مصنوعی محلی',
    subtitle: 'Local LLM Deployment',
    description:
      'نصب و پیکربندی Ollama، اجرای مدل‌های زبانی روی سرور شخصی، Fine-tuning و Deploy. حریم خصوصی کامل بدون نیاز به اینترنت.',
    color: '#8B5CF6',
    colorLight: '#F3F0FF',
    level: 'پیشرفته',
    duration: '۴۰ ساعت',
    tools: ['Ollama', 'LM Studio', 'LlamaCPP'],
  },
];

/* ───────── Key Features ───────── */
const aiFeatures = [
  {
    icon: Lock,
    title: 'حریم خصوصی کامل',
    description: 'مدل‌های AI روی سرور خودتان اجرا می‌شود — داده‌ها هرگز اینترنت را ترک نمی‌کنند. امنیت و کنترل کامل',
  },
  {
    icon: Wifi,
    title: 'بدون نیاز به اینترنت',
    description: 'بعد از دانلود مدل، بدون اتصال به اینترنت کار می‌کند. مناسب مناطق با اینترنت ضعیف یا محدود',
  },
  {
    icon: Settings,
    title: 'عامل‌های هوشمند خودکار',
    description: 'AI Agents وظایف تکراری را خودکار می‌کنند — از پشتیبانی مشتری تا تحلیل فروش و تولید محتوا',
  },
  {
    icon: TrendingUp,
    title: 'بازار کار پررونق',
    description: 'تقاضای ۳۰۰٪ رشد برای متخصصان AI در ایران — بالاترین میانگین حقوق در بخش فناوری',
  },
];

/* ───────── AI Agent Demos ───────── */
const aiAgents = [
  {
    icon: BarChart3,
    title: 'عامل تحلیل فروش',
    subtitle: 'Sales Analyst Agent',
    description: 'تحلیل داده‌های فروش و ارائه گزارش‌های پیشرفته و قابل‌فهم در قالب JSON',
    output: 'JSON',
    color: '#8B5CF6',
  },
  {
    icon: MessageCircle,
    title: 'عامل پشتیبانی',
    subtitle: 'Support Agent',
    description: 'تبدیل پیام‌های مشتری به سوالات متداول و پاسخ‌های استاندارد در قالب Markdown',
    output: 'Markdown',
    color: '#0D9488',
  },
  {
    icon: Lightbulb,
    title: 'عامل تولید محتوا',
    subtitle: 'Content Agent',
    description: 'تولید محتوای خلاقانه و متن‌های بازاریابی جذاب برای شبکه‌های اجتماعی',
    output: 'Creative Text',
    color: '#2563EB',
  },
  {
    icon: Target,
    title: 'عامل جذب مشتری',
    subtitle: 'Lead Generation Agent',
    description: 'جمع‌آوری اطلاعات مشتری و تحلیل داده‌های بازار برای استراتژی‌های فروش هوشمند',
    output: 'JSON',
    color: '#EC4899',
  },
];

/* ───────── FAQ ───────── */
const aiFAQ = [
  {
    q: 'اکوسیستم هوش مصنوعی محلی چیست؟',
    a: 'اکوسیستم هوش مصنوعی محلی مجموعه‌ای یکپارچه از ابزارها و فناوری‌هاست که به شما اجازه می‌دهد مدل‌های زبانی (LLM) را روی سرور یا سیستم شخصی خود اجرا کنید، عامل‌های هوشمند (AI Agents) بسازید و فرآیندهای کسب‌وکارتان را خودکار کنید — همه بدون وابستگی به اینترنت و با حفظ کامل حریم خصوصی. ابزارهایی مثل Ollama، n8n و Claude Code ستون‌های اصلی این اکوسیستم هستند.',
  },
  {
    q: 'اسکرچ چیست و چرا اولین قدم یادگیری هوش مصنوعی است؟',
    a: 'اسکرچ (Scratch) یک زبان برنامه‌نویسی بصری است که توسط MIT توسعه داده شده. با بلوک‌های رنگی و کشیدن و رها کردن (Drag & Drop)، مفاهیم پایه الگوریتم، حلقه، شرط و متغیر را بدون نوشتن کد یاد می‌گیرید. این بهترین نقطه شروع برای کودکان، نوجوانان و حتی بزرگسالانی است که هیچ تجربه‌ای در برنامه‌نویسی ندارند. بعد از اسکرچ، یادگیری پایتون بسیار آسان‌تر می‌شود.',
  },
  {
    q: 'آیا برای یادگیری هوش مصنوعی نیاز به سیستم قوی دارم؟',
    a: 'برای شروع نه. با Google Colab و سرویس‌های ابری رایگان می‌توانید تمرین کنید. برای اجرای محلی مدل‌ها، یک سیستم با حداقل ۸ گیگ رم و کارت گرافیک ۶ گیگ کافی است. ما نحوه بهینه‌سازی برای سخت‌افزارهای مختلف را هم آموزش می‌دهیم. حتی با سیستم‌های متوسط هم می‌توانید مدل‌های سبک‌تر را اجرا کنید.',
  },
  {
    q: 'هوش مصنوعی محلی چه مزیت‌هایی نسبت به سرویس‌های ابری دارد؟',
    a: 'سه مزیت بزرگ: ۱) حریم خصوصی — داده‌های شما هرگز سرور شخص دیگری را نمی‌بیند؛ ۲) عدم وابستگی — بدون فیلترشکن و قطعی اینترنت کار می‌کند؛ ۳) سفارشی‌سازی — مدل را می‌توانید برای نیازهای خاص خود Fine-tune کنید. ضمناً هزینه‌های بلندمدت اجرای محلی بسیار کمتر از اشتراک سرویس‌های ابری است.',
  },
  {
    q: 'n8n و AI Agents چه کمکی به کسب‌وکار من می‌کنند؟',
    a: 'n8n پلتفرم اتوماسیون فرآیندهاست که با اتصال به AI Agents، وظایف تکراری را خودکار می‌کند. مثلاً: پاسخ‌گویی خودکار به مشتریان، تحلیل فروش روزانه، تولید محتوای شبکه‌های اجتماعی و جذب سرنخ‌های فروش. نتیجه: صرفه‌جویی قابل‌توجه در زمان و هزینه با دقت بالاتر از کار انسانی.',
  },
  {
    q: 'آیا بدون دانش برنامه‌نویسی می‌توانم شرکت کنم؟',
    a: 'بله. دوره «برنامه‌نویسی اسکرچ» دقیقاً برای افراد بدون پیش‌زمینه طراحی شده. با بلوک‌های بصری کار می‌کنید و نیازی به تایپ کد ندارید. دوره «برنامه‌نویسی پایتون برای AI» هم از صفر شروع می‌شود. پیش‌نیاز خاصی جز آشنایی اولیه با کامپیوتر ندارید.',
  },
];

/* ───────── Learning Path Steps (Scratch FIRST) ───────── */
const learningPathSteps = [
  {
    step: '۱',
    title: 'اسکرچ',
    desc: 'مفاهیم پایه برنامه‌نویسی',
    icon: Puzzle,
    color: '#F97316',
    logo: 'Scratch',
  },
  {
    step: '۲',
    title: 'پایتون پایه',
    desc: 'ساختار داده، حلقه، تابع',
    icon: Code2,
    color: '#0EA5E9',
    logo: 'Python',
  },
  {
    step: '۳',
    title: 'تحلیل داده',
    desc: 'Pandas, NumPy, Matplotlib',
    icon: Database,
    color: '#2563EB',
    logo: 'Pandas',
  },
  {
    step: '۴',
    title: 'یادگیری ماشین',
    desc: 'رگرسیون، طبقه‌بندی، NLP',
    icon: Brain,
    color: '#0D9488',
    logo: 'TensorFlow',
  },
  {
    step: '۵',
    title: 'یادگیری عمیق',
    desc: 'CNN, Transformer, LLM',
    icon: Cpu,
    color: '#8B5CF6',
    logo: 'PyTorch',
  },
  {
    step: '۶',
    title: 'AI محلی',
    desc: 'Ollama, Agents, Deploy',
    icon: Bot,
    color: '#EC4899',
    logo: 'Ollama',
  },
];

export default function AISection() {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [activePillar, setActivePillar] = useState(0);

  // ── FAQ Schema for Google rich snippets ──
  const aiFAQSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: aiFAQ.map((faq) => ({
      '@type': 'Question',
      name: faq.q,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.a,
      },
    })),
  };

  return (
    <section className="relative overflow-hidden">
      {/* FAQ Schema for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(aiFAQSchema) }}
      />
      {/* ── Background — more vibrant animated gradient ── */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0c0a1a] via-[#110e24] to-[#0a1628] animate-gradient-shift" />

      {/* Decorative grid pattern — increased opacity */}
      <div
        className="absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(139,92,246,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(139,92,246,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Glow effects — much more visible and animated */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-purple-600/20 rounded-full blur-[120px] animate-glow-pulse-intense" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/15 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: '2s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-violet-600/10 rounded-full blur-[150px] animate-glow-pulse-intense" style={{ animationDelay: '4s' }} />

      {/* Floating particles */}
      <div className="absolute top-20 right-1/4 w-3 h-3 bg-purple-400/40 rounded-full animate-particle-1" />
      <div className="absolute top-40 left-1/3 w-2 h-2 bg-cyan-400/35 rounded-full animate-particle-2" />
      <div className="absolute bottom-40 right-1/3 w-4 h-4 bg-emerald-400/25 rounded-full animate-particle-3" />
      <div className="absolute top-1/3 right-16 w-2.5 h-2.5 bg-amber-400/30 rounded-full animate-particle-2" style={{ animationDelay: '3s' }} />

      {/* Noise texture for depth */}
      <div className="noise-overlay absolute inset-0" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28">
        {/* ── Header ── */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-white/8 backdrop-blur-md border border-purple-500/30 rounded-full px-5 py-2 mb-6">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-medium text-purple-200">
              اکوسیستم هوش مصنوعی محلی
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white mb-5 leading-tight">
            از یادگیری هوش مصنوعی تا خلق فرصت‌های ثروت‌ساز
          </h2>
          <p className="text-lg text-gray-300/80 max-w-3xl mx-auto leading-relaxed">
            از برنامه‌نویسی اسکرچ تا اجرای مدل‌های زبانی روی سرور شخصی و خودکارسازی
            فرآیندهای کسب‌وکار با عامل‌های هوشمند — اکوسیستم یکپارچه AI در {siteConfig.name.fa}{' '}
            با رویکرد محلی، امن و عملی طراحی شده تا شما را مستقیماً به نتیجه
            برساند.
          </p>
        </div>

        {/* ── Ecosystem Hero — with animated border ── */}
        <div className="relative mb-20 rounded-2xl overflow-hidden border border-purple-500/30 shadow-2xl shadow-purple-500/15 group">
          <Image
            src="/images/ai-ecosystem-hero.png"
            alt="اکوسیستم هوش مصنوعی محلی بهان رایانه"
            width={1344}
            height={768}
            className="w-full h-auto object-cover"
            priority
          />
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0c0a1a] via-[#0c0a1a]/30 to-transparent" />

          {/* Content overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-10">
            <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4">
              <div>
                <h3 className="text-2xl sm:text-3xl font-black text-white mb-2">
                  اکوسیستم هوش مصنوعی محلی
                </h3>
                <p className="text-gray-300/80 max-w-xl text-sm sm:text-base">
                  Scratch + Ollama + n8n + Claude Code + AI Agents — مسیر کامل از مبتدی تا متخصص
                </p>
              </div>
              <div className="flex gap-3">
                <Link
                  href="/courses?cluster=ai"
                  className="inline-flex items-center gap-2 bg-gradient-to-l from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-bold px-6 py-3 rounded-xl transition-colors shadow-lg shadow-purple-600/25 text-sm whitespace-nowrap"
                >
                  <Brain className="w-4 h-4" />
                  دوره‌های AI
                </Link>
                <Link
                  href="/consulting"
                  className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/25 text-white font-medium px-6 py-3 rounded-xl hover:bg-white/20 transition-all text-sm whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4" />
                  مشاوره رایگان
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* ── Ecosystem Pillars (Interactive Tabs) ── */}
        <div className="mb-20">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              ستون‌های اکوسیستم AI
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              چهار ستون اصلی که اکوسیستم هوش مصنوعی محلی را شکل می‌دهند
            </p>
          </div>

          {/* Tab Buttons — with animated active state */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {ecosystemPillars.map((pillar, idx) => {
              const Icon = pillar.icon;
              return (
                <button
                  key={pillar.title}
                  onClick={() => setActivePillar(idx)}
                  className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                    activePillar === idx
                      ? 'bg-purple-600/30 border border-purple-500/50 text-white shadow-lg shadow-purple-500/15 scale-105'
                      : 'bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10 hover:text-white hover:border-white/20'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {pillar.title}
                </button>
              );
            })}
          </div>

          {/* Active Pillar Content — with glass morphism */}
          {ecosystemPillars.map((pillar, idx) => {
            const Icon = pillar.icon;
            if (activePillar !== idx) return null;
            return (
              <div
                key={pillar.title}
                className="grid lg:grid-cols-2 gap-8 items-center glass-card rounded-2xl p-6 sm:p-8"
              >
                {/* Image */}
                <div className="relative rounded-xl overflow-hidden border border-purple-500/20">
                  <Image
                    src={pillar.image}
                    alt={pillar.title}
                    width={700}
                    height={500}
                    className="w-full h-auto object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0c0a1a]/50 to-transparent" />
                </div>

                {/* Text */}
                <div>
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center mb-5"
                    style={{ backgroundColor: pillar.color + '20' }}
                  >
                    <Icon className="w-7 h-7" style={{ color: pillar.color }} />
                  </div>
                  <h4 className="text-xl sm:text-2xl font-bold text-white mb-2">
                    {pillar.title}
                  </h4>
                  <p className="text-sm text-purple-300/70 font-medium mb-4">
                    {pillar.subtitle}
                  </p>
                  <p className="text-gray-300/80 leading-relaxed mb-6">
                    {pillar.description}
                  </p>

                  {/* Tags with logos */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {pillar.tags.map((tag) => (
                      <span
                        key={tag}
                        className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border border-white/15 text-gray-300 hover:border-white/30 transition-colors"
                        style={{ backgroundColor: pillar.color + '10' }}
                      >
                        <ToolLogo name={tag} size={14} />
                        {tag}
                      </span>
                    ))}
                  </div>

                  <Link
                    href="/courses?cluster=ai"
                    className="animated-underline inline-flex items-center gap-2 font-medium text-sm transition-all hover:gap-3"
                    style={{ color: pillar.color }}
                  >
                    مشاهده دوره‌ها
                    <ArrowLeft className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>

        {/* ── Feature Cards — with hover glow effects ── */}
        <div className="mb-20">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {aiFeatures.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="group relative flex flex-col items-start gap-3 glass-card rounded-xl p-5"
                >
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-purple-500/20 to-cyan-500/20 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-purple-300" />
                  </div>
                  <h3 className="font-bold text-white text-sm">
                    {feature.title}
                  </h3>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── AI Course Cards (Scratch First) ── */}
        <div className="mb-20">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              مسیر یادگیری هوش مصنوعی
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              از اسکرچ تا متخصص — دوره‌ها به ترتیب سطح چیده شده‌اند تا
              گام‌به‌گام پیش بروید
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4">
            {aiCourses.map((course, idx) => {
              const Icon = course.icon;
              return (
                <Link
                  key={course.title}
                  href="/courses?cluster=ai"
                  className="group relative glass-card rounded-2xl p-5"
                >

                  {/* Step number */}
                  <div className={`absolute -top-3 -right-2 w-7 h-7 rounded-full flex items-center justify-center text-xs font-black text-white shadow-lg ${
                    course.isStarter
                      ? 'bg-gradient-to-br from-orange-500 to-amber-500'
                      : 'bg-gradient-to-br from-purple-500 to-cyan-500'
                  }`}>
                    {idx + 1}
                  </div>

                  {/* Starter badge */}
                  {course.isStarter && (
                    <div className="absolute -top-3 -left-2 bg-gradient-to-l from-orange-500 to-amber-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow-lg">
                      اولین قدم
                    </div>
                  )}

                  {/* Icon */}
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ backgroundColor: course.colorLight + '1A' }}
                  >
                    <Icon
                      className="w-6 h-6"
                      style={{ color: course.color }}
                    />
                  </div>

                  {/* Level badge */}
                  <span
                    className="inline-flex items-center text-[10px] font-bold px-2.5 py-1 rounded-full mb-3"
                    style={{
                      backgroundColor: course.colorLight + '20',
                      color: course.color,
                    }}
                  >
                    {course.level}
                  </span>

                  {/* Title */}
                  <h4 className="font-bold text-white text-sm mb-1">
                    {course.title}
                  </h4>
                  <p className="text-[11px] text-purple-300/70 font-medium mb-2">
                    {course.subtitle}
                  </p>
                  <p className="text-xs text-gray-400 leading-relaxed mb-4 line-clamp-3">
                    {course.description}
                  </p>

                  {/* Tools with logos */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {course.tools.map((tool) => (
                      <span
                        key={tool}
                        className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded bg-white/5 text-gray-300 border border-white/10"
                      >
                        <ToolLogo name={tool} size={12} />
                        {tool}
                      </span>
                    ))}
                  </div>

                  {/* Duration + Arrow */}
                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="text-[11px] text-gray-500">
                      {course.duration}
                    </span>
                    <ArrowLeft className="w-4 h-4 text-purple-400" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* ── AI Agent Demos ── */}
        <div className="mb-20">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-3xl font-bold text-white mb-3">
              عامل‌های هوشمند آماده
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              نمونه‌های عملی از عامل‌های AI که می‌توانید در کسب‌وکار خود استفاده
              کنید
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {aiAgents.map((agent) => {
              const Icon = agent.icon;
              return (
                <div
                  key={agent.title}
                  className="group glass-card rounded-xl p-5 overflow-hidden"
                >
                  {/* Hover glow */}
                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: agent.color + '20' }}
                    >
                      <Icon
                        className="w-5 h-5"
                        style={{ color: agent.color }}
                      />
                    </div>
                    <span
                      className="text-[10px] font-bold px-2.5 py-1 rounded-full"
                      style={{
                        backgroundColor: agent.color + '15',
                        color: agent.color,
                      }}
                    >
                      {agent.output}
                    </span>
                  </div>
                  <h4 className="font-bold text-white text-sm mb-1">
                    {agent.title}
                  </h4>
                  <p className="text-[11px] text-purple-300/60 font-medium mb-2">
                    {agent.subtitle}
                  </p>
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {agent.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* ── AI Learning Path Visualization (Scratch FIRST) ── */}
        <div className="mb-20">
          <div className="glass-card rounded-2xl p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500/20 to-cyan-500/20 flex items-center justify-center">
                <Waypoints className="w-5 h-5 text-purple-300" />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg">
                  نقشه راه یادگیری AI
                </h3>
                <p className="text-xs text-gray-400">
                  از اسکرچ تا استخدام — مسیر گام‌به‌گام
                </p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
              {learningPathSteps.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div key={item.step} className="relative">
                    <div className={`bg-white/5 border rounded-xl p-4 text-center hover:bg-white/10 ${
                      idx === 0 ? 'border-orange-500/40 bg-orange-500/5' : 'border-white/10'
                    }`}>
                      {/* Logo + Icon row */}
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <div
                          className="w-9 h-9 rounded-full flex items-center justify-center"
                          style={{ backgroundColor: item.color + '20' }}
                        >
                          <Icon
                            className="w-4 h-4"
                            style={{ color: item.color }}
                          />
                        </div>
                        <ToolLogo name={item.logo} size={28} />
                      </div>
                      <p className="text-xs font-bold text-white mb-0.5">
                        {item.title}
                      </p>
                      <p className="text-[10px] text-gray-500">{item.desc}</p>
                      {idx === 0 && (
                        <span className="inline-block mt-1.5 text-[9px] font-bold text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded-full">
                          شروع از اینجا
                        </span>
                      )}
                    </div>
                    {/* Arrow between steps */}
                    {idx < learningPathSteps.length - 1 && (
                      <div className="hidden xl:block absolute top-1/2 -right-2 transform -translate-y-1/2 text-purple-500/40 z-10">
                        <ArrowLeft className="w-3 h-3" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ── FAQ ── */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
              سوالات متداول درباره اکوسیستم AI
            </h3>
          </div>
          <div className="max-w-3xl mx-auto space-y-3">
            {aiFAQ.map((faq, idx) => (
              <div
                key={idx}
                className="glass-card rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setOpenFAQ(openFAQ === idx ? null : idx)}
                  className="w-full flex items-center justify-between gap-3 p-4 text-right hover:bg-white/5 transition-colors"
                >
                  <span className="font-medium text-white text-sm">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-purple-400 flex-shrink-0 transition-transform duration-300 ${
                      openFAQ === idx ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openFAQ === idx && (
                  <div className="px-4 pb-4 pt-0">
                    <p className="text-xs text-gray-400 leading-relaxed">
                      {faq.a}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── Bottom CTA ── */}
        <div className="text-center">
          <div className="inline-flex flex-col sm:flex-row items-center gap-4 bg-gradient-to-l from-purple-600/10 via-violet-600/10 to-cyan-600/10 border border-purple-500/25 rounded-2xl px-8 py-6">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-purple-400" />
              <div className="text-right">
                <p className="font-bold text-white">همین الان شروع کنید</p>
                <p className="text-xs text-gray-400">
                  از اسکرچ تا متخصص AI — مشاوره اولیه رایگان
                </p>
              </div>
            </div>
            <Link
              href="/consulting"
              className="inline-flex items-center gap-2 bg-gradient-to-l from-purple-600 to-violet-600 hover:from-purple-500 hover:to-violet-500 text-white font-bold px-8 py-3 rounded-xl transition-colors shadow-lg shadow-purple-600/25 text-sm"
            >
              رزرو مشاوره رایگان
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
