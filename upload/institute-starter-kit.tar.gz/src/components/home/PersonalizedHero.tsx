import Link from 'next/link';
import { ArrowLeft, Gamepad2, TrendingUp, Rocket, Target } from 'lucide-react';
import type { Persona } from '@/lib/personalization';

interface PersonalizedHeroProps {
  persona: Persona;
  heroTitle: string;
  heroSubtitle: string;
  heroHighlight: string;
  ctaText: string;
  ctaLink: string;
  gradientFrom: string;
  gradientVia: string;
  gradientTo: string;
  accentColor: string;
  onDismiss?: () => void;
  dismissed?: boolean;
}

const personaIcons: Record<Persona, React.ElementType> = {
  teen: Gamepad2,
  trader: TrendingUp,
  entrepreneur: Rocket,
  jobseeker: Target,
  default: Target,
};

/**
 * Server Component: Renders personalized hero banner content.
 * The dismiss logic is handled by the client wrapper.
 */
export default function PersonalizedHero({
  persona,
  heroTitle,
  heroSubtitle,
  heroHighlight,
  ctaText,
  ctaLink,
  gradientFrom,
  gradientVia,
  gradientTo,
  accentColor,
  onDismiss,
  dismissed,
}: PersonalizedHeroProps) {
  if (dismissed || persona === 'default') {
    return null;
  }

  const Icon = personaIcons[persona] || Target;

  return (
    <div
      className="w-full animate-slide-down"
      style={{
        background: `linear-gradient(to left, ${gradientTo}, ${gradientVia}, ${gradientFrom})`,
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          {/* Left: Icon + Text */}
          <div className="flex items-start sm:items-center gap-3 flex-1 min-w-0">
            <div
              className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center flex-shrink-0 bg-white/20 backdrop-blur-sm"
            >
              <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-bold text-white leading-tight mb-0.5">
                {heroTitle}
              </h2>
              <p className="text-xs sm:text-sm text-white/85 leading-relaxed line-clamp-2">
                {heroSubtitle}
              </p>
            </div>
          </div>

          {/* Right: CTA + Dismiss */}
          <div className="flex items-center gap-2 flex-shrink-0 w-full sm:w-auto">
            <Link
              href={ctaLink}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white text-sm font-bold px-5 py-2.5 rounded-xl transition-colors whitespace-nowrap border border-white/20"
            >
              {ctaText}
              <ArrowLeft className="w-3.5 h-3.5" />
            </Link>
            {onDismiss && (
              <button
                onClick={onDismiss}
                className="p-2 hover:bg-white/20 rounded-xl transition-colors border border-white/10"
                aria-label="بستن"
                type="button"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-white/70"
                >
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            )}
          </div>
        </div>

        {/* Highlight pill */}
        <div className="mt-3 flex items-center gap-2">
          <span
            className="inline-flex items-center text-[11px] sm:text-xs font-semibold px-3 py-1 rounded-full bg-white/15 text-white/90 border border-white/10"
          >
            <span
              className="w-1.5 h-1.5 rounded-full ml-1.5"
              style={{ backgroundColor: accentColor, boxShadow: `0 0 6px ${accentColor}` }}
            />
            {heroHighlight}
          </span>
        </div>
      </div>
    </div>
  );
}
