import Link from 'next/link';
import { ArrowLeft, Play, Users, Award, BookOpen, Sparkles } from 'lucide-react';
import AnimatedCounter from './AnimatedCounter';
import { siteConfig } from '@/config/site';

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#0f766e]">
      {/* Background pattern - CSS grid instead of heavy SVG */}
      <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: 'linear-gradient(white 1px, transparent 1px), linear-gradient(90deg, white 1px, transparent 1px)',
        backgroundSize: '40px 40px',
      }} />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-28">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Text Content */}
          <div className="text-center lg:text-right">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span className="text-sm text-white/90">پلتفرم آموزش مبتنی بر شایستگی (CBT)</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6">
              از مبتدی تا متخصص
              <br />
              <span className="text-[#5eead4]">مسیر شغلی شما اینجاست</span>
            </h1>
            <p className="text-base sm:text-lg text-white/80 leading-relaxed mb-8 max-w-xl mx-auto lg:mx-0">
              {siteConfig.name.fullName} با {siteConfig.experience.yearsFa} سال تجربه، بر پایه آموزش پروژه‌محور و صدور گواهینامه
              بین‌المللی، مسیر تبدیل شما از کارآموز به متخصص بازار کار را هموار می‌کند.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link
                href="/courses"
                className="inline-flex items-center justify-center gap-2 bg-white text-[#0f766e] font-bold px-8 py-3.5 rounded-xl hover:bg-gray-50 transition-all shadow-lg shadow-black/10"
              >
                مشاهده دوره‌ها
                <ArrowLeft className="w-4 h-4" />
              </Link>
              <Link
                href="/consulting"
                className="inline-flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white font-bold px-8 py-3.5 rounded-xl hover:bg-white/20 transition-all border border-white/20"
              >
                مشاوره رایگان
              </Link>
            </div>
          </div>

          {/* Stats & Visual */}
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/10">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-[#5eead4]/20 flex items-center justify-center">
                    <Award className="w-5 h-5 text-[#5eead4]" />
                  </div>
                  <AnimatedCounter target={27} suffix="+" />
                </div>
                <p className="text-sm text-white/70">سال تجربه آموزشی</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/10">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-[#5eead4]/20 flex items-center justify-center">
                    <Users className="w-5 h-5 text-[#5eead4]" />
                  </div>
                  <AnimatedCounter target={5000} suffix="+" />
                </div>
                <p className="text-sm text-white/70">کارآموزان فارغ‌التحصیل</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/10">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-[#5eead4]/20 flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-[#5eead4]" />
                  </div>
                  <AnimatedCounter target={15} suffix="" />
                </div>
                <p className="text-sm text-white/70">دوره تخصصی فعال</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/10">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-[#5eead4]/20 flex items-center justify-center">
                    <Play className="w-5 h-5 text-[#5eead4]" />
                  </div>
                  <AnimatedCounter target={4} suffix="" />
                </div>
                <p className="text-sm text-white/70">خوشه شایستگی</p>
              </div>
            </div>

            {/* Trust Badge */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#5eead4]/20 flex items-center justify-center flex-shrink-0">
                  <Award className="w-6 h-6 text-[#5eead4]" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white">مجوز رسمی سازمان فنی و حرفه‌ای</p>
                  <p className="text-xs text-white/60">گواهینامه‌های بین‌المللی ICDL معتبر در ۱۴۰+ کشور</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave Divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path
            d="M0 80V30C240 0 480 60 720 40C960 20 1200 60 1440 30V80H0Z"
            fill="white"
          />
        </svg>
      </div>
    </section>
  );
}
