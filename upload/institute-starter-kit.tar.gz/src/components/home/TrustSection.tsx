import Image from 'next/image';
import { Shield, GraduationCap, CheckCircle2, BookOpen, Sparkles } from 'lucide-react';
import { siteConfig } from '@/config/site';

const credentials = [
  {
    icon: Shield,
    title: siteConfig.trust[0].title,
    desc: siteConfig.trust[0].description,
  },
  {
    icon: BookOpen,
    title: siteConfig.trust[1].title,
    desc: siteConfig.trust[1].description,
  },
];

const instructorInfo = {
  name: siteConfig.founder.name,
  title: siteConfig.founder.title,
  credentials: siteConfig.founder.credentials as readonly string[],
};

export default function TrustSection() {
  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Dark glossy background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#111827] to-[#0a1628] animate-gradient-shift-reverse" />

      {/* Decorative grid */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(13,148,136,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(13,148,136,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Glow effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-teal-600/15 rounded-full blur-[120px] animate-glow-pulse-intense" />
      <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-amber-600/10 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: '3s' }} />

      {/* Floating particles */}
      <div className="absolute top-20 left-1/4 w-2.5 h-2.5 bg-teal-400/30 rounded-full animate-particle-1" />
      <div className="absolute bottom-20 right-1/3 w-2 h-2 bg-amber-400/25 rounded-full animate-particle-2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-teal-300 bg-teal-500/15 backdrop-blur-md border border-teal-500/20 rounded-full px-4 py-1.5 mb-4 animate-float-slow">
            <Sparkles className="w-3.5 h-3.5" />
            اعتبار و صلاحیت
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            چرا {siteConfig.name.fa}؟
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto leading-relaxed">
            {siteConfig.experience.yearsFa} سال اعتبار، مجوزهای رسمی و گواهینامه‌های بین‌المللی. {siteConfig.name.fullName} تنها آموزشگاه
            {siteConfig.location.city} با این سطح از اعتبار رسمی است.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Credentials — glass cards on dark bg */}
          <div className="grid sm:grid-cols-2 gap-5">
            {credentials.map((cred) => (
              <div
                key={cred.title}
                className="group glass-card rounded-2xl p-5 hover:border-teal-500/30 transition-colors duration-200"
              >
                <div className="w-12 h-12 rounded-xl bg-teal-500/15 flex items-center justify-center mb-4">
                  <cred.icon className="w-6 h-6 text-teal-400" />
                </div>
                <h3 className="font-bold text-white text-sm mb-2">{cred.title}</h3>
                <p className="text-xs text-gray-400 leading-relaxed">{cred.desc}</p>
              </div>
            ))}
          </div>

          {/* Right Side: Instructor Info + Badges */}
          <div className="space-y-6">
            {/* Instructor Card — glossy dark with shimmer */}
            <div className="relative rounded-2xl p-6 sm:p-8 overflow-hidden group" style={{ background: 'linear-gradient(135deg, #0d9488, #0f766e, #0f172a)' }}>
              {/* Static gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#0d9488]/20 to-transparent opacity-50" />
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                    <GraduationCap className="w-5 h-5 text-[#5eead4]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-white">{instructorInfo.name}</h3>
                    <p className="text-sm text-white/70">{instructorInfo.title}</p>
                  </div>
                </div>

                <div className="mt-5 space-y-3">
                  {instructorInfo.credentials.map((cred, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-[#5eead4] mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-white/90">{cred}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>
    </section>
  );
}
