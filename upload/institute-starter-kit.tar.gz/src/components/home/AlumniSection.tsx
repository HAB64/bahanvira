import Link from 'next/link';
import { Briefcase, GraduationCap, Quote, ArrowLeft, Sparkles } from 'lucide-react';
import { alumni, clusterColors } from '@/data/alumni';
import { siteConfig } from '@/config/site';

export default function AlumniSection() {
  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Dark tech background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a192f] via-[#0d1f3c] to-[#0a1628] animate-gradient-shift-reverse" />

      {/* Circuit grid pattern */}
      <div className="absolute inset-0 circuit-grid opacity-[0.06]" />

      {/* Glow effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-teal-600/15 rounded-full blur-[120px] animate-glow-pulse-intense" />
      <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-amber-600/10 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: '3s' }} />

      {/* Floating particles */}
      <div className="absolute top-20 left-1/4 w-2.5 h-2.5 bg-teal-400/30 rounded-full animate-particle-1" />
      <div className="absolute bottom-20 right-1/3 w-2 h-2 bg-amber-400/25 rounded-full animate-particle-2" />
      <div className="absolute top-1/2 right-1/4 w-3 h-3 bg-violet-400/20 rounded-full animate-particle-3" style={{ animationDelay: '5s' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-teal-300 bg-teal-500/15 backdrop-blur-md border border-teal-500/20 rounded-full px-4 py-1.5 mb-4 animate-float-slow">
            <Sparkles className="w-3.5 h-3.5" />
            فارغ‌التحصیلان موفق
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            داستان‌های موفقیت فارغ‌التحصیلان
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto leading-relaxed">
            از کلاس درس تا بازار کار — مسیر واقعی
          </p>
        </div>

        {/* Alumni Cards Grid — glass cards on dark bg */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {alumni.map((person, index) => {
            const colors = clusterColors[person.cluster] ?? { color: '#0d9488', colorLight: '#ccfbf1' };
            return (
              <div
                key={`${person.name}-${index}`}
                className="group glass-card rounded-2xl overflow-hidden"
              >
                {/* Gradient Top Bar */}
                <div
                  className="h-1.5"
                  style={{
                    background: `linear-gradient(to left, ${colors.color}, ${colors.color}88)`,
                  }}
                />

                <div className="relative p-6">
                  {/* Name & Year */}
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-bold text-base text-white">{person.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        {/* Course Badge */}
                        <span
                          className="text-[10px] font-medium px-2.5 py-1 rounded-full border border-white/10"
                          style={{
                            backgroundColor: colors.color + '20',
                            color: colors.color,
                          }}
                        >
                          {person.course}
                        </span>
                      </div>
                    </div>
                    {/* Year */}
                    <span className="text-xs text-gray-400 bg-white/5 backdrop-blur-sm px-2.5 py-1 rounded-lg font-medium flex-shrink-0 border border-white/10">
                      فارغ‌التحصیل {person.year}
                    </span>
                  </div>

                  {/* Quote */}
                  <div className="relative mb-4">
                    <Quote className="absolute -top-1 -right-1 w-5 h-5 text-teal-500/10 rotate-180" />
                    <p className="text-sm text-gray-300 leading-relaxed pr-5">
                      &laquo;{person.quote}&raquo;
                    </p>
                  </div>

                  {/* Achievement Badge */}
                  <div className="flex items-center gap-2 mb-4">
                    <div
                      className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: colors.color + '20' }}
                    >
                      <GraduationCap className="w-3.5 h-3.5" style={{ color: colors.color }} />
                    </div>
                    <span className="text-xs font-medium" style={{ color: colors.color }}>
                      {person.achievement}
                    </span>
                  </div>

                  {/* Current Role */}
                  <div className="pt-4 border-t border-white/10">
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-3.5 h-3.5 text-teal-400 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-white truncate">{person.role}</p>
                        {person.company && (
                          <p className="text-[10px] text-gray-500 truncate">{person.company}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Link
            href="/consulting"
            className="inline-flex items-center gap-2 bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold px-8 py-3.5 rounded-xl transition-all text-sm shadow-lg shadow-teal-600/20 animate-ripple"
          >
            مسیر شغلی خود را بسازید
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <p className="text-xs text-gray-500 mt-3">
            {`مشاوره رایگان مسیر شغلی — ${siteConfig.contact.phone}`}
          </p>
        </div>
      </div>
    </section>
  );
}
