import Link from 'next/link';
import { Phone, MessageCircle, Award, Shield, Sparkles, ArrowLeft } from 'lucide-react';
import { siteConfig } from '@/config/site';

export default function CTASection() {
  return (
    <section className="py-16 sm:py-20 relative overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-bl from-[#0f172a] via-[#0d9488] to-[#0f766e] animate-gradient-shift" />

      {/* Background pattern — more visible */}
      <div className="absolute inset-0 opacity-15">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="cta-grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#cta-grid)" />
        </svg>
      </div>

      {/* Floating particles */}
      <div className="absolute top-20 left-1/4 w-3 h-3 bg-white/20 rounded-full animate-particle-1" />
      <div className="absolute bottom-20 right-1/3 w-2 h-2 bg-white/15 rounded-full animate-particle-2" />
      <div className="absolute top-1/2 left-10 w-4 h-4 bg-white/10 rounded-full animate-particle-3" />

      {/* Decorative glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-teal-400/15 rounded-full blur-[120px] animate-glow-pulse" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-400/10 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: '3s' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text */}
          <div className="text-center lg:text-right">
            {/* Animated badge */}
            <div className="inline-flex items-center gap-1.5 bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-4 py-1.5 mb-6 animate-float-slow">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span className="text-xs font-medium text-amber-200">شروع یادگیری</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
              آماده‌اید مهارت جدید یاد بگیرید؟
            </h2>
            <p className="text-white/80 leading-relaxed mb-8 max-w-lg mx-auto lg:mx-0">
              همین الان مشاوره رایگان دریافت کنید و مسیر شغلی مناسب خود را پیدا کنید.
              تیم مشاوره {siteConfig.name.fullName} آماده راهنمایی شماست.
            </p>
            <div className="flex items-center gap-4 justify-center lg:justify-start mb-8">
              <div className="flex -space-x-2 space-x-reverse">
                {[1,2,3,4].map(i => (
                  <div key={i} className="w-8 h-8 rounded-full border-2 border-white flex items-center justify-center text-[10px] font-bold text-white" style={{ backgroundColor: ['#0d9488','#2563eb','#d97706','#7c3aed'][i-1] }}>
                    {['س','م','ع','ف'][i-1]}
                  </div>
                ))}
              </div>
              <div className="text-right">
                <p className="text-sm text-white font-medium">۵,۰۰۰+ فارغ‌التحصیل</p>
                <p className="text-xs text-white/60">در {siteConfig.experience.yearsFa} سال فعالیت</p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link
                href="/consulting"
                className="group inline-flex items-center justify-center gap-2 bg-white text-[#0f766e] font-bold px-8 py-3.5 rounded-xl hover:bg-gray-50 transition-all shadow-lg shadow-black/10 hover:shadow-xl"
              >
                درخواست مشاوره رایگان
                <ArrowLeft className="w-4 h-4" />
              </Link>
              <a
                href={siteConfig.contact.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white font-bold px-8 py-3.5 rounded-xl hover:bg-[#20ba5c] transition-all shadow-lg shadow-black/10 animate-ripple"
              >
                <MessageCircle className="w-5 h-5" />
                پیام در واتساپ
              </a>
            </div>
          </div>

          {/* Trust Signals — with hover effects */}
          <div className="grid grid-cols-2 gap-4">
            {[
              { icon: Award, title: 'مجوز رسمی', desc: 'سازمان فنی و حرفه‌ای ایران' },
              { icon: Shield, title: 'گواهینامه بین‌المللی', desc: 'ICDL معتبر در ۱۴۰+ کشور' },
              { icon: Phone, title: 'پشتیبانی مستمر', desc: 'تا زمان اخذ مدرک و استخدام' },
              { icon: MessageCircle, title: 'مشاوره رایگان', desc: 'انتخاب مسیر شغلی مناسب' },
            ].map((item, idx) => (
              <div
                key={item.title}
                className="group bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/15 hover:bg-white/15"
              >
                <item.icon className="w-8 h-8 text-[#5eead4] mb-3" />
                <h3 className="font-bold text-white text-sm mb-1">{item.title}</h3>
                <p className="text-xs text-white/60">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
