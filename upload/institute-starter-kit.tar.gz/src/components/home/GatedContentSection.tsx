'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  Download,
  FileText,
  Video,
  CheckSquare,
  Phone,
  Mail,
  Lock,
  Loader2,
  BookOpen,
  Sparkles,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

interface LeadMagnet {
  id: string;
  title: string;
  description: string;
  type: string;
  thumbnailUrl: string | null;
  targetCluster: string;
  targetPersona: string;
  requiresPhone: boolean;
  requiresEmail: boolean;
  downloadCount: number;
  leadCount: number;
  createdAt: string;
}

const typeConfig: Record<
  string,
  { icon: React.ElementType; label: string; gradient: string }
> = {
  PDF: {
    icon: FileText,
    label: 'PDF',
    gradient: 'from-teal-500 to-emerald-600',
  },
  VIDEO: {
    icon: Video,
    label: 'ویدیو',
    gradient: 'from-amber-500 to-orange-600',
  },
  CHECKLIST: {
    icon: CheckSquare,
    label: 'چک‌لیست',
    gradient: 'from-purple-500 to-violet-600',
  },
  MINI_COURSE: {
    icon: BookOpen,
    label: 'مینی‌دوره',
    gradient: 'from-rose-500 to-pink-600',
  },
};

export default function GatedContentSection() {
  const [magnets, setMagnets] = useState<LeadMagnet[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMagnet, setSelectedMagnet] = useState<LeadMagnet | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    fileUrl: string | null;
    magnetTitle: string;
    magnetType: string;
  } | null>(null);
  const [error, setError] = useState('');

  const fetchMagnets = useCallback(async () => {
    try {
      const res = await fetch('/api/gated-content');
      if (res.ok) {
        const data = await res.json();
        setMagnets(data.magnets || []);
      }
    } catch {
      // silently fail
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMagnets();
  }, [fetchMagnets]);

  const handleSubmit = async () => {
    setError('');
    setResult(null);

    const phoneRegex = /^09\d{9}$/;
    if (!phoneRegex.test(phone)) {
      setError('شماره موبایل معتبر وارد کنید (مثال: 09123456789)');
      return;
    }

    if (email && email.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        setError('ایمیل معتبر وارد کنید');
        return;
      }
    }

    if (!selectedMagnet) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/gated-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          magnetId: selectedMagnet.id,
          phone,
          email: email || undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'خطایی رخ داد');
        return;
      }

      setResult({
        success: true,
        fileUrl: data.fileUrl,
        magnetTitle: data.magnetTitle,
        magnetType: data.magnetType,
      });
    } catch {
      setError('خطا در ارتباط با سرور');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenDialog = (magnet: LeadMagnet) => {
    setSelectedMagnet(magnet);
    setPhone('');
    setEmail('');
    setError('');
    setResult(null);
    setDialogOpen(true);
  };

  const typeIcon = (type: string) => {
    const config = typeConfig[type] || typeConfig.PDF;
    const Icon = config.icon;
    return <Icon className="size-5" />;
  };

  if (loading) {
    return (
      <section className="py-16 sm:py-20 relative overflow-hidden" dir="rtl">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a192f] via-[#0d1f3c] to-[#0a1628]" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <div className="w-10 h-10 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </section>
    );
  }

  if (magnets.length === 0) return null;

  return (
    <section
      className="py-16 sm:py-20 relative overflow-hidden"
      dir="rtl"
    >
      {/* Dark tech background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a192f] via-[#0d1f3c] to-[#0a1628] animate-gradient-shift" />

      {/* Circuit grid pattern */}
      <div className="absolute inset-0 circuit-grid opacity-[0.06]" />

      {/* Glow effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-teal-600/15 rounded-full blur-[120px] animate-glow-pulse-intense" />
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-amber-600/10 rounded-full blur-[100px] animate-glow-pulse" style={{ animationDelay: '3s' }} />

      {/* Floating particles */}
      <div className="absolute top-20 right-1/4 w-2.5 h-2.5 bg-teal-400/30 rounded-full animate-particle-1" />
      <div className="absolute bottom-20 left-1/3 w-2 h-2 bg-amber-400/25 rounded-full animate-particle-2" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="inline-flex items-center gap-1.5 text-sm font-bold text-teal-300 bg-teal-500/15 backdrop-blur-md border border-teal-500/20 rounded-full px-4 py-1.5 mb-4 animate-float-slow">
            <Sparkles className="w-3.5 h-3.5" />
            محتوای رایگان
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            محتوای آموزشی{' '}
            <span className="text-teal-400">رایگان</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            با ثبت شماره موبایل، به راهنماها، ویدیوها و چک‌لیست‌های آموزشی
            رایگان دسترسی پیدا کنید
          </p>
        </div>

        {/* Cards Grid — glass cards on dark bg */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {magnets.map((magnet, index) => {
            const config = typeConfig[magnet.type] || typeConfig.PDF;
            const Icon = config.icon;
            return (
              <div
                key={magnet.id}
                className="group glass-card rounded-2xl overflow-hidden"
              >
                {/* Gradient Top Bar */}
                <div
                  className={`h-1.5 bg-gradient-to-l ${config.gradient}`}
                />

                <div className="relative p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className={`w-12 h-12 rounded-xl bg-gradient-to-br ${config.gradient} flex items-center justify-center text-white shadow-lg`}
                    >
                      <Icon className="size-6" />
                    </div>
                    <span
                      className="text-[10px] font-bold px-2.5 py-1 rounded-full border border-white/10"
                      style={{
                        backgroundColor: config.gradient.includes('teal') ? 'rgba(13,148,136,0.15)' :
                          config.gradient.includes('amber') ? 'rgba(245,158,11,0.15)' :
                          config.gradient.includes('purple') ? 'rgba(139,92,246,0.15)' :
                          'rgba(236,72,153,0.15)',
                        color: config.gradient.includes('teal') ? '#5eead4' :
                          config.gradient.includes('amber') ? '#fbbf24' :
                          config.gradient.includes('purple') ? '#c4b5fd' :
                          '#f9a8d4',
                      }}
                    >
                      {config.label}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white leading-relaxed mb-2">
                    {magnet.title}
                  </h3>

                  <p className="text-sm text-gray-400 leading-relaxed mb-4">
                    {magnet.description}
                  </p>

                  {magnet.downloadCount > 0 && (
                    <div className="flex items-center gap-1 text-xs text-gray-500 mb-4">
                      <Download className="size-3" />
                      <span>
                        {magnet.downloadCount.toLocaleString('fa-IR')} دانلود
                      </span>
                    </div>
                  )}

                  <Button
                    onClick={() => handleOpenDialog(magnet)}
                    className="w-full bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white shadow-lg hover:shadow-xl transition-all duration-300 gap-2 border-0"
                    size="lg"
                  >
                    <Lock className="size-4" />
                    دریافت رایگان
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Download Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md bg-[#0d1f3c] border-white/10 text-white" dir="rtl">
          {!result ? (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2 text-right text-white">
                  <Download className="size-5 text-teal-400" />
                  دریافت {selectedMagnet?.title}
                </DialogTitle>
                <DialogDescription className="text-right text-gray-400">
                  برای دانلود رایگان، شماره موبایل خود را وارد کنید
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 mt-2">
                {/* Magnet Info */}
                {selectedMagnet && (
                  <div className="bg-white/[0.06] backdrop-blur-md rounded-lg p-3 flex items-center gap-3 border border-white/10">
                    <div className="w-10 h-10 rounded-lg bg-teal-600 flex items-center justify-center text-white shrink-0">
                      {typeIcon(selectedMagnet.type)}
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-sm text-white truncate">
                        {selectedMagnet.title}
                      </p>
                      <p className="text-xs text-gray-400">
                        {typeConfig[selectedMagnet.type]?.label || 'فایل'}
                      </p>
                    </div>
                  </div>
                )}

                {/* Phone Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300 flex items-center gap-1.5">
                    <Phone className="size-4 text-teal-400" />
                    شماره موبایل <span className="text-red-400">*</span>
                  </label>
                  <Input
                    type="tel"
                    dir="ltr"
                    placeholder="09123456789"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="text-left placeholder:text-left bg-white/[0.06] border-white/10 text-white placeholder:text-gray-500 focus:border-teal-500/50"
                    maxLength={11}
                  />
                </div>

                {/* Email Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-300 flex items-center gap-1.5">
                    <Mail className="size-4 text-gray-500" />
                    ایمیل <span className="text-gray-500">(اختیاری)</span>
                  </label>
                  <Input
                    type="email"
                    dir="ltr"
                    placeholder="email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="text-left placeholder:text-left bg-white/[0.06] border-white/10 text-white placeholder:text-gray-500 focus:border-teal-500/50"
                  />
                </div>

                {/* Error Message */}
                {error && (
                  <div className="bg-red-500/10 text-red-400 text-sm rounded-lg p-3 border border-red-500/20">
                    {error}
                  </div>
                )}

                {/* Submit Button */}
                <Button
                  onClick={handleSubmit}
                  disabled={submitting}
                  className="w-full bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white gap-2 border-0"
                  size="lg"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="size-4 animate-spin" />
                      در حال پردازش...
                    </>
                  ) : (
                    <>
                      <Download className="size-4" />
                      دانلود رایگان
                    </>
                  )}
                </Button>

                <p className="text-xs text-gray-500 text-center">
                  با ثبت شماره، مشاوران ما ممکن است برای راهنمایی با شما تماس
                  بگیرند
                </p>
              </div>
            </>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle className="text-right flex items-center gap-2 text-white">
                  <div className="w-8 h-8 rounded-full bg-teal-500/20 flex items-center justify-center">
                    <Download className="size-4 text-teal-400" />
                  </div>
                  دانلود آماده است!
                </DialogTitle>
                <DialogDescription className="text-right text-gray-400">
                  محتوای «{result.magnetTitle}» آماده دانلود است
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 mt-2">
                <div className="bg-teal-500/10 rounded-lg p-4 text-center border border-teal-500/20">
                  <div className="w-16 h-16 rounded-full bg-teal-500/15 flex items-center justify-center mx-auto mb-3">
                    <Download className="size-8 text-teal-400" />
                  </div>
                  <p className="text-teal-300 font-medium mb-1">
                    دسترسی شما تأیید شد
                  </p>
                  <p className="text-gray-400 text-sm">
                    روی دکمه زیر کلیک کنید تا دانلود شروع شود
                  </p>
                </div>

                {result.fileUrl ? (
                  <a
                    href={result.fileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full"
                  >
                    <Button
                      className="w-full bg-gradient-to-l from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white gap-2 border-0"
                      size="lg"
                    >
                      <Download className="size-4" />
                      شروع دانلود
                    </Button>
                  </a>
                ) : (
                  <div className="bg-white/[0.04] rounded-lg p-4 text-center border border-white/10">
                    <p className="text-gray-300 text-sm">
                      لینک دانلود به زودی از طریق پیامک ارسال خواهد شد
                    </p>
                  </div>
                )}

                <Button
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                  className="w-full border-white/10 text-gray-300 hover:bg-white/5 hover:text-white"
                >
                  بستن
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
