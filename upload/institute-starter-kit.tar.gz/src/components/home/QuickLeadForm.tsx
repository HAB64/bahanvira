'use client';

import { useState, useCallback, type FormEvent } from 'react';
import { Send, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import Image from 'next/image';
import { useUTM } from '@/hooks/use-utm';
import { useGTM } from '@/hooks/useGTM';

/**
 * ─── فرم مشاوره کوتاه — فقط نام + شماره ───
 * 
 * اصل: بار شناختی کم = نرخ تبدیل بالا
 * فقط ۲ فیلد الزامی (نام + شماره) — بقیه اطلاعات در تماس مشاوره‌ای جمع‌آوری می‌شود
 */
export default function QuickLeadForm() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const utm = useUTM();
  const { trackFormSubmission } = useGTM();

  const validatePhone = useCallback((p: string) => /^09[0-9]{9}$/.test(p), []);

  const handleSubmit = useCallback(
    async (e: FormEvent) => {
      e.preventDefault();
      setError('');

      if (!name.trim()) {
        setError('لطفاً نام خود را وارد کنید');
        return;
      }
      if (!validatePhone(phone)) {
        setError('شماره موبایل نامعتبر است (فرمت: 09123456789)');
        return;
      }

      setLoading(true);
      try {
        const res = await fetch('/api/crm/leads', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: name.trim(),
            phone,
            source: 'hero-quick-form',
            utmSource: utm.utmSource,
            utmMedium: utm.utmMedium,
            utmCampaign: utm.utmCampaign,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          setError(data['خطا'] || data.error || 'خطا در ثبت درخواست');
          return;
        }
        setSuccess(true);
        // ── GTM: track form submission ──────────────────────
        trackFormSubmission({
          formType: 'quick-consultation',
          formLocation: 'hero',
          interestedCategory: 'IT',
          source: 'website_form',
        });
        // ثبت رویداد تبدیل
        fetch('/api/events', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'FORM_SUBMIT',
            category: 'conversion',
            label: 'hero-quick-form',
            page: typeof window !== 'undefined' ? window.location.pathname : '/',
            metadata: { formType: 'quick-consultation' },
          }),
        }).catch(() => {});
      } catch {
        setError('خطا در ارتباط با سرور');
      } finally {
        setLoading(false);
      }
    },
    [name, phone, validatePhone, utm, trackFormSubmission]
  );

  // ── حالت موفق ─────────────────────────────
  if (success) {
    return (
      <div className="rounded-2xl p-6 text-center glass-card border-teal-500/20">
        <CheckCircle2 className="w-14 h-14 text-teal-400 mx-auto mb-3" />
        <p className="text-white font-bold text-lg mb-1">درخواست مشاوره شما ثبت شد!</p>
        <p className="text-gray-400 text-sm">مشاوران ما به زودی تماس خواهند گرفت</p>
        <button
          onClick={() => { setSuccess(false); setName(''); setPhone(''); }}
          className="mt-4 text-sm text-teal-400 hover:text-teal-300 font-medium transition-colors"
        >
          ثبت درخواست دیگر
        </button>
      </div>
    );
  }

  // ── فرم ساده ───────────────────────────────
  return (
    <div className="rounded-2xl glass-card overflow-hidden">
      <div className="p-5 sm:p-6">
        {/* 27 years badge — full width */}
        <div className="mb-3">
          <Image
            src="/images/27-years-badge.webp"
            alt="۲۷ سال سابقه آموزشگاه بهان رایانه"
            width={400}
            height={250}
            className="w-full sm:w-[380px] h-auto object-contain rounded-lg"
          />
        </div>
        <h3 className="text-white font-black text-lg mb-1">مشاوره رایگان</h3>
        <p className="text-gray-400 text-xs mb-5">نام و شماره‌تان را بگذارید، مشاوران ما تماس می‌گیرند</p>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="نام و نام خانوادگی"
            className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500/50 transition-all"
            disabled={loading}
          />
          <input
            type="tel"
            value={phone}
            onChange={(e) => {
              const val = e.target.value.replace(/[^0-9]/g, '');
              if (val.length <= 11) setPhone(val);
            }}
            placeholder="شماره همراه (09123456789)"
            dir="ltr"
            className="w-full bg-white/[0.06] border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500/50 transition-all text-left"
            disabled={loading}
          />
          {error && (
            <div className="flex items-center gap-2 text-red-400 text-xs bg-red-500/10 rounded-lg px-3 py-2 border border-red-500/20">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-l from-[#0d9488] to-[#0f766e] hover:from-[#0f766e] hover:to-[#115e59] disabled:opacity-50 text-white font-bold py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 text-sm shadow-lg shadow-[#0d9488]/25"
          >
            {loading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> در حال ثبت...</>
            ) : (
              <><Send className="w-4 h-4" /> دریافت مشاوره رایگان</>
            )}
          </button>
        </form>

        {/* اعتمادساز مینیمال */}
        <div className="mt-4 flex items-center justify-center gap-1.5 text-gray-500 text-[11px]">
          <CheckCircle2 className="w-3 h-3 text-teal-500" />
          <span>مجوز رسمی فنی و حرفه‌ای + مدرک بین‌المللی ICDL</span>
        </div>
      </div>
    </div>
  );
}
