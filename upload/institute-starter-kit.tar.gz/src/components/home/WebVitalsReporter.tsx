'use client';

import { useWebVitals } from '@/hooks/useWebVitals';

/**
 * WebVitalsReporter — کامپوننت نامرئی برای جمع‌آوری متریک‌ها
 * در صفحه اصلی قرار می‌گیرد تا داده‌های واقعی کاربران را جمع‌آوری کند
 */
export default function WebVitalsReporter() {
  useWebVitals({
    reportToServer: true,
    productionOnly: true,
  });

  return null; // این کامپوننت هیچ چیزی رندر نمی‌کند
}
