'use client';

import { useState } from 'react';
import Link from 'next/link';
import { X, Gamepad2, TrendingUp, Rocket, Target } from 'lucide-react';
import { useUTMPersonalization, UTMPersona } from '@/hooks/useUTMPersonalization';

const personaConfig: Record<UTMPersona, {
  title: string;
  link: string;
  linkText: string;
  gradient: string;
  icon: React.ElementType;
}> = {
  teen: {
    title: 'مسیر یادگیری نوجوانان — از Scratch تا پایتون 🎮',
    link: '/courses?cluster=tech-ai',
    linkText: 'مشاهده دوره‌های نوجوانان',
    gradient: 'from-yellow-500 via-amber-500 to-orange-500',
    icon: Gamepad2,
  },
  trader: {
    title: 'مسیر معامله‌گری حرفه‌ای — مدیریت ریسک + الگوریتمی 📈',
    link: '/courses?cluster=financial',
    linkText: 'مشاهده دوره‌های معامله‌گری',
    gradient: 'from-amber-600 via-orange-600 to-red-600',
    icon: TrendingUp,
  },
  entrepreneur: {
    title: 'مسیر کارآفرینی دیجیتال — از ایده تا درآمد 💡',
    link: '/courses/entrepreneurship',
    linkText: 'مشاهده دوره کارآفرینی',
    gradient: 'from-purple-600 via-violet-600 to-fuchsia-600',
    icon: Rocket,
  },
  jobseeker: {
    title: 'مسیر اشتغال — ICDL + مهارت‌های اداری 🎯',
    link: '/courses/icdl',
    linkText: 'مشاهده دوره ICDL',
    gradient: 'from-teal-600 via-cyan-600 to-sky-600',
    icon: Target,
  },
};

export default function UTMPersonalizer() {
  const personalization = useUTMPersonalization();
  const [dismissed, setDismissed] = useState(false);

  if (!personalization || dismissed) {
    return null;
  }

  const config = personaConfig[personalization.persona];
  const Icon = config.icon;

  return (
    <div className="relative z-10 animate-slide-down">
      <div className={`bg-gradient-to-l ${config.gradient} text-white`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <Icon className="w-5 h-5 flex-shrink-0" />
              <span className="text-sm font-medium truncate">{config.title}</span>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <Link
                href={config.link}
                className="bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white text-xs font-bold px-4 py-1.5 rounded-full transition-colors whitespace-nowrap"
              >
                {config.linkText}
              </Link>
              <button
                onClick={() => setDismissed(true)}
                className="p-1 hover:bg-white/20 rounded-full transition-colors"
                aria-label="بستن"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
