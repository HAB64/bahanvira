import Link from 'next/link';
import Image from 'next/image';
import { Phone, MapPin, Mail } from 'lucide-react';
import { siteConfig } from '@/config/site';

const quickLinks = [
  { label: 'صفحه اصلی', href: '/' },
  { label: 'دوره‌ها', href: '/courses' },
  { label: 'درباره ما', href: '/about' },
  { label: 'مشاوره و ثبت‌نام', href: '/consulting' },
  { label: 'استعلام مدرک', href: '/verify' },
  { label: 'وبلاگ', href: '/blog' },
  { label: 'تماس با ما', href: '/contact' },
];

const clusterLinks = [
  { label: 'فناوری و هوش مصنوعی', href: '/courses?cluster=tech-ai' },
  { label: 'بازارهای مالی', href: '/courses?cluster=financial' },
  { label: 'مدیریت و کارآفرینی', href: '/courses?cluster=management' },
  { label: 'صنایع خلاق و هنر', href: '/courses?cluster=creative' },
];

export default function Footer() {
  return (
    <footer className="bg-[#0a1628] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Column 1: Logo & Description */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-full overflow-hidden ring-2 ring-amber-400/30 shadow-lg">
                <Image
                  src={siteConfig.assets.logo}
                  alt={`لوگو ${siteConfig.name.fa}`}
                  width={48}
                  height={48}
                  className="object-cover w-full h-full"
                />
              </div>
              <div>
                <span className="text-lg font-black block leading-tight">{siteConfig.name.fa}</span>
                <span className="text-xs text-amber-400 font-medium">{`پلتفرم مهارت‌آموزی ${siteConfig.institute.typeFa}`}</span>
              </div>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed mb-6 max-w-xs">
              {`پلتفرم مهارت‌آموزی ${siteConfig.name.fa} با ${siteConfig.experience.yearsFa} سال تجربه درخشان، بر پایه آموزش مبتنی بر شایستگی (CBT) مسیر تبدیل شما از مبتدی به متخصص را هموار می‌کند.`}
            </p>
            <div className="flex gap-3">
              {/* WhatsApp */}
              <a
                href={siteConfig.contact.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-[#25D366] flex items-center justify-center transition-all group border border-white/10 hover:border-[#25D366]/50"
                title="واتساپ"
              >
                <svg className="w-[18px] h-[18px] text-[#25D366] group-hover:text-white transition-colors" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
              </a>
              {/* Instagram */}
              <a
                href={siteConfig.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-gradient-to-br hover:from-[#833AB4] hover:via-[#FD1D1D] hover:to-[#F77737] flex items-center justify-center transition-all group border border-white/10"
                title="اینستاگرام"
              >
                <svg className="w-[18px] h-[18px] text-[#E1306C] group-hover:text-white transition-colors" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                  <circle cx="12" cy="12" r="5.5" />
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                </svg>
              </a>
              {/* Telegram */}
              <a
                href={siteConfig.social.telegram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-[#0088cc] flex items-center justify-center transition-all group border border-white/10 hover:border-[#0088cc]/50"
                title="تلگرام"
              >
                <svg className="w-[18px] h-[18px] text-[#0088cc] group-hover:text-white transition-colors" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                </svg>
              </a>
              {/* Email */}
              <a
                href={`mailto:${siteConfig.contact.email}`}
                className="w-10 h-10 rounded-xl bg-white/5 hover:bg-[#EA4335] flex items-center justify-center transition-all group border border-white/10 hover:border-[#EA4335]/50"
                title="ایمیل"
              >
                <Mail className="w-4 h-4 text-[#EA4335] group-hover:text-white transition-colors" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h3 className="font-bold text-base mb-5 text-amber-400">دسترسی سریع</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-400 hover:text-[#14b8a6] transition-colors flex items-center gap-2"
                  >
                    <span className="w-1 h-1 bg-[#0d9488] rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Clusters */}
          <div>
            <h3 className="font-bold text-base mb-5 text-amber-400">خوشه‌های شایستگی</h3>
            <ul className="space-y-3">
              {clusterLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-gray-400 hover:text-[#14b8a6] transition-colors flex items-center gap-2"
                  >
                    <span className="w-1 h-1 bg-[#0d9488] rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Contact Info */}
          <div>
            <h3 className="font-bold text-base mb-5 text-amber-400">ارتباط با ما</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#0d9488]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Phone className="w-4 h-4 text-[#0d9488]" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">همراه (واتساپ)</p>
                  <p className="text-sm font-medium" dir="ltr">
                    {siteConfig.contact.whatsapp}
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#0d9488]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Phone className="w-4 h-4 text-[#0d9488]" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">تلفن ثابت</p>
                  <p className="text-sm font-medium" dir="ltr">
                    {siteConfig.contact.phone}
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#0d9488]/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4 text-[#0d9488]" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">آدرس</p>
                  <p className="text-sm font-medium leading-relaxed">
                    {siteConfig.location.fullAddress}
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-gray-500">
              {`© ۱۴۰۵ ${siteConfig.name.fullName}. تمامی حقوق محفوظ است.`}
            </p>
            <div className="flex items-center gap-4">
              <Link
                href="/about"
                className="text-xs text-gray-500 hover:text-[#14b8a6] transition-colors"
              >
                قوانین و مقررات
              </Link>
              <Link
                href="/contact"
                className="text-xs text-gray-500 hover:text-[#14b8a6] transition-colors"
              >
                حریم خصوصی
              </Link>
              <Link
                href="/contact"
                className="text-xs text-gray-500 hover:text-[#14b8a6] transition-colors"
              >
                تماس با ما
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
