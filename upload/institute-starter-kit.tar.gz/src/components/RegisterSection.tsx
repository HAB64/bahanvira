'use client';

import { useState } from 'react';
import { CreditCard, CheckCircle, Shield, Phone, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const courses = [
  { id: 'icdl', name: 'ICDL' },
  { id: 'scratch', name: 'Scratch' },
  { id: 'python', name: 'Python' },
  { id: 'consulting', name: 'مشاوره کسب‌وکار' },
];

const benefits = [
  'پرداخت امن با درگاه بانکی',
  'امکان پرداخت قسطی',
  'صدور فاکتور رسمی',
  'گواهینامه پس از اتمام دوره',
];

export default function RegisterSection() {
  const [selectedCourse, setSelectedCourse] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="register" className="py-16 sm:py-20 bg-gradient-to-br from-[#0d9488] via-[#0f766e] to-[#115e59] relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="regGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#regGrid)" />
        </svg>
      </div>

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-full px-4 py-1.5 mb-4 border border-white/20">
            <CreditCard className="w-4 h-4 text-white/90" />
            <span className="text-sm text-white/90 font-medium">ثبت‌نام و پرداخت</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">ثبت‌نام آنلاین</h2>
          <p className="text-white/80 text-base max-w-xl mx-auto leading-relaxed">
            همین الان ثبت‌نام کنید و مسیر یادگیری خود را آغاز کنید
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Benefits */}
          <div className="lg:col-span-2 space-y-4">
            {benefits.map((benefit) => (
              <div key={benefit} className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-xl p-4 border border-white/20">
                <CheckCircle className="w-5 h-5 text-[#5eead4] flex-shrink-0" />
                <span className="text-sm text-white font-medium">{benefit}</span>
              </div>
            ))}

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-5 border border-white/20 mt-6">
              <div className="flex items-center gap-2 mb-3">
                <Shield className="w-5 h-5 text-[#5eead4]" />
                <span className="text-sm font-bold text-white">پرداخت امن</span>
              </div>
              <p className="text-xs text-white/70 leading-relaxed">
                پرداخت از طریق درگاه بانکی زرین‌پال با رمزنگاری SSL انجام می‌شود. اطلاعات مالی شما کاملاً محرمانه خواهد بود.
              </p>
            </div>
          </div>

          {/* Registration Form */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-2xl">
              {submitted ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 rounded-full bg-[#ccfbf1] flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-[#0d9488]" />
                  </div>
                  <h3 className="text-xl font-bold text-[#0f172a] mb-2">درخواست ثبت‌نام دریافت شد!</h3>
                  <p className="text-[#64748b] mb-4">به زودی با شما تماس خواهیم گرفت تا مراحل پرداخت را تکمیل کنید.</p>
                  <Button onClick={() => setSubmitted(false)} variant="outline" className="border-[#0d9488]/30 text-[#0d9488]">
                    ثبت‌نام دوره دیگر
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <h3 className="text-lg font-bold text-[#0f172a] mb-1">فرم ثبت‌نام</h3>

                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">نام و نام خانوادگی</label>
                    <Input required placeholder="نام خود را وارد کنید" className="h-11 bg-gray-50 border-gray-200 focus:border-[#0d9488] focus:ring-[#0d9488]/20" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">شماره موبایل</label>
                    <Input required placeholder="۰۹۱۲XXXXXXX" dir="ltr" className="h-11 bg-gray-50 border-gray-200 focus:border-[#0d9488] focus:ring-[#0d9488]/20 text-right" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">دوره مورد نظر</label>
                    <div className="grid grid-cols-2 gap-2">
                      {courses.map((course) => (
                        <button
                          key={course.id}
                          type="button"
                          onClick={() => setSelectedCourse(course.id)}
                          className={`p-3 rounded-xl text-right transition-all duration-200 border ${
                            selectedCourse === course.id
                              ? 'bg-[#ccfbf1] border-[#0d9488] shadow-md shadow-[#0d9488]/10'
                              : 'bg-gray-50 border-gray-200 hover:border-[#0d9488]/50'
                          }`}
                        >
                          <p className={`text-sm font-bold ${selectedCourse === course.id ? 'text-[#0d9488]' : 'text-[#0f172a]'}`}>
                            {course.name}
                          </p>
                        </button>
                      ))}
                    </div>
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full bg-[#0d9488] hover:bg-[#0f766e] text-white shadow-lg shadow-[#0d9488]/20 h-12 text-base font-bold"
                  >
                    <CreditCard className="w-5 h-5 ml-2" />
                    ثبت‌نام و پرداخت
                  </Button>

                  <p className="text-xs text-[#94a3b8] text-center">
                    با کلیک روی دکمه بالا، به درگاه پرداخت امن هدایت می‌شوید
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
