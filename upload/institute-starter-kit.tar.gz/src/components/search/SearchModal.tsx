'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import {
  Search, X, BookOpen, Compass, Layers, FileText,
  ArrowUpRight, Loader2,
} from 'lucide-react';

interface SearchResult {
  type: 'course' | 'cluster' | 'career' | 'blog';
  title: string;
  description: string;
  href: string;
  icon: string;
  color?: string;
}

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ICON_MAP: Record<string, React.ElementType> = {
  BookOpen, Compass, Layers, FileText,
};

const TYPE_LABELS: Record<string, string> = {
  career: 'مسیر شغلی',
  cluster: 'خوشه مهارتی',
  course: 'دوره آموزشی',
  blog: 'مقاله بلاگ',
};

export default function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    } else {
      setQuery('');
      setResults([]);
      setSelectedIndex(-1);
    }
  }, [isOpen]);

  // Debounced search
  const searchTimer = useRef<NodeJS.Timeout | null>(null);

  const doSearch = useCallback(async (q: string) => {
    if (!q || q.length < 1) {
      setResults([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      setResults(data.results || []);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
    setSelectedIndex(-1);
  }, []);

  const handleInputChange = useCallback((value: string) => {
    setQuery(value);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => doSearch(value), 250);
  }, [doSearch]);

  // Keyboard navigation
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => Math.min(prev + 1, results.length - 1));
      return;
    }

    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => Math.max(prev - 1, -1));
      return;
    }

    if (e.key === 'Enter' && selectedIndex >= 0 && results[selectedIndex]) {
      e.preventDefault();
      router.push(results[selectedIndex].href);
      onClose();
      return;
    }
  }, [results, selectedIndex, router, onClose]);

  // Click outside to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        if (!isOpen) return; // handled by parent
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[15vh]" onClick={onClose}>
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />

      {/* Modal */}
      <div
        className="relative w-full max-w-xl mx-4 bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden"
        onClick={e => e.stopPropagation()}
        role="dialog"
        aria-label="جستجو"
      >
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-100">
          <Search className="w-5 h-5 text-gray-400 flex-shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => handleInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="جستجوی دوره، مسیر شغلی، خوشه مهارتی..."
            className="flex-1 text-sm text-gray-900 placeholder-gray-400 outline-none bg-transparent"
            autoComplete="off"
          />
          {loading && <Loader2 className="w-4 h-4 text-gray-400 animate-spin" />}
          {!loading && query && (
            <button onClick={() => { setQuery(''); setResults([]); }} className="p-1 hover:bg-gray-100 rounded-md">
              <X className="w-4 h-4 text-gray-400" />
            </button>
          )}
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] text-gray-400 bg-gray-100 rounded border border-gray-200">
            ESC
          </kbd>
        </div>

        {/* Results */}
        <div ref={resultsRef} className="max-h-[50vh] overflow-y-auto">
          {results.length > 0 ? (
            <div className="py-2">
              {results.map((result, idx) => {
                const Icon = ICON_MAP[result.icon] || BookOpen;
                const isSelected = idx === selectedIndex;
                return (
                  <button
                    key={`${result.type}-${result.href}-${idx}`}
                    onClick={() => { router.push(result.href); onClose(); }}
                    onMouseEnter={() => setSelectedIndex(idx)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-right transition-colors ${
                      isSelected ? 'bg-[#f0fdfa]' : 'hover:bg-gray-50'
                    }`}
                  >
                    <div
                      className="p-1.5 rounded-lg flex-shrink-0"
                      style={{ backgroundColor: result.color ? `${result.color}15` : '#f3f4f6' }}
                    >
                      <Icon className="w-4 h-4" style={{ color: result.color || '#6b7280' }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-gray-900 truncate">{result.title}</div>
                      <div className="text-xs text-gray-500 truncate">{result.description}</div>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <span className="text-[10px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">
                        {TYPE_LABELS[result.type]}
                      </span>
                      <ArrowUpRight className="w-3 h-3 text-gray-300" />
                    </div>
                  </button>
                );
              })}
            </div>
          ) : query && !loading ? (
            <div className="px-4 py-8 text-center">
              <Search className="w-8 h-8 text-gray-200 mx-auto mb-2" />
              <p className="text-sm text-gray-500">نتیجه‌ای برای «{query}» یافت نشد</p>
            </div>
          ) : !query ? (
            <div className="px-4 py-6 text-center">
              <p className="text-xs text-gray-400">نام دوره، مهارت یا مسیر شغلی را تایپ کنید</p>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
