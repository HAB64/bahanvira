'use client';

import Link from 'next/link';
import {
  Briefcase, Play, CheckCircle, Clock, Users, Star,
  BookOpen, CreditCard, UserCircle, MessageCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const features = [
  { icon: UserCircle, title: 'مشاوره اختصاصی', desc: 'جلسات یک‌به‌یک با دکتر بهان' },
  { icon: MessageCircle, title: 'بازاریابی دیجیتال', desc: 'استراتژی بازاریابی آنلاین' },
  { icon: BookOpen, title: 'مدیریت مالی', desc: 'برنامه‌ریزی و بودجه‌بندی' },
  { icon: Briefcase, title: 'راه‌اندازی کسب‌وکار', desc: 'از ایده تا اجرا' },
];

const reviews = [
  { name: 'حسن میرزایی', rating: 5, text: 'مشاوره دکتر بهان واقعاً مسیر کسب‌وکارم رو عوض کرد. از صفر شروع کردم و الان فروشگاه آنلاین موفق دارم.' },
  { name: 'زهرا صادقی', rating: 5, text: 'ممنون از مشاوره دقیق و کاربردی. خیلی از اشتباهاتم رو فهمیدم و اصلاح کردم.' },
];

export default function CourseConsulting() {
  return (
    <section id="course-consulting" className="py-16 sm:py-20 bg-[#f5f3ff]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12 mb-16">
          <div className="lg:w-1/2">
            <div className="relative aspect-video bg-gradient-to-br from-[#8b5cf6] to-[#6d28d9] rounded-2xl overflow-hidden shadow-xl">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-4 cursor-pointer hover:bg-white/30 transition-colors">
                    <Play className="w-10 h-10 text-white mr-[-2px]" />
                  </div>
                  <p className="text-lg font-medium">ویدئوی معرفی مشاوره کسب‌وکار</p>
                  <p className="text-sm text-white/70 mt-1">۱ دقیقه</p>
                </div>
              </div>
              <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm rounded-lg px-3 py-1.5">
                <span className="text-xs font-bold text-white">مشاوره</span>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2">
            <Badge variant="outline" className="mb-4 px-4 py-1.5 border-[#8b5cf6]/30 text-[#7c3aed] bg-[#ede9fe]/50 text-sm">
              <UserCircle className="w-4 h-4 ml-1.5" />
              با دکتر بهان
            </Badge>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#0f172a] mb-4 leading-relaxed">
              مشاوره کسب‌وکار
            </h2>

            <p className="text-[#475569] text-base leading-relaxed mb-6">
              اگر قصد راه‌اندازی یا توسعه کسب‌وکار خود را دارید، مشاوره اختصاصی با دکتر بهان بهترین نقطه شروع است. از بازاریابی دیجیتال تا مدیریت مالی، مسیر موفقیت شما را طراحی می‌کنیم.
            </p>

            <div className="grid grid-cols-2 gap-3 mb-6">
              {features.map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.title} className="bg-white rounded-xl p-4 shadow-sm">
                    <Icon className="w-5 h-5 text-[#8b5cf6] mb-2" />
                    <p className="text-sm font-bold text-[#0f172a]">{item.title}</p>
                    <p className="text-xs text-[#64748b]">{item.desc}</p>
                  </div>
                );
              })}
            </div>

            <div className="bg-gradient-to-l from-[#ede9fe] to-[#ddd6fe] rounded-2xl p-5 mb-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-[#5b21b6] font-medium">شهریه مشاوره</span>
                <span className="text-xs text-[#5b21b6] bg-white/60 rounded-full px-3 py-1">جلسه‌ای</span>
              </div>
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-bold text-[#0f172a]">۵۰۰,۰۰۰</span>
                <span className="text-sm text-[#5b21b6]">تومان / جلسه</span>
              </div>
              <p className="text-xs text-[#5b21b6] mt-2">اولین جلسه مشاوره رایگان است</p>
            </div>

            <div className="flex items-center gap-3">
              <Button asChild size="lg" className="bg-[#8b5cf6] hover:bg-[#7c3aed] text-white shadow-lg shadow-[#8b5cf6]/20 font-bold flex-1 sm:flex-none">
                <Link href="/register"><CreditCard className="w-5 h-5 ml-2" />رزرو مشاوره</Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="border-[#8b5cf6]/30 text-[#7c3aed] hover:bg-[#ede9fe]/50">
                <a href="https://wa.me/989111277194" target="_blank" rel="noopener noreferrer">مشاوره رایگان</a>
              </Button>
            </div>
          </div>
        </div>

        {/* Reviews */}
        <div>
          <h3 className="text-xl sm:text-2xl font-bold text-[#0f172a] mb-6 flex items-center gap-2">
            <Star className="w-6 h-6 text-[#f59e0b]" />نظرات مراجعین
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {reviews.map((review, index) => (
              <div key={index} className="bg-white rounded-2xl p-5 sm:p-6 shadow-sm">
                <div className="flex items-center gap-1 mb-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={`w-4 h-4 ${i < review.rating ? 'text-[#f59e0b] fill-[#f59e0b]' : 'text-gray-300'}`} />
                  ))}
                </div>
                <p className="text-sm text-[#475569] leading-relaxed mb-4">{review.text}</p>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#8b5cf6] flex items-center justify-center">
                    <span className="text-xs font-bold text-white">{review.name[0]}</span>
                  </div>
                  <span className="text-sm font-medium text-[#0f172a]">{review.name}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
