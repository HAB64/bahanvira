'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Menu, X, ChevronDown, LogIn, UserPlus, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { siteConfig } from '@/config/site';

const navLinks = [
  { label: 'صفحه اصلی', href: '/' },
  { label: 'درباره ما', href: '/about' },
  {
    label: 'دوره‌ها',
    href: '/courses',
    submenu: [
      { label: 'خوشه خدمات', href: '/courses?clusterId=services', isCluster: true },
      { label: '  فن آوری اطلاعات', href: '/courses?cluster=it' },
      { label: '  امور مالی و بازرگانی', href: '/courses?cluster=finance' },
      { label: '  خدمات آموزشی', href: '/courses?cluster=educational-services' },
      { label: '  خدمات حقوقی', href: '/courses?cluster=legal-services' },
      { label: 'خوشه صنعت', href: '/courses?clusterId=industry', isCluster: true },
      { label: '  معماری', href: '/courses?cluster=architecture' },
      { label: '  ساختمان', href: '/courses?cluster=building' },
      { label: 'خوشه فرهنگ و هنر', href: '/courses?clusterId=culture-art', isCluster: true },
      { label: '  صنایع پوشاک', href: '/courses?cluster=clothing' },
      { label: '  هنرهای تجسمی', href: '/courses?cluster=visual-arts' },
      { label: 'همه دوره‌ها', href: '/courses', divider: true },
    ],
  },
  { label: 'خدمات', href: '/consulting' },
  { label: 'وبلاگ', href: '/blog' },
  { label: 'تماس', href: '/contact' },
];

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [productsOpen, setProductsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Body scroll lock when mobile menu opens
  useEffect(() => {
    if (mobileMenuOpen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileMenuOpen]);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#0a1628]/95 backdrop-blur-xl shadow-lg shadow-black/20 border-b border-white/5'
          : 'bg-[#0a1628]/80 backdrop-blur-md border-b border-white/5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Right side: TVTO badge + Logo */}
          <div className="flex items-center gap-3 flex-shrink-0">
            {/* TVTO badge */}
            <Image
              src="/images/tvto-badge.png"
              alt="مجوز رسمی سازمان فنی و حرفه‌ای"
              width={40}
              height={40}
              className="hidden sm:block w-9 h-9 object-contain rounded-lg"
              priority
            />
            <Link href="/" className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full overflow-hidden shadow-md ring-2 ring-amber-400/30">
                <Image
                  src={siteConfig.assets.logo}
                  alt={`لوگو ${siteConfig.name.fa}`}
                  width={44}
                  height={44}
                  className="object-cover w-full h-full"
                  priority
                />
              </div>
              <div className="flex flex-col">
                <span className="text-lg sm:text-xl font-black text-white leading-tight">
                  {siteConfig.name.fa}
                </span>
                <span className="text-[10px] sm:text-xs text-amber-400 font-semibold leading-tight">
                  {siteConfig.institute.subtitle}
                </span>
              </div>
            </Link>
          </div>

          {/* Center: Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) =>
              link.submenu ? (
                <div
                  key={link.href}
                  className="relative"
                  onMouseEnter={() => setProductsOpen(true)}
                  onMouseLeave={() => setProductsOpen(false)}
                >
                  <button
                    className="flex items-center gap-1 px-4 py-2 text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 rounded-lg transition-all duration-200"
                    aria-expanded={productsOpen}
                    aria-haspopup="true"
                  >
                    {link.label}
                    <ChevronDown className={`w-3.5 h-3.5 transition-transform ${productsOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {productsOpen && (
                    <div className="absolute top-full right-0 mt-1 w-56 bg-[#0d1f3c]/95 backdrop-blur-xl rounded-xl shadow-xl border border-white/10 py-2 z-50 max-h-[80vh] overflow-y-auto">
                      {link.submenu.map((sub, idx) => (
                        'isCluster' in sub && sub.isCluster ? (
                          <div key={sub.href} className="px-4 pt-3 pb-1 text-xs font-bold text-amber-400 tracking-wide">
                            {sub.label}
                          </div>
                        ) : 'divider' in sub && sub.divider ? (
                          <div key={sub.href} className="my-2 border-t border-white/10" />
                        ) : (
                          <Link
                            key={sub.href + idx}
                            href={sub.href}
                            className="block px-6 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/5 transition-colors"
                          >
                            {sub.label}
                          </Link>
                        )
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <Link
                  key={link.href}
                  href={link.href}
                  className="px-4 py-2 text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 rounded-lg transition-all duration-200"
                >
                  {link.label}
                </Link>
              )
            )}
          </nav>

          {/* Left side: Phone & Auth buttons */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href={siteConfig.contact.phoneHref}
              className="flex items-center gap-2 text-sm text-amber-400 hover:text-amber-300 transition-colors"
              dir="ltr"
            >
              <Phone className="w-4 h-4" />
              <span className="font-semibold">{siteConfig.contact.phone}</span>
            </a>
            <a
              href={siteConfig.contact.mobiles[0].href}
              className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-gray-200 transition-colors"
              dir="ltr"
            >
              <span>{siteConfig.contact.mobiles[0].display}</span>
            </a>
            <div className="w-px h-5 bg-white/10" />
            <Link href="/portal/login">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-300 hover:text-white hover:bg-white/10 gap-1.5 text-sm"
              >
                <LogIn className="w-4 h-4" />
                ورود
              </Button>
            </Link>
            <Link href="/register">
              <Button
                size="sm"
                className="bg-[#0d9488] hover:bg-[#0f766e] text-white gap-1.5 text-sm rounded-lg px-5 shadow-lg shadow-[#0d9488]/20"
              >
                <UserPlus className="w-4 h-4" />
                ثبت نام
              </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            className="lg:hidden p-2 text-white hover:bg-white/10 rounded-lg"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? 'بستن منو' : 'باز کردن منو'}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0a1628]/98 backdrop-blur-xl border-t border-white/10 shadow-lg max-h-[80vh] overflow-y-auto">
          <div className="px-4 py-4 space-y-1">
            {navLinks.map((link) => (
              <div key={link.href}>
                <Link
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-4 py-3 text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                >
                  {link.label}
                </Link>
                {link.submenu && (
                  <div className="pr-6 space-y-0.5 mt-1">
                    {link.submenu.map((sub, idx) => (
                      'isCluster' in sub && sub.isCluster ? (
                        <div key={sub.href} className="px-3 pt-3 pb-1 text-xs font-bold text-amber-400">
                          {sub.label}
                        </div>
                      ) : 'divider' in sub && sub.divider ? (
                        <div key={sub.href} className="my-2 border-t border-white/10" />
                      ) : (
                        <Link
                          key={sub.href + idx}
                          href={sub.href}
                          onClick={() => setMobileMenuOpen(false)}
                          className="block px-6 py-2 text-sm text-gray-400 hover:text-white transition-colors"
                        >
                          {sub.label}
                        </Link>
                      )
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div className="pt-3 border-t border-white/10 space-y-3">
              {/* Phone numbers in mobile menu */}
              <div className="space-y-2">
                <a
                  href={siteConfig.contact.phoneHref}
                  className="flex items-center gap-2 text-sm text-amber-400 hover:text-amber-300 transition-colors"
                  dir="ltr"
                >
                  <Phone className="w-4 h-4" />
                  <span className="font-semibold">{siteConfig.contact.phone}</span>
                </a>
                <a
                  href={siteConfig.contact.mobiles[0].href}
                  className="flex items-center gap-2 text-sm text-gray-400 hover:text-gray-200 transition-colors"
                  dir="ltr"
                >
                  <span>{siteConfig.contact.mobiles[0].display}</span>
                </a>
                <a
                  href={siteConfig.contact.mobiles[1].href}
                  className="flex items-center gap-2 text-sm text-gray-400 hover:text-gray-200 transition-colors"
                  dir="ltr"
                >
                  <span>{siteConfig.contact.mobiles[1].display}</span>
                </a>
              </div>
              <div className="flex gap-2">
                <Link href="/portal/login" className="flex-1">
                  <Button variant="outline" className="w-full text-sm gap-1.5 border-white/10 text-gray-300 hover:bg-white/10 hover:text-white">
                    <LogIn className="w-4 h-4" />
                    ورود
                  </Button>
                </Link>
                <Link href="/register" className="flex-1">
                  <Button className="w-full bg-[#0d9488] hover:bg-[#0f766e] text-white text-sm gap-1.5 shadow-lg shadow-[#0d9488]/20">
                    <UserPlus className="w-4 h-4" />
                    ثبت نام
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
