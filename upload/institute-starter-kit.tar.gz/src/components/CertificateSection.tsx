'use client';

import { Award, ArrowLeft, Shield, BookOpen, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function CertificateSection() {
  return (
    <section className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-10 lg:gap-16">
          {/* Text Content */}
          <div className="flex-1 text-center lg:text-right">
            <div className="inline-flex items-center gap-2 bg-[#e6f9ef] text-[#00a650] rounded-full px-4 py-1.5 mb-4">
              <Award className="w-4 h-4" />
              <span className="text-sm font-medium">گواهینامه رسمی</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#1a1a2e] mb-4 leading-relaxed">
              یادگیری و گواهینامه
            </h2>
            <p className="text-base sm:text-lg text-gray-500 mb-3 leading-relaxed">
              از یادگیری تا دریافت گواهینامه رسمی دوزبانه پایان دوره فرادرس
            </p>
            <p className="text-sm text-gray-400 mb-8 leading-relaxed max-w-lg mx-auto lg:mx-0">
              با کسب نمره قبولی در آزمون‌ها، گواهینامه رسمی پایان دوره به دو زبان فارسی و انگلیسی به شما اعطا می‌شود. علاوه بر دانلود و ذخیره، امکان اشتراک‌گذاری مستقیم گواهینامه در لینکدین نیز فراهم است.
            </p>

            {/* Features */}
            <div className="flex flex-col gap-3 mb-8 items-center lg:items-start">
              {[
                { icon: BookOpen, text: 'گواهینامه دوزبانه فارسی و انگلیسی' },
                { icon: Shield, text: 'امکان اشتراک‌گذاری در لینکدین' },
                { icon: CheckCircle, text: 'آزمون‌های ارزیابی پایان دوره' },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.text} className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#e6f9ef] flex items-center justify-center flex-shrink-0">
                      <Icon className="w-4 h-4 text-[#00a650]" />
                    </div>
                    <span className="text-sm text-gray-600">{item.text}</span>
                  </div>
                );
              })}
            </div>

            <Button
              size="lg"
              className="bg-[#00a650] hover:bg-[#008c44] text-white text-base px-8 py-6 rounded-xl shadow-md shadow-[#00a650]/20 hover:shadow-lg transition-all font-bold"
            >
              دیدن آموزش‌ها
              <ArrowLeft className="h-5 w-5 mr-2" />
            </Button>
          </div>

          {/* Certificate Mockup */}
          <div className="flex-1 w-full max-w-lg">
            <div className="relative bg-white rounded-2xl shadow-2xl border-2 border-[#00a650]/20 p-6 sm:p-8">
              {/* Certificate border decoration */}
              <div className="absolute inset-3 border-2 border-dashed border-[#00a650]/20 rounded-xl pointer-events-none" />

              <div className="relative text-center">
                {/* Logo area */}
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Award className="w-8 h-8 text-[#00a650]" />
                  <span className="text-lg font-bold text-[#1a1a2e]">فرادرس</span>
                </div>

                {/* Title */}
                <h3 className="text-xl sm:text-2xl font-bold text-[#1a1a2e] mb-2">
                  گواهینامه پایان دوره
                </h3>
                <p className="text-sm text-gray-400 mb-6">Certificate of Completion</p>

                {/* Name */}
                <div className="bg-[#e6f9ef] rounded-lg p-4 mb-6">
                  <p className="text-sm text-gray-500 mb-1">اعطا شده به</p>
                  <p className="text-lg font-bold text-[#1a1a2e]">نام دارنده گواهینامه</p>
                </div>

                {/* Course name */}
                <p className="text-sm text-gray-500 mb-1">برای گذراندن دوره</p>
                <p className="text-base font-semibold text-[#1a1a2e] mb-6">
                  عنوان دوره آموزشی
                </p>

                {/* Date and signature */}
                <div className="flex items-center justify-between border-t border-gray-100 pt-4">
                  <div className="text-right">
                    <p className="text-xs text-gray-400">تاریخ صدور</p>
                    <p className="text-sm font-medium text-[#1a1a2e]">۱۴۰۴/۰۳/۱۵</p>
                  </div>
                  <div className="w-16 h-16 rounded-full bg-[#00a650]/10 flex items-center justify-center">
                    <Shield className="w-8 h-8 text-[#00a650]" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs text-gray-400">شماره گواهینامه</p>
                    <p className="text-sm font-medium text-[#1a1a2e]">FR-۱۲۳۴۵</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
