'use client';

import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

/* ─── Fix default marker icons in Next.js ─── */
const DefaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});
L.Marker.prototype.options.icon = DefaultIcon;

interface MapLead {
  id: string;
  name: string;
  phone: string;
  latitude: number;
  longitude: number;
  geoCity: string | null;
  stage: string;
  cluster: string;
  segment: string;
  score: number;
}

const STAGE_LABELS: Record<string, string> = {
  NEW: 'جدید',
  CONTACTED: 'تماس شده',
  INTERESTED: 'علاقه‌مند',
  ENROLLED: 'ثبت‌نام شده',
  REJECTED: 'رد شده',
  ARCHIVED: 'بایگانی',
};

const STAGE_COLORS: Record<string, string> = {
  NEW: '#6b7280',
  CONTACTED: '#3b82f6',
  INTERESTED: '#f59e0b',
  ENROLLED: '#10b981',
  REJECTED: '#ef4444',
  ARCHIVED: '#9ca3af',
};

interface CustomerMapProps {
  leads: MapLead[];
  center?: [number, number];
  zoom?: number;
}

export default function CustomerMap({ leads, center = [36.6350, 52.5500], zoom = 10 }: CustomerMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current) return;

    // Initialize map only once
    if (!mapInstanceRef.current) {
      mapInstanceRef.current = L.map(mapRef.current, {
        center,
        zoom,
        scrollWheelZoom: true,
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19,
      }).addTo(mapInstanceRef.current);
    }

    const map = mapInstanceRef.current;

    // Clear existing markers
    map.eachLayer((layer) => {
      if (layer instanceof L.Marker || layer instanceof L.CircleMarker) {
        map.removeLayer(layer);
      }
    });

    // Add leads as markers
    const validLeads = leads.filter(l => l.latitude && l.longitude);

    if (validLeads.length === 0) return;

    const markers: L.Marker[] = [];

    validLeads.forEach((lead) => {
      const color = STAGE_COLORS[lead.stage] || '#6b7280';
      const stageLabel = STAGE_LABELS[lead.stage] || lead.stage;

      // Use circle marker for better performance with many points
      const marker = L.circleMarker([lead.latitude, lead.longitude], {
        radius: 8,
        fillColor: color,
        color: '#fff',
        weight: 2,
        opacity: 1,
        fillOpacity: 0.8,
      }).addTo(map);

      marker.bindPopup(`
        <div style="direction:rtl; text-align:right; font-family: Vazirmatn, sans-serif; min-width:180px">
          <div style="font-weight:bold; font-size:14px; margin-bottom:4px; color:#1f2937">${lead.name}</div>
          <div style="font-size:12px; color:#6b7280; margin-bottom:2px">تلفن: ${lead.phone}</div>
          ${lead.geoCity ? `<div style="font-size:12px; color:#6b7280; margin-bottom:2px">شهر: ${lead.geoCity}</div>` : ''}
          <div style="margin-top:6px; display:inline-block; padding:2px 8px; border-radius:9999px; font-size:11px; background:${color}20; color:${color}; font-weight:600">${stageLabel}</div>
          ${lead.segment ? `<div style="margin-top:4px; font-size:11px; color:#8b5cf6">بخش: ${lead.segment}</div>` : ''}
          ${lead.cluster ? `<div style="font-size:11px; color:#0d9488">خوشه: ${lead.cluster}</div>` : ''}
          <div style="font-size:11px; color:#6b7280; margin-top:4px">امتیاز: ${lead.score}</div>
        </div>
      `, { maxWidth: 280 });

      markers.push(marker);
    });

    // Fit bounds to show all markers
    if (markers.length > 0) {
      const group = L.featureGroup(markers);
      map.fitBounds(group.getBounds().pad(0.1));
    }

    return () => {
      // Cleanup on unmount
    };
  }, [leads, center, zoom]);

  // Cleanup map on component unmount
  useEffect(() => {
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  return (
    <div
      ref={mapRef}
      className="w-full rounded-xl overflow-hidden border border-gray-200"
      style={{ height: '450px' }}
    />
  );
}
