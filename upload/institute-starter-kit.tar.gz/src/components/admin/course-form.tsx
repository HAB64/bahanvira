'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2, ArrowRight, Save } from 'lucide-react';
import { toast } from 'sonner';

interface ModuleData {
  title: string;
  lessons: string;
  duration: string;
  type: string;
  order: number;
}

interface ReviewData {
  name: string;
  role: string;
  rating: number;
  text: string;
  date: string;
}

interface CourseFormProps {
  initialData?: {
    id?: string;
    slug: string;
    title: string;
    subtitle: string;
    cluster: string;
    clusterLabel: string;
    level: string;
    levelOrder: number;
    duration: string;
    sessions: number;
    description: string;
    highlights: string;
    icon: string;
    color: string;
    colorLight: string;
    colorDark: string;
    prerequisites: string;
    certificate: string;
    targetAudience: string;
    learningOutcomes: string;
    published: boolean;
    modules: ModuleData[];
    reviews: ReviewData[];
  };
  isEdit?: boolean;
}

const emptyModule: ModuleData = {
  title: '',
  lessons: '[]',
  duration: '',
  type: 'theory',
  order: 1,
};

const emptyReview: ReviewData = {
  name: '',
  role: '',
  rating: 5,
  text: '',
  date: '',
};

export default function CourseForm({ initialData, isEdit }: CourseFormProps) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    slug: initialData?.slug || '',
    title: initialData?.title || '',
    subtitle: initialData?.subtitle || '',
    cluster: initialData?.cluster || 'it',
    clusterLabel: initialData?.clusterLabel || 'فناوری اطلاعات',
    level: initialData?.level || 'پایه',
    levelOrder: initialData?.levelOrder || 1,
    duration: initialData?.duration || '',
    sessions: initialData?.sessions || 0,
    description: initialData?.description || '',
    highlights: initialData?.highlights || '[]',
    icon: initialData?.icon || 'BookOpen',
    color: initialData?.color || '#0d9488',
    colorLight: initialData?.colorLight || '#ccfbf1',
    colorDark: initialData?.colorDark || '#0f766e',
    prerequisites: initialData?.prerequisites || '[]',
    certificate: initialData?.certificate || '',
    targetAudience: initialData?.targetAudience || '',
    learningOutcomes: initialData?.learningOutcomes || '[]',
    published: initialData?.published ?? true,
  });

  const [modules, setModules] = useState<ModuleData[]>(
    initialData?.modules || [{ ...emptyModule }]
  );
  const [reviews, setReviews] = useState<ReviewData[]>(
    initialData?.reviews || []
  );

  const updateForm = (field: string, value: string | number | boolean) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleClusterChange = (cluster: string) => {
    const labels: Record<string, string> = {
      'it': 'فناوری اطلاعات',
      'ai': 'هوش مصنوعی و علوم داده',
      financial: 'بازارهای مالی',
      management: 'مدیریت و کارآفرینی',
      creative: 'صنایع خلاق و هنر کاربردی',
    };
    updateForm('cluster', cluster);
    updateForm('clusterLabel', labels[cluster] || '');
  };

  const handleLevelChange = (level: string) => {
    const orders: Record<string, number> = { 'پایه': 1, 'متوسط': 2, 'پیشرفته': 3 };
    updateForm('level', level);
    updateForm('levelOrder', orders[level] || 1);
  };

  const addModule = () => {
    setModules([...modules, { ...emptyModule, order: modules.length + 1 }]);
  };

  const removeModule = (index: number) => {
    setModules(modules.filter((_, i) => i !== index));
  };

  const updateModule = (index: number, field: string, value: string | number) => {
    const updated = [...modules];
    updated[index] = { ...updated[index], [field]: value };
    setModules(updated);
  };

  const addReview = () => {
    setReviews([...reviews, { ...emptyReview }]);
  };

  const removeReview = (index: number) => {
    setReviews(reviews.filter((_, i) => i !== index));
  };

  const updateReview = (index: number, field: string, value: string | number) => {
    const updated = [...reviews];
    updated[index] = { ...updated[index], [field]: value };
    setReviews(updated);
  };

  const parseJsonArray = (str: string): string[] => {
    try {
      return JSON.parse(str);
    } catch {
      return [];
    }
  };

  const handleSave = async () => {
    if (!form.slug || !form.title) {
      toast.error('لطفاً فیلدهای الزامی را پر کنید');
      return;
    }

    setSaving(true);
    try {
      const url = isEdit && initialData?.id
        ? `/api/admin/courses/${initialData.id}`
        : '/api/admin/courses';
      const method = isEdit ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          modules: modules.filter((m) => m.title),
          reviews: reviews.filter((r) => r.name),
        }),
      });

      if (res.ok) {
        toast.success(isEdit ? 'دوره بروزرسانی شد' : 'دوره ایجاد شد');
        router.push('/admin/courses');
      } else {
        const data = await res.json();
        toast.error(data.error || 'خطا در ذخیره دوره');
      }
    } catch {
      toast.error('خطا در ذخیره دوره');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.push('/admin/courses')}>
            <ArrowRight className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isEdit ? 'ویرایش دوره' : 'افزودن دوره جدید'}
          </h1>
        </div>
        <Button
          onClick={handleSave}
          disabled={saving}
          className="bg-teal-600 hover:bg-teal-700 gap-2"
        >
          <Save className="h-4 w-4" />
          {saving ? 'در حال ذخیره...' : 'ذخیره'}
        </Button>
      </div>

      {/* Basic Info */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">اطلاعات پایه</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>عنوان *</Label>
              <Input
                value={form.title}
                onChange={(e) => updateForm('title', e.target.value)}
                placeholder="عنوان دوره"
              />
            </div>
            <div className="space-y-2">
              <Label>نامک (slug) *</Label>
              <Input
                value={form.slug}
                onChange={(e) => updateForm('slug', e.target.value)}
                placeholder="مثال: icdl"
                dir="ltr"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>زیرعنوان</Label>
            <Input
              value={form.subtitle}
              onChange={(e) => updateForm('subtitle', e.target.value)}
              placeholder="زیرعنوان دوره"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>خوشه شایستگی</Label>
              <Select value={form.cluster} onValueChange={handleClusterChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="it">فناوری اطلاعات</SelectItem>
                  <SelectItem value="ai">هوش مصنوعی و علوم داده</SelectItem>
                  <SelectItem value="financial">بازارهای مالی</SelectItem>
                  <SelectItem value="management">مدیریت و کارآفرینی</SelectItem>
                  <SelectItem value="creative">صنایع خلاق</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>سطح</Label>
              <Select value={form.level} onValueChange={handleLevelChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="پایه">پایه</SelectItem>
                  <SelectItem value="متوسط">متوسط</SelectItem>
                  <SelectItem value="پیشرفته">پیشرفته</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>مدت دوره</Label>
              <Input
                value={form.duration}
                onChange={(e) => updateForm('duration', e.target.value)}
                placeholder="مثال: ۳ ماه"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>تعداد جلسات</Label>
              <Input
                type="number"
                value={form.sessions}
                onChange={(e) => updateForm('sessions', parseInt(e.target.value) || 0)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>توضیحات</Label>
            <Textarea
              value={form.description}
              onChange={(e) => updateForm('description', e.target.value)}
              rows={4}
              placeholder="توضیحات کامل دوره"
            />
          </div>

          <div className="flex items-center gap-3">
            <Switch
              checked={form.published}
              onCheckedChange={(checked) => updateForm('published', checked)}
            />
            <Label>منتشر شده</Label>
          </div>
        </CardContent>
      </Card>

      {/* Highlights & Details */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">جزئیات دوره</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>نکات برجسته (هر خط یک نکته)</Label>
            <Textarea
              value={parseJsonArray(form.highlights).join('\n')}
              onChange={(e) =>
                updateForm(
                  'highlights',
                  JSON.stringify(e.target.value.split('\n').filter(Boolean))
                )
              }
              rows={5}
              placeholder="هر خط یک نکته بنویسید"
            />
          </div>

          <div className="space-y-2">
            <Label>پیش‌نیازها (هر خط یک پیش‌نیاز)</Label>
            <Textarea
              value={parseJsonArray(form.prerequisites).join('\n')}
              onChange={(e) =>
                updateForm(
                  'prerequisites',
                  JSON.stringify(e.target.value.split('\n').filter(Boolean))
                )
              }
              rows={3}
              placeholder="هر خط یک پیش‌نیاز"
            />
          </div>

          <div className="space-y-2">
            <Label>نتایج یادگیری (هر خط یک نتیجه)</Label>
            <Textarea
              value={parseJsonArray(form.learningOutcomes).join('\n')}
              onChange={(e) =>
                updateForm(
                  'learningOutcomes',
                  JSON.stringify(e.target.value.split('\n').filter(Boolean))
                )
              }
              rows={4}
              placeholder="هر خط یک نتیجه یادگیری"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>گواهینامه</Label>
              <Input
                value={form.certificate}
                onChange={(e) => updateForm('certificate', e.target.value)}
                placeholder="نوع گواهینامه"
              />
            </div>
            <div className="space-y-2">
              <Label>مخاطبان هدف</Label>
              <Input
                value={form.targetAudience}
                onChange={(e) => updateForm('targetAudience', e.target.value)}
                placeholder="مخاطبان هدف دوره"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>نام آیکون</Label>
              <Input
                value={form.icon}
                onChange={(e) => updateForm('icon', e.target.value)}
                placeholder="مثال: Monitor"
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <Label>رنگ اصلی</Label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={form.color}
                  onChange={(e) => updateForm('color', e.target.value)}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={form.color}
                  onChange={(e) => updateForm('color', e.target.value)}
                  dir="ltr"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>رنگ روشن</Label>
              <Input
                value={form.colorLight}
                onChange={(e) => updateForm('colorLight', e.target.value)}
                dir="ltr"
              />
            </div>
            <div className="space-y-2">
              <Label>رنگ تیره</Label>
              <Input
                value={form.colorDark}
                onChange={(e) => updateForm('colorDark', e.target.value)}
                dir="ltr"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Modules */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">ماژول‌های آموزشی</CardTitle>
            <Button variant="outline" size="sm" onClick={addModule} className="gap-1">
              <Plus className="h-3 w-3" />
              افزودن ماژول
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {modules.map((mod, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">
                  ماژول {index + 1}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeModule(index)}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">عنوان ماژول</Label>
                  <Input
                    value={mod.title}
                    onChange={(e) => updateModule(index, 'title', e.target.value)}
                    placeholder="عنوان ماژول"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">مدت</Label>
                  <Input
                    value={mod.duration}
                    onChange={(e) => updateModule(index, 'duration', e.target.value)}
                    placeholder="مثال: ۴ جلسه"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">نوع</Label>
                  <Select
                    value={mod.type}
                    onValueChange={(val) => updateModule(index, 'type', val)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="theory">نظری</SelectItem>
                      <SelectItem value="practical">عملی</SelectItem>
                      <SelectItem value="project">پروژه</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">جلسات (هر خط یک جلسه)</Label>
                  <Textarea
                    value={parseJsonArray(mod.lessons).join('\n')}
                    onChange={(e) =>
                      updateModule(
                        index,
                        'lessons',
                        JSON.stringify(e.target.value.split('\n').filter(Boolean))
                      )
                    }
                    rows={3}
                    placeholder="هر خط یک جلسه"
                  />
                </div>
              </div>
              {index < modules.length - 1 && <Separator />}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Reviews */}
      <Card className="border-0 shadow-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">نظرات کارآموزان</CardTitle>
            <Button variant="outline" size="sm" onClick={addReview} className="gap-1">
              <Plus className="h-3 w-3" />
              افزودن نظر
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {reviews.map((rev, index) => (
            <div key={index} className="p-4 bg-gray-50 rounded-lg space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">
                  نظر {index + 1}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeReview(index)}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">نام</Label>
                  <Input
                    value={rev.name}
                    onChange={(e) => updateReview(index, 'name', e.target.value)}
                    placeholder="نام کارآموز"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">نقش</Label>
                  <Input
                    value={rev.role}
                    onChange={(e) => updateReview(index, 'role', e.target.value)}
                    placeholder="مثال: کارشناس نرم‌افزار"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">امتیاز (۱-۵)</Label>
                  <Input
                    type="number"
                    min={1}
                    max={5}
                    value={rev.rating}
                    onChange={(e) =>
                      updateReview(index, 'rating', parseInt(e.target.value) || 5)
                    }
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">تاریخ</Label>
                  <Input
                    value={rev.date}
                    onChange={(e) => updateReview(index, 'date', e.target.value)}
                    placeholder="مثال: ۱۴۰۴/۰۸"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">متن نظر</Label>
                <Textarea
                  value={rev.text}
                  onChange={(e) => updateReview(index, 'text', e.target.value)}
                  rows={2}
                  placeholder="متن نظر"
                />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Save button at bottom */}
      <div className="flex justify-end gap-3 pb-6">
        <Button variant="outline" onClick={() => router.push('/admin/courses')}>
          انصراف
        </Button>
        <Button
          onClick={handleSave}
          disabled={saving}
          className="bg-teal-600 hover:bg-teal-700 gap-2"
        >
          <Save className="h-4 w-4" />
          {saving ? 'در حال ذخیره...' : 'ذخیره دوره'}
        </Button>
      </div>
    </div>
  );
}
