'use client';

import { useState, useCallback, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Phone,
  UserPlus,
  Star,
  FileText,
  MessageSquare,
  TrendingUp,
  XCircle,
  GripVertical,
  Clock,
  Calendar,
  Loader2,
  AlertTriangle,
  Users,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface LeadTag {
  id: string;
  name: string;
  color: string;
}

interface TagOnLead {
  tagId: string;
  tag: LeadTag;
}

interface ActivityLog {
  id: string;
  type: string;
  content: string;
  followUpAt: string | null;
  createdAt: string;
}

interface Payment {
  id: string;
  leadId: string;
  amount: number;
  type: string;
  status: string;
  dueDate: string | null;
  paidAt: string | null;
  note: string;
  createdAt: string;
  updatedAt: string;
}

interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  course: string;
  cluster: string;
  source: string;
  stage: string;
  score: number;
  assignedTo: string;
  message: string;
  goal: string;
  level: string;
  interest: string;
  company: string;
  serviceType: string;
  lastContactedAt: string | null;
  createdAt: string;
  tags?: TagOnLead[];
  activityLogs?: ActivityLog[];
  payments?: Payment[];
  _count?: { activityLogs: number; payments: number };
}

interface KanbanBoardProps {
  leads: Lead[];
  onLeadClick: (lead: Lead) => void;
  onStageChange: (leadId: string, newStage: string) => Promise<boolean>;
  selectedLeadIds?: Set<string>;
  onToggleLeadSelection?: (leadId: string) => void;
}

/* ─────────── Kanban Stage Definitions ─────────── */

const KANBAN_STAGES = [
  'NEW',
  'CONTACTED',
  'QUALIFIED',
  'PROPOSAL',
  'NEGOTIATION',
  'ENROLLED',
  'LOST',
] as const;

interface KanbanStageMeta {
  label: string;
  color: string;
  bg: string;
  borderColor: string;
  headerBg: string;
  dotColor: string;
  icon: typeof UserPlus;
}

const KANBAN_STAGE_META: Record<string, KanbanStageMeta> = {
  NEW: {
    label: 'جدید',
    color: 'text-blue-700',
    bg: 'bg-blue-50',
    borderColor: 'border-blue-200',
    headerBg: 'bg-blue-100',
    dotColor: 'bg-blue-500',
    icon: UserPlus,
  },
  CONTACTED: {
    label: 'تماس‌شده',
    color: 'text-cyan-700',
    bg: 'bg-cyan-50',
    borderColor: 'border-cyan-200',
    headerBg: 'bg-cyan-100',
    dotColor: 'bg-cyan-500',
    icon: Phone,
  },
  QUALIFIED: {
    label: 'واجدشرایط',
    color: 'text-green-700',
    bg: 'bg-green-50',
    borderColor: 'border-green-200',
    headerBg: 'bg-green-100',
    dotColor: 'bg-green-500',
    icon: Star,
  },
  PROPOSAL: {
    label: 'پیشنهاد',
    color: 'text-yellow-700',
    bg: 'bg-yellow-50',
    borderColor: 'border-yellow-200',
    headerBg: 'bg-yellow-100',
    dotColor: 'bg-yellow-500',
    icon: FileText,
  },
  NEGOTIATION: {
    label: 'مذاکره',
    color: 'text-orange-700',
    bg: 'bg-orange-50',
    borderColor: 'border-orange-200',
    headerBg: 'bg-orange-100',
    dotColor: 'bg-orange-500',
    icon: MessageSquare,
  },
  ENROLLED: {
    label: 'ثبت‌نام‌شده',
    color: 'text-emerald-700',
    bg: 'bg-emerald-50',
    borderColor: 'border-emerald-200',
    headerBg: 'bg-emerald-100',
    dotColor: 'bg-emerald-500',
    icon: TrendingUp,
  },
  LOST: {
    label: 'ازدست‌رفته',
    color: 'text-red-700',
    bg: 'bg-red-50',
    borderColor: 'border-red-200',
    headerBg: 'bg-red-100',
    dotColor: 'bg-red-500',
    icon: XCircle,
  },
};

/* ─────────── Source Map ─────────── */

const SOURCE_MAP: Record<string, string> = {
  'hero-form': 'فرم اصلی',
  'career-quiz': 'تست شغلی',
  'consulting-form': 'مشاوره',
  webhook: 'وب‌هوک',
  website: 'وبسایت',
  referral: 'معرفی',
};

/* ─────────── Helpers ─────────── */

function scoreColor(score: number) {
  if (score >= 70) return 'bg-emerald-100 text-emerald-700 border-emerald-200';
  if (score >= 40) return 'bg-amber-100 text-amber-700 border-amber-200';
  return 'bg-red-100 text-red-700 border-red-200';
}

function maskPhone(phone: string) {
  if (phone.length !== 11) return phone;
  return phone.slice(0, 4) + '***' + phone.slice(7);
}

/**
 * Map existing stages to Kanban stages for display.
 * Old stages: INTERESTED → QUALIFIED, REJECTED → LOST, ARCHIVED → LOST
 */
function mapStageToKanban(stage: string): string {
  const mapping: Record<string, string> = {
    INTERESTED: 'QUALIFIED',
    REJECTED: 'LOST',
    ARCHIVED: 'LOST',
  };
  return mapping[stage] || stage;
}

function timeAgo(dateStr: string) {
  const now = new Date();
  const date = new Date(dateStr);
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (minutes < 1) return 'همین الان';
  if (minutes < 60) return `${toPersianNumber(minutes)} دقیقه پیش`;
  if (hours < 24) return `${toPersianNumber(hours)} ساعت پیش`;
  if (days < 30) return `${toPersianNumber(days)} روز پیش`;
  return new Intl.DateTimeFormat('fa-IR', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(date);
}

function getNextFollowUp(lead: Lead): string | null {
  if (!lead.activityLogs || lead.activityLogs.length === 0) return null;
  const now = new Date();
  const upcoming = lead.activityLogs
    .filter((a) => a.followUpAt && new Date(a.followUpAt) > now)
    .sort(
      (a, b) =>
        new Date(a.followUpAt!).getTime() - new Date(b.followUpAt!).getTime()
    );
  if (upcoming.length > 0) return upcoming[0].followUpAt!;

  // Check for overdue follow-ups
  const overdue = lead.activityLogs
    .filter((a) => a.followUpAt && new Date(a.followUpAt) <= now)
    .sort(
      (a, b) =>
        new Date(a.followUpAt!).getTime() - new Date(b.followUpAt!).getTime()
    );
  if (overdue.length > 0) return overdue[0].followUpAt!;

  return null;
}

function isFollowUpOverdue(dateStr: string): boolean {
  return new Date(dateStr) < new Date();
}

/* ─────────── Kanban Lead Card ─────────── */

function KanbanLeadCard({
  lead,
  onLeadClick,
  isDragging,
  isSelected,
  onToggleSelection,
}: {
  lead: Lead;
  onLeadClick: (lead: Lead) => void;
  isDragging: boolean;
  isSelected?: boolean;
  onToggleSelection?: (leadId: string) => void;
}) {
  const followUp = getNextFollowUp(lead);
  const followUpOverdue = followUp ? isFollowUpOverdue(followUp) : false;
  const sourceLabel = SOURCE_MAP[lead.source] || lead.source;

  return (
    <Card
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData('text/plain', lead.id);
        e.dataTransfer.setData('application/lead-stage', lead.stage);
        e.dataTransfer.effectAllowed = 'move';
        // Add drag visual feedback with a slight delay
        const target = e.currentTarget as HTMLElement;
        requestAnimationFrame(() => {
          target.style.opacity = '0.5';
          target.style.transform = 'rotate(1deg)';
        });
      }}
      onDragEnd={(e) => {
        const target = e.currentTarget as HTMLElement;
        target.style.opacity = '1';
        target.style.transform = 'none';
      }}
      onClick={() => onLeadClick(lead)}
      className={`border shadow-sm hover:shadow-md transition-all cursor-pointer group ${
        isSelected
          ? 'border-teal-300 bg-teal-50/50 hover:border-teal-300'
          : 'border-gray-100 hover:border-teal-200'
      } ${isDragging ? 'opacity-50 rotate-1' : ''}`}
    >
      <CardContent className="p-3 space-y-2">
        {/* Checkbox + Grip handle + Name + Score */}
        <div className="flex items-center gap-1.5">
          {onToggleSelection && (
            <Checkbox
              checked={isSelected}
              onCheckedChange={() => onToggleSelection(lead.id)}
              onClick={(e) => e.stopPropagation()}
              className="border-gray-300 flex-shrink-0"
            />
          )}
          <GripVertical className="w-3.5 h-3.5 text-gray-300 group-hover:text-gray-400 flex-shrink-0 cursor-grab" />
          <span className="text-sm font-bold text-gray-900 truncate flex-1">
            {lead.name}
          </span>
          <Badge
            variant="outline"
            className={`text-[10px] px-1.5 py-0 h-5 flex-shrink-0 ${scoreColor(lead.score)}`}
          >
            {toPersianNumber(lead.score)}
          </Badge>
        </div>

        {/* Phone */}
        <div className="flex items-center gap-1.5 mr-5">
          <Phone className="w-3 h-3 text-gray-400 flex-shrink-0" />
          <p className="text-xs text-gray-500 font-mono truncate" dir="ltr">
            {maskPhone(lead.phone)}
          </p>
        </div>

        {/* Source badge */}
        {sourceLabel && (
          <div className="flex items-center gap-1.5 mr-5">
            <Badge
              variant="outline"
              className="text-[9px] px-1.5 py-0 h-4 bg-gray-50 text-gray-500 border-gray-200"
            >
              {sourceLabel}
            </Badge>
          </div>
        )}

        {/* Assigned to */}
        {lead.assignedTo && (
          <div className="flex items-center gap-1.5 mr-5">
            <Users className="w-3 h-3 text-gray-400 flex-shrink-0" />
            <span className="text-[10px] text-gray-500 truncate">
              {lead.assignedTo}
            </span>
          </div>
        )}

        {/* Follow-up date */}
        {followUp && (
          <div
            className={`flex items-center gap-1.5 mr-5 ${
              followUpOverdue ? 'text-red-600' : 'text-amber-600'
            }`}
          >
            {followUpOverdue ? (
              <AlertTriangle className="w-3 h-3 flex-shrink-0" />
            ) : (
              <Calendar className="w-3 h-3 flex-shrink-0" />
            )}
            <span className="text-[10px] truncate">
              {followUpOverdue ? 'سررسید: ' : 'پیگیری: '}
              {new Intl.DateTimeFormat('fa-IR', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              }).format(new Date(followUp))}
            </span>
          </div>
        )}

        {/* Created time */}
        <div className="flex items-center justify-between mr-5 pt-1 border-t border-gray-50">
          <span className="text-[10px] text-gray-400 flex items-center gap-1">
            <Clock className="w-2.5 h-2.5" />
            {timeAgo(lead.createdAt)}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

/* ─────────── Kanban Column ─────────── */

function KanbanColumn({
  stage,
  leads,
  onLeadClick,
  onStageChange,
  selectedLeadIds,
  onToggleLeadSelection,
}: {
  stage: string;
  leads: Lead[];
  onLeadClick: (lead: Lead) => void;
  onStageChange: (leadId: string, newStage: string) => Promise<boolean>;
  selectedLeadIds?: Set<string>;
  onToggleLeadSelection?: (leadId: string) => void;
}) {
  const meta = KANBAN_STAGE_META[stage];
  const Icon = meta.icon;
  const [isDragOver, setIsDragOver] = useState(false);
  const [updatingLeadId, setUpdatingLeadId] = useState<string | null>(null);
  const columnRef = useRef<HTMLDivElement>(null);

  const handleDragOver = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      setIsDragOver(true);
    },
    []
  );

  const handleDragLeave = useCallback(
    (e: React.DragEvent) => {
      // Only set dragOver to false if we're leaving the column itself
      const rect = columnRef.current?.getBoundingClientRect();
      if (rect) {
        const { clientX, clientY } = e;
        if (
          clientX < rect.left ||
          clientX > rect.right ||
          clientY < rect.top ||
          clientY > rect.bottom
        ) {
          setIsDragOver(false);
        }
      } else {
        setIsDragOver(false);
      }
    },
    []
  );

  const handleDrop = useCallback(
    async (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragOver(false);

      const leadId = e.dataTransfer.getData('text/plain');
      const originalStage = e.dataTransfer.getData('application/lead-stage');

      if (!leadId) return;

      // Don't do anything if dropped in the same column
      const mappedOriginalStage = mapStageToKanban(originalStage);
      if (mappedOriginalStage === stage) return;

      // Optimistically update UI
      setUpdatingLeadId(leadId);

      const success = await onStageChange(leadId, stage);

      if (!success) {
        // Revert - the parent component handles reverting the leads array
        // Just remove the loading state
      }

      setUpdatingLeadId(null);
    },
    [stage, onStageChange]
  );

  return (
    <div
      ref={columnRef}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`flex flex-col min-w-[280px] w-[280px] rounded-xl border-2 transition-colors ${
        isDragOver
          ? `${meta.borderColor} ${meta.bg} border-dashed`
          : 'border-gray-100 bg-gray-50/50'
      }`}
    >
      {/* Column header */}
      <div
        className={`flex items-center gap-2 px-3 py-2.5 rounded-t-xl border-b ${
          isDragOver ? meta.headerBg : 'bg-white'
        } border-gray-100`}
      >
        <div className={`w-2 h-2 rounded-full ${meta.dotColor} flex-shrink-0`} />
        <Icon className={`w-4 h-4 ${meta.color} flex-shrink-0`} />
        <span className={`text-sm font-bold ${meta.color} truncate`}>
          {meta.label}
        </span>
        <span
          className={`mr-auto text-xs font-medium px-2 py-0.5 rounded-full ${meta.bg} ${meta.color} flex-shrink-0`}
        >
          {toPersianNumber(leads.length)}
        </span>
      </div>

      {/* Cards container */}
      <div className="flex-1 p-2 space-y-2 max-h-[calc(100vh-320px)] overflow-y-auto scrollbar-thin">
        {leads.length === 0 ? (
          <div
            className={`text-center py-8 text-xs rounded-lg border border-dashed transition-colors ${
              isDragOver
                ? `${meta.borderColor} ${meta.color}`
                : 'border-gray-200 text-gray-400'
            }`}
          >
            {isDragOver ? 'رها کنید' : 'لیدی در این مرحله نیست'}
          </div>
        ) : (
          leads.map((lead) => (
            <div key={lead.id} className="relative">
              {updatingLeadId === lead.id && (
                <div className="absolute inset-0 bg-white/60 rounded-lg flex items-center justify-center z-10">
                  <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
                </div>
              )}
              <KanbanLeadCard
                lead={lead}
                onLeadClick={onLeadClick}
                isDragging={updatingLeadId === lead.id}
                isSelected={selectedLeadIds?.has(lead.id)}
                onToggleSelection={onToggleLeadSelection}
              />
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/* ─────────── Main Kanban Board ─────────── */

export default function KanbanBoard({
  leads,
  onLeadClick,
  onStageChange,
  selectedLeadIds,
  onToggleLeadSelection,
}: KanbanBoardProps) {
  // Group leads by their Kanban stage (mapping old stages to new ones)
  const leadsByKanbanStage = KANBAN_STAGES.reduce(
    (acc, stage) => {
      acc[stage] = leads.filter((l) => mapStageToKanban(l.stage) === stage);
      return acc;
    },
    {} as Record<string, Lead[]>
  );

  return (
    <div className="overflow-x-auto pb-4" dir="rtl">
      <div className="flex gap-3 min-h-[calc(100vh-320px)]">
        {KANBAN_STAGES.map((stage) => (
          <KanbanColumn
            key={stage}
            stage={stage}
            leads={leadsByKanbanStage[stage] || []}
            onLeadClick={onLeadClick}
            onStageChange={onStageChange}
            selectedLeadIds={selectedLeadIds}
            onToggleLeadSelection={onToggleLeadSelection}
          />
        ))}
      </div>
    </div>
  );
}
