'use client';

import { toPersianNumber } from '@/lib/persian';

interface MonthlyData {
  month: string;
  count: number;
  revenue: number;
  rate: number;
}

interface MonthlyTrendsProps {
  monthlyLeads: { month: string; count: number }[];
  monthlyRevenue: { month: string; revenue: number }[];
}

export default function MonthlyTrends({ monthlyLeads, monthlyRevenue }: MonthlyTrendsProps) {
  const maxLeads = Math.max(...monthlyLeads.map((m) => m.count), 1);
  const maxRevenue = Math.max(...monthlyRevenue.map((m) => m.revenue), 1);

  const formatToman = (amount: number) => {
    const toman = Math.round(amount / 10);
    if (toman >= 1000000) return `${toPersianNumber(Math.round(toman / 1000000))} میلیون`;
    if (toman >= 1000) return `${toPersianNumber(Math.round(toman / 1000))} هزار`;
    return toPersianNumber(toman);
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" dir="rtl">
      {/* Monthly Leads Chart */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-gray-700">لیدهای ماهانه</h3>
        <div className="flex items-end gap-1.5 h-32">
          {monthlyLeads.map((item, idx) => {
            const barHeight = maxLeads > 0 ? Math.max(8, (item.count / maxLeads) * 100) : 8;
            return (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-[9px] text-gray-500 font-medium">
                  {item.count > 0 ? toPersianNumber(item.count) : '–'}
                </span>
                <div className="w-full bg-gray-100 rounded-t-sm relative" style={{ height: '100%' }}>
                  <div
                    className="absolute bottom-0 left-0 right-0 bg-teal-400 rounded-t-sm transition-all duration-500"
                    style={{ height: `${barHeight}%` }}
                  />
                </div>
                <span className="text-[8px] text-gray-400 truncate w-full text-center">
                  {item.month}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Monthly Revenue Chart */}
      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-gray-700">درآمد ماهانه</h3>
        <div className="flex items-end gap-1.5 h-32">
          {monthlyRevenue.map((item, idx) => {
            const barHeight = maxRevenue > 0 ? Math.max(8, (item.revenue / maxRevenue) * 100) : 8;
            return (
              <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                <span className="text-[9px] text-gray-500 font-medium">
                  {item.revenue > 0 ? formatToman(item.revenue) : '–'}
                </span>
                <div className="w-full bg-gray-100 rounded-t-sm relative" style={{ height: '100%' }}>
                  <div
                    className="absolute bottom-0 left-0 right-0 bg-emerald-400 rounded-t-sm transition-all duration-500"
                    style={{ height: `${barHeight}%` }}
                  />
                </div>
                <span className="text-[8px] text-gray-400 truncate w-full text-center">
                  {item.month}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
