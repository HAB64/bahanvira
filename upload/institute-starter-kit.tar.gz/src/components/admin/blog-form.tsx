'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { ArrowRight, Save } from 'lucide-react';
import { toast } from 'sonner';

interface BlogFormProps {
  initialData?: {
    id?: string;
    title: string;
    slug: string;
    content: string;
    excerpt: string;
    published: boolean;
    coverImage: string;
  };
  isEdit?: boolean;
}

export default function BlogForm({ initialData, isEdit }: BlogFormProps) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    title: initialData?.title || '',
    slug: initialData?.slug || '',
    content: initialData?.content || '',
    excerpt: initialData?.excerpt || '',
    published: initialData?.published ?? false,
    coverImage: initialData?.coverImage || '',
  });

  const updateForm = (field: string, value: string | boolean) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const generateSlug = (title: string) => {
    return title
      .replace(/\s+/g, '-')
      .replace(/[^\u0600-\u06FFa-zA-Z0-9-]/g, '')
      .toLowerCase();
  };

  const handleSave = async () => {
    if (!form.title || !form.slug) {
      toast.error('لطفاً عنوان و نامک را وارد کنید');
      return;
    }

    setSaving(true);
    try {
      const url = isEdit && initialData?.id
        ? `/api/admin/blog/${initialData.id}`
        : '/api/admin/blog';
      const method = isEdit ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      if (res.ok) {
        toast.success(isEdit ? 'مقاله بروزرسانی شد' : 'مقاله ایجاد شد');
        router.push('/admin/blog');
      } else {
        const data = await res.json();
        toast.error(data.error || 'خطا در ذخیره مقاله');
      }
    } catch {
      toast.error('خطا در ذخیره مقاله');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => router.push('/admin/blog')}>
            <ArrowRight className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isEdit ? 'ویرایش مقاله' : 'نوشتن مقاله جدید'}
          </h1>
        </div>
        <Button
          onClick={handleSave}
          disabled={saving}
          className="bg-teal-600 hover:bg-teal-700 gap-2"
        >
          <Save className="h-4 w-4" />
          {saving ? 'در حال ذخیره...' : 'ذخیره'}
        </Button>
      </div>

      <Card className="border-0 shadow-sm">
        <CardHeader>
          <CardTitle className="text-lg">اطلاعات مقاله</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>عنوان *</Label>
              <Input
                value={form.title}
                onChange={(e) => {
                  updateForm('title', e.target.value);
                  if (!isEdit) {
                    updateForm('slug', generateSlug(e.target.value));
                  }
                }}
                placeholder="عنوان مقاله"
              />
            </div>
            <div className="space-y-2">
              <Label>نامک (slug) *</Label>
              <Input
                value={form.slug}
                onChange={(e) => updateForm('slug', e.target.value)}
                placeholder="مثال: my-blog-post"
                dir="ltr"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>خلاصه</Label>
            <Textarea
              value={form.excerpt}
              onChange={(e) => updateForm('excerpt', e.target.value)}
              rows={3}
              placeholder="خلاصه کوتاه مقاله"
            />
          </div>

          <div className="space-y-2">
            <Label>محتوای مقاله</Label>
            <Textarea
              value={form.content}
              onChange={(e) => updateForm('content', e.target.value)}
              rows={20}
              placeholder="محتوای کامل مقاله را بنویسید..."
              className="font-mono text-sm"
            />
          </div>

          <div className="space-y-2">
            <Label>آدرس تصویر جلد</Label>
            <Input
              value={form.coverImage}
              onChange={(e) => updateForm('coverImage', e.target.value)}
              placeholder="آدرس URL تصویر"
              dir="ltr"
            />
          </div>

          <div className="flex items-center gap-3">
            <Switch
              checked={form.published}
              onCheckedChange={(checked) => updateForm('published', checked)}
            />
            <Label>منتشر شده</Label>
          </div>
        </CardContent>
      </Card>

      {/* Save button at bottom */}
      <div className="flex justify-end gap-3 pb-6">
        <Button variant="outline" onClick={() => router.push('/admin/blog')}>
          انصراف
        </Button>
        <Button
          onClick={handleSave}
          disabled={saving}
          className="bg-teal-600 hover:bg-teal-700 gap-2"
        >
          <Save className="h-4 w-4" />
          {saving ? 'در حال ذخیره...' : 'ذخیره مقاله'}
        </Button>
      </div>
    </div>
  );
}
