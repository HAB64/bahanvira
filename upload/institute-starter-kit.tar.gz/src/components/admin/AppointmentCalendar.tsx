'use client';

import { useState, useMemo, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  ChevronLeft,
  ChevronRight,
  Clock,
  User,
  MapPin,
  Video,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';

/* ─────────── Types ─────────── */

interface Appointment {
  id: string;
  title: string;
  description: string | null;
  leadId: string | null;
  karAmuzId: string | null;
  startTime: string;
  endTime: string;
  location: string | null;
  meetingUrl: string | null;
  type: string;
  status: string;
  assignedTo: string;
  reminderSent: boolean;
  createdAt: string;
  updatedAt: string;
  lead?: { id: string; name: string; phone: string } | null;
  karAmuz?: { id: string; firstName: string; lastName: string; phone: string } | null;
}

/* ─────────── Constants ─────────── */

const PERSIAN_DAY_NAMES = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

const PERSIAN_MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
];

const TYPE_COLORS: Record<string, { bg: string; border: string; text: string; dot: string }> = {
  CONSULTATION: { bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-700', dot: 'bg-blue-500' },
  FOLLOW_UP: { bg: 'bg-green-50', border: 'border-green-200', text: 'text-green-700', dot: 'bg-green-500' },
  DEMO: { bg: 'bg-purple-50', border: 'border-purple-200', text: 'text-purple-700', dot: 'bg-purple-500' },
  CLASS: { bg: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-700', dot: 'bg-orange-500' },
  OTHER: { bg: 'bg-gray-50', border: 'border-gray-200', text: 'text-gray-600', dot: 'bg-gray-500' },
};

const TYPE_LABELS: Record<string, string> = {
  CONSULTATION: 'مشاوره',
  FOLLOW_UP: 'پیگیری',
  DEMO: 'نمایش',
  CLASS: 'کلاس',
  OTHER: 'سایر',
};

const STATUS_LABELS: Record<string, string> = {
  SCHEDULED: 'برنامه‌ریزی شده',
  CONFIRMED: 'تایید شده',
  COMPLETED: 'انجام شده',
  CANCELLED: 'لغو شده',
  NO_SHOW: 'عدم حضور',
};

const STATUS_COLORS: Record<string, string> = {
  SCHEDULED: 'bg-blue-100 text-blue-700',
  CONFIRMED: 'bg-green-100 text-green-700',
  COMPLETED: 'bg-gray-100 text-gray-600',
  CANCELLED: 'bg-red-100 text-red-700',
  NO_SHOW: 'bg-orange-100 text-orange-700',
};

/* ─────────── Helpers ─────────── */

/**
 * Simple Gregorian-to-Jalali conversion
 * Returns { jy, jm, jd } for a given JS Date
 */
function gregorianToJalali(date: Date): { jy: number; jm: number; jd: number } {
  const gy = date.getFullYear();
  const gm = date.getMonth() + 1;
  const gd = date.getDate();

  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy2: number;
  if (gy > 1600) {
    jy2 = 979;
  } else {
    jy2 = 0;
  }
  const gy2 = gy > 1600 ? gy - 1600 : gy - 621;
  const days = 365 * gy2 + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
  const jy3 = 33 * Math.floor(days / 12053);
  const rem = days % 12053;
  const jy4 = 4 * Math.floor(rem / 1461);
  const rem2 = rem % 1461;
  let jy5: number;
  if (rem2 > 365) {
    jy5 = Math.floor((rem2 - 1) / 365);
  } else {
    jy5 = 0;
  }
  const jy = jy2 + jy3 + jy4 + jy5;
  const jm_day = rem2 - 365 * jy5 + (rem2 > 365 ? 1 : 0);

  let jm: number;
  let jd: number;
  if (jm_day <= 186) {
    jm = Math.ceil(jm_day / 31);
    jd = jm_day - (jm - 1) * 31;
  } else {
    jm = Math.ceil((jm_day - 186) / 30);
    jd = jm_day - 186 - (jm - 7) * 30;
    jm += 6;
  }

  return { jy, jm, jd };
}

/**
 * Simple Jalali-to-Gregorian conversion
 * Returns a JS Date for given Jalali year/month/day
 */
function jalaliToGregorian(jy: number, jm: number, jd: number): Date {
  let jy2: number;
  let gy2: number;
  if (jy > 979) {
    gy2 = 1600;
    jy2 = jy - 979;
  } else {
    gy2 = 621;
    jy2 = jy;
  }

  const days = 365 * jy2 + Math.floor(jy2 / 33) * 8 + Math.floor(((jy2 % 33) + 3) / 4) + 78 + jd + (jm <= 7 ? (jm - 1) * 31 : (jm - 1) * 30 + 6);

  let gy = 400 * Math.floor(days / 146097);
  let rem = days % 146097;
  if (rem > 36524) {
    gy += 100 * Math.floor(--rem / 36524);
    rem %= 36524;
    if (rem >= 365) rem++;
  }
  gy += 4 * Math.floor(rem / 1461);
  rem %= 1461;
  if (rem > 365) {
    gy += Math.floor((rem - 1) / 365);
    rem = (rem - 1) % 365;
  }

  const gd = rem;
  const g_d_m = [0, 31, (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 0;
  let gmSum = 0;
  for (let i = 0; i < g_d_m.length; i++) {
    gmSum += g_d_m[i];
    if (gd < gmSum) {
      gm = i;
      break;
    }
  }

  const gDay = gd - (gm > 0 ? g_d_m.slice(0, gm).reduce((a, b) => a + b, 0) : 0) + 1;

  return new Date(gy2 + gy, gm - 1, gDay);
}

/**
 * Returns the day of week for a Jalali date (0=Saturday, 6=Friday)
 * In the Jalali calendar week, Saturday is the first day
 */
function getJalaliDayOfWeek(jy: number, jm: number, jd: number): number {
  const gregDate = jalaliToGregorian(jy, jm, jd);
  // JS: 0=Sunday, 6=Saturday
  // We want: 0=Saturday, 1=Sunday, ..., 6=Friday
  const jsDay = gregDate.getDay();
  return (jsDay + 1) % 7; // Convert: Saturday=0, Sunday=1, ..., Friday=6
}

/**
 * Number of days in a Jalali month
 */
function jalaliMonthDays(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  // Esfand: check leap year
  const a = jy - (jy > 0 ? 474 : 473);
  const b = ((a % 2820) + 474 + 2820) % 2820;
  return ((b + 38) * 682) % 2816 < 682 ? 30 : 29;
}

function formatTime(dateStr: string): string {
  return new Intl.DateTimeFormat('fa-IR', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(dateStr));
}

function getRelatedName(apt: Appointment): string {
  if (apt.lead) return apt.lead.name;
  if (apt.karAmuz) return `${apt.karAmuz.firstName} ${apt.karAmuz.lastName}`;
  return '-';
}

/* ─────────── Component Props ─────────── */

interface AppointmentCalendarProps {
  appointments: Appointment[];
}

/* ─────────── Main Component ─────────── */

export default function AppointmentCalendar({ appointments }: AppointmentCalendarProps) {
  const today = useMemo(() => {
    const now = new Date();
    return gregorianToJalali(now);
  }, []);

  const [currentMonth, setCurrentMonth] = useState(today.jm);
  const [currentYear, setCurrentYear] = useState(today.jy);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);

  /* ── Month navigation ── */

  const goToPrevMonth = useCallback(() => {
    setCurrentMonth((prev) => {
      if (prev === 1) {
        setCurrentYear((y) => y - 1);
        return 12;
      }
      return prev - 1;
    });
    setSelectedDay(null);
  }, []);

  const goToNextMonth = useCallback(() => {
    setCurrentMonth((prev) => {
      if (prev === 12) {
        setCurrentYear((y) => y + 1);
        return 1;
      }
      return prev + 1;
    });
    setSelectedDay(null);
  }, []);

  const goToToday = useCallback(() => {
    const now = new Date();
    const jalali = gregorianToJalali(now);
    setCurrentMonth(jalali.jm);
    setCurrentYear(jalali.jy);
    setSelectedDay(jalali.jd);
  }, []);

  /* ── Build calendar grid ── */

  const calendarGrid = useMemo(() => {
    const daysInMonth = jalaliMonthDays(currentYear, currentMonth);
    const firstDayOfWeek = getJalaliDayOfWeek(currentYear, currentMonth, 1);

    // Create array of day cells (null for empty)
    const cells: (number | null)[] = [];

    // Add empty cells for days before the 1st
    for (let i = 0; i < firstDayOfWeek; i++) {
      cells.push(null);
    }

    // Add day cells
    for (let day = 1; day <= daysInMonth; day++) {
      cells.push(day);
    }

    // Pad remaining cells to complete the last week row
    while (cells.length % 7 !== 0) {
      cells.push(null);
    }

    // Split into weeks
    const weeks: (number | null)[][] = [];
    for (let i = 0; i < cells.length; i += 7) {
      weeks.push(cells.slice(i, i + 7));
    }

    return weeks;
  }, [currentYear, currentMonth]);

  /* ── Map appointments to days ── */

  const appointmentsByDay = useMemo(() => {
    const map: Record<number, Appointment[]> = {};

    for (const apt of appointments) {
      const startDate = new Date(apt.startTime);
      const jalali = gregorianToJalali(startDate);

      if (jalali.jy === currentYear && jalali.jm === currentMonth) {
        if (!map[jalali.jd]) {
          map[jalali.jd] = [];
        }
        map[jalali.jd].push(apt);
      }
    }

    // Sort each day's appointments by start time
    for (const day of Object.keys(map)) {
      map[Number(day)].sort(
        (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
      );
    }

    return map;
  }, [appointments, currentYear, currentMonth]);

  /* ── Selected day appointments ── */

  const selectedDayAppointments = useMemo(() => {
    if (selectedDay === null) return [];
    return appointmentsByDay[selectedDay] || [];
  }, [selectedDay, appointmentsByDay]);

  /* ── Is today ── */

  const isToday = useCallback(
    (day: number) => day === today.jd && currentMonth === today.jm && currentYear === today.jy,
    [today, currentMonth, currentYear]
  );

  /* ──── Render ──── */

  return (
    <div className="space-y-4" dir="rtl">
      {/* Month Navigation */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={goToPrevMonth}>
            <ChevronRight className="w-4 h-4" />
          </Button>
          <h3 className="text-base font-bold text-gray-900 min-w-[140px] text-center">
            {PERSIAN_MONTH_NAMES[currentMonth - 1]} {toPersianNumber(currentYear)}
          </h3>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={goToNextMonth}>
            <ChevronLeft className="w-4 h-4" />
          </Button>
        </div>
        <Button variant="outline" size="sm" onClick={goToToday} className="gap-1.5 text-xs">
          امروز
        </Button>
      </div>

      {/* Calendar Grid */}
      <div className="border rounded-xl overflow-hidden bg-white shadow-sm">
        {/* Day name headers */}
        <div className="grid grid-cols-7 bg-gray-50 border-b">
          {PERSIAN_DAY_NAMES.map((name) => (
            <div
              key={name}
              className="py-2 text-center text-xs font-bold text-gray-500"
            >
              {name}
            </div>
          ))}
        </div>

        {/* Weeks */}
        {calendarGrid.map((week, weekIdx) => (
          <div
            key={weekIdx}
            className="grid grid-cols-7 border-b last:border-b-0"
          >
            {week.map((day, dayIdx) => {
              if (day === null) {
                return (
                  <div
                    key={`empty-${weekIdx}-${dayIdx}`}
                    className="min-h-[80px] sm:min-h-[100px] bg-gray-50/30 border-l last:border-l-0"
                  />
                );
              }

              const dayAppointments = appointmentsByDay[day] || [];
              const todayHighlight = isToday(day);
              const isSelected = selectedDay === day;

              return (
                <button
                  key={`day-${day}`}
                  onClick={() => setSelectedDay(day === selectedDay ? null : day)}
                  className={`min-h-[80px] sm:min-h-[100px] p-1.5 sm:p-2 border-l last:border-l-0 text-right transition-colors ${
                    isSelected
                      ? 'bg-teal-50/70'
                      : todayHighlight
                        ? 'bg-teal-50/30'
                        : 'hover:bg-gray-50'
                  } ${dayIdx === 6 ? 'bg-red-50/20' : ''}`}
                >
                  {/* Day number */}
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`text-xs sm:text-sm font-medium inline-flex items-center justify-center w-6 h-6 rounded-full ${
                        todayHighlight
                          ? 'bg-teal-600 text-white'
                          : 'text-gray-700'
                      }`}
                    >
                      {toPersianNumber(day)}
                    </span>
                    {dayAppointments.length > 0 && (
                      <span className="text-[9px] text-gray-400">
                        {toPersianNumber(dayAppointments.length)}
                      </span>
                    )}
                  </div>

                  {/* Appointment dots/compact cards */}
                  <div className="space-y-0.5 max-h-[56px] sm:max-h-[70px] overflow-hidden">
                    {dayAppointments.slice(0, 3).map((apt) => {
                      const typeColor = TYPE_COLORS[apt.type] || TYPE_COLORS.OTHER;
                      return (
                        <div
                          key={apt.id}
                          className={`text-[9px] sm:text-[10px] px-1 py-0.5 rounded border truncate ${typeColor.bg} ${typeColor.border} ${typeColor.text}`}
                        >
                          <span className="inline-block w-1 h-1 rounded-full ml-0.5" style={{ backgroundColor: 'currentColor', opacity: 0.6 }} />
                          {formatTime(apt.startTime)} {apt.title}
                        </div>
                      );
                    })}
                    {dayAppointments.length > 3 && (
                      <div className="text-[9px] text-gray-400 text-center">
                        +{toPersianNumber(dayAppointments.length - 3)}
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Day Detail Dialog */}
      <Dialog open={selectedDay !== null} onOpenChange={(open) => { if (!open) setSelectedDay(null); }}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Clock className="w-5 h-5 text-teal-600" />
              قرارهای {toPersianNumber(selectedDay || 0)} {PERSIAN_MONTH_NAMES[currentMonth - 1]}
            </DialogTitle>
          </DialogHeader>

          {selectedDayAppointments.length === 0 ? (
            <div className="py-8 text-center">
              <Clock className="w-10 h-10 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">قراری در این روز ثبت نشده است</p>
            </div>
          ) : (
            <div className="space-y-3 py-2">
              {selectedDayAppointments.map((apt) => {
                const typeColor = TYPE_COLORS[apt.type] || TYPE_COLORS.OTHER;
                const statusColor = STATUS_COLORS[apt.status] || STATUS_COLORS.SCHEDULED;

                return (
                  <div
                    key={apt.id}
                    className={`rounded-xl border p-3 ${typeColor.bg} ${typeColor.border} ${
                      apt.status === 'CANCELLED' ? 'opacity-50' : ''
                    }`}
                  >
                    {/* Title + badges */}
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <div className={`w-2 h-2 rounded-full ${typeColor.dot} shrink-0`} />
                      <h4 className="font-bold text-gray-900 text-sm">{apt.title}</h4>
                      <Badge variant="secondary" className={`${statusColor} text-[10px] border-0 px-1.5 py-0 h-4`}>
                        {STATUS_LABELS[apt.status] || apt.status}
                      </Badge>
                    </div>

                    {/* Time */}
                    <div className="flex items-center gap-1.5 text-xs text-gray-600 mb-1.5">
                      <Clock className="w-3.5 h-3.5 text-gray-400" />
                      <span>{formatTime(apt.startTime)} تا {formatTime(apt.endTime)}</span>
                    </div>

                    {/* Location */}
                    {apt.location && (
                      <div className="flex items-center gap-1.5 text-xs text-gray-600 mb-1.5">
                        <MapPin className="w-3.5 h-3.5 text-gray-400" />
                        <span>{apt.location}</span>
                      </div>
                    )}

                    {/* Meeting URL */}
                    {apt.meetingUrl && (
                      <div className="flex items-center gap-1.5 text-xs mb-1.5">
                        <Video className="w-3.5 h-3.5 text-gray-400" />
                        <a
                          href={apt.meetingUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-teal-600 hover:text-teal-800 hover:underline truncate"
                        >
                          لینک جلسه
                        </a>
                      </div>
                    )}

                    {/* Related person */}
                    {(apt.lead || apt.karAmuz) && (
                      <div className="flex items-center gap-1.5 text-xs text-gray-600">
                        <User className="w-3.5 h-3.5 text-teal-500" />
                        <span className="text-teal-700 font-medium">{getRelatedName(apt)}</span>
                      </div>
                    )}

                    {/* Status icons */}
                    <div className="flex items-center gap-2 mt-2 pt-2 border-t border-gray-200/50">
                      {apt.status === 'COMPLETED' && (
                        <div className="flex items-center gap-1 text-xs text-green-700">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>انجام شده</span>
                        </div>
                      )}
                      {apt.status === 'CANCELLED' && (
                        <div className="flex items-center gap-1 text-xs text-red-700">
                          <XCircle className="w-3.5 h-3.5" />
                          <span>لغو شده</span>
                        </div>
                      )}
                      {apt.assignedTo && (
                        <span className="text-[10px] text-gray-400 mr-auto">
                          مسئول: {apt.assignedTo}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
