'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Trash2,
  ArrowRightLeft,
  Tag,
  UserCheck,
  Download,
  X,
  Loader2,
  AlertTriangle,
  CheckCircle2,
} from 'lucide-react';
import { toPersianNumber } from '@/lib/persian';
import { toast } from 'sonner';

/* ─────────── Types ─────────── */

interface LeadTag {
  id: string;
  name: string;
  color: string;
}

interface BulkActionBarProps {
  selectedIds: string[];
  totalCount: number;
  onClearSelection: () => void;
  onActionComplete: () => void;
  availableTags: LeadTag[];
}

/* ─────────── Constants ─────────── */

const STAGE_OPTIONS = [
  { value: 'NEW', label: 'لیدهای جدید' },
  { value: 'CONTACTED', label: 'در انتظار تماس' },
  { value: 'INTERESTED', label: 'علاقه‌مند' },
  { value: 'ENROLLED', label: 'ثبت‌نام شده' },
  { value: 'REJECTED', label: 'رد شده' },
  { value: 'ARCHIVED', label: 'بایگانی' },
];

/* ─────────── Component ─────────── */

export default function BulkActionBar({
  selectedIds,
  totalCount,
  onClearSelection,
  onActionComplete,
  availableTags,
}: BulkActionBarProps) {
  const [loading, setLoading] = useState(false);

  // Dialogs
  const [stageDialogOpen, setStageDialogOpen] = useState(false);
  const [selectedStage, setSelectedStage] = useState('');

  const [tagDialogOpen, setTagDialogOpen] = useState(false);
  const [selectedTagName, setSelectedTagName] = useState('');
  const [customTagName, setCustomTagName] = useState('');

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [assignTo, setAssignTo] = useState('');

  if (selectedIds.length === 0) return null;

  const handleAction = async (action: string, data?: Record<string, unknown>) => {
    setLoading(true);
    try {
      if (action === 'exportCsv') {
        // Handle CSV export differently - it returns a file
        const res = await fetch('/api/crm/leads/bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'exportCsv',
            leadIds: selectedIds,
          }),
        });

        if (res.ok) {
          const blob = await res.blob();
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `leads-export-${new Date().toISOString().split('T')[0]}.csv`;
          document.body.appendChild(a);
          a.click();
          window.URL.revokeObjectURL(url);
          document.body.removeChild(a);
          toast.success(`خروجی CSV ${toPersianNumber(selectedIds.length)} لید دریافت شد`);
        } else {
          toast.error('خطا در دریافت خروجی CSV');
        }
      } else {
        const res = await fetch('/api/crm/leads/bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action,
            leadIds: selectedIds,
            data,
          }),
        });

        const result = await res.json();

        if (res.ok) {
          toast.success(result['پیام'] || 'عملیات با موفقیت انجام شد');
          onActionComplete();
        } else {
          toast.error(result['خطا'] || 'خطا در انجام عملیات');
        }
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Main Action Bar */}
      <div
        className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg"
        dir="rtl"
      >
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            {/* Selection info */}
            <div className="flex items-center gap-3">
              <Badge
                variant="secondary"
                className="bg-teal-50 text-teal-700 text-sm px-3 py-1 font-bold"
              >
                {toPersianNumber(selectedIds.length)} سرن انتخاب شده
              </Badge>
              <span className="text-xs text-gray-400">
                از {toPersianNumber(totalCount)}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={onClearSelection}
                className="h-7 text-xs text-gray-500 hover:text-gray-700 gap-1"
              >
                <X className="w-3 h-3" />
                لغو انتخاب
              </Button>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 flex-wrap">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setStageDialogOpen(true)}
                disabled={loading}
                className="gap-1.5 text-xs h-8"
              >
                <ArrowRightLeft className="w-3.5 h-3.5" />
                تغییر مرحله
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setTagDialogOpen(true)}
                disabled={loading}
                className="gap-1.5 text-xs h-8"
              >
                <Tag className="w-3.5 h-3.5" />
                افزودن برچسب
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setAssignDialogOpen(true)}
                disabled={loading}
                className="gap-1.5 text-xs h-8"
              >
                <UserCheck className="w-3.5 h-3.5" />
                تخصیص
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => handleAction('exportCsv')}
                disabled={loading}
                className="gap-1.5 text-xs h-8"
              >
                {loading ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Download className="w-3.5 h-3.5" />
                )}
                خروجی CSV
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setDeleteDialogOpen(true)}
                disabled={loading}
                className="gap-1.5 text-xs h-8 text-red-600 border-red-200 hover:bg-red-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                حذف
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Change Stage Dialog */}
      <Dialog open={stageDialogOpen} onOpenChange={setStageDialogOpen} dir="rtl">
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <ArrowRightLeft className="w-5 h-5 text-teal-600" />
              تغییر مرحله لیدها
            </DialogTitle>
            <DialogDescription>
              مرحله جدید را برای {toPersianNumber(selectedIds.length)} لید انتخاب کنید
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-sm font-medium">مرحله جدید</Label>
              <Select value={selectedStage} onValueChange={setSelectedStage}>
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب مرحله..." />
                </SelectTrigger>
                <SelectContent>
                  {STAGE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setStageDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              onClick={() => {
                handleAction('changeStage', { stage: selectedStage });
                setStageDialogOpen(false);
                setSelectedStage('');
              }}
              disabled={!selectedStage || loading}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              اعمال
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Tag Dialog */}
      <Dialog open={tagDialogOpen} onOpenChange={setTagDialogOpen} dir="rtl">
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <Tag className="w-5 h-5 text-teal-600" />
              افزودن برچسب
            </DialogTitle>
            <DialogDescription>
              برچسب مورد نظر را برای {toPersianNumber(selectedIds.length)} لید انتخاب یا ایجاد کنید
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Existing tags */}
            {availableTags.length > 0 && (
              <div className="space-y-2">
                <Label className="text-sm font-medium">برچسب‌های موجود</Label>
                <div className="flex flex-wrap gap-2">
                  {availableTags.map((tag) => (
                    <button
                      key={tag.id}
                      onClick={() => {
                        setSelectedTagName(tag.name);
                        setCustomTagName('');
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        selectedTagName === tag.name
                          ? 'border-teal-400 bg-teal-50 text-teal-700'
                          : 'border-gray-200 bg-white text-gray-600 hover:bg-gray-50'
                      }`}
                      style={{
                        borderColor: selectedTagName === tag.name ? tag.color : undefined,
                        color: selectedTagName === tag.name ? tag.color : undefined,
                      }}
                    >
                      {tag.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Custom tag input */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">برچسب جدید</Label>
              <Input
                placeholder="نام برچسب جدید..."
                value={customTagName}
                onChange={(e) => {
                  setCustomTagName(e.target.value);
                  setSelectedTagName('');
                }}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => { setTagDialogOpen(false); setSelectedTagName(''); setCustomTagName(''); }}>
              انصراف
            </Button>
            <Button
              onClick={() => {
                const tagName = customTagName || selectedTagName;
                if (tagName) {
                  handleAction('addTag', { tagName });
                  setTagDialogOpen(false);
                  setSelectedTagName('');
                  setCustomTagName('');
                }
              }}
              disabled={(!selectedTagName && !customTagName) || loading}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              اعمال
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen} dir="rtl">
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right text-red-700">
              <AlertTriangle className="w-5 h-5" />
              تأیید حذف
            </DialogTitle>
            <DialogDescription>
              آیا از حذف {toPersianNumber(selectedIds.length)} لید اطمینان دارید؟ این عمل قابل بازگشت نیست.
            </DialogDescription>
          </DialogHeader>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              انصراف
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                handleAction('delete');
                setDeleteDialogOpen(false);
              }}
              disabled={loading}
              className="gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              حذف {toPersianNumber(selectedIds.length)} لید
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Dialog */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen} dir="rtl">
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-right">
              <UserCheck className="w-5 h-5 text-teal-600" />
              تخصیص مشاور
            </DialogTitle>
            <DialogDescription>
              مشاور را برای {toPersianNumber(selectedIds.length)} لید انتخاب کنید
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label className="text-sm font-medium">نام مشاور</Label>
              <Input
                placeholder="نام مشاور..."
                value={assignTo}
                onChange={(e) => setAssignTo(e.target.value)}
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => { setAssignDialogOpen(false); setAssignTo(''); }}>
              انصراف
            </Button>
            <Button
              onClick={() => {
                handleAction('assign', { assignedTo: assignTo });
                setAssignDialogOpen(false);
                setAssignTo('');
              }}
              disabled={!assignTo.trim() || loading}
              className="bg-teal-600 hover:bg-teal-700 text-white gap-2"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
              تخصیص
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
