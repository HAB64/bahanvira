'use client';

import { toPersianNumber } from '@/lib/persian';

interface ConversionFunnelProps {
  stageCounts: Record<string, number>;
}

const FUNNEL_STAGES = [
  { key: 'NEW', label: 'لید جدید', color: 'bg-sky-500', bgLight: 'bg-sky-100' },
  { key: 'CONTACTED', label: 'در تماس', color: 'bg-amber-500', bgLight: 'bg-amber-100' },
  { key: 'INTERESTED', label: 'علاقه‌مند', color: 'bg-orange-500', bgLight: 'bg-orange-100' },
  { key: 'ENROLLED', label: 'ثبت‌نام شده', color: 'bg-emerald-500', bgLight: 'bg-emerald-100' },
];

export default function ConversionFunnel({ stageCounts }: ConversionFunnelProps) {
  const total = FUNNEL_STAGES.reduce((sum, s) => sum + (stageCounts[s.key] || 0), 0);
  const maxCount = Math.max(...FUNNEL_STAGES.map((s) => stageCounts[s.key] || 0), 1);

  return (
    <div className="space-y-3" dir="rtl">
      <h3 className="text-sm font-semibold text-gray-700">قیف تبدیل</h3>

      {/* Funnel bars */}
      <div className="space-y-2">
        {FUNNEL_STAGES.map((stage, idx) => {
          const count = stageCounts[stage.key] || 0;
          const percent = total > 0 ? Math.round((count / total) * 100) : 0;
          const barWidth = maxCount > 0 ? Math.max(15, (count / maxCount) * 100) : 15;

          // Calculate conversion rate from previous stage
          const prevCount = idx > 0 ? (stageCounts[FUNNEL_STAGES[idx - 1].key] || 0) : 0;
          const convRate = prevCount > 0 && count > 0
            ? Math.round((count / prevCount) * 100)
            : null;

          return (
            <div key={stage.key} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-gray-700">{stage.label}</span>
                <div className="flex items-center gap-2">
                  <span className="text-gray-500">
                    {toPersianNumber(count)} ({toPersianNumber(percent)}%)
                  </span>
                  {convRate !== null && (
                    <span className="text-[10px] text-teal-600 bg-teal-50 px-1.5 py-0.5 rounded-full">
                      {toPersianNumber(convRate)}% تبدیل
                    </span>
                  )}
                </div>
              </div>
              <div className={`w-full ${stage.bgLight} rounded-full h-6 overflow-hidden`}>
                <div
                  className={`h-full ${stage.color} rounded-full transition-all duration-500 flex items-center justify-center`}
                  style={{ width: `${barWidth}%`, minWidth: count > 0 ? '2rem' : '0' }}
                >
                  {count > 0 && (
                    <span className="text-white text-[10px] font-bold">
                      {toPersianNumber(count)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Overall conversion rate */}
      {total > 0 && (
        <div className="pt-2 border-t border-gray-100">
          <div className="flex items-center justify-between text-xs">
            <span className="text-gray-500">نرخ تبدیل کلی</span>
            <span className="font-bold text-teal-700">
              {toPersianNumber(
                Math.round(((stageCounts.ENROLLED || 0) / total) * 100)
              )}%
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
