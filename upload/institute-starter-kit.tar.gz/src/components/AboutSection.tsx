'use client';

import { Award, Eye, Heart, Users, GraduationCap, Star, Shield, FileCheck, BadgeCheck } from 'lucide-react';

const visions = [
  {
    icon: Award,
    title: 'ارائه مهارت‌های کاربردی',
    description: 'مهارت‌های مورد نیاز بازار کار را به صورت عملی و کاربردی آموزش می‌دهیم',
  },
  {
    icon: Star,
    title: 'پرورش تفکر خلاق',
    description: 'تفکر خلاق و نوآوری در نسل جدید را پرورش می‌دهیم',
  },
  {
    icon: Heart,
    title: 'حمایت از کارآفرینان',
    description: 'از کارآفرینان و کسب‌وکارهای محلی حمایت می‌کنیم',
  },
];

const licenses = [
  {
    icon: Shield,
    title: 'مجوز سازمان فنی و حرفه‌ای',
    description: 'دارای مجوز رسمی از سازمان فنی و حرفه‌ای کشور',
  },
  {
    icon: FileCheck,
    title: 'گواهینامه ICDL بین‌المللی',
    description: 'مرکز آزمون رسمی گواهینامه بین‌المللی ICDL',
  },
  {
    icon: BadgeCheck,
    title: 'تأییدیه وزارت آموزش و پرورش',
    description: 'دوره‌ها مورد تأیید وزارت آموزش و پرورش',
  },
];

export default function AboutSection() {
  return (
    <section id="about" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main About Content */}
        <div className="flex flex-col lg:flex-row items-center gap-10 lg:gap-16 mb-16">
          {/* Image/Illustration Side */}
          <div className="flex-1 w-full">
            <div className="relative bg-gradient-to-br from-[#ccfbf1] to-[#99f6e4] rounded-3xl p-8 sm:p-10 lg:p-12">
              {/* Decorative elements */}
              <div className="absolute top-6 left-6 w-20 h-20 bg-white/30 rounded-full blur-xl" />
              <div className="absolute bottom-6 right-6 w-32 h-32 bg-[#0d9488]/10 rounded-full blur-2xl" />

              <div className="relative text-center">
                {/* Year badge */}
                <div className="inline-flex items-center gap-2 bg-white rounded-full px-6 py-3 shadow-lg mb-8">
                  <GraduationCap className="w-5 h-5 text-[#0d9488]" />
                  <span className="text-lg font-bold text-[#0f172a]">از سال ۱۳۷۸</span>
                </div>

                {/* Big number */}
                <div className="mb-6">
                  <span className="text-7xl sm:text-8xl font-bold text-[#0d9488]">۲۷</span>
                  <span className="text-2xl sm:text-3xl font-bold text-[#0f766e] mr-2">سال</span>
                </div>

                <p className="text-lg text-[#0f766e] font-medium mb-8">
                  تجربه درخشان در آموزش مهارت‌های کامپیوتری
                </p>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4">
                    <Users className="w-6 h-6 text-[#0d9488] mx-auto mb-2" />
                    <p className="text-sm font-bold text-[#0f172a]">هزاران</p>
                    <p className="text-xs text-[#64748b]">دانشجو</p>
                  </div>
                  <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4">
                    <Award className="w-6 h-6 text-[#f59e0b] mx-auto mb-2" />
                    <p className="text-sm font-bold text-[#0f172a]">بین‌المللی</p>
                    <p className="text-xs text-[#64748b]">گواهینامه</p>
                  </div>
                  <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4">
                    <GraduationCap className="w-6 h-6 text-[#8b5cf6] mx-auto mb-2" />
                    <p className="text-sm font-bold text-[#0f172a]">مجرب</p>
                    <p className="text-xs text-[#64748b]">اساتید</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Text Content Side */}
          <div className="flex-1 text-center lg:text-right">
            <div className="inline-flex items-center gap-2 bg-[#ccfbf1] text-[#0d9488] rounded-full px-4 py-1.5 mb-4">
              <Eye className="w-4 h-4" />
              <span className="text-sm font-medium">درباره ما</span>
            </div>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#0f172a] mb-5 leading-relaxed">
              درباره آموزشگاه بهان رایانه
            </h2>

            <div className="space-y-4 mb-8">
              <p className="text-base text-[#475569] leading-relaxed">
                آموزشگاه فنی و حرفه‌ای بهان رایانه از سال ۱۳۷۸ فعالیت خود را آغاز کرده و طی{' '}
                <strong className="text-[#0f172a]">۲۷ سال</strong> تجربه ارزشمند، هزاران
                دانش‌آموز را در زمینه مهارت‌های کامپیوتری و کسب‌وکار تربیت کرده است.
              </p>
              <p className="text-base text-[#475569] leading-relaxed">
                تحت مدیریت <strong className="text-[#0f172a]">دکتر بهان</strong>، این
                آموزشگاه همواره بر آموزش‌های کاربردی، به‌روز و بازارمحور تمرکز داشته است.
                ما معتقدیم آموزش باید منجر به اشتغال و پیشرفت واقعی شود.
              </p>
              <p className="text-base text-[#475569] leading-relaxed">
                کادر آموزشی ما متشکل از اساتید مجرب و متخصص هستند که با اشتیاق کامل دانش و
                تجربه خود را منتقل می‌کنند.
              </p>
            </div>

            {/* Vision Items */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-[#0f172a]">چشم‌انداز ما:</h3>
              {visions.map((vision) => {
                const Icon = vision.icon;
                return (
                  <div
                    key={vision.title}
                    className="flex items-start gap-4 bg-gray-50 rounded-xl p-4"
                  >
                    <div className="w-10 h-10 rounded-lg bg-[#ccfbf1] flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-[#0d9488]" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-[#0f172a] mb-1">{vision.title}</p>
                      <p className="text-sm text-[#64748b]">{vision.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Licenses & Certificates */}
        <div className="bg-gradient-to-br from-[#f0f9ff] to-[#e0f2fe] rounded-3xl p-8 sm:p-10">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 bg-white text-[#3b82f6] rounded-full px-4 py-1.5 mb-4 shadow-sm">
              <Shield className="w-4 h-4" />
              <span className="text-sm font-medium">مجوزها و گواهینامه‌ها</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-[#0f172a]">
              مجوزها و تأییدیه‌های رسمی
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            {licenses.map((license) => {
              const Icon = license.icon;
              return (
                <div
                  key={license.title}
                  className="bg-white rounded-2xl p-6 text-center shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="w-14 h-14 rounded-2xl bg-[#dbeafe] flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-7 h-7 text-[#3b82f6]" />
                  </div>
                  <h4 className="font-bold text-[#0f172a] mb-2 text-sm">{license.title}</h4>
                  <p className="text-xs text-[#64748b] leading-relaxed">{license.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
