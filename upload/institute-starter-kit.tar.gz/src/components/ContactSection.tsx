'use client';

import { useState } from 'react';
import { Phone, MapPin, MessageCircle, Send, CheckCircle, Clock, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const contactInfo = [
  {
    icon: Phone,
    title: 'شماره‌های تماس',
    details: [
      { label: 'همراه (واتساپ)', value: '۰۹۱۱۱۲۷۷۱۹۴', dir: 'ltr' as const },
      { label: 'ثابت', value: '۰۱۱-۴۴۷۴۶۶۶۵', dir: 'ltr' as const },
    ],
    color: '#0d9488',
    bgColor: '#ccfbf1',
  },
  {
    icon: MapPin,
    title: 'آدرس',
    details: [
      {
        label: '',
        value: 'مازندران، محمودآباد، خیابان امام، نسیم ۴، انتهای کوچه',
        dir: 'rtl' as const,
      },
    ],
    color: '#3b82f6',
    bgColor: '#dbeafe',
  },
  {
    icon: Clock,
    title: 'ساعات کاری',
    details: [
      { label: 'شنبه تا چهارشنبه', value: '۸:۰۰ تا ۱۸:۰۰', dir: 'rtl' as const },
      { label: 'پنج‌شنبه', value: '۸:۰۰ تا ۱۳:۰۰', dir: 'rtl' as const },
    ],
    color: '#f59e0b',
    bgColor: '#fef3c7',
  },
];

const courseOptions = ['ICDL', 'Scratch', 'Python', 'مشاوره کسب‌وکار', 'سایر'];

export default function ContactSection() {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    course: '',
    message: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');

    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          phone: formData.phone,
          course: formData.course,
          message: formData.message,
          source: 'contact-form',
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'خطا در ثبت اطلاعات');
        return;
      }

      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setFormData({ name: '', phone: '', course: '', message: '' });
      }, 4000);
    } catch {
      setError('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-16 sm:py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-[#ccfbf1] text-[#0d9488] rounded-full px-4 py-1.5 mb-4">
            <MessageCircle className="w-4 h-4" />
            <span className="text-sm font-medium">ارتباط با ما</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">تماس با ما</h2>
          <p className="text-[#64748b] text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
            برای کسب اطلاعات بیشتر درباره دوره‌ها یا ثبت‌نام، با ما تماس بگیرید یا فرم زیر را
            پر کنید.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
          {/* Contact Info Cards + Map */}
          <div className="lg:w-5/12 space-y-5">
            {contactInfo.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.title}
                  className="bg-white rounded-2xl border border-gray-100 p-5 sm:p-6 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start gap-4">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: item.bgColor }}
                    >
                      <Icon className="w-6 h-6" style={{ color: item.color }} />
                    </div>
                    <div>
                      <h3 className="font-bold text-[#0f172a] mb-2">{item.title}</h3>
                      {item.details.map((detail, idx) => (
                        <p
                          key={idx}
                          className="text-sm text-[#475569] leading-relaxed"
                          dir={detail.dir}
                        >
                          {detail.label && (
                            <span className="text-[#64748b]">{detail.label}: </span>
                          )}
                          {detail.value}
                        </p>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Google Map */}
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              <div className="p-4 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <Navigation className="w-4 h-4 text-[#0d9488]" />
                  <span className="text-sm font-medium text-[#0f172a]">موقعیت ما روی نقشه</span>
                </div>
              </div>
              <div className="relative aspect-[4/3] bg-gray-100">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d40643.95873648!2d52.24!3d36.63!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3f8e1e2e2e2e2e2%3A0x2e2e2e2e2e2e2e2e!2sMahmudabad%2C%20Mazandaran%2C%20Iran!5e0!3m2!1sfa!2s!4v1700000000000!5m2!1sfa!2s"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="absolute inset-0"
                  title="موقعیت آموزشگاه بهان رایانه"
                />
              </div>
            </div>

            {/* WhatsApp CTA */}
            <a
              href="https://wa.me/989111277194"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 bg-[#25D366] hover:bg-[#1fb855] text-white rounded-2xl p-5 transition-all shadow-md hover:shadow-lg"
            >
              <MessageCircle className="w-6 h-6" />
              <span className="font-bold text-base">پیام در واتساپ</span>
            </a>
          </div>

          {/* Contact Form */}
          <div className="lg:w-7/12">
            <div className="bg-white rounded-2xl border border-gray-100 p-6 sm:p-8 shadow-sm">
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="w-16 h-16 rounded-full bg-[#ccfbf1] flex items-center justify-center mb-4">
                    <CheckCircle className="w-8 h-8 text-[#0d9488]" />
                  </div>
                  <h3 className="text-xl font-bold text-[#0f172a] mb-2">پیام شما ارسال شد!</h3>
                  <p className="text-[#64748b]">به زودی با شما تماس خواهیم گرفت.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-600 text-sm rounded-lg p-3">
                      {error}
                    </div>
                  )}
                  <h3 className="text-lg font-bold text-[#0f172a] mb-2">فرم تماس</h3>

                  {/* Name */}
                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">
                      نام و نام خانوادگی
                    </label>
                    <Input
                      placeholder="نام خود را وارد کنید"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                      className="h-11 bg-gray-50 border-gray-200 focus:border-[#0d9488] focus:ring-[#0d9488]/20"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">
                      شماره تماس
                    </label>
                    <Input
                      placeholder="شماره موبایل خود را وارد کنید"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      required
                      dir="ltr"
                      className="h-11 bg-gray-50 border-gray-200 focus:border-[#0d9488] focus:ring-[#0d9488]/20 text-right"
                    />
                  </div>

                  {/* Course Selection */}
                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">
                      دوره مورد نظر
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {courseOptions.map((option) => (
                        <button
                          key={option}
                          type="button"
                          onClick={() => setFormData({ ...formData, course: option })}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                            formData.course === option
                              ? 'bg-[#0d9488] text-white shadow-md shadow-[#0d9488]/20'
                              : 'bg-gray-50 text-[#475569] border border-gray-200 hover:border-[#0d9488]/50 hover:text-[#0d9488]'
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-sm font-medium text-[#334155] mb-1.5">
                      پیام شما
                    </label>
                    <Textarea
                      placeholder="پیام یا سوال خود را بنویسید..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      rows={4}
                      className="bg-gray-50 border-gray-200 focus:border-[#0d9488] focus:ring-[#0d9488]/20 resize-none"
                    />
                  </div>

                  {/* Submit */}
                  <Button
                    type="submit"
                    size="lg"
                    disabled={submitting}
                    className="w-full bg-[#0d9488] hover:bg-[#0f766e] text-white shadow-lg shadow-[#0d9488]/20 h-12 text-base font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {submitting ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        در حال ارسال...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Send className="w-5 h-5" />
                        ارسال پیام
                      </span>
                    )}
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
