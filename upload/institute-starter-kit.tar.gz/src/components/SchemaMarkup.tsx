import { courses } from '@/data/courses';
import { siteConfig } from '@/config/site';

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': ['Organization', 'LocalBusiness', 'EducationalOrganization'],
  name: siteConfig.name.fullName,
  alternateName: `${siteConfig.name.en} ${siteConfig.institute.typeEn} Institute`,
  url: siteConfig.url.base,
  logo: `${siteConfig.url.base}${siteConfig.assets.logo}`,
  image: `${siteConfig.url.base}${siteConfig.assets.ogImage}`,
  description:
    `پلتفرم مهارت‌آموزی ${siteConfig.institute.typeFa} ${siteConfig.name.fa} با ${siteConfig.experience.yearsFa} سال تجربه — آموزش مبتنی بر شایستگی (CBT) در ۳ خوشه و ۸ گروه آموزشی: فن آوری اطلاعات، امور مالی و بازرگانی، خدمات آموزشی، خدمات حقوقی، معماری، ساختمان، صنایع پوشاک، هنرهای تجسمی`,
  telephone: [`+${siteConfig.contact.whatsappRaw}`, `+98${siteConfig.contact.phoneRaw.substring(1)}`],
  email: siteConfig.contact.email,
  sameAs: [
    siteConfig.social.instagram,
    siteConfig.social.telegram,
    siteConfig.contact.whatsappUrl,
  ],
  address: {
    '@type': 'PostalAddress',
    streetAddress: 'خیابان امام، کوچه آسیاب (نسیم ۴)، انتهای کوچه',
    addressLocality: siteConfig.location.city,
    addressRegion: siteConfig.location.province,
    addressCountry: 'IR',
  },
  geo: {
    '@type': 'GeoCoordinates',
    latitude: siteConfig.location.latitude,
    longitude: siteConfig.location.longitude,
  },
  foundingDate: '1999',
  founder: {
    '@type': 'Person',
    name: siteConfig.founder.name,
    jobTitle: siteConfig.founder.title,
    knowsAbout: ['کارآفرینی', 'مدیریت آموزشی', 'عارضه‌یابی سازمانی'],
  },
  openingHoursSpecification: [
    {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday'],
      opens: '08:00',
      closes: '20:00',
    },
    {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: 'Thursday',
      opens: '08:00',
      closes: '13:00',
    },
  ],
  priceRange: '',
  areaServed: {
    '@type': 'City',
    name: siteConfig.location.city,
  },
};

const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'دوره ICDL شامل چه مباحثی است؟',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'دوره ICDL شامل ۶ ماژول است: مفاهیم بنیادی فناوری اطلاعات، واژه‌پرداز (Word)، صفحه‌گسترده (Excel)، ارائه الکترونیکی (PowerPoint)، پایگاه داده (Access) و ارتباطات آنلاین. پس از اتمام، گواهینامه بین‌المللی ICDL معتبر در ۱۴۰+ کشور صادر می‌شود.',
      },
    },
    {
      '@type': 'Question',
      name: 'آیا دوره‌ها مدرک بین‌المللی دارند؟',
      acceptedAnswer: {
        '@type': 'Answer',
        text: `دوره ICDL دارای گواهینامه بین‌المللی معتبر در ۱۴۰+ کشور است. سایر دوره‌ها شامل گواهی ${siteConfig.institute.typeFa} ایران و گواهی پایان دوره آموزشگاه هستند.`,
      },
    },
    {
      '@type': 'Question',
      name: 'نحوه ثبت‌نام در دوره‌ها چگونه است؟',
      acceptedAnswer: {
        '@type': 'Answer',
        text: `برای ثبت‌نام می‌توانید از طریق فرم ثبت‌نام در وبسایت، واتساپ (${siteConfig.contact.whatsapp}) یا تماس تلفنی (${siteConfig.contact.phone}) اقدام کنید. همچنین می‌توانید از مشاوره رایگان قبل از ثبت‌نام بهره‌مند شوید.`,
      },
    },
    {
      '@type': 'Question',
      name: `رویکرد آموزشی ${siteConfig.name.fa} چه تفاوتی دارد؟`,
      acceptedAnswer: {
        '@type': 'Answer',
        text: `پلتفرم ${siteConfig.name.fa} بر پایه آموزش مبتنی بر شایستگی (CBT) طراحی شده. در این سیستم، ارتقا به ماژول بعدی منوط به تأیید یک مأموریت عملی است، نه صرفاً تماشای ویدیو. هدف اطمینان از تسلط واقعی کارآموز بر مهارت‌هاست.`,
      },
    },
    {
      '@type': 'Question',
      name: 'آیا امکان پرداخت اقساطی وجود دارد؟',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'بله، برای برخی دوره‌ها امکان پرداخت اقساطی فراهم است. همچنین برای سازمان‌ها و شرکت‌ها، پیش‌فاکتور رسمی صادر می‌شود. برای جزئیات با واحد پشتیبانی تماس بگیرید.',
      },
    },
    {
      '@type': 'Question',
      name: 'خدمات مشاوره کسب‌وکار شامل چه مواردی است؟',
      acceptedAnswer: {
        '@type': 'Answer',
        text: `خدمات مشاوره شامل عارضه‌یابی سازمانی، سیستم‌سازی فرآیندها، استراتژی رشد و توسعه، و انکوباسیون استارتاپ است. مشاوره‌ها مستقیماً زیر نظر ${siteConfig.founder.name}، دارای دکتری کارآفرینی، ارائه می‌شود.`,
      },
    },
  ],
};

const webSiteSchema = {
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: siteConfig.name.fullName,
  url: siteConfig.url.base,
  inLanguage: 'fa-IR',
  description:
    `پلتفرم مهارت‌آموزی ${siteConfig.institute.typeFa} ${siteConfig.name.fa} با ${siteConfig.experience.yearsFa} سال تجربه — آموزش مبتنی بر شایستگی (CBT)`,
  publisher: {
    '@type': 'Organization',
    name: siteConfig.name.fullName,
  },
  potentialAction: {
    '@type': 'SearchAction',
    target: {
      '@type': 'EntryPoint',
      urlTemplate: `${siteConfig.url.base}/courses?q={search_term_string}`,
    },
    'query-input': 'required name=search_term_string',
  },
};

// Homepage breadcrumb: Home only (page-specific)
const homeBreadcrumbSchema = {
  '@context': 'https://schema.org',
  '@type': 'BreadcrumbList',
  itemListElement: [
    {
      '@type': 'ListItem',
      position: 1,
      name: 'خانه',
      item: siteConfig.url.base,
    },
  ],
};

// ItemList for course directory (keeps course discoverability without duplicate Course schemas)
const itemListSchema = {
  '@context': 'https://schema.org',
  '@type': 'ItemList',
  name: `دوره‌های آموزشی ${siteConfig.name.fa}`,
  itemListElement: courses.map((course, index) => ({
    '@type': 'ListItem',
    position: index + 1,
    item: {
      '@type': 'Course',
      name: course.title,
      url: `${siteConfig.url.base}/courses/${course.slug}`,
      description: course.subtitle,
      provider: {
        '@type': 'Organization',
        name: siteConfig.name.fullName,
      },
      educationalLevel: course.level === 'پایه' ? 'Beginner' : course.level === 'متوسط' ? 'Intermediate' : 'Advanced',
      inLanguage: 'fa-IR',
      coursePrerequisites: course.prerequisites?.join(', ') || 'بدون پیش‌نیاز',
    },
  })),
};

export default function SchemaMarkup() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(organizationSchema),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(webSiteSchema),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(homeBreadcrumbSchema),
        }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(itemListSchema),
        }}
      />
      {/* FAQ schema for rich snippets in Google */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(faqSchema),
        }}
      />
    </>
  );
}
