'use client';

import { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { siteConfig } from '@/config/site';

const faqs = [
  {
    question: 'دوره ICDL شامل چه مباحثی است؟',
    answer:
      'دوره ICDL شامل مهارت‌های هفت‌گانه کامپیوتر است: Windows، Word، Excel، PowerPoint، Access، Internet و Outlook. پس از اتمام دوره، شما قادر خواهید بود آزمون گواهینامه بین‌المللی ICDL را با موفقیت پشت سر بگذارید.',
  },
  {
    question: 'دوره Scratch برای چه سنی مناسب است؟',
    answer:
      'دوره Scratch برای کودکان و نوجوانان ۸ تا ۱۵ سال طراحی شده است. در این دوره، دانش‌آموزان با برنامه‌نویسی بصری آشنا شده و تفکر محاسباتی، منطق و خلاقیت خود را توسعه می‌دهند.',
  },
  {
    question: 'آیا بعد از دوره Python می‌توانم وارد بازار کار شوم؟',
    answer:
      `بله، دوره Python ${siteConfig.name.fa} از مقدماتی تا پیشرفته طراحی شده و شامل پروژه‌های عملی و واقعی است. پس از اتمام دوره، شما مهارت‌های لازم برای ورود به بازار کار برنامه‌نویسی را خواهید داشت.`,
  },
  {
    question: 'مشاوره کسب‌وکار چگونه برگزار می‌شود؟',
    answer:
      `مشاوره کسب‌وکار به صورت اختصاصی و یک‌به‌یک با ${siteConfig.founder.name} برگزار می‌شود. مباحث شامل راه‌اندازی و توسعه کسب‌وکار، بازاریابی دیجیتال و مدیریت مالی است. جلسات بر اساس نیاز شما شخصی‌سازی می‌شوند.`,
  },
  {
    question: 'آیا گواهینامه دوره‌ها معتبر است؟',
    answer:
      `گواهینامه ICDL یک گواهینامه بین‌المللی معتبر است که توسط سازمان ICDL Foundation صادر می‌شود و در سراسر جهان شناخته شده است. سایر دوره‌ها نیز گواهینامه ${siteConfig.name.fa} را دریافت می‌کنید که مورد تأیید سازمان ${siteConfig.institute.typeFa} است.`,
  },
  {
    question: 'نحوه ثبت‌نام در دوره‌ها چگونه است؟',
    answer:
      `برای ثبت‌نام می‌توانید از طریق فرم تماس در وبسایت، واتساپ (${siteConfig.contact.whatsappDisplay}) یا تماس تلفنی (${siteConfig.contact.phone}) اقدام کنید. همچنین می‌توانید مستقیماً به آموزشگاه مراجعه نمایید.`,
  },
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-[#ccfbf1] text-[#0d9488] rounded-full px-4 py-1.5 mb-4">
            <HelpCircle className="w-4 h-4" />
            <span className="text-sm font-medium">سوالات متداول</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0f172a] mb-4">
            پرسش‌های رایج
          </h2>
          <p className="text-[#64748b] text-base max-w-xl mx-auto leading-relaxed">
            پاسخ سوالات رایج درباره دوره‌ها و خدمات {siteConfig.name.fa}
          </p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-3">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className={`rounded-xl border transition-all duration-300 ${
                openIndex === index
                  ? 'border-[#0d9488]/30 bg-[#ccfbf1]/30 shadow-sm'
                  : 'border-gray-100 bg-white hover:border-gray-200'
              }`}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between gap-4 p-5 text-right"
                aria-expanded={openIndex === index}
              >
                <span
                  className={`text-sm sm:text-base font-medium leading-relaxed ${
                    openIndex === index ? 'text-[#0d9488]' : 'text-[#0f172a]'
                  }`}
                >
                  {faq.question}
                </span>
                <ChevronDown
                  className={`w-5 h-5 flex-shrink-0 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180 text-[#0d9488]' : 'text-gray-400'
                  }`}
                />
              </button>
              {openIndex === index && (
                <div className="px-5 pb-5">
                  <p className="text-sm text-[#475569] leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
