'use client'

import { useBehaviorTracking } from '@/hooks/useBehaviorTracking'

export default function BehaviorTracker() {
  useBehaviorTracking()
  return null
}
