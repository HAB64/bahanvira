'use client';

import dynamic from 'next/dynamic';

// Client-side only widgets — must be in a 'use client' file to use ssr: false
const AIConsultantWidget = dynamic(
  () => import('@/components/ai/AIConsultantWidget'),
  { ssr: false }
);

const PersonalizedRecommendations = dynamic(
  () => import('@/components/ai/PersonalizedRecommendations'),
  { ssr: false }
);

const BehaviorTracker = dynamic(
  () => import('@/components/ai/BehaviorTracker'),
  { ssr: false }
);

export { AIConsultantWidget, PersonalizedRecommendations, BehaviorTracker };
