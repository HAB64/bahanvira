'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import { Bot, X, Send, Sparkles, MessageCircle } from 'lucide-react'

interface ChatMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
  suggestedCourses?: string[]
  timestamp: Date
}

const QUICK_ACTIONS = [
  { label: 'یافتن مسیر شغلی', icon: '🧭', message: 'می‌خواهم مسیر شغلی مناسبم را پیدا کنم' },
  { label: 'پیشنهاد دوره', icon: '📚', message: 'چه دوره‌ای برای من مناسب است؟' },
  { label: 'سوال درباره هزینه', icon: '💰', message: 'هزینه و شهریه دوره‌ها چقدر است؟' },
  { label: 'مشاوره رایگان', icon: '📞', message: 'چگونه می‌توانم مشاوره رایگان دریافت کنم؟' },
  { label: 'مدرک و اعتبار', icon: '🏅', message: 'مدارک دوره‌ها چه اعتباری دارند؟ آیا برای مهاجرت هم معتبر است؟' },
  { label: 'دوره کودکان', icon: '👦', message: 'چه دوره‌هایی برای کودکان و نوجوانان دارید؟' },
  { label: 'مقایسه دوره‌ها', icon: '⚖️', message: 'تفاوت دوره‌ها با هم چیست؟ کدام را انتخاب کنم؟' },
  { label: 'ساعات و شیفت‌ها', icon: '🕐', message: 'ساعات کلاس‌ها و شیفت‌ها چگونه است؟' },
  { label: 'ثبت‌نام', icon: '✍️', message: 'چگونه می‌توانم ثبت‌نام کنم؟ مراحل ثبت‌نام چیست؟' },
  { label: 'آدرس و تماس', icon: '📍', message: 'آدرس آموزشگاه و شماره تماس چیست؟' },
  { label: 'فارغ‌التحصیلان', icon: '🌟', message: 'آیا فارغ‌التحصیلان موفقی دارید؟' },
  { label: 'پیشنهاد بر اساس سن', icon: '🎯', message: 'من [سن] ساله هستم، چه دوره‌ای پیشنهاد می‌کنید؟' },
]

export default function AIConsultantWidget() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [sessionId, setSessionId] = useState('')
  const [showQuickActions, setShowQuickActions] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  /** ساخت شناسه نشست جدید */
  const createNewSession = useCallback(() => {
    const sid = 'cs-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9)
    localStorage.setItem('br_consult_session', sid)
    setSessionId(sid)
    setMessages([])
    setShowQuickActions(true)
  }, [])

  // Initialize session ID from localStorage
  useEffect(() => {
    let sid = localStorage.getItem('br_consult_session')
    if (!sid) {
      sid = 'cs-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9)
      localStorage.setItem('br_consult_session', sid)
    }
    setSessionId(sid)
  }, [])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Focus input when opening
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 300)
    }
  }, [isOpen])

  // وقتی چت‌بات بسته می‌شود، نشست ریست شود
  useEffect(() => {
    if (!isOpen && sessionId) {
      createNewSession()
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen])

  const sendMessage = useCallback(async (messageText: string) => {
    if (!messageText.trim() || isLoading || !sessionId) return

    const userMessage: ChatMessage = {
      role: 'user',
      content: messageText.trim(),
      timestamp: new Date(),
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsLoading(true)
    setShowQuickActions(false)

    try {
      const res = await fetch('/api/ai-consultant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText.trim(),
          sessionId,
          context: {
            page: window.location.pathname,
          },
        }),
      })

      if (!res.ok) throw new Error('Failed to get response')

      const data = await res.json()

      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: data.reply,
        suggestedCourses: data.suggestedCourses || [],
        timestamp: new Date(),
      }

      setMessages(prev => [...prev, assistantMessage])
    } catch (error) {
      console.error('Chat error:', error)
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: 'متاسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید.',
        timestamp: new Date(),
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }, [isLoading, sessionId])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    sendMessage(input)
  }

  const handleQuickAction = (message: string) => {
    sendMessage(message)
  }

  return (
    <>
      {/* Chat Bubble Button */}
      <button
        onClick={() => setIsOpen(prev => !prev)}
        className="fixed bottom-20 left-4 z-50 w-14 h-14 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center group"
        style={{
          background: isOpen ? '#1f2937' : 'linear-gradient(135deg, #0d9488, #8B5CF6)',
        }}
        aria-label={isOpen ? 'بستن مشاور هوشمند' : 'باز کردن مشاور هوشمند'}
      >
        {isOpen ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <div className="relative">
            <Bot className="w-7 h-7 text-white group-hover:scale-110 transition-transform" />
            <Sparkles className="w-3 h-3 text-yellow-300 absolute -top-1 -right-1 animate-pulse" />
          </div>
        )}
      </button>

      {/* Chat Panel */}
      <div
        className={`fixed bottom-36 left-4 z-50 w-[calc(100vw-2rem)] sm:w-96 transition-all duration-300 ${
          isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8 pointer-events-none'
        }`}
      >
        <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden flex flex-col max-h-[70vh]">
          {/* Header */}
          <div
            className="px-4 py-3 flex items-center justify-between shrink-0"
            style={{ background: 'linear-gradient(135deg, #0d9488, #8B5CF6)' }}
          >
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold text-sm">مشاور هوشمند بهان رایانه</h3>
                <p className="text-white/70 text-xs">آماده راهنمایی شماست</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white transition-colors"
              aria-label="بستن"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-[200px] max-h-[400px]" style={{ direction: 'rtl' }}>
            {/* Welcome message */}
            {messages.length === 0 && (
              <div className="text-center py-6">
                <div className="w-16 h-16 mx-auto mb-3 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #0d9488, #8B5CF6)' }}>
                  <MessageCircle className="w-8 h-8 text-white" />
                </div>
                <p className="text-gray-700 font-bold text-sm mb-1">سلام! من مشاور هوشمند شما هستم</p>
                <p className="text-gray-500 text-xs">می‌توانم در یافتن مسیر شغلی و انتخاب دوره به شما کمک کنم</p>
              </div>
            )}

            {/* Message list */}
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-gray-100 text-gray-800 rounded-br-sm'
                      : 'text-white rounded-bl-sm'
                  }`}
                  style={msg.role === 'assistant' ? { background: 'linear-gradient(135deg, #0d9488, #7c3aed)' } : {}}
                >
                  <p className="whitespace-pre-wrap">{msg.content}</p>

                  {/* Suggested courses */}
                  {msg.suggestedCourses && msg.suggestedCourses.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {msg.suggestedCourses.map((course, cIdx) => (
                        <span
                          key={cIdx}
                          className="inline-block text-xs bg-white/20 text-white rounded-full px-2 py-0.5"
                        >
                          {course}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Loading indicator */}
            {isLoading && (
              <div className="flex justify-end">
                <div
                  className="rounded-2xl px-4 py-3 rounded-bl-sm text-white"
                  style={{ background: 'linear-gradient(135deg, #0d9488, #7c3aed)' }}
                >
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-white/60 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Actions */}
          {showQuickActions && messages.length === 0 && (
            <div className="px-4 pb-2 shrink-0" style={{ direction: 'rtl' }}>
              <div className="flex flex-wrap gap-2">
                {QUICK_ACTIONS.map((action, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleQuickAction(action.message)}
                    className="text-xs bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-full px-3 py-1.5 transition-colors border border-gray-200"
                  >
                    <span className="ml-1">{action.icon}</span>
                    {action.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <form
            onSubmit={handleSubmit}
            className="border-t border-gray-100 p-3 flex items-center gap-2 shrink-0"
            style={{ direction: 'rtl' }}
          >
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="پیام خود را بنویسید..."
              className="flex-1 bg-gray-50 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-teal-500/30 border border-gray-200 focus:border-teal-500 transition-all"
              disabled={isLoading}
              dir="rtl"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="w-10 h-10 rounded-xl flex items-center justify-center transition-all shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: input.trim() ? 'linear-gradient(135deg, #0d9488, #8B5CF6)' : '#e5e7eb' }}
            >
              <Send className={`w-4 h-4 ${input.trim() ? 'text-white' : 'text-gray-400'}`} />
            </button>
          </form>
        </div>
      </div>
    </>
  )
}
