'use client'

import { useState, useEffect } from 'react'
import { Sparkles, MapPin, BookOpen, ChevronLeft } from 'lucide-react'

interface Recommendation {
  step: number
  courseSlug: string
  courseTitle: string
  cluster: string
  clusterLabel: string
  reason: string
  confidence: number
}

interface PathStep {
  step: number
  title: string
  description: string
  courses: string[]
}

export default function PersonalizedRecommendations() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([])
  const [path, setPath] = useState<PathStep[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [sessionId, setSessionId] = useState('')
  const [expanded, setExpanded] = useState(false)

  useEffect(() => {
    let sid = localStorage.getItem('br_consult_session')
    if (!sid) {
      sid = 'cs-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9)
      localStorage.setItem('br_consult_session', sid)
    }
    setSessionId(sid)
  }, [])

  useEffect(() => {
    if (!sessionId) return

    const fetchRecommendations = async () => {
      try {
        const res = await fetch(`/api/ai/personalize?sessionId=${sessionId}`)
        if (res.ok) {
          const data = await res.json()
          setRecommendations(data.recommendations || [])
          setPath(data.path || [])
        }
      } catch {
        // Silently fail
      } finally {
        setIsLoading(false)
      }
    }

    fetchRecommendations()
  }, [sessionId])

  // Don't show if no recommendations
  if (!isLoading && recommendations.length === 0) return null

  const levelLabels: Record<string, string> = {
    'FOUNDATION': 'پایه',
    'SPECIALIZED': 'تخصصی',
    'STRATEGIC': 'استراتژیک',
  }

  return (
    <section className="py-16 sm:py-20 relative overflow-hidden" dir="rtl">
      <div className="absolute inset-0 bg-gradient-to-br from-[#0a192f] via-[#0d1f3c] to-[#0a1628]" />
      <div className="absolute inset-0 circuit-grid opacity-[0.06]" />
      <div className="absolute top-1/3 left-1/4 w-80 h-80 bg-teal-600/10 rounded-full blur-[100px]" />
      <div className="absolute bottom-1/4 right-1/3 w-72 h-72 bg-purple-600/10 rounded-full blur-[90px]" />
      <div className="relative z-10 max-w-5xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-3 px-4 py-1.5 rounded-full text-sm font-medium bg-teal-500/15 border border-teal-500/20 text-teal-300">
            <Sparkles className="w-4 h-4" />
            <span>پیشنهاد هوشمند</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2">
            مسیر پیشنهادی شما
          </h2>
          <p className="text-gray-400 text-sm sm:text-base">
            بر اساس رفتار و علایق شما، این مسیر یادگیری پیشنهاد می‌شود
          </p>
        </div>

        {/* Path Visualization */}
        {path.length > 0 && (
          <div className="flex items-center justify-center gap-0 mb-8 overflow-x-auto pb-2">
            {path.map((step, idx) => (
              <div key={idx} className="flex items-center">
                <div className="flex flex-col items-center min-w-[120px]">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg mb-2 shadow-lg"
                    style={{ background: `linear-gradient(135deg, #0d9488, ${idx === 0 ? '#0d9488' : idx === 1 ? '#8B5CF6' : '#7c3aed'})` }}
                  >
                    {step.step}
                  </div>
                  <span className="text-sm font-bold text-white">{step.title}</span>
                  <span className="text-xs text-gray-400 mt-0.5">{step.description}</span>
                </div>
                {idx < path.length - 1 && (
                  <ChevronLeft className="w-5 h-5 text-teal-500/40 mx-2 shrink-0 mt-[-20px]" />
                )}
              </div>
            ))}
          </div>
        )}

        {/* Recommendation Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, idx) => (
              <div key={idx} className="glass-card rounded-xl p-5 animate-pulse">
                <div className="h-4 bg-white/10 rounded w-3/4 mb-3" />
                <div className="h-3 bg-white/5 rounded w-1/2 mb-4" />
                <div className="h-3 bg-white/5 rounded w-full" />
              </div>
            ))
          ) : (
            recommendations.slice(0, expanded ? 6 : 3).map((rec, idx) => {
              const occ = rec.courseSlug
              const matchPercent = Math.round(rec.confidence * 100)

              return (
                <div
                  key={idx}
                  className="glass-card rounded-xl p-5 hover:shadow-lg hover:shadow-teal-500/5 transition-all group cursor-pointer border border-white/10"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full border font-medium ${
                        rec.cluster === 'it' ? 'bg-teal-500/15 text-teal-300 border-teal-500/20' :
                        rec.cluster === 'ai' ? 'bg-purple-500/15 text-purple-300 border-purple-500/20' :
                        'bg-amber-500/15 text-amber-300 border-amber-500/20'
                      }`}
                    >
                      {rec.clusterLabel}
                    </span>
                    <span className="text-xs font-bold text-teal-400">{matchPercent}% تطابق</span>
                  </div>

                  <h3 className="font-bold text-white mb-1 group-hover:text-teal-300 transition-colors flex items-center gap-1.5">
                    <BookOpen className="w-4 h-4 text-teal-400 shrink-0" />
                    <span>{rec.courseTitle}</span>
                  </h3>

                  <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                    <MapPin className="w-3 h-3 inline ml-1" />
                    {rec.reason}
                  </p>

                  <div className="mt-3 h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${matchPercent}%`,
                        background: 'linear-gradient(90deg, #0d9488, #8B5CF6)',
                      }}
                    />
                  </div>
                </div>
              )
            })
          )}
        </div>

        {/* Expand button */}
        {recommendations.length > 3 && !expanded && (
          <div className="text-center mt-6">
            <button
              onClick={() => setExpanded(true)}
              className="text-sm text-teal-400 hover:text-teal-300 font-medium transition-colors"
            >
              مشاهده بیشتر...
            </button>
          </div>
        )}
      </div>
    </section>
  )
}
