/**
 * useGTM — Custom Hook for Event Tracking
 * ===========================================
 * Pushes events to:
 *   1. window.dataLayer (for GTM, when configured)
 *   2. /api/track endpoint (server-side storage in EventLog table)
 *
 * Works with or without GTM — all events are captured regardless.
 *
 * Usage:
 *   const { trackFormSubmission, trackWhatsappClick } = useGTM();
 *
 * File: src/hooks/useGTM.ts
 */

import { useCallback } from 'react';
import type {
  GTMEventData,
  GTMFormSubmissionEvent,
  GTMWhatsappClickEvent,
  GTMCareerTestEvent,
  GTMPricingPageViewEvent,
  InterestedCategory,
  LeadSource,
} from '@/types/lead';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function generateEventId(): string {
  return `evt_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

/** Push to dataLayer (GTM) — no-op on server */
function pushToDataLayer<T extends GTMEventData>(data: T): void {
  if (typeof window === 'undefined') return;
  (window as unknown as Record<string, unknown[]>).dataLayer =
    (window as unknown as Record<string, unknown[]>).dataLayer || [];
  (window as unknown as Record<string, unknown[]>).dataLayer.push(data as unknown);
}

/** Send to /api/track — server-side persistence (fire-and-forget) */
function sendToTrackApi(eventData: Record<string, unknown>): void {
  if (typeof window === 'undefined') return;
  try {
    fetch('/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...eventData,
        page_url: typeof window !== 'undefined' ? window.location.href : '',
        page_title: typeof document !== 'undefined' ? document.title : '',
        referrer: typeof document !== 'undefined' ? document.referrer : '',
      }),
      keepalive: true, // survives page unload
    }).catch(() => {}); // silent fail — never block UX
  } catch {
    // silent
  }
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useGTM() {
  const trackFormSubmission = useCallback(
    (params: {
      formType: string;
      formLocation: string;
      interestedCategory: InterestedCategory;
      source: LeadSource;
    }) => {
      const event: GTMFormSubmissionEvent = {
        event: 'form_submission',
        event_id: generateEventId(),
        event_timestamp: Date.now(),
        event_params: {
          form_type: params.formType,
          form_location: params.formLocation,
          interested_category: params.interestedCategory,
          source: params.source,
        },
      };
      pushToDataLayer(event);
      sendToTrackApi(event);
    },
    [],
  );

  const trackWhatsappClick = useCallback((params: {
    clickUrl?: string;
    utmSource?: string;
    utmCampaign?: string;
  }) => {
    const event: GTMWhatsappClickEvent = {
      event: 'whatsapp_click',
      event_id: generateEventId(),
      event_timestamp: Date.now(),
      event_params: {
        click_url: params.clickUrl ?? '',
        page_url: typeof window !== 'undefined' ? window.location.href : '',
        utm_source: params.utmSource,
        utm_campaign: params.utmCampaign,
      },
    };
    pushToDataLayer(event);
    sendToTrackApi(event);
  }, []);

  const trackCareerTestCompleted = useCallback((params: {
    resultCategory: InterestedCategory;
    totalQuestions: number;
    completionTimeSeconds: number;
  }) => {
    const event: GTMCareerTestEvent = {
      event: 'career_test_completed',
      event_id: generateEventId(),
      event_timestamp: Date.now(),
      event_params: {
        result_category: params.resultCategory,
        total_questions: params.totalQuestions,
        completion_time_seconds: params.completionTimeSeconds,
      },
    };
    pushToDataLayer(event);
    sendToTrackApi(event);
  }, []);

  const trackPricingPageView = useCallback(() => {
    const event: GTMPricingPageViewEvent = {
      event: 'page_view_pricing',
      event_id: generateEventId(),
      event_timestamp: Date.now(),
      event_params: {
        page_url: typeof window !== 'undefined' ? window.location.href : '',
        page_title: typeof document !== 'undefined' ? document.title : '',
        referrer: typeof document !== 'undefined' ? document.referrer : '',
      },
    };
    pushToDataLayer(event);
    sendToTrackApi(event);
  }, []);

  const pushEvent = useCallback(<T extends Record<string, unknown>>(data: T) => {
    if (typeof window === 'undefined') return;
    const enriched = {
      ...data,
      event_id: generateEventId(),
      event_timestamp: Date.now(),
    };
    (window as unknown as Record<string, unknown[]>).dataLayer =
      (window as unknown as Record<string, unknown[]>).dataLayer || [];
    (window as unknown as Record<string, unknown[]>).dataLayer.push(enriched);
    sendToTrackApi(enriched);
  }, []);

  return {
    trackFormSubmission,
    trackWhatsappClick,
    trackCareerTestCompleted,
    trackPricingPageView,
    pushEvent,
  } as const;
}