'use client';

import { useSyncExternalStore } from 'react';

/**
 * Hook to capture UTM parameters from the URL.
 * Uses useSyncExternalStore to read URL search params
 * without Suspense boundary requirements.
 *
 * Usage: const utm = useUTM();
 * Returns: { utmSource, utmMedium, utmCampaign }
 *
 * These values are automatically passed to lead creation APIs
 * for marketing attribution and analytics.
 */

// Stable empty object reference for server snapshot
// This prevents infinite re-renders because useSyncExternalStore
// uses Object.is to compare snapshots - a new {} each time would
// trigger an infinite re-render loop
const EMPTY_UTM = { utmSource: '', utmMedium: '', utmCampaign: '' };

// Cache the last snapshot to maintain referential stability
let cachedSnapshot: { utmSource: string; utmMedium: string; utmCampaign: string } | null = null;
let cachedSearch = '';

function getUTMFromURL() {
  if (typeof window === 'undefined') {
    return EMPTY_UTM;
  }
  const search = window.location.search;
  // Return cached snapshot if search params haven't changed
  if (search === cachedSearch && cachedSnapshot) {
    return cachedSnapshot;
  }
  cachedSearch = search;
  const params = new URLSearchParams(search);
  cachedSnapshot = {
    utmSource: params.get('utm_source') || '',
    utmMedium: params.get('utm_medium') || '',
    utmCampaign: params.get('utm_campaign') || '',
  };
  return cachedSnapshot;
}

function subscribeToURL(callback: () => void) {
  window.addEventListener('popstate', callback);
  return () => window.removeEventListener('popstate', callback);
}

export function useUTM() {
  return useSyncExternalStore(subscribeToURL, getUTMFromURL, () => EMPTY_UTM);
}
