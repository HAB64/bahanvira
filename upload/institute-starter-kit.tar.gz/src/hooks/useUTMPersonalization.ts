'use client';

import { useSyncExternalStore } from 'react';

/**
 * Hook to detect persona based on UTM parameters for dynamic personalization.
 * Reads utm_source, utm_campaign, utm_medium, utm_content from URL search params.
 *
 * Returns a persona object or null if no matching UTM is detected.
 */

export type UTMPersona = 'teen' | 'trader' | 'entrepreneur' | 'jobseeker';

export interface UTMPersonalization {
  persona: UTMPersona;
  utmSource: string;
  utmCampaign: string;
  utmMedium: string;
  utmContent: string;
}

const EMPTY_RESULT = { result: null as UTMPersonalization | null, search: '' };
let cachedResult: { result: UTMPersonalization | null; search: string } = EMPTY_RESULT;

function detectPersona(campaign: string): UTMPersona | null {
  const lower = campaign.toLowerCase();

  if (lower.includes('teen') || lower.includes('scratch') || lower.includes('python')) {
    return 'teen';
  }
  if (lower.includes('forex') || lower.includes('trading') || lower.includes('mql5')) {
    return 'trader';
  }
  if (lower.includes('business') || lower.includes('entrepreneur')) {
    return 'entrepreneur';
  }
  if (lower.includes('icdl') || lower.includes('office') || lower.includes('employment')) {
    return 'jobseeker';
  }

  return null;
}

function getUTMPersonaFromURL(): UTMPersonalization | null {
  if (typeof window === 'undefined') {
    return null;
  }

  const search = window.location.search;

  // Return cached if unchanged
  if (search === cachedResult.search) {
    return cachedResult.result;
  }

  const params = new URLSearchParams(search);
  const utmSource = params.get('utm_source') || '';
  const utmCampaign = params.get('utm_campaign') || '';
  const utmMedium = params.get('utm_medium') || '';
  const utmContent = params.get('utm_content') || '';

  // Try to detect persona from campaign first, then source, then content
  const persona =
    detectPersona(utmCampaign) ||
    detectPersona(utmSource) ||
    detectPersona(utmContent);

  const result = persona
    ? { persona, utmSource, utmCampaign, utmMedium, utmContent }
    : null;

  cachedResult = { result, search };
  return result;
}

function subscribeToURL(callback: () => void) {
  window.addEventListener('popstate', callback);
  return () => window.removeEventListener('popstate', callback);
}

export function useUTMPersonalization(): UTMPersonalization | null {
  return useSyncExternalStore(subscribeToURL, getUTMPersonaFromURL, () => null);
}
