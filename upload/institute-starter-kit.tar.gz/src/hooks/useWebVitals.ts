/**
 * useWebVitals — Client-side Core Web Vitals Reporter
 * جمع‌آوری متریک‌های واقعی LCP, INP, CLS, FCP, TTFB, TBT
 * و ارسال به API برای تحلیل
 */
'use client';

import { useEffect, useState, useCallback } from 'react';

export interface WebVitalReport {
  name: string;
  value: number;
  rating: string;
  delta: number;
  navigationType: string;
  url: string;
  timestamp: number;
}

interface UseWebVitalsOptions {
  /** ارسال خودکار به سرور (پیش‌فرض: true) */
  reportToServer?: boolean;
  /** گزارش فقط در تولید (پیش‌فرض: true) */
  productionOnly?: boolean;
  /** کال‌بک برای هر متریک */
  onMetric?: (metric: WebVitalReport) => void;
}

export function useWebVitals(options: UseWebVitalsOptions = {}) {
  const { reportToServer = true, productionOnly = true, onMetric } = options;
  const [metrics, setMetrics] = useState<WebVitalReport[]>([]);
  const [isSupported, setIsSupported] = useState(false);

  const reportMetric = useCallback(async (metric: WebVitalReport) => {
    onMetric?.(metric);

    setMetrics(prev => [...prev.slice(-9), metric]); // Keep last 10

    if (reportToServer && (!productionOnly || process.env.NODE_ENV === 'production')) {
      try {
        // Use sendBeacon for reliability during page unload
        const data = JSON.stringify(metric);
        if (navigator.sendBeacon) {
          navigator.sendBeacon('/api/admin/web-vitals', data);
        } else {
          fetch('/api/admin/web-vitals', {
            method: 'POST',
            body: data,
            headers: { 'Content-Type': 'application/json' },
            keepalive: true,
          }).catch(() => {});
        }
      } catch {
        // Silently fail — web vitals reporting is non-critical
      }
    }
  }, [reportToServer, productionOnly, onMetric]);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Check PerformanceObserver support
    if (!('PerformanceObserver' in window)) {
      setIsSupported(false);
      return;
    }
    setIsSupported(true);

    const url = window.location.href;
    const timestamp = Date.now();

    // ─── LCP (Largest Contentful Paint) ───────────────────
    try {
      const lcpObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        if (lastEntry) {
          const value = lastEntry.startTime / 1000; // Convert to seconds
          reportMetric({
            name: 'LCP',
            value: Math.round(value * 100) / 100,
            rating: value <= 2.5 ? 'good' : value <= 4 ? 'needs-improvement' : 'poor',
            delta: 0,
            navigationType: (lastEntry as any).navigationType || 'navigate',
            url,
            timestamp,
          });
        }
      });
      lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });
    } catch { /* Not supported */ }

    // ─── FCP (First Contentful Paint) ─────────────────────
    try {
      const fcpObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        for (const entry of entries) {
          if (entry.name === 'first-contentful-paint') {
            const value = entry.startTime / 1000;
            reportMetric({
              name: 'FCP',
              value: Math.round(value * 100) / 100,
              rating: value <= 1.8 ? 'good' : value <= 3 ? 'needs-improvement' : 'poor',
              delta: 0,
              navigationType: (entry as any).navigationType || 'navigate',
              url,
              timestamp,
            });
          }
        }
      });
      fcpObserver.observe({ type: 'paint', buffered: true });
    } catch { /* Not supported */ }

    // ─── CLS (Cumulative Layout Shift) ────────────────────
    try {
      let clsValue = 0;
      let clsEntries: any[] = [];
      let sessionValue = 0;
      let sessionEntries: any[] = [];

      const clsObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          const layoutShift = entry as any;
          if (!layoutShift.hadRecentInput) {
            const firstSessionEntry = sessionEntries[0];
            const lastSessionEntry = sessionEntries[sessionEntries.length - 1];

            if (sessionValue &&
                layoutShift.startTime - lastSessionEntry.startTime < 1000 &&
                layoutShift.startTime - firstSessionEntry.startTime < 5000) {
              sessionValue += layoutShift.value;
              sessionEntries.push(layoutShift);
            } else {
              sessionValue = layoutShift.value;
              sessionEntries = [layoutShift];
            }

            if (sessionValue > clsValue) {
              clsValue = sessionValue;
              clsEntries = sessionEntries;
            }
          }
        }
      });
      clsObserver.observe({ type: 'layout-shift', buffered: true });

      // Report CLS on page hide
      const reportCLS = () => {
        if (clsValue > 0) {
          reportMetric({
            name: 'CLS',
            value: Math.round(clsValue * 1000) / 1000,
            rating: clsValue <= 0.1 ? 'good' : clsValue <= 0.25 ? 'needs-improvement' : 'poor',
            delta: clsValue,
            navigationType: 'navigate',
            url,
            timestamp,
          });
        }
      };
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') reportCLS();
      });
    } catch { /* Not supported */ }

    // ─── INP (Interaction to Next Paint) ──────────────────
    try {
      let maxINP = 0;
      const inpObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          const eventEntry = entry as any;
          const duration = eventEntry.duration || 0;
          if (duration > maxINP) {
            maxINP = duration;
          }
        }
      });
      inpObserver.observe({ type: 'event', buffered: true });

      // Report INP on page hide
      const reportINP = () => {
        if (maxINP > 0) {
          reportMetric({
            name: 'INP',
            value: Math.round(maxINP),
            rating: maxINP <= 200 ? 'good' : maxINP <= 500 ? 'needs-improvement' : 'poor',
            delta: maxINP,
            navigationType: 'navigate',
            url,
            timestamp,
          });
        }
      };
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') reportINP();
      });
    } catch { /* Not supported */ }

    // ─── TTFB (Time to First Byte) ────────────────────────
    try {
      const navEntry = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
      if (navEntry) {
        const value = navEntry.responseStart / 1000;
        reportMetric({
          name: 'TTFB',
          value: Math.round(value * 100) / 100,
          rating: value <= 0.8 ? 'good' : value <= 1.8 ? 'needs-improvement' : 'poor',
          delta: 0,
          navigationType: navEntry.type || 'navigate',
          url,
          timestamp,
        });
      }
    } catch { /* Not supported */ }
  }, [reportMetric]);

  return { metrics, isSupported };
}
