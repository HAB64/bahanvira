'use client'

import { useEffect, useRef, useCallback } from 'react'

interface TrackEvent {
  eventType: string
  page: string
  element?: string
  metadata?: Record<string, unknown>
  duration?: number
  cluster?: string
  courseSlug?: string
  referrer?: string
}

export function useBehaviorTracking() {
  const sessionIdRef = useRef<string>('')
  const pageEnterTimeRef = useRef<number>(Date.now())
  const batchRef = useRef<TrackEvent[]>([])
  const batchTimerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const hasTrackedPageView = useRef(false)

  const flushBatch = useCallback(async () => {
    if (batchRef.current.length === 0) return

    const eventsToSend = [...batchRef.current]
    batchRef.current = []

    try {
      // Send all events in a single batch request — reduces HTTP overhead
      await fetch('/api/behavior/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: sessionIdRef.current,
          batch: eventsToSend,
        }),
      })
    } catch {
      // Silently fail - behavior tracking is non-critical
    }
  }, [])

  const trackEvent = useCallback((event: TrackEvent) => {
    batchRef.current.push(event)

    // If batch is large, flush immediately
    if (batchRef.current.length >= 10) {
      flushBatch()
    }
  }, [flushBatch])

  // Initialize session ID
  useEffect(() => {
    let sid = localStorage.getItem('br_behavior_session')
    if (!sid) {
      sid = 'bs-' + Date.now() + '-' + Math.random().toString(36).substring(2, 9)
      localStorage.setItem('br_behavior_session', sid)
    }
    sessionIdRef.current = sid

    // Set up batch sending every 5 seconds
    batchTimerRef.current = setInterval(() => {
      flushBatch()
    }, 5000)

    return () => {
      if (batchTimerRef.current) {
        clearInterval(batchTimerRef.current)
      }
      // Flush remaining events on unmount
      flushBatch()
    }
  }, [flushBatch])

  // Track page view on route change
  useEffect(() => {
    pageEnterTimeRef.current = Date.now()

    if (!hasTrackedPageView.current) {
      hasTrackedPageView.current = true
      trackEvent({
        eventType: 'PAGE_VIEW',
        page: window.location.pathname,
        referrer: document.referrer || undefined,
      })
    }

    // Track time spent when leaving page
    return () => {
      const timeSpent = Math.round((Date.now() - pageEnterTimeRef.current) / 1000)
      if (timeSpent > 2) {
        trackEvent({
          eventType: 'TIME_SPENT',
          page: window.location.pathname,
          duration: timeSpent,
        })
      }
    }
  }, [trackEvent])

  const trackCourseView = useCallback((courseSlug: string, cluster?: string) => {
    trackEvent({
      eventType: 'COURSE_VIEW',
      page: window.location.pathname,
      courseSlug,
      cluster,
    })
  }, [trackEvent])

  const trackSearch = useCallback((query: string) => {
    trackEvent({
      eventType: 'SEARCH',
      page: window.location.pathname,
      metadata: { query },
    })
  }, [trackEvent])

  const trackCTAClick = useCallback((element: string, cluster?: string) => {
    trackEvent({
      eventType: 'CTA_CLICK',
      page: window.location.pathname,
      element,
      cluster,
    })
  }, [trackEvent])

  const trackQuizComplete = useCallback((cluster: string, score?: number) => {
    trackEvent({
      eventType: 'QUIZ_COMPLETE',
      page: window.location.pathname,
      cluster,
      metadata: score !== undefined ? { score } : undefined,
    })
  }, [trackEvent])

  const trackConsultationStart = useCallback((topic?: string) => {
    trackEvent({
      eventType: 'CONSULTATION_START',
      page: window.location.pathname,
      metadata: topic ? { topic } : undefined,
    })
  }, [trackEvent])

  return {
    trackEvent,
    trackCourseView,
    trackSearch,
    trackCTAClick,
    trackQuizComplete,
    trackConsultationStart,
  }
}
